const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/creation-journey-BlpuVZUr.js","assets/preload-helper-BlTxHScW.js","assets/equipment-icons-C0E5S3wP.js","assets/local-characters-DjkZAk9a.js","assets/page-transition-rUIT0izW.js","assets/graphics-advisor-BLamsr-N.js","assets/graphics-advisor-Dy5bEt4Q.css","assets/creation-journey-B3BJKFl6.css"])))=>i.map(i=>d[i]);
import{r as up}from"./local-characters-DjkZAk9a.js";import{o as dp,g as hp,a as zh,l as fp,r as pp,c as mp,b as gp}from"./page-transition-rUIT0izW.js";import{_ as vp}from"./preload-helper-BlTxHScW.js";import{m as _p}from"./graphics-advisor-BLamsr-N.js";/**
 * @license
 * Copyright 2010-2025 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const Ic="180",xp=0,xu=1,yp=2,Vh=1,bp=2,ai=3,mi=0,cn=1,Et=2,hi=0,Pi=1,tn=2,yu=3,bu=4,Sp=5,$i=100,Mp=101,Ep=102,Tp=103,Ap=104,wp=200,Rp=201,Cp=202,Ip=203,Cl=204,Il=205,Pp=206,Lp=207,Dp=208,Np=209,Op=210,Up=211,Fp=212,Bp=213,kp=214,Pl=0,Ll=1,Dl=2,kr=3,Nl=4,Ol=5,Ul=6,Fl=7,Pc=0,zp=1,Vp=2,Li=0,Hp=1,Gp=2,Wp=3,Hh=4,Xp=5,qp=6,Yp=7,Su="attached",jp="detached",Gh=300,zr=301,Vr=302,Bl=303,kl=304,lo=306,Hr=1e3,Ii=1001,Wa=1002,en=1003,Wh=1004,Ms=1005,Dt=1006,Fa=1007,Gt=1008,Yn=1009,Xh=1010,qh=1011,Is=1012,Lc=1013,Ji=1014,Bn=1015,fi=1016,Dc=1017,Nc=1018,Ps=1020,Yh=35902,jh=35899,$h=1021,Kh=1022,wn=1023,Ls=1026,Ds=1027,Oc=1028,Uc=1029,Zh=1030,Fc=1031,Bc=1033,Ba=33776,ka=33777,za=33778,Va=33779,zl=35840,Vl=35841,Hl=35842,Gl=35843,Wl=36196,Xl=37492,ql=37496,Yl=37808,jl=37809,$l=37810,Kl=37811,Zl=37812,Jl=37813,Ql=37814,ec=37815,tc=37816,nc=37817,ic=37818,rc=37819,sc=37820,ac=37821,oc=36492,lc=36494,cc=36495,uc=36283,dc=36284,hc=36285,fc=36286,Ns=2300,Os=2301,Lo=2302,Mu=2400,Eu=2401,Tu=2402,$p=2500,Kp=0,Jh=1,pc=2,Zp=3200,Jp=3201,kc=0,Qp=1,ci="",_t="srgb",nn="srgb-linear",Xa="linear",pt="srgb",rr=7680,Au=519,em=512,tm=513,nm=514,Qh=515,im=516,rm=517,sm=518,am=519,mc=35044,ef=35048,wu="300 es",qn=2e3,qa=2001;class es{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});const n=this._listeners;n[e]===void 0&&(n[e]=[]),n[e].indexOf(t)===-1&&n[e].push(t)}hasEventListener(e,t){const n=this._listeners;return n===void 0?!1:n[e]!==void 0&&n[e].indexOf(t)!==-1}removeEventListener(e,t){const n=this._listeners;if(n===void 0)return;const r=n[e];if(r!==void 0){const s=r.indexOf(t);s!==-1&&r.splice(s,1)}}dispatchEvent(e){const t=this._listeners;if(t===void 0)return;const n=t[e.type];if(n!==void 0){e.target=this;const r=n.slice(0);for(let s=0,a=r.length;s<a;s++)r[s].call(this,e);e.target=null}}}const qt=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];let Ru=1234567;const As=Math.PI/180,Gr=180/Math.PI;function kn(){const i=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(qt[i&255]+qt[i>>8&255]+qt[i>>16&255]+qt[i>>24&255]+"-"+qt[e&255]+qt[e>>8&255]+"-"+qt[e>>16&15|64]+qt[e>>24&255]+"-"+qt[t&63|128]+qt[t>>8&255]+"-"+qt[t>>16&255]+qt[t>>24&255]+qt[n&255]+qt[n>>8&255]+qt[n>>16&255]+qt[n>>24&255]).toLowerCase()}function Je(i,e,t){return Math.max(e,Math.min(t,i))}function zc(i,e){return(i%e+e)%e}function om(i,e,t,n,r){return n+(i-e)*(r-n)/(t-e)}function lm(i,e,t){return i!==e?(t-i)/(e-i):0}function ws(i,e,t){return(1-t)*i+t*e}function cm(i,e,t,n){return ws(i,e,1-Math.exp(-t*n))}function um(i,e=1){return e-Math.abs(zc(i,e*2)-e)}function dm(i,e,t){return i<=e?0:i>=t?1:(i=(i-e)/(t-e),i*i*(3-2*i))}function hm(i,e,t){return i<=e?0:i>=t?1:(i=(i-e)/(t-e),i*i*i*(i*(i*6-15)+10))}function fm(i,e){return i+Math.floor(Math.random()*(e-i+1))}function pm(i,e){return i+Math.random()*(e-i)}function mm(i){return i*(.5-Math.random())}function gm(i){i!==void 0&&(Ru=i);let e=Ru+=1831565813;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}function vm(i){return i*As}function _m(i){return i*Gr}function xm(i){return(i&i-1)===0&&i!==0}function ym(i){return Math.pow(2,Math.ceil(Math.log(i)/Math.LN2))}function bm(i){return Math.pow(2,Math.floor(Math.log(i)/Math.LN2))}function Sm(i,e,t,n,r){const s=Math.cos,a=Math.sin,o=s(t/2),l=a(t/2),c=s((e+n)/2),d=a((e+n)/2),u=s((e-n)/2),h=a((e-n)/2),p=s((n-e)/2),g=a((n-e)/2);switch(r){case"XYX":i.set(o*d,l*u,l*h,o*c);break;case"YZY":i.set(l*h,o*d,l*u,o*c);break;case"ZXZ":i.set(l*u,l*h,o*d,o*c);break;case"XZX":i.set(o*d,l*g,l*p,o*c);break;case"YXY":i.set(l*p,o*d,l*g,o*c);break;case"ZYZ":i.set(l*g,l*p,o*d,o*c);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+r)}}function Fn(i,e){switch(e.constructor){case Float32Array:return i;case Uint32Array:return i/4294967295;case Uint16Array:return i/65535;case Uint8Array:return i/255;case Int32Array:return Math.max(i/2147483647,-1);case Int16Array:return Math.max(i/32767,-1);case Int8Array:return Math.max(i/127,-1);default:throw new Error("Invalid component type.")}}function ot(i,e){switch(e.constructor){case Float32Array:return i;case Uint32Array:return Math.round(i*4294967295);case Uint16Array:return Math.round(i*65535);case Uint8Array:return Math.round(i*255);case Int32Array:return Math.round(i*2147483647);case Int16Array:return Math.round(i*32767);case Int8Array:return Math.round(i*127);default:throw new Error("Invalid component type.")}}const _e={DEG2RAD:As,RAD2DEG:Gr,generateUUID:kn,clamp:Je,euclideanModulo:zc,mapLinear:om,inverseLerp:lm,lerp:ws,damp:cm,pingpong:um,smoothstep:dm,smootherstep:hm,randInt:fm,randFloat:pm,randFloatSpread:mm,seededRandom:gm,degToRad:vm,radToDeg:_m,isPowerOfTwo:xm,ceilPowerOfTwo:ym,floorPowerOfTwo:bm,setQuaternionFromProperEuler:Sm,normalize:ot,denormalize:Fn};class Ce{constructor(e=0,t=0){Ce.prototype.isVector2=!0,this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const t=this.x,n=this.y,r=e.elements;return this.x=r[0]*t+r[3]*n+r[6],this.y=r[1]*t+r[4]*n+r[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Je(this.x,e.x,t.x),this.y=Je(this.y,e.y,t.y),this}clampScalar(e,t){return this.x=Je(this.x,e,t),this.y=Je(this.y,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Je(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(Je(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){const n=Math.cos(t),r=Math.sin(t),s=this.x-e.x,a=this.y-e.y;return this.x=s*n-a*r+e.x,this.y=s*r+a*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class dt{constructor(e=0,t=0,n=0,r=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=r}static slerpFlat(e,t,n,r,s,a,o){let l=n[r+0],c=n[r+1],d=n[r+2],u=n[r+3];const h=s[a+0],p=s[a+1],g=s[a+2],v=s[a+3];if(o===0){e[t+0]=l,e[t+1]=c,e[t+2]=d,e[t+3]=u;return}if(o===1){e[t+0]=h,e[t+1]=p,e[t+2]=g,e[t+3]=v;return}if(u!==v||l!==h||c!==p||d!==g){let m=1-o;const f=l*h+c*p+d*g+u*v,y=f>=0?1:-1,_=1-f*f;if(_>Number.EPSILON){const R=Math.sqrt(_),M=Math.atan2(R,f*y);m=Math.sin(m*M)/R,o=Math.sin(o*M)/R}const x=o*y;if(l=l*m+h*x,c=c*m+p*x,d=d*m+g*x,u=u*m+v*x,m===1-o){const R=1/Math.sqrt(l*l+c*c+d*d+u*u);l*=R,c*=R,d*=R,u*=R}}e[t]=l,e[t+1]=c,e[t+2]=d,e[t+3]=u}static multiplyQuaternionsFlat(e,t,n,r,s,a){const o=n[r],l=n[r+1],c=n[r+2],d=n[r+3],u=s[a],h=s[a+1],p=s[a+2],g=s[a+3];return e[t]=o*g+d*u+l*p-c*h,e[t+1]=l*g+d*h+c*u-o*p,e[t+2]=c*g+d*p+o*h-l*u,e[t+3]=d*g-o*u-l*h-c*p,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,r){return this._x=e,this._y=t,this._z=n,this._w=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){const n=e._x,r=e._y,s=e._z,a=e._order,o=Math.cos,l=Math.sin,c=o(n/2),d=o(r/2),u=o(s/2),h=l(n/2),p=l(r/2),g=l(s/2);switch(a){case"XYZ":this._x=h*d*u+c*p*g,this._y=c*p*u-h*d*g,this._z=c*d*g+h*p*u,this._w=c*d*u-h*p*g;break;case"YXZ":this._x=h*d*u+c*p*g,this._y=c*p*u-h*d*g,this._z=c*d*g-h*p*u,this._w=c*d*u+h*p*g;break;case"ZXY":this._x=h*d*u-c*p*g,this._y=c*p*u+h*d*g,this._z=c*d*g+h*p*u,this._w=c*d*u-h*p*g;break;case"ZYX":this._x=h*d*u-c*p*g,this._y=c*p*u+h*d*g,this._z=c*d*g-h*p*u,this._w=c*d*u+h*p*g;break;case"YZX":this._x=h*d*u+c*p*g,this._y=c*p*u+h*d*g,this._z=c*d*g-h*p*u,this._w=c*d*u-h*p*g;break;case"XZY":this._x=h*d*u-c*p*g,this._y=c*p*u-h*d*g,this._z=c*d*g+h*p*u,this._w=c*d*u+h*p*g;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+a)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){const n=t/2,r=Math.sin(n);return this._x=e.x*r,this._y=e.y*r,this._z=e.z*r,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){const t=e.elements,n=t[0],r=t[4],s=t[8],a=t[1],o=t[5],l=t[9],c=t[2],d=t[6],u=t[10],h=n+o+u;if(h>0){const p=.5/Math.sqrt(h+1);this._w=.25/p,this._x=(d-l)*p,this._y=(s-c)*p,this._z=(a-r)*p}else if(n>o&&n>u){const p=2*Math.sqrt(1+n-o-u);this._w=(d-l)/p,this._x=.25*p,this._y=(r+a)/p,this._z=(s+c)/p}else if(o>u){const p=2*Math.sqrt(1+o-n-u);this._w=(s-c)/p,this._x=(r+a)/p,this._y=.25*p,this._z=(l+d)/p}else{const p=2*Math.sqrt(1+u-n-o);this._w=(a-r)/p,this._x=(s+c)/p,this._y=(l+d)/p,this._z=.25*p}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;return n<1e-8?(n=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=n):(this._x=0,this._y=-e.z,this._z=e.y,this._w=n)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(Je(this.dot(e),-1,1)))}rotateTowards(e,t){const n=this.angleTo(e);if(n===0)return this;const r=Math.min(1,t/n);return this.slerp(e,r),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){const n=e._x,r=e._y,s=e._z,a=e._w,o=t._x,l=t._y,c=t._z,d=t._w;return this._x=n*d+a*o+r*c-s*l,this._y=r*d+a*l+s*o-n*c,this._z=s*d+a*c+n*l-r*o,this._w=a*d-n*o-r*l-s*c,this._onChangeCallback(),this}slerp(e,t){if(t===0)return this;if(t===1)return this.copy(e);const n=this._x,r=this._y,s=this._z,a=this._w;let o=a*e._w+n*e._x+r*e._y+s*e._z;if(o<0?(this._w=-e._w,this._x=-e._x,this._y=-e._y,this._z=-e._z,o=-o):this.copy(e),o>=1)return this._w=a,this._x=n,this._y=r,this._z=s,this;const l=1-o*o;if(l<=Number.EPSILON){const p=1-t;return this._w=p*a+t*this._w,this._x=p*n+t*this._x,this._y=p*r+t*this._y,this._z=p*s+t*this._z,this.normalize(),this}const c=Math.sqrt(l),d=Math.atan2(c,o),u=Math.sin((1-t)*d)/c,h=Math.sin(t*d)/c;return this._w=a*u+this._w*h,this._x=n*u+this._x*h,this._y=r*u+this._y*h,this._z=s*u+this._z*h,this._onChangeCallback(),this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){const e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),n=Math.random(),r=Math.sqrt(1-n),s=Math.sqrt(n);return this.set(r*Math.sin(e),r*Math.cos(e),s*Math.sin(t),s*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class U{constructor(e=0,t=0,n=0){U.prototype.isVector3=!0,this.x=e,this.y=t,this.z=n}set(e,t,n){return n===void 0&&(n=this.z),this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(Cu.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(Cu.setFromAxisAngle(e,t))}applyMatrix3(e){const t=this.x,n=this.y,r=this.z,s=e.elements;return this.x=s[0]*t+s[3]*n+s[6]*r,this.y=s[1]*t+s[4]*n+s[7]*r,this.z=s[2]*t+s[5]*n+s[8]*r,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const t=this.x,n=this.y,r=this.z,s=e.elements,a=1/(s[3]*t+s[7]*n+s[11]*r+s[15]);return this.x=(s[0]*t+s[4]*n+s[8]*r+s[12])*a,this.y=(s[1]*t+s[5]*n+s[9]*r+s[13])*a,this.z=(s[2]*t+s[6]*n+s[10]*r+s[14])*a,this}applyQuaternion(e){const t=this.x,n=this.y,r=this.z,s=e.x,a=e.y,o=e.z,l=e.w,c=2*(a*r-o*n),d=2*(o*t-s*r),u=2*(s*n-a*t);return this.x=t+l*c+a*u-o*d,this.y=n+l*d+o*c-s*u,this.z=r+l*u+s*d-a*c,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const t=this.x,n=this.y,r=this.z,s=e.elements;return this.x=s[0]*t+s[4]*n+s[8]*r,this.y=s[1]*t+s[5]*n+s[9]*r,this.z=s[2]*t+s[6]*n+s[10]*r,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Je(this.x,e.x,t.x),this.y=Je(this.y,e.y,t.y),this.z=Je(this.z,e.z,t.z),this}clampScalar(e,t){return this.x=Je(this.x,e,t),this.y=Je(this.y,e,t),this.z=Je(this.z,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Je(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){const n=e.x,r=e.y,s=e.z,a=t.x,o=t.y,l=t.z;return this.x=r*l-s*o,this.y=s*a-n*l,this.z=n*o-r*a,this}projectOnVector(e){const t=e.lengthSq();if(t===0)return this.set(0,0,0);const n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return Do.copy(this).projectOnVector(e),this.sub(Do)}reflect(e){return this.sub(Do.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(Je(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y,r=this.z-e.z;return t*t+n*n+r*r}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,n){const r=Math.sin(t)*e;return this.x=r*Math.sin(n),this.y=Math.cos(t)*e,this.z=r*Math.cos(n),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){const t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),r=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=r,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,t=Math.random()*2-1,n=Math.sqrt(1-t*t);return this.x=n*Math.cos(e),this.y=t,this.z=n*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const Do=new U,Cu=new dt;class $e{constructor(e,t,n,r,s,a,o,l,c){$e.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,n,r,s,a,o,l,c)}set(e,t,n,r,s,a,o,l,c){const d=this.elements;return d[0]=e,d[1]=r,d[2]=o,d[3]=t,d[4]=s,d[5]=l,d[6]=n,d[7]=a,d[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,r=t.elements,s=this.elements,a=n[0],o=n[3],l=n[6],c=n[1],d=n[4],u=n[7],h=n[2],p=n[5],g=n[8],v=r[0],m=r[3],f=r[6],y=r[1],_=r[4],x=r[7],R=r[2],M=r[5],w=r[8];return s[0]=a*v+o*y+l*R,s[3]=a*m+o*_+l*M,s[6]=a*f+o*x+l*w,s[1]=c*v+d*y+u*R,s[4]=c*m+d*_+u*M,s[7]=c*f+d*x+u*w,s[2]=h*v+p*y+g*R,s[5]=h*m+p*_+g*M,s[8]=h*f+p*x+g*w,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[1],r=e[2],s=e[3],a=e[4],o=e[5],l=e[6],c=e[7],d=e[8];return t*a*d-t*o*c-n*s*d+n*o*l+r*s*c-r*a*l}invert(){const e=this.elements,t=e[0],n=e[1],r=e[2],s=e[3],a=e[4],o=e[5],l=e[6],c=e[7],d=e[8],u=d*a-o*c,h=o*l-d*s,p=c*s-a*l,g=t*u+n*h+r*p;if(g===0)return this.set(0,0,0,0,0,0,0,0,0);const v=1/g;return e[0]=u*v,e[1]=(r*c-d*n)*v,e[2]=(o*n-r*a)*v,e[3]=h*v,e[4]=(d*t-r*l)*v,e[5]=(r*s-o*t)*v,e[6]=p*v,e[7]=(n*l-c*t)*v,e[8]=(a*t-n*s)*v,this}transpose(){let e;const t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,r,s,a,o){const l=Math.cos(s),c=Math.sin(s);return this.set(n*l,n*c,-n*(l*a+c*o)+a+e,-r*c,r*l,-r*(-c*a+l*o)+o+t,0,0,1),this}scale(e,t){return this.premultiply(No.makeScale(e,t)),this}rotate(e){return this.premultiply(No.makeRotation(-e)),this}translate(e,t){return this.premultiply(No.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){const t=this.elements,n=e.elements;for(let r=0;r<9;r++)if(t[r]!==n[r])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new this.constructor().fromArray(this.elements)}}const No=new $e;function tf(i){for(let e=i.length-1;e>=0;--e)if(i[e]>=65535)return!0;return!1}function Us(i){return document.createElementNS("http://www.w3.org/1999/xhtml",i)}function Mm(){const i=Us("canvas");return i.style.display="block",i}const Iu={};function Fs(i){i in Iu||(Iu[i]=!0,console.warn(i))}function Em(i,e,t){return new Promise(function(n,r){function s(){switch(i.clientWaitSync(e,i.SYNC_FLUSH_COMMANDS_BIT,0)){case i.WAIT_FAILED:r();break;case i.TIMEOUT_EXPIRED:setTimeout(s,t);break;default:n()}}setTimeout(s,t)})}const Pu=new $e().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),Lu=new $e().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function Tm(){const i={enabled:!0,workingColorSpace:nn,spaces:{},convert:function(r,s,a){return this.enabled===!1||s===a||!s||!a||(this.spaces[s].transfer===pt&&(r.r=pi(r.r),r.g=pi(r.g),r.b=pi(r.b)),this.spaces[s].primaries!==this.spaces[a].primaries&&(r.applyMatrix3(this.spaces[s].toXYZ),r.applyMatrix3(this.spaces[a].fromXYZ)),this.spaces[a].transfer===pt&&(r.r=Dr(r.r),r.g=Dr(r.g),r.b=Dr(r.b))),r},workingToColorSpace:function(r,s){return this.convert(r,this.workingColorSpace,s)},colorSpaceToWorking:function(r,s){return this.convert(r,s,this.workingColorSpace)},getPrimaries:function(r){return this.spaces[r].primaries},getTransfer:function(r){return r===ci?Xa:this.spaces[r].transfer},getToneMappingMode:function(r){return this.spaces[r].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(r,s=this.workingColorSpace){return r.fromArray(this.spaces[s].luminanceCoefficients)},define:function(r){Object.assign(this.spaces,r)},_getMatrix:function(r,s,a){return r.copy(this.spaces[s].toXYZ).multiply(this.spaces[a].fromXYZ)},_getDrawingBufferColorSpace:function(r){return this.spaces[r].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(r=this.workingColorSpace){return this.spaces[r].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(r,s){return Fs("THREE.ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),i.workingToColorSpace(r,s)},toWorkingColorSpace:function(r,s){return Fs("THREE.ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),i.colorSpaceToWorking(r,s)}},e=[.64,.33,.3,.6,.15,.06],t=[.2126,.7152,.0722],n=[.3127,.329];return i.define({[nn]:{primaries:e,whitePoint:n,transfer:Xa,toXYZ:Pu,fromXYZ:Lu,luminanceCoefficients:t,workingColorSpaceConfig:{unpackColorSpace:_t},outputColorSpaceConfig:{drawingBufferColorSpace:_t}},[_t]:{primaries:e,whitePoint:n,transfer:pt,toXYZ:Pu,fromXYZ:Lu,luminanceCoefficients:t,outputColorSpaceConfig:{drawingBufferColorSpace:_t}}}),i}const tt=Tm();function pi(i){return i<.04045?i*.0773993808:Math.pow(i*.9478672986+.0521327014,2.4)}function Dr(i){return i<.0031308?i*12.92:1.055*Math.pow(i,.41666)-.055}let sr;class Am{static getDataURL(e,t="image/png"){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let n;if(e instanceof HTMLCanvasElement)n=e;else{sr===void 0&&(sr=Us("canvas")),sr.width=e.width,sr.height=e.height;const r=sr.getContext("2d");e instanceof ImageData?r.putImageData(e,0,0):r.drawImage(e,0,0,e.width,e.height),n=sr}return n.toDataURL(t)}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const t=Us("canvas");t.width=e.width,t.height=e.height;const n=t.getContext("2d");n.drawImage(e,0,0,e.width,e.height);const r=n.getImageData(0,0,e.width,e.height),s=r.data;for(let a=0;a<s.length;a++)s[a]=pi(s[a]/255)*255;return n.putImageData(r,0,0),t}else if(e.data){const t=e.data.slice(0);for(let n=0;n<t.length;n++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[n]=Math.floor(pi(t[n]/255)*255):t[n]=pi(t[n]);return{data:t,width:e.width,height:e.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let wm=0;class Vc{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:wm++}),this.uuid=kn(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){const t=this.data;return typeof HTMLVideoElement<"u"&&t instanceof HTMLVideoElement?e.set(t.videoWidth,t.videoHeight,0):t instanceof VideoFrame?e.set(t.displayHeight,t.displayWidth,0):t!==null?e.set(t.width,t.height,t.depth||0):e.set(0,0,0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const n={uuid:this.uuid,url:""},r=this.data;if(r!==null){let s;if(Array.isArray(r)){s=[];for(let a=0,o=r.length;a<o;a++)r[a].isDataTexture?s.push(Oo(r[a].image)):s.push(Oo(r[a]))}else s=Oo(r);n.url=s}return t||(e.images[this.uuid]=n),n}}function Oo(i){return typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&i instanceof ImageBitmap?Am.getDataURL(i):i.data?{data:Array.from(i.data),width:i.width,height:i.height,type:i.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}let Rm=0;const Uo=new U;class Ft extends es{constructor(e=Ft.DEFAULT_IMAGE,t=Ft.DEFAULT_MAPPING,n=Ii,r=Ii,s=Dt,a=Gt,o=wn,l=Yn,c=Ft.DEFAULT_ANISOTROPY,d=ci){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Rm++}),this.uuid=kn(),this.name="",this.source=new Vc(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=n,this.wrapT=r,this.magFilter=s,this.minFilter=a,this.anisotropy=c,this.format=o,this.internalFormat=null,this.type=l,this.offset=new Ce(0,0),this.repeat=new Ce(1,1),this.center=new Ce(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new $e,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=d,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0}get width(){return this.source.getSize(Uo).x}get height(){return this.source.getSize(Uo).y}get depth(){return this.source.getSize(Uo).z}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(const t in e){const n=e[t];if(n===void 0){console.warn(`THREE.Texture.setValues(): parameter '${t}' has value of undefined.`);continue}const r=this[t];if(r===void 0){console.warn(`THREE.Texture.setValues(): property '${t}' does not exist.`);continue}r&&n&&r.isVector2&&n.isVector2||r&&n&&r.isVector3&&n.isVector3||r&&n&&r.isMatrix3&&n.isMatrix3?r.copy(n):this[t]=n}}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const n={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),t||(e.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==Gh)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Hr:e.x=e.x-Math.floor(e.x);break;case Ii:e.x=e.x<0?0:1;break;case Wa:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case Hr:e.y=e.y-Math.floor(e.y);break;case Ii:e.y=e.y<0?0:1;break;case Wa:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}Ft.DEFAULT_IMAGE=null;Ft.DEFAULT_MAPPING=Gh;Ft.DEFAULT_ANISOTROPY=1;class rt{constructor(e=0,t=0,n=0,r=1){rt.prototype.isVector4=!0,this.x=e,this.y=t,this.z=n,this.w=r}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,r){return this.x=e,this.y=t,this.z=n,this.w=r,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const t=this.x,n=this.y,r=this.z,s=this.w,a=e.elements;return this.x=a[0]*t+a[4]*n+a[8]*r+a[12]*s,this.y=a[1]*t+a[5]*n+a[9]*r+a[13]*s,this.z=a[2]*t+a[6]*n+a[10]*r+a[14]*s,this.w=a[3]*t+a[7]*n+a[11]*r+a[15]*s,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,n,r,s;const l=e.elements,c=l[0],d=l[4],u=l[8],h=l[1],p=l[5],g=l[9],v=l[2],m=l[6],f=l[10];if(Math.abs(d-h)<.01&&Math.abs(u-v)<.01&&Math.abs(g-m)<.01){if(Math.abs(d+h)<.1&&Math.abs(u+v)<.1&&Math.abs(g+m)<.1&&Math.abs(c+p+f-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;const _=(c+1)/2,x=(p+1)/2,R=(f+1)/2,M=(d+h)/4,w=(u+v)/4,A=(g+m)/4;return _>x&&_>R?_<.01?(n=0,r=.707106781,s=.707106781):(n=Math.sqrt(_),r=M/n,s=w/n):x>R?x<.01?(n=.707106781,r=0,s=.707106781):(r=Math.sqrt(x),n=M/r,s=A/r):R<.01?(n=.707106781,r=.707106781,s=0):(s=Math.sqrt(R),n=w/s,r=A/s),this.set(n,r,s,t),this}let y=Math.sqrt((m-g)*(m-g)+(u-v)*(u-v)+(h-d)*(h-d));return Math.abs(y)<.001&&(y=1),this.x=(m-g)/y,this.y=(u-v)/y,this.z=(h-d)/y,this.w=Math.acos((c+p+f-1)/2),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Je(this.x,e.x,t.x),this.y=Je(this.y,e.y,t.y),this.z=Je(this.z,e.z,t.z),this.w=Je(this.w,e.w,t.w),this}clampScalar(e,t){return this.x=Je(this.x,e,t),this.y=Je(this.y,e,t),this.z=Je(this.z,e,t),this.w=Je(this.w,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Je(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class Cm extends es{constructor(e=1,t=1,n={}){super(),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Dt,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1},n),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=n.depth,this.scissor=new rt(0,0,e,t),this.scissorTest=!1,this.viewport=new rt(0,0,e,t);const r={width:e,height:t,depth:n.depth},s=new Ft(r);this.textures=[];const a=n.count;for(let o=0;o<a;o++)this.textures[o]=s.clone(),this.textures[o].isRenderTargetTexture=!0,this.textures[o].renderTarget=this;this._setTextureOptions(n),this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=n.depthTexture,this.samples=n.samples,this.multiview=n.multiview}_setTextureOptions(e={}){const t={minFilter:Dt,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(t.mapping=e.mapping),e.wrapS!==void 0&&(t.wrapS=e.wrapS),e.wrapT!==void 0&&(t.wrapT=e.wrapT),e.wrapR!==void 0&&(t.wrapR=e.wrapR),e.magFilter!==void 0&&(t.magFilter=e.magFilter),e.minFilter!==void 0&&(t.minFilter=e.minFilter),e.format!==void 0&&(t.format=e.format),e.type!==void 0&&(t.type=e.type),e.anisotropy!==void 0&&(t.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(t.colorSpace=e.colorSpace),e.flipY!==void 0&&(t.flipY=e.flipY),e.generateMipmaps!==void 0&&(t.generateMipmaps=e.generateMipmaps),e.internalFormat!==void 0&&(t.internalFormat=e.internalFormat);for(let n=0;n<this.textures.length;n++)this.textures[n].setValues(t)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),e!==null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,t,n=1){if(this.width!==e||this.height!==t||this.depth!==n){this.width=e,this.height=t,this.depth=n;for(let r=0,s=this.textures.length;r<s;r++)this.textures[r].image.width=e,this.textures[r].image.height=t,this.textures[r].image.depth=n,this.textures[r].isArrayTexture=this.textures[r].image.depth>1;this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let t=0,n=e.textures.length;t<n;t++){this.textures[t]=e.textures[t].clone(),this.textures[t].isRenderTargetTexture=!0,this.textures[t].renderTarget=this;const r=Object.assign({},e.textures[t].image);this.textures[t].source=new Vc(r)}return this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class zn extends Cm{constructor(e=1,t=1,n={}){super(e,t,n),this.isWebGLRenderTarget=!0}}class nf extends Ft{constructor(e=null,t=1,n=1,r=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:n,depth:r},this.magFilter=en,this.minFilter=en,this.wrapR=Ii,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class Im extends Ft{constructor(e=null,t=1,n=1,r=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:n,depth:r},this.magFilter=en,this.minFilter=en,this.wrapR=Ii,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class jn{constructor(e=new U(1/0,1/0,1/0),t=new U(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t+=3)this.expandByPoint(Nn.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,n=e.count;t<n;t++)this.expandByPoint(Nn.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const n=Nn.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);const n=e.geometry;if(n!==void 0){const s=n.getAttribute("position");if(t===!0&&s!==void 0&&e.isInstancedMesh!==!0)for(let a=0,o=s.count;a<o;a++)e.isMesh===!0?e.getVertexPosition(a,Nn):Nn.fromBufferAttribute(s,a),Nn.applyMatrix4(e.matrixWorld),this.expandByPoint(Nn);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),na.copy(e.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),na.copy(n.boundingBox)),na.applyMatrix4(e.matrixWorld),this.union(na)}const r=e.children;for(let s=0,a=r.length;s<a;s++)this.expandByObject(r[s],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,Nn),Nn.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,n;return e.normal.x>0?(t=e.normal.x*this.min.x,n=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,n=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,n+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,n+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,n+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,n+=e.normal.z*this.min.z),t<=-e.constant&&n>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(ls),ia.subVectors(this.max,ls),ar.subVectors(e.a,ls),or.subVectors(e.b,ls),lr.subVectors(e.c,ls),gi.subVectors(or,ar),vi.subVectors(lr,or),ki.subVectors(ar,lr);let t=[0,-gi.z,gi.y,0,-vi.z,vi.y,0,-ki.z,ki.y,gi.z,0,-gi.x,vi.z,0,-vi.x,ki.z,0,-ki.x,-gi.y,gi.x,0,-vi.y,vi.x,0,-ki.y,ki.x,0];return!Fo(t,ar,or,lr,ia)||(t=[1,0,0,0,1,0,0,0,1],!Fo(t,ar,or,lr,ia))?!1:(ra.crossVectors(gi,vi),t=[ra.x,ra.y,ra.z],Fo(t,ar,or,lr,ia))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Nn).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(Nn).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(Jn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),Jn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),Jn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),Jn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),Jn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),Jn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),Jn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),Jn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(Jn),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}}const Jn=[new U,new U,new U,new U,new U,new U,new U,new U],Nn=new U,na=new jn,ar=new U,or=new U,lr=new U,gi=new U,vi=new U,ki=new U,ls=new U,ia=new U,ra=new U,zi=new U;function Fo(i,e,t,n,r){for(let s=0,a=i.length-3;s<=a;s+=3){zi.fromArray(i,s);const o=r.x*Math.abs(zi.x)+r.y*Math.abs(zi.y)+r.z*Math.abs(zi.z),l=e.dot(zi),c=t.dot(zi),d=n.dot(zi);if(Math.max(-Math.max(l,c,d),Math.min(l,c,d))>o)return!1}return!0}const Pm=new jn,cs=new U,Bo=new U;class $n{constructor(e=new U,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){const n=this.center;t!==void 0?n.copy(t):Pm.setFromPoints(e).getCenter(n);let r=0;for(let s=0,a=e.length;s<a;s++)r=Math.max(r,n.distanceToSquared(e[s]));return this.radius=Math.sqrt(r),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){const n=this.center.distanceToSquared(e);return t.copy(e),n>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;cs.subVectors(e,this.center);const t=cs.lengthSq();if(t>this.radius*this.radius){const n=Math.sqrt(t),r=(n-this.radius)*.5;this.center.addScaledVector(cs,r/n),this.radius+=r}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Bo.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(cs.copy(e.center).add(Bo)),this.expandByPoint(cs.copy(e.center).sub(Bo))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}}const Qn=new U,ko=new U,sa=new U,_i=new U,zo=new U,aa=new U,Vo=new U;class Vs{constructor(e=new U,t=new U(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,Qn)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);const n=t.dot(this.direction);return n<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const t=Qn.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(Qn.copy(this.origin).addScaledVector(this.direction,t),Qn.distanceToSquared(e))}distanceSqToSegment(e,t,n,r){ko.copy(e).add(t).multiplyScalar(.5),sa.copy(t).sub(e).normalize(),_i.copy(this.origin).sub(ko);const s=e.distanceTo(t)*.5,a=-this.direction.dot(sa),o=_i.dot(this.direction),l=-_i.dot(sa),c=_i.lengthSq(),d=Math.abs(1-a*a);let u,h,p,g;if(d>0)if(u=a*l-o,h=a*o-l,g=s*d,u>=0)if(h>=-g)if(h<=g){const v=1/d;u*=v,h*=v,p=u*(u+a*h+2*o)+h*(a*u+h+2*l)+c}else h=s,u=Math.max(0,-(a*h+o)),p=-u*u+h*(h+2*l)+c;else h=-s,u=Math.max(0,-(a*h+o)),p=-u*u+h*(h+2*l)+c;else h<=-g?(u=Math.max(0,-(-a*s+o)),h=u>0?-s:Math.min(Math.max(-s,-l),s),p=-u*u+h*(h+2*l)+c):h<=g?(u=0,h=Math.min(Math.max(-s,-l),s),p=h*(h+2*l)+c):(u=Math.max(0,-(a*s+o)),h=u>0?s:Math.min(Math.max(-s,-l),s),p=-u*u+h*(h+2*l)+c);else h=a>0?-s:s,u=Math.max(0,-(a*h+o)),p=-u*u+h*(h+2*l)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,u),r&&r.copy(ko).addScaledVector(sa,h),p}intersectSphere(e,t){Qn.subVectors(e.center,this.origin);const n=Qn.dot(this.direction),r=Qn.dot(Qn)-n*n,s=e.radius*e.radius;if(r>s)return null;const a=Math.sqrt(s-r),o=n-a,l=n+a;return l<0?null:o<0?this.at(l,t):this.at(o,t)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;const n=-(this.origin.dot(e.normal)+e.constant)/t;return n>=0?n:null}intersectPlane(e,t){const n=this.distanceToPlane(e);return n===null?null:this.at(n,t)}intersectsPlane(e){const t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let n,r,s,a,o,l;const c=1/this.direction.x,d=1/this.direction.y,u=1/this.direction.z,h=this.origin;return c>=0?(n=(e.min.x-h.x)*c,r=(e.max.x-h.x)*c):(n=(e.max.x-h.x)*c,r=(e.min.x-h.x)*c),d>=0?(s=(e.min.y-h.y)*d,a=(e.max.y-h.y)*d):(s=(e.max.y-h.y)*d,a=(e.min.y-h.y)*d),n>a||s>r||((s>n||isNaN(n))&&(n=s),(a<r||isNaN(r))&&(r=a),u>=0?(o=(e.min.z-h.z)*u,l=(e.max.z-h.z)*u):(o=(e.max.z-h.z)*u,l=(e.min.z-h.z)*u),n>l||o>r)||((o>n||n!==n)&&(n=o),(l<r||r!==r)&&(r=l),r<0)?null:this.at(n>=0?n:r,t)}intersectsBox(e){return this.intersectBox(e,Qn)!==null}intersectTriangle(e,t,n,r,s){zo.subVectors(t,e),aa.subVectors(n,e),Vo.crossVectors(zo,aa);let a=this.direction.dot(Vo),o;if(a>0){if(r)return null;o=1}else if(a<0)o=-1,a=-a;else return null;_i.subVectors(this.origin,e);const l=o*this.direction.dot(aa.crossVectors(_i,aa));if(l<0)return null;const c=o*this.direction.dot(zo.cross(_i));if(c<0||l+c>a)return null;const d=-o*_i.dot(Vo);return d<0?null:this.at(d/a,s)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class qe{constructor(e,t,n,r,s,a,o,l,c,d,u,h,p,g,v,m){qe.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,n,r,s,a,o,l,c,d,u,h,p,g,v,m)}set(e,t,n,r,s,a,o,l,c,d,u,h,p,g,v,m){const f=this.elements;return f[0]=e,f[4]=t,f[8]=n,f[12]=r,f[1]=s,f[5]=a,f[9]=o,f[13]=l,f[2]=c,f[6]=d,f[10]=u,f[14]=h,f[3]=p,f[7]=g,f[11]=v,f[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new qe().fromArray(this.elements)}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){const t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){const t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){return e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){const t=this.elements,n=e.elements,r=1/cr.setFromMatrixColumn(e,0).length(),s=1/cr.setFromMatrixColumn(e,1).length(),a=1/cr.setFromMatrixColumn(e,2).length();return t[0]=n[0]*r,t[1]=n[1]*r,t[2]=n[2]*r,t[3]=0,t[4]=n[4]*s,t[5]=n[5]*s,t[6]=n[6]*s,t[7]=0,t[8]=n[8]*a,t[9]=n[9]*a,t[10]=n[10]*a,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){const t=this.elements,n=e.x,r=e.y,s=e.z,a=Math.cos(n),o=Math.sin(n),l=Math.cos(r),c=Math.sin(r),d=Math.cos(s),u=Math.sin(s);if(e.order==="XYZ"){const h=a*d,p=a*u,g=o*d,v=o*u;t[0]=l*d,t[4]=-l*u,t[8]=c,t[1]=p+g*c,t[5]=h-v*c,t[9]=-o*l,t[2]=v-h*c,t[6]=g+p*c,t[10]=a*l}else if(e.order==="YXZ"){const h=l*d,p=l*u,g=c*d,v=c*u;t[0]=h+v*o,t[4]=g*o-p,t[8]=a*c,t[1]=a*u,t[5]=a*d,t[9]=-o,t[2]=p*o-g,t[6]=v+h*o,t[10]=a*l}else if(e.order==="ZXY"){const h=l*d,p=l*u,g=c*d,v=c*u;t[0]=h-v*o,t[4]=-a*u,t[8]=g+p*o,t[1]=p+g*o,t[5]=a*d,t[9]=v-h*o,t[2]=-a*c,t[6]=o,t[10]=a*l}else if(e.order==="ZYX"){const h=a*d,p=a*u,g=o*d,v=o*u;t[0]=l*d,t[4]=g*c-p,t[8]=h*c+v,t[1]=l*u,t[5]=v*c+h,t[9]=p*c-g,t[2]=-c,t[6]=o*l,t[10]=a*l}else if(e.order==="YZX"){const h=a*l,p=a*c,g=o*l,v=o*c;t[0]=l*d,t[4]=v-h*u,t[8]=g*u+p,t[1]=u,t[5]=a*d,t[9]=-o*d,t[2]=-c*d,t[6]=p*u+g,t[10]=h-v*u}else if(e.order==="XZY"){const h=a*l,p=a*c,g=o*l,v=o*c;t[0]=l*d,t[4]=-u,t[8]=c*d,t[1]=h*u+v,t[5]=a*d,t[9]=p*u-g,t[2]=g*u-p,t[6]=o*d,t[10]=v*u+h}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(Lm,e,Dm)}lookAt(e,t,n){const r=this.elements;return mn.subVectors(e,t),mn.lengthSq()===0&&(mn.z=1),mn.normalize(),xi.crossVectors(n,mn),xi.lengthSq()===0&&(Math.abs(n.z)===1?mn.x+=1e-4:mn.z+=1e-4,mn.normalize(),xi.crossVectors(n,mn)),xi.normalize(),oa.crossVectors(mn,xi),r[0]=xi.x,r[4]=oa.x,r[8]=mn.x,r[1]=xi.y,r[5]=oa.y,r[9]=mn.y,r[2]=xi.z,r[6]=oa.z,r[10]=mn.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,r=t.elements,s=this.elements,a=n[0],o=n[4],l=n[8],c=n[12],d=n[1],u=n[5],h=n[9],p=n[13],g=n[2],v=n[6],m=n[10],f=n[14],y=n[3],_=n[7],x=n[11],R=n[15],M=r[0],w=r[4],A=r[8],S=r[12],b=r[1],T=r[5],D=r[9],k=r[13],z=r[2],H=r[6],L=r[10],N=r[14],B=r[3],V=r[7],Y=r[11],ee=r[15];return s[0]=a*M+o*b+l*z+c*B,s[4]=a*w+o*T+l*H+c*V,s[8]=a*A+o*D+l*L+c*Y,s[12]=a*S+o*k+l*N+c*ee,s[1]=d*M+u*b+h*z+p*B,s[5]=d*w+u*T+h*H+p*V,s[9]=d*A+u*D+h*L+p*Y,s[13]=d*S+u*k+h*N+p*ee,s[2]=g*M+v*b+m*z+f*B,s[6]=g*w+v*T+m*H+f*V,s[10]=g*A+v*D+m*L+f*Y,s[14]=g*S+v*k+m*N+f*ee,s[3]=y*M+_*b+x*z+R*B,s[7]=y*w+_*T+x*H+R*V,s[11]=y*A+_*D+x*L+R*Y,s[15]=y*S+_*k+x*N+R*ee,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[4],r=e[8],s=e[12],a=e[1],o=e[5],l=e[9],c=e[13],d=e[2],u=e[6],h=e[10],p=e[14],g=e[3],v=e[7],m=e[11],f=e[15];return g*(+s*l*u-r*c*u-s*o*h+n*c*h+r*o*p-n*l*p)+v*(+t*l*p-t*c*h+s*a*h-r*a*p+r*c*d-s*l*d)+m*(+t*c*u-t*o*p-s*a*u+n*a*p+s*o*d-n*c*d)+f*(-r*o*d-t*l*u+t*o*h+r*a*u-n*a*h+n*l*d)}transpose(){const e=this.elements;let t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){const r=this.elements;return e.isVector3?(r[12]=e.x,r[13]=e.y,r[14]=e.z):(r[12]=e,r[13]=t,r[14]=n),this}invert(){const e=this.elements,t=e[0],n=e[1],r=e[2],s=e[3],a=e[4],o=e[5],l=e[6],c=e[7],d=e[8],u=e[9],h=e[10],p=e[11],g=e[12],v=e[13],m=e[14],f=e[15],y=u*m*c-v*h*c+v*l*p-o*m*p-u*l*f+o*h*f,_=g*h*c-d*m*c-g*l*p+a*m*p+d*l*f-a*h*f,x=d*v*c-g*u*c+g*o*p-a*v*p-d*o*f+a*u*f,R=g*u*l-d*v*l-g*o*h+a*v*h+d*o*m-a*u*m,M=t*y+n*_+r*x+s*R;if(M===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const w=1/M;return e[0]=y*w,e[1]=(v*h*s-u*m*s-v*r*p+n*m*p+u*r*f-n*h*f)*w,e[2]=(o*m*s-v*l*s+v*r*c-n*m*c-o*r*f+n*l*f)*w,e[3]=(u*l*s-o*h*s-u*r*c+n*h*c+o*r*p-n*l*p)*w,e[4]=_*w,e[5]=(d*m*s-g*h*s+g*r*p-t*m*p-d*r*f+t*h*f)*w,e[6]=(g*l*s-a*m*s-g*r*c+t*m*c+a*r*f-t*l*f)*w,e[7]=(a*h*s-d*l*s+d*r*c-t*h*c-a*r*p+t*l*p)*w,e[8]=x*w,e[9]=(g*u*s-d*v*s-g*n*p+t*v*p+d*n*f-t*u*f)*w,e[10]=(a*v*s-g*o*s+g*n*c-t*v*c-a*n*f+t*o*f)*w,e[11]=(d*o*s-a*u*s-d*n*c+t*u*c+a*n*p-t*o*p)*w,e[12]=R*w,e[13]=(d*v*r-g*u*r+g*n*h-t*v*h-d*n*m+t*u*m)*w,e[14]=(g*o*r-a*v*r-g*n*l+t*v*l+a*n*m-t*o*m)*w,e[15]=(a*u*r-d*o*r+d*n*l-t*u*l-a*n*h+t*o*h)*w,this}scale(e){const t=this.elements,n=e.x,r=e.y,s=e.z;return t[0]*=n,t[4]*=r,t[8]*=s,t[1]*=n,t[5]*=r,t[9]*=s,t[2]*=n,t[6]*=r,t[10]*=s,t[3]*=n,t[7]*=r,t[11]*=s,this}getMaxScaleOnAxis(){const e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],r=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,r))}makeTranslation(e,t,n){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1),this}makeRotationX(e){const t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){const n=Math.cos(t),r=Math.sin(t),s=1-n,a=e.x,o=e.y,l=e.z,c=s*a,d=s*o;return this.set(c*a+n,c*o-r*l,c*l+r*o,0,c*o+r*l,d*o+n,d*l-r*a,0,c*l-r*o,d*l+r*a,s*l*l+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,r,s,a){return this.set(1,n,s,0,e,1,a,0,t,r,1,0,0,0,0,1),this}compose(e,t,n){const r=this.elements,s=t._x,a=t._y,o=t._z,l=t._w,c=s+s,d=a+a,u=o+o,h=s*c,p=s*d,g=s*u,v=a*d,m=a*u,f=o*u,y=l*c,_=l*d,x=l*u,R=n.x,M=n.y,w=n.z;return r[0]=(1-(v+f))*R,r[1]=(p+x)*R,r[2]=(g-_)*R,r[3]=0,r[4]=(p-x)*M,r[5]=(1-(h+f))*M,r[6]=(m+y)*M,r[7]=0,r[8]=(g+_)*w,r[9]=(m-y)*w,r[10]=(1-(h+v))*w,r[11]=0,r[12]=e.x,r[13]=e.y,r[14]=e.z,r[15]=1,this}decompose(e,t,n){const r=this.elements;let s=cr.set(r[0],r[1],r[2]).length();const a=cr.set(r[4],r[5],r[6]).length(),o=cr.set(r[8],r[9],r[10]).length();this.determinant()<0&&(s=-s),e.x=r[12],e.y=r[13],e.z=r[14],On.copy(this);const c=1/s,d=1/a,u=1/o;return On.elements[0]*=c,On.elements[1]*=c,On.elements[2]*=c,On.elements[4]*=d,On.elements[5]*=d,On.elements[6]*=d,On.elements[8]*=u,On.elements[9]*=u,On.elements[10]*=u,t.setFromRotationMatrix(On),n.x=s,n.y=a,n.z=o,this}makePerspective(e,t,n,r,s,a,o=qn,l=!1){const c=this.elements,d=2*s/(t-e),u=2*s/(n-r),h=(t+e)/(t-e),p=(n+r)/(n-r);let g,v;if(l)g=s/(a-s),v=a*s/(a-s);else if(o===qn)g=-(a+s)/(a-s),v=-2*a*s/(a-s);else if(o===qa)g=-a/(a-s),v=-a*s/(a-s);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return c[0]=d,c[4]=0,c[8]=h,c[12]=0,c[1]=0,c[5]=u,c[9]=p,c[13]=0,c[2]=0,c[6]=0,c[10]=g,c[14]=v,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(e,t,n,r,s,a,o=qn,l=!1){const c=this.elements,d=2/(t-e),u=2/(n-r),h=-(t+e)/(t-e),p=-(n+r)/(n-r);let g,v;if(l)g=1/(a-s),v=a/(a-s);else if(o===qn)g=-2/(a-s),v=-(a+s)/(a-s);else if(o===qa)g=-1/(a-s),v=-s/(a-s);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return c[0]=d,c[4]=0,c[8]=0,c[12]=h,c[1]=0,c[5]=u,c[9]=0,c[13]=p,c[2]=0,c[6]=0,c[10]=g,c[14]=v,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(e){const t=this.elements,n=e.elements;for(let r=0;r<16;r++)if(t[r]!==n[r])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}}const cr=new U,On=new qe,Lm=new U(0,0,0),Dm=new U(1,1,1),xi=new U,oa=new U,mn=new U,Du=new qe,Nu=new dt;class xn{constructor(e=0,t=0,n=0,r=xn.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=n,this._order=r}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,r=this._order){return this._x=e,this._y=t,this._z=n,this._order=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){const r=e.elements,s=r[0],a=r[4],o=r[8],l=r[1],c=r[5],d=r[9],u=r[2],h=r[6],p=r[10];switch(t){case"XYZ":this._y=Math.asin(Je(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-d,p),this._z=Math.atan2(-a,s)):(this._x=Math.atan2(h,c),this._z=0);break;case"YXZ":this._x=Math.asin(-Je(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(o,p),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-u,s),this._z=0);break;case"ZXY":this._x=Math.asin(Je(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(-u,p),this._z=Math.atan2(-a,c)):(this._y=0,this._z=Math.atan2(l,s));break;case"ZYX":this._y=Math.asin(-Je(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(h,p),this._z=Math.atan2(l,s)):(this._x=0,this._z=Math.atan2(-a,c));break;case"YZX":this._z=Math.asin(Je(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-d,c),this._y=Math.atan2(-u,s)):(this._x=0,this._y=Math.atan2(o,p));break;case"XZY":this._z=Math.asin(-Je(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(h,c),this._y=Math.atan2(o,s)):(this._x=Math.atan2(-d,p),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,n===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,n){return Du.makeRotationFromQuaternion(e),this.setFromRotationMatrix(Du,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return Nu.setFromEuler(this),this.setFromQuaternion(Nu,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}xn.DEFAULT_ORDER="XYZ";class Hc{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let Nm=0;const Ou=new U,ur=new dt,ei=new qe,la=new U,us=new U,Om=new U,Um=new dt,Uu=new U(1,0,0),Fu=new U(0,1,0),Bu=new U(0,0,1),ku={type:"added"},Fm={type:"removed"},dr={type:"childadded",child:null},Ho={type:"childremoved",child:null};class Mt extends es{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Nm++}),this.uuid=kn(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=Mt.DEFAULT_UP.clone();const e=new U,t=new xn,n=new dt,r=new U(1,1,1);function s(){n.setFromEuler(t,!1)}function a(){t.setFromQuaternion(n,void 0,!1)}t._onChange(s),n._onChange(a),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:r},modelViewMatrix:{value:new qe},normalMatrix:{value:new $e}}),this.matrix=new qe,this.matrixWorld=new qe,this.matrixAutoUpdate=Mt.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=Mt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Hc,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return ur.setFromAxisAngle(e,t),this.quaternion.multiply(ur),this}rotateOnWorldAxis(e,t){return ur.setFromAxisAngle(e,t),this.quaternion.premultiply(ur),this}rotateX(e){return this.rotateOnAxis(Uu,e)}rotateY(e){return this.rotateOnAxis(Fu,e)}rotateZ(e){return this.rotateOnAxis(Bu,e)}translateOnAxis(e,t){return Ou.copy(e).applyQuaternion(this.quaternion),this.position.add(Ou.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(Uu,e)}translateY(e){return this.translateOnAxis(Fu,e)}translateZ(e){return this.translateOnAxis(Bu,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(ei.copy(this.matrixWorld).invert())}lookAt(e,t,n){e.isVector3?la.copy(e):la.set(e,t,n);const r=this.parent;this.updateWorldMatrix(!0,!1),us.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?ei.lookAt(us,la,this.up):ei.lookAt(la,us,this.up),this.quaternion.setFromRotationMatrix(ei),r&&(ei.extractRotation(r.matrixWorld),ur.setFromRotationMatrix(ei),this.quaternion.premultiply(ur.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(ku),dr.child=e,this.dispatchEvent(dr),dr.child=null):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}const t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(Fm),Ho.child=e,this.dispatchEvent(Ho),Ho.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),ei.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),ei.multiply(e.parent.matrixWorld)),e.applyMatrix4(ei),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(ku),dr.child=e,this.dispatchEvent(dr),dr.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let n=0,r=this.children.length;n<r;n++){const a=this.children[n].getObjectByProperty(e,t);if(a!==void 0)return a}}getObjectsByProperty(e,t,n=[]){this[e]===t&&n.push(this);const r=this.children;for(let s=0,a=r.length;s<a;s++)r[s].getObjectsByProperty(e,t,n);return n}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(us,e,Om),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(us,Um,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);const t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].traverseVisible(e)}traverseAncestors(e){const t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].updateMatrixWorld(e)}updateWorldMatrix(e,t){const n=this.parent;if(e===!0&&n!==null&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),t===!0){const r=this.children;for(let s=0,a=r.length;s<a;s++)r[s].updateWorldMatrix(!1,!0)}}toJSON(e){const t=e===void 0||typeof e=="string",n={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const r={};r.uuid=this.uuid,r.type=this.type,this.name!==""&&(r.name=this.name),this.castShadow===!0&&(r.castShadow=!0),this.receiveShadow===!0&&(r.receiveShadow=!0),this.visible===!1&&(r.visible=!1),this.frustumCulled===!1&&(r.frustumCulled=!1),this.renderOrder!==0&&(r.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(r.userData=this.userData),r.layers=this.layers.mask,r.matrix=this.matrix.toArray(),r.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(r.matrixAutoUpdate=!1),this.isInstancedMesh&&(r.type="InstancedMesh",r.count=this.count,r.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(r.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(r.type="BatchedMesh",r.perObjectFrustumCulled=this.perObjectFrustumCulled,r.sortObjects=this.sortObjects,r.drawRanges=this._drawRanges,r.reservedRanges=this._reservedRanges,r.geometryInfo=this._geometryInfo.map(o=>({...o,boundingBox:o.boundingBox?o.boundingBox.toJSON():void 0,boundingSphere:o.boundingSphere?o.boundingSphere.toJSON():void 0})),r.instanceInfo=this._instanceInfo.map(o=>({...o})),r.availableInstanceIds=this._availableInstanceIds.slice(),r.availableGeometryIds=this._availableGeometryIds.slice(),r.nextIndexStart=this._nextIndexStart,r.nextVertexStart=this._nextVertexStart,r.geometryCount=this._geometryCount,r.maxInstanceCount=this._maxInstanceCount,r.maxVertexCount=this._maxVertexCount,r.maxIndexCount=this._maxIndexCount,r.geometryInitialized=this._geometryInitialized,r.matricesTexture=this._matricesTexture.toJSON(e),r.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(r.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(r.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(r.boundingBox=this.boundingBox.toJSON()));function s(o,l){return o[l.uuid]===void 0&&(o[l.uuid]=l.toJSON(e)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?r.background=this.background.toJSON():this.background.isTexture&&(r.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(r.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){r.geometry=s(e.geometries,this.geometry);const o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){const l=o.shapes;if(Array.isArray(l))for(let c=0,d=l.length;c<d;c++){const u=l[c];s(e.shapes,u)}else s(e.shapes,l)}}if(this.isSkinnedMesh&&(r.bindMode=this.bindMode,r.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(s(e.skeletons,this.skeleton),r.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const o=[];for(let l=0,c=this.material.length;l<c;l++)o.push(s(e.materials,this.material[l]));r.material=o}else r.material=s(e.materials,this.material);if(this.children.length>0){r.children=[];for(let o=0;o<this.children.length;o++)r.children.push(this.children[o].toJSON(e).object)}if(this.animations.length>0){r.animations=[];for(let o=0;o<this.animations.length;o++){const l=this.animations[o];r.animations.push(s(e.animations,l))}}if(t){const o=a(e.geometries),l=a(e.materials),c=a(e.textures),d=a(e.images),u=a(e.shapes),h=a(e.skeletons),p=a(e.animations),g=a(e.nodes);o.length>0&&(n.geometries=o),l.length>0&&(n.materials=l),c.length>0&&(n.textures=c),d.length>0&&(n.images=d),u.length>0&&(n.shapes=u),h.length>0&&(n.skeletons=h),p.length>0&&(n.animations=p),g.length>0&&(n.nodes=g)}return n.object=r,n;function a(o){const l=[];for(const c in o){const d=o[c];delete d.metadata,l.push(d)}return l}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let n=0;n<e.children.length;n++){const r=e.children[n];this.add(r.clone())}return this}}Mt.DEFAULT_UP=new U(0,1,0);Mt.DEFAULT_MATRIX_AUTO_UPDATE=!0;Mt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const Un=new U,ti=new U,Go=new U,ni=new U,hr=new U,fr=new U,zu=new U,Wo=new U,Xo=new U,qo=new U,Yo=new rt,jo=new rt,$o=new rt;class An{constructor(e=new U,t=new U,n=new U){this.a=e,this.b=t,this.c=n}static getNormal(e,t,n,r){r.subVectors(n,t),Un.subVectors(e,t),r.cross(Un);const s=r.lengthSq();return s>0?r.multiplyScalar(1/Math.sqrt(s)):r.set(0,0,0)}static getBarycoord(e,t,n,r,s){Un.subVectors(r,t),ti.subVectors(n,t),Go.subVectors(e,t);const a=Un.dot(Un),o=Un.dot(ti),l=Un.dot(Go),c=ti.dot(ti),d=ti.dot(Go),u=a*c-o*o;if(u===0)return s.set(0,0,0),null;const h=1/u,p=(c*l-o*d)*h,g=(a*d-o*l)*h;return s.set(1-p-g,g,p)}static containsPoint(e,t,n,r){return this.getBarycoord(e,t,n,r,ni)===null?!1:ni.x>=0&&ni.y>=0&&ni.x+ni.y<=1}static getInterpolation(e,t,n,r,s,a,o,l){return this.getBarycoord(e,t,n,r,ni)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(s,ni.x),l.addScaledVector(a,ni.y),l.addScaledVector(o,ni.z),l)}static getInterpolatedAttribute(e,t,n,r,s,a){return Yo.setScalar(0),jo.setScalar(0),$o.setScalar(0),Yo.fromBufferAttribute(e,t),jo.fromBufferAttribute(e,n),$o.fromBufferAttribute(e,r),a.setScalar(0),a.addScaledVector(Yo,s.x),a.addScaledVector(jo,s.y),a.addScaledVector($o,s.z),a}static isFrontFacing(e,t,n,r){return Un.subVectors(n,t),ti.subVectors(e,t),Un.cross(ti).dot(r)<0}set(e,t,n){return this.a.copy(e),this.b.copy(t),this.c.copy(n),this}setFromPointsAndIndices(e,t,n,r){return this.a.copy(e[t]),this.b.copy(e[n]),this.c.copy(e[r]),this}setFromAttributeAndIndices(e,t,n,r){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,n),this.c.fromBufferAttribute(e,r),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return Un.subVectors(this.c,this.b),ti.subVectors(this.a,this.b),Un.cross(ti).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return An.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return An.getBarycoord(e,this.a,this.b,this.c,t)}getInterpolation(e,t,n,r,s){return An.getInterpolation(e,this.a,this.b,this.c,t,n,r,s)}containsPoint(e){return An.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return An.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){const n=this.a,r=this.b,s=this.c;let a,o;hr.subVectors(r,n),fr.subVectors(s,n),Wo.subVectors(e,n);const l=hr.dot(Wo),c=fr.dot(Wo);if(l<=0&&c<=0)return t.copy(n);Xo.subVectors(e,r);const d=hr.dot(Xo),u=fr.dot(Xo);if(d>=0&&u<=d)return t.copy(r);const h=l*u-d*c;if(h<=0&&l>=0&&d<=0)return a=l/(l-d),t.copy(n).addScaledVector(hr,a);qo.subVectors(e,s);const p=hr.dot(qo),g=fr.dot(qo);if(g>=0&&p<=g)return t.copy(s);const v=p*c-l*g;if(v<=0&&c>=0&&g<=0)return o=c/(c-g),t.copy(n).addScaledVector(fr,o);const m=d*g-p*u;if(m<=0&&u-d>=0&&p-g>=0)return zu.subVectors(s,r),o=(u-d)/(u-d+(p-g)),t.copy(r).addScaledVector(zu,o);const f=1/(m+v+h);return a=v*f,o=h*f,t.copy(n).addScaledVector(hr,a).addScaledVector(fr,o)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}const rf={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},yi={h:0,s:0,l:0},ca={h:0,s:0,l:0};function Ko(i,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?i+(e-i)*6*t:t<1/2?e:t<2/3?i+(e-i)*6*(2/3-t):i}class Ie{constructor(e,t,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,n)}set(e,t,n){if(t===void 0&&n===void 0){const r=e;r&&r.isColor?this.copy(r):typeof r=="number"?this.setHex(r):typeof r=="string"&&this.setStyle(r)}else this.setRGB(e,t,n);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=_t){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,tt.colorSpaceToWorking(this,t),this}setRGB(e,t,n,r=tt.workingColorSpace){return this.r=e,this.g=t,this.b=n,tt.colorSpaceToWorking(this,r),this}setHSL(e,t,n,r=tt.workingColorSpace){if(e=zc(e,1),t=Je(t,0,1),n=Je(n,0,1),t===0)this.r=this.g=this.b=n;else{const s=n<=.5?n*(1+t):n+t-n*t,a=2*n-s;this.r=Ko(a,s,e+1/3),this.g=Ko(a,s,e),this.b=Ko(a,s,e-1/3)}return tt.colorSpaceToWorking(this,r),this}setStyle(e,t=_t){function n(s){s!==void 0&&parseFloat(s)<1&&console.warn("THREE.Color: Alpha component of "+e+" will be ignored.")}let r;if(r=/^(\w+)\(([^\)]*)\)/.exec(e)){let s;const a=r[1],o=r[2];switch(a){case"rgb":case"rgba":if(s=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(s[4]),this.setRGB(Math.min(255,parseInt(s[1],10))/255,Math.min(255,parseInt(s[2],10))/255,Math.min(255,parseInt(s[3],10))/255,t);if(s=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(s[4]),this.setRGB(Math.min(100,parseInt(s[1],10))/100,Math.min(100,parseInt(s[2],10))/100,Math.min(100,parseInt(s[3],10))/100,t);break;case"hsl":case"hsla":if(s=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(s[4]),this.setHSL(parseFloat(s[1])/360,parseFloat(s[2])/100,parseFloat(s[3])/100,t);break;default:console.warn("THREE.Color: Unknown color model "+e)}}else if(r=/^\#([A-Fa-f\d]+)$/.exec(e)){const s=r[1],a=s.length;if(a===3)return this.setRGB(parseInt(s.charAt(0),16)/15,parseInt(s.charAt(1),16)/15,parseInt(s.charAt(2),16)/15,t);if(a===6)return this.setHex(parseInt(s,16),t);console.warn("THREE.Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=_t){const n=rf[e.toLowerCase()];return n!==void 0?this.setHex(n,t):console.warn("THREE.Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=pi(e.r),this.g=pi(e.g),this.b=pi(e.b),this}copyLinearToSRGB(e){return this.r=Dr(e.r),this.g=Dr(e.g),this.b=Dr(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=_t){return tt.workingToColorSpace(Yt.copy(this),e),Math.round(Je(Yt.r*255,0,255))*65536+Math.round(Je(Yt.g*255,0,255))*256+Math.round(Je(Yt.b*255,0,255))}getHexString(e=_t){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=tt.workingColorSpace){tt.workingToColorSpace(Yt.copy(this),t);const n=Yt.r,r=Yt.g,s=Yt.b,a=Math.max(n,r,s),o=Math.min(n,r,s);let l,c;const d=(o+a)/2;if(o===a)l=0,c=0;else{const u=a-o;switch(c=d<=.5?u/(a+o):u/(2-a-o),a){case n:l=(r-s)/u+(r<s?6:0);break;case r:l=(s-n)/u+2;break;case s:l=(n-r)/u+4;break}l/=6}return e.h=l,e.s=c,e.l=d,e}getRGB(e,t=tt.workingColorSpace){return tt.workingToColorSpace(Yt.copy(this),t),e.r=Yt.r,e.g=Yt.g,e.b=Yt.b,e}getStyle(e=_t){tt.workingToColorSpace(Yt.copy(this),e);const t=Yt.r,n=Yt.g,r=Yt.b;return e!==_t?`color(${e} ${t.toFixed(3)} ${n.toFixed(3)} ${r.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(n*255)},${Math.round(r*255)})`}offsetHSL(e,t,n){return this.getHSL(yi),this.setHSL(yi.h+e,yi.s+t,yi.l+n)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,n){return this.r=e.r+(t.r-e.r)*n,this.g=e.g+(t.g-e.g)*n,this.b=e.b+(t.b-e.b)*n,this}lerpHSL(e,t){this.getHSL(yi),e.getHSL(ca);const n=ws(yi.h,ca.h,t),r=ws(yi.s,ca.s,t),s=ws(yi.l,ca.l,t);return this.setHSL(n,r,s),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const t=this.r,n=this.g,r=this.b,s=e.elements;return this.r=s[0]*t+s[3]*n+s[6]*r,this.g=s[1]*t+s[4]*n+s[7]*r,this.b=s[2]*t+s[5]*n+s[8]*r,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Yt=new Ie;Ie.NAMES=rf;let Bm=0;class Cn extends es{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Bm++}),this.uuid=kn(),this.name="",this.type="Material",this.blending=Pi,this.side=mi,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Cl,this.blendDst=Il,this.blendEquation=$i,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Ie(0,0,0),this.blendAlpha=0,this.depthFunc=kr,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Au,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=rr,this.stencilZFail=rr,this.stencilZPass=rr,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const t in e){const n=e[t];if(n===void 0){console.warn(`THREE.Material: parameter '${t}' has value of undefined.`);continue}const r=this[t];if(r===void 0){console.warn(`THREE.Material: '${t}' is not a property of THREE.${this.type}.`);continue}r&&r.isColor?r.set(n):r&&r.isVector3&&n&&n.isVector3?r.copy(n):this[t]=n}}toJSON(e){const t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});const n={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(n.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(n.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(e).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(e).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(e).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(e).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(e).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==Pi&&(n.blending=this.blending),this.side!==mi&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==Cl&&(n.blendSrc=this.blendSrc),this.blendDst!==Il&&(n.blendDst=this.blendDst),this.blendEquation!==$i&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==kr&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Au&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==rr&&(n.stencilFail=this.stencilFail),this.stencilZFail!==rr&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==rr&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function r(s){const a=[];for(const o in s){const l=s[o];delete l.metadata,a.push(l)}return a}if(t){const s=r(e.textures),a=r(e.images);s.length>0&&(n.textures=s),a.length>0&&(n.images=a)}return n}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const t=e.clippingPlanes;let n=null;if(t!==null){const r=t.length;n=new Array(r);for(let s=0;s!==r;++s)n[s]=t[s].clone()}return this.clippingPlanes=n,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}class Ut extends Cn{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Ie(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new xn,this.combine=Pc,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const Nt=new U,ua=new Ce;let km=0;class ct{constructor(e,t,n=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:km++}),this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=n,this.usage=mc,this.updateRanges=[],this.gpuType=Bn,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,n){e*=this.itemSize,n*=t.itemSize;for(let r=0,s=this.itemSize;r<s;r++)this.array[e+r]=t.array[n+r];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,n=this.count;t<n;t++)ua.fromBufferAttribute(this,t),ua.applyMatrix3(e),this.setXY(t,ua.x,ua.y);else if(this.itemSize===3)for(let t=0,n=this.count;t<n;t++)Nt.fromBufferAttribute(this,t),Nt.applyMatrix3(e),this.setXYZ(t,Nt.x,Nt.y,Nt.z);return this}applyMatrix4(e){for(let t=0,n=this.count;t<n;t++)Nt.fromBufferAttribute(this,t),Nt.applyMatrix4(e),this.setXYZ(t,Nt.x,Nt.y,Nt.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)Nt.fromBufferAttribute(this,t),Nt.applyNormalMatrix(e),this.setXYZ(t,Nt.x,Nt.y,Nt.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)Nt.fromBufferAttribute(this,t),Nt.transformDirection(e),this.setXYZ(t,Nt.x,Nt.y,Nt.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let n=this.array[e*this.itemSize+t];return this.normalized&&(n=Fn(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=ot(n,this.array)),this.array[e*this.itemSize+t]=n,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=Fn(t,this.array)),t}setX(e,t){return this.normalized&&(t=ot(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=Fn(t,this.array)),t}setY(e,t){return this.normalized&&(t=ot(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=Fn(t,this.array)),t}setZ(e,t){return this.normalized&&(t=ot(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=Fn(t,this.array)),t}setW(e,t){return this.normalized&&(t=ot(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,n){return e*=this.itemSize,this.normalized&&(t=ot(t,this.array),n=ot(n,this.array)),this.array[e+0]=t,this.array[e+1]=n,this}setXYZ(e,t,n,r){return e*=this.itemSize,this.normalized&&(t=ot(t,this.array),n=ot(n,this.array),r=ot(r,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=r,this}setXYZW(e,t,n,r,s){return e*=this.itemSize,this.normalized&&(t=ot(t,this.array),n=ot(n,this.array),r=ot(r,this.array),s=ot(s,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=r,this.array[e+3]=s,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==mc&&(e.usage=this.usage),e}}class co extends ct{constructor(e,t,n){super(new Uint16Array(e),t,n)}}class sf extends ct{constructor(e,t,n){super(new Uint32Array(e),t,n)}}class nt extends ct{constructor(e,t,n){super(new Float32Array(e),t,n)}}let zm=0;const Mn=new qe,Zo=new Mt,pr=new U,gn=new jn,ds=new jn,zt=new U;class Lt extends es{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:zm++}),this.uuid=kn(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(tf(e)?sf:co)(e,1):this.index=e,this}setIndirect(e){return this.indirect=e,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,n=0){this.groups.push({start:e,count:t,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){const t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);const n=this.attributes.normal;if(n!==void 0){const s=new $e().getNormalMatrix(e);n.applyNormalMatrix(s),n.needsUpdate=!0}const r=this.attributes.tangent;return r!==void 0&&(r.transformDirection(e),r.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return Mn.makeRotationFromQuaternion(e),this.applyMatrix4(Mn),this}rotateX(e){return Mn.makeRotationX(e),this.applyMatrix4(Mn),this}rotateY(e){return Mn.makeRotationY(e),this.applyMatrix4(Mn),this}rotateZ(e){return Mn.makeRotationZ(e),this.applyMatrix4(Mn),this}translate(e,t,n){return Mn.makeTranslation(e,t,n),this.applyMatrix4(Mn),this}scale(e,t,n){return Mn.makeScale(e,t,n),this.applyMatrix4(Mn),this}lookAt(e){return Zo.lookAt(e),Zo.updateMatrix(),this.applyMatrix4(Zo.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(pr).negate(),this.translate(pr.x,pr.y,pr.z),this}setFromPoints(e){const t=this.getAttribute("position");if(t===void 0){const n=[];for(let r=0,s=e.length;r<s;r++){const a=e[r];n.push(a.x,a.y,a.z||0)}this.setAttribute("position",new nt(n,3))}else{const n=Math.min(e.length,t.count);for(let r=0;r<n;r++){const s=e[r];t.setXYZ(r,s.x,s.y,s.z||0)}e.length>t.count&&console.warn("THREE.BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new jn);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new U(-1/0,-1/0,-1/0),new U(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let n=0,r=t.length;n<r;n++){const s=t[n];gn.setFromBufferAttribute(s),this.morphTargetsRelative?(zt.addVectors(this.boundingBox.min,gn.min),this.boundingBox.expandByPoint(zt),zt.addVectors(this.boundingBox.max,gn.max),this.boundingBox.expandByPoint(zt)):(this.boundingBox.expandByPoint(gn.min),this.boundingBox.expandByPoint(gn.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new $n);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new U,1/0);return}if(e){const n=this.boundingSphere.center;if(gn.setFromBufferAttribute(e),t)for(let s=0,a=t.length;s<a;s++){const o=t[s];ds.setFromBufferAttribute(o),this.morphTargetsRelative?(zt.addVectors(gn.min,ds.min),gn.expandByPoint(zt),zt.addVectors(gn.max,ds.max),gn.expandByPoint(zt)):(gn.expandByPoint(ds.min),gn.expandByPoint(ds.max))}gn.getCenter(n);let r=0;for(let s=0,a=e.count;s<a;s++)zt.fromBufferAttribute(e,s),r=Math.max(r,n.distanceToSquared(zt));if(t)for(let s=0,a=t.length;s<a;s++){const o=t[s],l=this.morphTargetsRelative;for(let c=0,d=o.count;c<d;c++)zt.fromBufferAttribute(o,c),l&&(pr.fromBufferAttribute(e,c),zt.add(pr)),r=Math.max(r,n.distanceToSquared(zt))}this.boundingSphere.radius=Math.sqrt(r),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const n=t.position,r=t.normal,s=t.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new ct(new Float32Array(4*n.count),4));const a=this.getAttribute("tangent"),o=[],l=[];for(let A=0;A<n.count;A++)o[A]=new U,l[A]=new U;const c=new U,d=new U,u=new U,h=new Ce,p=new Ce,g=new Ce,v=new U,m=new U;function f(A,S,b){c.fromBufferAttribute(n,A),d.fromBufferAttribute(n,S),u.fromBufferAttribute(n,b),h.fromBufferAttribute(s,A),p.fromBufferAttribute(s,S),g.fromBufferAttribute(s,b),d.sub(c),u.sub(c),p.sub(h),g.sub(h);const T=1/(p.x*g.y-g.x*p.y);isFinite(T)&&(v.copy(d).multiplyScalar(g.y).addScaledVector(u,-p.y).multiplyScalar(T),m.copy(u).multiplyScalar(p.x).addScaledVector(d,-g.x).multiplyScalar(T),o[A].add(v),o[S].add(v),o[b].add(v),l[A].add(m),l[S].add(m),l[b].add(m))}let y=this.groups;y.length===0&&(y=[{start:0,count:e.count}]);for(let A=0,S=y.length;A<S;++A){const b=y[A],T=b.start,D=b.count;for(let k=T,z=T+D;k<z;k+=3)f(e.getX(k+0),e.getX(k+1),e.getX(k+2))}const _=new U,x=new U,R=new U,M=new U;function w(A){R.fromBufferAttribute(r,A),M.copy(R);const S=o[A];_.copy(S),_.sub(R.multiplyScalar(R.dot(S))).normalize(),x.crossVectors(M,S);const T=x.dot(l[A])<0?-1:1;a.setXYZW(A,_.x,_.y,_.z,T)}for(let A=0,S=y.length;A<S;++A){const b=y[A],T=b.start,D=b.count;for(let k=T,z=T+D;k<z;k+=3)w(e.getX(k+0)),w(e.getX(k+1)),w(e.getX(k+2))}}computeVertexNormals(){const e=this.index,t=this.getAttribute("position");if(t!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new ct(new Float32Array(t.count*3),3),this.setAttribute("normal",n);else for(let h=0,p=n.count;h<p;h++)n.setXYZ(h,0,0,0);const r=new U,s=new U,a=new U,o=new U,l=new U,c=new U,d=new U,u=new U;if(e)for(let h=0,p=e.count;h<p;h+=3){const g=e.getX(h+0),v=e.getX(h+1),m=e.getX(h+2);r.fromBufferAttribute(t,g),s.fromBufferAttribute(t,v),a.fromBufferAttribute(t,m),d.subVectors(a,s),u.subVectors(r,s),d.cross(u),o.fromBufferAttribute(n,g),l.fromBufferAttribute(n,v),c.fromBufferAttribute(n,m),o.add(d),l.add(d),c.add(d),n.setXYZ(g,o.x,o.y,o.z),n.setXYZ(v,l.x,l.y,l.z),n.setXYZ(m,c.x,c.y,c.z)}else for(let h=0,p=t.count;h<p;h+=3)r.fromBufferAttribute(t,h+0),s.fromBufferAttribute(t,h+1),a.fromBufferAttribute(t,h+2),d.subVectors(a,s),u.subVectors(r,s),d.cross(u),n.setXYZ(h+0,d.x,d.y,d.z),n.setXYZ(h+1,d.x,d.y,d.z),n.setXYZ(h+2,d.x,d.y,d.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let t=0,n=e.count;t<n;t++)zt.fromBufferAttribute(e,t),zt.normalize(),e.setXYZ(t,zt.x,zt.y,zt.z)}toNonIndexed(){function e(o,l){const c=o.array,d=o.itemSize,u=o.normalized,h=new c.constructor(l.length*d);let p=0,g=0;for(let v=0,m=l.length;v<m;v++){o.isInterleavedBufferAttribute?p=l[v]*o.data.stride+o.offset:p=l[v]*d;for(let f=0;f<d;f++)h[g++]=c[p++]}return new ct(h,d,u)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const t=new Lt,n=this.index.array,r=this.attributes;for(const o in r){const l=r[o],c=e(l,n);t.setAttribute(o,c)}const s=this.morphAttributes;for(const o in s){const l=[],c=s[o];for(let d=0,u=c.length;d<u;d++){const h=c[d],p=e(h,n);l.push(p)}t.morphAttributes[o]=l}t.morphTargetsRelative=this.morphTargetsRelative;const a=this.groups;for(let o=0,l=a.length;o<l;o++){const c=a[o];t.addGroup(c.start,c.count,c.materialIndex)}return t}toJSON(){const e={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){const l=this.parameters;for(const c in l)l[c]!==void 0&&(e[c]=l[c]);return e}e.data={attributes:{}};const t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});const n=this.attributes;for(const l in n){const c=n[l];e.data.attributes[l]=c.toJSON(e.data)}const r={};let s=!1;for(const l in this.morphAttributes){const c=this.morphAttributes[l],d=[];for(let u=0,h=c.length;u<h;u++){const p=c[u];d.push(p.toJSON(e.data))}d.length>0&&(r[l]=d,s=!0)}s&&(e.data.morphAttributes=r,e.data.morphTargetsRelative=this.morphTargetsRelative);const a=this.groups;a.length>0&&(e.data.groups=JSON.parse(JSON.stringify(a)));const o=this.boundingSphere;return o!==null&&(e.data.boundingSphere=o.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const t={};this.name=e.name;const n=e.index;n!==null&&this.setIndex(n.clone());const r=e.attributes;for(const c in r){const d=r[c];this.setAttribute(c,d.clone(t))}const s=e.morphAttributes;for(const c in s){const d=[],u=s[c];for(let h=0,p=u.length;h<p;h++)d.push(u[h].clone(t));this.morphAttributes[c]=d}this.morphTargetsRelative=e.morphTargetsRelative;const a=e.groups;for(let c=0,d=a.length;c<d;c++){const u=a[c];this.addGroup(u.start,u.count,u.materialIndex)}const o=e.boundingBox;o!==null&&(this.boundingBox=o.clone());const l=e.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const Vu=new qe,Vi=new Vs,da=new $n,Hu=new U,ha=new U,fa=new U,pa=new U,Jo=new U,ma=new U,Gu=new U,ga=new U;class ht extends Mt{constructor(e=new Lt,t=new Ut){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const r=t[n[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,a=r.length;s<a;s++){const o=r[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=s}}}}getVertexPosition(e,t){const n=this.geometry,r=n.attributes.position,s=n.morphAttributes.position,a=n.morphTargetsRelative;t.fromBufferAttribute(r,e);const o=this.morphTargetInfluences;if(s&&o){ma.set(0,0,0);for(let l=0,c=s.length;l<c;l++){const d=o[l],u=s[l];d!==0&&(Jo.fromBufferAttribute(u,e),a?ma.addScaledVector(Jo,d):ma.addScaledVector(Jo.sub(t),d))}t.add(ma)}return t}raycast(e,t){const n=this.geometry,r=this.material,s=this.matrixWorld;r!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),da.copy(n.boundingSphere),da.applyMatrix4(s),Vi.copy(e.ray).recast(e.near),!(da.containsPoint(Vi.origin)===!1&&(Vi.intersectSphere(da,Hu)===null||Vi.origin.distanceToSquared(Hu)>(e.far-e.near)**2))&&(Vu.copy(s).invert(),Vi.copy(e.ray).applyMatrix4(Vu),!(n.boundingBox!==null&&Vi.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(e,t,Vi)))}_computeIntersections(e,t,n){let r;const s=this.geometry,a=this.material,o=s.index,l=s.attributes.position,c=s.attributes.uv,d=s.attributes.uv1,u=s.attributes.normal,h=s.groups,p=s.drawRange;if(o!==null)if(Array.isArray(a))for(let g=0,v=h.length;g<v;g++){const m=h[g],f=a[m.materialIndex],y=Math.max(m.start,p.start),_=Math.min(o.count,Math.min(m.start+m.count,p.start+p.count));for(let x=y,R=_;x<R;x+=3){const M=o.getX(x),w=o.getX(x+1),A=o.getX(x+2);r=va(this,f,e,n,c,d,u,M,w,A),r&&(r.faceIndex=Math.floor(x/3),r.face.materialIndex=m.materialIndex,t.push(r))}}else{const g=Math.max(0,p.start),v=Math.min(o.count,p.start+p.count);for(let m=g,f=v;m<f;m+=3){const y=o.getX(m),_=o.getX(m+1),x=o.getX(m+2);r=va(this,a,e,n,c,d,u,y,_,x),r&&(r.faceIndex=Math.floor(m/3),t.push(r))}}else if(l!==void 0)if(Array.isArray(a))for(let g=0,v=h.length;g<v;g++){const m=h[g],f=a[m.materialIndex],y=Math.max(m.start,p.start),_=Math.min(l.count,Math.min(m.start+m.count,p.start+p.count));for(let x=y,R=_;x<R;x+=3){const M=x,w=x+1,A=x+2;r=va(this,f,e,n,c,d,u,M,w,A),r&&(r.faceIndex=Math.floor(x/3),r.face.materialIndex=m.materialIndex,t.push(r))}}else{const g=Math.max(0,p.start),v=Math.min(l.count,p.start+p.count);for(let m=g,f=v;m<f;m+=3){const y=m,_=m+1,x=m+2;r=va(this,a,e,n,c,d,u,y,_,x),r&&(r.faceIndex=Math.floor(m/3),t.push(r))}}}}function Vm(i,e,t,n,r,s,a,o){let l;if(e.side===cn?l=n.intersectTriangle(a,s,r,!0,o):l=n.intersectTriangle(r,s,a,e.side===mi,o),l===null)return null;ga.copy(o),ga.applyMatrix4(i.matrixWorld);const c=t.ray.origin.distanceTo(ga);return c<t.near||c>t.far?null:{distance:c,point:ga.clone(),object:i}}function va(i,e,t,n,r,s,a,o,l,c){i.getVertexPosition(o,ha),i.getVertexPosition(l,fa),i.getVertexPosition(c,pa);const d=Vm(i,e,t,n,ha,fa,pa,Gu);if(d){const u=new U;An.getBarycoord(Gu,ha,fa,pa,u),r&&(d.uv=An.getInterpolatedAttribute(r,o,l,c,u,new Ce)),s&&(d.uv1=An.getInterpolatedAttribute(s,o,l,c,u,new Ce)),a&&(d.normal=An.getInterpolatedAttribute(a,o,l,c,u,new U),d.normal.dot(n.direction)>0&&d.normal.multiplyScalar(-1));const h={a:o,b:l,c,normal:new U,materialIndex:0};An.getNormal(ha,fa,pa,h.normal),d.face=h,d.barycoord=u}return d}class Hs extends Lt{constructor(e=1,t=1,n=1,r=1,s=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:n,widthSegments:r,heightSegments:s,depthSegments:a};const o=this;r=Math.floor(r),s=Math.floor(s),a=Math.floor(a);const l=[],c=[],d=[],u=[];let h=0,p=0;g("z","y","x",-1,-1,n,t,e,a,s,0),g("z","y","x",1,-1,n,t,-e,a,s,1),g("x","z","y",1,1,e,n,t,r,a,2),g("x","z","y",1,-1,e,n,-t,r,a,3),g("x","y","z",1,-1,e,t,n,r,s,4),g("x","y","z",-1,-1,e,t,-n,r,s,5),this.setIndex(l),this.setAttribute("position",new nt(c,3)),this.setAttribute("normal",new nt(d,3)),this.setAttribute("uv",new nt(u,2));function g(v,m,f,y,_,x,R,M,w,A,S){const b=x/w,T=R/A,D=x/2,k=R/2,z=M/2,H=w+1,L=A+1;let N=0,B=0;const V=new U;for(let Y=0;Y<L;Y++){const ee=Y*T-k;for(let $=0;$<H;$++){const re=$*b-D;V[v]=re*y,V[m]=ee*_,V[f]=z,c.push(V.x,V.y,V.z),V[v]=0,V[m]=0,V[f]=M>0?1:-1,d.push(V.x,V.y,V.z),u.push($/w),u.push(1-Y/A),N+=1}}for(let Y=0;Y<A;Y++)for(let ee=0;ee<w;ee++){const $=h+ee+H*Y,re=h+ee+H*(Y+1),te=h+(ee+1)+H*(Y+1),F=h+(ee+1)+H*Y;l.push($,re,F),l.push(re,te,F),B+=6}o.addGroup(p,B,S),p+=B,h+=N}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Hs(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}function Wr(i){const e={};for(const t in i){e[t]={};for(const n in i[t]){const r=i[t][n];r&&(r.isColor||r.isMatrix3||r.isMatrix4||r.isVector2||r.isVector3||r.isVector4||r.isTexture||r.isQuaternion)?r.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][n]=null):e[t][n]=r.clone():Array.isArray(r)?e[t][n]=r.slice():e[t][n]=r}}return e}function Kt(i){const e={};for(let t=0;t<i.length;t++){const n=Wr(i[t]);for(const r in n)e[r]=n[r]}return e}function Hm(i){const e=[];for(let t=0;t<i.length;t++)e.push(i[t].clone());return e}function af(i){const e=i.getRenderTarget();return e===null?i.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:tt.workingColorSpace}const Ya={clone:Wr,merge:Kt};var Gm=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,Wm=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class Rt extends Cn{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=Gm,this.fragmentShader=Wm,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=Wr(e.uniforms),this.uniformsGroups=Hm(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this}toJSON(e){const t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(const r in this.uniforms){const a=this.uniforms[r].value;a&&a.isTexture?t.uniforms[r]={type:"t",value:a.toJSON(e).uuid}:a&&a.isColor?t.uniforms[r]={type:"c",value:a.getHex()}:a&&a.isVector2?t.uniforms[r]={type:"v2",value:a.toArray()}:a&&a.isVector3?t.uniforms[r]={type:"v3",value:a.toArray()}:a&&a.isVector4?t.uniforms[r]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?t.uniforms[r]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?t.uniforms[r]={type:"m4",value:a.toArray()}:t.uniforms[r]={value:a}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;const n={};for(const r in this.extensions)this.extensions[r]===!0&&(n[r]=!0);return Object.keys(n).length>0&&(t.extensions=n),t}}class of extends Mt{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new qe,this.projectionMatrix=new qe,this.projectionMatrixInverse=new qe,this.coordinateSystem=qn,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,t){super.updateWorldMatrix(e,t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}}const bi=new U,Wu=new Ce,Xu=new Ce;class Zt extends of{constructor(e=50,t=1,n=.1,r=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=n,this.far=r,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const t=.5*this.getFilmHeight()/e;this.fov=Gr*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(As*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return Gr*2*Math.atan(Math.tan(As*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,n){bi.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(bi.x,bi.y).multiplyScalar(-e/bi.z),bi.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(bi.x,bi.y).multiplyScalar(-e/bi.z)}getViewSize(e,t){return this.getViewBounds(e,Wu,Xu),t.subVectors(Xu,Wu)}setViewOffset(e,t,n,r,s,a){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=r,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let t=e*Math.tan(As*.5*this.fov)/this.zoom,n=2*t,r=this.aspect*n,s=-.5*r;const a=this.view;if(this.view!==null&&this.view.enabled){const l=a.fullWidth,c=a.fullHeight;s+=a.offsetX*r/l,t-=a.offsetY*n/c,r*=a.width/l,n*=a.height/c}const o=this.filmOffset;o!==0&&(s+=e*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(s,s+r,t,t-n,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}}const mr=-90,gr=1;class Xm extends Mt{constructor(e,t,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;const r=new Zt(mr,gr,e,t);r.layers=this.layers,this.add(r);const s=new Zt(mr,gr,e,t);s.layers=this.layers,this.add(s);const a=new Zt(mr,gr,e,t);a.layers=this.layers,this.add(a);const o=new Zt(mr,gr,e,t);o.layers=this.layers,this.add(o);const l=new Zt(mr,gr,e,t);l.layers=this.layers,this.add(l);const c=new Zt(mr,gr,e,t);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){const e=this.coordinateSystem,t=this.children.concat(),[n,r,s,a,o,l]=t;for(const c of t)this.remove(c);if(e===qn)n.up.set(0,1,0),n.lookAt(1,0,0),r.up.set(0,1,0),r.lookAt(-1,0,0),s.up.set(0,0,-1),s.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(e===qa)n.up.set(0,-1,0),n.lookAt(-1,0,0),r.up.set(0,-1,0),r.lookAt(1,0,0),s.up.set(0,0,1),s.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const c of t)this.add(c),c.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();const{renderTarget:n,activeMipmapLevel:r}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[s,a,o,l,c,d]=this.children,u=e.getRenderTarget(),h=e.getActiveCubeFace(),p=e.getActiveMipmapLevel(),g=e.xr.enabled;e.xr.enabled=!1;const v=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,e.setRenderTarget(n,0,r),e.render(t,s),e.setRenderTarget(n,1,r),e.render(t,a),e.setRenderTarget(n,2,r),e.render(t,o),e.setRenderTarget(n,3,r),e.render(t,l),e.setRenderTarget(n,4,r),e.render(t,c),n.texture.generateMipmaps=v,e.setRenderTarget(n,5,r),e.render(t,d),e.setRenderTarget(u,h,p),e.xr.enabled=g,n.texture.needsPMREMUpdate=!0}}class lf extends Ft{constructor(e=[],t=zr,n,r,s,a,o,l,c,d){super(e,t,n,r,s,a,o,l,c,d),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class qm extends zn{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;const n={width:e,height:e,depth:1},r=[n,n,n,n,n,n];this.texture=new lf(r),this._setTextureOptions(t),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;const n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},r=new Hs(5,5,5),s=new Rt({name:"CubemapFromEquirect",uniforms:Wr(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:cn,blending:hi});s.uniforms.tEquirect.value=t;const a=new ht(r,s),o=t.minFilter;return t.minFilter===Gt&&(t.minFilter=Dt),new Xm(1,10,this).update(e,a),t.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(e,t=!0,n=!0,r=!0){const s=e.getRenderTarget();for(let a=0;a<6;a++)e.setRenderTarget(this,a),e.clear(t,n,r);e.setRenderTarget(s)}}class Ct extends Mt{constructor(){super(),this.isGroup=!0,this.type="Group"}}const Ym={type:"move"};class Qo{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new Ct,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new Ct,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new U,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new U),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new Ct,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new U,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new U),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const t=this._hand;if(t)for(const n of e.hand.values())this._getHandJoint(t,n)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,n){let r=null,s=null,a=null;const o=this._targetRay,l=this._grip,c=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(c&&e.hand){a=!0;for(const v of e.hand.values()){const m=t.getJointPose(v,n),f=this._getHandJoint(c,v);m!==null&&(f.matrix.fromArray(m.transform.matrix),f.matrix.decompose(f.position,f.rotation,f.scale),f.matrixWorldNeedsUpdate=!0,f.jointRadius=m.radius),f.visible=m!==null}const d=c.joints["index-finger-tip"],u=c.joints["thumb-tip"],h=d.position.distanceTo(u.position),p=.02,g=.005;c.inputState.pinching&&h>p+g?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!c.inputState.pinching&&h<=p-g&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else l!==null&&e.gripSpace&&(s=t.getPose(e.gripSpace,n),s!==null&&(l.matrix.fromArray(s.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,s.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(s.linearVelocity)):l.hasLinearVelocity=!1,s.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(s.angularVelocity)):l.hasAngularVelocity=!1));o!==null&&(r=t.getPose(e.targetRaySpace,n),r===null&&s!==null&&(r=s),r!==null&&(o.matrix.fromArray(r.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,r.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(r.linearVelocity)):o.hasLinearVelocity=!1,r.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(r.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(Ym)))}return o!==null&&(o.visible=r!==null),l!==null&&(l.visible=s!==null),c!==null&&(c.visible=a!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){const n=new Ct;n.matrixAutoUpdate=!1,n.visible=!1,e.joints[t.jointName]=n,e.add(n)}return e.joints[t.jointName]}}class cf extends Mt{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new xn,this.environmentIntensity=1,this.environmentRotation=new xn,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(t.object.environmentIntensity=this.environmentIntensity),t.object.environmentRotation=this.environmentRotation.toArray(),t}}class uf{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e!==void 0?e.length/t:0,this.usage=mc,this.updateRanges=[],this.version=0,this.uuid=kn()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,n){e*=this.stride,n*=t.stride;for(let r=0,s=this.stride;r<s;r++)this.array[e+r]=t.array[n+r];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=kn()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);const t=new this.array.constructor(e.arrayBuffers[this.array.buffer._uuid]),n=new this.constructor(t,this.stride);return n.setUsage(this.usage),n}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){return e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=kn()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}}const $t=new U;class Bs{constructor(e,t,n,r=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=e,this.itemSize=t,this.offset=n,this.normalized=r}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let t=0,n=this.data.count;t<n;t++)$t.fromBufferAttribute(this,t),$t.applyMatrix4(e),this.setXYZ(t,$t.x,$t.y,$t.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)$t.fromBufferAttribute(this,t),$t.applyNormalMatrix(e),this.setXYZ(t,$t.x,$t.y,$t.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)$t.fromBufferAttribute(this,t),$t.transformDirection(e),this.setXYZ(t,$t.x,$t.y,$t.z);return this}getComponent(e,t){let n=this.array[e*this.data.stride+this.offset+t];return this.normalized&&(n=Fn(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=ot(n,this.array)),this.data.array[e*this.data.stride+this.offset+t]=n,this}setX(e,t){return this.normalized&&(t=ot(t,this.array)),this.data.array[e*this.data.stride+this.offset]=t,this}setY(e,t){return this.normalized&&(t=ot(t,this.array)),this.data.array[e*this.data.stride+this.offset+1]=t,this}setZ(e,t){return this.normalized&&(t=ot(t,this.array)),this.data.array[e*this.data.stride+this.offset+2]=t,this}setW(e,t){return this.normalized&&(t=ot(t,this.array)),this.data.array[e*this.data.stride+this.offset+3]=t,this}getX(e){let t=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(t=Fn(t,this.array)),t}getY(e){let t=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(t=Fn(t,this.array)),t}getZ(e){let t=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(t=Fn(t,this.array)),t}getW(e){let t=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(t=Fn(t,this.array)),t}setXY(e,t,n){return e=e*this.data.stride+this.offset,this.normalized&&(t=ot(t,this.array),n=ot(n,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this}setXYZ(e,t,n,r){return e=e*this.data.stride+this.offset,this.normalized&&(t=ot(t,this.array),n=ot(n,this.array),r=ot(r,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=r,this}setXYZW(e,t,n,r,s){return e=e*this.data.stride+this.offset,this.normalized&&(t=ot(t,this.array),n=ot(n,this.array),r=ot(r,this.array),s=ot(s,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=r,this.data.array[e+3]=s,this}clone(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let n=0;n<this.count;n++){const r=n*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[r+s])}return new ct(new this.array.constructor(t),this.itemSize,this.normalized)}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.clone(e)),new Bs(e.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let n=0;n<this.count;n++){const r=n*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[r+s])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:t,normalized:this.normalized}}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}}class Gs extends Cn{constructor(e){super(),this.isSpriteMaterial=!0,this.type="SpriteMaterial",this.color=new Ie(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.rotation=e.rotation,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}let vr;const hs=new U,_r=new U,xr=new U,yr=new Ce,fs=new Ce,df=new qe,_a=new U,ps=new U,xa=new U,qu=new Ce,el=new Ce,Yu=new Ce;class uo extends Mt{constructor(e=new Gs){if(super(),this.isSprite=!0,this.type="Sprite",vr===void 0){vr=new Lt;const t=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),n=new uf(t,5);vr.setIndex([0,1,2,0,2,3]),vr.setAttribute("position",new Bs(n,3,0,!1)),vr.setAttribute("uv",new Bs(n,2,3,!1))}this.geometry=vr,this.material=e,this.center=new Ce(.5,.5),this.count=1}raycast(e,t){e.camera===null&&console.error('THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),_r.setFromMatrixScale(this.matrixWorld),df.copy(e.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(e.camera.matrixWorldInverse,this.matrixWorld),xr.setFromMatrixPosition(this.modelViewMatrix),e.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&_r.multiplyScalar(-xr.z);const n=this.material.rotation;let r,s;n!==0&&(s=Math.cos(n),r=Math.sin(n));const a=this.center;ya(_a.set(-.5,-.5,0),xr,a,_r,r,s),ya(ps.set(.5,-.5,0),xr,a,_r,r,s),ya(xa.set(.5,.5,0),xr,a,_r,r,s),qu.set(0,0),el.set(1,0),Yu.set(1,1);let o=e.ray.intersectTriangle(_a,ps,xa,!1,hs);if(o===null&&(ya(ps.set(-.5,.5,0),xr,a,_r,r,s),el.set(0,1),o=e.ray.intersectTriangle(_a,xa,ps,!1,hs),o===null))return;const l=e.ray.origin.distanceTo(hs);l<e.near||l>e.far||t.push({distance:l,point:hs.clone(),uv:An.getInterpolation(hs,_a,ps,xa,qu,el,Yu,new Ce),face:null,object:this})}copy(e,t){return super.copy(e,t),e.center!==void 0&&this.center.copy(e.center),this.material=e.material,this}}function ya(i,e,t,n,r,s){yr.subVectors(i,t).addScalar(.5).multiply(n),r!==void 0?(fs.x=s*yr.x-r*yr.y,fs.y=r*yr.x+s*yr.y):fs.copy(yr),i.copy(e),i.x+=fs.x,i.y+=fs.y,i.applyMatrix4(df)}const ju=new U,$u=new rt,Ku=new rt,jm=new U,Zu=new qe,ba=new U,tl=new $n,Ju=new qe,nl=new Vs;class Gc extends ht{constructor(e,t){super(e,t),this.isSkinnedMesh=!0,this.type="SkinnedMesh",this.bindMode=Su,this.bindMatrix=new qe,this.bindMatrixInverse=new qe,this.boundingBox=null,this.boundingSphere=null}computeBoundingBox(){const e=this.geometry;this.boundingBox===null&&(this.boundingBox=new jn),this.boundingBox.makeEmpty();const t=e.getAttribute("position");for(let n=0;n<t.count;n++)this.getVertexPosition(n,ba),this.boundingBox.expandByPoint(ba)}computeBoundingSphere(){const e=this.geometry;this.boundingSphere===null&&(this.boundingSphere=new $n),this.boundingSphere.makeEmpty();const t=e.getAttribute("position");for(let n=0;n<t.count;n++)this.getVertexPosition(n,ba),this.boundingSphere.expandByPoint(ba)}copy(e,t){return super.copy(e,t),this.bindMode=e.bindMode,this.bindMatrix.copy(e.bindMatrix),this.bindMatrixInverse.copy(e.bindMatrixInverse),this.skeleton=e.skeleton,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}raycast(e,t){const n=this.material,r=this.matrixWorld;n!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),tl.copy(this.boundingSphere),tl.applyMatrix4(r),e.ray.intersectsSphere(tl)!==!1&&(Ju.copy(r).invert(),nl.copy(e.ray).applyMatrix4(Ju),!(this.boundingBox!==null&&nl.intersectsBox(this.boundingBox)===!1)&&this._computeIntersections(e,t,nl)))}getVertexPosition(e,t){return super.getVertexPosition(e,t),this.applyBoneTransform(e,t),t}bind(e,t){this.skeleton=e,t===void 0&&(this.updateMatrixWorld(!0),this.skeleton.calculateInverses(),t=this.matrixWorld),this.bindMatrix.copy(t),this.bindMatrixInverse.copy(t).invert()}pose(){this.skeleton.pose()}normalizeSkinWeights(){const e=new rt,t=this.geometry.attributes.skinWeight;for(let n=0,r=t.count;n<r;n++){e.fromBufferAttribute(t,n);const s=1/e.manhattanLength();s!==1/0?e.multiplyScalar(s):e.set(1,0,0,0),t.setXYZW(n,e.x,e.y,e.z,e.w)}}updateMatrixWorld(e){super.updateMatrixWorld(e),this.bindMode===Su?this.bindMatrixInverse.copy(this.matrixWorld).invert():this.bindMode===jp?this.bindMatrixInverse.copy(this.bindMatrix).invert():console.warn("THREE.SkinnedMesh: Unrecognized bindMode: "+this.bindMode)}applyBoneTransform(e,t){const n=this.skeleton,r=this.geometry;$u.fromBufferAttribute(r.attributes.skinIndex,e),Ku.fromBufferAttribute(r.attributes.skinWeight,e),ju.copy(t).applyMatrix4(this.bindMatrix),t.set(0,0,0);for(let s=0;s<4;s++){const a=Ku.getComponent(s);if(a!==0){const o=$u.getComponent(s);Zu.multiplyMatrices(n.bones[o].matrixWorld,n.boneInverses[o]),t.addScaledVector(jm.copy(ju).applyMatrix4(Zu),a)}}return t.applyMatrix4(this.bindMatrixInverse)}}class ho extends Mt{constructor(){super(),this.isBone=!0,this.type="Bone"}}class hf extends Ft{constructor(e=null,t=1,n=1,r,s,a,o,l,c=en,d=en,u,h){super(null,a,o,l,c,d,r,s,u,h),this.isDataTexture=!0,this.image={data:e,width:t,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const Qu=new qe,$m=new qe;class Ws{constructor(e=[],t=[]){this.uuid=kn(),this.bones=e.slice(0),this.boneInverses=t,this.boneMatrices=null,this.boneTexture=null,this.init()}init(){const e=this.bones,t=this.boneInverses;if(this.boneMatrices=new Float32Array(e.length*16),t.length===0)this.calculateInverses();else if(e.length!==t.length){console.warn("THREE.Skeleton: Number of inverse bone matrices does not match amount of bones."),this.boneInverses=[];for(let n=0,r=this.bones.length;n<r;n++)this.boneInverses.push(new qe)}}calculateInverses(){this.boneInverses.length=0;for(let e=0,t=this.bones.length;e<t;e++){const n=new qe;this.bones[e]&&n.copy(this.bones[e].matrixWorld).invert(),this.boneInverses.push(n)}}pose(){for(let e=0,t=this.bones.length;e<t;e++){const n=this.bones[e];n&&n.matrixWorld.copy(this.boneInverses[e]).invert()}for(let e=0,t=this.bones.length;e<t;e++){const n=this.bones[e];n&&(n.parent&&n.parent.isBone?(n.matrix.copy(n.parent.matrixWorld).invert(),n.matrix.multiply(n.matrixWorld)):n.matrix.copy(n.matrixWorld),n.matrix.decompose(n.position,n.quaternion,n.scale))}}update(){const e=this.bones,t=this.boneInverses,n=this.boneMatrices,r=this.boneTexture;for(let s=0,a=e.length;s<a;s++){const o=e[s]?e[s].matrixWorld:$m;Qu.multiplyMatrices(o,t[s]),Qu.toArray(n,s*16)}r!==null&&(r.needsUpdate=!0)}clone(){return new Ws(this.bones,this.boneInverses)}computeBoneTexture(){let e=Math.sqrt(this.bones.length*4);e=Math.ceil(e/4)*4,e=Math.max(e,4);const t=new Float32Array(e*e*4);t.set(this.boneMatrices);const n=new hf(t,e,e,wn,Bn);return n.needsUpdate=!0,this.boneMatrices=t,this.boneTexture=n,this}getBoneByName(e){for(let t=0,n=this.bones.length;t<n;t++){const r=this.bones[t];if(r.name===e)return r}}dispose(){this.boneTexture!==null&&(this.boneTexture.dispose(),this.boneTexture=null)}fromJSON(e,t){this.uuid=e.uuid;for(let n=0,r=e.bones.length;n<r;n++){const s=e.bones[n];let a=t[s];a===void 0&&(console.warn("THREE.Skeleton: No bone found with UUID:",s),a=new ho),this.bones.push(a),this.boneInverses.push(new qe().fromArray(e.boneInverses[n]))}return this.init(),this}toJSON(){const e={metadata:{version:4.7,type:"Skeleton",generator:"Skeleton.toJSON"},bones:[],boneInverses:[]};e.uuid=this.uuid;const t=this.bones,n=this.boneInverses;for(let r=0,s=t.length;r<s;r++){const a=t[r];e.bones.push(a.uuid);const o=n[r];e.boneInverses.push(o.toArray())}return e}}class Xr extends ct{constructor(e,t,n,r=1){super(e,t,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=r}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){const e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}}const br=new qe,ed=new qe,Sa=[],td=new jn,Km=new qe,ms=new ht,gs=new $n;class Zm extends ht{constructor(e,t,n){super(e,t),this.isInstancedMesh=!0,this.instanceMatrix=new Xr(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let r=0;r<n;r++)this.setMatrixAt(r,Km)}computeBoundingBox(){const e=this.geometry,t=this.count;this.boundingBox===null&&(this.boundingBox=new jn),e.boundingBox===null&&e.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,br),td.copy(e.boundingBox).applyMatrix4(br),this.boundingBox.union(td)}computeBoundingSphere(){const e=this.geometry,t=this.count;this.boundingSphere===null&&(this.boundingSphere=new $n),e.boundingSphere===null&&e.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,br),gs.copy(e.boundingSphere).applyMatrix4(br),this.boundingSphere.union(gs)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),e.morphTexture!==null&&(this.morphTexture=e.morphTexture.clone()),e.instanceColor!==null&&(this.instanceColor=e.instanceColor.clone()),this.count=e.count,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}getColorAt(e,t){t.fromArray(this.instanceColor.array,e*3)}getMatrixAt(e,t){t.fromArray(this.instanceMatrix.array,e*16)}getMorphAt(e,t){const n=t.morphTargetInfluences,r=this.morphTexture.source.data.data,s=n.length+1,a=e*s+1;for(let o=0;o<n.length;o++)n[o]=r[a+o]}raycast(e,t){const n=this.matrixWorld,r=this.count;if(ms.geometry=this.geometry,ms.material=this.material,ms.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),gs.copy(this.boundingSphere),gs.applyMatrix4(n),e.ray.intersectsSphere(gs)!==!1))for(let s=0;s<r;s++){this.getMatrixAt(s,br),ed.multiplyMatrices(n,br),ms.matrixWorld=ed,ms.raycast(e,Sa);for(let a=0,o=Sa.length;a<o;a++){const l=Sa[a];l.instanceId=s,l.object=this,t.push(l)}Sa.length=0}}setColorAt(e,t){this.instanceColor===null&&(this.instanceColor=new Xr(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),t.toArray(this.instanceColor.array,e*3)}setMatrixAt(e,t){t.toArray(this.instanceMatrix.array,e*16)}setMorphAt(e,t){const n=t.morphTargetInfluences,r=n.length+1;this.morphTexture===null&&(this.morphTexture=new hf(new Float32Array(r*this.count),r,this.count,Oc,Bn));const s=this.morphTexture.source.data.data;let a=0;for(let c=0;c<n.length;c++)a+=n[c];const o=this.geometry.morphTargetsRelative?1:1-a,l=r*e;s[l]=o,s.set(n,l+1)}updateMorphTargets(){}dispose(){this.dispatchEvent({type:"dispose"}),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null)}}const il=new U,Jm=new U,Qm=new $e;class Yi{constructor(e=new U(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,n,r){return this.normal.set(e,t,n),this.constant=r,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,n){const r=il.subVectors(n,t).cross(Jm.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(r,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t){const n=e.delta(il),r=this.normal.dot(n);if(r===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;const s=-(e.start.dot(this.normal)+this.constant)/r;return s<0||s>1?null:t.copy(e.start).addScaledVector(n,s)}intersectsLine(e){const t=this.distanceToPoint(e.start),n=this.distanceToPoint(e.end);return t<0&&n>0||n<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){const n=t||Qm.getNormalMatrix(e),r=this.coplanarPoint(il).applyMatrix4(e),s=this.normal.applyMatrix3(n).normalize();return this.constant=-r.dot(s),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const Hi=new $n,eg=new Ce(.5,.5),Ma=new U;class Wc{constructor(e=new Yi,t=new Yi,n=new Yi,r=new Yi,s=new Yi,a=new Yi){this.planes=[e,t,n,r,s,a]}set(e,t,n,r,s,a){const o=this.planes;return o[0].copy(e),o[1].copy(t),o[2].copy(n),o[3].copy(r),o[4].copy(s),o[5].copy(a),this}copy(e){const t=this.planes;for(let n=0;n<6;n++)t[n].copy(e.planes[n]);return this}setFromProjectionMatrix(e,t=qn,n=!1){const r=this.planes,s=e.elements,a=s[0],o=s[1],l=s[2],c=s[3],d=s[4],u=s[5],h=s[6],p=s[7],g=s[8],v=s[9],m=s[10],f=s[11],y=s[12],_=s[13],x=s[14],R=s[15];if(r[0].setComponents(c-a,p-d,f-g,R-y).normalize(),r[1].setComponents(c+a,p+d,f+g,R+y).normalize(),r[2].setComponents(c+o,p+u,f+v,R+_).normalize(),r[3].setComponents(c-o,p-u,f-v,R-_).normalize(),n)r[4].setComponents(l,h,m,x).normalize(),r[5].setComponents(c-l,p-h,f-m,R-x).normalize();else if(r[4].setComponents(c-l,p-h,f-m,R-x).normalize(),t===qn)r[5].setComponents(c+l,p+h,f+m,R+x).normalize();else if(t===qa)r[5].setComponents(l,h,m,x).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),Hi.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),Hi.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(Hi)}intersectsSprite(e){Hi.center.set(0,0,0);const t=eg.distanceTo(e.center);return Hi.radius=.7071067811865476+t,Hi.applyMatrix4(e.matrixWorld),this.intersectsSphere(Hi)}intersectsSphere(e){const t=this.planes,n=e.center,r=-e.radius;for(let s=0;s<6;s++)if(t[s].distanceToPoint(n)<r)return!1;return!0}intersectsBox(e){const t=this.planes;for(let n=0;n<6;n++){const r=t[n];if(Ma.x=r.normal.x>0?e.max.x:e.min.x,Ma.y=r.normal.y>0?e.max.y:e.min.y,Ma.z=r.normal.z>0?e.max.z:e.min.z,r.distanceToPoint(Ma)<0)return!1}return!0}containsPoint(e){const t=this.planes;for(let n=0;n<6;n++)if(t[n].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class Xc extends Cn{constructor(e){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new Ie(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}}const ja=new U,$a=new U,nd=new qe,vs=new Vs,Ea=new $n,rl=new U,id=new U;class qc extends Mt{constructor(e=new Lt,t=new Xc){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,n=[0];for(let r=1,s=t.count;r<s;r++)ja.fromBufferAttribute(t,r-1),$a.fromBufferAttribute(t,r),n[r]=n[r-1],n[r]+=ja.distanceTo($a);e.setAttribute("lineDistance",new nt(n,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(e,t){const n=this.geometry,r=this.matrixWorld,s=e.params.Line.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Ea.copy(n.boundingSphere),Ea.applyMatrix4(r),Ea.radius+=s,e.ray.intersectsSphere(Ea)===!1)return;nd.copy(r).invert(),vs.copy(e.ray).applyMatrix4(nd);const o=s/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,c=this.isLineSegments?2:1,d=n.index,h=n.attributes.position;if(d!==null){const p=Math.max(0,a.start),g=Math.min(d.count,a.start+a.count);for(let v=p,m=g-1;v<m;v+=c){const f=d.getX(v),y=d.getX(v+1),_=Ta(this,e,vs,l,f,y,v);_&&t.push(_)}if(this.isLineLoop){const v=d.getX(g-1),m=d.getX(p),f=Ta(this,e,vs,l,v,m,g-1);f&&t.push(f)}}else{const p=Math.max(0,a.start),g=Math.min(h.count,a.start+a.count);for(let v=p,m=g-1;v<m;v+=c){const f=Ta(this,e,vs,l,v,v+1,v);f&&t.push(f)}if(this.isLineLoop){const v=Ta(this,e,vs,l,g-1,p,g-1);v&&t.push(v)}}}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const r=t[n[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,a=r.length;s<a;s++){const o=r[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=s}}}}}function Ta(i,e,t,n,r,s,a){const o=i.geometry.attributes.position;if(ja.fromBufferAttribute(o,r),$a.fromBufferAttribute(o,s),t.distanceSqToSegment(ja,$a,rl,id)>n)return;rl.applyMatrix4(i.matrixWorld);const c=e.ray.origin.distanceTo(rl);if(!(c<e.near||c>e.far))return{distance:c,point:id.clone().applyMatrix4(i.matrixWorld),index:a,face:null,faceIndex:null,barycoord:null,object:i}}const rd=new U,sd=new U;class ff extends qc{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,n=[];for(let r=0,s=t.count;r<s;r+=2)rd.fromBufferAttribute(t,r),sd.fromBufferAttribute(t,r+1),n[r]=r===0?0:n[r-1],n[r+1]=n[r]+rd.distanceTo(sd);e.setAttribute("lineDistance",new nt(n,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class tg extends qc{constructor(e,t){super(e,t),this.isLineLoop=!0,this.type="LineLoop"}}class pf extends Cn{constructor(e){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new Ie(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}const ad=new qe,gc=new Vs,Aa=new $n,wa=new U;class Yc extends Mt{constructor(e=new Lt,t=new pf){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}raycast(e,t){const n=this.geometry,r=this.matrixWorld,s=e.params.Points.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Aa.copy(n.boundingSphere),Aa.applyMatrix4(r),Aa.radius+=s,e.ray.intersectsSphere(Aa)===!1)return;ad.copy(r).invert(),gc.copy(e.ray).applyMatrix4(ad);const o=s/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,c=n.index,u=n.attributes.position;if(c!==null){const h=Math.max(0,a.start),p=Math.min(c.count,a.start+a.count);for(let g=h,v=p;g<v;g++){const m=c.getX(g);wa.fromBufferAttribute(u,m),od(wa,m,l,r,e,t,this)}}else{const h=Math.max(0,a.start),p=Math.min(u.count,a.start+a.count);for(let g=h,v=p;g<v;g++)wa.fromBufferAttribute(u,g),od(wa,g,l,r,e,t,this)}}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const r=t[n[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,a=r.length;s<a;s++){const o=r[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=s}}}}}function od(i,e,t,n,r,s,a){const o=gc.distanceSqToPoint(i);if(o<t){const l=new U;gc.closestPointToPoint(i,l),l.applyMatrix4(n);const c=r.ray.origin.distanceTo(l);if(c<r.near||c>r.far)return;s.push({distance:c,distanceToRay:Math.sqrt(o),point:l,index:e,face:null,faceIndex:null,barycoord:null,object:a})}}class fo extends Ft{constructor(e,t,n,r,s,a,o,l,c){super(e,t,n,r,s,a,o,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}}class mf extends Ft{constructor(e,t,n=Ji,r,s,a,o=en,l=en,c,d=Ls,u=1){if(d!==Ls&&d!==Ds)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const h={width:e,height:t,depth:u};super(h,r,s,a,o,l,d,n,c),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new Vc(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){const t=super.toJSON(e);return this.compareFunction!==null&&(t.compareFunction=this.compareFunction),t}}class gf extends Ft{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}}class jc extends Lt{constructor(e=1,t=1,n=1,r=32,s=1,a=!1,o=0,l=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:t,height:n,radialSegments:r,heightSegments:s,openEnded:a,thetaStart:o,thetaLength:l};const c=this;r=Math.floor(r),s=Math.floor(s);const d=[],u=[],h=[],p=[];let g=0;const v=[],m=n/2;let f=0;y(),a===!1&&(e>0&&_(!0),t>0&&_(!1)),this.setIndex(d),this.setAttribute("position",new nt(u,3)),this.setAttribute("normal",new nt(h,3)),this.setAttribute("uv",new nt(p,2));function y(){const x=new U,R=new U;let M=0;const w=(t-e)/n;for(let A=0;A<=s;A++){const S=[],b=A/s,T=b*(t-e)+e;for(let D=0;D<=r;D++){const k=D/r,z=k*l+o,H=Math.sin(z),L=Math.cos(z);R.x=T*H,R.y=-b*n+m,R.z=T*L,u.push(R.x,R.y,R.z),x.set(H,w,L).normalize(),h.push(x.x,x.y,x.z),p.push(k,1-b),S.push(g++)}v.push(S)}for(let A=0;A<r;A++)for(let S=0;S<s;S++){const b=v[S][A],T=v[S+1][A],D=v[S+1][A+1],k=v[S][A+1];(e>0||S!==0)&&(d.push(b,T,k),M+=3),(t>0||S!==s-1)&&(d.push(T,D,k),M+=3)}c.addGroup(f,M,0),f+=M}function _(x){const R=g,M=new Ce,w=new U;let A=0;const S=x===!0?e:t,b=x===!0?1:-1;for(let D=1;D<=r;D++)u.push(0,m*b,0),h.push(0,b,0),p.push(.5,.5),g++;const T=g;for(let D=0;D<=r;D++){const z=D/r*l+o,H=Math.cos(z),L=Math.sin(z);w.x=S*L,w.y=m*b,w.z=S*H,u.push(w.x,w.y,w.z),h.push(0,b,0),M.x=H*.5+.5,M.y=L*.5*b+.5,p.push(M.x,M.y),g++}for(let D=0;D<r;D++){const k=R+D,z=T+D;x===!0?d.push(z,z+1,k):d.push(z+1,z,k),A+=3}c.addGroup(f,A,x===!0?1:2),f+=A}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new jc(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class yn extends Lt{constructor(e=1,t=1,n=1,r=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:n,heightSegments:r};const s=e/2,a=t/2,o=Math.floor(n),l=Math.floor(r),c=o+1,d=l+1,u=e/o,h=t/l,p=[],g=[],v=[],m=[];for(let f=0;f<d;f++){const y=f*h-a;for(let _=0;_<c;_++){const x=_*u-s;g.push(x,-y,0),v.push(0,0,1),m.push(_/o),m.push(1-f/l)}}for(let f=0;f<l;f++)for(let y=0;y<o;y++){const _=y+c*f,x=y+c*(f+1),R=y+1+c*(f+1),M=y+1+c*f;p.push(_,x,M),p.push(x,R,M)}this.setIndex(p),this.setAttribute("position",new nt(g,3)),this.setAttribute("normal",new nt(v,3)),this.setAttribute("uv",new nt(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new yn(e.width,e.height,e.widthSegments,e.heightSegments)}}class po extends Lt{constructor(e=.5,t=1,n=32,r=1,s=0,a=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:e,outerRadius:t,thetaSegments:n,phiSegments:r,thetaStart:s,thetaLength:a},n=Math.max(3,n),r=Math.max(1,r);const o=[],l=[],c=[],d=[];let u=e;const h=(t-e)/r,p=new U,g=new Ce;for(let v=0;v<=r;v++){for(let m=0;m<=n;m++){const f=s+m/n*a;p.x=u*Math.cos(f),p.y=u*Math.sin(f),l.push(p.x,p.y,p.z),c.push(0,0,1),g.x=(p.x/t+1)/2,g.y=(p.y/t+1)/2,d.push(g.x,g.y)}u+=h}for(let v=0;v<r;v++){const m=v*(n+1);for(let f=0;f<n;f++){const y=f+m,_=y,x=y+n+1,R=y+n+2,M=y+1;o.push(_,x,M),o.push(x,R,M)}}this.setIndex(o),this.setAttribute("position",new nt(l,3)),this.setAttribute("normal",new nt(c,3)),this.setAttribute("uv",new nt(d,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new po(e.innerRadius,e.outerRadius,e.thetaSegments,e.phiSegments,e.thetaStart,e.thetaLength)}}class $c extends Lt{constructor(e=1,t=32,n=16,r=0,s=Math.PI*2,a=0,o=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:t,heightSegments:n,phiStart:r,phiLength:s,thetaStart:a,thetaLength:o},t=Math.max(3,Math.floor(t)),n=Math.max(2,Math.floor(n));const l=Math.min(a+o,Math.PI);let c=0;const d=[],u=new U,h=new U,p=[],g=[],v=[],m=[];for(let f=0;f<=n;f++){const y=[],_=f/n;let x=0;f===0&&a===0?x=.5/t:f===n&&l===Math.PI&&(x=-.5/t);for(let R=0;R<=t;R++){const M=R/t;u.x=-e*Math.cos(r+M*s)*Math.sin(a+_*o),u.y=e*Math.cos(a+_*o),u.z=e*Math.sin(r+M*s)*Math.sin(a+_*o),g.push(u.x,u.y,u.z),h.copy(u).normalize(),v.push(h.x,h.y,h.z),m.push(M+x,1-_),y.push(c++)}d.push(y)}for(let f=0;f<n;f++)for(let y=0;y<t;y++){const _=d[f][y+1],x=d[f][y],R=d[f+1][y],M=d[f+1][y+1];(f!==0||a>0)&&p.push(_,x,M),(f!==n-1||l<Math.PI)&&p.push(x,R,M)}this.setIndex(p),this.setAttribute("position",new nt(g,3)),this.setAttribute("normal",new nt(v,3)),this.setAttribute("uv",new nt(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new $c(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}}class Kc extends Cn{constructor(e){super(),this.isMeshStandardMaterial=!0,this.type="MeshStandardMaterial",this.defines={STANDARD:""},this.color=new Ie(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Ie(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=kc,this.normalScale=new Ce(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new xn,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class Kn extends Kc{constructor(e){super(),this.isMeshPhysicalMaterial=!0,this.defines={STANDARD:"",PHYSICAL:""},this.type="MeshPhysicalMaterial",this.anisotropyRotation=0,this.anisotropyMap=null,this.clearcoatMap=null,this.clearcoatRoughness=0,this.clearcoatRoughnessMap=null,this.clearcoatNormalScale=new Ce(1,1),this.clearcoatNormalMap=null,this.ior=1.5,Object.defineProperty(this,"reflectivity",{get:function(){return Je(2.5*(this.ior-1)/(this.ior+1),0,1)},set:function(t){this.ior=(1+.4*t)/(1-.4*t)}}),this.iridescenceMap=null,this.iridescenceIOR=1.3,this.iridescenceThicknessRange=[100,400],this.iridescenceThicknessMap=null,this.sheenColor=new Ie(0),this.sheenColorMap=null,this.sheenRoughness=1,this.sheenRoughnessMap=null,this.transmissionMap=null,this.thickness=0,this.thicknessMap=null,this.attenuationDistance=1/0,this.attenuationColor=new Ie(1,1,1),this.specularIntensity=1,this.specularIntensityMap=null,this.specularColor=new Ie(1,1,1),this.specularColorMap=null,this._anisotropy=0,this._clearcoat=0,this._dispersion=0,this._iridescence=0,this._sheen=0,this._transmission=0,this.setValues(e)}get anisotropy(){return this._anisotropy}set anisotropy(e){this._anisotropy>0!=e>0&&this.version++,this._anisotropy=e}get clearcoat(){return this._clearcoat}set clearcoat(e){this._clearcoat>0!=e>0&&this.version++,this._clearcoat=e}get iridescence(){return this._iridescence}set iridescence(e){this._iridescence>0!=e>0&&this.version++,this._iridescence=e}get dispersion(){return this._dispersion}set dispersion(e){this._dispersion>0!=e>0&&this.version++,this._dispersion=e}get sheen(){return this._sheen}set sheen(e){this._sheen>0!=e>0&&this.version++,this._sheen=e}get transmission(){return this._transmission}set transmission(e){this._transmission>0!=e>0&&this.version++,this._transmission=e}copy(e){return super.copy(e),this.defines={STANDARD:"",PHYSICAL:""},this.anisotropy=e.anisotropy,this.anisotropyRotation=e.anisotropyRotation,this.anisotropyMap=e.anisotropyMap,this.clearcoat=e.clearcoat,this.clearcoatMap=e.clearcoatMap,this.clearcoatRoughness=e.clearcoatRoughness,this.clearcoatRoughnessMap=e.clearcoatRoughnessMap,this.clearcoatNormalMap=e.clearcoatNormalMap,this.clearcoatNormalScale.copy(e.clearcoatNormalScale),this.dispersion=e.dispersion,this.ior=e.ior,this.iridescence=e.iridescence,this.iridescenceMap=e.iridescenceMap,this.iridescenceIOR=e.iridescenceIOR,this.iridescenceThicknessRange=[...e.iridescenceThicknessRange],this.iridescenceThicknessMap=e.iridescenceThicknessMap,this.sheen=e.sheen,this.sheenColor.copy(e.sheenColor),this.sheenColorMap=e.sheenColorMap,this.sheenRoughness=e.sheenRoughness,this.sheenRoughnessMap=e.sheenRoughnessMap,this.transmission=e.transmission,this.transmissionMap=e.transmissionMap,this.thickness=e.thickness,this.thicknessMap=e.thicknessMap,this.attenuationDistance=e.attenuationDistance,this.attenuationColor.copy(e.attenuationColor),this.specularIntensity=e.specularIntensity,this.specularIntensityMap=e.specularIntensityMap,this.specularColor.copy(e.specularColor),this.specularColorMap=e.specularColorMap,this}}class ng extends Cn{constructor(e){super(),this.isMeshLambertMaterial=!0,this.type="MeshLambertMaterial",this.color=new Ie(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Ie(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=kc,this.normalScale=new Ce(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new xn,this.combine=Pc,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class ig extends Cn{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=Zp,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class rg extends Cn{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}function Ra(i,e){return!i||i.constructor===e?i:typeof e.BYTES_PER_ELEMENT=="number"?new e(i):Array.prototype.slice.call(i)}function sg(i){return ArrayBuffer.isView(i)&&!(i instanceof DataView)}function ag(i){function e(r,s){return i[r]-i[s]}const t=i.length,n=new Array(t);for(let r=0;r!==t;++r)n[r]=r;return n.sort(e),n}function ld(i,e,t){const n=i.length,r=new i.constructor(n);for(let s=0,a=0;a!==n;++s){const o=t[s]*e;for(let l=0;l!==e;++l)r[a++]=i[o+l]}return r}function vf(i,e,t,n){let r=1,s=i[0];for(;s!==void 0&&s[n]===void 0;)s=i[r++];if(s===void 0)return;let a=s[n];if(a!==void 0)if(Array.isArray(a))do a=s[n],a!==void 0&&(e.push(s.time),t.push(...a)),s=i[r++];while(s!==void 0);else if(a.toArray!==void 0)do a=s[n],a!==void 0&&(e.push(s.time),a.toArray(t,t.length)),s=i[r++];while(s!==void 0);else do a=s[n],a!==void 0&&(e.push(s.time),t.push(a)),s=i[r++];while(s!==void 0)}class Xs{constructor(e,t,n,r){this.parameterPositions=e,this._cachedIndex=0,this.resultBuffer=r!==void 0?r:new t.constructor(n),this.sampleValues=t,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(e){const t=this.parameterPositions;let n=this._cachedIndex,r=t[n],s=t[n-1];n:{e:{let a;t:{i:if(!(e<r)){for(let o=n+2;;){if(r===void 0){if(e<s)break i;return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===o)break;if(s=r,r=t[++n],e<r)break e}a=t.length;break t}if(!(e>=s)){const o=t[1];e<o&&(n=2,s=o);for(let l=n-2;;){if(s===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===l)break;if(r=s,s=t[--n-1],e>=s)break e}a=n,n=0;break t}break n}for(;n<a;){const o=n+a>>>1;e<t[o]?a=o:n=o+1}if(r=t[n],s=t[n-1],s===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(r===void 0)return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,s,r)}return this.interpolate_(n,s,e,r)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(e){const t=this.resultBuffer,n=this.sampleValues,r=this.valueSize,s=e*r;for(let a=0;a!==r;++a)t[a]=n[s+a];return t}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}}class og extends Xs{constructor(e,t,n,r){super(e,t,n,r),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:Mu,endingEnd:Mu}}intervalChanged_(e,t,n){const r=this.parameterPositions;let s=e-2,a=e+1,o=r[s],l=r[a];if(o===void 0)switch(this.getSettings_().endingStart){case Eu:s=e,o=2*t-n;break;case Tu:s=r.length-2,o=t+r[s]-r[s+1];break;default:s=e,o=n}if(l===void 0)switch(this.getSettings_().endingEnd){case Eu:a=e,l=2*n-t;break;case Tu:a=1,l=n+r[1]-r[0];break;default:a=e-1,l=t}const c=(n-t)*.5,d=this.valueSize;this._weightPrev=c/(t-o),this._weightNext=c/(l-n),this._offsetPrev=s*d,this._offsetNext=a*d}interpolate_(e,t,n,r){const s=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=e*o,c=l-o,d=this._offsetPrev,u=this._offsetNext,h=this._weightPrev,p=this._weightNext,g=(n-t)/(r-t),v=g*g,m=v*g,f=-h*m+2*h*v-h*g,y=(1+h)*m+(-1.5-2*h)*v+(-.5+h)*g+1,_=(-1-p)*m+(1.5+p)*v+.5*g,x=p*m-p*v;for(let R=0;R!==o;++R)s[R]=f*a[d+R]+y*a[c+R]+_*a[l+R]+x*a[u+R];return s}}class lg extends Xs{constructor(e,t,n,r){super(e,t,n,r)}interpolate_(e,t,n,r){const s=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=e*o,c=l-o,d=(n-t)/(r-t),u=1-d;for(let h=0;h!==o;++h)s[h]=a[c+h]*u+a[l+h]*d;return s}}class cg extends Xs{constructor(e,t,n,r){super(e,t,n,r)}interpolate_(e){return this.copySampleValue_(e-1)}}class Vn{constructor(e,t,n,r){if(e===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(t===void 0||t.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+e);this.name=e,this.times=Ra(t,this.TimeBufferType),this.values=Ra(n,this.ValueBufferType),this.setInterpolation(r||this.DefaultInterpolation)}static toJSON(e){const t=e.constructor;let n;if(t.toJSON!==this.toJSON)n=t.toJSON(e);else{n={name:e.name,times:Ra(e.times,Array),values:Ra(e.values,Array)};const r=e.getInterpolation();r!==e.DefaultInterpolation&&(n.interpolation=r)}return n.type=e.ValueTypeName,n}InterpolantFactoryMethodDiscrete(e){return new cg(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodLinear(e){return new lg(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodSmooth(e){return new og(this.times,this.values,this.getValueSize(),e)}setInterpolation(e){let t;switch(e){case Ns:t=this.InterpolantFactoryMethodDiscrete;break;case Os:t=this.InterpolantFactoryMethodLinear;break;case Lo:t=this.InterpolantFactoryMethodSmooth;break}if(t===void 0){const n="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(e!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(n);return console.warn("THREE.KeyframeTrack:",n),this}return this.createInterpolant=t,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return Ns;case this.InterpolantFactoryMethodLinear:return Os;case this.InterpolantFactoryMethodSmooth:return Lo}}getValueSize(){return this.values.length/this.times.length}shift(e){if(e!==0){const t=this.times;for(let n=0,r=t.length;n!==r;++n)t[n]+=e}return this}scale(e){if(e!==1){const t=this.times;for(let n=0,r=t.length;n!==r;++n)t[n]*=e}return this}trim(e,t){const n=this.times,r=n.length;let s=0,a=r-1;for(;s!==r&&n[s]<e;)++s;for(;a!==-1&&n[a]>t;)--a;if(++a,s!==0||a!==r){s>=a&&(a=Math.max(a,1),s=a-1);const o=this.getValueSize();this.times=n.slice(s,a),this.values=this.values.slice(s*o,a*o)}return this}validate(){let e=!0;const t=this.getValueSize();t-Math.floor(t)!==0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),e=!1);const n=this.times,r=this.values,s=n.length;s===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),e=!1);let a=null;for(let o=0;o!==s;o++){const l=n[o];if(typeof l=="number"&&isNaN(l)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,o,l),e=!1;break}if(a!==null&&a>l){console.error("THREE.KeyframeTrack: Out of order keys.",this,o,l,a),e=!1;break}a=l}if(r!==void 0&&sg(r))for(let o=0,l=r.length;o!==l;++o){const c=r[o];if(isNaN(c)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,o,c),e=!1;break}}return e}optimize(){const e=this.times.slice(),t=this.values.slice(),n=this.getValueSize(),r=this.getInterpolation()===Lo,s=e.length-1;let a=1;for(let o=1;o<s;++o){let l=!1;const c=e[o],d=e[o+1];if(c!==d&&(o!==1||c!==e[0]))if(r)l=!0;else{const u=o*n,h=u-n,p=u+n;for(let g=0;g!==n;++g){const v=t[u+g];if(v!==t[h+g]||v!==t[p+g]){l=!0;break}}}if(l){if(o!==a){e[a]=e[o];const u=o*n,h=a*n;for(let p=0;p!==n;++p)t[h+p]=t[u+p]}++a}}if(s>0){e[a]=e[s];for(let o=s*n,l=a*n,c=0;c!==n;++c)t[l+c]=t[o+c];++a}return a!==e.length?(this.times=e.slice(0,a),this.values=t.slice(0,a*n)):(this.times=e,this.values=t),this}clone(){const e=this.times.slice(),t=this.values.slice(),n=this.constructor,r=new n(this.name,e,t);return r.createInterpolant=this.createInterpolant,r}}Vn.prototype.ValueTypeName="";Vn.prototype.TimeBufferType=Float32Array;Vn.prototype.ValueBufferType=Float32Array;Vn.prototype.DefaultInterpolation=Os;class ts extends Vn{constructor(e,t,n){super(e,t,n)}}ts.prototype.ValueTypeName="bool";ts.prototype.ValueBufferType=Array;ts.prototype.DefaultInterpolation=Ns;ts.prototype.InterpolantFactoryMethodLinear=void 0;ts.prototype.InterpolantFactoryMethodSmooth=void 0;class _f extends Vn{constructor(e,t,n,r){super(e,t,n,r)}}_f.prototype.ValueTypeName="color";class qr extends Vn{constructor(e,t,n,r){super(e,t,n,r)}}qr.prototype.ValueTypeName="number";class ug extends Xs{constructor(e,t,n,r){super(e,t,n,r)}interpolate_(e,t,n,r){const s=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=(n-t)/(r-t);let c=e*o;for(let d=c+o;c!==d;c+=4)dt.slerpFlat(s,0,a,c-o,a,c,l);return s}}class Yr extends Vn{constructor(e,t,n,r){super(e,t,n,r)}InterpolantFactoryMethodLinear(e){return new ug(this.times,this.values,this.getValueSize(),e)}}Yr.prototype.ValueTypeName="quaternion";Yr.prototype.InterpolantFactoryMethodSmooth=void 0;class ns extends Vn{constructor(e,t,n){super(e,t,n)}}ns.prototype.ValueTypeName="string";ns.prototype.ValueBufferType=Array;ns.prototype.DefaultInterpolation=Ns;ns.prototype.InterpolantFactoryMethodLinear=void 0;ns.prototype.InterpolantFactoryMethodSmooth=void 0;class jr extends Vn{constructor(e,t,n,r){super(e,t,n,r)}}jr.prototype.ValueTypeName="vector";class dg{constructor(e="",t=-1,n=[],r=$p){this.name=e,this.tracks=n,this.duration=t,this.blendMode=r,this.uuid=kn(),this.userData={},this.duration<0&&this.resetDuration()}static parse(e){const t=[],n=e.tracks,r=1/(e.fps||1);for(let a=0,o=n.length;a!==o;++a)t.push(fg(n[a]).scale(r));const s=new this(e.name,e.duration,t,e.blendMode);return s.uuid=e.uuid,s.userData=JSON.parse(e.userData||"{}"),s}static toJSON(e){const t=[],n=e.tracks,r={name:e.name,duration:e.duration,tracks:t,uuid:e.uuid,blendMode:e.blendMode,userData:JSON.stringify(e.userData)};for(let s=0,a=n.length;s!==a;++s)t.push(Vn.toJSON(n[s]));return r}static CreateFromMorphTargetSequence(e,t,n,r){const s=t.length,a=[];for(let o=0;o<s;o++){let l=[],c=[];l.push((o+s-1)%s,o,(o+1)%s),c.push(0,1,0);const d=ag(l);l=ld(l,1,d),c=ld(c,1,d),!r&&l[0]===0&&(l.push(s),c.push(c[0])),a.push(new qr(".morphTargetInfluences["+t[o].name+"]",l,c).scale(1/n))}return new this(e,-1,a)}static findByName(e,t){let n=e;if(!Array.isArray(e)){const r=e;n=r.geometry&&r.geometry.animations||r.animations}for(let r=0;r<n.length;r++)if(n[r].name===t)return n[r];return null}static CreateClipsFromMorphTargetSequences(e,t,n){const r={},s=/^([\w-]*?)([\d]+)$/;for(let o=0,l=e.length;o<l;o++){const c=e[o],d=c.name.match(s);if(d&&d.length>1){const u=d[1];let h=r[u];h||(r[u]=h=[]),h.push(c)}}const a=[];for(const o in r)a.push(this.CreateFromMorphTargetSequence(o,r[o],t,n));return a}static parseAnimation(e,t){if(console.warn("THREE.AnimationClip: parseAnimation() is deprecated and will be removed with r185"),!e)return console.error("THREE.AnimationClip: No animation in JSONLoader data."),null;const n=function(u,h,p,g,v){if(p.length!==0){const m=[],f=[];vf(p,m,f,g),m.length!==0&&v.push(new u(h,m,f))}},r=[],s=e.name||"default",a=e.fps||30,o=e.blendMode;let l=e.length||-1;const c=e.hierarchy||[];for(let u=0;u<c.length;u++){const h=c[u].keys;if(!(!h||h.length===0))if(h[0].morphTargets){const p={};let g;for(g=0;g<h.length;g++)if(h[g].morphTargets)for(let v=0;v<h[g].morphTargets.length;v++)p[h[g].morphTargets[v]]=-1;for(const v in p){const m=[],f=[];for(let y=0;y!==h[g].morphTargets.length;++y){const _=h[g];m.push(_.time),f.push(_.morphTarget===v?1:0)}r.push(new qr(".morphTargetInfluence["+v+"]",m,f))}l=p.length*a}else{const p=".bones["+t[u].name+"]";n(jr,p+".position",h,"pos",r),n(Yr,p+".quaternion",h,"rot",r),n(jr,p+".scale",h,"scl",r)}}return r.length===0?null:new this(s,l,r,o)}resetDuration(){const e=this.tracks;let t=0;for(let n=0,r=e.length;n!==r;++n){const s=this.tracks[n];t=Math.max(t,s.times[s.times.length-1])}return this.duration=t,this}trim(){for(let e=0;e<this.tracks.length;e++)this.tracks[e].trim(0,this.duration);return this}validate(){let e=!0;for(let t=0;t<this.tracks.length;t++)e=e&&this.tracks[t].validate();return e}optimize(){for(let e=0;e<this.tracks.length;e++)this.tracks[e].optimize();return this}clone(){const e=[];for(let n=0;n<this.tracks.length;n++)e.push(this.tracks[n].clone());const t=new this.constructor(this.name,this.duration,e,this.blendMode);return t.userData=JSON.parse(JSON.stringify(this.userData)),t}toJSON(){return this.constructor.toJSON(this)}}function hg(i){switch(i.toLowerCase()){case"scalar":case"double":case"float":case"number":case"integer":return qr;case"vector":case"vector2":case"vector3":case"vector4":return jr;case"color":return _f;case"quaternion":return Yr;case"bool":case"boolean":return ts;case"string":return ns}throw new Error("THREE.KeyframeTrack: Unsupported typeName: "+i)}function fg(i){if(i.type===void 0)throw new Error("THREE.KeyframeTrack: track type undefined, can not parse");const e=hg(i.type);if(i.times===void 0){const t=[],n=[];vf(i.keys,t,n,"value"),i.times=t,i.values=n}return e.parse!==void 0?e.parse(i):new e(i.name,i.times,i.values,i.interpolation)}const ui={enabled:!1,files:{},add:function(i,e){this.enabled!==!1&&(this.files[i]=e)},get:function(i){if(this.enabled!==!1)return this.files[i]},remove:function(i){delete this.files[i]},clear:function(){this.files={}}};class pg{constructor(e,t,n){const r=this;let s=!1,a=0,o=0,l;const c=[];this.onStart=void 0,this.onLoad=e,this.onProgress=t,this.onError=n,this.abortController=new AbortController,this.itemStart=function(d){o++,s===!1&&r.onStart!==void 0&&r.onStart(d,a,o),s=!0},this.itemEnd=function(d){a++,r.onProgress!==void 0&&r.onProgress(d,a,o),a===o&&(s=!1,r.onLoad!==void 0&&r.onLoad())},this.itemError=function(d){r.onError!==void 0&&r.onError(d)},this.resolveURL=function(d){return l?l(d):d},this.setURLModifier=function(d){return l=d,this},this.addHandler=function(d,u){return c.push(d,u),this},this.removeHandler=function(d){const u=c.indexOf(d);return u!==-1&&c.splice(u,2),this},this.getHandler=function(d){for(let u=0,h=c.length;u<h;u+=2){const p=c[u],g=c[u+1];if(p.global&&(p.lastIndex=0),p.test(d))return g}return null},this.abort=function(){return this.abortController.abort(),this.abortController=new AbortController,this}}}const mg=new pg;class is{constructor(e){this.manager=e!==void 0?e:mg,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(e,t){const n=this;return new Promise(function(r,s){n.load(e,r,t,s)})}parse(){}setCrossOrigin(e){return this.crossOrigin=e,this}setWithCredentials(e){return this.withCredentials=e,this}setPath(e){return this.path=e,this}setResourcePath(e){return this.resourcePath=e,this}setRequestHeader(e){return this.requestHeader=e,this}abort(){return this}}is.DEFAULT_MATERIAL_NAME="__DEFAULT";const ii={};class gg extends Error{constructor(e,t){super(e),this.response=t}}class xf extends is{constructor(e){super(e),this.mimeType="",this.responseType="",this._abortController=new AbortController}load(e,t,n,r){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);const s=ui.get(`file:${e}`);if(s!==void 0)return this.manager.itemStart(e),setTimeout(()=>{t&&t(s),this.manager.itemEnd(e)},0),s;if(ii[e]!==void 0){ii[e].push({onLoad:t,onProgress:n,onError:r});return}ii[e]=[],ii[e].push({onLoad:t,onProgress:n,onError:r});const a=new Request(e,{headers:new Headers(this.requestHeader),credentials:this.withCredentials?"include":"same-origin",signal:typeof AbortSignal.any=="function"?AbortSignal.any([this._abortController.signal,this.manager.abortController.signal]):this._abortController.signal}),o=this.mimeType,l=this.responseType;fetch(a).then(c=>{if(c.status===200||c.status===0){if(c.status===0&&console.warn("THREE.FileLoader: HTTP Status 0 received."),typeof ReadableStream>"u"||c.body===void 0||c.body.getReader===void 0)return c;const d=ii[e],u=c.body.getReader(),h=c.headers.get("X-File-Size")||c.headers.get("Content-Length"),p=h?parseInt(h):0,g=p!==0;let v=0;const m=new ReadableStream({start(f){y();function y(){u.read().then(({done:_,value:x})=>{if(_)f.close();else{v+=x.byteLength;const R=new ProgressEvent("progress",{lengthComputable:g,loaded:v,total:p});for(let M=0,w=d.length;M<w;M++){const A=d[M];A.onProgress&&A.onProgress(R)}f.enqueue(x),y()}},_=>{f.error(_)})}}});return new Response(m)}else throw new gg(`fetch for "${c.url}" responded with ${c.status}: ${c.statusText}`,c)}).then(c=>{switch(l){case"arraybuffer":return c.arrayBuffer();case"blob":return c.blob();case"document":return c.text().then(d=>new DOMParser().parseFromString(d,o));case"json":return c.json();default:if(o==="")return c.text();{const u=/charset="?([^;"\s]*)"?/i.exec(o),h=u&&u[1]?u[1].toLowerCase():void 0,p=new TextDecoder(h);return c.arrayBuffer().then(g=>p.decode(g))}}}).then(c=>{ui.add(`file:${e}`,c);const d=ii[e];delete ii[e];for(let u=0,h=d.length;u<h;u++){const p=d[u];p.onLoad&&p.onLoad(c)}}).catch(c=>{const d=ii[e];if(d===void 0)throw this.manager.itemError(e),c;delete ii[e];for(let u=0,h=d.length;u<h;u++){const p=d[u];p.onError&&p.onError(c)}this.manager.itemError(e)}).finally(()=>{this.manager.itemEnd(e)}),this.manager.itemStart(e)}setResponseType(e){return this.responseType=e,this}setMimeType(e){return this.mimeType=e,this}abort(){return this._abortController.abort(),this._abortController=new AbortController,this}}const Sr=new WeakMap;class vg extends is{constructor(e){super(e)}load(e,t,n,r){this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);const s=this,a=ui.get(`image:${e}`);if(a!==void 0){if(a.complete===!0)s.manager.itemStart(e),setTimeout(function(){t&&t(a),s.manager.itemEnd(e)},0);else{let u=Sr.get(a);u===void 0&&(u=[],Sr.set(a,u)),u.push({onLoad:t,onError:r})}return a}const o=Us("img");function l(){d(),t&&t(this);const u=Sr.get(this)||[];for(let h=0;h<u.length;h++){const p=u[h];p.onLoad&&p.onLoad(this)}Sr.delete(this),s.manager.itemEnd(e)}function c(u){d(),r&&r(u),ui.remove(`image:${e}`);const h=Sr.get(this)||[];for(let p=0;p<h.length;p++){const g=h[p];g.onError&&g.onError(u)}Sr.delete(this),s.manager.itemError(e),s.manager.itemEnd(e)}function d(){o.removeEventListener("load",l,!1),o.removeEventListener("error",c,!1)}return o.addEventListener("load",l,!1),o.addEventListener("error",c,!1),e.slice(0,5)!=="data:"&&this.crossOrigin!==void 0&&(o.crossOrigin=this.crossOrigin),ui.add(`image:${e}`,o),s.manager.itemStart(e),o.src=e,o}}class rs extends is{constructor(e){super(e)}load(e,t,n,r){const s=new Ft,a=new vg(this.manager);return a.setCrossOrigin(this.crossOrigin),a.setPath(this.path),a.load(e,function(o){s.image=o,s.needsUpdate=!0,t!==void 0&&t(s)},n,r),s}}class mo extends Mt{constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new Ie(e),this.intensity=t}dispose(){}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){const t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,this.groundColor!==void 0&&(t.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(t.object.distance=this.distance),this.angle!==void 0&&(t.object.angle=this.angle),this.decay!==void 0&&(t.object.decay=this.decay),this.penumbra!==void 0&&(t.object.penumbra=this.penumbra),this.shadow!==void 0&&(t.object.shadow=this.shadow.toJSON()),this.target!==void 0&&(t.object.target=this.target.uuid),t}}class _g extends mo{constructor(e,t,n){super(e,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(Mt.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Ie(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}}const sl=new qe,cd=new U,ud=new U;class Zc{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new Ce(512,512),this.mapType=Yn,this.map=null,this.mapPass=null,this.matrix=new qe,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Wc,this._frameExtents=new Ce(1,1),this._viewportCount=1,this._viewports=[new rt(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){const t=this.camera,n=this.matrix;cd.setFromMatrixPosition(e.matrixWorld),t.position.copy(cd),ud.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(ud),t.updateMatrixWorld(),sl.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),this._frustum.setFromProjectionMatrix(sl,t.coordinateSystem,t.reversedDepth),t.reversedDepth?n.set(.5,0,0,.5,0,.5,0,.5,0,0,1,0,0,0,0,1):n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(sl)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.autoUpdate=e.autoUpdate,this.needsUpdate=e.needsUpdate,this.normalBias=e.normalBias,this.blurSamples=e.blurSamples,this.mapSize.copy(e.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){const e={};return this.intensity!==1&&(e.intensity=this.intensity),this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}}class xg extends Zc{constructor(){super(new Zt(50,1,.5,500)),this.isSpotLightShadow=!0,this.focus=1,this.aspect=1}updateMatrices(e){const t=this.camera,n=Gr*2*e.angle*this.focus,r=this.mapSize.width/this.mapSize.height*this.aspect,s=e.distance||t.far;(n!==t.fov||r!==t.aspect||s!==t.far)&&(t.fov=n,t.aspect=r,t.far=s,t.updateProjectionMatrix()),super.updateMatrices(e)}copy(e){return super.copy(e),this.focus=e.focus,this}}class yg extends mo{constructor(e,t,n=0,r=Math.PI/3,s=0,a=2){super(e,t),this.isSpotLight=!0,this.type="SpotLight",this.position.copy(Mt.DEFAULT_UP),this.updateMatrix(),this.target=new Mt,this.distance=n,this.angle=r,this.penumbra=s,this.decay=a,this.map=null,this.shadow=new xg}get power(){return this.intensity*Math.PI}set power(e){this.intensity=e/Math.PI}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.angle=e.angle,this.penumbra=e.penumbra,this.decay=e.decay,this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}}const dd=new qe,_s=new U,al=new U;class bg extends Zc{constructor(){super(new Zt(90,1,.5,500)),this.isPointLightShadow=!0,this._frameExtents=new Ce(4,2),this._viewportCount=6,this._viewports=[new rt(2,1,1,1),new rt(0,1,1,1),new rt(3,1,1,1),new rt(1,1,1,1),new rt(3,0,1,1),new rt(1,0,1,1)],this._cubeDirections=[new U(1,0,0),new U(-1,0,0),new U(0,0,1),new U(0,0,-1),new U(0,1,0),new U(0,-1,0)],this._cubeUps=[new U(0,1,0),new U(0,1,0),new U(0,1,0),new U(0,1,0),new U(0,0,1),new U(0,0,-1)]}updateMatrices(e,t=0){const n=this.camera,r=this.matrix,s=e.distance||n.far;s!==n.far&&(n.far=s,n.updateProjectionMatrix()),_s.setFromMatrixPosition(e.matrixWorld),n.position.copy(_s),al.copy(n.position),al.add(this._cubeDirections[t]),n.up.copy(this._cubeUps[t]),n.lookAt(al),n.updateMatrixWorld(),r.makeTranslation(-_s.x,-_s.y,-_s.z),dd.multiplyMatrices(n.projectionMatrix,n.matrixWorldInverse),this._frustum.setFromProjectionMatrix(dd,n.coordinateSystem,n.reversedDepth)}}class Sg extends mo{constructor(e,t,n=0,r=2){super(e,t),this.isPointLight=!0,this.type="PointLight",this.distance=n,this.decay=r,this.shadow=new bg}get power(){return this.intensity*4*Math.PI}set power(e){this.intensity=e/(4*Math.PI)}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.decay=e.decay,this.shadow=e.shadow.clone(),this}}class qs extends of{constructor(e=-1,t=1,n=1,r=-1,s=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=n,this.bottom=r,this.near=s,this.far=a,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,n,r,s,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=r,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,r=(this.top+this.bottom)/2;let s=n-e,a=n+e,o=r+t,l=r-t;if(this.view!==null&&this.view.enabled){const c=(this.right-this.left)/this.view.fullWidth/this.zoom,d=(this.top-this.bottom)/this.view.fullHeight/this.zoom;s+=c*this.view.offsetX,a=s+c*this.view.width,o-=d*this.view.offsetY,l=o-d*this.view.height}this.projectionMatrix.makeOrthographic(s,a,o,l,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}}class Mg extends Zc{constructor(){super(new qs(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class yf extends mo{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(Mt.DEFAULT_UP),this.updateMatrix(),this.target=new Mt,this.shadow=new Mg}dispose(){this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}}class Rs{static extractUrlBase(e){const t=e.lastIndexOf("/");return t===-1?"./":e.slice(0,t+1)}static resolveURL(e,t){return typeof e!="string"||e===""?"":(/^https?:\/\//i.test(t)&&/^\//.test(e)&&(t=t.replace(/(^https?:\/\/[^\/]+).*/i,"$1")),/^(https?:)?\/\//i.test(e)||/^data:.*,.*$/i.test(e)||/^blob:.*$/i.test(e)?e:t+e)}}class Eg extends Lt{constructor(){super(),this.isInstancedBufferGeometry=!0,this.type="InstancedBufferGeometry",this.instanceCount=1/0}copy(e){return super.copy(e),this.instanceCount=e.instanceCount,this}toJSON(){const e=super.toJSON();return e.instanceCount=this.instanceCount,e.isInstancedBufferGeometry=!0,e}}const ol=new WeakMap;class Tg extends is{constructor(e){super(e),this.isImageBitmapLoader=!0,typeof createImageBitmap>"u"&&console.warn("THREE.ImageBitmapLoader: createImageBitmap() not supported."),typeof fetch>"u"&&console.warn("THREE.ImageBitmapLoader: fetch() not supported."),this.options={premultiplyAlpha:"none"},this._abortController=new AbortController}setOptions(e){return this.options=e,this}load(e,t,n,r){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);const s=this,a=ui.get(`image-bitmap:${e}`);if(a!==void 0){if(s.manager.itemStart(e),a.then){a.then(c=>{if(ol.has(a)===!0)r&&r(ol.get(a)),s.manager.itemError(e),s.manager.itemEnd(e);else return t&&t(c),s.manager.itemEnd(e),c});return}return setTimeout(function(){t&&t(a),s.manager.itemEnd(e)},0),a}const o={};o.credentials=this.crossOrigin==="anonymous"?"same-origin":"include",o.headers=this.requestHeader,o.signal=typeof AbortSignal.any=="function"?AbortSignal.any([this._abortController.signal,this.manager.abortController.signal]):this._abortController.signal;const l=fetch(e,o).then(function(c){return c.blob()}).then(function(c){return createImageBitmap(c,Object.assign(s.options,{colorSpaceConversion:"none"}))}).then(function(c){return ui.add(`image-bitmap:${e}`,c),t&&t(c),s.manager.itemEnd(e),c}).catch(function(c){r&&r(c),ol.set(l,c),ui.remove(`image-bitmap:${e}`),s.manager.itemError(e),s.manager.itemEnd(e)});ui.add(`image-bitmap:${e}`,l),s.manager.itemStart(e)}abort(){return this._abortController.abort(),this._abortController=new AbortController,this}}class Ag extends Zt{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e}}class wg{constructor(e=!0){this.autoStart=e,this.startTime=0,this.oldTime=0,this.elapsedTime=0,this.running=!1}start(){this.startTime=performance.now(),this.oldTime=this.startTime,this.elapsedTime=0,this.running=!0}stop(){this.getElapsedTime(),this.running=!1,this.autoStart=!1}getElapsedTime(){return this.getDelta(),this.elapsedTime}getDelta(){let e=0;if(this.autoStart&&!this.running)return this.start(),0;if(this.running){const t=performance.now();e=(t-this.oldTime)/1e3,this.oldTime=t,this.elapsedTime+=e}return e}}const Jc="\\[\\]\\.:\\/",Rg=new RegExp("["+Jc+"]","g"),Qc="[^"+Jc+"]",Cg="[^"+Jc.replace("\\.","")+"]",Ig=/((?:WC+[\/:])*)/.source.replace("WC",Qc),Pg=/(WCOD+)?/.source.replace("WCOD",Cg),Lg=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",Qc),Dg=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",Qc),Ng=new RegExp("^"+Ig+Pg+Lg+Dg+"$"),Og=["material","materials","bones","map"];class Ug{constructor(e,t,n){const r=n||lt.parseTrackName(t);this._targetGroup=e,this._bindings=e.subscribe_(t,r)}getValue(e,t){this.bind();const n=this._targetGroup.nCachedObjects_,r=this._bindings[n];r!==void 0&&r.getValue(e,t)}setValue(e,t){const n=this._bindings;for(let r=this._targetGroup.nCachedObjects_,s=n.length;r!==s;++r)n[r].setValue(e,t)}bind(){const e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].bind()}unbind(){const e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].unbind()}}class lt{constructor(e,t,n){this.path=t,this.parsedPath=n||lt.parseTrackName(t),this.node=lt.findNode(e,this.parsedPath.nodeName),this.rootNode=e,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(e,t,n){return e&&e.isAnimationObjectGroup?new lt.Composite(e,t,n):new lt(e,t,n)}static sanitizeNodeName(e){return e.replace(/\s/g,"_").replace(Rg,"")}static parseTrackName(e){const t=Ng.exec(e);if(t===null)throw new Error("PropertyBinding: Cannot parse trackName: "+e);const n={nodeName:t[2],objectName:t[3],objectIndex:t[4],propertyName:t[5],propertyIndex:t[6]},r=n.nodeName&&n.nodeName.lastIndexOf(".");if(r!==void 0&&r!==-1){const s=n.nodeName.substring(r+1);Og.indexOf(s)!==-1&&(n.nodeName=n.nodeName.substring(0,r),n.objectName=s)}if(n.propertyName===null||n.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+e);return n}static findNode(e,t){if(t===void 0||t===""||t==="."||t===-1||t===e.name||t===e.uuid)return e;if(e.skeleton){const n=e.skeleton.getBoneByName(t);if(n!==void 0)return n}if(e.children){const n=function(s){for(let a=0;a<s.length;a++){const o=s[a];if(o.name===t||o.uuid===t)return o;const l=n(o.children);if(l)return l}return null},r=n(e.children);if(r)return r}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(e,t){e[t]=this.targetObject[this.propertyName]}_getValue_array(e,t){const n=this.resolvedProperty;for(let r=0,s=n.length;r!==s;++r)e[t++]=n[r]}_getValue_arrayElement(e,t){e[t]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(e,t){this.resolvedProperty.toArray(e,t)}_setValue_direct(e,t){this.targetObject[this.propertyName]=e[t]}_setValue_direct_setNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(e,t){const n=this.resolvedProperty;for(let r=0,s=n.length;r!==s;++r)n[r]=e[t++]}_setValue_array_setNeedsUpdate(e,t){const n=this.resolvedProperty;for(let r=0,s=n.length;r!==s;++r)n[r]=e[t++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(e,t){const n=this.resolvedProperty;for(let r=0,s=n.length;r!==s;++r)n[r]=e[t++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(e,t){this.resolvedProperty[this.propertyIndex]=e[t]}_setValue_arrayElement_setNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(e,t){this.resolvedProperty.fromArray(e,t)}_setValue_fromArray_setNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(e,t){this.bind(),this.getValue(e,t)}_setValue_unbound(e,t){this.bind(),this.setValue(e,t)}bind(){let e=this.node;const t=this.parsedPath,n=t.objectName,r=t.propertyName;let s=t.propertyIndex;if(e||(e=lt.findNode(this.rootNode,t.nodeName),this.node=e),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!e){console.warn("THREE.PropertyBinding: No target node found for track: "+this.path+".");return}if(n){let c=t.objectIndex;switch(n){case"materials":if(!e.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!e.material.materials){console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}e=e.material.materials;break;case"bones":if(!e.skeleton){console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}e=e.skeleton.bones;for(let d=0;d<e.length;d++)if(e[d].name===c){c=d;break}break;case"map":if("map"in e){e=e.map;break}if(!e.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!e.material.map){console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}e=e.material.map;break;default:if(e[n]===void 0){console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);return}e=e[n]}if(c!==void 0){if(e[c]===void 0){console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,e);return}e=e[c]}}const a=e[r];if(a===void 0){const c=t.nodeName;console.error("THREE.PropertyBinding: Trying to update property for track: "+c+"."+r+" but it wasn't found.",e);return}let o=this.Versioning.None;this.targetObject=e,e.isMaterial===!0?o=this.Versioning.NeedsUpdate:e.isObject3D===!0&&(o=this.Versioning.MatrixWorldNeedsUpdate);let l=this.BindingType.Direct;if(s!==void 0){if(r==="morphTargetInfluences"){if(!e.geometry){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!e.geometry.morphAttributes){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}e.morphTargetDictionary[s]!==void 0&&(s=e.morphTargetDictionary[s])}l=this.BindingType.ArrayElement,this.resolvedProperty=a,this.propertyIndex=s}else a.fromArray!==void 0&&a.toArray!==void 0?(l=this.BindingType.HasFromToArray,this.resolvedProperty=a):Array.isArray(a)?(l=this.BindingType.EntireArray,this.resolvedProperty=a):this.propertyName=r;this.getValue=this.GetterByBindingType[l],this.setValue=this.SetterByBindingTypeAndVersioning[l][o]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}}lt.Composite=Ug;lt.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};lt.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};lt.prototype.GetterByBindingType=[lt.prototype._getValue_direct,lt.prototype._getValue_array,lt.prototype._getValue_arrayElement,lt.prototype._getValue_toArray];lt.prototype.SetterByBindingTypeAndVersioning=[[lt.prototype._setValue_direct,lt.prototype._setValue_direct_setNeedsUpdate,lt.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[lt.prototype._setValue_array,lt.prototype._setValue_array_setNeedsUpdate,lt.prototype._setValue_array_setMatrixWorldNeedsUpdate],[lt.prototype._setValue_arrayElement,lt.prototype._setValue_arrayElement_setNeedsUpdate,lt.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[lt.prototype._setValue_fromArray,lt.prototype._setValue_fromArray_setNeedsUpdate,lt.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];const hd=new qe;class Fg{constructor(e,t,n=0,r=1/0){this.ray=new Vs(e,t),this.near=n,this.far=r,this.camera=null,this.layers=new Hc,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,(t.near+t.far)/(t.near-t.far)).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):console.error("THREE.Raycaster: Unsupported camera type: "+t.type)}setFromXRController(e){return hd.identity().extractRotation(e.matrixWorld),this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(hd),this}intersectObject(e,t=!0,n=[]){return vc(e,this,n,t),n.sort(fd),n}intersectObjects(e,t=!0,n=[]){for(let r=0,s=e.length;r<s;r++)vc(e[r],this,n,t);return n.sort(fd),n}}function fd(i,e){return i.distance-e.distance}function vc(i,e,t,n){let r=!0;if(i.layers.test(e.layers)&&i.raycast(e,t)===!1&&(r=!1),r===!0&&n===!0){const s=i.children;for(let a=0,o=s.length;a<o;a++)vc(s[a],e,t,!0)}}function pd(i,e,t,n){const r=Bg(n);switch(t){case $h:return i*e;case Oc:return i*e/r.components*r.byteLength;case Uc:return i*e/r.components*r.byteLength;case Zh:return i*e*2/r.components*r.byteLength;case Fc:return i*e*2/r.components*r.byteLength;case Kh:return i*e*3/r.components*r.byteLength;case wn:return i*e*4/r.components*r.byteLength;case Bc:return i*e*4/r.components*r.byteLength;case Ba:case ka:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case za:case Va:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case Vl:case Gl:return Math.max(i,16)*Math.max(e,8)/4;case zl:case Hl:return Math.max(i,8)*Math.max(e,8)/2;case Wl:case Xl:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case ql:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case Yl:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case jl:return Math.floor((i+4)/5)*Math.floor((e+3)/4)*16;case $l:return Math.floor((i+4)/5)*Math.floor((e+4)/5)*16;case Kl:return Math.floor((i+5)/6)*Math.floor((e+4)/5)*16;case Zl:return Math.floor((i+5)/6)*Math.floor((e+5)/6)*16;case Jl:return Math.floor((i+7)/8)*Math.floor((e+4)/5)*16;case Ql:return Math.floor((i+7)/8)*Math.floor((e+5)/6)*16;case ec:return Math.floor((i+7)/8)*Math.floor((e+7)/8)*16;case tc:return Math.floor((i+9)/10)*Math.floor((e+4)/5)*16;case nc:return Math.floor((i+9)/10)*Math.floor((e+5)/6)*16;case ic:return Math.floor((i+9)/10)*Math.floor((e+7)/8)*16;case rc:return Math.floor((i+9)/10)*Math.floor((e+9)/10)*16;case sc:return Math.floor((i+11)/12)*Math.floor((e+9)/10)*16;case ac:return Math.floor((i+11)/12)*Math.floor((e+11)/12)*16;case oc:case lc:case cc:return Math.ceil(i/4)*Math.ceil(e/4)*16;case uc:case dc:return Math.ceil(i/4)*Math.ceil(e/4)*8;case hc:case fc:return Math.ceil(i/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${t} format.`)}function Bg(i){switch(i){case Yn:case Xh:return{byteLength:1,components:1};case Is:case qh:case fi:return{byteLength:2,components:1};case Dc:case Nc:return{byteLength:2,components:4};case Ji:case Lc:case Bn:return{byteLength:4,components:1};case Yh:case jh:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${i}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Ic}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Ic);/**
 * @license
 * Copyright 2010-2025 Three.js Authors
 * SPDX-License-Identifier: MIT
 */function bf(){let i=null,e=!1,t=null,n=null;function r(s,a){t(s,a),n=i.requestAnimationFrame(r)}return{start:function(){e!==!0&&t!==null&&(n=i.requestAnimationFrame(r),e=!0)},stop:function(){i.cancelAnimationFrame(n),e=!1},setAnimationLoop:function(s){t=s},setContext:function(s){i=s}}}function kg(i){const e=new WeakMap;function t(o,l){const c=o.array,d=o.usage,u=c.byteLength,h=i.createBuffer();i.bindBuffer(l,h),i.bufferData(l,c,d),o.onUploadCallback();let p;if(c instanceof Float32Array)p=i.FLOAT;else if(typeof Float16Array<"u"&&c instanceof Float16Array)p=i.HALF_FLOAT;else if(c instanceof Uint16Array)o.isFloat16BufferAttribute?p=i.HALF_FLOAT:p=i.UNSIGNED_SHORT;else if(c instanceof Int16Array)p=i.SHORT;else if(c instanceof Uint32Array)p=i.UNSIGNED_INT;else if(c instanceof Int32Array)p=i.INT;else if(c instanceof Int8Array)p=i.BYTE;else if(c instanceof Uint8Array)p=i.UNSIGNED_BYTE;else if(c instanceof Uint8ClampedArray)p=i.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+c);return{buffer:h,type:p,bytesPerElement:c.BYTES_PER_ELEMENT,version:o.version,size:u}}function n(o,l,c){const d=l.array,u=l.updateRanges;if(i.bindBuffer(c,o),u.length===0)i.bufferSubData(c,0,d);else{u.sort((p,g)=>p.start-g.start);let h=0;for(let p=1;p<u.length;p++){const g=u[h],v=u[p];v.start<=g.start+g.count+1?g.count=Math.max(g.count,v.start+v.count-g.start):(++h,u[h]=v)}u.length=h+1;for(let p=0,g=u.length;p<g;p++){const v=u[p];i.bufferSubData(c,v.start*d.BYTES_PER_ELEMENT,d,v.start,v.count)}l.clearUpdateRanges()}l.onUploadCallback()}function r(o){return o.isInterleavedBufferAttribute&&(o=o.data),e.get(o)}function s(o){o.isInterleavedBufferAttribute&&(o=o.data);const l=e.get(o);l&&(i.deleteBuffer(l.buffer),e.delete(o))}function a(o,l){if(o.isInterleavedBufferAttribute&&(o=o.data),o.isGLBufferAttribute){const d=e.get(o);(!d||d.version<o.version)&&e.set(o,{buffer:o.buffer,type:o.type,bytesPerElement:o.elementSize,version:o.version});return}const c=e.get(o);if(c===void 0)e.set(o,t(o,l));else if(c.version<o.version){if(c.size!==o.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(c.buffer,o,l),c.version=o.version}}return{get:r,remove:s,update:a}}var zg=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,Vg=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,Hg=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,Gg=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Wg=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,Xg=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,qg=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,Yg=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,jg=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,$g=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,Kg=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Zg=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Jg=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,Qg=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,e0=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,t0=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,n0=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,i0=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,r0=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,s0=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,a0=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,o0=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,l0=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,c0=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,u0=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,d0=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,h0=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,f0=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,p0=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,m0=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,g0="gl_FragColor = linearToOutputTexel( gl_FragColor );",v0=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,_0=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,x0=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,y0=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,b0=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,S0=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,M0=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,E0=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,T0=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,A0=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,w0=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,R0=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,C0=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,I0=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,P0=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,L0=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,D0=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,N0=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,O0=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,U0=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,F0=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,B0=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,k0=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,z0=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,V0=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,H0=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,G0=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,W0=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,X0=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,q0=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,Y0=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,j0=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,$0=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,K0=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,Z0=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,J0=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,Q0=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,ev=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,tv=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,nv=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,iv=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,rv=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,sv=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,av=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,ov=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,lv=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,cv=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,uv=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,dv=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,hv=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,fv=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,pv=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,mv=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,gv=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,vv=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,_v=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,xv=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,yv=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,bv=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		float depth = unpackRGBAToDepth( texture2D( depths, uv ) );
		#ifdef USE_REVERSED_DEPTH_BUFFER
			return step( depth, compare );
		#else
			return step( compare, depth );
		#endif
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow( sampler2D shadow, vec2 uv, float compare ) {
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		#ifdef USE_REVERSED_DEPTH_BUFFER
			float hard_shadow = step( distribution.x, compare );
		#else
			float hard_shadow = step( compare, distribution.x );
		#endif
		if ( hard_shadow != 1.0 ) {
			float distance = compare - distribution.x;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,Sv=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,Mv=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,Ev=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Tv=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,Av=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,wv=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,Rv=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,Cv=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,Iv=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,Pv=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,Lv=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,Dv=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,Nv=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,Ov=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Uv=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Fv=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,Bv=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const kv=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,zv=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Vv=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Hv=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Gv=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Wv=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Xv=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,qv=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,Yv=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,jv=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,$v=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,Kv=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Zv=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Jv=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Qv=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,e_=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,t_=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,n_=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,i_=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,r_=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,s_=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,a_=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,o_=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,l_=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,c_=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,u_=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,d_=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,h_=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,f_=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,p_=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,m_=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,g_=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,v_=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,__=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Ze={alphahash_fragment:zg,alphahash_pars_fragment:Vg,alphamap_fragment:Hg,alphamap_pars_fragment:Gg,alphatest_fragment:Wg,alphatest_pars_fragment:Xg,aomap_fragment:qg,aomap_pars_fragment:Yg,batching_pars_vertex:jg,batching_vertex:$g,begin_vertex:Kg,beginnormal_vertex:Zg,bsdfs:Jg,iridescence_fragment:Qg,bumpmap_pars_fragment:e0,clipping_planes_fragment:t0,clipping_planes_pars_fragment:n0,clipping_planes_pars_vertex:i0,clipping_planes_vertex:r0,color_fragment:s0,color_pars_fragment:a0,color_pars_vertex:o0,color_vertex:l0,common:c0,cube_uv_reflection_fragment:u0,defaultnormal_vertex:d0,displacementmap_pars_vertex:h0,displacementmap_vertex:f0,emissivemap_fragment:p0,emissivemap_pars_fragment:m0,colorspace_fragment:g0,colorspace_pars_fragment:v0,envmap_fragment:_0,envmap_common_pars_fragment:x0,envmap_pars_fragment:y0,envmap_pars_vertex:b0,envmap_physical_pars_fragment:L0,envmap_vertex:S0,fog_vertex:M0,fog_pars_vertex:E0,fog_fragment:T0,fog_pars_fragment:A0,gradientmap_pars_fragment:w0,lightmap_pars_fragment:R0,lights_lambert_fragment:C0,lights_lambert_pars_fragment:I0,lights_pars_begin:P0,lights_toon_fragment:D0,lights_toon_pars_fragment:N0,lights_phong_fragment:O0,lights_phong_pars_fragment:U0,lights_physical_fragment:F0,lights_physical_pars_fragment:B0,lights_fragment_begin:k0,lights_fragment_maps:z0,lights_fragment_end:V0,logdepthbuf_fragment:H0,logdepthbuf_pars_fragment:G0,logdepthbuf_pars_vertex:W0,logdepthbuf_vertex:X0,map_fragment:q0,map_pars_fragment:Y0,map_particle_fragment:j0,map_particle_pars_fragment:$0,metalnessmap_fragment:K0,metalnessmap_pars_fragment:Z0,morphinstance_vertex:J0,morphcolor_vertex:Q0,morphnormal_vertex:ev,morphtarget_pars_vertex:tv,morphtarget_vertex:nv,normal_fragment_begin:iv,normal_fragment_maps:rv,normal_pars_fragment:sv,normal_pars_vertex:av,normal_vertex:ov,normalmap_pars_fragment:lv,clearcoat_normal_fragment_begin:cv,clearcoat_normal_fragment_maps:uv,clearcoat_pars_fragment:dv,iridescence_pars_fragment:hv,opaque_fragment:fv,packing:pv,premultiplied_alpha_fragment:mv,project_vertex:gv,dithering_fragment:vv,dithering_pars_fragment:_v,roughnessmap_fragment:xv,roughnessmap_pars_fragment:yv,shadowmap_pars_fragment:bv,shadowmap_pars_vertex:Sv,shadowmap_vertex:Mv,shadowmask_pars_fragment:Ev,skinbase_vertex:Tv,skinning_pars_vertex:Av,skinning_vertex:wv,skinnormal_vertex:Rv,specularmap_fragment:Cv,specularmap_pars_fragment:Iv,tonemapping_fragment:Pv,tonemapping_pars_fragment:Lv,transmission_fragment:Dv,transmission_pars_fragment:Nv,uv_pars_fragment:Ov,uv_pars_vertex:Uv,uv_vertex:Fv,worldpos_vertex:Bv,background_vert:kv,background_frag:zv,backgroundCube_vert:Vv,backgroundCube_frag:Hv,cube_vert:Gv,cube_frag:Wv,depth_vert:Xv,depth_frag:qv,distanceRGBA_vert:Yv,distanceRGBA_frag:jv,equirect_vert:$v,equirect_frag:Kv,linedashed_vert:Zv,linedashed_frag:Jv,meshbasic_vert:Qv,meshbasic_frag:e_,meshlambert_vert:t_,meshlambert_frag:n_,meshmatcap_vert:i_,meshmatcap_frag:r_,meshnormal_vert:s_,meshnormal_frag:a_,meshphong_vert:o_,meshphong_frag:l_,meshphysical_vert:c_,meshphysical_frag:u_,meshtoon_vert:d_,meshtoon_frag:h_,points_vert:f_,points_frag:p_,shadow_vert:m_,shadow_frag:g_,sprite_vert:v_,sprite_frag:__},be={common:{diffuse:{value:new Ie(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new $e},alphaMap:{value:null},alphaMapTransform:{value:new $e},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new $e}},envmap:{envMap:{value:null},envMapRotation:{value:new $e},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new $e}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new $e}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new $e},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new $e},normalScale:{value:new Ce(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new $e},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new $e}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new $e}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new $e}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Ie(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new Ie(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new $e},alphaTest:{value:0},uvTransform:{value:new $e}},sprite:{diffuse:{value:new Ie(16777215)},opacity:{value:1},center:{value:new Ce(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new $e},alphaMap:{value:null},alphaMapTransform:{value:new $e},alphaTest:{value:0}}},Xn={basic:{uniforms:Kt([be.common,be.specularmap,be.envmap,be.aomap,be.lightmap,be.fog]),vertexShader:Ze.meshbasic_vert,fragmentShader:Ze.meshbasic_frag},lambert:{uniforms:Kt([be.common,be.specularmap,be.envmap,be.aomap,be.lightmap,be.emissivemap,be.bumpmap,be.normalmap,be.displacementmap,be.fog,be.lights,{emissive:{value:new Ie(0)}}]),vertexShader:Ze.meshlambert_vert,fragmentShader:Ze.meshlambert_frag},phong:{uniforms:Kt([be.common,be.specularmap,be.envmap,be.aomap,be.lightmap,be.emissivemap,be.bumpmap,be.normalmap,be.displacementmap,be.fog,be.lights,{emissive:{value:new Ie(0)},specular:{value:new Ie(1118481)},shininess:{value:30}}]),vertexShader:Ze.meshphong_vert,fragmentShader:Ze.meshphong_frag},standard:{uniforms:Kt([be.common,be.envmap,be.aomap,be.lightmap,be.emissivemap,be.bumpmap,be.normalmap,be.displacementmap,be.roughnessmap,be.metalnessmap,be.fog,be.lights,{emissive:{value:new Ie(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Ze.meshphysical_vert,fragmentShader:Ze.meshphysical_frag},toon:{uniforms:Kt([be.common,be.aomap,be.lightmap,be.emissivemap,be.bumpmap,be.normalmap,be.displacementmap,be.gradientmap,be.fog,be.lights,{emissive:{value:new Ie(0)}}]),vertexShader:Ze.meshtoon_vert,fragmentShader:Ze.meshtoon_frag},matcap:{uniforms:Kt([be.common,be.bumpmap,be.normalmap,be.displacementmap,be.fog,{matcap:{value:null}}]),vertexShader:Ze.meshmatcap_vert,fragmentShader:Ze.meshmatcap_frag},points:{uniforms:Kt([be.points,be.fog]),vertexShader:Ze.points_vert,fragmentShader:Ze.points_frag},dashed:{uniforms:Kt([be.common,be.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Ze.linedashed_vert,fragmentShader:Ze.linedashed_frag},depth:{uniforms:Kt([be.common,be.displacementmap]),vertexShader:Ze.depth_vert,fragmentShader:Ze.depth_frag},normal:{uniforms:Kt([be.common,be.bumpmap,be.normalmap,be.displacementmap,{opacity:{value:1}}]),vertexShader:Ze.meshnormal_vert,fragmentShader:Ze.meshnormal_frag},sprite:{uniforms:Kt([be.sprite,be.fog]),vertexShader:Ze.sprite_vert,fragmentShader:Ze.sprite_frag},background:{uniforms:{uvTransform:{value:new $e},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Ze.background_vert,fragmentShader:Ze.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new $e}},vertexShader:Ze.backgroundCube_vert,fragmentShader:Ze.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Ze.cube_vert,fragmentShader:Ze.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Ze.equirect_vert,fragmentShader:Ze.equirect_frag},distanceRGBA:{uniforms:Kt([be.common,be.displacementmap,{referencePosition:{value:new U},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Ze.distanceRGBA_vert,fragmentShader:Ze.distanceRGBA_frag},shadow:{uniforms:Kt([be.lights,be.fog,{color:{value:new Ie(0)},opacity:{value:1}}]),vertexShader:Ze.shadow_vert,fragmentShader:Ze.shadow_frag}};Xn.physical={uniforms:Kt([Xn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new $e},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new $e},clearcoatNormalScale:{value:new Ce(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new $e},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new $e},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new $e},sheen:{value:0},sheenColor:{value:new Ie(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new $e},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new $e},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new $e},transmissionSamplerSize:{value:new Ce},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new $e},attenuationDistance:{value:0},attenuationColor:{value:new Ie(0)},specularColor:{value:new Ie(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new $e},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new $e},anisotropyVector:{value:new Ce},anisotropyMap:{value:null},anisotropyMapTransform:{value:new $e}}]),vertexShader:Ze.meshphysical_vert,fragmentShader:Ze.meshphysical_frag};const Ca={r:0,b:0,g:0},Gi=new xn,x_=new qe;function y_(i,e,t,n,r,s,a){const o=new Ie(0);let l=s===!0?0:1,c,d,u=null,h=0,p=null;function g(_){let x=_.isScene===!0?_.background:null;return x&&x.isTexture&&(x=(_.backgroundBlurriness>0?t:e).get(x)),x}function v(_){let x=!1;const R=g(_);R===null?f(o,l):R&&R.isColor&&(f(R,1),x=!0);const M=i.xr.getEnvironmentBlendMode();M==="additive"?n.buffers.color.setClear(0,0,0,1,a):M==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,a),(i.autoClear||x)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil))}function m(_,x){const R=g(x);R&&(R.isCubeTexture||R.mapping===lo)?(d===void 0&&(d=new ht(new Hs(1,1,1),new Rt({name:"BackgroundCubeMaterial",uniforms:Wr(Xn.backgroundCube.uniforms),vertexShader:Xn.backgroundCube.vertexShader,fragmentShader:Xn.backgroundCube.fragmentShader,side:cn,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),d.geometry.deleteAttribute("normal"),d.geometry.deleteAttribute("uv"),d.onBeforeRender=function(M,w,A){this.matrixWorld.copyPosition(A.matrixWorld)},Object.defineProperty(d.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),r.update(d)),Gi.copy(x.backgroundRotation),Gi.x*=-1,Gi.y*=-1,Gi.z*=-1,R.isCubeTexture&&R.isRenderTargetTexture===!1&&(Gi.y*=-1,Gi.z*=-1),d.material.uniforms.envMap.value=R,d.material.uniforms.flipEnvMap.value=R.isCubeTexture&&R.isRenderTargetTexture===!1?-1:1,d.material.uniforms.backgroundBlurriness.value=x.backgroundBlurriness,d.material.uniforms.backgroundIntensity.value=x.backgroundIntensity,d.material.uniforms.backgroundRotation.value.setFromMatrix4(x_.makeRotationFromEuler(Gi)),d.material.toneMapped=tt.getTransfer(R.colorSpace)!==pt,(u!==R||h!==R.version||p!==i.toneMapping)&&(d.material.needsUpdate=!0,u=R,h=R.version,p=i.toneMapping),d.layers.enableAll(),_.unshift(d,d.geometry,d.material,0,0,null)):R&&R.isTexture&&(c===void 0&&(c=new ht(new yn(2,2),new Rt({name:"BackgroundMaterial",uniforms:Wr(Xn.background.uniforms),vertexShader:Xn.background.vertexShader,fragmentShader:Xn.background.fragmentShader,side:mi,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),c.geometry.deleteAttribute("normal"),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),r.update(c)),c.material.uniforms.t2D.value=R,c.material.uniforms.backgroundIntensity.value=x.backgroundIntensity,c.material.toneMapped=tt.getTransfer(R.colorSpace)!==pt,R.matrixAutoUpdate===!0&&R.updateMatrix(),c.material.uniforms.uvTransform.value.copy(R.matrix),(u!==R||h!==R.version||p!==i.toneMapping)&&(c.material.needsUpdate=!0,u=R,h=R.version,p=i.toneMapping),c.layers.enableAll(),_.unshift(c,c.geometry,c.material,0,0,null))}function f(_,x){_.getRGB(Ca,af(i)),n.buffers.color.setClear(Ca.r,Ca.g,Ca.b,x,a)}function y(){d!==void 0&&(d.geometry.dispose(),d.material.dispose(),d=void 0),c!==void 0&&(c.geometry.dispose(),c.material.dispose(),c=void 0)}return{getClearColor:function(){return o},setClearColor:function(_,x=1){o.set(_),l=x,f(o,l)},getClearAlpha:function(){return l},setClearAlpha:function(_){l=_,f(o,l)},render:v,addToRenderList:m,dispose:y}}function b_(i,e){const t=i.getParameter(i.MAX_VERTEX_ATTRIBS),n={},r=h(null);let s=r,a=!1;function o(b,T,D,k,z){let H=!1;const L=u(k,D,T);s!==L&&(s=L,c(s.object)),H=p(b,k,D,z),H&&g(b,k,D,z),z!==null&&e.update(z,i.ELEMENT_ARRAY_BUFFER),(H||a)&&(a=!1,x(b,T,D,k),z!==null&&i.bindBuffer(i.ELEMENT_ARRAY_BUFFER,e.get(z).buffer))}function l(){return i.createVertexArray()}function c(b){return i.bindVertexArray(b)}function d(b){return i.deleteVertexArray(b)}function u(b,T,D){const k=D.wireframe===!0;let z=n[b.id];z===void 0&&(z={},n[b.id]=z);let H=z[T.id];H===void 0&&(H={},z[T.id]=H);let L=H[k];return L===void 0&&(L=h(l()),H[k]=L),L}function h(b){const T=[],D=[],k=[];for(let z=0;z<t;z++)T[z]=0,D[z]=0,k[z]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:T,enabledAttributes:D,attributeDivisors:k,object:b,attributes:{},index:null}}function p(b,T,D,k){const z=s.attributes,H=T.attributes;let L=0;const N=D.getAttributes();for(const B in N)if(N[B].location>=0){const Y=z[B];let ee=H[B];if(ee===void 0&&(B==="instanceMatrix"&&b.instanceMatrix&&(ee=b.instanceMatrix),B==="instanceColor"&&b.instanceColor&&(ee=b.instanceColor)),Y===void 0||Y.attribute!==ee||ee&&Y.data!==ee.data)return!0;L++}return s.attributesNum!==L||s.index!==k}function g(b,T,D,k){const z={},H=T.attributes;let L=0;const N=D.getAttributes();for(const B in N)if(N[B].location>=0){let Y=H[B];Y===void 0&&(B==="instanceMatrix"&&b.instanceMatrix&&(Y=b.instanceMatrix),B==="instanceColor"&&b.instanceColor&&(Y=b.instanceColor));const ee={};ee.attribute=Y,Y&&Y.data&&(ee.data=Y.data),z[B]=ee,L++}s.attributes=z,s.attributesNum=L,s.index=k}function v(){const b=s.newAttributes;for(let T=0,D=b.length;T<D;T++)b[T]=0}function m(b){f(b,0)}function f(b,T){const D=s.newAttributes,k=s.enabledAttributes,z=s.attributeDivisors;D[b]=1,k[b]===0&&(i.enableVertexAttribArray(b),k[b]=1),z[b]!==T&&(i.vertexAttribDivisor(b,T),z[b]=T)}function y(){const b=s.newAttributes,T=s.enabledAttributes;for(let D=0,k=T.length;D<k;D++)T[D]!==b[D]&&(i.disableVertexAttribArray(D),T[D]=0)}function _(b,T,D,k,z,H,L){L===!0?i.vertexAttribIPointer(b,T,D,z,H):i.vertexAttribPointer(b,T,D,k,z,H)}function x(b,T,D,k){v();const z=k.attributes,H=D.getAttributes(),L=T.defaultAttributeValues;for(const N in H){const B=H[N];if(B.location>=0){let V=z[N];if(V===void 0&&(N==="instanceMatrix"&&b.instanceMatrix&&(V=b.instanceMatrix),N==="instanceColor"&&b.instanceColor&&(V=b.instanceColor)),V!==void 0){const Y=V.normalized,ee=V.itemSize,$=e.get(V);if($===void 0)continue;const re=$.buffer,te=$.type,F=$.bytesPerElement,O=te===i.INT||te===i.UNSIGNED_INT||V.gpuType===Lc;if(V.isInterleavedBufferAttribute){const G=V.data,ne=G.stride,xe=V.offset;if(G.isInstancedInterleavedBuffer){for(let fe=0;fe<B.locationSize;fe++)f(B.location+fe,G.meshPerAttribute);b.isInstancedMesh!==!0&&k._maxInstanceCount===void 0&&(k._maxInstanceCount=G.meshPerAttribute*G.count)}else for(let fe=0;fe<B.locationSize;fe++)m(B.location+fe);i.bindBuffer(i.ARRAY_BUFFER,re);for(let fe=0;fe<B.locationSize;fe++)_(B.location+fe,ee/B.locationSize,te,Y,ne*F,(xe+ee/B.locationSize*fe)*F,O)}else{if(V.isInstancedBufferAttribute){for(let G=0;G<B.locationSize;G++)f(B.location+G,V.meshPerAttribute);b.isInstancedMesh!==!0&&k._maxInstanceCount===void 0&&(k._maxInstanceCount=V.meshPerAttribute*V.count)}else for(let G=0;G<B.locationSize;G++)m(B.location+G);i.bindBuffer(i.ARRAY_BUFFER,re);for(let G=0;G<B.locationSize;G++)_(B.location+G,ee/B.locationSize,te,Y,ee*F,ee/B.locationSize*G*F,O)}}else if(L!==void 0){const Y=L[N];if(Y!==void 0)switch(Y.length){case 2:i.vertexAttrib2fv(B.location,Y);break;case 3:i.vertexAttrib3fv(B.location,Y);break;case 4:i.vertexAttrib4fv(B.location,Y);break;default:i.vertexAttrib1fv(B.location,Y)}}}}y()}function R(){A();for(const b in n){const T=n[b];for(const D in T){const k=T[D];for(const z in k)d(k[z].object),delete k[z];delete T[D]}delete n[b]}}function M(b){if(n[b.id]===void 0)return;const T=n[b.id];for(const D in T){const k=T[D];for(const z in k)d(k[z].object),delete k[z];delete T[D]}delete n[b.id]}function w(b){for(const T in n){const D=n[T];if(D[b.id]===void 0)continue;const k=D[b.id];for(const z in k)d(k[z].object),delete k[z];delete D[b.id]}}function A(){S(),a=!0,s!==r&&(s=r,c(s.object))}function S(){r.geometry=null,r.program=null,r.wireframe=!1}return{setup:o,reset:A,resetDefaultState:S,dispose:R,releaseStatesOfGeometry:M,releaseStatesOfProgram:w,initAttributes:v,enableAttribute:m,disableUnusedAttributes:y}}function S_(i,e,t){let n;function r(c){n=c}function s(c,d){i.drawArrays(n,c,d),t.update(d,n,1)}function a(c,d,u){u!==0&&(i.drawArraysInstanced(n,c,d,u),t.update(d,n,u))}function o(c,d,u){if(u===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,c,0,d,0,u);let p=0;for(let g=0;g<u;g++)p+=d[g];t.update(p,n,1)}function l(c,d,u,h){if(u===0)return;const p=e.get("WEBGL_multi_draw");if(p===null)for(let g=0;g<c.length;g++)a(c[g],d[g],h[g]);else{p.multiDrawArraysInstancedWEBGL(n,c,0,d,0,h,0,u);let g=0;for(let v=0;v<u;v++)g+=d[v]*h[v];t.update(g,n,1)}}this.setMode=r,this.render=s,this.renderInstances=a,this.renderMultiDraw=o,this.renderMultiDrawInstances=l}function M_(i,e,t,n){let r;function s(){if(r!==void 0)return r;if(e.has("EXT_texture_filter_anisotropic")===!0){const w=e.get("EXT_texture_filter_anisotropic");r=i.getParameter(w.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else r=0;return r}function a(w){return!(w!==wn&&n.convert(w)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_FORMAT))}function o(w){const A=w===fi&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(w!==Yn&&n.convert(w)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_TYPE)&&w!==Bn&&!A)}function l(w){if(w==="highp"){if(i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.HIGH_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.HIGH_FLOAT).precision>0)return"highp";w="mediump"}return w==="mediump"&&i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.MEDIUM_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let c=t.precision!==void 0?t.precision:"highp";const d=l(c);d!==c&&(console.warn("THREE.WebGLRenderer:",c,"not supported, using",d,"instead."),c=d);const u=t.logarithmicDepthBuffer===!0,h=t.reversedDepthBuffer===!0&&e.has("EXT_clip_control"),p=i.getParameter(i.MAX_TEXTURE_IMAGE_UNITS),g=i.getParameter(i.MAX_VERTEX_TEXTURE_IMAGE_UNITS),v=i.getParameter(i.MAX_TEXTURE_SIZE),m=i.getParameter(i.MAX_CUBE_MAP_TEXTURE_SIZE),f=i.getParameter(i.MAX_VERTEX_ATTRIBS),y=i.getParameter(i.MAX_VERTEX_UNIFORM_VECTORS),_=i.getParameter(i.MAX_VARYING_VECTORS),x=i.getParameter(i.MAX_FRAGMENT_UNIFORM_VECTORS),R=g>0,M=i.getParameter(i.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:s,getMaxPrecision:l,textureFormatReadable:a,textureTypeReadable:o,precision:c,logarithmicDepthBuffer:u,reversedDepthBuffer:h,maxTextures:p,maxVertexTextures:g,maxTextureSize:v,maxCubemapSize:m,maxAttributes:f,maxVertexUniforms:y,maxVaryings:_,maxFragmentUniforms:x,vertexTextures:R,maxSamples:M}}function E_(i){const e=this;let t=null,n=0,r=!1,s=!1;const a=new Yi,o=new $e,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(u,h){const p=u.length!==0||h||n!==0||r;return r=h,n=u.length,p},this.beginShadows=function(){s=!0,d(null)},this.endShadows=function(){s=!1},this.setGlobalState=function(u,h){t=d(u,h,0)},this.setState=function(u,h,p){const g=u.clippingPlanes,v=u.clipIntersection,m=u.clipShadows,f=i.get(u);if(!r||g===null||g.length===0||s&&!m)s?d(null):c();else{const y=s?0:n,_=y*4;let x=f.clippingState||null;l.value=x,x=d(g,h,_,p);for(let R=0;R!==_;++R)x[R]=t[R];f.clippingState=x,this.numIntersection=v?this.numPlanes:0,this.numPlanes+=y}};function c(){l.value!==t&&(l.value=t,l.needsUpdate=n>0),e.numPlanes=n,e.numIntersection=0}function d(u,h,p,g){const v=u!==null?u.length:0;let m=null;if(v!==0){if(m=l.value,g!==!0||m===null){const f=p+v*4,y=h.matrixWorldInverse;o.getNormalMatrix(y),(m===null||m.length<f)&&(m=new Float32Array(f));for(let _=0,x=p;_!==v;++_,x+=4)a.copy(u[_]).applyMatrix4(y,o),a.normal.toArray(m,x),m[x+3]=a.constant}l.value=m,l.needsUpdate=!0}return e.numPlanes=v,e.numIntersection=0,m}}function T_(i){let e=new WeakMap;function t(a,o){return o===Bl?a.mapping=zr:o===kl&&(a.mapping=Vr),a}function n(a){if(a&&a.isTexture){const o=a.mapping;if(o===Bl||o===kl)if(e.has(a)){const l=e.get(a).texture;return t(l,a.mapping)}else{const l=a.image;if(l&&l.height>0){const c=new qm(l.height);return c.fromEquirectangularTexture(i,a),e.set(a,c),a.addEventListener("dispose",r),t(c.texture,a.mapping)}else return null}}return a}function r(a){const o=a.target;o.removeEventListener("dispose",r);const l=e.get(o);l!==void 0&&(e.delete(o),l.dispose())}function s(){e=new WeakMap}return{get:n,dispose:s}}const Ir=4,md=[.125,.215,.35,.446,.526,.582],Ki=20,ll=new qs,gd=new Ie;let cl=null,ul=0,dl=0,hl=!1;const ji=(1+Math.sqrt(5))/2,Mr=1/ji,vd=[new U(-ji,Mr,0),new U(ji,Mr,0),new U(-Mr,0,ji),new U(Mr,0,ji),new U(0,ji,-Mr),new U(0,ji,Mr),new U(-1,1,-1),new U(1,1,-1),new U(-1,1,1),new U(1,1,1)],A_=new U;class _d{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(e,t=0,n=.1,r=100,s={}){const{size:a=256,position:o=A_}=s;cl=this._renderer.getRenderTarget(),ul=this._renderer.getActiveCubeFace(),dl=this._renderer.getActiveMipmapLevel(),hl=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(a);const l=this._allocateTargets();return l.depthBuffer=!0,this._sceneToCubeUV(e,n,r,l,o),t>0&&this._blur(l,0,0,t),this._applyPMREM(l),this._cleanup(l),l}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=bd(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=yd(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodPlanes.length;e++)this._lodPlanes[e].dispose()}_cleanup(e){this._renderer.setRenderTarget(cl,ul,dl),this._renderer.xr.enabled=hl,e.scissorTest=!1,Ia(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===zr||e.mapping===Vr?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),cl=this._renderer.getRenderTarget(),ul=this._renderer.getActiveCubeFace(),dl=this._renderer.getActiveMipmapLevel(),hl=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const n=t||this._allocateTargets();return this._textureToCubeUV(e,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,n={magFilter:Dt,minFilter:Dt,generateMipmaps:!1,type:fi,format:wn,colorSpace:nn,depthBuffer:!1},r=xd(e,t,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=xd(e,t,n);const{_lodMax:s}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=w_(s)),this._blurMaterial=R_(s,e,t)}return r}_compileMaterial(e){const t=new ht(this._lodPlanes[0],e);this._renderer.compile(t,ll)}_sceneToCubeUV(e,t,n,r,s){const l=new Zt(90,1,t,n),c=[1,-1,1,1,1,1],d=[1,1,1,-1,-1,-1],u=this._renderer,h=u.autoClear,p=u.toneMapping;u.getClearColor(gd),u.toneMapping=Li,u.autoClear=!1,u.state.buffers.depth.getReversed()&&(u.setRenderTarget(r),u.clearDepth(),u.setRenderTarget(null));const v=new Ut({name:"PMREM.Background",side:cn,depthWrite:!1,depthTest:!1}),m=new ht(new Hs,v);let f=!1;const y=e.background;y?y.isColor&&(v.color.copy(y),e.background=null,f=!0):(v.color.copy(gd),f=!0);for(let _=0;_<6;_++){const x=_%3;x===0?(l.up.set(0,c[_],0),l.position.set(s.x,s.y,s.z),l.lookAt(s.x+d[_],s.y,s.z)):x===1?(l.up.set(0,0,c[_]),l.position.set(s.x,s.y,s.z),l.lookAt(s.x,s.y+d[_],s.z)):(l.up.set(0,c[_],0),l.position.set(s.x,s.y,s.z),l.lookAt(s.x,s.y,s.z+d[_]));const R=this._cubeSize;Ia(r,x*R,_>2?R:0,R,R),u.setRenderTarget(r),f&&u.render(m,l),u.render(e,l)}m.geometry.dispose(),m.material.dispose(),u.toneMapping=p,u.autoClear=h,e.background=y}_textureToCubeUV(e,t){const n=this._renderer,r=e.mapping===zr||e.mapping===Vr;r?(this._cubemapMaterial===null&&(this._cubemapMaterial=bd()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=yd());const s=r?this._cubemapMaterial:this._equirectMaterial,a=new ht(this._lodPlanes[0],s),o=s.uniforms;o.envMap.value=e;const l=this._cubeSize;Ia(t,0,0,3*l,2*l),n.setRenderTarget(t),n.render(a,ll)}_applyPMREM(e){const t=this._renderer,n=t.autoClear;t.autoClear=!1;const r=this._lodPlanes.length;for(let s=1;s<r;s++){const a=Math.sqrt(this._sigmas[s]*this._sigmas[s]-this._sigmas[s-1]*this._sigmas[s-1]),o=vd[(r-s-1)%vd.length];this._blur(e,s-1,s,a,o)}t.autoClear=n}_blur(e,t,n,r,s){const a=this._pingPongRenderTarget;this._halfBlur(e,a,t,n,r,"latitudinal",s),this._halfBlur(a,e,n,n,r,"longitudinal",s)}_halfBlur(e,t,n,r,s,a,o){const l=this._renderer,c=this._blurMaterial;a!=="latitudinal"&&a!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");const d=3,u=new ht(this._lodPlanes[r],c),h=c.uniforms,p=this._sizeLods[n]-1,g=isFinite(s)?Math.PI/(2*p):2*Math.PI/(2*Ki-1),v=s/g,m=isFinite(s)?1+Math.floor(d*v):Ki;m>Ki&&console.warn(`sigmaRadians, ${s}, is too large and will clip, as it requested ${m} samples when the maximum is set to ${Ki}`);const f=[];let y=0;for(let w=0;w<Ki;++w){const A=w/v,S=Math.exp(-A*A/2);f.push(S),w===0?y+=S:w<m&&(y+=2*S)}for(let w=0;w<f.length;w++)f[w]=f[w]/y;h.envMap.value=e.texture,h.samples.value=m,h.weights.value=f,h.latitudinal.value=a==="latitudinal",o&&(h.poleAxis.value=o);const{_lodMax:_}=this;h.dTheta.value=g,h.mipInt.value=_-n;const x=this._sizeLods[r],R=3*x*(r>_-Ir?r-_+Ir:0),M=4*(this._cubeSize-x);Ia(t,R,M,3*x,2*x),l.setRenderTarget(t),l.render(u,ll)}}function w_(i){const e=[],t=[],n=[];let r=i;const s=i-Ir+1+md.length;for(let a=0;a<s;a++){const o=Math.pow(2,r);t.push(o);let l=1/o;a>i-Ir?l=md[a-i+Ir-1]:a===0&&(l=0),n.push(l);const c=1/(o-2),d=-c,u=1+c,h=[d,d,u,d,u,u,d,d,u,u,d,u],p=6,g=6,v=3,m=2,f=1,y=new Float32Array(v*g*p),_=new Float32Array(m*g*p),x=new Float32Array(f*g*p);for(let M=0;M<p;M++){const w=M%3*2/3-1,A=M>2?0:-1,S=[w,A,0,w+2/3,A,0,w+2/3,A+1,0,w,A,0,w+2/3,A+1,0,w,A+1,0];y.set(S,v*g*M),_.set(h,m*g*M);const b=[M,M,M,M,M,M];x.set(b,f*g*M)}const R=new Lt;R.setAttribute("position",new ct(y,v)),R.setAttribute("uv",new ct(_,m)),R.setAttribute("faceIndex",new ct(x,f)),e.push(R),r>Ir&&r--}return{lodPlanes:e,sizeLods:t,sigmas:n}}function xd(i,e,t){const n=new zn(i,e,t);return n.texture.mapping=lo,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function Ia(i,e,t,n,r){i.viewport.set(e,t,n,r),i.scissor.set(e,t,n,r)}function R_(i,e,t){const n=new Float32Array(Ki),r=new U(0,1,0);return new Rt({name:"SphericalGaussianBlur",defines:{n:Ki,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${i}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:r}},vertexShader:eu(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:hi,depthTest:!1,depthWrite:!1})}function yd(){return new Rt({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:eu(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:hi,depthTest:!1,depthWrite:!1})}function bd(){return new Rt({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:eu(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:hi,depthTest:!1,depthWrite:!1})}function eu(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function C_(i){let e=new WeakMap,t=null;function n(o){if(o&&o.isTexture){const l=o.mapping,c=l===Bl||l===kl,d=l===zr||l===Vr;if(c||d){let u=e.get(o);const h=u!==void 0?u.texture.pmremVersion:0;if(o.isRenderTargetTexture&&o.pmremVersion!==h)return t===null&&(t=new _d(i)),u=c?t.fromEquirectangular(o,u):t.fromCubemap(o,u),u.texture.pmremVersion=o.pmremVersion,e.set(o,u),u.texture;if(u!==void 0)return u.texture;{const p=o.image;return c&&p&&p.height>0||d&&p&&r(p)?(t===null&&(t=new _d(i)),u=c?t.fromEquirectangular(o):t.fromCubemap(o),u.texture.pmremVersion=o.pmremVersion,e.set(o,u),o.addEventListener("dispose",s),u.texture):null}}}return o}function r(o){let l=0;const c=6;for(let d=0;d<c;d++)o[d]!==void 0&&l++;return l===c}function s(o){const l=o.target;l.removeEventListener("dispose",s);const c=e.get(l);c!==void 0&&(e.delete(l),c.dispose())}function a(){e=new WeakMap,t!==null&&(t.dispose(),t=null)}return{get:n,dispose:a}}function I_(i){const e={};function t(n){if(e[n]!==void 0)return e[n];let r;switch(n){case"WEBGL_depth_texture":r=i.getExtension("WEBGL_depth_texture")||i.getExtension("MOZ_WEBGL_depth_texture")||i.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":r=i.getExtension("EXT_texture_filter_anisotropic")||i.getExtension("MOZ_EXT_texture_filter_anisotropic")||i.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":r=i.getExtension("WEBGL_compressed_texture_s3tc")||i.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":r=i.getExtension("WEBGL_compressed_texture_pvrtc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:r=i.getExtension(n)}return e[n]=r,r}return{has:function(n){return t(n)!==null},init:function(){t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance"),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture"),t("WEBGL_render_shared_exponent")},get:function(n){const r=t(n);return r===null&&Fs("THREE.WebGLRenderer: "+n+" extension not supported."),r}}}function P_(i,e,t,n){const r={},s=new WeakMap;function a(u){const h=u.target;h.index!==null&&e.remove(h.index);for(const g in h.attributes)e.remove(h.attributes[g]);h.removeEventListener("dispose",a),delete r[h.id];const p=s.get(h);p&&(e.remove(p),s.delete(h)),n.releaseStatesOfGeometry(h),h.isInstancedBufferGeometry===!0&&delete h._maxInstanceCount,t.memory.geometries--}function o(u,h){return r[h.id]===!0||(h.addEventListener("dispose",a),r[h.id]=!0,t.memory.geometries++),h}function l(u){const h=u.attributes;for(const p in h)e.update(h[p],i.ARRAY_BUFFER)}function c(u){const h=[],p=u.index,g=u.attributes.position;let v=0;if(p!==null){const y=p.array;v=p.version;for(let _=0,x=y.length;_<x;_+=3){const R=y[_+0],M=y[_+1],w=y[_+2];h.push(R,M,M,w,w,R)}}else if(g!==void 0){const y=g.array;v=g.version;for(let _=0,x=y.length/3-1;_<x;_+=3){const R=_+0,M=_+1,w=_+2;h.push(R,M,M,w,w,R)}}else return;const m=new(tf(h)?sf:co)(h,1);m.version=v;const f=s.get(u);f&&e.remove(f),s.set(u,m)}function d(u){const h=s.get(u);if(h){const p=u.index;p!==null&&h.version<p.version&&c(u)}else c(u);return s.get(u)}return{get:o,update:l,getWireframeAttribute:d}}function L_(i,e,t){let n;function r(h){n=h}let s,a;function o(h){s=h.type,a=h.bytesPerElement}function l(h,p){i.drawElements(n,p,s,h*a),t.update(p,n,1)}function c(h,p,g){g!==0&&(i.drawElementsInstanced(n,p,s,h*a,g),t.update(p,n,g))}function d(h,p,g){if(g===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,p,0,s,h,0,g);let m=0;for(let f=0;f<g;f++)m+=p[f];t.update(m,n,1)}function u(h,p,g,v){if(g===0)return;const m=e.get("WEBGL_multi_draw");if(m===null)for(let f=0;f<h.length;f++)c(h[f]/a,p[f],v[f]);else{m.multiDrawElementsInstancedWEBGL(n,p,0,s,h,0,v,0,g);let f=0;for(let y=0;y<g;y++)f+=p[y]*v[y];t.update(f,n,1)}}this.setMode=r,this.setIndex=o,this.render=l,this.renderInstances=c,this.renderMultiDraw=d,this.renderMultiDrawInstances=u}function D_(i){const e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function n(s,a,o){switch(t.calls++,a){case i.TRIANGLES:t.triangles+=o*(s/3);break;case i.LINES:t.lines+=o*(s/2);break;case i.LINE_STRIP:t.lines+=o*(s-1);break;case i.LINE_LOOP:t.lines+=o*s;break;case i.POINTS:t.points+=o*s;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",a);break}}function r(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:r,update:n}}function N_(i,e,t){const n=new WeakMap,r=new rt;function s(a,o,l){const c=a.morphTargetInfluences,d=o.morphAttributes.position||o.morphAttributes.normal||o.morphAttributes.color,u=d!==void 0?d.length:0;let h=n.get(o);if(h===void 0||h.count!==u){let S=function(){w.dispose(),n.delete(o),o.removeEventListener("dispose",S)};h!==void 0&&h.texture.dispose();const p=o.morphAttributes.position!==void 0,g=o.morphAttributes.normal!==void 0,v=o.morphAttributes.color!==void 0,m=o.morphAttributes.position||[],f=o.morphAttributes.normal||[],y=o.morphAttributes.color||[];let _=0;p===!0&&(_=1),g===!0&&(_=2),v===!0&&(_=3);let x=o.attributes.position.count*_,R=1;x>e.maxTextureSize&&(R=Math.ceil(x/e.maxTextureSize),x=e.maxTextureSize);const M=new Float32Array(x*R*4*u),w=new nf(M,x,R,u);w.type=Bn,w.needsUpdate=!0;const A=_*4;for(let b=0;b<u;b++){const T=m[b],D=f[b],k=y[b],z=x*R*4*b;for(let H=0;H<T.count;H++){const L=H*A;p===!0&&(r.fromBufferAttribute(T,H),M[z+L+0]=r.x,M[z+L+1]=r.y,M[z+L+2]=r.z,M[z+L+3]=0),g===!0&&(r.fromBufferAttribute(D,H),M[z+L+4]=r.x,M[z+L+5]=r.y,M[z+L+6]=r.z,M[z+L+7]=0),v===!0&&(r.fromBufferAttribute(k,H),M[z+L+8]=r.x,M[z+L+9]=r.y,M[z+L+10]=r.z,M[z+L+11]=k.itemSize===4?r.w:1)}}h={count:u,texture:w,size:new Ce(x,R)},n.set(o,h),o.addEventListener("dispose",S)}if(a.isInstancedMesh===!0&&a.morphTexture!==null)l.getUniforms().setValue(i,"morphTexture",a.morphTexture,t);else{let p=0;for(let v=0;v<c.length;v++)p+=c[v];const g=o.morphTargetsRelative?1:1-p;l.getUniforms().setValue(i,"morphTargetBaseInfluence",g),l.getUniforms().setValue(i,"morphTargetInfluences",c)}l.getUniforms().setValue(i,"morphTargetsTexture",h.texture,t),l.getUniforms().setValue(i,"morphTargetsTextureSize",h.size)}return{update:s}}function O_(i,e,t,n){let r=new WeakMap;function s(l){const c=n.render.frame,d=l.geometry,u=e.get(l,d);if(r.get(u)!==c&&(e.update(u),r.set(u,c)),l.isInstancedMesh&&(l.hasEventListener("dispose",o)===!1&&l.addEventListener("dispose",o),r.get(l)!==c&&(t.update(l.instanceMatrix,i.ARRAY_BUFFER),l.instanceColor!==null&&t.update(l.instanceColor,i.ARRAY_BUFFER),r.set(l,c))),l.isSkinnedMesh){const h=l.skeleton;r.get(h)!==c&&(h.update(),r.set(h,c))}return u}function a(){r=new WeakMap}function o(l){const c=l.target;c.removeEventListener("dispose",o),t.remove(c.instanceMatrix),c.instanceColor!==null&&t.remove(c.instanceColor)}return{update:s,dispose:a}}const Sf=new Ft,Sd=new mf(1,1),Mf=new nf,Ef=new Im,Tf=new lf,Md=[],Ed=[],Td=new Float32Array(16),Ad=new Float32Array(9),wd=new Float32Array(4);function ss(i,e,t){const n=i[0];if(n<=0||n>0)return i;const r=e*t;let s=Md[r];if(s===void 0&&(s=new Float32Array(r),Md[r]=s),e!==0){n.toArray(s,0);for(let a=1,o=0;a!==e;++a)o+=t,i[a].toArray(s,o)}return s}function Bt(i,e){if(i.length!==e.length)return!1;for(let t=0,n=i.length;t<n;t++)if(i[t]!==e[t])return!1;return!0}function kt(i,e){for(let t=0,n=e.length;t<n;t++)i[t]=e[t]}function go(i,e){let t=Ed[e];t===void 0&&(t=new Int32Array(e),Ed[e]=t);for(let n=0;n!==e;++n)t[n]=i.allocateTextureUnit();return t}function U_(i,e){const t=this.cache;t[0]!==e&&(i.uniform1f(this.addr,e),t[0]=e)}function F_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Bt(t,e))return;i.uniform2fv(this.addr,e),kt(t,e)}}function B_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(i.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(Bt(t,e))return;i.uniform3fv(this.addr,e),kt(t,e)}}function k_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Bt(t,e))return;i.uniform4fv(this.addr,e),kt(t,e)}}function z_(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Bt(t,e))return;i.uniformMatrix2fv(this.addr,!1,e),kt(t,e)}else{if(Bt(t,n))return;wd.set(n),i.uniformMatrix2fv(this.addr,!1,wd),kt(t,n)}}function V_(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Bt(t,e))return;i.uniformMatrix3fv(this.addr,!1,e),kt(t,e)}else{if(Bt(t,n))return;Ad.set(n),i.uniformMatrix3fv(this.addr,!1,Ad),kt(t,n)}}function H_(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Bt(t,e))return;i.uniformMatrix4fv(this.addr,!1,e),kt(t,e)}else{if(Bt(t,n))return;Td.set(n),i.uniformMatrix4fv(this.addr,!1,Td),kt(t,n)}}function G_(i,e){const t=this.cache;t[0]!==e&&(i.uniform1i(this.addr,e),t[0]=e)}function W_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Bt(t,e))return;i.uniform2iv(this.addr,e),kt(t,e)}}function X_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Bt(t,e))return;i.uniform3iv(this.addr,e),kt(t,e)}}function q_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Bt(t,e))return;i.uniform4iv(this.addr,e),kt(t,e)}}function Y_(i,e){const t=this.cache;t[0]!==e&&(i.uniform1ui(this.addr,e),t[0]=e)}function j_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Bt(t,e))return;i.uniform2uiv(this.addr,e),kt(t,e)}}function $_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Bt(t,e))return;i.uniform3uiv(this.addr,e),kt(t,e)}}function K_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Bt(t,e))return;i.uniform4uiv(this.addr,e),kt(t,e)}}function Z_(i,e,t){const n=this.cache,r=t.allocateTextureUnit();n[0]!==r&&(i.uniform1i(this.addr,r),n[0]=r);let s;this.type===i.SAMPLER_2D_SHADOW?(Sd.compareFunction=Qh,s=Sd):s=Sf,t.setTexture2D(e||s,r)}function J_(i,e,t){const n=this.cache,r=t.allocateTextureUnit();n[0]!==r&&(i.uniform1i(this.addr,r),n[0]=r),t.setTexture3D(e||Ef,r)}function Q_(i,e,t){const n=this.cache,r=t.allocateTextureUnit();n[0]!==r&&(i.uniform1i(this.addr,r),n[0]=r),t.setTextureCube(e||Tf,r)}function ex(i,e,t){const n=this.cache,r=t.allocateTextureUnit();n[0]!==r&&(i.uniform1i(this.addr,r),n[0]=r),t.setTexture2DArray(e||Mf,r)}function tx(i){switch(i){case 5126:return U_;case 35664:return F_;case 35665:return B_;case 35666:return k_;case 35674:return z_;case 35675:return V_;case 35676:return H_;case 5124:case 35670:return G_;case 35667:case 35671:return W_;case 35668:case 35672:return X_;case 35669:case 35673:return q_;case 5125:return Y_;case 36294:return j_;case 36295:return $_;case 36296:return K_;case 35678:case 36198:case 36298:case 36306:case 35682:return Z_;case 35679:case 36299:case 36307:return J_;case 35680:case 36300:case 36308:case 36293:return Q_;case 36289:case 36303:case 36311:case 36292:return ex}}function nx(i,e){i.uniform1fv(this.addr,e)}function ix(i,e){const t=ss(e,this.size,2);i.uniform2fv(this.addr,t)}function rx(i,e){const t=ss(e,this.size,3);i.uniform3fv(this.addr,t)}function sx(i,e){const t=ss(e,this.size,4);i.uniform4fv(this.addr,t)}function ax(i,e){const t=ss(e,this.size,4);i.uniformMatrix2fv(this.addr,!1,t)}function ox(i,e){const t=ss(e,this.size,9);i.uniformMatrix3fv(this.addr,!1,t)}function lx(i,e){const t=ss(e,this.size,16);i.uniformMatrix4fv(this.addr,!1,t)}function cx(i,e){i.uniform1iv(this.addr,e)}function ux(i,e){i.uniform2iv(this.addr,e)}function dx(i,e){i.uniform3iv(this.addr,e)}function hx(i,e){i.uniform4iv(this.addr,e)}function fx(i,e){i.uniform1uiv(this.addr,e)}function px(i,e){i.uniform2uiv(this.addr,e)}function mx(i,e){i.uniform3uiv(this.addr,e)}function gx(i,e){i.uniform4uiv(this.addr,e)}function vx(i,e,t){const n=this.cache,r=e.length,s=go(t,r);Bt(n,s)||(i.uniform1iv(this.addr,s),kt(n,s));for(let a=0;a!==r;++a)t.setTexture2D(e[a]||Sf,s[a])}function _x(i,e,t){const n=this.cache,r=e.length,s=go(t,r);Bt(n,s)||(i.uniform1iv(this.addr,s),kt(n,s));for(let a=0;a!==r;++a)t.setTexture3D(e[a]||Ef,s[a])}function xx(i,e,t){const n=this.cache,r=e.length,s=go(t,r);Bt(n,s)||(i.uniform1iv(this.addr,s),kt(n,s));for(let a=0;a!==r;++a)t.setTextureCube(e[a]||Tf,s[a])}function yx(i,e,t){const n=this.cache,r=e.length,s=go(t,r);Bt(n,s)||(i.uniform1iv(this.addr,s),kt(n,s));for(let a=0;a!==r;++a)t.setTexture2DArray(e[a]||Mf,s[a])}function bx(i){switch(i){case 5126:return nx;case 35664:return ix;case 35665:return rx;case 35666:return sx;case 35674:return ax;case 35675:return ox;case 35676:return lx;case 5124:case 35670:return cx;case 35667:case 35671:return ux;case 35668:case 35672:return dx;case 35669:case 35673:return hx;case 5125:return fx;case 36294:return px;case 36295:return mx;case 36296:return gx;case 35678:case 36198:case 36298:case 36306:case 35682:return vx;case 35679:case 36299:case 36307:return _x;case 35680:case 36300:case 36308:case 36293:return xx;case 36289:case 36303:case 36311:case 36292:return yx}}class Sx{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.setValue=tx(t.type)}}class Mx{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=bx(t.type)}}class Ex{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,n){const r=this.seq;for(let s=0,a=r.length;s!==a;++s){const o=r[s];o.setValue(e,t[o.id],n)}}}const fl=/(\w+)(\])?(\[|\.)?/g;function Rd(i,e){i.seq.push(e),i.map[e.id]=e}function Tx(i,e,t){const n=i.name,r=n.length;for(fl.lastIndex=0;;){const s=fl.exec(n),a=fl.lastIndex;let o=s[1];const l=s[2]==="]",c=s[3];if(l&&(o=o|0),c===void 0||c==="["&&a+2===r){Rd(t,c===void 0?new Sx(o,i,e):new Mx(o,i,e));break}else{let u=t.map[o];u===void 0&&(u=new Ex(o),Rd(t,u)),t=u}}}class Ha{constructor(e,t){this.seq=[],this.map={};const n=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let r=0;r<n;++r){const s=e.getActiveUniform(t,r),a=e.getUniformLocation(t,s.name);Tx(s,a,this)}}setValue(e,t,n,r){const s=this.map[t];s!==void 0&&s.setValue(e,n,r)}setOptional(e,t,n){const r=t[n];r!==void 0&&this.setValue(e,n,r)}static upload(e,t,n,r){for(let s=0,a=t.length;s!==a;++s){const o=t[s],l=n[o.id];l.needsUpdate!==!1&&o.setValue(e,l.value,r)}}static seqWithValue(e,t){const n=[];for(let r=0,s=e.length;r!==s;++r){const a=e[r];a.id in t&&n.push(a)}return n}}function Cd(i,e,t){const n=i.createShader(e);return i.shaderSource(n,t),i.compileShader(n),n}const Ax=37297;let wx=0;function Rx(i,e){const t=i.split(`
`),n=[],r=Math.max(e-6,0),s=Math.min(e+6,t.length);for(let a=r;a<s;a++){const o=a+1;n.push(`${o===e?">":" "} ${o}: ${t[a]}`)}return n.join(`
`)}const Id=new $e;function Cx(i){tt._getMatrix(Id,tt.workingColorSpace,i);const e=`mat3( ${Id.elements.map(t=>t.toFixed(4))} )`;switch(tt.getTransfer(i)){case Xa:return[e,"LinearTransferOETF"];case pt:return[e,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space: ",i),[e,"LinearTransferOETF"]}}function Pd(i,e,t){const n=i.getShaderParameter(e,i.COMPILE_STATUS),s=(i.getShaderInfoLog(e)||"").trim();if(n&&s==="")return"";const a=/ERROR: 0:(\d+)/.exec(s);if(a){const o=parseInt(a[1]);return t.toUpperCase()+`

`+s+`

`+Rx(i.getShaderSource(e),o)}else return s}function Ix(i,e){const t=Cx(e);return[`vec4 ${i}( vec4 value ) {`,`	return ${t[1]}( vec4( value.rgb * ${t[0]}, value.a ) );`,"}"].join(`
`)}function Px(i,e){let t;switch(e){case Hp:t="Linear";break;case Gp:t="Reinhard";break;case Wp:t="Cineon";break;case Hh:t="ACESFilmic";break;case qp:t="AgX";break;case Yp:t="Neutral";break;case Xp:t="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",e),t="Linear"}return"vec3 "+i+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}const Pa=new U;function Lx(){tt.getLuminanceCoefficients(Pa);const i=Pa.x.toFixed(4),e=Pa.y.toFixed(4),t=Pa.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${i}, ${e}, ${t} );`,"	return dot( weights, rgb );","}"].join(`
`)}function Dx(i){return[i.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",i.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(Es).join(`
`)}function Nx(i){const e=[];for(const t in i){const n=i[t];n!==!1&&e.push("#define "+t+" "+n)}return e.join(`
`)}function Ox(i,e){const t={},n=i.getProgramParameter(e,i.ACTIVE_ATTRIBUTES);for(let r=0;r<n;r++){const s=i.getActiveAttrib(e,r),a=s.name;let o=1;s.type===i.FLOAT_MAT2&&(o=2),s.type===i.FLOAT_MAT3&&(o=3),s.type===i.FLOAT_MAT4&&(o=4),t[a]={type:s.type,location:i.getAttribLocation(e,a),locationSize:o}}return t}function Es(i){return i!==""}function Ld(i,e){const t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return i.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function Dd(i,e){return i.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const Ux=/^[ \t]*#include +<([\w\d./]+)>/gm;function _c(i){return i.replace(Ux,Bx)}const Fx=new Map;function Bx(i,e){let t=Ze[e];if(t===void 0){const n=Fx.get(e);if(n!==void 0)t=Ze[n],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,n);else throw new Error("Can not resolve #include <"+e+">")}return _c(t)}const kx=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Nd(i){return i.replace(kx,zx)}function zx(i,e,t,n){let r="";for(let s=parseInt(e);s<parseInt(t);s++)r+=n.replace(/\[\s*i\s*\]/g,"[ "+s+" ]").replace(/UNROLLED_LOOP_INDEX/g,s);return r}function Od(i){let e=`precision ${i.precision} float;
	precision ${i.precision} int;
	precision ${i.precision} sampler2D;
	precision ${i.precision} samplerCube;
	precision ${i.precision} sampler3D;
	precision ${i.precision} sampler2DArray;
	precision ${i.precision} sampler2DShadow;
	precision ${i.precision} samplerCubeShadow;
	precision ${i.precision} sampler2DArrayShadow;
	precision ${i.precision} isampler2D;
	precision ${i.precision} isampler3D;
	precision ${i.precision} isamplerCube;
	precision ${i.precision} isampler2DArray;
	precision ${i.precision} usampler2D;
	precision ${i.precision} usampler3D;
	precision ${i.precision} usamplerCube;
	precision ${i.precision} usampler2DArray;
	`;return i.precision==="highp"?e+=`
#define HIGH_PRECISION`:i.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:i.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}function Vx(i){let e="SHADOWMAP_TYPE_BASIC";return i.shadowMapType===Vh?e="SHADOWMAP_TYPE_PCF":i.shadowMapType===bp?e="SHADOWMAP_TYPE_PCF_SOFT":i.shadowMapType===ai&&(e="SHADOWMAP_TYPE_VSM"),e}function Hx(i){let e="ENVMAP_TYPE_CUBE";if(i.envMap)switch(i.envMapMode){case zr:case Vr:e="ENVMAP_TYPE_CUBE";break;case lo:e="ENVMAP_TYPE_CUBE_UV";break}return e}function Gx(i){let e="ENVMAP_MODE_REFLECTION";if(i.envMap)switch(i.envMapMode){case Vr:e="ENVMAP_MODE_REFRACTION";break}return e}function Wx(i){let e="ENVMAP_BLENDING_NONE";if(i.envMap)switch(i.combine){case Pc:e="ENVMAP_BLENDING_MULTIPLY";break;case zp:e="ENVMAP_BLENDING_MIX";break;case Vp:e="ENVMAP_BLENDING_ADD";break}return e}function Xx(i){const e=i.envMapCubeUVHeight;if(e===null)return null;const t=Math.log2(e)-2,n=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,t),112)),texelHeight:n,maxMip:t}}function qx(i,e,t,n){const r=i.getContext(),s=t.defines;let a=t.vertexShader,o=t.fragmentShader;const l=Vx(t),c=Hx(t),d=Gx(t),u=Wx(t),h=Xx(t),p=Dx(t),g=Nx(s),v=r.createProgram();let m,f,y=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(m=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g].filter(Es).join(`
`),m.length>0&&(m+=`
`),f=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g].filter(Es).join(`
`),f.length>0&&(f+=`
`)):(m=[Od(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.batchingColor?"#define USE_BATCHING_COLOR":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.instancingMorph?"#define USE_INSTANCING_MORPH":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+d:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Es).join(`
`),f=[Od(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+c:"",t.envMap?"#define "+d:"",t.envMap?"#define "+u:"",h?"#define CUBEUV_TEXEL_WIDTH "+h.texelWidth:"",h?"#define CUBEUV_TEXEL_HEIGHT "+h.texelHeight:"",h?"#define CUBEUV_MAX_MIP "+h.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.dispersion?"#define USE_DISPERSION":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor||t.batchingColor?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==Li?"#define TONE_MAPPING":"",t.toneMapping!==Li?Ze.tonemapping_pars_fragment:"",t.toneMapping!==Li?Px("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",Ze.colorspace_pars_fragment,Ix("linearToOutputTexel",t.outputColorSpace),Lx(),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(Es).join(`
`)),a=_c(a),a=Ld(a,t),a=Dd(a,t),o=_c(o),o=Ld(o,t),o=Dd(o,t),a=Nd(a),o=Nd(o),t.isRawShaderMaterial!==!0&&(y=`#version 300 es
`,m=[p,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+m,f=["#define varying in",t.glslVersion===wu?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===wu?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+f);const _=y+m+a,x=y+f+o,R=Cd(r,r.VERTEX_SHADER,_),M=Cd(r,r.FRAGMENT_SHADER,x);r.attachShader(v,R),r.attachShader(v,M),t.index0AttributeName!==void 0?r.bindAttribLocation(v,0,t.index0AttributeName):t.morphTargets===!0&&r.bindAttribLocation(v,0,"position"),r.linkProgram(v);function w(T){if(i.debug.checkShaderErrors){const D=r.getProgramInfoLog(v)||"",k=r.getShaderInfoLog(R)||"",z=r.getShaderInfoLog(M)||"",H=D.trim(),L=k.trim(),N=z.trim();let B=!0,V=!0;if(r.getProgramParameter(v,r.LINK_STATUS)===!1)if(B=!1,typeof i.debug.onShaderError=="function")i.debug.onShaderError(r,v,R,M);else{const Y=Pd(r,R,"vertex"),ee=Pd(r,M,"fragment");console.error("THREE.WebGLProgram: Shader Error "+r.getError()+" - VALIDATE_STATUS "+r.getProgramParameter(v,r.VALIDATE_STATUS)+`

Material Name: `+T.name+`
Material Type: `+T.type+`

Program Info Log: `+H+`
`+Y+`
`+ee)}else H!==""?console.warn("THREE.WebGLProgram: Program Info Log:",H):(L===""||N==="")&&(V=!1);V&&(T.diagnostics={runnable:B,programLog:H,vertexShader:{log:L,prefix:m},fragmentShader:{log:N,prefix:f}})}r.deleteShader(R),r.deleteShader(M),A=new Ha(r,v),S=Ox(r,v)}let A;this.getUniforms=function(){return A===void 0&&w(this),A};let S;this.getAttributes=function(){return S===void 0&&w(this),S};let b=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return b===!1&&(b=r.getProgramParameter(v,Ax)),b},this.destroy=function(){n.releaseStatesOfProgram(this),r.deleteProgram(v),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=wx++,this.cacheKey=e,this.usedTimes=1,this.program=v,this.vertexShader=R,this.fragmentShader=M,this}let Yx=0;class jx{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){const t=e.vertexShader,n=e.fragmentShader,r=this._getShaderStage(t),s=this._getShaderStage(n),a=this._getShaderCacheForMaterial(e);return a.has(r)===!1&&(a.add(r),r.usedTimes++),a.has(s)===!1&&(a.add(s),s.usedTimes++),this}remove(e){const t=this.materialCache.get(e);for(const n of t)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const t=this.materialCache;let n=t.get(e);return n===void 0&&(n=new Set,t.set(e,n)),n}_getShaderStage(e){const t=this.shaderCache;let n=t.get(e);return n===void 0&&(n=new $x(e),t.set(e,n)),n}}class $x{constructor(e){this.id=Yx++,this.code=e,this.usedTimes=0}}function Kx(i,e,t,n,r,s,a){const o=new Hc,l=new jx,c=new Set,d=[],u=r.logarithmicDepthBuffer,h=r.vertexTextures;let p=r.precision;const g={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function v(S){return c.add(S),S===0?"uv":`uv${S}`}function m(S,b,T,D,k){const z=D.fog,H=k.geometry,L=S.isMeshStandardMaterial?D.environment:null,N=(S.isMeshStandardMaterial?t:e).get(S.envMap||L),B=N&&N.mapping===lo?N.image.height:null,V=g[S.type];S.precision!==null&&(p=r.getMaxPrecision(S.precision),p!==S.precision&&console.warn("THREE.WebGLProgram.getParameters:",S.precision,"not supported, using",p,"instead."));const Y=H.morphAttributes.position||H.morphAttributes.normal||H.morphAttributes.color,ee=Y!==void 0?Y.length:0;let $=0;H.morphAttributes.position!==void 0&&($=1),H.morphAttributes.normal!==void 0&&($=2),H.morphAttributes.color!==void 0&&($=3);let re,te,F,O;if(V){const st=Xn[V];re=st.vertexShader,te=st.fragmentShader}else re=S.vertexShader,te=S.fragmentShader,l.update(S),F=l.getVertexShaderID(S),O=l.getFragmentShaderID(S);const G=i.getRenderTarget(),ne=i.state.buffers.depth.getReversed(),xe=k.isInstancedMesh===!0,fe=k.isBatchedMesh===!0,we=!!S.map,me=!!S.matcap,P=!!N,Le=!!S.aoMap,Te=!!S.lightMap,ge=!!S.bumpMap,ae=!!S.normalMap,ze=!!S.displacementMap,oe=!!S.emissiveMap,Se=!!S.metalnessMap,Ye=!!S.roughnessMap,De=S.anisotropy>0,I=S.clearcoat>0,E=S.dispersion>0,j=S.iridescence>0,Q=S.sheen>0,ie=S.transmission>0,K=De&&!!S.anisotropyMap,ye=I&&!!S.clearcoatMap,le=I&&!!S.clearcoatNormalMap,Ue=I&&!!S.clearcoatRoughnessMap,Fe=j&&!!S.iridescenceMap,de=j&&!!S.iridescenceThicknessMap,Ae=Q&&!!S.sheenColorMap,Ge=Q&&!!S.sheenRoughnessMap,Be=!!S.specularMap,Me=!!S.specularColorMap,Ke=!!S.specularIntensityMap,W=ie&&!!S.transmissionMap,he=ie&&!!S.thicknessMap,ve=!!S.gradientMap,Pe=!!S.alphaMap,ce=S.alphaTest>0,se=!!S.alphaHash,Oe=!!S.extensions;let je=Li;S.toneMapped&&(G===null||G.isXRRenderTarget===!0)&&(je=i.toneMapping);const gt={shaderID:V,shaderType:S.type,shaderName:S.name,vertexShader:re,fragmentShader:te,defines:S.defines,customVertexShaderID:F,customFragmentShaderID:O,isRawShaderMaterial:S.isRawShaderMaterial===!0,glslVersion:S.glslVersion,precision:p,batching:fe,batchingColor:fe&&k._colorsTexture!==null,instancing:xe,instancingColor:xe&&k.instanceColor!==null,instancingMorph:xe&&k.morphTexture!==null,supportsVertexTextures:h,outputColorSpace:G===null?i.outputColorSpace:G.isXRRenderTarget===!0?G.texture.colorSpace:nn,alphaToCoverage:!!S.alphaToCoverage,map:we,matcap:me,envMap:P,envMapMode:P&&N.mapping,envMapCubeUVHeight:B,aoMap:Le,lightMap:Te,bumpMap:ge,normalMap:ae,displacementMap:h&&ze,emissiveMap:oe,normalMapObjectSpace:ae&&S.normalMapType===Qp,normalMapTangentSpace:ae&&S.normalMapType===kc,metalnessMap:Se,roughnessMap:Ye,anisotropy:De,anisotropyMap:K,clearcoat:I,clearcoatMap:ye,clearcoatNormalMap:le,clearcoatRoughnessMap:Ue,dispersion:E,iridescence:j,iridescenceMap:Fe,iridescenceThicknessMap:de,sheen:Q,sheenColorMap:Ae,sheenRoughnessMap:Ge,specularMap:Be,specularColorMap:Me,specularIntensityMap:Ke,transmission:ie,transmissionMap:W,thicknessMap:he,gradientMap:ve,opaque:S.transparent===!1&&S.blending===Pi&&S.alphaToCoverage===!1,alphaMap:Pe,alphaTest:ce,alphaHash:se,combine:S.combine,mapUv:we&&v(S.map.channel),aoMapUv:Le&&v(S.aoMap.channel),lightMapUv:Te&&v(S.lightMap.channel),bumpMapUv:ge&&v(S.bumpMap.channel),normalMapUv:ae&&v(S.normalMap.channel),displacementMapUv:ze&&v(S.displacementMap.channel),emissiveMapUv:oe&&v(S.emissiveMap.channel),metalnessMapUv:Se&&v(S.metalnessMap.channel),roughnessMapUv:Ye&&v(S.roughnessMap.channel),anisotropyMapUv:K&&v(S.anisotropyMap.channel),clearcoatMapUv:ye&&v(S.clearcoatMap.channel),clearcoatNormalMapUv:le&&v(S.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Ue&&v(S.clearcoatRoughnessMap.channel),iridescenceMapUv:Fe&&v(S.iridescenceMap.channel),iridescenceThicknessMapUv:de&&v(S.iridescenceThicknessMap.channel),sheenColorMapUv:Ae&&v(S.sheenColorMap.channel),sheenRoughnessMapUv:Ge&&v(S.sheenRoughnessMap.channel),specularMapUv:Be&&v(S.specularMap.channel),specularColorMapUv:Me&&v(S.specularColorMap.channel),specularIntensityMapUv:Ke&&v(S.specularIntensityMap.channel),transmissionMapUv:W&&v(S.transmissionMap.channel),thicknessMapUv:he&&v(S.thicknessMap.channel),alphaMapUv:Pe&&v(S.alphaMap.channel),vertexTangents:!!H.attributes.tangent&&(ae||De),vertexColors:S.vertexColors,vertexAlphas:S.vertexColors===!0&&!!H.attributes.color&&H.attributes.color.itemSize===4,pointsUvs:k.isPoints===!0&&!!H.attributes.uv&&(we||Pe),fog:!!z,useFog:S.fog===!0,fogExp2:!!z&&z.isFogExp2,flatShading:S.flatShading===!0&&S.wireframe===!1,sizeAttenuation:S.sizeAttenuation===!0,logarithmicDepthBuffer:u,reversedDepthBuffer:ne,skinning:k.isSkinnedMesh===!0,morphTargets:H.morphAttributes.position!==void 0,morphNormals:H.morphAttributes.normal!==void 0,morphColors:H.morphAttributes.color!==void 0,morphTargetsCount:ee,morphTextureStride:$,numDirLights:b.directional.length,numPointLights:b.point.length,numSpotLights:b.spot.length,numSpotLightMaps:b.spotLightMap.length,numRectAreaLights:b.rectArea.length,numHemiLights:b.hemi.length,numDirLightShadows:b.directionalShadowMap.length,numPointLightShadows:b.pointShadowMap.length,numSpotLightShadows:b.spotShadowMap.length,numSpotLightShadowsWithMaps:b.numSpotLightShadowsWithMaps,numLightProbes:b.numLightProbes,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:S.dithering,shadowMapEnabled:i.shadowMap.enabled&&T.length>0,shadowMapType:i.shadowMap.type,toneMapping:je,decodeVideoTexture:we&&S.map.isVideoTexture===!0&&tt.getTransfer(S.map.colorSpace)===pt,decodeVideoTextureEmissive:oe&&S.emissiveMap.isVideoTexture===!0&&tt.getTransfer(S.emissiveMap.colorSpace)===pt,premultipliedAlpha:S.premultipliedAlpha,doubleSided:S.side===Et,flipSided:S.side===cn,useDepthPacking:S.depthPacking>=0,depthPacking:S.depthPacking||0,index0AttributeName:S.index0AttributeName,extensionClipCullDistance:Oe&&S.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Oe&&S.extensions.multiDraw===!0||fe)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:S.customProgramCacheKey()};return gt.vertexUv1s=c.has(1),gt.vertexUv2s=c.has(2),gt.vertexUv3s=c.has(3),c.clear(),gt}function f(S){const b=[];if(S.shaderID?b.push(S.shaderID):(b.push(S.customVertexShaderID),b.push(S.customFragmentShaderID)),S.defines!==void 0)for(const T in S.defines)b.push(T),b.push(S.defines[T]);return S.isRawShaderMaterial===!1&&(y(b,S),_(b,S),b.push(i.outputColorSpace)),b.push(S.customProgramCacheKey),b.join()}function y(S,b){S.push(b.precision),S.push(b.outputColorSpace),S.push(b.envMapMode),S.push(b.envMapCubeUVHeight),S.push(b.mapUv),S.push(b.alphaMapUv),S.push(b.lightMapUv),S.push(b.aoMapUv),S.push(b.bumpMapUv),S.push(b.normalMapUv),S.push(b.displacementMapUv),S.push(b.emissiveMapUv),S.push(b.metalnessMapUv),S.push(b.roughnessMapUv),S.push(b.anisotropyMapUv),S.push(b.clearcoatMapUv),S.push(b.clearcoatNormalMapUv),S.push(b.clearcoatRoughnessMapUv),S.push(b.iridescenceMapUv),S.push(b.iridescenceThicknessMapUv),S.push(b.sheenColorMapUv),S.push(b.sheenRoughnessMapUv),S.push(b.specularMapUv),S.push(b.specularColorMapUv),S.push(b.specularIntensityMapUv),S.push(b.transmissionMapUv),S.push(b.thicknessMapUv),S.push(b.combine),S.push(b.fogExp2),S.push(b.sizeAttenuation),S.push(b.morphTargetsCount),S.push(b.morphAttributeCount),S.push(b.numDirLights),S.push(b.numPointLights),S.push(b.numSpotLights),S.push(b.numSpotLightMaps),S.push(b.numHemiLights),S.push(b.numRectAreaLights),S.push(b.numDirLightShadows),S.push(b.numPointLightShadows),S.push(b.numSpotLightShadows),S.push(b.numSpotLightShadowsWithMaps),S.push(b.numLightProbes),S.push(b.shadowMapType),S.push(b.toneMapping),S.push(b.numClippingPlanes),S.push(b.numClipIntersection),S.push(b.depthPacking)}function _(S,b){o.disableAll(),b.supportsVertexTextures&&o.enable(0),b.instancing&&o.enable(1),b.instancingColor&&o.enable(2),b.instancingMorph&&o.enable(3),b.matcap&&o.enable(4),b.envMap&&o.enable(5),b.normalMapObjectSpace&&o.enable(6),b.normalMapTangentSpace&&o.enable(7),b.clearcoat&&o.enable(8),b.iridescence&&o.enable(9),b.alphaTest&&o.enable(10),b.vertexColors&&o.enable(11),b.vertexAlphas&&o.enable(12),b.vertexUv1s&&o.enable(13),b.vertexUv2s&&o.enable(14),b.vertexUv3s&&o.enable(15),b.vertexTangents&&o.enable(16),b.anisotropy&&o.enable(17),b.alphaHash&&o.enable(18),b.batching&&o.enable(19),b.dispersion&&o.enable(20),b.batchingColor&&o.enable(21),b.gradientMap&&o.enable(22),S.push(o.mask),o.disableAll(),b.fog&&o.enable(0),b.useFog&&o.enable(1),b.flatShading&&o.enable(2),b.logarithmicDepthBuffer&&o.enable(3),b.reversedDepthBuffer&&o.enable(4),b.skinning&&o.enable(5),b.morphTargets&&o.enable(6),b.morphNormals&&o.enable(7),b.morphColors&&o.enable(8),b.premultipliedAlpha&&o.enable(9),b.shadowMapEnabled&&o.enable(10),b.doubleSided&&o.enable(11),b.flipSided&&o.enable(12),b.useDepthPacking&&o.enable(13),b.dithering&&o.enable(14),b.transmission&&o.enable(15),b.sheen&&o.enable(16),b.opaque&&o.enable(17),b.pointsUvs&&o.enable(18),b.decodeVideoTexture&&o.enable(19),b.decodeVideoTextureEmissive&&o.enable(20),b.alphaToCoverage&&o.enable(21),S.push(o.mask)}function x(S){const b=g[S.type];let T;if(b){const D=Xn[b];T=Ya.clone(D.uniforms)}else T=S.uniforms;return T}function R(S,b){let T;for(let D=0,k=d.length;D<k;D++){const z=d[D];if(z.cacheKey===b){T=z,++T.usedTimes;break}}return T===void 0&&(T=new qx(i,b,S,s),d.push(T)),T}function M(S){if(--S.usedTimes===0){const b=d.indexOf(S);d[b]=d[d.length-1],d.pop(),S.destroy()}}function w(S){l.remove(S)}function A(){l.dispose()}return{getParameters:m,getProgramCacheKey:f,getUniforms:x,acquireProgram:R,releaseProgram:M,releaseShaderCache:w,programs:d,dispose:A}}function Zx(){let i=new WeakMap;function e(a){return i.has(a)}function t(a){let o=i.get(a);return o===void 0&&(o={},i.set(a,o)),o}function n(a){i.delete(a)}function r(a,o,l){i.get(a)[o]=l}function s(){i=new WeakMap}return{has:e,get:t,remove:n,update:r,dispose:s}}function Jx(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.material.id!==e.material.id?i.material.id-e.material.id:i.z!==e.z?i.z-e.z:i.id-e.id}function Ud(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.z!==e.z?e.z-i.z:i.id-e.id}function Fd(){const i=[];let e=0;const t=[],n=[],r=[];function s(){e=0,t.length=0,n.length=0,r.length=0}function a(u,h,p,g,v,m){let f=i[e];return f===void 0?(f={id:u.id,object:u,geometry:h,material:p,groupOrder:g,renderOrder:u.renderOrder,z:v,group:m},i[e]=f):(f.id=u.id,f.object=u,f.geometry=h,f.material=p,f.groupOrder=g,f.renderOrder=u.renderOrder,f.z=v,f.group=m),e++,f}function o(u,h,p,g,v,m){const f=a(u,h,p,g,v,m);p.transmission>0?n.push(f):p.transparent===!0?r.push(f):t.push(f)}function l(u,h,p,g,v,m){const f=a(u,h,p,g,v,m);p.transmission>0?n.unshift(f):p.transparent===!0?r.unshift(f):t.unshift(f)}function c(u,h){t.length>1&&t.sort(u||Jx),n.length>1&&n.sort(h||Ud),r.length>1&&r.sort(h||Ud)}function d(){for(let u=e,h=i.length;u<h;u++){const p=i[u];if(p.id===null)break;p.id=null,p.object=null,p.geometry=null,p.material=null,p.group=null}}return{opaque:t,transmissive:n,transparent:r,init:s,push:o,unshift:l,finish:d,sort:c}}function Qx(){let i=new WeakMap;function e(n,r){const s=i.get(n);let a;return s===void 0?(a=new Fd,i.set(n,[a])):r>=s.length?(a=new Fd,s.push(a)):a=s[r],a}function t(){i=new WeakMap}return{get:e,dispose:t}}function ey(){const i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"DirectionalLight":t={direction:new U,color:new Ie};break;case"SpotLight":t={position:new U,direction:new U,color:new Ie,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new U,color:new Ie,distance:0,decay:0};break;case"HemisphereLight":t={direction:new U,skyColor:new Ie,groundColor:new Ie};break;case"RectAreaLight":t={color:new Ie,position:new U,halfWidth:new U,halfHeight:new U};break}return i[e.id]=t,t}}}function ty(){const i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"DirectionalLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ce};break;case"SpotLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ce};break;case"PointLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ce,shadowCameraNear:1,shadowCameraFar:1e3};break}return i[e.id]=t,t}}}let ny=0;function iy(i,e){return(e.castShadow?2:0)-(i.castShadow?2:0)+(e.map?1:0)-(i.map?1:0)}function ry(i){const e=new ey,t=ty(),n={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let c=0;c<9;c++)n.probe.push(new U);const r=new U,s=new qe,a=new qe;function o(c){let d=0,u=0,h=0;for(let S=0;S<9;S++)n.probe[S].set(0,0,0);let p=0,g=0,v=0,m=0,f=0,y=0,_=0,x=0,R=0,M=0,w=0;c.sort(iy);for(let S=0,b=c.length;S<b;S++){const T=c[S],D=T.color,k=T.intensity,z=T.distance,H=T.shadow&&T.shadow.map?T.shadow.map.texture:null;if(T.isAmbientLight)d+=D.r*k,u+=D.g*k,h+=D.b*k;else if(T.isLightProbe){for(let L=0;L<9;L++)n.probe[L].addScaledVector(T.sh.coefficients[L],k);w++}else if(T.isDirectionalLight){const L=e.get(T);if(L.color.copy(T.color).multiplyScalar(T.intensity),T.castShadow){const N=T.shadow,B=t.get(T);B.shadowIntensity=N.intensity,B.shadowBias=N.bias,B.shadowNormalBias=N.normalBias,B.shadowRadius=N.radius,B.shadowMapSize=N.mapSize,n.directionalShadow[p]=B,n.directionalShadowMap[p]=H,n.directionalShadowMatrix[p]=T.shadow.matrix,y++}n.directional[p]=L,p++}else if(T.isSpotLight){const L=e.get(T);L.position.setFromMatrixPosition(T.matrixWorld),L.color.copy(D).multiplyScalar(k),L.distance=z,L.coneCos=Math.cos(T.angle),L.penumbraCos=Math.cos(T.angle*(1-T.penumbra)),L.decay=T.decay,n.spot[v]=L;const N=T.shadow;if(T.map&&(n.spotLightMap[R]=T.map,R++,N.updateMatrices(T),T.castShadow&&M++),n.spotLightMatrix[v]=N.matrix,T.castShadow){const B=t.get(T);B.shadowIntensity=N.intensity,B.shadowBias=N.bias,B.shadowNormalBias=N.normalBias,B.shadowRadius=N.radius,B.shadowMapSize=N.mapSize,n.spotShadow[v]=B,n.spotShadowMap[v]=H,x++}v++}else if(T.isRectAreaLight){const L=e.get(T);L.color.copy(D).multiplyScalar(k),L.halfWidth.set(T.width*.5,0,0),L.halfHeight.set(0,T.height*.5,0),n.rectArea[m]=L,m++}else if(T.isPointLight){const L=e.get(T);if(L.color.copy(T.color).multiplyScalar(T.intensity),L.distance=T.distance,L.decay=T.decay,T.castShadow){const N=T.shadow,B=t.get(T);B.shadowIntensity=N.intensity,B.shadowBias=N.bias,B.shadowNormalBias=N.normalBias,B.shadowRadius=N.radius,B.shadowMapSize=N.mapSize,B.shadowCameraNear=N.camera.near,B.shadowCameraFar=N.camera.far,n.pointShadow[g]=B,n.pointShadowMap[g]=H,n.pointShadowMatrix[g]=T.shadow.matrix,_++}n.point[g]=L,g++}else if(T.isHemisphereLight){const L=e.get(T);L.skyColor.copy(T.color).multiplyScalar(k),L.groundColor.copy(T.groundColor).multiplyScalar(k),n.hemi[f]=L,f++}}m>0&&(i.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=be.LTC_FLOAT_1,n.rectAreaLTC2=be.LTC_FLOAT_2):(n.rectAreaLTC1=be.LTC_HALF_1,n.rectAreaLTC2=be.LTC_HALF_2)),n.ambient[0]=d,n.ambient[1]=u,n.ambient[2]=h;const A=n.hash;(A.directionalLength!==p||A.pointLength!==g||A.spotLength!==v||A.rectAreaLength!==m||A.hemiLength!==f||A.numDirectionalShadows!==y||A.numPointShadows!==_||A.numSpotShadows!==x||A.numSpotMaps!==R||A.numLightProbes!==w)&&(n.directional.length=p,n.spot.length=v,n.rectArea.length=m,n.point.length=g,n.hemi.length=f,n.directionalShadow.length=y,n.directionalShadowMap.length=y,n.pointShadow.length=_,n.pointShadowMap.length=_,n.spotShadow.length=x,n.spotShadowMap.length=x,n.directionalShadowMatrix.length=y,n.pointShadowMatrix.length=_,n.spotLightMatrix.length=x+R-M,n.spotLightMap.length=R,n.numSpotLightShadowsWithMaps=M,n.numLightProbes=w,A.directionalLength=p,A.pointLength=g,A.spotLength=v,A.rectAreaLength=m,A.hemiLength=f,A.numDirectionalShadows=y,A.numPointShadows=_,A.numSpotShadows=x,A.numSpotMaps=R,A.numLightProbes=w,n.version=ny++)}function l(c,d){let u=0,h=0,p=0,g=0,v=0;const m=d.matrixWorldInverse;for(let f=0,y=c.length;f<y;f++){const _=c[f];if(_.isDirectionalLight){const x=n.directional[u];x.direction.setFromMatrixPosition(_.matrixWorld),r.setFromMatrixPosition(_.target.matrixWorld),x.direction.sub(r),x.direction.transformDirection(m),u++}else if(_.isSpotLight){const x=n.spot[p];x.position.setFromMatrixPosition(_.matrixWorld),x.position.applyMatrix4(m),x.direction.setFromMatrixPosition(_.matrixWorld),r.setFromMatrixPosition(_.target.matrixWorld),x.direction.sub(r),x.direction.transformDirection(m),p++}else if(_.isRectAreaLight){const x=n.rectArea[g];x.position.setFromMatrixPosition(_.matrixWorld),x.position.applyMatrix4(m),a.identity(),s.copy(_.matrixWorld),s.premultiply(m),a.extractRotation(s),x.halfWidth.set(_.width*.5,0,0),x.halfHeight.set(0,_.height*.5,0),x.halfWidth.applyMatrix4(a),x.halfHeight.applyMatrix4(a),g++}else if(_.isPointLight){const x=n.point[h];x.position.setFromMatrixPosition(_.matrixWorld),x.position.applyMatrix4(m),h++}else if(_.isHemisphereLight){const x=n.hemi[v];x.direction.setFromMatrixPosition(_.matrixWorld),x.direction.transformDirection(m),v++}}}return{setup:o,setupView:l,state:n}}function Bd(i){const e=new ry(i),t=[],n=[];function r(d){c.camera=d,t.length=0,n.length=0}function s(d){t.push(d)}function a(d){n.push(d)}function o(){e.setup(t)}function l(d){e.setupView(t,d)}const c={lightsArray:t,shadowsArray:n,camera:null,lights:e,transmissionRenderTarget:{}};return{init:r,state:c,setupLights:o,setupLightsView:l,pushLight:s,pushShadow:a}}function sy(i){let e=new WeakMap;function t(r,s=0){const a=e.get(r);let o;return a===void 0?(o=new Bd(i),e.set(r,[o])):s>=a.length?(o=new Bd(i),a.push(o)):o=a[s],o}function n(){e=new WeakMap}return{get:t,dispose:n}}const ay=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,oy=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function ly(i,e,t){let n=new Wc;const r=new Ce,s=new Ce,a=new rt,o=new ig({depthPacking:Jp}),l=new rg,c={},d=t.maxTextureSize,u={[mi]:cn,[cn]:mi,[Et]:Et},h=new Rt({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Ce},radius:{value:4}},vertexShader:ay,fragmentShader:oy}),p=h.clone();p.defines.HORIZONTAL_PASS=1;const g=new Lt;g.setAttribute("position",new ct(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const v=new ht(g,h),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Vh;let f=this.type;this.render=function(M,w,A){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||M.length===0)return;const S=i.getRenderTarget(),b=i.getActiveCubeFace(),T=i.getActiveMipmapLevel(),D=i.state;D.setBlending(hi),D.buffers.depth.getReversed()===!0?D.buffers.color.setClear(0,0,0,0):D.buffers.color.setClear(1,1,1,1),D.buffers.depth.setTest(!0),D.setScissorTest(!1);const k=f!==ai&&this.type===ai,z=f===ai&&this.type!==ai;for(let H=0,L=M.length;H<L;H++){const N=M[H],B=N.shadow;if(B===void 0){console.warn("THREE.WebGLShadowMap:",N,"has no shadow.");continue}if(B.autoUpdate===!1&&B.needsUpdate===!1)continue;r.copy(B.mapSize);const V=B.getFrameExtents();if(r.multiply(V),s.copy(B.mapSize),(r.x>d||r.y>d)&&(r.x>d&&(s.x=Math.floor(d/V.x),r.x=s.x*V.x,B.mapSize.x=s.x),r.y>d&&(s.y=Math.floor(d/V.y),r.y=s.y*V.y,B.mapSize.y=s.y)),B.map===null||k===!0||z===!0){const ee=this.type!==ai?{minFilter:en,magFilter:en}:{};B.map!==null&&B.map.dispose(),B.map=new zn(r.x,r.y,ee),B.map.texture.name=N.name+".shadowMap",B.camera.updateProjectionMatrix()}i.setRenderTarget(B.map),i.clear();const Y=B.getViewportCount();for(let ee=0;ee<Y;ee++){const $=B.getViewport(ee);a.set(s.x*$.x,s.y*$.y,s.x*$.z,s.y*$.w),D.viewport(a),B.updateMatrices(N,ee),n=B.getFrustum(),x(w,A,B.camera,N,this.type)}B.isPointLightShadow!==!0&&this.type===ai&&y(B,A),B.needsUpdate=!1}f=this.type,m.needsUpdate=!1,i.setRenderTarget(S,b,T)};function y(M,w){const A=e.update(v);h.defines.VSM_SAMPLES!==M.blurSamples&&(h.defines.VSM_SAMPLES=M.blurSamples,p.defines.VSM_SAMPLES=M.blurSamples,h.needsUpdate=!0,p.needsUpdate=!0),M.mapPass===null&&(M.mapPass=new zn(r.x,r.y)),h.uniforms.shadow_pass.value=M.map.texture,h.uniforms.resolution.value=M.mapSize,h.uniforms.radius.value=M.radius,i.setRenderTarget(M.mapPass),i.clear(),i.renderBufferDirect(w,null,A,h,v,null),p.uniforms.shadow_pass.value=M.mapPass.texture,p.uniforms.resolution.value=M.mapSize,p.uniforms.radius.value=M.radius,i.setRenderTarget(M.map),i.clear(),i.renderBufferDirect(w,null,A,p,v,null)}function _(M,w,A,S){let b=null;const T=A.isPointLight===!0?M.customDistanceMaterial:M.customDepthMaterial;if(T!==void 0)b=T;else if(b=A.isPointLight===!0?l:o,i.localClippingEnabled&&w.clipShadows===!0&&Array.isArray(w.clippingPlanes)&&w.clippingPlanes.length!==0||w.displacementMap&&w.displacementScale!==0||w.alphaMap&&w.alphaTest>0||w.map&&w.alphaTest>0||w.alphaToCoverage===!0){const D=b.uuid,k=w.uuid;let z=c[D];z===void 0&&(z={},c[D]=z);let H=z[k];H===void 0&&(H=b.clone(),z[k]=H,w.addEventListener("dispose",R)),b=H}if(b.visible=w.visible,b.wireframe=w.wireframe,S===ai?b.side=w.shadowSide!==null?w.shadowSide:w.side:b.side=w.shadowSide!==null?w.shadowSide:u[w.side],b.alphaMap=w.alphaMap,b.alphaTest=w.alphaToCoverage===!0?.5:w.alphaTest,b.map=w.map,b.clipShadows=w.clipShadows,b.clippingPlanes=w.clippingPlanes,b.clipIntersection=w.clipIntersection,b.displacementMap=w.displacementMap,b.displacementScale=w.displacementScale,b.displacementBias=w.displacementBias,b.wireframeLinewidth=w.wireframeLinewidth,b.linewidth=w.linewidth,A.isPointLight===!0&&b.isMeshDistanceMaterial===!0){const D=i.properties.get(b);D.light=A}return b}function x(M,w,A,S,b){if(M.visible===!1)return;if(M.layers.test(w.layers)&&(M.isMesh||M.isLine||M.isPoints)&&(M.castShadow||M.receiveShadow&&b===ai)&&(!M.frustumCulled||n.intersectsObject(M))){M.modelViewMatrix.multiplyMatrices(A.matrixWorldInverse,M.matrixWorld);const k=e.update(M),z=M.material;if(Array.isArray(z)){const H=k.groups;for(let L=0,N=H.length;L<N;L++){const B=H[L],V=z[B.materialIndex];if(V&&V.visible){const Y=_(M,V,S,b);M.onBeforeShadow(i,M,w,A,k,Y,B),i.renderBufferDirect(A,null,k,Y,M,B),M.onAfterShadow(i,M,w,A,k,Y,B)}}}else if(z.visible){const H=_(M,z,S,b);M.onBeforeShadow(i,M,w,A,k,H,null),i.renderBufferDirect(A,null,k,H,M,null),M.onAfterShadow(i,M,w,A,k,H,null)}}const D=M.children;for(let k=0,z=D.length;k<z;k++)x(D[k],w,A,S,b)}function R(M){M.target.removeEventListener("dispose",R);for(const A in c){const S=c[A],b=M.target.uuid;b in S&&(S[b].dispose(),delete S[b])}}}const cy={[Pl]:Ll,[Dl]:Ul,[Nl]:Fl,[kr]:Ol,[Ll]:Pl,[Ul]:Dl,[Fl]:Nl,[Ol]:kr};function uy(i,e){function t(){let W=!1;const he=new rt;let ve=null;const Pe=new rt(0,0,0,0);return{setMask:function(ce){ve!==ce&&!W&&(i.colorMask(ce,ce,ce,ce),ve=ce)},setLocked:function(ce){W=ce},setClear:function(ce,se,Oe,je,gt){gt===!0&&(ce*=je,se*=je,Oe*=je),he.set(ce,se,Oe,je),Pe.equals(he)===!1&&(i.clearColor(ce,se,Oe,je),Pe.copy(he))},reset:function(){W=!1,ve=null,Pe.set(-1,0,0,0)}}}function n(){let W=!1,he=!1,ve=null,Pe=null,ce=null;return{setReversed:function(se){if(he!==se){const Oe=e.get("EXT_clip_control");se?Oe.clipControlEXT(Oe.LOWER_LEFT_EXT,Oe.ZERO_TO_ONE_EXT):Oe.clipControlEXT(Oe.LOWER_LEFT_EXT,Oe.NEGATIVE_ONE_TO_ONE_EXT),he=se;const je=ce;ce=null,this.setClear(je)}},getReversed:function(){return he},setTest:function(se){se?G(i.DEPTH_TEST):ne(i.DEPTH_TEST)},setMask:function(se){ve!==se&&!W&&(i.depthMask(se),ve=se)},setFunc:function(se){if(he&&(se=cy[se]),Pe!==se){switch(se){case Pl:i.depthFunc(i.NEVER);break;case Ll:i.depthFunc(i.ALWAYS);break;case Dl:i.depthFunc(i.LESS);break;case kr:i.depthFunc(i.LEQUAL);break;case Nl:i.depthFunc(i.EQUAL);break;case Ol:i.depthFunc(i.GEQUAL);break;case Ul:i.depthFunc(i.GREATER);break;case Fl:i.depthFunc(i.NOTEQUAL);break;default:i.depthFunc(i.LEQUAL)}Pe=se}},setLocked:function(se){W=se},setClear:function(se){ce!==se&&(he&&(se=1-se),i.clearDepth(se),ce=se)},reset:function(){W=!1,ve=null,Pe=null,ce=null,he=!1}}}function r(){let W=!1,he=null,ve=null,Pe=null,ce=null,se=null,Oe=null,je=null,gt=null;return{setTest:function(st){W||(st?G(i.STENCIL_TEST):ne(i.STENCIL_TEST))},setMask:function(st){he!==st&&!W&&(i.stencilMask(st),he=st)},setFunc:function(st,Zn,Hn){(ve!==st||Pe!==Zn||ce!==Hn)&&(i.stencilFunc(st,Zn,Hn),ve=st,Pe=Zn,ce=Hn)},setOp:function(st,Zn,Hn){(se!==st||Oe!==Zn||je!==Hn)&&(i.stencilOp(st,Zn,Hn),se=st,Oe=Zn,je=Hn)},setLocked:function(st){W=st},setClear:function(st){gt!==st&&(i.clearStencil(st),gt=st)},reset:function(){W=!1,he=null,ve=null,Pe=null,ce=null,se=null,Oe=null,je=null,gt=null}}}const s=new t,a=new n,o=new r,l=new WeakMap,c=new WeakMap;let d={},u={},h=new WeakMap,p=[],g=null,v=!1,m=null,f=null,y=null,_=null,x=null,R=null,M=null,w=new Ie(0,0,0),A=0,S=!1,b=null,T=null,D=null,k=null,z=null;const H=i.getParameter(i.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let L=!1,N=0;const B=i.getParameter(i.VERSION);B.indexOf("WebGL")!==-1?(N=parseFloat(/^WebGL (\d)/.exec(B)[1]),L=N>=1):B.indexOf("OpenGL ES")!==-1&&(N=parseFloat(/^OpenGL ES (\d)/.exec(B)[1]),L=N>=2);let V=null,Y={};const ee=i.getParameter(i.SCISSOR_BOX),$=i.getParameter(i.VIEWPORT),re=new rt().fromArray(ee),te=new rt().fromArray($);function F(W,he,ve,Pe){const ce=new Uint8Array(4),se=i.createTexture();i.bindTexture(W,se),i.texParameteri(W,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(W,i.TEXTURE_MAG_FILTER,i.NEAREST);for(let Oe=0;Oe<ve;Oe++)W===i.TEXTURE_3D||W===i.TEXTURE_2D_ARRAY?i.texImage3D(he,0,i.RGBA,1,1,Pe,0,i.RGBA,i.UNSIGNED_BYTE,ce):i.texImage2D(he+Oe,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,ce);return se}const O={};O[i.TEXTURE_2D]=F(i.TEXTURE_2D,i.TEXTURE_2D,1),O[i.TEXTURE_CUBE_MAP]=F(i.TEXTURE_CUBE_MAP,i.TEXTURE_CUBE_MAP_POSITIVE_X,6),O[i.TEXTURE_2D_ARRAY]=F(i.TEXTURE_2D_ARRAY,i.TEXTURE_2D_ARRAY,1,1),O[i.TEXTURE_3D]=F(i.TEXTURE_3D,i.TEXTURE_3D,1,1),s.setClear(0,0,0,1),a.setClear(1),o.setClear(0),G(i.DEPTH_TEST),a.setFunc(kr),ge(!1),ae(xu),G(i.CULL_FACE),Le(hi);function G(W){d[W]!==!0&&(i.enable(W),d[W]=!0)}function ne(W){d[W]!==!1&&(i.disable(W),d[W]=!1)}function xe(W,he){return u[W]!==he?(i.bindFramebuffer(W,he),u[W]=he,W===i.DRAW_FRAMEBUFFER&&(u[i.FRAMEBUFFER]=he),W===i.FRAMEBUFFER&&(u[i.DRAW_FRAMEBUFFER]=he),!0):!1}function fe(W,he){let ve=p,Pe=!1;if(W){ve=h.get(he),ve===void 0&&(ve=[],h.set(he,ve));const ce=W.textures;if(ve.length!==ce.length||ve[0]!==i.COLOR_ATTACHMENT0){for(let se=0,Oe=ce.length;se<Oe;se++)ve[se]=i.COLOR_ATTACHMENT0+se;ve.length=ce.length,Pe=!0}}else ve[0]!==i.BACK&&(ve[0]=i.BACK,Pe=!0);Pe&&i.drawBuffers(ve)}function we(W){return g!==W?(i.useProgram(W),g=W,!0):!1}const me={[$i]:i.FUNC_ADD,[Mp]:i.FUNC_SUBTRACT,[Ep]:i.FUNC_REVERSE_SUBTRACT};me[Tp]=i.MIN,me[Ap]=i.MAX;const P={[wp]:i.ZERO,[Rp]:i.ONE,[Cp]:i.SRC_COLOR,[Cl]:i.SRC_ALPHA,[Op]:i.SRC_ALPHA_SATURATE,[Dp]:i.DST_COLOR,[Pp]:i.DST_ALPHA,[Ip]:i.ONE_MINUS_SRC_COLOR,[Il]:i.ONE_MINUS_SRC_ALPHA,[Np]:i.ONE_MINUS_DST_COLOR,[Lp]:i.ONE_MINUS_DST_ALPHA,[Up]:i.CONSTANT_COLOR,[Fp]:i.ONE_MINUS_CONSTANT_COLOR,[Bp]:i.CONSTANT_ALPHA,[kp]:i.ONE_MINUS_CONSTANT_ALPHA};function Le(W,he,ve,Pe,ce,se,Oe,je,gt,st){if(W===hi){v===!0&&(ne(i.BLEND),v=!1);return}if(v===!1&&(G(i.BLEND),v=!0),W!==Sp){if(W!==m||st!==S){if((f!==$i||x!==$i)&&(i.blendEquation(i.FUNC_ADD),f=$i,x=$i),st)switch(W){case Pi:i.blendFuncSeparate(i.ONE,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case tn:i.blendFunc(i.ONE,i.ONE);break;case yu:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case bu:i.blendFuncSeparate(i.DST_COLOR,i.ONE_MINUS_SRC_ALPHA,i.ZERO,i.ONE);break;default:console.error("THREE.WebGLState: Invalid blending: ",W);break}else switch(W){case Pi:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case tn:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE,i.ONE,i.ONE);break;case yu:console.error("THREE.WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case bu:console.error("THREE.WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:console.error("THREE.WebGLState: Invalid blending: ",W);break}y=null,_=null,R=null,M=null,w.set(0,0,0),A=0,m=W,S=st}return}ce=ce||he,se=se||ve,Oe=Oe||Pe,(he!==f||ce!==x)&&(i.blendEquationSeparate(me[he],me[ce]),f=he,x=ce),(ve!==y||Pe!==_||se!==R||Oe!==M)&&(i.blendFuncSeparate(P[ve],P[Pe],P[se],P[Oe]),y=ve,_=Pe,R=se,M=Oe),(je.equals(w)===!1||gt!==A)&&(i.blendColor(je.r,je.g,je.b,gt),w.copy(je),A=gt),m=W,S=!1}function Te(W,he){W.side===Et?ne(i.CULL_FACE):G(i.CULL_FACE);let ve=W.side===cn;he&&(ve=!ve),ge(ve),W.blending===Pi&&W.transparent===!1?Le(hi):Le(W.blending,W.blendEquation,W.blendSrc,W.blendDst,W.blendEquationAlpha,W.blendSrcAlpha,W.blendDstAlpha,W.blendColor,W.blendAlpha,W.premultipliedAlpha),a.setFunc(W.depthFunc),a.setTest(W.depthTest),a.setMask(W.depthWrite),s.setMask(W.colorWrite);const Pe=W.stencilWrite;o.setTest(Pe),Pe&&(o.setMask(W.stencilWriteMask),o.setFunc(W.stencilFunc,W.stencilRef,W.stencilFuncMask),o.setOp(W.stencilFail,W.stencilZFail,W.stencilZPass)),oe(W.polygonOffset,W.polygonOffsetFactor,W.polygonOffsetUnits),W.alphaToCoverage===!0?G(i.SAMPLE_ALPHA_TO_COVERAGE):ne(i.SAMPLE_ALPHA_TO_COVERAGE)}function ge(W){b!==W&&(W?i.frontFace(i.CW):i.frontFace(i.CCW),b=W)}function ae(W){W!==xp?(G(i.CULL_FACE),W!==T&&(W===xu?i.cullFace(i.BACK):W===yp?i.cullFace(i.FRONT):i.cullFace(i.FRONT_AND_BACK))):ne(i.CULL_FACE),T=W}function ze(W){W!==D&&(L&&i.lineWidth(W),D=W)}function oe(W,he,ve){W?(G(i.POLYGON_OFFSET_FILL),(k!==he||z!==ve)&&(i.polygonOffset(he,ve),k=he,z=ve)):ne(i.POLYGON_OFFSET_FILL)}function Se(W){W?G(i.SCISSOR_TEST):ne(i.SCISSOR_TEST)}function Ye(W){W===void 0&&(W=i.TEXTURE0+H-1),V!==W&&(i.activeTexture(W),V=W)}function De(W,he,ve){ve===void 0&&(V===null?ve=i.TEXTURE0+H-1:ve=V);let Pe=Y[ve];Pe===void 0&&(Pe={type:void 0,texture:void 0},Y[ve]=Pe),(Pe.type!==W||Pe.texture!==he)&&(V!==ve&&(i.activeTexture(ve),V=ve),i.bindTexture(W,he||O[W]),Pe.type=W,Pe.texture=he)}function I(){const W=Y[V];W!==void 0&&W.type!==void 0&&(i.bindTexture(W.type,null),W.type=void 0,W.texture=void 0)}function E(){try{i.compressedTexImage2D(...arguments)}catch(W){console.error("THREE.WebGLState:",W)}}function j(){try{i.compressedTexImage3D(...arguments)}catch(W){console.error("THREE.WebGLState:",W)}}function Q(){try{i.texSubImage2D(...arguments)}catch(W){console.error("THREE.WebGLState:",W)}}function ie(){try{i.texSubImage3D(...arguments)}catch(W){console.error("THREE.WebGLState:",W)}}function K(){try{i.compressedTexSubImage2D(...arguments)}catch(W){console.error("THREE.WebGLState:",W)}}function ye(){try{i.compressedTexSubImage3D(...arguments)}catch(W){console.error("THREE.WebGLState:",W)}}function le(){try{i.texStorage2D(...arguments)}catch(W){console.error("THREE.WebGLState:",W)}}function Ue(){try{i.texStorage3D(...arguments)}catch(W){console.error("THREE.WebGLState:",W)}}function Fe(){try{i.texImage2D(...arguments)}catch(W){console.error("THREE.WebGLState:",W)}}function de(){try{i.texImage3D(...arguments)}catch(W){console.error("THREE.WebGLState:",W)}}function Ae(W){re.equals(W)===!1&&(i.scissor(W.x,W.y,W.z,W.w),re.copy(W))}function Ge(W){te.equals(W)===!1&&(i.viewport(W.x,W.y,W.z,W.w),te.copy(W))}function Be(W,he){let ve=c.get(he);ve===void 0&&(ve=new WeakMap,c.set(he,ve));let Pe=ve.get(W);Pe===void 0&&(Pe=i.getUniformBlockIndex(he,W.name),ve.set(W,Pe))}function Me(W,he){const Pe=c.get(he).get(W);l.get(he)!==Pe&&(i.uniformBlockBinding(he,Pe,W.__bindingPointIndex),l.set(he,Pe))}function Ke(){i.disable(i.BLEND),i.disable(i.CULL_FACE),i.disable(i.DEPTH_TEST),i.disable(i.POLYGON_OFFSET_FILL),i.disable(i.SCISSOR_TEST),i.disable(i.STENCIL_TEST),i.disable(i.SAMPLE_ALPHA_TO_COVERAGE),i.blendEquation(i.FUNC_ADD),i.blendFunc(i.ONE,i.ZERO),i.blendFuncSeparate(i.ONE,i.ZERO,i.ONE,i.ZERO),i.blendColor(0,0,0,0),i.colorMask(!0,!0,!0,!0),i.clearColor(0,0,0,0),i.depthMask(!0),i.depthFunc(i.LESS),a.setReversed(!1),i.clearDepth(1),i.stencilMask(4294967295),i.stencilFunc(i.ALWAYS,0,4294967295),i.stencilOp(i.KEEP,i.KEEP,i.KEEP),i.clearStencil(0),i.cullFace(i.BACK),i.frontFace(i.CCW),i.polygonOffset(0,0),i.activeTexture(i.TEXTURE0),i.bindFramebuffer(i.FRAMEBUFFER,null),i.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),i.bindFramebuffer(i.READ_FRAMEBUFFER,null),i.useProgram(null),i.lineWidth(1),i.scissor(0,0,i.canvas.width,i.canvas.height),i.viewport(0,0,i.canvas.width,i.canvas.height),d={},V=null,Y={},u={},h=new WeakMap,p=[],g=null,v=!1,m=null,f=null,y=null,_=null,x=null,R=null,M=null,w=new Ie(0,0,0),A=0,S=!1,b=null,T=null,D=null,k=null,z=null,re.set(0,0,i.canvas.width,i.canvas.height),te.set(0,0,i.canvas.width,i.canvas.height),s.reset(),a.reset(),o.reset()}return{buffers:{color:s,depth:a,stencil:o},enable:G,disable:ne,bindFramebuffer:xe,drawBuffers:fe,useProgram:we,setBlending:Le,setMaterial:Te,setFlipSided:ge,setCullFace:ae,setLineWidth:ze,setPolygonOffset:oe,setScissorTest:Se,activeTexture:Ye,bindTexture:De,unbindTexture:I,compressedTexImage2D:E,compressedTexImage3D:j,texImage2D:Fe,texImage3D:de,updateUBOMapping:Be,uniformBlockBinding:Me,texStorage2D:le,texStorage3D:Ue,texSubImage2D:Q,texSubImage3D:ie,compressedTexSubImage2D:K,compressedTexSubImage3D:ye,scissor:Ae,viewport:Ge,reset:Ke}}function dy(i,e,t,n,r,s,a){const o=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),c=new Ce,d=new WeakMap;let u;const h=new WeakMap;let p=!1;try{p=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function g(I,E){return p?new OffscreenCanvas(I,E):Us("canvas")}function v(I,E,j){let Q=1;const ie=De(I);if((ie.width>j||ie.height>j)&&(Q=j/Math.max(ie.width,ie.height)),Q<1)if(typeof HTMLImageElement<"u"&&I instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&I instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&I instanceof ImageBitmap||typeof VideoFrame<"u"&&I instanceof VideoFrame){const K=Math.floor(Q*ie.width),ye=Math.floor(Q*ie.height);u===void 0&&(u=g(K,ye));const le=E?g(K,ye):u;return le.width=K,le.height=ye,le.getContext("2d").drawImage(I,0,0,K,ye),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+ie.width+"x"+ie.height+") to ("+K+"x"+ye+")."),le}else return"data"in I&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+ie.width+"x"+ie.height+")."),I;return I}function m(I){return I.generateMipmaps}function f(I){i.generateMipmap(I)}function y(I){return I.isWebGLCubeRenderTarget?i.TEXTURE_CUBE_MAP:I.isWebGL3DRenderTarget?i.TEXTURE_3D:I.isWebGLArrayRenderTarget||I.isCompressedArrayTexture?i.TEXTURE_2D_ARRAY:i.TEXTURE_2D}function _(I,E,j,Q,ie=!1){if(I!==null){if(i[I]!==void 0)return i[I];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+I+"'")}let K=E;if(E===i.RED&&(j===i.FLOAT&&(K=i.R32F),j===i.HALF_FLOAT&&(K=i.R16F),j===i.UNSIGNED_BYTE&&(K=i.R8)),E===i.RED_INTEGER&&(j===i.UNSIGNED_BYTE&&(K=i.R8UI),j===i.UNSIGNED_SHORT&&(K=i.R16UI),j===i.UNSIGNED_INT&&(K=i.R32UI),j===i.BYTE&&(K=i.R8I),j===i.SHORT&&(K=i.R16I),j===i.INT&&(K=i.R32I)),E===i.RG&&(j===i.FLOAT&&(K=i.RG32F),j===i.HALF_FLOAT&&(K=i.RG16F),j===i.UNSIGNED_BYTE&&(K=i.RG8)),E===i.RG_INTEGER&&(j===i.UNSIGNED_BYTE&&(K=i.RG8UI),j===i.UNSIGNED_SHORT&&(K=i.RG16UI),j===i.UNSIGNED_INT&&(K=i.RG32UI),j===i.BYTE&&(K=i.RG8I),j===i.SHORT&&(K=i.RG16I),j===i.INT&&(K=i.RG32I)),E===i.RGB_INTEGER&&(j===i.UNSIGNED_BYTE&&(K=i.RGB8UI),j===i.UNSIGNED_SHORT&&(K=i.RGB16UI),j===i.UNSIGNED_INT&&(K=i.RGB32UI),j===i.BYTE&&(K=i.RGB8I),j===i.SHORT&&(K=i.RGB16I),j===i.INT&&(K=i.RGB32I)),E===i.RGBA_INTEGER&&(j===i.UNSIGNED_BYTE&&(K=i.RGBA8UI),j===i.UNSIGNED_SHORT&&(K=i.RGBA16UI),j===i.UNSIGNED_INT&&(K=i.RGBA32UI),j===i.BYTE&&(K=i.RGBA8I),j===i.SHORT&&(K=i.RGBA16I),j===i.INT&&(K=i.RGBA32I)),E===i.RGB&&(j===i.UNSIGNED_INT_5_9_9_9_REV&&(K=i.RGB9_E5),j===i.UNSIGNED_INT_10F_11F_11F_REV&&(K=i.R11F_G11F_B10F)),E===i.RGBA){const ye=ie?Xa:tt.getTransfer(Q);j===i.FLOAT&&(K=i.RGBA32F),j===i.HALF_FLOAT&&(K=i.RGBA16F),j===i.UNSIGNED_BYTE&&(K=ye===pt?i.SRGB8_ALPHA8:i.RGBA8),j===i.UNSIGNED_SHORT_4_4_4_4&&(K=i.RGBA4),j===i.UNSIGNED_SHORT_5_5_5_1&&(K=i.RGB5_A1)}return(K===i.R16F||K===i.R32F||K===i.RG16F||K===i.RG32F||K===i.RGBA16F||K===i.RGBA32F)&&e.get("EXT_color_buffer_float"),K}function x(I,E){let j;return I?E===null||E===Ji||E===Ps?j=i.DEPTH24_STENCIL8:E===Bn?j=i.DEPTH32F_STENCIL8:E===Is&&(j=i.DEPTH24_STENCIL8,console.warn("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):E===null||E===Ji||E===Ps?j=i.DEPTH_COMPONENT24:E===Bn?j=i.DEPTH_COMPONENT32F:E===Is&&(j=i.DEPTH_COMPONENT16),j}function R(I,E){return m(I)===!0||I.isFramebufferTexture&&I.minFilter!==en&&I.minFilter!==Dt?Math.log2(Math.max(E.width,E.height))+1:I.mipmaps!==void 0&&I.mipmaps.length>0?I.mipmaps.length:I.isCompressedTexture&&Array.isArray(I.image)?E.mipmaps.length:1}function M(I){const E=I.target;E.removeEventListener("dispose",M),A(E),E.isVideoTexture&&d.delete(E)}function w(I){const E=I.target;E.removeEventListener("dispose",w),b(E)}function A(I){const E=n.get(I);if(E.__webglInit===void 0)return;const j=I.source,Q=h.get(j);if(Q){const ie=Q[E.__cacheKey];ie.usedTimes--,ie.usedTimes===0&&S(I),Object.keys(Q).length===0&&h.delete(j)}n.remove(I)}function S(I){const E=n.get(I);i.deleteTexture(E.__webglTexture);const j=I.source,Q=h.get(j);delete Q[E.__cacheKey],a.memory.textures--}function b(I){const E=n.get(I);if(I.depthTexture&&(I.depthTexture.dispose(),n.remove(I.depthTexture)),I.isWebGLCubeRenderTarget)for(let Q=0;Q<6;Q++){if(Array.isArray(E.__webglFramebuffer[Q]))for(let ie=0;ie<E.__webglFramebuffer[Q].length;ie++)i.deleteFramebuffer(E.__webglFramebuffer[Q][ie]);else i.deleteFramebuffer(E.__webglFramebuffer[Q]);E.__webglDepthbuffer&&i.deleteRenderbuffer(E.__webglDepthbuffer[Q])}else{if(Array.isArray(E.__webglFramebuffer))for(let Q=0;Q<E.__webglFramebuffer.length;Q++)i.deleteFramebuffer(E.__webglFramebuffer[Q]);else i.deleteFramebuffer(E.__webglFramebuffer);if(E.__webglDepthbuffer&&i.deleteRenderbuffer(E.__webglDepthbuffer),E.__webglMultisampledFramebuffer&&i.deleteFramebuffer(E.__webglMultisampledFramebuffer),E.__webglColorRenderbuffer)for(let Q=0;Q<E.__webglColorRenderbuffer.length;Q++)E.__webglColorRenderbuffer[Q]&&i.deleteRenderbuffer(E.__webglColorRenderbuffer[Q]);E.__webglDepthRenderbuffer&&i.deleteRenderbuffer(E.__webglDepthRenderbuffer)}const j=I.textures;for(let Q=0,ie=j.length;Q<ie;Q++){const K=n.get(j[Q]);K.__webglTexture&&(i.deleteTexture(K.__webglTexture),a.memory.textures--),n.remove(j[Q])}n.remove(I)}let T=0;function D(){T=0}function k(){const I=T;return I>=r.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+I+" texture units while this GPU supports only "+r.maxTextures),T+=1,I}function z(I){const E=[];return E.push(I.wrapS),E.push(I.wrapT),E.push(I.wrapR||0),E.push(I.magFilter),E.push(I.minFilter),E.push(I.anisotropy),E.push(I.internalFormat),E.push(I.format),E.push(I.type),E.push(I.generateMipmaps),E.push(I.premultiplyAlpha),E.push(I.flipY),E.push(I.unpackAlignment),E.push(I.colorSpace),E.join()}function H(I,E){const j=n.get(I);if(I.isVideoTexture&&Se(I),I.isRenderTargetTexture===!1&&I.isExternalTexture!==!0&&I.version>0&&j.__version!==I.version){const Q=I.image;if(Q===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(Q.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{O(j,I,E);return}}else I.isExternalTexture&&(j.__webglTexture=I.sourceTexture?I.sourceTexture:null);t.bindTexture(i.TEXTURE_2D,j.__webglTexture,i.TEXTURE0+E)}function L(I,E){const j=n.get(I);if(I.isRenderTargetTexture===!1&&I.version>0&&j.__version!==I.version){O(j,I,E);return}t.bindTexture(i.TEXTURE_2D_ARRAY,j.__webglTexture,i.TEXTURE0+E)}function N(I,E){const j=n.get(I);if(I.isRenderTargetTexture===!1&&I.version>0&&j.__version!==I.version){O(j,I,E);return}t.bindTexture(i.TEXTURE_3D,j.__webglTexture,i.TEXTURE0+E)}function B(I,E){const j=n.get(I);if(I.version>0&&j.__version!==I.version){G(j,I,E);return}t.bindTexture(i.TEXTURE_CUBE_MAP,j.__webglTexture,i.TEXTURE0+E)}const V={[Hr]:i.REPEAT,[Ii]:i.CLAMP_TO_EDGE,[Wa]:i.MIRRORED_REPEAT},Y={[en]:i.NEAREST,[Wh]:i.NEAREST_MIPMAP_NEAREST,[Ms]:i.NEAREST_MIPMAP_LINEAR,[Dt]:i.LINEAR,[Fa]:i.LINEAR_MIPMAP_NEAREST,[Gt]:i.LINEAR_MIPMAP_LINEAR},ee={[em]:i.NEVER,[am]:i.ALWAYS,[tm]:i.LESS,[Qh]:i.LEQUAL,[nm]:i.EQUAL,[sm]:i.GEQUAL,[im]:i.GREATER,[rm]:i.NOTEQUAL};function $(I,E){if(E.type===Bn&&e.has("OES_texture_float_linear")===!1&&(E.magFilter===Dt||E.magFilter===Fa||E.magFilter===Ms||E.magFilter===Gt||E.minFilter===Dt||E.minFilter===Fa||E.minFilter===Ms||E.minFilter===Gt)&&console.warn("THREE.WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),i.texParameteri(I,i.TEXTURE_WRAP_S,V[E.wrapS]),i.texParameteri(I,i.TEXTURE_WRAP_T,V[E.wrapT]),(I===i.TEXTURE_3D||I===i.TEXTURE_2D_ARRAY)&&i.texParameteri(I,i.TEXTURE_WRAP_R,V[E.wrapR]),i.texParameteri(I,i.TEXTURE_MAG_FILTER,Y[E.magFilter]),i.texParameteri(I,i.TEXTURE_MIN_FILTER,Y[E.minFilter]),E.compareFunction&&(i.texParameteri(I,i.TEXTURE_COMPARE_MODE,i.COMPARE_REF_TO_TEXTURE),i.texParameteri(I,i.TEXTURE_COMPARE_FUNC,ee[E.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(E.magFilter===en||E.minFilter!==Ms&&E.minFilter!==Gt||E.type===Bn&&e.has("OES_texture_float_linear")===!1)return;if(E.anisotropy>1||n.get(E).__currentAnisotropy){const j=e.get("EXT_texture_filter_anisotropic");i.texParameterf(I,j.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(E.anisotropy,r.getMaxAnisotropy())),n.get(E).__currentAnisotropy=E.anisotropy}}}function re(I,E){let j=!1;I.__webglInit===void 0&&(I.__webglInit=!0,E.addEventListener("dispose",M));const Q=E.source;let ie=h.get(Q);ie===void 0&&(ie={},h.set(Q,ie));const K=z(E);if(K!==I.__cacheKey){ie[K]===void 0&&(ie[K]={texture:i.createTexture(),usedTimes:0},a.memory.textures++,j=!0),ie[K].usedTimes++;const ye=ie[I.__cacheKey];ye!==void 0&&(ie[I.__cacheKey].usedTimes--,ye.usedTimes===0&&S(E)),I.__cacheKey=K,I.__webglTexture=ie[K].texture}return j}function te(I,E,j){return Math.floor(Math.floor(I/j)/E)}function F(I,E,j,Q){const K=I.updateRanges;if(K.length===0)t.texSubImage2D(i.TEXTURE_2D,0,0,0,E.width,E.height,j,Q,E.data);else{K.sort((de,Ae)=>de.start-Ae.start);let ye=0;for(let de=1;de<K.length;de++){const Ae=K[ye],Ge=K[de],Be=Ae.start+Ae.count,Me=te(Ge.start,E.width,4),Ke=te(Ae.start,E.width,4);Ge.start<=Be+1&&Me===Ke&&te(Ge.start+Ge.count-1,E.width,4)===Me?Ae.count=Math.max(Ae.count,Ge.start+Ge.count-Ae.start):(++ye,K[ye]=Ge)}K.length=ye+1;const le=i.getParameter(i.UNPACK_ROW_LENGTH),Ue=i.getParameter(i.UNPACK_SKIP_PIXELS),Fe=i.getParameter(i.UNPACK_SKIP_ROWS);i.pixelStorei(i.UNPACK_ROW_LENGTH,E.width);for(let de=0,Ae=K.length;de<Ae;de++){const Ge=K[de],Be=Math.floor(Ge.start/4),Me=Math.ceil(Ge.count/4),Ke=Be%E.width,W=Math.floor(Be/E.width),he=Me,ve=1;i.pixelStorei(i.UNPACK_SKIP_PIXELS,Ke),i.pixelStorei(i.UNPACK_SKIP_ROWS,W),t.texSubImage2D(i.TEXTURE_2D,0,Ke,W,he,ve,j,Q,E.data)}I.clearUpdateRanges(),i.pixelStorei(i.UNPACK_ROW_LENGTH,le),i.pixelStorei(i.UNPACK_SKIP_PIXELS,Ue),i.pixelStorei(i.UNPACK_SKIP_ROWS,Fe)}}function O(I,E,j){let Q=i.TEXTURE_2D;(E.isDataArrayTexture||E.isCompressedArrayTexture)&&(Q=i.TEXTURE_2D_ARRAY),E.isData3DTexture&&(Q=i.TEXTURE_3D);const ie=re(I,E),K=E.source;t.bindTexture(Q,I.__webglTexture,i.TEXTURE0+j);const ye=n.get(K);if(K.version!==ye.__version||ie===!0){t.activeTexture(i.TEXTURE0+j);const le=tt.getPrimaries(tt.workingColorSpace),Ue=E.colorSpace===ci?null:tt.getPrimaries(E.colorSpace),Fe=E.colorSpace===ci||le===Ue?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,E.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,E.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,E.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,Fe);let de=v(E.image,!1,r.maxTextureSize);de=Ye(E,de);const Ae=s.convert(E.format,E.colorSpace),Ge=s.convert(E.type);let Be=_(E.internalFormat,Ae,Ge,E.colorSpace,E.isVideoTexture);$(Q,E);let Me;const Ke=E.mipmaps,W=E.isVideoTexture!==!0,he=ye.__version===void 0||ie===!0,ve=K.dataReady,Pe=R(E,de);if(E.isDepthTexture)Be=x(E.format===Ds,E.type),he&&(W?t.texStorage2D(i.TEXTURE_2D,1,Be,de.width,de.height):t.texImage2D(i.TEXTURE_2D,0,Be,de.width,de.height,0,Ae,Ge,null));else if(E.isDataTexture)if(Ke.length>0){W&&he&&t.texStorage2D(i.TEXTURE_2D,Pe,Be,Ke[0].width,Ke[0].height);for(let ce=0,se=Ke.length;ce<se;ce++)Me=Ke[ce],W?ve&&t.texSubImage2D(i.TEXTURE_2D,ce,0,0,Me.width,Me.height,Ae,Ge,Me.data):t.texImage2D(i.TEXTURE_2D,ce,Be,Me.width,Me.height,0,Ae,Ge,Me.data);E.generateMipmaps=!1}else W?(he&&t.texStorage2D(i.TEXTURE_2D,Pe,Be,de.width,de.height),ve&&F(E,de,Ae,Ge)):t.texImage2D(i.TEXTURE_2D,0,Be,de.width,de.height,0,Ae,Ge,de.data);else if(E.isCompressedTexture)if(E.isCompressedArrayTexture){W&&he&&t.texStorage3D(i.TEXTURE_2D_ARRAY,Pe,Be,Ke[0].width,Ke[0].height,de.depth);for(let ce=0,se=Ke.length;ce<se;ce++)if(Me=Ke[ce],E.format!==wn)if(Ae!==null)if(W){if(ve)if(E.layerUpdates.size>0){const Oe=pd(Me.width,Me.height,E.format,E.type);for(const je of E.layerUpdates){const gt=Me.data.subarray(je*Oe/Me.data.BYTES_PER_ELEMENT,(je+1)*Oe/Me.data.BYTES_PER_ELEMENT);t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,ce,0,0,je,Me.width,Me.height,1,Ae,gt)}E.clearLayerUpdates()}else t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,ce,0,0,0,Me.width,Me.height,de.depth,Ae,Me.data)}else t.compressedTexImage3D(i.TEXTURE_2D_ARRAY,ce,Be,Me.width,Me.height,de.depth,0,Me.data,0,0);else console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else W?ve&&t.texSubImage3D(i.TEXTURE_2D_ARRAY,ce,0,0,0,Me.width,Me.height,de.depth,Ae,Ge,Me.data):t.texImage3D(i.TEXTURE_2D_ARRAY,ce,Be,Me.width,Me.height,de.depth,0,Ae,Ge,Me.data)}else{W&&he&&t.texStorage2D(i.TEXTURE_2D,Pe,Be,Ke[0].width,Ke[0].height);for(let ce=0,se=Ke.length;ce<se;ce++)Me=Ke[ce],E.format!==wn?Ae!==null?W?ve&&t.compressedTexSubImage2D(i.TEXTURE_2D,ce,0,0,Me.width,Me.height,Ae,Me.data):t.compressedTexImage2D(i.TEXTURE_2D,ce,Be,Me.width,Me.height,0,Me.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):W?ve&&t.texSubImage2D(i.TEXTURE_2D,ce,0,0,Me.width,Me.height,Ae,Ge,Me.data):t.texImage2D(i.TEXTURE_2D,ce,Be,Me.width,Me.height,0,Ae,Ge,Me.data)}else if(E.isDataArrayTexture)if(W){if(he&&t.texStorage3D(i.TEXTURE_2D_ARRAY,Pe,Be,de.width,de.height,de.depth),ve)if(E.layerUpdates.size>0){const ce=pd(de.width,de.height,E.format,E.type);for(const se of E.layerUpdates){const Oe=de.data.subarray(se*ce/de.data.BYTES_PER_ELEMENT,(se+1)*ce/de.data.BYTES_PER_ELEMENT);t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,se,de.width,de.height,1,Ae,Ge,Oe)}E.clearLayerUpdates()}else t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,0,de.width,de.height,de.depth,Ae,Ge,de.data)}else t.texImage3D(i.TEXTURE_2D_ARRAY,0,Be,de.width,de.height,de.depth,0,Ae,Ge,de.data);else if(E.isData3DTexture)W?(he&&t.texStorage3D(i.TEXTURE_3D,Pe,Be,de.width,de.height,de.depth),ve&&t.texSubImage3D(i.TEXTURE_3D,0,0,0,0,de.width,de.height,de.depth,Ae,Ge,de.data)):t.texImage3D(i.TEXTURE_3D,0,Be,de.width,de.height,de.depth,0,Ae,Ge,de.data);else if(E.isFramebufferTexture){if(he)if(W)t.texStorage2D(i.TEXTURE_2D,Pe,Be,de.width,de.height);else{let ce=de.width,se=de.height;for(let Oe=0;Oe<Pe;Oe++)t.texImage2D(i.TEXTURE_2D,Oe,Be,ce,se,0,Ae,Ge,null),ce>>=1,se>>=1}}else if(Ke.length>0){if(W&&he){const ce=De(Ke[0]);t.texStorage2D(i.TEXTURE_2D,Pe,Be,ce.width,ce.height)}for(let ce=0,se=Ke.length;ce<se;ce++)Me=Ke[ce],W?ve&&t.texSubImage2D(i.TEXTURE_2D,ce,0,0,Ae,Ge,Me):t.texImage2D(i.TEXTURE_2D,ce,Be,Ae,Ge,Me);E.generateMipmaps=!1}else if(W){if(he){const ce=De(de);t.texStorage2D(i.TEXTURE_2D,Pe,Be,ce.width,ce.height)}ve&&t.texSubImage2D(i.TEXTURE_2D,0,0,0,Ae,Ge,de)}else t.texImage2D(i.TEXTURE_2D,0,Be,Ae,Ge,de);m(E)&&f(Q),ye.__version=K.version,E.onUpdate&&E.onUpdate(E)}I.__version=E.version}function G(I,E,j){if(E.image.length!==6)return;const Q=re(I,E),ie=E.source;t.bindTexture(i.TEXTURE_CUBE_MAP,I.__webglTexture,i.TEXTURE0+j);const K=n.get(ie);if(ie.version!==K.__version||Q===!0){t.activeTexture(i.TEXTURE0+j);const ye=tt.getPrimaries(tt.workingColorSpace),le=E.colorSpace===ci?null:tt.getPrimaries(E.colorSpace),Ue=E.colorSpace===ci||ye===le?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,E.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,E.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,E.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,Ue);const Fe=E.isCompressedTexture||E.image[0].isCompressedTexture,de=E.image[0]&&E.image[0].isDataTexture,Ae=[];for(let se=0;se<6;se++)!Fe&&!de?Ae[se]=v(E.image[se],!0,r.maxCubemapSize):Ae[se]=de?E.image[se].image:E.image[se],Ae[se]=Ye(E,Ae[se]);const Ge=Ae[0],Be=s.convert(E.format,E.colorSpace),Me=s.convert(E.type),Ke=_(E.internalFormat,Be,Me,E.colorSpace),W=E.isVideoTexture!==!0,he=K.__version===void 0||Q===!0,ve=ie.dataReady;let Pe=R(E,Ge);$(i.TEXTURE_CUBE_MAP,E);let ce;if(Fe){W&&he&&t.texStorage2D(i.TEXTURE_CUBE_MAP,Pe,Ke,Ge.width,Ge.height);for(let se=0;se<6;se++){ce=Ae[se].mipmaps;for(let Oe=0;Oe<ce.length;Oe++){const je=ce[Oe];E.format!==wn?Be!==null?W?ve&&t.compressedTexSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+se,Oe,0,0,je.width,je.height,Be,je.data):t.compressedTexImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+se,Oe,Ke,je.width,je.height,0,je.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):W?ve&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+se,Oe,0,0,je.width,je.height,Be,Me,je.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+se,Oe,Ke,je.width,je.height,0,Be,Me,je.data)}}}else{if(ce=E.mipmaps,W&&he){ce.length>0&&Pe++;const se=De(Ae[0]);t.texStorage2D(i.TEXTURE_CUBE_MAP,Pe,Ke,se.width,se.height)}for(let se=0;se<6;se++)if(de){W?ve&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+se,0,0,0,Ae[se].width,Ae[se].height,Be,Me,Ae[se].data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+se,0,Ke,Ae[se].width,Ae[se].height,0,Be,Me,Ae[se].data);for(let Oe=0;Oe<ce.length;Oe++){const gt=ce[Oe].image[se].image;W?ve&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+se,Oe+1,0,0,gt.width,gt.height,Be,Me,gt.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+se,Oe+1,Ke,gt.width,gt.height,0,Be,Me,gt.data)}}else{W?ve&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+se,0,0,0,Be,Me,Ae[se]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+se,0,Ke,Be,Me,Ae[se]);for(let Oe=0;Oe<ce.length;Oe++){const je=ce[Oe];W?ve&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+se,Oe+1,0,0,Be,Me,je.image[se]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+se,Oe+1,Ke,Be,Me,je.image[se])}}}m(E)&&f(i.TEXTURE_CUBE_MAP),K.__version=ie.version,E.onUpdate&&E.onUpdate(E)}I.__version=E.version}function ne(I,E,j,Q,ie,K){const ye=s.convert(j.format,j.colorSpace),le=s.convert(j.type),Ue=_(j.internalFormat,ye,le,j.colorSpace),Fe=n.get(E),de=n.get(j);if(de.__renderTarget=E,!Fe.__hasExternalTextures){const Ae=Math.max(1,E.width>>K),Ge=Math.max(1,E.height>>K);ie===i.TEXTURE_3D||ie===i.TEXTURE_2D_ARRAY?t.texImage3D(ie,K,Ue,Ae,Ge,E.depth,0,ye,le,null):t.texImage2D(ie,K,Ue,Ae,Ge,0,ye,le,null)}t.bindFramebuffer(i.FRAMEBUFFER,I),oe(E)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,Q,ie,de.__webglTexture,0,ze(E)):(ie===i.TEXTURE_2D||ie>=i.TEXTURE_CUBE_MAP_POSITIVE_X&&ie<=i.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&i.framebufferTexture2D(i.FRAMEBUFFER,Q,ie,de.__webglTexture,K),t.bindFramebuffer(i.FRAMEBUFFER,null)}function xe(I,E,j){if(i.bindRenderbuffer(i.RENDERBUFFER,I),E.depthBuffer){const Q=E.depthTexture,ie=Q&&Q.isDepthTexture?Q.type:null,K=x(E.stencilBuffer,ie),ye=E.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,le=ze(E);oe(E)?o.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,le,K,E.width,E.height):j?i.renderbufferStorageMultisample(i.RENDERBUFFER,le,K,E.width,E.height):i.renderbufferStorage(i.RENDERBUFFER,K,E.width,E.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,ye,i.RENDERBUFFER,I)}else{const Q=E.textures;for(let ie=0;ie<Q.length;ie++){const K=Q[ie],ye=s.convert(K.format,K.colorSpace),le=s.convert(K.type),Ue=_(K.internalFormat,ye,le,K.colorSpace),Fe=ze(E);j&&oe(E)===!1?i.renderbufferStorageMultisample(i.RENDERBUFFER,Fe,Ue,E.width,E.height):oe(E)?o.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,Fe,Ue,E.width,E.height):i.renderbufferStorage(i.RENDERBUFFER,Ue,E.width,E.height)}}i.bindRenderbuffer(i.RENDERBUFFER,null)}function fe(I,E){if(E&&E.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(t.bindFramebuffer(i.FRAMEBUFFER,I),!(E.depthTexture&&E.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const Q=n.get(E.depthTexture);Q.__renderTarget=E,(!Q.__webglTexture||E.depthTexture.image.width!==E.width||E.depthTexture.image.height!==E.height)&&(E.depthTexture.image.width=E.width,E.depthTexture.image.height=E.height,E.depthTexture.needsUpdate=!0),H(E.depthTexture,0);const ie=Q.__webglTexture,K=ze(E);if(E.depthTexture.format===Ls)oe(E)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,ie,0,K):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,ie,0);else if(E.depthTexture.format===Ds)oe(E)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,ie,0,K):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,ie,0);else throw new Error("Unknown depthTexture format")}function we(I){const E=n.get(I),j=I.isWebGLCubeRenderTarget===!0;if(E.__boundDepthTexture!==I.depthTexture){const Q=I.depthTexture;if(E.__depthDisposeCallback&&E.__depthDisposeCallback(),Q){const ie=()=>{delete E.__boundDepthTexture,delete E.__depthDisposeCallback,Q.removeEventListener("dispose",ie)};Q.addEventListener("dispose",ie),E.__depthDisposeCallback=ie}E.__boundDepthTexture=Q}if(I.depthTexture&&!E.__autoAllocateDepthBuffer){if(j)throw new Error("target.depthTexture not supported in Cube render targets");const Q=I.texture.mipmaps;Q&&Q.length>0?fe(E.__webglFramebuffer[0],I):fe(E.__webglFramebuffer,I)}else if(j){E.__webglDepthbuffer=[];for(let Q=0;Q<6;Q++)if(t.bindFramebuffer(i.FRAMEBUFFER,E.__webglFramebuffer[Q]),E.__webglDepthbuffer[Q]===void 0)E.__webglDepthbuffer[Q]=i.createRenderbuffer(),xe(E.__webglDepthbuffer[Q],I,!1);else{const ie=I.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,K=E.__webglDepthbuffer[Q];i.bindRenderbuffer(i.RENDERBUFFER,K),i.framebufferRenderbuffer(i.FRAMEBUFFER,ie,i.RENDERBUFFER,K)}}else{const Q=I.texture.mipmaps;if(Q&&Q.length>0?t.bindFramebuffer(i.FRAMEBUFFER,E.__webglFramebuffer[0]):t.bindFramebuffer(i.FRAMEBUFFER,E.__webglFramebuffer),E.__webglDepthbuffer===void 0)E.__webglDepthbuffer=i.createRenderbuffer(),xe(E.__webglDepthbuffer,I,!1);else{const ie=I.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,K=E.__webglDepthbuffer;i.bindRenderbuffer(i.RENDERBUFFER,K),i.framebufferRenderbuffer(i.FRAMEBUFFER,ie,i.RENDERBUFFER,K)}}t.bindFramebuffer(i.FRAMEBUFFER,null)}function me(I,E,j){const Q=n.get(I);E!==void 0&&ne(Q.__webglFramebuffer,I,I.texture,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,0),j!==void 0&&we(I)}function P(I){const E=I.texture,j=n.get(I),Q=n.get(E);I.addEventListener("dispose",w);const ie=I.textures,K=I.isWebGLCubeRenderTarget===!0,ye=ie.length>1;if(ye||(Q.__webglTexture===void 0&&(Q.__webglTexture=i.createTexture()),Q.__version=E.version,a.memory.textures++),K){j.__webglFramebuffer=[];for(let le=0;le<6;le++)if(E.mipmaps&&E.mipmaps.length>0){j.__webglFramebuffer[le]=[];for(let Ue=0;Ue<E.mipmaps.length;Ue++)j.__webglFramebuffer[le][Ue]=i.createFramebuffer()}else j.__webglFramebuffer[le]=i.createFramebuffer()}else{if(E.mipmaps&&E.mipmaps.length>0){j.__webglFramebuffer=[];for(let le=0;le<E.mipmaps.length;le++)j.__webglFramebuffer[le]=i.createFramebuffer()}else j.__webglFramebuffer=i.createFramebuffer();if(ye)for(let le=0,Ue=ie.length;le<Ue;le++){const Fe=n.get(ie[le]);Fe.__webglTexture===void 0&&(Fe.__webglTexture=i.createTexture(),a.memory.textures++)}if(I.samples>0&&oe(I)===!1){j.__webglMultisampledFramebuffer=i.createFramebuffer(),j.__webglColorRenderbuffer=[],t.bindFramebuffer(i.FRAMEBUFFER,j.__webglMultisampledFramebuffer);for(let le=0;le<ie.length;le++){const Ue=ie[le];j.__webglColorRenderbuffer[le]=i.createRenderbuffer(),i.bindRenderbuffer(i.RENDERBUFFER,j.__webglColorRenderbuffer[le]);const Fe=s.convert(Ue.format,Ue.colorSpace),de=s.convert(Ue.type),Ae=_(Ue.internalFormat,Fe,de,Ue.colorSpace,I.isXRRenderTarget===!0),Ge=ze(I);i.renderbufferStorageMultisample(i.RENDERBUFFER,Ge,Ae,I.width,I.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+le,i.RENDERBUFFER,j.__webglColorRenderbuffer[le])}i.bindRenderbuffer(i.RENDERBUFFER,null),I.depthBuffer&&(j.__webglDepthRenderbuffer=i.createRenderbuffer(),xe(j.__webglDepthRenderbuffer,I,!0)),t.bindFramebuffer(i.FRAMEBUFFER,null)}}if(K){t.bindTexture(i.TEXTURE_CUBE_MAP,Q.__webglTexture),$(i.TEXTURE_CUBE_MAP,E);for(let le=0;le<6;le++)if(E.mipmaps&&E.mipmaps.length>0)for(let Ue=0;Ue<E.mipmaps.length;Ue++)ne(j.__webglFramebuffer[le][Ue],I,E,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+le,Ue);else ne(j.__webglFramebuffer[le],I,E,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+le,0);m(E)&&f(i.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(ye){for(let le=0,Ue=ie.length;le<Ue;le++){const Fe=ie[le],de=n.get(Fe);let Ae=i.TEXTURE_2D;(I.isWebGL3DRenderTarget||I.isWebGLArrayRenderTarget)&&(Ae=I.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),t.bindTexture(Ae,de.__webglTexture),$(Ae,Fe),ne(j.__webglFramebuffer,I,Fe,i.COLOR_ATTACHMENT0+le,Ae,0),m(Fe)&&f(Ae)}t.unbindTexture()}else{let le=i.TEXTURE_2D;if((I.isWebGL3DRenderTarget||I.isWebGLArrayRenderTarget)&&(le=I.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),t.bindTexture(le,Q.__webglTexture),$(le,E),E.mipmaps&&E.mipmaps.length>0)for(let Ue=0;Ue<E.mipmaps.length;Ue++)ne(j.__webglFramebuffer[Ue],I,E,i.COLOR_ATTACHMENT0,le,Ue);else ne(j.__webglFramebuffer,I,E,i.COLOR_ATTACHMENT0,le,0);m(E)&&f(le),t.unbindTexture()}I.depthBuffer&&we(I)}function Le(I){const E=I.textures;for(let j=0,Q=E.length;j<Q;j++){const ie=E[j];if(m(ie)){const K=y(I),ye=n.get(ie).__webglTexture;t.bindTexture(K,ye),f(K),t.unbindTexture()}}}const Te=[],ge=[];function ae(I){if(I.samples>0){if(oe(I)===!1){const E=I.textures,j=I.width,Q=I.height;let ie=i.COLOR_BUFFER_BIT;const K=I.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,ye=n.get(I),le=E.length>1;if(le)for(let Fe=0;Fe<E.length;Fe++)t.bindFramebuffer(i.FRAMEBUFFER,ye.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Fe,i.RENDERBUFFER,null),t.bindFramebuffer(i.FRAMEBUFFER,ye.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Fe,i.TEXTURE_2D,null,0);t.bindFramebuffer(i.READ_FRAMEBUFFER,ye.__webglMultisampledFramebuffer);const Ue=I.texture.mipmaps;Ue&&Ue.length>0?t.bindFramebuffer(i.DRAW_FRAMEBUFFER,ye.__webglFramebuffer[0]):t.bindFramebuffer(i.DRAW_FRAMEBUFFER,ye.__webglFramebuffer);for(let Fe=0;Fe<E.length;Fe++){if(I.resolveDepthBuffer&&(I.depthBuffer&&(ie|=i.DEPTH_BUFFER_BIT),I.stencilBuffer&&I.resolveStencilBuffer&&(ie|=i.STENCIL_BUFFER_BIT)),le){i.framebufferRenderbuffer(i.READ_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.RENDERBUFFER,ye.__webglColorRenderbuffer[Fe]);const de=n.get(E[Fe]).__webglTexture;i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,de,0)}i.blitFramebuffer(0,0,j,Q,0,0,j,Q,ie,i.NEAREST),l===!0&&(Te.length=0,ge.length=0,Te.push(i.COLOR_ATTACHMENT0+Fe),I.depthBuffer&&I.resolveDepthBuffer===!1&&(Te.push(K),ge.push(K),i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,ge)),i.invalidateFramebuffer(i.READ_FRAMEBUFFER,Te))}if(t.bindFramebuffer(i.READ_FRAMEBUFFER,null),t.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),le)for(let Fe=0;Fe<E.length;Fe++){t.bindFramebuffer(i.FRAMEBUFFER,ye.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Fe,i.RENDERBUFFER,ye.__webglColorRenderbuffer[Fe]);const de=n.get(E[Fe]).__webglTexture;t.bindFramebuffer(i.FRAMEBUFFER,ye.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Fe,i.TEXTURE_2D,de,0)}t.bindFramebuffer(i.DRAW_FRAMEBUFFER,ye.__webglMultisampledFramebuffer)}else if(I.depthBuffer&&I.resolveDepthBuffer===!1&&l){const E=I.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,[E])}}}function ze(I){return Math.min(r.maxSamples,I.samples)}function oe(I){const E=n.get(I);return I.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&E.__useRenderToTexture!==!1}function Se(I){const E=a.render.frame;d.get(I)!==E&&(d.set(I,E),I.update())}function Ye(I,E){const j=I.colorSpace,Q=I.format,ie=I.type;return I.isCompressedTexture===!0||I.isVideoTexture===!0||j!==nn&&j!==ci&&(tt.getTransfer(j)===pt?(Q!==wn||ie!==Yn)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",j)),E}function De(I){return typeof HTMLImageElement<"u"&&I instanceof HTMLImageElement?(c.width=I.naturalWidth||I.width,c.height=I.naturalHeight||I.height):typeof VideoFrame<"u"&&I instanceof VideoFrame?(c.width=I.displayWidth,c.height=I.displayHeight):(c.width=I.width,c.height=I.height),c}this.allocateTextureUnit=k,this.resetTextureUnits=D,this.setTexture2D=H,this.setTexture2DArray=L,this.setTexture3D=N,this.setTextureCube=B,this.rebindTextures=me,this.setupRenderTarget=P,this.updateRenderTargetMipmap=Le,this.updateMultisampleRenderTarget=ae,this.setupDepthRenderbuffer=we,this.setupFrameBufferTexture=ne,this.useMultisampledRTT=oe}function hy(i,e){function t(n,r=ci){let s;const a=tt.getTransfer(r);if(n===Yn)return i.UNSIGNED_BYTE;if(n===Dc)return i.UNSIGNED_SHORT_4_4_4_4;if(n===Nc)return i.UNSIGNED_SHORT_5_5_5_1;if(n===Yh)return i.UNSIGNED_INT_5_9_9_9_REV;if(n===jh)return i.UNSIGNED_INT_10F_11F_11F_REV;if(n===Xh)return i.BYTE;if(n===qh)return i.SHORT;if(n===Is)return i.UNSIGNED_SHORT;if(n===Lc)return i.INT;if(n===Ji)return i.UNSIGNED_INT;if(n===Bn)return i.FLOAT;if(n===fi)return i.HALF_FLOAT;if(n===$h)return i.ALPHA;if(n===Kh)return i.RGB;if(n===wn)return i.RGBA;if(n===Ls)return i.DEPTH_COMPONENT;if(n===Ds)return i.DEPTH_STENCIL;if(n===Oc)return i.RED;if(n===Uc)return i.RED_INTEGER;if(n===Zh)return i.RG;if(n===Fc)return i.RG_INTEGER;if(n===Bc)return i.RGBA_INTEGER;if(n===Ba||n===ka||n===za||n===Va)if(a===pt)if(s=e.get("WEBGL_compressed_texture_s3tc_srgb"),s!==null){if(n===Ba)return s.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===ka)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===za)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===Va)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(s=e.get("WEBGL_compressed_texture_s3tc"),s!==null){if(n===Ba)return s.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===ka)return s.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===za)return s.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===Va)return s.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===zl||n===Vl||n===Hl||n===Gl)if(s=e.get("WEBGL_compressed_texture_pvrtc"),s!==null){if(n===zl)return s.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===Vl)return s.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===Hl)return s.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===Gl)return s.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===Wl||n===Xl||n===ql)if(s=e.get("WEBGL_compressed_texture_etc"),s!==null){if(n===Wl||n===Xl)return a===pt?s.COMPRESSED_SRGB8_ETC2:s.COMPRESSED_RGB8_ETC2;if(n===ql)return a===pt?s.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:s.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(n===Yl||n===jl||n===$l||n===Kl||n===Zl||n===Jl||n===Ql||n===ec||n===tc||n===nc||n===ic||n===rc||n===sc||n===ac)if(s=e.get("WEBGL_compressed_texture_astc"),s!==null){if(n===Yl)return a===pt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:s.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===jl)return a===pt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:s.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===$l)return a===pt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:s.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===Kl)return a===pt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:s.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===Zl)return a===pt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:s.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===Jl)return a===pt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:s.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===Ql)return a===pt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:s.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===ec)return a===pt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:s.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===tc)return a===pt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:s.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===nc)return a===pt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:s.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===ic)return a===pt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:s.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===rc)return a===pt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:s.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===sc)return a===pt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:s.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===ac)return a===pt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:s.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===oc||n===lc||n===cc)if(s=e.get("EXT_texture_compression_bptc"),s!==null){if(n===oc)return a===pt?s.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:s.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===lc)return s.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===cc)return s.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===uc||n===dc||n===hc||n===fc)if(s=e.get("EXT_texture_compression_rgtc"),s!==null){if(n===uc)return s.COMPRESSED_RED_RGTC1_EXT;if(n===dc)return s.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===hc)return s.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===fc)return s.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===Ps?i.UNSIGNED_INT_24_8:i[n]!==void 0?i[n]:null}return{convert:t}}const fy=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,py=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class my{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t){if(this.texture===null){const n=new gf(e.texture);(e.depthNear!==t.depthNear||e.depthFar!==t.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=n}}getMesh(e){if(this.texture!==null&&this.mesh===null){const t=e.cameras[0].viewport,n=new Rt({vertexShader:fy,fragmentShader:py,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new ht(new yn(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class gy extends es{constructor(e,t){super();const n=this;let r=null,s=1,a=null,o="local-floor",l=1,c=null,d=null,u=null,h=null,p=null,g=null;const v=typeof XRWebGLBinding<"u",m=new my,f={},y=t.getContextAttributes();let _=null,x=null;const R=[],M=[],w=new Ce;let A=null;const S=new Zt;S.viewport=new rt;const b=new Zt;b.viewport=new rt;const T=[S,b],D=new Ag;let k=null,z=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(O){let G=R[O];return G===void 0&&(G=new Qo,R[O]=G),G.getTargetRaySpace()},this.getControllerGrip=function(O){let G=R[O];return G===void 0&&(G=new Qo,R[O]=G),G.getGripSpace()},this.getHand=function(O){let G=R[O];return G===void 0&&(G=new Qo,R[O]=G),G.getHandSpace()};function H(O){const G=M.indexOf(O.inputSource);if(G===-1)return;const ne=R[G];ne!==void 0&&(ne.update(O.inputSource,O.frame,c||a),ne.dispatchEvent({type:O.type,data:O.inputSource}))}function L(){r.removeEventListener("select",H),r.removeEventListener("selectstart",H),r.removeEventListener("selectend",H),r.removeEventListener("squeeze",H),r.removeEventListener("squeezestart",H),r.removeEventListener("squeezeend",H),r.removeEventListener("end",L),r.removeEventListener("inputsourceschange",N);for(let O=0;O<R.length;O++){const G=M[O];G!==null&&(M[O]=null,R[O].disconnect(G))}k=null,z=null,m.reset();for(const O in f)delete f[O];e.setRenderTarget(_),p=null,h=null,u=null,r=null,x=null,F.stop(),n.isPresenting=!1,e.setPixelRatio(A),e.setSize(w.width,w.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(O){s=O,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(O){o=O,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||a},this.setReferenceSpace=function(O){c=O},this.getBaseLayer=function(){return h!==null?h:p},this.getBinding=function(){return u===null&&v&&(u=new XRWebGLBinding(r,t)),u},this.getFrame=function(){return g},this.getSession=function(){return r},this.setSession=async function(O){if(r=O,r!==null){if(_=e.getRenderTarget(),r.addEventListener("select",H),r.addEventListener("selectstart",H),r.addEventListener("selectend",H),r.addEventListener("squeeze",H),r.addEventListener("squeezestart",H),r.addEventListener("squeezeend",H),r.addEventListener("end",L),r.addEventListener("inputsourceschange",N),y.xrCompatible!==!0&&await t.makeXRCompatible(),A=e.getPixelRatio(),e.getSize(w),v&&"createProjectionLayer"in XRWebGLBinding.prototype){let ne=null,xe=null,fe=null;y.depth&&(fe=y.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,ne=y.stencil?Ds:Ls,xe=y.stencil?Ps:Ji);const we={colorFormat:t.RGBA8,depthFormat:fe,scaleFactor:s};u=this.getBinding(),h=u.createProjectionLayer(we),r.updateRenderState({layers:[h]}),e.setPixelRatio(1),e.setSize(h.textureWidth,h.textureHeight,!1),x=new zn(h.textureWidth,h.textureHeight,{format:wn,type:Yn,depthTexture:new mf(h.textureWidth,h.textureHeight,xe,void 0,void 0,void 0,void 0,void 0,void 0,ne),stencilBuffer:y.stencil,colorSpace:e.outputColorSpace,samples:y.antialias?4:0,resolveDepthBuffer:h.ignoreDepthValues===!1,resolveStencilBuffer:h.ignoreDepthValues===!1})}else{const ne={antialias:y.antialias,alpha:!0,depth:y.depth,stencil:y.stencil,framebufferScaleFactor:s};p=new XRWebGLLayer(r,t,ne),r.updateRenderState({baseLayer:p}),e.setPixelRatio(1),e.setSize(p.framebufferWidth,p.framebufferHeight,!1),x=new zn(p.framebufferWidth,p.framebufferHeight,{format:wn,type:Yn,colorSpace:e.outputColorSpace,stencilBuffer:y.stencil,resolveDepthBuffer:p.ignoreDepthValues===!1,resolveStencilBuffer:p.ignoreDepthValues===!1})}x.isXRRenderTarget=!0,this.setFoveation(l),c=null,a=await r.requestReferenceSpace(o),F.setContext(r),F.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(r!==null)return r.environmentBlendMode},this.getDepthTexture=function(){return m.getDepthTexture()};function N(O){for(let G=0;G<O.removed.length;G++){const ne=O.removed[G],xe=M.indexOf(ne);xe>=0&&(M[xe]=null,R[xe].disconnect(ne))}for(let G=0;G<O.added.length;G++){const ne=O.added[G];let xe=M.indexOf(ne);if(xe===-1){for(let we=0;we<R.length;we++)if(we>=M.length){M.push(ne),xe=we;break}else if(M[we]===null){M[we]=ne,xe=we;break}if(xe===-1)break}const fe=R[xe];fe&&fe.connect(ne)}}const B=new U,V=new U;function Y(O,G,ne){B.setFromMatrixPosition(G.matrixWorld),V.setFromMatrixPosition(ne.matrixWorld);const xe=B.distanceTo(V),fe=G.projectionMatrix.elements,we=ne.projectionMatrix.elements,me=fe[14]/(fe[10]-1),P=fe[14]/(fe[10]+1),Le=(fe[9]+1)/fe[5],Te=(fe[9]-1)/fe[5],ge=(fe[8]-1)/fe[0],ae=(we[8]+1)/we[0],ze=me*ge,oe=me*ae,Se=xe/(-ge+ae),Ye=Se*-ge;if(G.matrixWorld.decompose(O.position,O.quaternion,O.scale),O.translateX(Ye),O.translateZ(Se),O.matrixWorld.compose(O.position,O.quaternion,O.scale),O.matrixWorldInverse.copy(O.matrixWorld).invert(),fe[10]===-1)O.projectionMatrix.copy(G.projectionMatrix),O.projectionMatrixInverse.copy(G.projectionMatrixInverse);else{const De=me+Se,I=P+Se,E=ze-Ye,j=oe+(xe-Ye),Q=Le*P/I*De,ie=Te*P/I*De;O.projectionMatrix.makePerspective(E,j,Q,ie,De,I),O.projectionMatrixInverse.copy(O.projectionMatrix).invert()}}function ee(O,G){G===null?O.matrixWorld.copy(O.matrix):O.matrixWorld.multiplyMatrices(G.matrixWorld,O.matrix),O.matrixWorldInverse.copy(O.matrixWorld).invert()}this.updateCamera=function(O){if(r===null)return;let G=O.near,ne=O.far;m.texture!==null&&(m.depthNear>0&&(G=m.depthNear),m.depthFar>0&&(ne=m.depthFar)),D.near=b.near=S.near=G,D.far=b.far=S.far=ne,(k!==D.near||z!==D.far)&&(r.updateRenderState({depthNear:D.near,depthFar:D.far}),k=D.near,z=D.far),D.layers.mask=O.layers.mask|6,S.layers.mask=D.layers.mask&3,b.layers.mask=D.layers.mask&5;const xe=O.parent,fe=D.cameras;ee(D,xe);for(let we=0;we<fe.length;we++)ee(fe[we],xe);fe.length===2?Y(D,S,b):D.projectionMatrix.copy(S.projectionMatrix),$(O,D,xe)};function $(O,G,ne){ne===null?O.matrix.copy(G.matrixWorld):(O.matrix.copy(ne.matrixWorld),O.matrix.invert(),O.matrix.multiply(G.matrixWorld)),O.matrix.decompose(O.position,O.quaternion,O.scale),O.updateMatrixWorld(!0),O.projectionMatrix.copy(G.projectionMatrix),O.projectionMatrixInverse.copy(G.projectionMatrixInverse),O.isPerspectiveCamera&&(O.fov=Gr*2*Math.atan(1/O.projectionMatrix.elements[5]),O.zoom=1)}this.getCamera=function(){return D},this.getFoveation=function(){if(!(h===null&&p===null))return l},this.setFoveation=function(O){l=O,h!==null&&(h.fixedFoveation=O),p!==null&&p.fixedFoveation!==void 0&&(p.fixedFoveation=O)},this.hasDepthSensing=function(){return m.texture!==null},this.getDepthSensingMesh=function(){return m.getMesh(D)},this.getCameraTexture=function(O){return f[O]};let re=null;function te(O,G){if(d=G.getViewerPose(c||a),g=G,d!==null){const ne=d.views;p!==null&&(e.setRenderTargetFramebuffer(x,p.framebuffer),e.setRenderTarget(x));let xe=!1;ne.length!==D.cameras.length&&(D.cameras.length=0,xe=!0);for(let P=0;P<ne.length;P++){const Le=ne[P];let Te=null;if(p!==null)Te=p.getViewport(Le);else{const ae=u.getViewSubImage(h,Le);Te=ae.viewport,P===0&&(e.setRenderTargetTextures(x,ae.colorTexture,ae.depthStencilTexture),e.setRenderTarget(x))}let ge=T[P];ge===void 0&&(ge=new Zt,ge.layers.enable(P),ge.viewport=new rt,T[P]=ge),ge.matrix.fromArray(Le.transform.matrix),ge.matrix.decompose(ge.position,ge.quaternion,ge.scale),ge.projectionMatrix.fromArray(Le.projectionMatrix),ge.projectionMatrixInverse.copy(ge.projectionMatrix).invert(),ge.viewport.set(Te.x,Te.y,Te.width,Te.height),P===0&&(D.matrix.copy(ge.matrix),D.matrix.decompose(D.position,D.quaternion,D.scale)),xe===!0&&D.cameras.push(ge)}const fe=r.enabledFeatures;if(fe&&fe.includes("depth-sensing")&&r.depthUsage=="gpu-optimized"&&v){u=n.getBinding();const P=u.getDepthInformation(ne[0]);P&&P.isValid&&P.texture&&m.init(P,r.renderState)}if(fe&&fe.includes("camera-access")&&v){e.state.unbindTexture(),u=n.getBinding();for(let P=0;P<ne.length;P++){const Le=ne[P].camera;if(Le){let Te=f[Le];Te||(Te=new gf,f[Le]=Te);const ge=u.getCameraImage(Le);Te.sourceTexture=ge}}}}for(let ne=0;ne<R.length;ne++){const xe=M[ne],fe=R[ne];xe!==null&&fe!==void 0&&fe.update(xe,G,c||a)}re&&re(O,G),G.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:G}),g=null}const F=new bf;F.setAnimationLoop(te),this.setAnimationLoop=function(O){re=O},this.dispose=function(){}}}const Wi=new xn,vy=new qe;function _y(i,e){function t(m,f){m.matrixAutoUpdate===!0&&m.updateMatrix(),f.value.copy(m.matrix)}function n(m,f){f.color.getRGB(m.fogColor.value,af(i)),f.isFog?(m.fogNear.value=f.near,m.fogFar.value=f.far):f.isFogExp2&&(m.fogDensity.value=f.density)}function r(m,f,y,_,x){f.isMeshBasicMaterial||f.isMeshLambertMaterial?s(m,f):f.isMeshToonMaterial?(s(m,f),u(m,f)):f.isMeshPhongMaterial?(s(m,f),d(m,f)):f.isMeshStandardMaterial?(s(m,f),h(m,f),f.isMeshPhysicalMaterial&&p(m,f,x)):f.isMeshMatcapMaterial?(s(m,f),g(m,f)):f.isMeshDepthMaterial?s(m,f):f.isMeshDistanceMaterial?(s(m,f),v(m,f)):f.isMeshNormalMaterial?s(m,f):f.isLineBasicMaterial?(a(m,f),f.isLineDashedMaterial&&o(m,f)):f.isPointsMaterial?l(m,f,y,_):f.isSpriteMaterial?c(m,f):f.isShadowMaterial?(m.color.value.copy(f.color),m.opacity.value=f.opacity):f.isShaderMaterial&&(f.uniformsNeedUpdate=!1)}function s(m,f){m.opacity.value=f.opacity,f.color&&m.diffuse.value.copy(f.color),f.emissive&&m.emissive.value.copy(f.emissive).multiplyScalar(f.emissiveIntensity),f.map&&(m.map.value=f.map,t(f.map,m.mapTransform)),f.alphaMap&&(m.alphaMap.value=f.alphaMap,t(f.alphaMap,m.alphaMapTransform)),f.bumpMap&&(m.bumpMap.value=f.bumpMap,t(f.bumpMap,m.bumpMapTransform),m.bumpScale.value=f.bumpScale,f.side===cn&&(m.bumpScale.value*=-1)),f.normalMap&&(m.normalMap.value=f.normalMap,t(f.normalMap,m.normalMapTransform),m.normalScale.value.copy(f.normalScale),f.side===cn&&m.normalScale.value.negate()),f.displacementMap&&(m.displacementMap.value=f.displacementMap,t(f.displacementMap,m.displacementMapTransform),m.displacementScale.value=f.displacementScale,m.displacementBias.value=f.displacementBias),f.emissiveMap&&(m.emissiveMap.value=f.emissiveMap,t(f.emissiveMap,m.emissiveMapTransform)),f.specularMap&&(m.specularMap.value=f.specularMap,t(f.specularMap,m.specularMapTransform)),f.alphaTest>0&&(m.alphaTest.value=f.alphaTest);const y=e.get(f),_=y.envMap,x=y.envMapRotation;_&&(m.envMap.value=_,Wi.copy(x),Wi.x*=-1,Wi.y*=-1,Wi.z*=-1,_.isCubeTexture&&_.isRenderTargetTexture===!1&&(Wi.y*=-1,Wi.z*=-1),m.envMapRotation.value.setFromMatrix4(vy.makeRotationFromEuler(Wi)),m.flipEnvMap.value=_.isCubeTexture&&_.isRenderTargetTexture===!1?-1:1,m.reflectivity.value=f.reflectivity,m.ior.value=f.ior,m.refractionRatio.value=f.refractionRatio),f.lightMap&&(m.lightMap.value=f.lightMap,m.lightMapIntensity.value=f.lightMapIntensity,t(f.lightMap,m.lightMapTransform)),f.aoMap&&(m.aoMap.value=f.aoMap,m.aoMapIntensity.value=f.aoMapIntensity,t(f.aoMap,m.aoMapTransform))}function a(m,f){m.diffuse.value.copy(f.color),m.opacity.value=f.opacity,f.map&&(m.map.value=f.map,t(f.map,m.mapTransform))}function o(m,f){m.dashSize.value=f.dashSize,m.totalSize.value=f.dashSize+f.gapSize,m.scale.value=f.scale}function l(m,f,y,_){m.diffuse.value.copy(f.color),m.opacity.value=f.opacity,m.size.value=f.size*y,m.scale.value=_*.5,f.map&&(m.map.value=f.map,t(f.map,m.uvTransform)),f.alphaMap&&(m.alphaMap.value=f.alphaMap,t(f.alphaMap,m.alphaMapTransform)),f.alphaTest>0&&(m.alphaTest.value=f.alphaTest)}function c(m,f){m.diffuse.value.copy(f.color),m.opacity.value=f.opacity,m.rotation.value=f.rotation,f.map&&(m.map.value=f.map,t(f.map,m.mapTransform)),f.alphaMap&&(m.alphaMap.value=f.alphaMap,t(f.alphaMap,m.alphaMapTransform)),f.alphaTest>0&&(m.alphaTest.value=f.alphaTest)}function d(m,f){m.specular.value.copy(f.specular),m.shininess.value=Math.max(f.shininess,1e-4)}function u(m,f){f.gradientMap&&(m.gradientMap.value=f.gradientMap)}function h(m,f){m.metalness.value=f.metalness,f.metalnessMap&&(m.metalnessMap.value=f.metalnessMap,t(f.metalnessMap,m.metalnessMapTransform)),m.roughness.value=f.roughness,f.roughnessMap&&(m.roughnessMap.value=f.roughnessMap,t(f.roughnessMap,m.roughnessMapTransform)),f.envMap&&(m.envMapIntensity.value=f.envMapIntensity)}function p(m,f,y){m.ior.value=f.ior,f.sheen>0&&(m.sheenColor.value.copy(f.sheenColor).multiplyScalar(f.sheen),m.sheenRoughness.value=f.sheenRoughness,f.sheenColorMap&&(m.sheenColorMap.value=f.sheenColorMap,t(f.sheenColorMap,m.sheenColorMapTransform)),f.sheenRoughnessMap&&(m.sheenRoughnessMap.value=f.sheenRoughnessMap,t(f.sheenRoughnessMap,m.sheenRoughnessMapTransform))),f.clearcoat>0&&(m.clearcoat.value=f.clearcoat,m.clearcoatRoughness.value=f.clearcoatRoughness,f.clearcoatMap&&(m.clearcoatMap.value=f.clearcoatMap,t(f.clearcoatMap,m.clearcoatMapTransform)),f.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=f.clearcoatRoughnessMap,t(f.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),f.clearcoatNormalMap&&(m.clearcoatNormalMap.value=f.clearcoatNormalMap,t(f.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(f.clearcoatNormalScale),f.side===cn&&m.clearcoatNormalScale.value.negate())),f.dispersion>0&&(m.dispersion.value=f.dispersion),f.iridescence>0&&(m.iridescence.value=f.iridescence,m.iridescenceIOR.value=f.iridescenceIOR,m.iridescenceThicknessMinimum.value=f.iridescenceThicknessRange[0],m.iridescenceThicknessMaximum.value=f.iridescenceThicknessRange[1],f.iridescenceMap&&(m.iridescenceMap.value=f.iridescenceMap,t(f.iridescenceMap,m.iridescenceMapTransform)),f.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=f.iridescenceThicknessMap,t(f.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),f.transmission>0&&(m.transmission.value=f.transmission,m.transmissionSamplerMap.value=y.texture,m.transmissionSamplerSize.value.set(y.width,y.height),f.transmissionMap&&(m.transmissionMap.value=f.transmissionMap,t(f.transmissionMap,m.transmissionMapTransform)),m.thickness.value=f.thickness,f.thicknessMap&&(m.thicknessMap.value=f.thicknessMap,t(f.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=f.attenuationDistance,m.attenuationColor.value.copy(f.attenuationColor)),f.anisotropy>0&&(m.anisotropyVector.value.set(f.anisotropy*Math.cos(f.anisotropyRotation),f.anisotropy*Math.sin(f.anisotropyRotation)),f.anisotropyMap&&(m.anisotropyMap.value=f.anisotropyMap,t(f.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=f.specularIntensity,m.specularColor.value.copy(f.specularColor),f.specularColorMap&&(m.specularColorMap.value=f.specularColorMap,t(f.specularColorMap,m.specularColorMapTransform)),f.specularIntensityMap&&(m.specularIntensityMap.value=f.specularIntensityMap,t(f.specularIntensityMap,m.specularIntensityMapTransform))}function g(m,f){f.matcap&&(m.matcap.value=f.matcap)}function v(m,f){const y=e.get(f).light;m.referencePosition.value.setFromMatrixPosition(y.matrixWorld),m.nearDistance.value=y.shadow.camera.near,m.farDistance.value=y.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:r}}function xy(i,e,t,n){let r={},s={},a=[];const o=i.getParameter(i.MAX_UNIFORM_BUFFER_BINDINGS);function l(y,_){const x=_.program;n.uniformBlockBinding(y,x)}function c(y,_){let x=r[y.id];x===void 0&&(g(y),x=d(y),r[y.id]=x,y.addEventListener("dispose",m));const R=_.program;n.updateUBOMapping(y,R);const M=e.render.frame;s[y.id]!==M&&(h(y),s[y.id]=M)}function d(y){const _=u();y.__bindingPointIndex=_;const x=i.createBuffer(),R=y.__size,M=y.usage;return i.bindBuffer(i.UNIFORM_BUFFER,x),i.bufferData(i.UNIFORM_BUFFER,R,M),i.bindBuffer(i.UNIFORM_BUFFER,null),i.bindBufferBase(i.UNIFORM_BUFFER,_,x),x}function u(){for(let y=0;y<o;y++)if(a.indexOf(y)===-1)return a.push(y),y;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function h(y){const _=r[y.id],x=y.uniforms,R=y.__cache;i.bindBuffer(i.UNIFORM_BUFFER,_);for(let M=0,w=x.length;M<w;M++){const A=Array.isArray(x[M])?x[M]:[x[M]];for(let S=0,b=A.length;S<b;S++){const T=A[S];if(p(T,M,S,R)===!0){const D=T.__offset,k=Array.isArray(T.value)?T.value:[T.value];let z=0;for(let H=0;H<k.length;H++){const L=k[H],N=v(L);typeof L=="number"||typeof L=="boolean"?(T.__data[0]=L,i.bufferSubData(i.UNIFORM_BUFFER,D+z,T.__data)):L.isMatrix3?(T.__data[0]=L.elements[0],T.__data[1]=L.elements[1],T.__data[2]=L.elements[2],T.__data[3]=0,T.__data[4]=L.elements[3],T.__data[5]=L.elements[4],T.__data[6]=L.elements[5],T.__data[7]=0,T.__data[8]=L.elements[6],T.__data[9]=L.elements[7],T.__data[10]=L.elements[8],T.__data[11]=0):(L.toArray(T.__data,z),z+=N.storage/Float32Array.BYTES_PER_ELEMENT)}i.bufferSubData(i.UNIFORM_BUFFER,D,T.__data)}}}i.bindBuffer(i.UNIFORM_BUFFER,null)}function p(y,_,x,R){const M=y.value,w=_+"_"+x;if(R[w]===void 0)return typeof M=="number"||typeof M=="boolean"?R[w]=M:R[w]=M.clone(),!0;{const A=R[w];if(typeof M=="number"||typeof M=="boolean"){if(A!==M)return R[w]=M,!0}else if(A.equals(M)===!1)return A.copy(M),!0}return!1}function g(y){const _=y.uniforms;let x=0;const R=16;for(let w=0,A=_.length;w<A;w++){const S=Array.isArray(_[w])?_[w]:[_[w]];for(let b=0,T=S.length;b<T;b++){const D=S[b],k=Array.isArray(D.value)?D.value:[D.value];for(let z=0,H=k.length;z<H;z++){const L=k[z],N=v(L),B=x%R,V=B%N.boundary,Y=B+V;x+=V,Y!==0&&R-Y<N.storage&&(x+=R-Y),D.__data=new Float32Array(N.storage/Float32Array.BYTES_PER_ELEMENT),D.__offset=x,x+=N.storage}}}const M=x%R;return M>0&&(x+=R-M),y.__size=x,y.__cache={},this}function v(y){const _={boundary:0,storage:0};return typeof y=="number"||typeof y=="boolean"?(_.boundary=4,_.storage=4):y.isVector2?(_.boundary=8,_.storage=8):y.isVector3||y.isColor?(_.boundary=16,_.storage=12):y.isVector4?(_.boundary=16,_.storage=16):y.isMatrix3?(_.boundary=48,_.storage=48):y.isMatrix4?(_.boundary=64,_.storage=64):y.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",y),_}function m(y){const _=y.target;_.removeEventListener("dispose",m);const x=a.indexOf(_.__bindingPointIndex);a.splice(x,1),i.deleteBuffer(r[_.id]),delete r[_.id],delete s[_.id]}function f(){for(const y in r)i.deleteBuffer(r[y]);a=[],r={},s={}}return{bind:l,update:c,dispose:f}}class yy{constructor(e={}){const{canvas:t=Mm(),context:n=null,depth:r=!0,stencil:s=!1,alpha:a=!1,antialias:o=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:d="default",failIfMajorPerformanceCaveat:u=!1,reversedDepthBuffer:h=!1}=e;this.isWebGLRenderer=!0;let p;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");p=n.getContextAttributes().alpha}else p=a;const g=new Uint32Array(4),v=new Int32Array(4);let m=null,f=null;const y=[],_=[];this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=Li,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const x=this;let R=!1;this._outputColorSpace=_t;let M=0,w=0,A=null,S=-1,b=null;const T=new rt,D=new rt;let k=null;const z=new Ie(0);let H=0,L=t.width,N=t.height,B=1,V=null,Y=null;const ee=new rt(0,0,L,N),$=new rt(0,0,L,N);let re=!1;const te=new Wc;let F=!1,O=!1;const G=new qe,ne=new U,xe=new rt,fe={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let we=!1;function me(){return A===null?B:1}let P=n;function Le(C,X){return t.getContext(C,X)}try{const C={alpha:!0,depth:r,stencil:s,antialias:o,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:d,failIfMajorPerformanceCaveat:u};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${Ic}`),t.addEventListener("webglcontextlost",ve,!1),t.addEventListener("webglcontextrestored",Pe,!1),t.addEventListener("webglcontextcreationerror",ce,!1),P===null){const X="webgl2";if(P=Le(X,C),P===null)throw Le(X)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(C){throw console.error("THREE.WebGLRenderer: "+C.message),C}let Te,ge,ae,ze,oe,Se,Ye,De,I,E,j,Q,ie,K,ye,le,Ue,Fe,de,Ae,Ge,Be,Me,Ke;function W(){Te=new I_(P),Te.init(),Be=new hy(P,Te),ge=new M_(P,Te,e,Be),ae=new uy(P,Te),ge.reversedDepthBuffer&&h&&ae.buffers.depth.setReversed(!0),ze=new D_(P),oe=new Zx,Se=new dy(P,Te,ae,oe,ge,Be,ze),Ye=new T_(x),De=new C_(x),I=new kg(P),Me=new b_(P,I),E=new P_(P,I,ze,Me),j=new O_(P,E,I,ze),de=new N_(P,ge,Se),le=new E_(oe),Q=new Kx(x,Ye,De,Te,ge,Me,le),ie=new _y(x,oe),K=new Qx,ye=new sy(Te),Fe=new y_(x,Ye,De,ae,j,p,l),Ue=new ly(x,j,ge),Ke=new xy(P,ze,ge,ae),Ae=new S_(P,Te,ze),Ge=new L_(P,Te,ze),ze.programs=Q.programs,x.capabilities=ge,x.extensions=Te,x.properties=oe,x.renderLists=K,x.shadowMap=Ue,x.state=ae,x.info=ze}W();const he=new gy(x,P);this.xr=he,this.getContext=function(){return P},this.getContextAttributes=function(){return P.getContextAttributes()},this.forceContextLoss=function(){const C=Te.get("WEBGL_lose_context");C&&C.loseContext()},this.forceContextRestore=function(){const C=Te.get("WEBGL_lose_context");C&&C.restoreContext()},this.getPixelRatio=function(){return B},this.setPixelRatio=function(C){C!==void 0&&(B=C,this.setSize(L,N,!1))},this.getSize=function(C){return C.set(L,N)},this.setSize=function(C,X,Z=!0){if(he.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}L=C,N=X,t.width=Math.floor(C*B),t.height=Math.floor(X*B),Z===!0&&(t.style.width=C+"px",t.style.height=X+"px"),this.setViewport(0,0,C,X)},this.getDrawingBufferSize=function(C){return C.set(L*B,N*B).floor()},this.setDrawingBufferSize=function(C,X,Z){L=C,N=X,B=Z,t.width=Math.floor(C*Z),t.height=Math.floor(X*Z),this.setViewport(0,0,C,X)},this.getCurrentViewport=function(C){return C.copy(T)},this.getViewport=function(C){return C.copy(ee)},this.setViewport=function(C,X,Z,J){C.isVector4?ee.set(C.x,C.y,C.z,C.w):ee.set(C,X,Z,J),ae.viewport(T.copy(ee).multiplyScalar(B).round())},this.getScissor=function(C){return C.copy($)},this.setScissor=function(C,X,Z,J){C.isVector4?$.set(C.x,C.y,C.z,C.w):$.set(C,X,Z,J),ae.scissor(D.copy($).multiplyScalar(B).round())},this.getScissorTest=function(){return re},this.setScissorTest=function(C){ae.setScissorTest(re=C)},this.setOpaqueSort=function(C){V=C},this.setTransparentSort=function(C){Y=C},this.getClearColor=function(C){return C.copy(Fe.getClearColor())},this.setClearColor=function(){Fe.setClearColor(...arguments)},this.getClearAlpha=function(){return Fe.getClearAlpha()},this.setClearAlpha=function(){Fe.setClearAlpha(...arguments)},this.clear=function(C=!0,X=!0,Z=!0){let J=0;if(C){let q=!1;if(A!==null){const ue=A.texture.format;q=ue===Bc||ue===Fc||ue===Uc}if(q){const ue=A.texture.type,Ee=ue===Yn||ue===Ji||ue===Is||ue===Ps||ue===Dc||ue===Nc,Ne=Fe.getClearColor(),Re=Fe.getClearAlpha(),He=Ne.r,We=Ne.g,ke=Ne.b;Ee?(g[0]=He,g[1]=We,g[2]=ke,g[3]=Re,P.clearBufferuiv(P.COLOR,0,g)):(v[0]=He,v[1]=We,v[2]=ke,v[3]=Re,P.clearBufferiv(P.COLOR,0,v))}else J|=P.COLOR_BUFFER_BIT}X&&(J|=P.DEPTH_BUFFER_BIT),Z&&(J|=P.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),P.clear(J)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){t.removeEventListener("webglcontextlost",ve,!1),t.removeEventListener("webglcontextrestored",Pe,!1),t.removeEventListener("webglcontextcreationerror",ce,!1),Fe.dispose(),K.dispose(),ye.dispose(),oe.dispose(),Ye.dispose(),De.dispose(),j.dispose(),Me.dispose(),Ke.dispose(),Q.dispose(),he.dispose(),he.removeEventListener("sessionstart",Hn),he.removeEventListener("sessionend",fu),Fi.stop()};function ve(C){C.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),R=!0}function Pe(){console.log("THREE.WebGLRenderer: Context Restored."),R=!1;const C=ze.autoReset,X=Ue.enabled,Z=Ue.autoUpdate,J=Ue.needsUpdate,q=Ue.type;W(),ze.autoReset=C,Ue.enabled=X,Ue.autoUpdate=Z,Ue.needsUpdate=J,Ue.type=q}function ce(C){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",C.statusMessage)}function se(C){const X=C.target;X.removeEventListener("dispose",se),Oe(X)}function Oe(C){je(C),oe.remove(C)}function je(C){const X=oe.get(C).programs;X!==void 0&&(X.forEach(function(Z){Q.releaseProgram(Z)}),C.isShaderMaterial&&Q.releaseShaderCache(C))}this.renderBufferDirect=function(C,X,Z,J,q,ue){X===null&&(X=fe);const Ee=q.isMesh&&q.matrixWorld.determinant()<0,Ne=rp(C,X,Z,J,q);ae.setMaterial(J,Ee);let Re=Z.index,He=1;if(J.wireframe===!0){if(Re=E.getWireframeAttribute(Z),Re===void 0)return;He=2}const We=Z.drawRange,ke=Z.attributes.position;let et=We.start*He,ft=(We.start+We.count)*He;ue!==null&&(et=Math.max(et,ue.start*He),ft=Math.min(ft,(ue.start+ue.count)*He)),Re!==null?(et=Math.max(et,0),ft=Math.min(ft,Re.count)):ke!=null&&(et=Math.max(et,0),ft=Math.min(ft,ke.count));const It=ft-et;if(It<0||It===1/0)return;Me.setup(q,J,Ne,Z,Re);let yt,mt=Ae;if(Re!==null&&(yt=I.get(Re),mt=Ge,mt.setIndex(yt)),q.isMesh)J.wireframe===!0?(ae.setLineWidth(J.wireframeLinewidth*me()),mt.setMode(P.LINES)):mt.setMode(P.TRIANGLES);else if(q.isLine){let Ve=J.linewidth;Ve===void 0&&(Ve=1),ae.setLineWidth(Ve*me()),q.isLineSegments?mt.setMode(P.LINES):q.isLineLoop?mt.setMode(P.LINE_LOOP):mt.setMode(P.LINE_STRIP)}else q.isPoints?mt.setMode(P.POINTS):q.isSprite&&mt.setMode(P.TRIANGLES);if(q.isBatchedMesh)if(q._multiDrawInstances!==null)Fs("THREE.WebGLRenderer: renderMultiDrawInstances has been deprecated and will be removed in r184. Append to renderMultiDraw arguments and use indirection."),mt.renderMultiDrawInstances(q._multiDrawStarts,q._multiDrawCounts,q._multiDrawCount,q._multiDrawInstances);else if(Te.get("WEBGL_multi_draw"))mt.renderMultiDraw(q._multiDrawStarts,q._multiDrawCounts,q._multiDrawCount);else{const Ve=q._multiDrawStarts,At=q._multiDrawCounts,it=q._multiDrawCount,fn=Re?I.get(Re).bytesPerElement:1,ir=oe.get(J).currentProgram.getUniforms();for(let pn=0;pn<it;pn++)ir.setValue(P,"_gl_DrawID",pn),mt.render(Ve[pn]/fn,At[pn])}else if(q.isInstancedMesh)mt.renderInstances(et,It,q.count);else if(Z.isInstancedBufferGeometry){const Ve=Z._maxInstanceCount!==void 0?Z._maxInstanceCount:1/0,At=Math.min(Z.instanceCount,Ve);mt.renderInstances(et,It,At)}else mt.render(et,It)};function gt(C,X,Z){C.transparent===!0&&C.side===Et&&C.forceSinglePass===!1?(C.side=cn,C.needsUpdate=!0,ta(C,X,Z),C.side=mi,C.needsUpdate=!0,ta(C,X,Z),C.side=Et):ta(C,X,Z)}this.compile=function(C,X,Z=null){Z===null&&(Z=C),f=ye.get(Z),f.init(X),_.push(f),Z.traverseVisible(function(q){q.isLight&&q.layers.test(X.layers)&&(f.pushLight(q),q.castShadow&&f.pushShadow(q))}),C!==Z&&C.traverseVisible(function(q){q.isLight&&q.layers.test(X.layers)&&(f.pushLight(q),q.castShadow&&f.pushShadow(q))}),f.setupLights();const J=new Set;return C.traverse(function(q){if(!(q.isMesh||q.isPoints||q.isLine||q.isSprite))return;const ue=q.material;if(ue)if(Array.isArray(ue))for(let Ee=0;Ee<ue.length;Ee++){const Ne=ue[Ee];gt(Ne,Z,q),J.add(Ne)}else gt(ue,Z,q),J.add(ue)}),f=_.pop(),J},this.compileAsync=function(C,X,Z=null){const J=this.compile(C,X,Z);return new Promise(q=>{function ue(){if(J.forEach(function(Ee){oe.get(Ee).currentProgram.isReady()&&J.delete(Ee)}),J.size===0){q(C);return}setTimeout(ue,10)}Te.get("KHR_parallel_shader_compile")!==null?ue():setTimeout(ue,10)})};let st=null;function Zn(C){st&&st(C)}function Hn(){Fi.stop()}function fu(){Fi.start()}const Fi=new bf;Fi.setAnimationLoop(Zn),typeof self<"u"&&Fi.setContext(self),this.setAnimationLoop=function(C){st=C,he.setAnimationLoop(C),C===null?Fi.stop():Fi.start()},he.addEventListener("sessionstart",Hn),he.addEventListener("sessionend",fu),this.render=function(C,X){if(X!==void 0&&X.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(R===!0)return;if(C.matrixWorldAutoUpdate===!0&&C.updateMatrixWorld(),X.parent===null&&X.matrixWorldAutoUpdate===!0&&X.updateMatrixWorld(),he.enabled===!0&&he.isPresenting===!0&&(he.cameraAutoUpdate===!0&&he.updateCamera(X),X=he.getCamera()),C.isScene===!0&&C.onBeforeRender(x,C,X,A),f=ye.get(C,_.length),f.init(X),_.push(f),G.multiplyMatrices(X.projectionMatrix,X.matrixWorldInverse),te.setFromProjectionMatrix(G,qn,X.reversedDepth),O=this.localClippingEnabled,F=le.init(this.clippingPlanes,O),m=K.get(C,y.length),m.init(),y.push(m),he.enabled===!0&&he.isPresenting===!0){const ue=x.xr.getDepthSensingMesh();ue!==null&&Io(ue,X,-1/0,x.sortObjects)}Io(C,X,0,x.sortObjects),m.finish(),x.sortObjects===!0&&m.sort(V,Y),we=he.enabled===!1||he.isPresenting===!1||he.hasDepthSensing()===!1,we&&Fe.addToRenderList(m,C),this.info.render.frame++,F===!0&&le.beginShadows();const Z=f.state.shadowsArray;Ue.render(Z,C,X),F===!0&&le.endShadows(),this.info.autoReset===!0&&this.info.reset();const J=m.opaque,q=m.transmissive;if(f.setupLights(),X.isArrayCamera){const ue=X.cameras;if(q.length>0)for(let Ee=0,Ne=ue.length;Ee<Ne;Ee++){const Re=ue[Ee];mu(J,q,C,Re)}we&&Fe.render(C);for(let Ee=0,Ne=ue.length;Ee<Ne;Ee++){const Re=ue[Ee];pu(m,C,Re,Re.viewport)}}else q.length>0&&mu(J,q,C,X),we&&Fe.render(C),pu(m,C,X);A!==null&&w===0&&(Se.updateMultisampleRenderTarget(A),Se.updateRenderTargetMipmap(A)),C.isScene===!0&&C.onAfterRender(x,C,X),Me.resetDefaultState(),S=-1,b=null,_.pop(),_.length>0?(f=_[_.length-1],F===!0&&le.setGlobalState(x.clippingPlanes,f.state.camera)):f=null,y.pop(),y.length>0?m=y[y.length-1]:m=null};function Io(C,X,Z,J){if(C.visible===!1)return;if(C.layers.test(X.layers)){if(C.isGroup)Z=C.renderOrder;else if(C.isLOD)C.autoUpdate===!0&&C.update(X);else if(C.isLight)f.pushLight(C),C.castShadow&&f.pushShadow(C);else if(C.isSprite){if(!C.frustumCulled||te.intersectsSprite(C)){J&&xe.setFromMatrixPosition(C.matrixWorld).applyMatrix4(G);const Ee=j.update(C),Ne=C.material;Ne.visible&&m.push(C,Ee,Ne,Z,xe.z,null)}}else if((C.isMesh||C.isLine||C.isPoints)&&(!C.frustumCulled||te.intersectsObject(C))){const Ee=j.update(C),Ne=C.material;if(J&&(C.boundingSphere!==void 0?(C.boundingSphere===null&&C.computeBoundingSphere(),xe.copy(C.boundingSphere.center)):(Ee.boundingSphere===null&&Ee.computeBoundingSphere(),xe.copy(Ee.boundingSphere.center)),xe.applyMatrix4(C.matrixWorld).applyMatrix4(G)),Array.isArray(Ne)){const Re=Ee.groups;for(let He=0,We=Re.length;He<We;He++){const ke=Re[He],et=Ne[ke.materialIndex];et&&et.visible&&m.push(C,Ee,et,Z,xe.z,ke)}}else Ne.visible&&m.push(C,Ee,Ne,Z,xe.z,null)}}const ue=C.children;for(let Ee=0,Ne=ue.length;Ee<Ne;Ee++)Io(ue[Ee],X,Z,J)}function pu(C,X,Z,J){const q=C.opaque,ue=C.transmissive,Ee=C.transparent;f.setupLightsView(Z),F===!0&&le.setGlobalState(x.clippingPlanes,Z),J&&ae.viewport(T.copy(J)),q.length>0&&ea(q,X,Z),ue.length>0&&ea(ue,X,Z),Ee.length>0&&ea(Ee,X,Z),ae.buffers.depth.setTest(!0),ae.buffers.depth.setMask(!0),ae.buffers.color.setMask(!0),ae.setPolygonOffset(!1)}function mu(C,X,Z,J){if((Z.isScene===!0?Z.overrideMaterial:null)!==null)return;f.state.transmissionRenderTarget[J.id]===void 0&&(f.state.transmissionRenderTarget[J.id]=new zn(1,1,{generateMipmaps:!0,type:Te.has("EXT_color_buffer_half_float")||Te.has("EXT_color_buffer_float")?fi:Yn,minFilter:Gt,samples:4,stencilBuffer:s,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:tt.workingColorSpace}));const ue=f.state.transmissionRenderTarget[J.id],Ee=J.viewport||T;ue.setSize(Ee.z*x.transmissionResolutionScale,Ee.w*x.transmissionResolutionScale);const Ne=x.getRenderTarget(),Re=x.getActiveCubeFace(),He=x.getActiveMipmapLevel();x.setRenderTarget(ue),x.getClearColor(z),H=x.getClearAlpha(),H<1&&x.setClearColor(16777215,.5),x.clear(),we&&Fe.render(Z);const We=x.toneMapping;x.toneMapping=Li;const ke=J.viewport;if(J.viewport!==void 0&&(J.viewport=void 0),f.setupLightsView(J),F===!0&&le.setGlobalState(x.clippingPlanes,J),ea(C,Z,J),Se.updateMultisampleRenderTarget(ue),Se.updateRenderTargetMipmap(ue),Te.has("WEBGL_multisampled_render_to_texture")===!1){let et=!1;for(let ft=0,It=X.length;ft<It;ft++){const yt=X[ft],mt=yt.object,Ve=yt.geometry,At=yt.material,it=yt.group;if(At.side===Et&&mt.layers.test(J.layers)){const fn=At.side;At.side=cn,At.needsUpdate=!0,gu(mt,Z,J,Ve,At,it),At.side=fn,At.needsUpdate=!0,et=!0}}et===!0&&(Se.updateMultisampleRenderTarget(ue),Se.updateRenderTargetMipmap(ue))}x.setRenderTarget(Ne,Re,He),x.setClearColor(z,H),ke!==void 0&&(J.viewport=ke),x.toneMapping=We}function ea(C,X,Z){const J=X.isScene===!0?X.overrideMaterial:null;for(let q=0,ue=C.length;q<ue;q++){const Ee=C[q],Ne=Ee.object,Re=Ee.geometry,He=Ee.group;let We=Ee.material;We.allowOverride===!0&&J!==null&&(We=J),Ne.layers.test(Z.layers)&&gu(Ne,X,Z,Re,We,He)}}function gu(C,X,Z,J,q,ue){C.onBeforeRender(x,X,Z,J,q,ue),C.modelViewMatrix.multiplyMatrices(Z.matrixWorldInverse,C.matrixWorld),C.normalMatrix.getNormalMatrix(C.modelViewMatrix),q.onBeforeRender(x,X,Z,J,C,ue),q.transparent===!0&&q.side===Et&&q.forceSinglePass===!1?(q.side=cn,q.needsUpdate=!0,x.renderBufferDirect(Z,X,J,q,C,ue),q.side=mi,q.needsUpdate=!0,x.renderBufferDirect(Z,X,J,q,C,ue),q.side=Et):x.renderBufferDirect(Z,X,J,q,C,ue),C.onAfterRender(x,X,Z,J,q,ue)}function ta(C,X,Z){X.isScene!==!0&&(X=fe);const J=oe.get(C),q=f.state.lights,ue=f.state.shadowsArray,Ee=q.state.version,Ne=Q.getParameters(C,q.state,ue,X,Z),Re=Q.getProgramCacheKey(Ne);let He=J.programs;J.environment=C.isMeshStandardMaterial?X.environment:null,J.fog=X.fog,J.envMap=(C.isMeshStandardMaterial?De:Ye).get(C.envMap||J.environment),J.envMapRotation=J.environment!==null&&C.envMap===null?X.environmentRotation:C.envMapRotation,He===void 0&&(C.addEventListener("dispose",se),He=new Map,J.programs=He);let We=He.get(Re);if(We!==void 0){if(J.currentProgram===We&&J.lightsStateVersion===Ee)return _u(C,Ne),We}else Ne.uniforms=Q.getUniforms(C),C.onBeforeCompile(Ne,x),We=Q.acquireProgram(Ne,Re),He.set(Re,We),J.uniforms=Ne.uniforms;const ke=J.uniforms;return(!C.isShaderMaterial&&!C.isRawShaderMaterial||C.clipping===!0)&&(ke.clippingPlanes=le.uniform),_u(C,Ne),J.needsLights=ap(C),J.lightsStateVersion=Ee,J.needsLights&&(ke.ambientLightColor.value=q.state.ambient,ke.lightProbe.value=q.state.probe,ke.directionalLights.value=q.state.directional,ke.directionalLightShadows.value=q.state.directionalShadow,ke.spotLights.value=q.state.spot,ke.spotLightShadows.value=q.state.spotShadow,ke.rectAreaLights.value=q.state.rectArea,ke.ltc_1.value=q.state.rectAreaLTC1,ke.ltc_2.value=q.state.rectAreaLTC2,ke.pointLights.value=q.state.point,ke.pointLightShadows.value=q.state.pointShadow,ke.hemisphereLights.value=q.state.hemi,ke.directionalShadowMap.value=q.state.directionalShadowMap,ke.directionalShadowMatrix.value=q.state.directionalShadowMatrix,ke.spotShadowMap.value=q.state.spotShadowMap,ke.spotLightMatrix.value=q.state.spotLightMatrix,ke.spotLightMap.value=q.state.spotLightMap,ke.pointShadowMap.value=q.state.pointShadowMap,ke.pointShadowMatrix.value=q.state.pointShadowMatrix),J.currentProgram=We,J.uniformsList=null,We}function vu(C){if(C.uniformsList===null){const X=C.currentProgram.getUniforms();C.uniformsList=Ha.seqWithValue(X.seq,C.uniforms)}return C.uniformsList}function _u(C,X){const Z=oe.get(C);Z.outputColorSpace=X.outputColorSpace,Z.batching=X.batching,Z.batchingColor=X.batchingColor,Z.instancing=X.instancing,Z.instancingColor=X.instancingColor,Z.instancingMorph=X.instancingMorph,Z.skinning=X.skinning,Z.morphTargets=X.morphTargets,Z.morphNormals=X.morphNormals,Z.morphColors=X.morphColors,Z.morphTargetsCount=X.morphTargetsCount,Z.numClippingPlanes=X.numClippingPlanes,Z.numIntersection=X.numClipIntersection,Z.vertexAlphas=X.vertexAlphas,Z.vertexTangents=X.vertexTangents,Z.toneMapping=X.toneMapping}function rp(C,X,Z,J,q){X.isScene!==!0&&(X=fe),Se.resetTextureUnits();const ue=X.fog,Ee=J.isMeshStandardMaterial?X.environment:null,Ne=A===null?x.outputColorSpace:A.isXRRenderTarget===!0?A.texture.colorSpace:nn,Re=(J.isMeshStandardMaterial?De:Ye).get(J.envMap||Ee),He=J.vertexColors===!0&&!!Z.attributes.color&&Z.attributes.color.itemSize===4,We=!!Z.attributes.tangent&&(!!J.normalMap||J.anisotropy>0),ke=!!Z.morphAttributes.position,et=!!Z.morphAttributes.normal,ft=!!Z.morphAttributes.color;let It=Li;J.toneMapped&&(A===null||A.isXRRenderTarget===!0)&&(It=x.toneMapping);const yt=Z.morphAttributes.position||Z.morphAttributes.normal||Z.morphAttributes.color,mt=yt!==void 0?yt.length:0,Ve=oe.get(J),At=f.state.lights;if(F===!0&&(O===!0||C!==b)){const jt=C===b&&J.id===S;le.setState(J,C,jt)}let it=!1;J.version===Ve.__version?(Ve.needsLights&&Ve.lightsStateVersion!==At.state.version||Ve.outputColorSpace!==Ne||q.isBatchedMesh&&Ve.batching===!1||!q.isBatchedMesh&&Ve.batching===!0||q.isBatchedMesh&&Ve.batchingColor===!0&&q.colorTexture===null||q.isBatchedMesh&&Ve.batchingColor===!1&&q.colorTexture!==null||q.isInstancedMesh&&Ve.instancing===!1||!q.isInstancedMesh&&Ve.instancing===!0||q.isSkinnedMesh&&Ve.skinning===!1||!q.isSkinnedMesh&&Ve.skinning===!0||q.isInstancedMesh&&Ve.instancingColor===!0&&q.instanceColor===null||q.isInstancedMesh&&Ve.instancingColor===!1&&q.instanceColor!==null||q.isInstancedMesh&&Ve.instancingMorph===!0&&q.morphTexture===null||q.isInstancedMesh&&Ve.instancingMorph===!1&&q.morphTexture!==null||Ve.envMap!==Re||J.fog===!0&&Ve.fog!==ue||Ve.numClippingPlanes!==void 0&&(Ve.numClippingPlanes!==le.numPlanes||Ve.numIntersection!==le.numIntersection)||Ve.vertexAlphas!==He||Ve.vertexTangents!==We||Ve.morphTargets!==ke||Ve.morphNormals!==et||Ve.morphColors!==ft||Ve.toneMapping!==It||Ve.morphTargetsCount!==mt)&&(it=!0):(it=!0,Ve.__version=J.version);let fn=Ve.currentProgram;it===!0&&(fn=ta(J,X,q));let ir=!1,pn=!1,os=!1;const wt=fn.getUniforms(),bn=Ve.uniforms;if(ae.useProgram(fn.program)&&(ir=!0,pn=!0,os=!0),J.id!==S&&(S=J.id,pn=!0),ir||b!==C){ae.buffers.depth.getReversed()&&C.reversedDepth!==!0&&(C._reversedDepth=!0,C.updateProjectionMatrix()),wt.setValue(P,"projectionMatrix",C.projectionMatrix),wt.setValue(P,"viewMatrix",C.matrixWorldInverse);const rn=wt.map.cameraPosition;rn!==void 0&&rn.setValue(P,ne.setFromMatrixPosition(C.matrixWorld)),ge.logarithmicDepthBuffer&&wt.setValue(P,"logDepthBufFC",2/(Math.log(C.far+1)/Math.LN2)),(J.isMeshPhongMaterial||J.isMeshToonMaterial||J.isMeshLambertMaterial||J.isMeshBasicMaterial||J.isMeshStandardMaterial||J.isShaderMaterial)&&wt.setValue(P,"isOrthographic",C.isOrthographicCamera===!0),b!==C&&(b=C,pn=!0,os=!0)}if(q.isSkinnedMesh){wt.setOptional(P,q,"bindMatrix"),wt.setOptional(P,q,"bindMatrixInverse");const jt=q.skeleton;jt&&(jt.boneTexture===null&&jt.computeBoneTexture(),wt.setValue(P,"boneTexture",jt.boneTexture,Se))}q.isBatchedMesh&&(wt.setOptional(P,q,"batchingTexture"),wt.setValue(P,"batchingTexture",q._matricesTexture,Se),wt.setOptional(P,q,"batchingIdTexture"),wt.setValue(P,"batchingIdTexture",q._indirectTexture,Se),wt.setOptional(P,q,"batchingColorTexture"),q._colorsTexture!==null&&wt.setValue(P,"batchingColorTexture",q._colorsTexture,Se));const Sn=Z.morphAttributes;if((Sn.position!==void 0||Sn.normal!==void 0||Sn.color!==void 0)&&de.update(q,Z,fn),(pn||Ve.receiveShadow!==q.receiveShadow)&&(Ve.receiveShadow=q.receiveShadow,wt.setValue(P,"receiveShadow",q.receiveShadow)),J.isMeshGouraudMaterial&&J.envMap!==null&&(bn.envMap.value=Re,bn.flipEnvMap.value=Re.isCubeTexture&&Re.isRenderTargetTexture===!1?-1:1),J.isMeshStandardMaterial&&J.envMap===null&&X.environment!==null&&(bn.envMapIntensity.value=X.environmentIntensity),pn&&(wt.setValue(P,"toneMappingExposure",x.toneMappingExposure),Ve.needsLights&&sp(bn,os),ue&&J.fog===!0&&ie.refreshFogUniforms(bn,ue),ie.refreshMaterialUniforms(bn,J,B,N,f.state.transmissionRenderTarget[C.id]),Ha.upload(P,vu(Ve),bn,Se)),J.isShaderMaterial&&J.uniformsNeedUpdate===!0&&(Ha.upload(P,vu(Ve),bn,Se),J.uniformsNeedUpdate=!1),J.isSpriteMaterial&&wt.setValue(P,"center",q.center),wt.setValue(P,"modelViewMatrix",q.modelViewMatrix),wt.setValue(P,"normalMatrix",q.normalMatrix),wt.setValue(P,"modelMatrix",q.matrixWorld),J.isShaderMaterial||J.isRawShaderMaterial){const jt=J.uniformsGroups;for(let rn=0,Po=jt.length;rn<Po;rn++){const Bi=jt[rn];Ke.update(Bi,fn),Ke.bind(Bi,fn)}}return fn}function sp(C,X){C.ambientLightColor.needsUpdate=X,C.lightProbe.needsUpdate=X,C.directionalLights.needsUpdate=X,C.directionalLightShadows.needsUpdate=X,C.pointLights.needsUpdate=X,C.pointLightShadows.needsUpdate=X,C.spotLights.needsUpdate=X,C.spotLightShadows.needsUpdate=X,C.rectAreaLights.needsUpdate=X,C.hemisphereLights.needsUpdate=X}function ap(C){return C.isMeshLambertMaterial||C.isMeshToonMaterial||C.isMeshPhongMaterial||C.isMeshStandardMaterial||C.isShadowMaterial||C.isShaderMaterial&&C.lights===!0}this.getActiveCubeFace=function(){return M},this.getActiveMipmapLevel=function(){return w},this.getRenderTarget=function(){return A},this.setRenderTargetTextures=function(C,X,Z){const J=oe.get(C);J.__autoAllocateDepthBuffer=C.resolveDepthBuffer===!1,J.__autoAllocateDepthBuffer===!1&&(J.__useRenderToTexture=!1),oe.get(C.texture).__webglTexture=X,oe.get(C.depthTexture).__webglTexture=J.__autoAllocateDepthBuffer?void 0:Z,J.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(C,X){const Z=oe.get(C);Z.__webglFramebuffer=X,Z.__useDefaultFramebuffer=X===void 0};const op=P.createFramebuffer();this.setRenderTarget=function(C,X=0,Z=0){A=C,M=X,w=Z;let J=!0,q=null,ue=!1,Ee=!1;if(C){const Re=oe.get(C);if(Re.__useDefaultFramebuffer!==void 0)ae.bindFramebuffer(P.FRAMEBUFFER,null),J=!1;else if(Re.__webglFramebuffer===void 0)Se.setupRenderTarget(C);else if(Re.__hasExternalTextures)Se.rebindTextures(C,oe.get(C.texture).__webglTexture,oe.get(C.depthTexture).__webglTexture);else if(C.depthBuffer){const ke=C.depthTexture;if(Re.__boundDepthTexture!==ke){if(ke!==null&&oe.has(ke)&&(C.width!==ke.image.width||C.height!==ke.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");Se.setupDepthRenderbuffer(C)}}const He=C.texture;(He.isData3DTexture||He.isDataArrayTexture||He.isCompressedArrayTexture)&&(Ee=!0);const We=oe.get(C).__webglFramebuffer;C.isWebGLCubeRenderTarget?(Array.isArray(We[X])?q=We[X][Z]:q=We[X],ue=!0):C.samples>0&&Se.useMultisampledRTT(C)===!1?q=oe.get(C).__webglMultisampledFramebuffer:Array.isArray(We)?q=We[Z]:q=We,T.copy(C.viewport),D.copy(C.scissor),k=C.scissorTest}else T.copy(ee).multiplyScalar(B).floor(),D.copy($).multiplyScalar(B).floor(),k=re;if(Z!==0&&(q=op),ae.bindFramebuffer(P.FRAMEBUFFER,q)&&J&&ae.drawBuffers(C,q),ae.viewport(T),ae.scissor(D),ae.setScissorTest(k),ue){const Re=oe.get(C.texture);P.framebufferTexture2D(P.FRAMEBUFFER,P.COLOR_ATTACHMENT0,P.TEXTURE_CUBE_MAP_POSITIVE_X+X,Re.__webglTexture,Z)}else if(Ee){const Re=X;for(let He=0;He<C.textures.length;He++){const We=oe.get(C.textures[He]);P.framebufferTextureLayer(P.FRAMEBUFFER,P.COLOR_ATTACHMENT0+He,We.__webglTexture,Z,Re)}}else if(C!==null&&Z!==0){const Re=oe.get(C.texture);P.framebufferTexture2D(P.FRAMEBUFFER,P.COLOR_ATTACHMENT0,P.TEXTURE_2D,Re.__webglTexture,Z)}S=-1},this.readRenderTargetPixels=function(C,X,Z,J,q,ue,Ee,Ne=0){if(!(C&&C.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Re=oe.get(C).__webglFramebuffer;if(C.isWebGLCubeRenderTarget&&Ee!==void 0&&(Re=Re[Ee]),Re){ae.bindFramebuffer(P.FRAMEBUFFER,Re);try{const He=C.textures[Ne],We=He.format,ke=He.type;if(!ge.textureFormatReadable(We)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!ge.textureTypeReadable(ke)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}X>=0&&X<=C.width-J&&Z>=0&&Z<=C.height-q&&(C.textures.length>1&&P.readBuffer(P.COLOR_ATTACHMENT0+Ne),P.readPixels(X,Z,J,q,Be.convert(We),Be.convert(ke),ue))}finally{const He=A!==null?oe.get(A).__webglFramebuffer:null;ae.bindFramebuffer(P.FRAMEBUFFER,He)}}},this.readRenderTargetPixelsAsync=async function(C,X,Z,J,q,ue,Ee,Ne=0){if(!(C&&C.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let Re=oe.get(C).__webglFramebuffer;if(C.isWebGLCubeRenderTarget&&Ee!==void 0&&(Re=Re[Ee]),Re)if(X>=0&&X<=C.width-J&&Z>=0&&Z<=C.height-q){ae.bindFramebuffer(P.FRAMEBUFFER,Re);const He=C.textures[Ne],We=He.format,ke=He.type;if(!ge.textureFormatReadable(We))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!ge.textureTypeReadable(ke))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const et=P.createBuffer();P.bindBuffer(P.PIXEL_PACK_BUFFER,et),P.bufferData(P.PIXEL_PACK_BUFFER,ue.byteLength,P.STREAM_READ),C.textures.length>1&&P.readBuffer(P.COLOR_ATTACHMENT0+Ne),P.readPixels(X,Z,J,q,Be.convert(We),Be.convert(ke),0);const ft=A!==null?oe.get(A).__webglFramebuffer:null;ae.bindFramebuffer(P.FRAMEBUFFER,ft);const It=P.fenceSync(P.SYNC_GPU_COMMANDS_COMPLETE,0);return P.flush(),await Em(P,It,4),P.bindBuffer(P.PIXEL_PACK_BUFFER,et),P.getBufferSubData(P.PIXEL_PACK_BUFFER,0,ue),P.deleteBuffer(et),P.deleteSync(It),ue}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(C,X=null,Z=0){const J=Math.pow(2,-Z),q=Math.floor(C.image.width*J),ue=Math.floor(C.image.height*J),Ee=X!==null?X.x:0,Ne=X!==null?X.y:0;Se.setTexture2D(C,0),P.copyTexSubImage2D(P.TEXTURE_2D,Z,0,0,Ee,Ne,q,ue),ae.unbindTexture()};const lp=P.createFramebuffer(),cp=P.createFramebuffer();this.copyTextureToTexture=function(C,X,Z=null,J=null,q=0,ue=null){ue===null&&(q!==0?(Fs("WebGLRenderer: copyTextureToTexture function signature has changed to support src and dst mipmap levels."),ue=q,q=0):ue=0);let Ee,Ne,Re,He,We,ke,et,ft,It;const yt=C.isCompressedTexture?C.mipmaps[ue]:C.image;if(Z!==null)Ee=Z.max.x-Z.min.x,Ne=Z.max.y-Z.min.y,Re=Z.isBox3?Z.max.z-Z.min.z:1,He=Z.min.x,We=Z.min.y,ke=Z.isBox3?Z.min.z:0;else{const Sn=Math.pow(2,-q);Ee=Math.floor(yt.width*Sn),Ne=Math.floor(yt.height*Sn),C.isDataArrayTexture?Re=yt.depth:C.isData3DTexture?Re=Math.floor(yt.depth*Sn):Re=1,He=0,We=0,ke=0}J!==null?(et=J.x,ft=J.y,It=J.z):(et=0,ft=0,It=0);const mt=Be.convert(X.format),Ve=Be.convert(X.type);let At;X.isData3DTexture?(Se.setTexture3D(X,0),At=P.TEXTURE_3D):X.isDataArrayTexture||X.isCompressedArrayTexture?(Se.setTexture2DArray(X,0),At=P.TEXTURE_2D_ARRAY):(Se.setTexture2D(X,0),At=P.TEXTURE_2D),P.pixelStorei(P.UNPACK_FLIP_Y_WEBGL,X.flipY),P.pixelStorei(P.UNPACK_PREMULTIPLY_ALPHA_WEBGL,X.premultiplyAlpha),P.pixelStorei(P.UNPACK_ALIGNMENT,X.unpackAlignment);const it=P.getParameter(P.UNPACK_ROW_LENGTH),fn=P.getParameter(P.UNPACK_IMAGE_HEIGHT),ir=P.getParameter(P.UNPACK_SKIP_PIXELS),pn=P.getParameter(P.UNPACK_SKIP_ROWS),os=P.getParameter(P.UNPACK_SKIP_IMAGES);P.pixelStorei(P.UNPACK_ROW_LENGTH,yt.width),P.pixelStorei(P.UNPACK_IMAGE_HEIGHT,yt.height),P.pixelStorei(P.UNPACK_SKIP_PIXELS,He),P.pixelStorei(P.UNPACK_SKIP_ROWS,We),P.pixelStorei(P.UNPACK_SKIP_IMAGES,ke);const wt=C.isDataArrayTexture||C.isData3DTexture,bn=X.isDataArrayTexture||X.isData3DTexture;if(C.isDepthTexture){const Sn=oe.get(C),jt=oe.get(X),rn=oe.get(Sn.__renderTarget),Po=oe.get(jt.__renderTarget);ae.bindFramebuffer(P.READ_FRAMEBUFFER,rn.__webglFramebuffer),ae.bindFramebuffer(P.DRAW_FRAMEBUFFER,Po.__webglFramebuffer);for(let Bi=0;Bi<Re;Bi++)wt&&(P.framebufferTextureLayer(P.READ_FRAMEBUFFER,P.COLOR_ATTACHMENT0,oe.get(C).__webglTexture,q,ke+Bi),P.framebufferTextureLayer(P.DRAW_FRAMEBUFFER,P.COLOR_ATTACHMENT0,oe.get(X).__webglTexture,ue,It+Bi)),P.blitFramebuffer(He,We,Ee,Ne,et,ft,Ee,Ne,P.DEPTH_BUFFER_BIT,P.NEAREST);ae.bindFramebuffer(P.READ_FRAMEBUFFER,null),ae.bindFramebuffer(P.DRAW_FRAMEBUFFER,null)}else if(q!==0||C.isRenderTargetTexture||oe.has(C)){const Sn=oe.get(C),jt=oe.get(X);ae.bindFramebuffer(P.READ_FRAMEBUFFER,lp),ae.bindFramebuffer(P.DRAW_FRAMEBUFFER,cp);for(let rn=0;rn<Re;rn++)wt?P.framebufferTextureLayer(P.READ_FRAMEBUFFER,P.COLOR_ATTACHMENT0,Sn.__webglTexture,q,ke+rn):P.framebufferTexture2D(P.READ_FRAMEBUFFER,P.COLOR_ATTACHMENT0,P.TEXTURE_2D,Sn.__webglTexture,q),bn?P.framebufferTextureLayer(P.DRAW_FRAMEBUFFER,P.COLOR_ATTACHMENT0,jt.__webglTexture,ue,It+rn):P.framebufferTexture2D(P.DRAW_FRAMEBUFFER,P.COLOR_ATTACHMENT0,P.TEXTURE_2D,jt.__webglTexture,ue),q!==0?P.blitFramebuffer(He,We,Ee,Ne,et,ft,Ee,Ne,P.COLOR_BUFFER_BIT,P.NEAREST):bn?P.copyTexSubImage3D(At,ue,et,ft,It+rn,He,We,Ee,Ne):P.copyTexSubImage2D(At,ue,et,ft,He,We,Ee,Ne);ae.bindFramebuffer(P.READ_FRAMEBUFFER,null),ae.bindFramebuffer(P.DRAW_FRAMEBUFFER,null)}else bn?C.isDataTexture||C.isData3DTexture?P.texSubImage3D(At,ue,et,ft,It,Ee,Ne,Re,mt,Ve,yt.data):X.isCompressedArrayTexture?P.compressedTexSubImage3D(At,ue,et,ft,It,Ee,Ne,Re,mt,yt.data):P.texSubImage3D(At,ue,et,ft,It,Ee,Ne,Re,mt,Ve,yt):C.isDataTexture?P.texSubImage2D(P.TEXTURE_2D,ue,et,ft,Ee,Ne,mt,Ve,yt.data):C.isCompressedTexture?P.compressedTexSubImage2D(P.TEXTURE_2D,ue,et,ft,yt.width,yt.height,mt,yt.data):P.texSubImage2D(P.TEXTURE_2D,ue,et,ft,Ee,Ne,mt,Ve,yt);P.pixelStorei(P.UNPACK_ROW_LENGTH,it),P.pixelStorei(P.UNPACK_IMAGE_HEIGHT,fn),P.pixelStorei(P.UNPACK_SKIP_PIXELS,ir),P.pixelStorei(P.UNPACK_SKIP_ROWS,pn),P.pixelStorei(P.UNPACK_SKIP_IMAGES,os),ue===0&&X.generateMipmaps&&P.generateMipmap(At),ae.unbindTexture()},this.initRenderTarget=function(C){oe.get(C).__webglFramebuffer===void 0&&Se.setupRenderTarget(C)},this.initTexture=function(C){C.isCubeTexture?Se.setTextureCube(C,0):C.isData3DTexture?Se.setTexture3D(C,0):C.isDataArrayTexture||C.isCompressedArrayTexture?Se.setTexture2DArray(C,0):Se.setTexture2D(C,0),ae.unbindTexture()},this.resetState=function(){M=0,w=0,A=null,ae.reset(),Me.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return qn}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const t=this.getContext();t.drawingBufferColorSpace=tt._getDrawingBufferColorSpace(e),t.unpackColorSpace=tt._getUnpackColorSpace()}}const by=`
  varying vec2 vUv;
  void main() {
    vUv = uv;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`,Sy=`
  precision highp float;
  varying vec2 vUv;
  uniform float uTime;
  uniform float uFlow;
  uniform float uDensity;
  uniform float uStrength;
  uniform float uSeed;
  uniform float uBreath;
  uniform vec3 uCool;
  uniform vec3 uWarm;

  float hash21(vec2 p) {
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
  }
  float noise2(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(
      mix(hash21(i), hash21(i + vec2(1.0, 0.0)), u.x),
      mix(hash21(i + vec2(0.0, 1.0)), hash21(i + vec2(1.0, 1.0)), u.x),
      u.y
    );
  }
  float fbm(vec2 p) {
    float v = 0.0;
    float a = .5;
    for (int i = 0; i < 3; ++i) {
      v += a * noise2(p);
      p = p * 2.03 + vec2(3.73, 4.17);
      a *= .5;
    }
    return v;
  }
  void main() {
    vec2 uv = vUv;
    float motion = uTime * uFlow;
    vec2 drift = vec2(motion * .012, -motion * .006);
    // So a nuvem e deformada. A imagem principal da ESO nunca usa este shader.
    float domain = fbm(uv * 2.9 + drift + vec2(uSeed, uSeed * .34));
    vec2 advected = uv * vec2(4.6, 3.7) + vec2(domain * .62, -domain * .37);
    advected += drift;
    float body = fbm(advected + uSeed * .13);
    float wisps = fbm(advected * 2.8 + vec2(.0, motion * .014));
    float horizontal = uv.y - (.51 + .08 * sin(uv.x * 5.4 + uSeed));
    float band = exp(-horizontal * horizontal * 10.5);
    float edges = smoothstep(.01, .22, uv.x) * smoothstep(.01, .22, 1.0-uv.x)
      * smoothstep(.02, .18, uv.y) * smoothstep(.02, .18, 1.0-uv.y);
    float volume = smoothstep(.45, .68, body);
    float threads = smoothstep(.57, .78, wisps) * smoothstep(.35, .76, body);
    float alpha = (volume * .68 + threads * .32) * band * edges
      * uDensity * uStrength * uBreath;
    vec3 color = mix(uCool, uWarm, clamp(body * .85 + threads * .24, 0.0, 1.0));
    color *= (.68 + .56 * threads) * (1.0 + (uBreath-1.0)*.35);
    gl_FragColor = vec4(color, clamp(alpha, 0.0, .16));
    #include <colorspace_fragment>
  }
`,My=[{name:"07 · Gás profundo",z:-225,x:-20,y:6,aspect:2.72,factor:1.55,order:2.6,opacity:.44,seed:1.7,cool:"#314778",warm:"#7853a8"},{name:"08 · Filamentos violetas",z:-195,x:12,y:-6,aspect:2.72,factor:1.54,order:3.3,opacity:.57,seed:8.3,cool:"#403d80",warm:"#ac70c5"},{name:"09 · Nuvens intermediárias",z:-169,x:-9,y:1,aspect:2.66,factor:1.5,order:3.7,opacity:.51,seed:13.6,cool:"#345a91",warm:"#8d59a8"},{name:"10 · Reflexos no gás",z:-112,x:5,y:-4,aspect:2.55,factor:1.56,order:4.6,opacity:.35,seed:23.8,cool:"#406aa3",warm:"#b47aab"},{name:"11 · Véu próximo",z:-73,x:13,y:-10,aspect:2.52,factor:1.65,order:5.3,opacity:.28,seed:31.2,cool:"#343d77",warm:"#6b578e"}];function Ey(i,{reducedMotion:e=!1}={}){const t={density:.46,flow:.27,bloom:.18},n=[];for(const o of My){const l=new Rt({vertexShader:by,fragmentShader:Sy,transparent:!0,depthTest:!1,depthWrite:!1,blending:tn,side:Et,toneMapped:!1,uniforms:{uTime:{value:0},uFlow:{value:e?0:t.flow},uDensity:{value:t.density},uStrength:{value:o.opacity},uSeed:{value:o.seed},uBreath:{value:1},uCool:{value:new Ie(o.cool)},uWarm:{value:new Ie(o.warm)}}}),c=new ht(new yn(1,1),l);c.position.set(o.x,o.y,o.z),c.renderOrder=o.order,c.userData.aspect=o.aspect,c.userData.factor=o.factor,c.userData.layerName=o.name,c.userData.breathRate=.38+o.seed%5*.045,c.userData.breathPhase=o.seed*.83,i.add(c),n.push(c)}function r(o){for(const l of n){l.material.uniforms.uTime.value=e?0:o,l.material.uniforms.uFlow.value=e?0:t.flow,l.material.uniforms.uDensity.value=t.density;const c=l.userData.breathRate,d=l.userData.breathPhase;l.material.uniforms.uBreath.value=e?1:1+.036*Math.sin(o*c+d)+.016*Math.sin(o*(c*.61)+d*1.71)}}function s(o){t.density=_e.clamp(o,0,1.5)}function a(o){t.flow=_e.clamp(o,0,1)}return{layers:n,state:t,update:r,setDensity:s,setFlow:a}}const Ga={name:"CopyShader",uniforms:{tDiffuse:{value:null},opacity:{value:1}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform float opacity;

		uniform sampler2D tDiffuse;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );
			gl_FragColor = opacity * texel;


		}`};class Ys{constructor(){this.isPass=!0,this.enabled=!0,this.needsSwap=!0,this.clear=!1,this.renderToScreen=!1}setSize(){}render(){console.error("THREE.Pass: .render() must be implemented in derived pass.")}dispose(){}}const Ty=new qs(-1,1,1,-1,0,1);class Ay extends Lt{constructor(){super(),this.setAttribute("position",new nt([-1,3,0,-1,-1,0,3,-1,0],3)),this.setAttribute("uv",new nt([0,2,0,0,2,0],2))}}const wy=new Ay;class Af{constructor(e){this._mesh=new ht(wy,e)}dispose(){this._mesh.geometry.dispose()}render(e){e.render(this._mesh,Ty)}get material(){return this._mesh.material}set material(e){this._mesh.material=e}}class Ry extends Ys{constructor(e,t="tDiffuse"){super(),this.textureID=t,this.uniforms=null,this.material=null,e instanceof Rt?(this.uniforms=e.uniforms,this.material=e):e&&(this.uniforms=Ya.clone(e.uniforms),this.material=new Rt({name:e.name!==void 0?e.name:"unspecified",defines:Object.assign({},e.defines),uniforms:this.uniforms,vertexShader:e.vertexShader,fragmentShader:e.fragmentShader})),this._fsQuad=new Af(this.material)}render(e,t,n){this.uniforms[this.textureID]&&(this.uniforms[this.textureID].value=n.texture),this._fsQuad.material=this.material,this.renderToScreen?(e.setRenderTarget(null),this._fsQuad.render(e)):(e.setRenderTarget(t),this.clear&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),this._fsQuad.render(e))}dispose(){this.material.dispose(),this._fsQuad.dispose()}}class kd extends Ys{constructor(e,t){super(),this.scene=e,this.camera=t,this.clear=!0,this.needsSwap=!1,this.inverse=!1}render(e,t,n){const r=e.getContext(),s=e.state;s.buffers.color.setMask(!1),s.buffers.depth.setMask(!1),s.buffers.color.setLocked(!0),s.buffers.depth.setLocked(!0);let a,o;this.inverse?(a=0,o=1):(a=1,o=0),s.buffers.stencil.setTest(!0),s.buffers.stencil.setOp(r.REPLACE,r.REPLACE,r.REPLACE),s.buffers.stencil.setFunc(r.ALWAYS,a,4294967295),s.buffers.stencil.setClear(o),s.buffers.stencil.setLocked(!0),e.setRenderTarget(n),this.clear&&e.clear(),e.render(this.scene,this.camera),e.setRenderTarget(t),this.clear&&e.clear(),e.render(this.scene,this.camera),s.buffers.color.setLocked(!1),s.buffers.depth.setLocked(!1),s.buffers.color.setMask(!0),s.buffers.depth.setMask(!0),s.buffers.stencil.setLocked(!1),s.buffers.stencil.setFunc(r.EQUAL,1,4294967295),s.buffers.stencil.setOp(r.KEEP,r.KEEP,r.KEEP),s.buffers.stencil.setLocked(!0)}}class Cy extends Ys{constructor(){super(),this.needsSwap=!1}render(e){e.state.buffers.stencil.setLocked(!1),e.state.buffers.stencil.setTest(!1)}}class Iy{constructor(e,t){if(this.renderer=e,this._pixelRatio=e.getPixelRatio(),t===void 0){const n=e.getSize(new Ce);this._width=n.width,this._height=n.height,t=new zn(this._width*this._pixelRatio,this._height*this._pixelRatio,{type:fi}),t.texture.name="EffectComposer.rt1"}else this._width=t.width,this._height=t.height;this.renderTarget1=t,this.renderTarget2=t.clone(),this.renderTarget2.texture.name="EffectComposer.rt2",this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2,this.renderToScreen=!0,this.passes=[],this.copyPass=new Ry(Ga),this.copyPass.material.blending=hi,this.clock=new wg}swapBuffers(){const e=this.readBuffer;this.readBuffer=this.writeBuffer,this.writeBuffer=e}addPass(e){this.passes.push(e),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}insertPass(e,t){this.passes.splice(t,0,e),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}removePass(e){const t=this.passes.indexOf(e);t!==-1&&this.passes.splice(t,1)}isLastEnabledPass(e){for(let t=e+1;t<this.passes.length;t++)if(this.passes[t].enabled)return!1;return!0}render(e){e===void 0&&(e=this.clock.getDelta());const t=this.renderer.getRenderTarget();let n=!1;for(let r=0,s=this.passes.length;r<s;r++){const a=this.passes[r];if(a.enabled!==!1){if(a.renderToScreen=this.renderToScreen&&this.isLastEnabledPass(r),a.render(this.renderer,this.writeBuffer,this.readBuffer,e,n),a.needsSwap){if(n){const o=this.renderer.getContext(),l=this.renderer.state.buffers.stencil;l.setFunc(o.NOTEQUAL,1,4294967295),this.copyPass.render(this.renderer,this.writeBuffer,this.readBuffer,e),l.setFunc(o.EQUAL,1,4294967295)}this.swapBuffers()}kd!==void 0&&(a instanceof kd?n=!0:a instanceof Cy&&(n=!1))}}this.renderer.setRenderTarget(t)}reset(e){if(e===void 0){const t=this.renderer.getSize(new Ce);this._pixelRatio=this.renderer.getPixelRatio(),this._width=t.width,this._height=t.height,e=this.renderTarget1.clone(),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.renderTarget1=e,this.renderTarget2=e.clone(),this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2}setSize(e,t){this._width=e,this._height=t;const n=this._width*this._pixelRatio,r=this._height*this._pixelRatio;this.renderTarget1.setSize(n,r),this.renderTarget2.setSize(n,r);for(let s=0;s<this.passes.length;s++)this.passes[s].setSize(n,r)}setPixelRatio(e){this._pixelRatio=e,this.setSize(this._width,this._height)}dispose(){this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.copyPass.dispose()}}class Py extends Ys{constructor(e,t,n=null,r=null,s=null){super(),this.scene=e,this.camera=t,this.overrideMaterial=n,this.clearColor=r,this.clearAlpha=s,this.clear=!0,this.clearDepth=!1,this.needsSwap=!1,this._oldClearColor=new Ie}render(e,t,n){const r=e.autoClear;e.autoClear=!1;let s,a;this.overrideMaterial!==null&&(a=this.scene.overrideMaterial,this.scene.overrideMaterial=this.overrideMaterial),this.clearColor!==null&&(e.getClearColor(this._oldClearColor),e.setClearColor(this.clearColor,e.getClearAlpha())),this.clearAlpha!==null&&(s=e.getClearAlpha(),e.setClearAlpha(this.clearAlpha)),this.clearDepth==!0&&e.clearDepth(),e.setRenderTarget(this.renderToScreen?null:n),this.clear===!0&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),e.render(this.scene,this.camera),this.clearColor!==null&&e.setClearColor(this._oldClearColor),this.clearAlpha!==null&&e.setClearAlpha(s),this.overrideMaterial!==null&&(this.scene.overrideMaterial=a),e.autoClear=r}}const Ly={uniforms:{tDiffuse:{value:null},luminosityThreshold:{value:1},smoothWidth:{value:1},defaultColor:{value:new Ie(0)},defaultOpacity:{value:0}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;

			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform sampler2D tDiffuse;
		uniform vec3 defaultColor;
		uniform float defaultOpacity;
		uniform float luminosityThreshold;
		uniform float smoothWidth;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );

			float v = luminance( texel.xyz );

			vec4 outputColor = vec4( defaultColor.rgb, defaultOpacity );

			float alpha = smoothstep( luminosityThreshold, luminosityThreshold + smoothWidth, v );

			gl_FragColor = mix( outputColor, texel, alpha );

		}`};class $r extends Ys{constructor(e,t=1,n,r){super(),this.strength=t,this.radius=n,this.threshold=r,this.resolution=e!==void 0?new Ce(e.x,e.y):new Ce(256,256),this.clearColor=new Ie(0,0,0),this.needsSwap=!1,this.renderTargetsHorizontal=[],this.renderTargetsVertical=[],this.nMips=5;let s=Math.round(this.resolution.x/2),a=Math.round(this.resolution.y/2);this.renderTargetBright=new zn(s,a,{type:fi}),this.renderTargetBright.texture.name="UnrealBloomPass.bright",this.renderTargetBright.texture.generateMipmaps=!1;for(let d=0;d<this.nMips;d++){const u=new zn(s,a,{type:fi});u.texture.name="UnrealBloomPass.h"+d,u.texture.generateMipmaps=!1,this.renderTargetsHorizontal.push(u);const h=new zn(s,a,{type:fi});h.texture.name="UnrealBloomPass.v"+d,h.texture.generateMipmaps=!1,this.renderTargetsVertical.push(h),s=Math.round(s/2),a=Math.round(a/2)}const o=Ly;this.highPassUniforms=Ya.clone(o.uniforms),this.highPassUniforms.luminosityThreshold.value=r,this.highPassUniforms.smoothWidth.value=.01,this.materialHighPassFilter=new Rt({uniforms:this.highPassUniforms,vertexShader:o.vertexShader,fragmentShader:o.fragmentShader}),this.separableBlurMaterials=[];const l=[3,5,7,9,11];s=Math.round(this.resolution.x/2),a=Math.round(this.resolution.y/2);for(let d=0;d<this.nMips;d++)this.separableBlurMaterials.push(this._getSeparableBlurMaterial(l[d])),this.separableBlurMaterials[d].uniforms.invSize.value=new Ce(1/s,1/a),s=Math.round(s/2),a=Math.round(a/2);this.compositeMaterial=this._getCompositeMaterial(this.nMips),this.compositeMaterial.uniforms.blurTexture1.value=this.renderTargetsVertical[0].texture,this.compositeMaterial.uniforms.blurTexture2.value=this.renderTargetsVertical[1].texture,this.compositeMaterial.uniforms.blurTexture3.value=this.renderTargetsVertical[2].texture,this.compositeMaterial.uniforms.blurTexture4.value=this.renderTargetsVertical[3].texture,this.compositeMaterial.uniforms.blurTexture5.value=this.renderTargetsVertical[4].texture,this.compositeMaterial.uniforms.bloomStrength.value=t,this.compositeMaterial.uniforms.bloomRadius.value=.1;const c=[1,.8,.6,.4,.2];this.compositeMaterial.uniforms.bloomFactors.value=c,this.bloomTintColors=[new U(1,1,1),new U(1,1,1),new U(1,1,1),new U(1,1,1),new U(1,1,1)],this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors,this.copyUniforms=Ya.clone(Ga.uniforms),this.blendMaterial=new Rt({uniforms:this.copyUniforms,vertexShader:Ga.vertexShader,fragmentShader:Ga.fragmentShader,blending:tn,depthTest:!1,depthWrite:!1,transparent:!0}),this._oldClearColor=new Ie,this._oldClearAlpha=1,this._basic=new Ut,this._fsQuad=new Af(null)}dispose(){for(let e=0;e<this.renderTargetsHorizontal.length;e++)this.renderTargetsHorizontal[e].dispose();for(let e=0;e<this.renderTargetsVertical.length;e++)this.renderTargetsVertical[e].dispose();this.renderTargetBright.dispose();for(let e=0;e<this.separableBlurMaterials.length;e++)this.separableBlurMaterials[e].dispose();this.compositeMaterial.dispose(),this.blendMaterial.dispose(),this._basic.dispose(),this._fsQuad.dispose()}setSize(e,t){let n=Math.round(e/2),r=Math.round(t/2);this.renderTargetBright.setSize(n,r);for(let s=0;s<this.nMips;s++)this.renderTargetsHorizontal[s].setSize(n,r),this.renderTargetsVertical[s].setSize(n,r),this.separableBlurMaterials[s].uniforms.invSize.value=new Ce(1/n,1/r),n=Math.round(n/2),r=Math.round(r/2)}render(e,t,n,r,s){e.getClearColor(this._oldClearColor),this._oldClearAlpha=e.getClearAlpha();const a=e.autoClear;e.autoClear=!1,e.setClearColor(this.clearColor,0),s&&e.state.buffers.stencil.setTest(!1),this.renderToScreen&&(this._fsQuad.material=this._basic,this._basic.map=n.texture,e.setRenderTarget(null),e.clear(),this._fsQuad.render(e)),this.highPassUniforms.tDiffuse.value=n.texture,this.highPassUniforms.luminosityThreshold.value=this.threshold,this._fsQuad.material=this.materialHighPassFilter,e.setRenderTarget(this.renderTargetBright),e.clear(),this._fsQuad.render(e);let o=this.renderTargetBright;for(let l=0;l<this.nMips;l++)this._fsQuad.material=this.separableBlurMaterials[l],this.separableBlurMaterials[l].uniforms.colorTexture.value=o.texture,this.separableBlurMaterials[l].uniforms.direction.value=$r.BlurDirectionX,e.setRenderTarget(this.renderTargetsHorizontal[l]),e.clear(),this._fsQuad.render(e),this.separableBlurMaterials[l].uniforms.colorTexture.value=this.renderTargetsHorizontal[l].texture,this.separableBlurMaterials[l].uniforms.direction.value=$r.BlurDirectionY,e.setRenderTarget(this.renderTargetsVertical[l]),e.clear(),this._fsQuad.render(e),o=this.renderTargetsVertical[l];this._fsQuad.material=this.compositeMaterial,this.compositeMaterial.uniforms.bloomStrength.value=this.strength,this.compositeMaterial.uniforms.bloomRadius.value=this.radius,this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors,e.setRenderTarget(this.renderTargetsHorizontal[0]),e.clear(),this._fsQuad.render(e),this._fsQuad.material=this.blendMaterial,this.copyUniforms.tDiffuse.value=this.renderTargetsHorizontal[0].texture,s&&e.state.buffers.stencil.setTest(!0),this.renderToScreen?(e.setRenderTarget(null),this._fsQuad.render(e)):(e.setRenderTarget(n),this._fsQuad.render(e)),e.setClearColor(this._oldClearColor,this._oldClearAlpha),e.autoClear=a}_getSeparableBlurMaterial(e){const t=[];for(let n=0;n<e;n++)t.push(.39894*Math.exp(-.5*n*n/(e*e))/e);return new Rt({defines:{KERNEL_RADIUS:e},uniforms:{colorTexture:{value:null},invSize:{value:new Ce(.5,.5)},direction:{value:new Ce(.5,.5)},gaussianCoefficients:{value:t}},vertexShader:`varying vec2 vUv;
				void main() {
					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
				}`,fragmentShader:`#include <common>
				varying vec2 vUv;
				uniform sampler2D colorTexture;
				uniform vec2 invSize;
				uniform vec2 direction;
				uniform float gaussianCoefficients[KERNEL_RADIUS];

				void main() {
					float weightSum = gaussianCoefficients[0];
					vec3 diffuseSum = texture2D( colorTexture, vUv ).rgb * weightSum;
					for( int i = 1; i < KERNEL_RADIUS; i ++ ) {
						float x = float(i);
						float w = gaussianCoefficients[i];
						vec2 uvOffset = direction * invSize * x;
						vec3 sample1 = texture2D( colorTexture, vUv + uvOffset ).rgb;
						vec3 sample2 = texture2D( colorTexture, vUv - uvOffset ).rgb;
						diffuseSum += (sample1 + sample2) * w;
						weightSum += 2.0 * w;
					}
					gl_FragColor = vec4(diffuseSum/weightSum, 1.0);
				}`})}_getCompositeMaterial(e){return new Rt({defines:{NUM_MIPS:e},uniforms:{blurTexture1:{value:null},blurTexture2:{value:null},blurTexture3:{value:null},blurTexture4:{value:null},blurTexture5:{value:null},bloomStrength:{value:1},bloomFactors:{value:null},bloomTintColors:{value:null},bloomRadius:{value:0}},vertexShader:`varying vec2 vUv;
				void main() {
					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
				}`,fragmentShader:`varying vec2 vUv;
				uniform sampler2D blurTexture1;
				uniform sampler2D blurTexture2;
				uniform sampler2D blurTexture3;
				uniform sampler2D blurTexture4;
				uniform sampler2D blurTexture5;
				uniform float bloomStrength;
				uniform float bloomRadius;
				uniform float bloomFactors[NUM_MIPS];
				uniform vec3 bloomTintColors[NUM_MIPS];

				float lerpBloomFactor(const in float factor) {
					float mirrorFactor = 1.2 - factor;
					return mix(factor, mirrorFactor, bloomRadius);
				}

				void main() {
					gl_FragColor = bloomStrength * ( lerpBloomFactor(bloomFactors[0]) * vec4(bloomTintColors[0], 1.0) * texture2D(blurTexture1, vUv) +
						lerpBloomFactor(bloomFactors[1]) * vec4(bloomTintColors[1], 1.0) * texture2D(blurTexture2, vUv) +
						lerpBloomFactor(bloomFactors[2]) * vec4(bloomTintColors[2], 1.0) * texture2D(blurTexture3, vUv) +
						lerpBloomFactor(bloomFactors[3]) * vec4(bloomTintColors[3], 1.0) * texture2D(blurTexture4, vUv) +
						lerpBloomFactor(bloomFactors[4]) * vec4(bloomTintColors[4], 1.0) * texture2D(blurTexture5, vUv) );
				}`})}}$r.BlurDirectionX=new Ce(1,0);$r.BlurDirectionY=new Ce(0,1);function Dy(i,e,t,{initial:n=.48,reducedMotion:r=!1}={}){const s={intensity:r?.23:n},a=new Iy(i);a.renderToScreen=!1,a.setPixelRatio(1);const o=new $r(new Ce(512,288),.72,.3,.72);a.addPass(new Py(e,t)),a.addPass(o);const l=new cf,c=new qs(-1,1,1,-1,0,1),d=new Rt({depthTest:!1,depthWrite:!1,transparent:!0,blending:tn,toneMapped:!1,uniforms:{uTexture:{value:null},uOpacity:{value:s.intensity}},vertexShader:"varying vec2 vUv;void main(){vUv=uv;gl_Position=vec4(position.xy,0.0,1.0);}",fragmentShader:`uniform sampler2D uTexture; uniform float uOpacity;varying vec2 vUv;
      void main(){vec3 c=texture2D(uTexture,vUv).rgb;gl_FragColor=vec4(c*uOpacity,1.0);}`});l.add(new ht(new yn(2,2),d));function u(g,v,m=.34){const f=_e.clamp(m,.2,.5);a.setSize(Math.max(64,Math.floor(g*f)),Math.max(64,Math.floor(v*f)))}function h(g=!0,v=!0){if(!v){t.layers.set(0),i.setRenderTarget(null),i.render(e,t);return}g&&(t.layers.set(1),a.render(),t.layers.set(0),d.uniforms.uTexture.value=a.readBuffer.texture),i.setRenderTarget(null),i.render(e,t);const m=i.autoClear;i.autoClear=!1,i.render(l,c),i.autoClear=m}function p(g){s.intensity=_e.clamp(g,0,1.5),d.uniforms.uOpacity.value=s.intensity}return{state:s,render:h,resize:u,setIntensity:p}}const Ny=1.32;function Oy(i,e){const t={uSkyActive:{value:0},uSkyBasis:{value:new $e},uSkyEye:{value:new Ce},uSkyCenter:{value:new Ce},uSkySize:{value:new Ce},uSkyDistance:{value:1},uSkyTanHalf:{value:1},uSkyAspect:{value:e.aspect},uSkyPan:{value:new Ce},uSkyZoom:{value:1}},n={active:!1,projection:"angular-sky",panX:0,panY:0,approach:0,zoom:1,newTextures:0,newSurfaces:0},r=new dt,s=new dt,a=new dt,o=new U,l=new U,c=new U,d=new U,u=new qe,h=new xn(0,0,0,"YXZ");i.material.onBeforeCompile=v=>{Object.assign(v.uniforms,t),v.vertexShader=v.vertexShader.replace("#include <common>",`#include <common>
      varying vec2 vSkyScreen;`).replace("#include <project_vertex>",`#include <project_vertex>
      vSkyScreen=gl_Position.xy/gl_Position.w;`),v.fragmentShader=v.fragmentShader.replace("#include <common>",`#include <common>
      varying vec2 vSkyScreen;
      uniform float uSkyActive,uSkyDistance,uSkyTanHalf,uSkyAspect,uSkyZoom;
      uniform mat3 uSkyBasis;
      uniform vec2 uSkyEye,uSkyCenter,uSkySize,uSkyPan;`).replace("#include <map_fragment>",`
      if(uSkyActive>.5){
        // A projeção de partida fica fixa. O giro acrescenta o mesmo
        // deslocamento angular a todos os pixels, sem cisalhar a fotografia.
        // Zoom uniforme no espaço da tela, centrado na direção de chegada.
        // A mesma escala nos dois eixos conserva o formato durante o giro.
        vec2 screen=vSkyScreen/uSkyZoom;
        vec3 ray=uSkyBasis*vec3(screen.x*uSkyTanHalf*uSkyAspect,screen.y*uSkyTanHalf,-1.);
        vec2 uv=(uSkyEye+ray.xy*uSkyDistance/max(.00001,-ray.z)-uSkyCenter)/uSkySize+.5+uSkyPan;
        vec4 sky=texture2D(map,clamp(uv,vec2(0.),vec2(1.)));
        // Fora da região fotografada há céu escuro, sem repetir/esticar bordas.
        vec2 edge=smoothstep(vec2(0.),vec2(.035),uv)*(1.-smoothstep(vec2(.965),vec2(1.),uv));
        sky.rgb=mix(vec3(.0006,.0004,.0012),sky.rgb,edge.x*edge.y);
        diffuseColor*=sky;
      }else{
        #include <map_fragment>
      }`)},i.material.customProgramCacheKey=()=>"orion-angular-sky-v2",i.material.needsUpdate=!0;function p(){return n.active?!1:(e.updateWorldMatrix(!0,!1),i.updateWorldMatrix(!0,!1),e.getWorldPosition(o),e.getWorldQuaternion(r),s.copy(r).invert(),i.getWorldPosition(l),i.getWorldScale(c),t.uSkyBasis.value.setFromMatrix4(u.makeRotationFromQuaternion(r)),t.uSkyEye.value.set(o.x,o.y),t.uSkyCenter.value.set(l.x,l.y),t.uSkySize.value.set(c.x,c.y),t.uSkyDistance.value=o.z-l.z,t.uSkyTanHalf.value=Math.tan(_e.degToRad(e.fov/2)),e.add(i),i.quaternion.identity(),t.uSkyActive.value=1,n.active=!0,g(0),!0)}function g(v=n.approach){if(!n.active)return;n.approach=_e.clamp(Number.isFinite(v)?v:0,0,1),n.zoom=1+(Ny-1)*n.approach,t.uSkyZoom.value=n.zoom,e.getWorldQuaternion(a),a.premultiply(s),h.setFromQuaternion(a,"YXZ"),d.set(-h.y,h.x,0).applyQuaternion(r);const m=t.uSkyDistance.value;t.uSkyPan.value.set(d.x*m/c.x,d.y*m/c.y),n.panX=t.uSkyPan.value.x,n.panY=t.uSkyPan.value.y,t.uSkyAspect.value=e.aspect;const f=Math.max(e.near*2,Math.min(100,e.far*.5)),y=2*f*Math.tan(_e.degToRad(e.fov/2));i.position.set(0,0,-f),i.scale.set(y*e.aspect*1.0001,y*1.0001,1),i.quaternion.identity()}return{begin:p,update:g,state:n,uniforms:t,photo:i}}const Pr=i=>Math.min(1,Math.max(0,i)),xs=(i,e,t)=>{const n=Pr((i-e)/(t-e));return n*n*n*(n*(n*6-15)+10)},Uy=2550,ys=(i,e,t)=>{const n=Pr((i-e)/(t-e));return n*n*(3-2*n)};function Fy({scene:i,camera:e,star:t,glows:n,layers:r,gasLayers:s,selectiveBloom:a,flash:o,reducedMotion:l,onArrive:c,sky:d=null}){const u=[{object:n.halo,scale:156,opacity:.22},{object:n.soft,scale:118,opacity:.3},{object:n.main,scale:66,opacity:.8},{object:n.core,scale:18,opacity:1}];let h=52,p=t.position.z;const g=new U(t.position.x,t.position.y,p+53),v=l?850:Uy,m=l?80:700,f=l?0:160,y=l?.7:.77,_=new U,x=new dt,R=new dt,M=new qe,w=new U(0,1,0),A=a.state.intensity;let S=!1,b=!1,T=0,D=0,k=1;const z=s.map(me=>[me,me.material.uniforms.uStrength.value,1]),H=r.filter(me=>me.material?.opacity!==void 0).map(me=>[me,me.material.opacity,1]),L=[...new Set([...s,...r.filter(me=>me!==d?.photo&&me.material?.opacity!==void 0)])].map(me=>({layer:me,quaternion:new dt})),N=new U,B=new U,V=me=>B.copy(me.position).sub(e.position).dot(N),Y=me=>ys(V(me),6,55),ee=l?0:540,$=new Float32Array(ee*6),re=new Float32Array(ee*6),te=[],F=[new Ie("#c8d5ff"),new Ie("#9f8dd8"),new Ie("#fce1b4")];for(let me=0;me<ee;me++){const P=Math.random()*Math.PI*2,Le=6+Math.sqrt(Math.random())*100,Te=Math.cos(P)*Le,ge=Math.sin(P)*Le*.65,ae=-14-Math.random()*200,ze=3+Math.random()*18,oe=.65+Math.random()*.8;te.push({x:Te,y:ge,z:ae,len:ze,speed:oe});const Se=F[me%F.length],Ye=me*6;for(let De=0;De<2;De++)re[Ye+De*3]=Se.r,re[Ye+De*3+1]=Se.g,re[Ye+De*3+2]=Se.b}const O=new Lt;O.setAttribute("position",new ct($,3).setUsage(ef)),O.setAttribute("color",new ct(re,3));const G=new Xc({vertexColors:!0,transparent:!0,opacity:0,depthTest:!1,depthWrite:!1,blending:tn}),ne=new ff(O,G);ne.frustumCulled=!1,ne.renderOrder=18,ne.visible=!1,e.add(ne);function xe(me,P){if(S||b)return!1;t=me,n=P,p=t.position.z,g.set(t.position.x,t.position.y,p+53);for(const[Le,Te]of["halo","soft","main","core"].entries())u[Le].object=n[Te];return!0}function fe(me=performance.now()){if(S||b)return!1;e.updateWorldMatrix(!0,!1),i.attach(e),e.updateWorldMatrix(!0,!1),_.copy(e.position),x.copy(e.quaternion),h=e.fov,d?.begin(),k=1,N.set(0,0,-1).applyQuaternion(e.quaternion);for(const P of L)P.quaternion.copy(P.layer.quaternion);for(const P of z)P[1]=P[0].material.uniforms.uStrength.value,P[2]=Y(P[0]);for(const P of H)P[1]=P[0].material.opacity,P[2]=Y(P[0]);g.copy(_).lerp(t.position,(_.z-(p+53))/(_.z-p));for(const P of u)P.startScale=P.object.scale.x,P.startOpacity=P.object.material.opacity;return M.lookAt(_,t.position,w),R.setFromRotationMatrix(M),T=me,S=!0,D=0,ne.visible=!l,!0}function we(me,P){if(!S)return 0;const Le=me-T,Te=Pr(Le/v);D=Te;const ge=Pr((Le-m)/(v-m));k=l?0:1-xs(Le,0,f);const ae=xs(ge,0,1),ze=_e.lerp(_.x,g.x,ae),oe=_e.lerp(_.y,g.y,ae);e.position.set(ze,oe,_e.lerp(_.z,g.z,ae)),e.quaternion.slerpQuaternions(x,R,xs(Le,f,m));const Se=xs(Le,0,m);e.fov=_e.lerp(h,52,Se)+(l?0:4*Math.sin(Math.PI*ge)**2),e.updateProjectionMatrix(),d?.update(l?0:ae),N.set(0,0,-1).applyQuaternion(e.quaternion);const Ye=l?1:1+1.4*xs(ge,0,.35);for(const{layer:K,quaternion:ye}of L)K.quaternion.slerpQuaternions(ye,e.quaternion,Se);for(const[K,ye,le]of z)K.material.uniforms.uStrength.value=ye*Ye*Pr(Y(K)/Math.max(1e-6,le));for(const[K,ye,le]of H)K===d?.photo||K.position.z<p-25||(K.material.opacity=Math.min(1,ye*Ye*Pr(Y(K)/Math.max(1e-6,le))));const De=ys(Te,y,.995),I=Math.max(35,e.position.distanceTo(t.position)),E=Math.max(1,_.distanceTo(t.position)),j=I/E,Q=1+De*De*22;for(const K of u)K.object.scale.setScalar(_e.lerp(K.startScale,K.scale*j*Q,Se));for(const[K,ye]of[.2+.47*De,.3+.47*De,.85+.22*De,1].entries())u[K].object.material.opacity=_e.lerp(u[K].startOpacity,ye,Se);a.setIntensity(Math.min(1.5,A+.75*De));const ie=140+1700*Math.pow(ge,1.7);for(let K=0;K<te.length;K++){const ye=te[K];ye.z+=P*ie*ye.speed,ye.z>2&&(ye.z=-220-Math.random()*45);const le=K*6;$[le]=ye.x,$[le+1]=ye.y,$[le+2]=ye.z,$[le+3]=ye.x,$[le+4]=ye.y,$[le+5]=ye.z-Math.min(28,ye.len*(1+2.2*ge))}return O.attributes.position.needsUpdate=!0,G.opacity=l?0:ys(ge,0,.18)*(.04+.5*ys(ge,0,.55))*(1-De*.88),o.style.opacity=String(De),o.style.setProperty("--veil-opacity",String(ys(Te,.9,1))),Te>=1&&!b&&(b=!0,S=!1,c()),Te}return{begin:fe,update:we,setDestination:xe,get active(){return S},get progress(){return D},get companionOpacity(){return k},get streakCount(){return ee},get passedLayers(){return s.filter(me=>e.position.z<me.position.z).length}}}const Kr=i=>Math.max(0,Math.min(1,i)),Ot=(i,e,t)=>{const n=Kr((i-e)/(t-e));return Kr(n*n*n*(n*(n*6-15)+10))},By=1.12,ky=.16,zy=.78;function wf(i,e=!1){const t=Kr(i/(e?ky:By));if(e)return{progress:t,reach:0,press:0,anticipation:0,followThrough:0,lift:0,charge:0,burst:0,light:t<1?.3:0};const n=Ot(t,0,.07)*(1-Ot(t,.1,.24)),r=Ot(t,.08,.4)*(1-Ot(t,.68,1)),s=Ot(t,.05,.28)*(1-Ot(t,.57,.94)),a=Ot(t,.32,.49)*(1-Ot(t,.6,.88)),o=Ot(t,.6,.78)*(1-Ot(t,.86,1)),l=Ot(t,0,.34)*(1-Ot(t,.44,.64)),c=Ot(t,.32,.49)*(1-Ot(t,.6,.98)),d=1-(1-.65*l)*(1-.95*c);return{progress:t,reach:r,press:a,anticipation:n,followThrough:o,lift:s,charge:l,burst:c,light:d}}function zd(i,e,t=Math.PI*2){const n=new po(i,1,e,4,0,t),r=n.attributes.position,s=new Float32Array(r.count*4);for(let a=0;a<r.count;a++){const o=r.getX(a),l=r.getY(a),c=Math.hypot(o,l),d=Math.sin(Math.PI*Kr((c-i)/(1-i)))**2;let u=Math.atan2(l,o);u<0&&(u+=Math.PI*2);const h=t<Math.PI*2?Math.sin(Math.PI*Kr(u/t))**2:1;s.set([1,1,1,d*h],a*4)}return n.setAttribute("color",new nt(s,4)),n}function Vy(i,{camera:e,hands:t,reducedMotion:n=!1,onConfirm:r,onDepart:s}){const a={active:!1,completed:!1,departed:!1,elapsed:0,progress:0,reach:0,press:0,anticipation:0,followThrough:0,lift:0,charge:0,burst:0,light:0,activations:0,surfaces:0,triangles:0},o=new Ct;o.name="NoxSelectionLight",o.visible=!1,i.add(o);const l=[],c=[],d=[],u=new Set,h=new dt,p=new dt,g=new Ie(16113064),v=new Ie(12166639);let m=null,f=null,y=!1,_=!1;function x(S,b,T){u.add(S);const D=new Ut({color:b,vertexColors:!0,transparent:!0,opacity:0,side:Et,depthTest:!1,depthWrite:!1,blending:tn,toneMapped:!1,forceSinglePass:!0}),k=new ht(S,D);return k.renderOrder=15,k.frustumCulled=!1,k.userData.selectionType=T,o.add(k),c.push(k),k}function R(){if(c.length)return;const S=zd(.86,96);for(const b of[g,v])l.push(x(S,b,"wave"));if(!n){const b=zd(.91,80,Math.PI*1.65);for(const N of[v,g])d.push(x(b,N,"ribbon"));const T=[],D=[];for(let N=0;N<12;N++){const B=N*Math.PI/6+.12,V=N%3===0?78:N%2===0?54:35,Y=N%3===0?1.9:1.1,ee=N%2?v:g;for(const[$,re,te]of[[8,0,0],[18,-Y,0],[18,0,.85],[18,-Y,0],[V,0,0],[18,0,.85],[8,0,0],[18,0,.85],[18,Y,0],[18,Y,0],[18,0,.85],[V,0,0]])T.push(Math.cos(B)*$-Math.sin(B)*re,Math.sin(B)*$+Math.cos(B)*re,0),D.push(ee.r,ee.g,ee.b,te)}const k=new Lt;k.setAttribute("position",new nt(T,3)),k.setAttribute("color",new nt(D,4)),m=x(k,16777215,"corona");const z=new Lt,H=new Float32Array(648),L=new Float32Array(864);for(let N=0;N<18;N++)for(let B=0;B<12;B++){const V=N%2?v:g,Y=B%3===1?.9:0;L.set([V.r,V.g,V.b,Y],(N*12+B)*4)}z.setAttribute("position",new ct(H,3).setUsage(ef)),z.setAttribute("color",new nt(L,4)),f=x(z,16777215,"motes")}a.surfaces=c.length,a.triangles=[...c].reduce((b,T)=>b+(T.geometry.index?.count??T.geometry.attributes.position.count)/3,0)}function M(){return y||a.active||a.completed?!1:(R(),a.active=!0,a.activations++,o.visible=!0,t.setStarSelection?.({reach:0,press:0}),w(0),_=n,!0)}function w(S){if(!(!a.active||y)){_&&(_=!1,S=0),a.elapsed+=Math.max(0,n?S:Math.min(S,.1)),Object.assign(a,wf(a.elapsed,n)),t.setStarSelection?.(a),i.getWorldQuaternion(h),e.getWorldQuaternion(p),o.quaternion.copy(h.invert().multiply(p));for(let b=0;b<l.length;b++){const T=b*.28,D=Kr((a.progress-T)/(1-T));l[b].scale.setScalar(n?20:10+(b===0?68:80)*(1-(1-D)**2)),l[b].material.opacity=n?b===0?a.light:0:(b===0?.58:.4)*Ot(D,0,.14)*(1-Ot(D,.42,1))}if(!n){const b=a.progress,T=Ot(b,.46,1);for(let L=0;L<d.length;L++){const N=d[L],B=_e.lerp(38,23,a.charge)+26*T;N.scale.setScalar(B),N.rotation.set(L===0?.85:-.95,L===0?.3:-.35,(L===0?1:-1)*(.35+b*1.8)),N.material.opacity=(L===0?.52:.42)*a.light}m.rotation.z=-.08+b*.18,m.scale.setScalar(.65+.55*T),m.material.opacity=.62*a.burst;const D=f.geometry.attributes.position,k=_e.lerp(64,14,Ot(b,0,.44)),z=14+98*(1-(1-T)**2),H=_e.lerp(k,z,Ot(b,.44,.54));for(let L=0;L<18;L++){const N=L*Math.PI*2/18+.17+b*.85,B=.82+L%5*.09,V=H*B,Y=.65+L%3*.17,ee=2.2+5*T,$=Math.cos(N)*V,re=Math.sin(N)*V;for(const[te,[F,O]]of[[-ee,0],[0,0],[0,-Y],[0,-Y],[0,0],[ee,0],[ee,0],[0,0],[0,Y],[0,Y],[0,0],[-ee,0]].entries())D.setXYZ(L*12+te,$+Math.cos(N)*F-Math.sin(N)*O,re+Math.sin(N)*F+Math.cos(N)*O,0)}D.needsUpdate=!0,f.material.opacity=.72*(1-(1-.75*a.charge)*(1-a.burst))}!n&&s&&!a.departed&&a.progress>=zy&&(a.departed=!0,s()),a.progress>=1&&(a.active=!1,a.completed=!0,o.visible=!1,t.setStarSelection?.(null),r?.())}}function A(){if(!y){y=!0,a.active=!1,o.visible=!1,t.setStarSelection?.(null);for(const S of u)S.dispose();for(const S of c)S.material.dispose();i.remove(o)}}return{state:a,root:o,rings:l,effects:c,begin:M,update:w,dispose:A}}function Hy(){const i=document.createElement("canvas");i.width=i.height=512;const e=i.getContext("2d");if(!e)throw Error("Canvas 2D indisponível para o flare da estrela");const t=256;e.translate(t,t),e.globalCompositeOperation="lighter";const n=e.createRadialGradient(0,0,2,0,0,90);n.addColorStop(0,"rgba(255,249,226,.30)"),n.addColorStop(.11,"rgba(247,223,185,.18)"),n.addColorStop(.36,"rgba(199,179,223,.043)"),n.addColorStop(1,"rgba(199,179,223,0)"),e.fillStyle=n,e.fillRect(-96,-96,192,192);function r(a,o,l,c){e.save(),e.rotate(a);for(const[d,u]of[[c*3.4,.1],[c,.48],[.55,1]]){const h=e.createLinearGradient(0,0,o,0),p=l*u;h.addColorStop(0,`rgba(255,252,239,${Math.min(1,p)})`),h.addColorStop(.08,`rgba(255,242,211,${p*.75})`),h.addColorStop(.34,`rgba(228,217,246,${p*.32})`),h.addColorStop(.7,`rgba(205,202,255,${p*.12})`),h.addColorStop(1,"rgba(205,202,255,0)"),e.fillStyle=h,e.beginPath(),e.moveTo(0,-d),e.lineTo(o,0),e.lineTo(0,d),e.closePath(),e.fill()}e.restore()}for(let a=0;a<4;a++)r(a*Math.PI/2,231,.48,1.6);for(let a=0;a<4;a++)r(Math.PI/4+a*Math.PI/2,119,.15,.72);const s=new fo(i);return s.colorSpace=_t,s.minFilter=Gt,s.magFilter=Dt,s.generateMipmaps=!0,s}function Rf(i,{reducedMotion:e=!1,sharedTexture:t=null}={}){const n=t??Hy();function r(h,p,g){const v=new Gs({map:n,transparent:!0,opacity:p,depthTest:!1,depthWrite:!1,blending:tn,toneMapped:!1}),m=new uo(v);return m.scale.setScalar(h),m.renderOrder=g,i.add(m),m}const s=r(174,.31,11),a=r(123,.085,11);let o=0,l=0,c=null;function d(h,p,g){const v=c===null?0:Math.max(0,Math.min(.1,h-c));c=h;const m=e?1:1-Math.exp(-v*12);o+=((p?1:0)-o)*m,l+=((g?1:0)-l)*m;const f=e?0:Math.sin(h*.79+.9),y=e?0:Math.sin(h*2.11+.7)*.55+Math.sin(h*3.16+2.3)*.45;s.material.rotation=e?.11:.11+h*.019,a.material.rotation=e?-.3:-.3-h*.012,s.material.opacity=.28-.16*l+.04*f+.032*y+.09*o,a.material.opacity=.075-.03*l+.012*f+.035*o,s.scale.setScalar(174*(1+.018*f+.045*o)),a.scale.setScalar(123*(1+.025*y))}function u(){s.material.dispose(),a.material.dispose(),t||n.dispose()}return{primary:s,secondary:a,update:d,dispose:u}}const Gy=Object.freeze([{id:"01",name:"Massa distante",u:.19,v:.51,w:.23,h:.27,z:-425,opacity:.18,rate:.27,phase:.6,drift:1.5,parallaxX:2.2,parallaxY:.8},{id:"02",name:"Nuvem central",u:.41,v:.52,w:.25,h:.32,z:-342,opacity:.23,rate:.22,phase:1.9,drift:2.1,parallaxX:5.2,parallaxY:2.1},{id:"03",name:"Filamento lateral",u:.61,v:.53,w:.23,h:.3,z:-252,opacity:.19,rate:.3,phase:3,drift:2.9,parallaxX:9,parallaxY:3.1},{id:"04",name:"Véu avançado",u:.8,v:.53,w:.22,h:.26,z:-185,opacity:.14,rate:.36,phase:4.2,drift:3.6,parallaxX:16.5,parallaxY:6.2},{id:"05",name:"Bruma intermediária esquerda",u:.28,v:.43,w:.18,h:.24,z:-130,opacity:.1,rate:.25,phase:5.4,drift:1.2,parallaxX:12,parallaxY:4},{id:"06",name:"Filamento próximo direito",u:.66,v:.61,w:.2,h:.27,z:-42,opacity:.055,rate:.32,phase:6.7,drift:.65,parallaxX:8,parallaxY:3}]);function Wy(i,e,{reducedMotion:t=!1,parallaxEnabled:n=!0,foregroundEnabled:r=!0}={}){const s=new rs,a=Gy.map((g,v)=>{const m=new Ut({transparent:!0,opacity:g.opacity,depthTest:!1,depthWrite:!1,side:Et,forceSinglePass:!0,blending:Pi,toneMapped:!1}),f=new ht(new yn(1,1),m);return f.position.z=g.z,f.renderOrder=2.11+v*.08,f.visible=!1,f.userData.layerName="Foto ESO em volume · "+g.name,f.userData.volumeFragment=!0,f.userData.spec=g,f.userData.loaded=!1,f.userData.parallaxOffsetX=0,f.userData.parallaxOffsetY=0,f.userData.baseScaleX=1,f.userData.baseScaleY=1,i.add(f),f}),o={active:0,loaded:0,parallaxEnabled:n&&!t,parallaxStrength:1,foregroundEnabled:r};function l(g){const v=Number(g);Number.isFinite(v)&&(o.parallaxStrength=_e.clamp(v,.45,1.6))}function c(g){if(g.userData.loaded)return;g.userData.loaded=!0;const v=g.userData.spec.id,m=s.load("/assets/depth/eso-gas-"+v+".webp",void 0,void 0,f=>{console.warn("[Nebulosa em volume] falha ao carregar recorte",v,f),g.visible=!1});m.colorSpace=_t,m.anisotropy=1,m.minFilter=Gt,m.magFilter=Dt,g.material.map=m,g.material.needsUpdate=!0,o.loaded++}function d(g){const v=g==="eco-plus"?o.foregroundEnabled?[1,2,3,4,5]:[1,3]:["lite","eco"].includes(g)?[1,3]:g==="high"?[0,1,2,3,4,5]:[0,1,2,4,5];a.forEach((m,f)=>{const y=g==="eco-plus"&&o.foregroundEnabled&&f===2,_=m.userData.spec;m.position.z=y?-75:_.z,m.userData.opacityFactor=y?.38:1,m.material.opacity=_.opacity*m.userData.opacityFactor,m.renderOrder=2.11+(425+m.position.z)*8e-4,m.visible=v.includes(f),m.visible&&c(m)}),o.active=v.length}function u(){const g=26-e.position.z;for(const v of a){const m=v.userData.spec,f=(26-v.position.z)/g;v.userData.baseX=e.position.x+(m.u-.5)*e.scale.x*f,v.userData.baseY=e.position.y+(.5-m.v)*e.scale.y*f,v.position.x=v.userData.baseX,v.position.y=v.userData.baseY,v.userData.baseScaleX=e.scale.x*m.w*f*1.008,v.userData.baseScaleY=e.scale.y*m.h*f*1.008,v.scale.set(v.userData.baseScaleX,v.userData.baseScaleY,1)}}function h(g,v=0,m=0,f=1/60){const y=o.parallaxEnabled,_=y?1-Math.exp(-Math.max(0,Math.min(.1,f))*14):1,x=y?_e.clamp(v,-1,1):0,R=y?_e.clamp(m,-1,1):0;for(const M of a){if(!M.visible)continue;const w=M.userData.spec,A=t?0:Math.sin(g*w.rate+w.phase),S=t?0:Math.sin(g*w.rate*.55+w.phase*1.43),b=M.userData;b.parallaxOffsetX+=(-x*w.parallaxX*o.parallaxStrength-b.parallaxOffsetX)*_,b.parallaxOffsetY+=(-R*w.parallaxY*o.parallaxStrength-b.parallaxOffsetY)*_,M.position.x=b.baseX+S*w.drift+b.parallaxOffsetX,M.position.y=b.baseY+A*w.drift*.32+b.parallaxOffsetY;const T=t?0:.003*Math.sin(g*w.rate*.67+w.phase);M.scale.x=b.baseScaleX*(1+T),M.scale.y=b.baseScaleY*(1+T*.6),M.material.opacity=w.opacity*b.opacityFactor*(1+A*.085)}}function p(){for(const g of a)g.material.map?.dispose(),g.material.dispose(),g.geometry.dispose(),i.remove(g)}return{layers:a,state:o,resize:u,update:h,applyQuality:d,dispose:p,setParallaxStrength:l}}const tu="orion-observatorio-hands-ab-v1";function Xy(i){return JSON.stringify({quality:i.quality,effects:i.effects,bloomRest:i.bloomRest,viewport:i.viewport,dpr:i.dpr,canvasPixels:i.canvasPixels,gasLayers:i.gasLayers,volumeLayers:i.volumeLayers,foregroundNear:i.foregroundNear,depthMotion:i.depthMotion,parallaxStrength:i.parallaxStrength})}function Vd(i,e){if(!i||!e)return{ok:!1,reason:"Faltam medições dos dois modos."};if(i.mode!=="off"||e.mode!=="fps")return{ok:!1,reason:"Modos A/B inválidos."};if(i.signature!==e.signature)return{ok:!1,reason:"Configurações ou resolução diferentes. Limpe as medições e repita no mesmo tamanho de janela."};for(const t of[i.fps,i.p95Ms,e.fps,e.p95Ms])if(!Number.isFinite(t))return{ok:!1,reason:"Medições incompletas."};return{ok:!0,fpsDifference:e.fps-i.fps,p95Difference:+(e.p95Ms-i.p95Ms).toFixed(1),drawCallsDifference:(e.drawCalls??0)-(i.drawCalls??0),texturesDifference:(e.textures??0)-(i.textures??0)}}function pl(){try{const i=JSON.parse(sessionStorage.getItem(tu)||"{}");return i&&typeof i=="object"?i:{}}catch{return{}}}function qy(i){try{return sessionStorage.setItem(tu,JSON.stringify(i)),!0}catch{return!1}}function Yy(i,e){const t=document.createElement("section");t.className="perf-ab-inspector",t.setAttribute("aria-label","Benchmark local das mãos FPS");const n=document.createElement("strong");n.textContent="Comparação A/B · mãos FPS";const r=document.createElement("small");r.textContent="Mesmo PC e janela: espere 10 s com a aba visível, registre uma amostra, mude de modo e registre a outra. Repita para confirmar. Não mede VRAM nem FPS efetivamente exibido pela GPU.";const s=document.createElement("output");s.id="orionHandsABResult",s.className="perf-values",s.setAttribute("aria-live","polite");const a=document.createElement("button");a.id="orionHandsABCapture",a.className="perf-copy",a.type="button",a.textContent="Registrar amostra atual";const o=document.createElement("a");o.id="orionHandsABSwitch",o.className="perf-depth-compare";const l=document.createElement("button");l.id="orionHandsABClear",l.className="perf-copy",l.type="button",l.textContent="Limpar comparativo";const c=document.createElement("small");c.id="orionHandsABStatus",c.setAttribute("aria-live","polite");const d=new URLSearchParams(location.search),u=d.get("hands")==="off",h=new URL(location.href);h.searchParams.set("debug","1"),h.searchParams.set("quality","eco-plus"),h.searchParams.set("hands",u?"fps":"off"),h.searchParams.set("fpsStyle","frame"),h.searchParams.delete("fpsTune"),o.href=h.pathname+h.search,o.textContent=u?"Testar com mãos FPS":"Testar sem mãos FPS",t.append(n,r,s,a,o,l,c),i.appendChild(t);function p(){const v=pl(),m=v.off,f=v.fps;if(!m&&!f)return"Comparativo A/B: sem dados registrados.";const y=x=>x?"FPS "+x.fps+" | p95 "+x.p95Ms+" ms | >33 ms "+x.longFrames+"% | draw calls "+x.drawCalls+" | texturas "+x.textures+" | amostras "+x.samples+" | viewport "+x.viewport:"pendente",_=Vd(m,f);return["Observatório · mãos FPS · comparação local A/B","Sem mãos: "+y(m),"David Fischer (natural): "+y(f),_.ok?"Diferença com mãos menos sem mãos: FPS "+(_.fpsDifference>=0?"+":"")+_.fpsDifference+" | p95 "+(_.p95Difference>=0?"+":"")+_.p95Difference+" ms | draw calls "+(_.drawCallsDifference>=0?"+":"")+_.drawCallsDifference+" | texturas "+(_.texturesDifference>=0?"+":"")+_.texturesDifference:"Comparação pendente: "+_.reason,"Amostras do loop da página, não benchmark de GPU. Repetir pares A/B na mesma janela."].join(`
`)}function g(){const v=pl(),m=Vd(v.off,v.fps);m.ok?s.textContent="FPS: sem mãos "+v.off.fps+" → com mãos "+v.fps.fps+" ("+(m.fpsDifference>=0?"+":"")+m.fpsDifference+`)
p95: `+v.off.p95Ms+" → "+v.fps.p95Ms+" ms ("+(m.p95Difference>=0?"+":"")+m.p95Difference+` ms)
Draw calls: `+v.off.drawCalls+" → "+v.fps.drawCalls+" | Texturas: "+v.off.textures+" → "+v.fps.textures:s.textContent="Sem mãos: "+(v.off?"registrado":"pendente")+" · Com mãos FPS: "+(v.fps?"registrado":"pendente")+`
`+(v.off&&v.fps?m.reason:"Aguardando duas amostras comparáveis.")}return a.addEventListener("click",()=>{const v=e(),m=d.get("hands")==="off",f=m?"off":"fps";if(document.hidden){c.textContent="Volte para a aba visível antes de medir.";return}if(v.quality!=="eco-plus"){c.textContent="Selecione Eco+ para comparar com resolução fixa.";return}if(!m&&(v.handsMode!=="fps"||!v.handsVisible||!v.handsReady||v.handsLoadError)){c.textContent="O modelo FPS ainda não está pronto para a medição.";return}if(m&&v.handsVisible){c.textContent="Desligue as mãos antes de medir o modo sem mãos.";return}if(performance.now()<1e4||v.samples<30||!Number.isFinite(v.fps)||!Number.isFinite(v.p95Ms)){c.textContent="Espere pelo menos 10 s de cena carregada e 30 quadros de amostra.";return}const y={mode:f,signature:Xy(v),fps:v.fps,p95Ms:v.p95Ms,longFrames:v.longFrames,drawCalls:v.drawCalls,textures:v.textures,samples:v.samples,viewport:v.viewport,quality:v.quality,recordedAt:new Date().toISOString()},_=pl();if(_[f]=y,!qy(_)){c.textContent="Armazenamento da aba bloqueado. Não foi possível preservar a comparação.";return}c.textContent="Amostra "+(f==="fps"?"com mãos FPS":"sem mãos")+" registrada nesta aba.",g()}),l.addEventListener("click",()=>{try{sessionStorage.removeItem(tu)}catch{}c.textContent="Comparação limpa.",g()}),g(),{report:p}}function jy(i,e){const t=document.createElement("fieldset");t.className="layer-inspector perf-inspector";const n=document.createElement("legend");n.textContent="Diagnóstico de fluidez · prévia";const r=document.createElement("output");r.id="orionPerfReadout",r.className="perf-values",r.setAttribute("aria-label","Indicadores de desempenho locais"),r.textContent="Coletando amostras do seu navegador…";const s=document.createElement("small");s.textContent="FPS medido na aba, não pela GPU. Texturas e draw calls não representam RAM/VRAM. Para memória total: Shift+Esc no Chrome.";const a=document.createElement("button");a.type="button",a.className="perf-copy",a.textContent="Copiar diagnóstico";const o=document.createElement("small");o.className="perf-copy-status",o.setAttribute("aria-live","polite"),t.append(n,r,s,a,o);const l=document.createElement("nav");l.className="perf-comparisons",l.setAttribute("aria-label","Comparação de custos de renderização");const c=[{label:"Lite original · 950k px",quality:"lite",effects:null},{label:"Lite sem gás GLSL",quality:"lite",effects:"no-gas"},{label:"Eco+ · 670k px + bloom",quality:"eco-plus",effects:null},{label:"Eco+ sem bloom",quality:"eco-plus",effects:"no-bloom"},{label:"Eco · 500k px",quality:"eco",effects:null}];for(const V of c){const Y=new URL(window.location.href);Y.searchParams.set("debug","1"),Y.searchParams.set("quality",V.quality),Y.searchParams.delete("depthMotion"),V.effects?Y.searchParams.set("effects",V.effects):Y.searchParams.delete("effects");const ee=document.createElement("a");ee.href=Y.pathname+Y.search,ee.textContent=V.label,V.quality===new URLSearchParams(location.search).get("quality")&&(V.effects||"normal")===(new URLSearchParams(location.search).get("effects")||"normal")&&new URLSearchParams(location.search).get("depthMotion")!=="off"&&ee.setAttribute("aria-current","page"),l.appendChild(ee)}const d=document.createElement("small");d.textContent="Compare após ~10 s em cada modo e repita as medições. Lite sem gás e Eco+ preservam o bloom: a diferença isola principalmente a resolução; Eco+ sem bloom mostra o custo do bloom na mesma resolução.";const u=document.createElement("a"),h=new URL(window.location.href);h.searchParams.set("debug","1"),h.searchParams.set("quality","eco-plus"),h.searchParams.delete("effects"),new URLSearchParams(location.search).get("depthMotion")==="off"?(h.searchParams.delete("depthMotion"),u.textContent="Ativar profundidade orgânica · Eco+"):(h.searchParams.set("depthMotion","off"),u.textContent="Comparar profundidade original · Eco+"),u.href=h.pathname+h.search,u.className="perf-depth-compare";const p=document.createElement("a"),g=new URL(window.location.href);g.searchParams.set("debug","1"),g.searchParams.set("quality","eco-plus"),g.searchParams.delete("effects"),new URLSearchParams(location.search).get("foreground")==="off"?(g.searchParams.delete("foreground"),p.textContent="Ativar véu próximo · Eco+"):(g.searchParams.set("foreground","off"),p.textContent="Comparar sem véu próximo · Eco+"),p.href=g.pathname+g.search,p.className="perf-depth-compare";const m=document.createElement("a"),f=new URL(window.location.href);f.searchParams.set("debug","1"),f.searchParams.set("quality","eco-plus"),new URLSearchParams(location.search).get("hands")==="off"?(f.searchParams.set("hands","fps"),f.searchParams.set("fpsStyle","frame"),f.searchParams.delete("fpsTune"),m.textContent="Ativar mãos FPS David Fischer · Eco+"):(f.searchParams.set("hands","off"),m.textContent="Comparar sem mãos · Eco+"),m.href=f.pathname+f.search,m.className="perf-depth-compare";const _=document.createElement("nav");_.className="perf-comparisons",_.setAttribute("aria-label","Comparar modelos das mãos");const x=new URLSearchParams(location.search).get("hands")||"fps";for(const{mode:V,label:Y}of[{mode:"fps",label:"David Fischer · FPS (CC BY)"},{mode:"vr",label:"Mãos anatômicas VR · MIT"},{mode:"rig",label:"WRAD retrô · 50 ossos"},{mode:"3d",label:"Modelo 3D anterior"},{mode:"2d",label:"Silhueta 2,5D"},{mode:"off",label:"Sem mãos"}]){const ee=new URL(window.location.href);ee.searchParams.set("quality","eco-plus"),ee.searchParams.set("debug","1"),ee.searchParams.set("hands",V);const $=document.createElement("a");$.href=ee.pathname+ee.search,$.textContent=Y,(V===x||V==="fps"&&x==="on")&&$.setAttribute("aria-current","page"),_.appendChild($)}t.append(d,l,u,p,_,m),i.appendChild(t);const R=360,M=4e3,w=new Array(R);let A=0,S=0,b=-1/0,T=null;function D(){S=0,A=0,b=-1/0,T=null,r.textContent="Coletando amostras do seu navegador…"}function k(V,Y){if(!(!Number.isFinite(V)||!Number.isFinite(Y)||Y<=0)){if(Y>1e3){D();return}w[A]={t:V,dt:Y},A=(A+1)%R,S=Math.min(R,S+1)}}function z(V=performance.now()){const Y=[];for(let te=0;te<S;te++){const F=w[(A-S+te+R)%R];V-F.t<=M&&Y.push(F.dt)}Y.sort((te,F)=>te-F);const ee=Y.reduce((te,F)=>te+F,0),$=e(),re=typeof performance.memory?.usedJSHeapSize=="number"?Math.round(performance.memory.usedJSHeapSize/1048576):null;return{fps:ee>0?Math.round(1e3*Y.length/ee):null,p95Ms:Y.length?Math.round(Y[Math.min(Y.length-1,Math.ceil(Y.length*.95)-1)]*10)/10:null,longFrames:Y.length?Math.round(100*Y.filter(te=>te>33.3).length/Y.length):null,samples:Y.length,jsHeapMB:re,...$}}function H(V){return["FPS médio (~4s): "+(V.fps??"—"),"Quadro p95: "+(V.p95Ms??"—")+" ms","Quadros acima de 33 ms: "+(V.longFrames??"—")+"%","Perfil: "+V.quality+" · DPR: "+V.dpr,"Efeitos: "+V.effects+" · bloom em repouso: "+(V.bloomRest?"sim":"não"),"Pixels do canvas: "+V.canvasPixels,"Camadas: "+V.gasLayers+" gás / "+V.volumeLayers+" recortes","Véu frontal próximo da câmera: "+(V.foregroundNear?"sim":"não"),"Mãos em primeira pessoa: "+(V.handsVisible?"visíveis":"desligadas")+" · modo: "+V.handsMode+" · superfícies: "+V.handsSurfaces+" · texturas de mãos: "+V.handsTextures+" · triângulos por mão: "+V.handsTriangles,"Rig pronto: "+(V.handsReady?"sim":"carregando/indisponível")+" · ossos: "+V.handsJoints+" · juntas de dedos: "+V.handsFingerJoints,...V.handsMode==="fps"&&window.__orionHandsDebug?.state?.framing?["FPS | punhos NDC: "+JSON.stringify(window.__orionHandsDebug.state.framing)]:[],...V.handsLoadError?["Falha no rig: "+V.handsLoadError]:[],"Profundidade orgânica: "+(V.depthMotion?"ativa":"desativada")+" · intensidade: "+V.parallaxStrength,"Draw calls: "+V.drawCalls+" · texturas GPU: "+V.textures,"Diferença interna mouse/câmera: "+V.mouseDeltaPx+" px","Heap JavaScript: "+(V.jsHeapMB==null?"indisponível":V.jsHeapMB+" MB")+" (não é RAM total)"].join(`
`)}function L(){const V=z();return["Projeto Órion · Observatório v0.9.15 (prévia)",new Date().toLocaleString("pt-BR"),H(V),"Amostras: "+V.samples+" · adaptações automáticas: "+V.adaptations,"Janela: "+V.viewport,"Memória total da aba: verificar no Gerenciador de tarefas do Chrome (Shift+Esc).","Os valores são observações locais, não benchmarks de GPU nem medidas de VRAM."].join(`
`)}const N=Yy(t,z);function B(V){V-b<1e3||(b=V,T=z(V),r.textContent=H(T))}return a.addEventListener("click",async()=>{const V=L()+`

`+N.report();try{if(!navigator.clipboard?.writeText)throw new Error("Clipboard indisponível");await navigator.clipboard.writeText(V),o.textContent="Diagnóstico copiado. Pode colar no chat."}catch{o.textContent="Cópia automática indisponível; selecione o texto abaixo.";const Y=document.createElement("textarea");Y.readOnly=!0,Y.className="perf-fallback",Y.setAttribute("aria-label","Diagnóstico para cópia manual"),Y.value=V,t.querySelector(".perf-fallback")?.remove(),t.appendChild(Y),Y.focus(),Y.select()}}),{record:k,refresh:B,reset:D,snapshot:z,report:L,get latest(){return T}}}function $y(){const i=document.createElement("canvas");i.width=320,i.height=512;const e=i.getContext("2d");if(!e)throw new Error("Canvas 2D indisponível para as mãos etéreas");const t=new Path2D;t.moveTo(30,520),t.bezierCurveTo(38,460,60,418,89,385),t.bezierCurveTo(108,363,119,352,114,328),t.bezierCurveTo(102,309,99,289,106,279),t.bezierCurveTo(112,269,123,271,132,287),t.bezierCurveTo(137,295,140,315,143,323),t.lineTo(140,264),t.bezierCurveTo(140,247,145,237,155,236),t.bezierCurveTo(167,237,167,249,167,264),t.lineTo(169,304),t.lineTo(169,236),t.bezierCurveTo(169,222,174,213,184,212),t.bezierCurveTo(197,213,199,227,198,243),t.lineTo(199,306),t.lineTo(205,269),t.bezierCurveTo(206,252,214,246,226,250),t.bezierCurveTo(238,256,235,270,232,286),t.lineTo(222,333),t.bezierCurveTo(239,323,251,313,266,316),t.bezierCurveTo(280,319,282,330,273,341),t.bezierCurveTo(261,355,246,365,238,386),t.bezierCurveTo(223,426,226,475,245,520),t.closePath(),e.save(),e.shadowBlur=23,e.shadowColor="rgba(173,96,212,.25)";const n=e.createLinearGradient(74,210,247,502);n.addColorStop(0,"rgba(101,76,149,.96)"),n.addColorStop(.31,"rgba(74,51,115,.98)"),n.addColorStop(.65,"rgba(34,28,69,.99)"),n.addColorStop(1,"rgba(9,15,39,.98)"),e.fillStyle=n,e.fill(t),e.restore(),e.save(),e.clip(t);const r=e.createRadialGradient(194,305,5,178,327,156);r.addColorStop(0,"rgba(209,135,218,.35)"),r.addColorStop(.45,"rgba(136,92,189,.20)"),r.addColorStop(1,"rgba(54,30,99,0)"),e.fillStyle=r,e.fillRect(0,160,320,360),e.lineCap="round",e.lineJoin="round",e.lineWidth=5,e.strokeStyle="rgba(245,203,255,.10)",e.beginPath(),e.moveTo(112,338),e.bezierCurveTo(143,319,170,322,193,339),e.moveTo(123,369),e.bezierCurveTo(162,355,189,358,219,380),e.moveTo(150,266),e.lineTo(151,304),e.moveTo(181,242),e.lineTo(182,298),e.moveTo(217,275),e.lineTo(210,310),e.stroke(),e.strokeStyle="rgba(208,146,244,.28)",e.lineWidth=2,e.beginPath(),e.moveTo(117,308),e.bezierCurveTo(126,349,133,353,144,361),e.moveTo(148,252),e.lineTo(150,289),e.moveTo(177,226),e.lineTo(179,286),e.moveTo(218,263),e.lineTo(211,309),e.moveTo(110,392),e.bezierCurveTo(120,410,121,437,115,452),e.stroke(),e.save(),e.translate(163,409),e.rotate(-.08);const s=e.createLinearGradient(0,-20,0,45);s.addColorStop(0,"rgba(15,16,38,.35)"),s.addColorStop(.22,"rgba(12,16,42,.90)"),s.addColorStop(.7,"rgba(8,12,30,.96)"),s.addColorStop(1,"rgba(26,19,56,.90)"),e.fillStyle=s,e.fillRect(-110,-5,210,63),e.strokeStyle="rgba(186,113,210,.32)",e.lineWidth=3,e.beginPath(),e.moveTo(-107,0),e.lineTo(98,0),e.stroke(),e.restore(),e.strokeStyle="rgba(230,146,233,.13)",e.lineWidth=7,e.shadowBlur=10,e.shadowColor="rgba(177,78,238,.28)",e.beginPath(),e.moveTo(61,418),e.bezierCurveTo(84,392,98,373,103,345),e.moveTo(239,382),e.bezierCurveTo(231,409,224,446,229,470),e.stroke(),e.shadowBlur=0,e.restore(),e.save(),e.strokeStyle="rgba(185,126,212,.38)",e.lineWidth=2.2,e.lineJoin="round",e.stroke(t),e.restore();const a=e.createLinearGradient(0,388,0,512);a.addColorStop(0,"rgba(0,0,0,1)"),a.addColorStop(.77,"rgba(0,0,0,.92)"),a.addColorStop(1,"rgba(0,0,0,.06)"),e.globalCompositeOperation="destination-in",e.fillStyle=a,e.fillRect(0,0,320,512),e.globalCompositeOperation="source-over";const o=new fo(i);return o.colorSpace=_t,o.anisotropy=1,o.minFilter=Gt,o.magFilter=Dt,o}function Ky(i,{enabled:e=!0,reducedMotion:t=!1}={}){const n={enabled:!!e,visible:!!e,motionEnabled:!t,leftX:0,rightX:0,swayX:0,swayY:0,textureCount:e?1:0,drawSurfaces:e?2:0};if(!e)return{state:n,meshes:[],update(){},resize(){},beginTravel(){},dispose(){}};const r=$y(),s=new yn(1,1),a=new Ut({map:r,transparent:!0,opacity:.78,depthTest:!1,depthWrite:!1,toneMapped:!1,side:Et}),o=new ht(s,a),l=new ht(s,a);o.name="Mão etérea esquerda · pose de primeira pessoa v0.9.11",l.name="Mão etérea direita · pose de primeira pessoa v0.9.11",o.layers.set(0),l.layers.set(0),o.renderOrder=30,l.renderOrder=30,o.frustumCulled=!1,l.frustumCulled=!1,i.add(o,l);const c=[o,l],d={left:{z:-1.1,x:-.7,y:-.72,size:1.1,roll:-.2,pitch:.055,yaw:.025,sway:.86},right:{z:-1,x:.68,y:-.66,size:1.17,roll:.18,pitch:.035,yaw:-.025,sway:1}};let u=0,h=0;function p(y){const _=Math.tan(_e.degToRad(i.fov/2))*Math.abs(y);return{hh:_,hw:_*i.aspect}}function g(){for(const[y,_,x]of[[o,d.left,1],[l,d.right,-1]]){const{hh:R,hw:M}=p(_.z),w=R*_.size;y.scale.set(x*w*(320/512),w,1),y.position.set(M*_.x,R*_.y,_.z),y.rotation.set(_.pitch,_.yaw,_.roll)}n.leftX=o.position.x,n.rightX=l.position.x}g();function v(y,_,x=0,R=0){if(!n.visible)return;const M=_e.clamp(x,-1,1),w=_e.clamp(R,-1,1),A=n.motionEnabled?1-Math.exp(-Math.max(0,Math.min(_,.06))*7.5):1;u+=(M-u)*A,h+=(w-h)*A,n.swayX=n.motionEnabled?u:0,n.swayY=n.motionEnabled?h:0;const S=n.motionEnabled?Math.sin(y*.81)*.006:0;for(const[b,T,D]of[[o,d.left,.9],[l,d.right,1]]){const{hh:k,hw:z}=p(T.z),H=n.swayX*z*.029*T.sway,L=n.swayY*k*.024*T.sway;b.position.set(z*T.x-H,k*T.y-L+S*k*D,T.z),b.rotation.set(T.pitch+(n.motionEnabled?n.swayY*.012:0),T.yaw,T.roll+(n.motionEnabled?n.swayX*.02*T.sway:0))}n.leftX=o.position.x,n.rightX=l.position.x}function m(){n.visible=!1,c.forEach(y=>y.visible=!1)}function f(){i.remove(o,l),s.dispose(),a.dispose(),r.dispose()}return{state:n,meshes:c,update:v,resize:g,beginTravel:m,dispose:f}}function Zy(i,e=!1){const t=i[0].index!==null,n=new Set(Object.keys(i[0].attributes)),r=new Set(Object.keys(i[0].morphAttributes)),s={},a={},o=i[0].morphTargetsRelative,l=new Lt;let c=0;for(let d=0;d<i.length;++d){const u=i[d];let h=0;if(t!==(u.index!==null))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."),null;for(const p in u.attributes){if(!n.has(p))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+'. All geometries must have compatible attributes; make sure "'+p+'" attribute exists among all geometries, or in none of them.'),null;s[p]===void 0&&(s[p]=[]),s[p].push(u.attributes[p]),h++}if(h!==n.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+". Make sure all geometries have the same number of attributes."),null;if(o!==u.morphTargetsRelative)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+". .morphTargetsRelative must be consistent throughout all geometries."),null;for(const p in u.morphAttributes){if(!r.has(p))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+".  .morphAttributes must be consistent throughout all geometries."),null;a[p]===void 0&&(a[p]=[]),a[p].push(u.morphAttributes[p])}if(e){let p;if(t)p=u.index.count;else if(u.attributes.position!==void 0)p=u.attributes.position.count;else return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+". The geometry must have either an index or a position attribute"),null;l.addGroup(c,p,d),c+=p}}if(t){let d=0;const u=[];for(let h=0;h<i.length;++h){const p=i[h].index;for(let g=0;g<p.count;++g)u.push(p.getX(g)+d);d+=i[h].attributes.position.count}l.setIndex(u)}for(const d in s){const u=Hd(s[d]);if(!u)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+d+" attribute."),null;l.setAttribute(d,u)}for(const d in a){const u=a[d][0].length;if(u===0)break;l.morphAttributes=l.morphAttributes||{},l.morphAttributes[d]=[];for(let h=0;h<u;++h){const p=[];for(let v=0;v<a[d].length;++v)p.push(a[d][v][h]);const g=Hd(p);if(!g)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+d+" morphAttribute."),null;l.morphAttributes[d].push(g)}}return l}function Hd(i){let e,t,n,r=-1,s=0;for(let c=0;c<i.length;++c){const d=i[c];if(e===void 0&&(e=d.array.constructor),e!==d.array.constructor)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."),null;if(t===void 0&&(t=d.itemSize),t!==d.itemSize)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."),null;if(n===void 0&&(n=d.normalized),n!==d.normalized)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."),null;if(r===-1&&(r=d.gpuType),r!==d.gpuType)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."),null;s+=d.count*t}const a=new e(s),o=new ct(a,t,n);let l=0;for(let c=0;c<i.length;++c){const d=i[c];if(d.isInterleavedBufferAttribute){const u=l/t;for(let h=0,p=d.count;h<p;h++)for(let g=0;g<t;g++){const v=d.getComponent(h,g);o.setComponent(h+u,g,v)}}else a.set(d.array,l);l+=d.count*t}return r!==void 0&&(o.gpuType=r),o}function Gd(i,e){if(e===Kp)return console.warn("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Geometry already defined as triangles."),i;if(e===pc||e===Jh){let t=i.getIndex();if(t===null){const a=[],o=i.getAttribute("position");if(o!==void 0){for(let l=0;l<o.count;l++)a.push(l);i.setIndex(a),t=i.getIndex()}else return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Undefined position attribute. Processing not possible."),i}const n=t.count-2,r=[];if(e===pc)for(let a=1;a<=n;a++)r.push(t.getX(0)),r.push(t.getX(a)),r.push(t.getX(a+1));else for(let a=0;a<n;a++)a%2===0?(r.push(t.getX(a)),r.push(t.getX(a+1)),r.push(t.getX(a+2))):(r.push(t.getX(a+2)),r.push(t.getX(a+1)),r.push(t.getX(a)));r.length/3!==n&&console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unable to generate correct amount of triangles.");const s=i.clone();return s.setIndex(r),s.clearGroups(),s}else return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unknown draw mode:",e),i}const ml=new Ie("#5b3e83"),Jy=new Ie("#171831"),Wd=new Ie("#ba79ca"),Qy=new Ie("#101329"),gl=new U(-.48,.64,.64).normalize();function Cf(i,{kind:e="skin",strength:t=1}={}){const n=i.getAttribute("position"),r=i.getAttribute("normal"),s=new Float32Array(n.count*4),a=new Ie;for(let o=0;o<n.count;o++){n.getX(o);const l=n.getY(o),c=r.getX(o),d=r.getY(o),u=r.getZ(o),h=Math.max(0,c*gl.x+d*gl.y+u*gl.z),p=Math.max(0,u);if(e==="cuff")a.copy(Qy).lerp(ml,Math.min(.22,h*.14));else if(e==="glimmer")a.copy(Wd).lerp(ml,.25);else{a.copy(Jy).lerp(ml,.44+.36*h+.13*p);const v=Math.min(.2,Math.max(0,l-.2)*.42);a.lerp(Wd,Math.min(.44,v+h*.1*t))}const g=_e.smoothstep(l,-1.15,-.79);s[o*4]=a.r,s[o*4+1]=a.g,s[o*4+2]=a.b,s[o*4+3]=(e==="glimmer"?.5:1)*g}return i.setAttribute("color",new nt(s,4)),i}function ri(i,e,t,n="skin",r=12,s=8){const a=new $c(1,r,s);a.scale(t[0],t[1],t[2]),a.translate(e[0],e[1],e[2]),i.push(Cf(a,{kind:n}))}function Xi(i,e,t,n,r,s="skin"){const a=new U(...e),o=new U(...t),l=o.clone().sub(a),c=l.length();if(c<.001)return;const d=new jc(r,n,c,9,1,!1),u=new dt().setFromUnitVectors(new U(0,1,0),l.normalize());d.applyMatrix4(new qe().compose(a.add(o).multiplyScalar(.5),u,new U(1,1,1))),i.push(Cf(d,{kind:s}))}function eb(){const i=[];Xi(i,[0,-1.12,-.16],[.025,-.4,-.04],.185,.135,"cuff"),ri(i,[.023,-.49,-.035],[.153,.13,.124],"cuff"),Xi(i,[.025,-.43,-.04],[.02,-.25,.025],.125,.118),ri(i,[0,-.07,.035],[.27,.326,.126]),ri(i,[.002,.13,.063],[.225,.144,.115]),ri(i,[.178,-.16,.114],[.12,.17,.108]);const e=[{x:-.205,len:.265,lean:-.057,r:.047},{x:-.104,len:.344,lean:-.024,r:.053},{x:.011,len:.393,lean:.011,r:.057},{x:.125,len:.334,lean:.064,r:.051}];for(const a of e){const o=[a.x,.187,.067],l=[a.x+a.lean*.43,.187+a.len*.57,.018],c=[a.x+a.lean,.187+a.len,-.1];Xi(i,o,l,a.r*1.18,a.r*.93),ri(i,l,[a.r*.99,a.r*.99,a.r*.94]),Xi(i,l,c,a.r*.94,a.r*.72),ri(i,c,[a.r*.8,a.r*.9,a.r*.78]),ri(i,[c[0],c[1]+a.r*.18,c[2]+a.r*.48],[a.r*.43,a.r*.25,a.r*.12],"glimmer",8,5)}const t=[.196,-.168,.117],n=[.357,-.043,.157],r=[.385,.102,.073];Xi(i,t,n,.083,.062),ri(i,n,[.066,.066,.068]),Xi(i,n,r,.062,.043),ri(i,r,[.051,.062,.048]),Xi(i,[.025,-.53,-.034],[.025,-.49,-.034],.159,.159,"glimmer");const s=Zy(i,!1);for(const a of i)a.dispose();if(!s)throw new Error("Não foi possível mesclar a malha das mãos 3D");return s.computeBoundingSphere(),s.userData.fingerCount=5,s.userData.sections=i.length,s.userData.triangles=s.index?.count/3,s}function tb(i,{enabled:e=!0,reducedMotion:t=!1}={}){const n={mode:"3d",enabled:!!e,visible:!!e,motionEnabled:!t,textureCount:0,drawSurfaces:e?2:0,fingerCount:e?10:0,leftX:0,rightX:0,swayX:0,swayY:0,triangles:0};if(!e)return{state:n,meshes:[],update(){},resize(){},beginTravel(){},dispose(){}};const r=eb();n.triangles=r.userData.triangles;const s=new Ut({color:16777215,vertexColors:!0,transparent:!0,opacity:.92,side:Et,depthTest:!1,depthWrite:!1,toneMapped:!1}),a=new ht(r,s),o=new ht(r,s);a.name="Mão 3D esquerda · primeira pessoa",o.name="Mão 3D direita · primeira pessoa";for(const f of[a,o])f.layers.set(0),f.renderOrder=30,f.frustumCulled=!1;i.add(a,o);const l=[a,o],c={left:{z:-1.1,x:-.78,y:-.82,size:.65,roll:-.2,pitch:-.13,yaw:-.13,sway:.86},right:{z:-1,x:.76,y:-.8,size:.68,roll:.18,pitch:-.11,yaw:.12,sway:1}};function d(f){const y=Math.tan(_e.degToRad(i.fov*.5))*Math.abs(f);return{hh:y,hw:y*i.aspect}}function u(){for(const[f,y,_]of[[a,c.left,1],[o,c.right,-1]]){const{hh:x,hw:R}=d(y.z),M=x*y.size;f.scale.set(_*M,M,M),f.position.set(R*y.x,x*y.y,y.z),f.rotation.set(y.pitch,y.yaw,y.roll)}n.leftX=a.position.x,n.rightX=o.position.x}let h=0,p=0;u();function g(f,y,_=0,x=0){if(!n.visible)return;const R=n.motionEnabled?1-Math.exp(-Math.max(0,Math.min(y,.06))*7.5):1;h+=(_e.clamp(_,-1,1)-h)*R,p+=(_e.clamp(x,-1,1)-p)*R,n.swayX=n.motionEnabled?h:0,n.swayY=n.motionEnabled?p:0;const M=n.motionEnabled?Math.sin(f*.81)*.006:0;for(const[w,A,S]of[[a,c.left,.9],[o,c.right,1]]){const{hh:b,hw:T}=d(A.z);w.position.set(T*(A.x-n.swayX*.029*A.sway),b*(A.y-n.swayY*.024*A.sway+M*S),A.z),w.rotation.set(A.pitch+(n.motionEnabled?n.swayY*.012:0),A.yaw+(n.motionEnabled?n.swayX*.01:0),A.roll+(n.motionEnabled?n.swayX*.02*A.sway:0))}n.leftX=a.position.x,n.rightX=o.position.x}function v(){n.visible=!1;for(const f of l)f.visible=!1}function m(){i.remove(a,o),r.dispose(),s.dispose()}return{state:n,meshes:l,update:g,resize:u,beginTravel:v,dispose:m}}class nu extends is{constructor(e){super(e),this.dracoLoader=null,this.ktx2Loader=null,this.meshoptDecoder=null,this.pluginCallbacks=[],this.register(function(t){return new ab(t)}),this.register(function(t){return new ob(t)}),this.register(function(t){return new gb(t)}),this.register(function(t){return new vb(t)}),this.register(function(t){return new _b(t)}),this.register(function(t){return new cb(t)}),this.register(function(t){return new ub(t)}),this.register(function(t){return new db(t)}),this.register(function(t){return new hb(t)}),this.register(function(t){return new sb(t)}),this.register(function(t){return new fb(t)}),this.register(function(t){return new lb(t)}),this.register(function(t){return new mb(t)}),this.register(function(t){return new pb(t)}),this.register(function(t){return new ib(t)}),this.register(function(t){return new xb(t)}),this.register(function(t){return new yb(t)})}load(e,t,n,r){const s=this;let a;if(this.resourcePath!=="")a=this.resourcePath;else if(this.path!==""){const c=Rs.extractUrlBase(e);a=Rs.resolveURL(c,this.path)}else a=Rs.extractUrlBase(e);this.manager.itemStart(e);const o=function(c){r?r(c):console.error(c),s.manager.itemError(e),s.manager.itemEnd(e)},l=new xf(this.manager);l.setPath(this.path),l.setResponseType("arraybuffer"),l.setRequestHeader(this.requestHeader),l.setWithCredentials(this.withCredentials),l.load(e,function(c){try{s.parse(c,a,function(d){t(d),s.manager.itemEnd(e)},o)}catch(d){o(d)}},n,o)}setDRACOLoader(e){return this.dracoLoader=e,this}setKTX2Loader(e){return this.ktx2Loader=e,this}setMeshoptDecoder(e){return this.meshoptDecoder=e,this}register(e){return this.pluginCallbacks.indexOf(e)===-1&&this.pluginCallbacks.push(e),this}unregister(e){return this.pluginCallbacks.indexOf(e)!==-1&&this.pluginCallbacks.splice(this.pluginCallbacks.indexOf(e),1),this}parse(e,t,n,r){let s;const a={},o={},l=new TextDecoder;if(typeof e=="string")s=JSON.parse(e);else if(e instanceof ArrayBuffer)if(l.decode(new Uint8Array(e,0,4))===If){try{a[Qe.KHR_BINARY_GLTF]=new bb(e)}catch(u){r&&r(u);return}s=JSON.parse(a[Qe.KHR_BINARY_GLTF].content)}else s=JSON.parse(l.decode(e));else s=e;if(s.asset===void 0||s.asset.version[0]<2){r&&r(new Error("THREE.GLTFLoader: Unsupported asset. glTF versions >=2.0 are supported."));return}const c=new Nb(s,{path:t||this.resourcePath||"",crossOrigin:this.crossOrigin,requestHeader:this.requestHeader,manager:this.manager,ktx2Loader:this.ktx2Loader,meshoptDecoder:this.meshoptDecoder});c.fileLoader.setRequestHeader(this.requestHeader);for(let d=0;d<this.pluginCallbacks.length;d++){const u=this.pluginCallbacks[d](c);u.name||console.error("THREE.GLTFLoader: Invalid plugin found: missing name"),o[u.name]=u,a[u.name]=!0}if(s.extensionsUsed)for(let d=0;d<s.extensionsUsed.length;++d){const u=s.extensionsUsed[d],h=s.extensionsRequired||[];switch(u){case Qe.KHR_MATERIALS_UNLIT:a[u]=new rb;break;case Qe.KHR_DRACO_MESH_COMPRESSION:a[u]=new Sb(s,this.dracoLoader);break;case Qe.KHR_TEXTURE_TRANSFORM:a[u]=new Mb;break;case Qe.KHR_MESH_QUANTIZATION:a[u]=new Eb;break;default:h.indexOf(u)>=0&&o[u]===void 0&&console.warn('THREE.GLTFLoader: Unknown extension "'+u+'".')}}c.setExtensions(a),c.setPlugins(o),c.parse(n,r)}parseAsync(e,t){const n=this;return new Promise(function(r,s){n.parse(e,t,r,s)})}}function nb(){let i={};return{get:function(e){return i[e]},add:function(e,t){i[e]=t},remove:function(e){delete i[e]},removeAll:function(){i={}}}}const Qe={KHR_BINARY_GLTF:"KHR_binary_glTF",KHR_DRACO_MESH_COMPRESSION:"KHR_draco_mesh_compression",KHR_LIGHTS_PUNCTUAL:"KHR_lights_punctual",KHR_MATERIALS_CLEARCOAT:"KHR_materials_clearcoat",KHR_MATERIALS_DISPERSION:"KHR_materials_dispersion",KHR_MATERIALS_IOR:"KHR_materials_ior",KHR_MATERIALS_SHEEN:"KHR_materials_sheen",KHR_MATERIALS_SPECULAR:"KHR_materials_specular",KHR_MATERIALS_TRANSMISSION:"KHR_materials_transmission",KHR_MATERIALS_IRIDESCENCE:"KHR_materials_iridescence",KHR_MATERIALS_ANISOTROPY:"KHR_materials_anisotropy",KHR_MATERIALS_UNLIT:"KHR_materials_unlit",KHR_MATERIALS_VOLUME:"KHR_materials_volume",KHR_TEXTURE_BASISU:"KHR_texture_basisu",KHR_TEXTURE_TRANSFORM:"KHR_texture_transform",KHR_MESH_QUANTIZATION:"KHR_mesh_quantization",KHR_MATERIALS_EMISSIVE_STRENGTH:"KHR_materials_emissive_strength",EXT_MATERIALS_BUMP:"EXT_materials_bump",EXT_TEXTURE_WEBP:"EXT_texture_webp",EXT_TEXTURE_AVIF:"EXT_texture_avif",EXT_MESHOPT_COMPRESSION:"EXT_meshopt_compression",EXT_MESH_GPU_INSTANCING:"EXT_mesh_gpu_instancing"};class ib{constructor(e){this.parser=e,this.name=Qe.KHR_LIGHTS_PUNCTUAL,this.cache={refs:{},uses:{}}}_markDefs(){const e=this.parser,t=this.parser.json.nodes||[];for(let n=0,r=t.length;n<r;n++){const s=t[n];s.extensions&&s.extensions[this.name]&&s.extensions[this.name].light!==void 0&&e._addNodeRef(this.cache,s.extensions[this.name].light)}}_loadLight(e){const t=this.parser,n="light:"+e;let r=t.cache.get(n);if(r)return r;const s=t.json,l=((s.extensions&&s.extensions[this.name]||{}).lights||[])[e];let c;const d=new Ie(16777215);l.color!==void 0&&d.setRGB(l.color[0],l.color[1],l.color[2],nn);const u=l.range!==void 0?l.range:0;switch(l.type){case"directional":c=new yf(d),c.target.position.set(0,0,-1),c.add(c.target);break;case"point":c=new Sg(d),c.distance=u;break;case"spot":c=new yg(d),c.distance=u,l.spot=l.spot||{},l.spot.innerConeAngle=l.spot.innerConeAngle!==void 0?l.spot.innerConeAngle:0,l.spot.outerConeAngle=l.spot.outerConeAngle!==void 0?l.spot.outerConeAngle:Math.PI/4,c.angle=l.spot.outerConeAngle,c.penumbra=1-l.spot.innerConeAngle/l.spot.outerConeAngle,c.target.position.set(0,0,-1),c.add(c.target);break;default:throw new Error("THREE.GLTFLoader: Unexpected light type: "+l.type)}return c.position.set(0,0,0),Wn(c,l),l.intensity!==void 0&&(c.intensity=l.intensity),c.name=t.createUniqueName(l.name||"light_"+e),r=Promise.resolve(c),t.cache.add(n,r),r}getDependency(e,t){if(e==="light")return this._loadLight(t)}createNodeAttachment(e){const t=this,n=this.parser,s=n.json.nodes[e],o=(s.extensions&&s.extensions[this.name]||{}).light;return o===void 0?null:this._loadLight(o).then(function(l){return n._getNodeRef(t.cache,o,l)})}}class rb{constructor(){this.name=Qe.KHR_MATERIALS_UNLIT}getMaterialType(){return Ut}extendParams(e,t,n){const r=[];e.color=new Ie(1,1,1),e.opacity=1;const s=t.pbrMetallicRoughness;if(s){if(Array.isArray(s.baseColorFactor)){const a=s.baseColorFactor;e.color.setRGB(a[0],a[1],a[2],nn),e.opacity=a[3]}s.baseColorTexture!==void 0&&r.push(n.assignTexture(e,"map",s.baseColorTexture,_t))}return Promise.all(r)}}class sb{constructor(e){this.parser=e,this.name=Qe.KHR_MATERIALS_EMISSIVE_STRENGTH}extendMaterialParams(e,t){const r=this.parser.json.materials[e];if(!r.extensions||!r.extensions[this.name])return Promise.resolve();const s=r.extensions[this.name].emissiveStrength;return s!==void 0&&(t.emissiveIntensity=s),Promise.resolve()}}class ab{constructor(e){this.parser=e,this.name=Qe.KHR_MATERIALS_CLEARCOAT}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Kn}extendMaterialParams(e,t){const n=this.parser,r=n.json.materials[e];if(!r.extensions||!r.extensions[this.name])return Promise.resolve();const s=[],a=r.extensions[this.name];if(a.clearcoatFactor!==void 0&&(t.clearcoat=a.clearcoatFactor),a.clearcoatTexture!==void 0&&s.push(n.assignTexture(t,"clearcoatMap",a.clearcoatTexture)),a.clearcoatRoughnessFactor!==void 0&&(t.clearcoatRoughness=a.clearcoatRoughnessFactor),a.clearcoatRoughnessTexture!==void 0&&s.push(n.assignTexture(t,"clearcoatRoughnessMap",a.clearcoatRoughnessTexture)),a.clearcoatNormalTexture!==void 0&&(s.push(n.assignTexture(t,"clearcoatNormalMap",a.clearcoatNormalTexture)),a.clearcoatNormalTexture.scale!==void 0)){const o=a.clearcoatNormalTexture.scale;t.clearcoatNormalScale=new Ce(o,o)}return Promise.all(s)}}class ob{constructor(e){this.parser=e,this.name=Qe.KHR_MATERIALS_DISPERSION}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Kn}extendMaterialParams(e,t){const r=this.parser.json.materials[e];if(!r.extensions||!r.extensions[this.name])return Promise.resolve();const s=r.extensions[this.name];return t.dispersion=s.dispersion!==void 0?s.dispersion:0,Promise.resolve()}}class lb{constructor(e){this.parser=e,this.name=Qe.KHR_MATERIALS_IRIDESCENCE}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Kn}extendMaterialParams(e,t){const n=this.parser,r=n.json.materials[e];if(!r.extensions||!r.extensions[this.name])return Promise.resolve();const s=[],a=r.extensions[this.name];return a.iridescenceFactor!==void 0&&(t.iridescence=a.iridescenceFactor),a.iridescenceTexture!==void 0&&s.push(n.assignTexture(t,"iridescenceMap",a.iridescenceTexture)),a.iridescenceIor!==void 0&&(t.iridescenceIOR=a.iridescenceIor),t.iridescenceThicknessRange===void 0&&(t.iridescenceThicknessRange=[100,400]),a.iridescenceThicknessMinimum!==void 0&&(t.iridescenceThicknessRange[0]=a.iridescenceThicknessMinimum),a.iridescenceThicknessMaximum!==void 0&&(t.iridescenceThicknessRange[1]=a.iridescenceThicknessMaximum),a.iridescenceThicknessTexture!==void 0&&s.push(n.assignTexture(t,"iridescenceThicknessMap",a.iridescenceThicknessTexture)),Promise.all(s)}}class cb{constructor(e){this.parser=e,this.name=Qe.KHR_MATERIALS_SHEEN}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Kn}extendMaterialParams(e,t){const n=this.parser,r=n.json.materials[e];if(!r.extensions||!r.extensions[this.name])return Promise.resolve();const s=[];t.sheenColor=new Ie(0,0,0),t.sheenRoughness=0,t.sheen=1;const a=r.extensions[this.name];if(a.sheenColorFactor!==void 0){const o=a.sheenColorFactor;t.sheenColor.setRGB(o[0],o[1],o[2],nn)}return a.sheenRoughnessFactor!==void 0&&(t.sheenRoughness=a.sheenRoughnessFactor),a.sheenColorTexture!==void 0&&s.push(n.assignTexture(t,"sheenColorMap",a.sheenColorTexture,_t)),a.sheenRoughnessTexture!==void 0&&s.push(n.assignTexture(t,"sheenRoughnessMap",a.sheenRoughnessTexture)),Promise.all(s)}}class ub{constructor(e){this.parser=e,this.name=Qe.KHR_MATERIALS_TRANSMISSION}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Kn}extendMaterialParams(e,t){const n=this.parser,r=n.json.materials[e];if(!r.extensions||!r.extensions[this.name])return Promise.resolve();const s=[],a=r.extensions[this.name];return a.transmissionFactor!==void 0&&(t.transmission=a.transmissionFactor),a.transmissionTexture!==void 0&&s.push(n.assignTexture(t,"transmissionMap",a.transmissionTexture)),Promise.all(s)}}class db{constructor(e){this.parser=e,this.name=Qe.KHR_MATERIALS_VOLUME}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Kn}extendMaterialParams(e,t){const n=this.parser,r=n.json.materials[e];if(!r.extensions||!r.extensions[this.name])return Promise.resolve();const s=[],a=r.extensions[this.name];t.thickness=a.thicknessFactor!==void 0?a.thicknessFactor:0,a.thicknessTexture!==void 0&&s.push(n.assignTexture(t,"thicknessMap",a.thicknessTexture)),t.attenuationDistance=a.attenuationDistance||1/0;const o=a.attenuationColor||[1,1,1];return t.attenuationColor=new Ie().setRGB(o[0],o[1],o[2],nn),Promise.all(s)}}class hb{constructor(e){this.parser=e,this.name=Qe.KHR_MATERIALS_IOR}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Kn}extendMaterialParams(e,t){const r=this.parser.json.materials[e];if(!r.extensions||!r.extensions[this.name])return Promise.resolve();const s=r.extensions[this.name];return t.ior=s.ior!==void 0?s.ior:1.5,Promise.resolve()}}class fb{constructor(e){this.parser=e,this.name=Qe.KHR_MATERIALS_SPECULAR}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Kn}extendMaterialParams(e,t){const n=this.parser,r=n.json.materials[e];if(!r.extensions||!r.extensions[this.name])return Promise.resolve();const s=[],a=r.extensions[this.name];t.specularIntensity=a.specularFactor!==void 0?a.specularFactor:1,a.specularTexture!==void 0&&s.push(n.assignTexture(t,"specularIntensityMap",a.specularTexture));const o=a.specularColorFactor||[1,1,1];return t.specularColor=new Ie().setRGB(o[0],o[1],o[2],nn),a.specularColorTexture!==void 0&&s.push(n.assignTexture(t,"specularColorMap",a.specularColorTexture,_t)),Promise.all(s)}}class pb{constructor(e){this.parser=e,this.name=Qe.EXT_MATERIALS_BUMP}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Kn}extendMaterialParams(e,t){const n=this.parser,r=n.json.materials[e];if(!r.extensions||!r.extensions[this.name])return Promise.resolve();const s=[],a=r.extensions[this.name];return t.bumpScale=a.bumpFactor!==void 0?a.bumpFactor:1,a.bumpTexture!==void 0&&s.push(n.assignTexture(t,"bumpMap",a.bumpTexture)),Promise.all(s)}}class mb{constructor(e){this.parser=e,this.name=Qe.KHR_MATERIALS_ANISOTROPY}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Kn}extendMaterialParams(e,t){const n=this.parser,r=n.json.materials[e];if(!r.extensions||!r.extensions[this.name])return Promise.resolve();const s=[],a=r.extensions[this.name];return a.anisotropyStrength!==void 0&&(t.anisotropy=a.anisotropyStrength),a.anisotropyRotation!==void 0&&(t.anisotropyRotation=a.anisotropyRotation),a.anisotropyTexture!==void 0&&s.push(n.assignTexture(t,"anisotropyMap",a.anisotropyTexture)),Promise.all(s)}}class gb{constructor(e){this.parser=e,this.name=Qe.KHR_TEXTURE_BASISU}loadTexture(e){const t=this.parser,n=t.json,r=n.textures[e];if(!r.extensions||!r.extensions[this.name])return null;const s=r.extensions[this.name],a=t.options.ktx2Loader;if(!a){if(n.extensionsRequired&&n.extensionsRequired.indexOf(this.name)>=0)throw new Error("THREE.GLTFLoader: setKTX2Loader must be called before loading KTX2 textures");return null}return t.loadTextureImage(e,s.source,a)}}class vb{constructor(e){this.parser=e,this.name=Qe.EXT_TEXTURE_WEBP}loadTexture(e){const t=this.name,n=this.parser,r=n.json,s=r.textures[e];if(!s.extensions||!s.extensions[t])return null;const a=s.extensions[t],o=r.images[a.source];let l=n.textureLoader;if(o.uri){const c=n.options.manager.getHandler(o.uri);c!==null&&(l=c)}return n.loadTextureImage(e,a.source,l)}}class _b{constructor(e){this.parser=e,this.name=Qe.EXT_TEXTURE_AVIF}loadTexture(e){const t=this.name,n=this.parser,r=n.json,s=r.textures[e];if(!s.extensions||!s.extensions[t])return null;const a=s.extensions[t],o=r.images[a.source];let l=n.textureLoader;if(o.uri){const c=n.options.manager.getHandler(o.uri);c!==null&&(l=c)}return n.loadTextureImage(e,a.source,l)}}class xb{constructor(e){this.name=Qe.EXT_MESHOPT_COMPRESSION,this.parser=e}loadBufferView(e){const t=this.parser.json,n=t.bufferViews[e];if(n.extensions&&n.extensions[this.name]){const r=n.extensions[this.name],s=this.parser.getDependency("buffer",r.buffer),a=this.parser.options.meshoptDecoder;if(!a||!a.supported){if(t.extensionsRequired&&t.extensionsRequired.indexOf(this.name)>=0)throw new Error("THREE.GLTFLoader: setMeshoptDecoder must be called before loading compressed files");return null}return s.then(function(o){const l=r.byteOffset||0,c=r.byteLength||0,d=r.count,u=r.byteStride,h=new Uint8Array(o,l,c);return a.decodeGltfBufferAsync?a.decodeGltfBufferAsync(d,u,h,r.mode,r.filter).then(function(p){return p.buffer}):a.ready.then(function(){const p=new ArrayBuffer(d*u);return a.decodeGltfBuffer(new Uint8Array(p),d,u,h,r.mode,r.filter),p})})}else return null}}class yb{constructor(e){this.name=Qe.EXT_MESH_GPU_INSTANCING,this.parser=e}createNodeMesh(e){const t=this.parser.json,n=t.nodes[e];if(!n.extensions||!n.extensions[this.name]||n.mesh===void 0)return null;const r=t.meshes[n.mesh];for(const c of r.primitives)if(c.mode!==Tn.TRIANGLES&&c.mode!==Tn.TRIANGLE_STRIP&&c.mode!==Tn.TRIANGLE_FAN&&c.mode!==void 0)return null;const a=n.extensions[this.name].attributes,o=[],l={};for(const c in a)o.push(this.parser.getDependency("accessor",a[c]).then(d=>(l[c]=d,l[c])));return o.length<1?null:(o.push(this.parser.createNodeMesh(e)),Promise.all(o).then(c=>{const d=c.pop(),u=d.isGroup?d.children:[d],h=c[0].count,p=[];for(const g of u){const v=new qe,m=new U,f=new dt,y=new U(1,1,1),_=new Zm(g.geometry,g.material,h);for(let x=0;x<h;x++)l.TRANSLATION&&m.fromBufferAttribute(l.TRANSLATION,x),l.ROTATION&&f.fromBufferAttribute(l.ROTATION,x),l.SCALE&&y.fromBufferAttribute(l.SCALE,x),_.setMatrixAt(x,v.compose(m,f,y));for(const x in l)if(x==="_COLOR_0"){const R=l[x];_.instanceColor=new Xr(R.array,R.itemSize,R.normalized)}else x!=="TRANSLATION"&&x!=="ROTATION"&&x!=="SCALE"&&g.geometry.setAttribute(x,l[x]);Mt.prototype.copy.call(_,g),this.parser.assignFinalMaterial(_),p.push(_)}return d.isGroup?(d.clear(),d.add(...p),d):p[0]}))}}const If="glTF",bs=12,Xd={JSON:1313821514,BIN:5130562};class bb{constructor(e){this.name=Qe.KHR_BINARY_GLTF,this.content=null,this.body=null;const t=new DataView(e,0,bs),n=new TextDecoder;if(this.header={magic:n.decode(new Uint8Array(e.slice(0,4))),version:t.getUint32(4,!0),length:t.getUint32(8,!0)},this.header.magic!==If)throw new Error("THREE.GLTFLoader: Unsupported glTF-Binary header.");if(this.header.version<2)throw new Error("THREE.GLTFLoader: Legacy binary file detected.");const r=this.header.length-bs,s=new DataView(e,bs);let a=0;for(;a<r;){const o=s.getUint32(a,!0);a+=4;const l=s.getUint32(a,!0);if(a+=4,l===Xd.JSON){const c=new Uint8Array(e,bs+a,o);this.content=n.decode(c)}else if(l===Xd.BIN){const c=bs+a;this.body=e.slice(c,c+o)}a+=o}if(this.content===null)throw new Error("THREE.GLTFLoader: JSON content not found.")}}class Sb{constructor(e,t){if(!t)throw new Error("THREE.GLTFLoader: No DRACOLoader instance provided.");this.name=Qe.KHR_DRACO_MESH_COMPRESSION,this.json=e,this.dracoLoader=t,this.dracoLoader.preload()}decodePrimitive(e,t){const n=this.json,r=this.dracoLoader,s=e.extensions[this.name].bufferView,a=e.extensions[this.name].attributes,o={},l={},c={};for(const d in a){const u=xc[d]||d.toLowerCase();o[u]=a[d]}for(const d in e.attributes){const u=xc[d]||d.toLowerCase();if(a[d]!==void 0){const h=n.accessors[e.attributes[d]],p=Nr[h.componentType];c[u]=p.name,l[u]=h.normalized===!0}}return t.getDependency("bufferView",s).then(function(d){return new Promise(function(u,h){r.decodeDracoFile(d,function(p){for(const g in p.attributes){const v=p.attributes[g],m=l[g];m!==void 0&&(v.normalized=m)}u(p)},o,c,nn,h)})})}}class Mb{constructor(){this.name=Qe.KHR_TEXTURE_TRANSFORM}extendTexture(e,t){return(t.texCoord===void 0||t.texCoord===e.channel)&&t.offset===void 0&&t.rotation===void 0&&t.scale===void 0||(e=e.clone(),t.texCoord!==void 0&&(e.channel=t.texCoord),t.offset!==void 0&&e.offset.fromArray(t.offset),t.rotation!==void 0&&(e.rotation=t.rotation),t.scale!==void 0&&e.repeat.fromArray(t.scale),e.needsUpdate=!0),e}}class Eb{constructor(){this.name=Qe.KHR_MESH_QUANTIZATION}}class Pf extends Xs{constructor(e,t,n,r){super(e,t,n,r)}copySampleValue_(e){const t=this.resultBuffer,n=this.sampleValues,r=this.valueSize,s=e*r*3+r;for(let a=0;a!==r;a++)t[a]=n[s+a];return t}interpolate_(e,t,n,r){const s=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=o*2,c=o*3,d=r-t,u=(n-t)/d,h=u*u,p=h*u,g=e*c,v=g-c,m=-2*p+3*h,f=p-h,y=1-m,_=f-h+u;for(let x=0;x!==o;x++){const R=a[v+x+o],M=a[v+x+l]*d,w=a[g+x+o],A=a[g+x]*d;s[x]=y*R+_*M+m*w+f*A}return s}}const Tb=new dt;class Ab extends Pf{interpolate_(e,t,n,r){const s=super.interpolate_(e,t,n,r);return Tb.fromArray(s).normalize().toArray(s),s}}const Tn={POINTS:0,LINES:1,LINE_LOOP:2,LINE_STRIP:3,TRIANGLES:4,TRIANGLE_STRIP:5,TRIANGLE_FAN:6},Nr={5120:Int8Array,5121:Uint8Array,5122:Int16Array,5123:Uint16Array,5125:Uint32Array,5126:Float32Array},qd={9728:en,9729:Dt,9984:Wh,9985:Fa,9986:Ms,9987:Gt},Yd={33071:Ii,33648:Wa,10497:Hr},vl={SCALAR:1,VEC2:2,VEC3:3,VEC4:4,MAT2:4,MAT3:9,MAT4:16},xc={POSITION:"position",NORMAL:"normal",TANGENT:"tangent",TEXCOORD_0:"uv",TEXCOORD_1:"uv1",TEXCOORD_2:"uv2",TEXCOORD_3:"uv3",COLOR_0:"color",WEIGHTS_0:"skinWeight",JOINTS_0:"skinIndex"},Si={scale:"scale",translation:"position",rotation:"quaternion",weights:"morphTargetInfluences"},wb={CUBICSPLINE:void 0,LINEAR:Os,STEP:Ns},_l={OPAQUE:"OPAQUE",MASK:"MASK",BLEND:"BLEND"};function Rb(i){return i.DefaultMaterial===void 0&&(i.DefaultMaterial=new Kc({color:16777215,emissive:0,metalness:1,roughness:1,transparent:!1,depthTest:!0,side:mi})),i.DefaultMaterial}function qi(i,e,t){for(const n in t.extensions)i[n]===void 0&&(e.userData.gltfExtensions=e.userData.gltfExtensions||{},e.userData.gltfExtensions[n]=t.extensions[n])}function Wn(i,e){e.extras!==void 0&&(typeof e.extras=="object"?Object.assign(i.userData,e.extras):console.warn("THREE.GLTFLoader: Ignoring primitive type .extras, "+e.extras))}function Cb(i,e,t){let n=!1,r=!1,s=!1;for(let c=0,d=e.length;c<d;c++){const u=e[c];if(u.POSITION!==void 0&&(n=!0),u.NORMAL!==void 0&&(r=!0),u.COLOR_0!==void 0&&(s=!0),n&&r&&s)break}if(!n&&!r&&!s)return Promise.resolve(i);const a=[],o=[],l=[];for(let c=0,d=e.length;c<d;c++){const u=e[c];if(n){const h=u.POSITION!==void 0?t.getDependency("accessor",u.POSITION):i.attributes.position;a.push(h)}if(r){const h=u.NORMAL!==void 0?t.getDependency("accessor",u.NORMAL):i.attributes.normal;o.push(h)}if(s){const h=u.COLOR_0!==void 0?t.getDependency("accessor",u.COLOR_0):i.attributes.color;l.push(h)}}return Promise.all([Promise.all(a),Promise.all(o),Promise.all(l)]).then(function(c){const d=c[0],u=c[1],h=c[2];return n&&(i.morphAttributes.position=d),r&&(i.morphAttributes.normal=u),s&&(i.morphAttributes.color=h),i.morphTargetsRelative=!0,i})}function Ib(i,e){if(i.updateMorphTargets(),e.weights!==void 0)for(let t=0,n=e.weights.length;t<n;t++)i.morphTargetInfluences[t]=e.weights[t];if(e.extras&&Array.isArray(e.extras.targetNames)){const t=e.extras.targetNames;if(i.morphTargetInfluences.length===t.length){i.morphTargetDictionary={};for(let n=0,r=t.length;n<r;n++)i.morphTargetDictionary[t[n]]=n}else console.warn("THREE.GLTFLoader: Invalid extras.targetNames length. Ignoring names.")}}function Pb(i){let e;const t=i.extensions&&i.extensions[Qe.KHR_DRACO_MESH_COMPRESSION];if(t?e="draco:"+t.bufferView+":"+t.indices+":"+xl(t.attributes):e=i.indices+":"+xl(i.attributes)+":"+i.mode,i.targets!==void 0)for(let n=0,r=i.targets.length;n<r;n++)e+=":"+xl(i.targets[n]);return e}function xl(i){let e="";const t=Object.keys(i).sort();for(let n=0,r=t.length;n<r;n++)e+=t[n]+":"+i[t[n]]+";";return e}function yc(i){switch(i){case Int8Array:return 1/127;case Uint8Array:return 1/255;case Int16Array:return 1/32767;case Uint16Array:return 1/65535;default:throw new Error("THREE.GLTFLoader: Unsupported normalized accessor component type.")}}function Lb(i){return i.search(/\.jpe?g($|\?)/i)>0||i.search(/^data\:image\/jpeg/)===0?"image/jpeg":i.search(/\.webp($|\?)/i)>0||i.search(/^data\:image\/webp/)===0?"image/webp":i.search(/\.ktx2($|\?)/i)>0||i.search(/^data\:image\/ktx2/)===0?"image/ktx2":"image/png"}const Db=new qe;class Nb{constructor(e={},t={}){this.json=e,this.extensions={},this.plugins={},this.options=t,this.cache=new nb,this.associations=new Map,this.primitiveCache={},this.nodeCache={},this.meshCache={refs:{},uses:{}},this.cameraCache={refs:{},uses:{}},this.lightCache={refs:{},uses:{}},this.sourceCache={},this.textureCache={},this.nodeNamesUsed={};let n=!1,r=-1,s=!1,a=-1;if(typeof navigator<"u"){const o=navigator.userAgent;n=/^((?!chrome|android).)*safari/i.test(o)===!0;const l=o.match(/Version\/(\d+)/);r=n&&l?parseInt(l[1],10):-1,s=o.indexOf("Firefox")>-1,a=s?o.match(/Firefox\/([0-9]+)\./)[1]:-1}typeof createImageBitmap>"u"||n&&r<17||s&&a<98?this.textureLoader=new rs(this.options.manager):this.textureLoader=new Tg(this.options.manager),this.textureLoader.setCrossOrigin(this.options.crossOrigin),this.textureLoader.setRequestHeader(this.options.requestHeader),this.fileLoader=new xf(this.options.manager),this.fileLoader.setResponseType("arraybuffer"),this.options.crossOrigin==="use-credentials"&&this.fileLoader.setWithCredentials(!0)}setExtensions(e){this.extensions=e}setPlugins(e){this.plugins=e}parse(e,t){const n=this,r=this.json,s=this.extensions;this.cache.removeAll(),this.nodeCache={},this._invokeAll(function(a){return a._markDefs&&a._markDefs()}),Promise.all(this._invokeAll(function(a){return a.beforeRoot&&a.beforeRoot()})).then(function(){return Promise.all([n.getDependencies("scene"),n.getDependencies("animation"),n.getDependencies("camera")])}).then(function(a){const o={scene:a[0][r.scene||0],scenes:a[0],animations:a[1],cameras:a[2],asset:r.asset,parser:n,userData:{}};return qi(s,o,r),Wn(o,r),Promise.all(n._invokeAll(function(l){return l.afterRoot&&l.afterRoot(o)})).then(function(){for(const l of o.scenes)l.updateMatrixWorld();e(o)})}).catch(t)}_markDefs(){const e=this.json.nodes||[],t=this.json.skins||[],n=this.json.meshes||[];for(let r=0,s=t.length;r<s;r++){const a=t[r].joints;for(let o=0,l=a.length;o<l;o++)e[a[o]].isBone=!0}for(let r=0,s=e.length;r<s;r++){const a=e[r];a.mesh!==void 0&&(this._addNodeRef(this.meshCache,a.mesh),a.skin!==void 0&&(n[a.mesh].isSkinnedMesh=!0)),a.camera!==void 0&&this._addNodeRef(this.cameraCache,a.camera)}}_addNodeRef(e,t){t!==void 0&&(e.refs[t]===void 0&&(e.refs[t]=e.uses[t]=0),e.refs[t]++)}_getNodeRef(e,t,n){if(e.refs[t]<=1)return n;const r=n.clone(),s=(a,o)=>{const l=this.associations.get(a);l!=null&&this.associations.set(o,l);for(const[c,d]of a.children.entries())s(d,o.children[c])};return s(n,r),r.name+="_instance_"+e.uses[t]++,r}_invokeOne(e){const t=Object.values(this.plugins);t.push(this);for(let n=0;n<t.length;n++){const r=e(t[n]);if(r)return r}return null}_invokeAll(e){const t=Object.values(this.plugins);t.unshift(this);const n=[];for(let r=0;r<t.length;r++){const s=e(t[r]);s&&n.push(s)}return n}getDependency(e,t){const n=e+":"+t;let r=this.cache.get(n);if(!r){switch(e){case"scene":r=this.loadScene(t);break;case"node":r=this._invokeOne(function(s){return s.loadNode&&s.loadNode(t)});break;case"mesh":r=this._invokeOne(function(s){return s.loadMesh&&s.loadMesh(t)});break;case"accessor":r=this.loadAccessor(t);break;case"bufferView":r=this._invokeOne(function(s){return s.loadBufferView&&s.loadBufferView(t)});break;case"buffer":r=this.loadBuffer(t);break;case"material":r=this._invokeOne(function(s){return s.loadMaterial&&s.loadMaterial(t)});break;case"texture":r=this._invokeOne(function(s){return s.loadTexture&&s.loadTexture(t)});break;case"skin":r=this.loadSkin(t);break;case"animation":r=this._invokeOne(function(s){return s.loadAnimation&&s.loadAnimation(t)});break;case"camera":r=this.loadCamera(t);break;default:if(r=this._invokeOne(function(s){return s!=this&&s.getDependency&&s.getDependency(e,t)}),!r)throw new Error("Unknown type: "+e);break}this.cache.add(n,r)}return r}getDependencies(e){let t=this.cache.get(e);if(!t){const n=this,r=this.json[e+(e==="mesh"?"es":"s")]||[];t=Promise.all(r.map(function(s,a){return n.getDependency(e,a)})),this.cache.add(e,t)}return t}loadBuffer(e){const t=this.json.buffers[e],n=this.fileLoader;if(t.type&&t.type!=="arraybuffer")throw new Error("THREE.GLTFLoader: "+t.type+" buffer type is not supported.");if(t.uri===void 0&&e===0)return Promise.resolve(this.extensions[Qe.KHR_BINARY_GLTF].body);const r=this.options;return new Promise(function(s,a){n.load(Rs.resolveURL(t.uri,r.path),s,void 0,function(){a(new Error('THREE.GLTFLoader: Failed to load buffer "'+t.uri+'".'))})})}loadBufferView(e){const t=this.json.bufferViews[e];return this.getDependency("buffer",t.buffer).then(function(n){const r=t.byteLength||0,s=t.byteOffset||0;return n.slice(s,s+r)})}loadAccessor(e){const t=this,n=this.json,r=this.json.accessors[e];if(r.bufferView===void 0&&r.sparse===void 0){const a=vl[r.type],o=Nr[r.componentType],l=r.normalized===!0,c=new o(r.count*a);return Promise.resolve(new ct(c,a,l))}const s=[];return r.bufferView!==void 0?s.push(this.getDependency("bufferView",r.bufferView)):s.push(null),r.sparse!==void 0&&(s.push(this.getDependency("bufferView",r.sparse.indices.bufferView)),s.push(this.getDependency("bufferView",r.sparse.values.bufferView))),Promise.all(s).then(function(a){const o=a[0],l=vl[r.type],c=Nr[r.componentType],d=c.BYTES_PER_ELEMENT,u=d*l,h=r.byteOffset||0,p=r.bufferView!==void 0?n.bufferViews[r.bufferView].byteStride:void 0,g=r.normalized===!0;let v,m;if(p&&p!==u){const f=Math.floor(h/p),y="InterleavedBuffer:"+r.bufferView+":"+r.componentType+":"+f+":"+r.count;let _=t.cache.get(y);_||(v=new c(o,f*p,r.count*p/d),_=new uf(v,p/d),t.cache.add(y,_)),m=new Bs(_,l,h%p/d,g)}else o===null?v=new c(r.count*l):v=new c(o,h,r.count*l),m=new ct(v,l,g);if(r.sparse!==void 0){const f=vl.SCALAR,y=Nr[r.sparse.indices.componentType],_=r.sparse.indices.byteOffset||0,x=r.sparse.values.byteOffset||0,R=new y(a[1],_,r.sparse.count*f),M=new c(a[2],x,r.sparse.count*l);o!==null&&(m=new ct(m.array.slice(),m.itemSize,m.normalized)),m.normalized=!1;for(let w=0,A=R.length;w<A;w++){const S=R[w];if(m.setX(S,M[w*l]),l>=2&&m.setY(S,M[w*l+1]),l>=3&&m.setZ(S,M[w*l+2]),l>=4&&m.setW(S,M[w*l+3]),l>=5)throw new Error("THREE.GLTFLoader: Unsupported itemSize in sparse BufferAttribute.")}m.normalized=g}return m})}loadTexture(e){const t=this.json,n=this.options,s=t.textures[e].source,a=t.images[s];let o=this.textureLoader;if(a.uri){const l=n.manager.getHandler(a.uri);l!==null&&(o=l)}return this.loadTextureImage(e,s,o)}loadTextureImage(e,t,n){const r=this,s=this.json,a=s.textures[e],o=s.images[t],l=(o.uri||o.bufferView)+":"+a.sampler;if(this.textureCache[l])return this.textureCache[l];const c=this.loadImageSource(t,n).then(function(d){d.flipY=!1,d.name=a.name||o.name||"",d.name===""&&typeof o.uri=="string"&&o.uri.startsWith("data:image/")===!1&&(d.name=o.uri);const h=(s.samplers||{})[a.sampler]||{};return d.magFilter=qd[h.magFilter]||Dt,d.minFilter=qd[h.minFilter]||Gt,d.wrapS=Yd[h.wrapS]||Hr,d.wrapT=Yd[h.wrapT]||Hr,d.generateMipmaps=!d.isCompressedTexture&&d.minFilter!==en&&d.minFilter!==Dt,r.associations.set(d,{textures:e}),d}).catch(function(){return null});return this.textureCache[l]=c,c}loadImageSource(e,t){const n=this,r=this.json,s=this.options;if(this.sourceCache[e]!==void 0)return this.sourceCache[e].then(u=>u.clone());const a=r.images[e],o=self.URL||self.webkitURL;let l=a.uri||"",c=!1;if(a.bufferView!==void 0)l=n.getDependency("bufferView",a.bufferView).then(function(u){c=!0;const h=new Blob([u],{type:a.mimeType});return l=o.createObjectURL(h),l});else if(a.uri===void 0)throw new Error("THREE.GLTFLoader: Image "+e+" is missing URI and bufferView");const d=Promise.resolve(l).then(function(u){return new Promise(function(h,p){let g=h;t.isImageBitmapLoader===!0&&(g=function(v){const m=new Ft(v);m.needsUpdate=!0,h(m)}),t.load(Rs.resolveURL(u,s.path),g,void 0,p)})}).then(function(u){return c===!0&&o.revokeObjectURL(l),Wn(u,a),u.userData.mimeType=a.mimeType||Lb(a.uri),u}).catch(function(u){throw console.error("THREE.GLTFLoader: Couldn't load texture",l),u});return this.sourceCache[e]=d,d}assignTexture(e,t,n,r){const s=this;return this.getDependency("texture",n.index).then(function(a){if(!a)return null;if(n.texCoord!==void 0&&n.texCoord>0&&(a=a.clone(),a.channel=n.texCoord),s.extensions[Qe.KHR_TEXTURE_TRANSFORM]){const o=n.extensions!==void 0?n.extensions[Qe.KHR_TEXTURE_TRANSFORM]:void 0;if(o){const l=s.associations.get(a);a=s.extensions[Qe.KHR_TEXTURE_TRANSFORM].extendTexture(a,o),s.associations.set(a,l)}}return r!==void 0&&(a.colorSpace=r),e[t]=a,a})}assignFinalMaterial(e){const t=e.geometry;let n=e.material;const r=t.attributes.tangent===void 0,s=t.attributes.color!==void 0,a=t.attributes.normal===void 0;if(e.isPoints){const o="PointsMaterial:"+n.uuid;let l=this.cache.get(o);l||(l=new pf,Cn.prototype.copy.call(l,n),l.color.copy(n.color),l.map=n.map,l.sizeAttenuation=!1,this.cache.add(o,l)),n=l}else if(e.isLine){const o="LineBasicMaterial:"+n.uuid;let l=this.cache.get(o);l||(l=new Xc,Cn.prototype.copy.call(l,n),l.color.copy(n.color),l.map=n.map,this.cache.add(o,l)),n=l}if(r||s||a){let o="ClonedMaterial:"+n.uuid+":";r&&(o+="derivative-tangents:"),s&&(o+="vertex-colors:"),a&&(o+="flat-shading:");let l=this.cache.get(o);l||(l=n.clone(),s&&(l.vertexColors=!0),a&&(l.flatShading=!0),r&&(l.normalScale&&(l.normalScale.y*=-1),l.clearcoatNormalScale&&(l.clearcoatNormalScale.y*=-1)),this.cache.add(o,l),this.associations.set(l,this.associations.get(n))),n=l}e.material=n}getMaterialType(){return Kc}loadMaterial(e){const t=this,n=this.json,r=this.extensions,s=n.materials[e];let a;const o={},l=s.extensions||{},c=[];if(l[Qe.KHR_MATERIALS_UNLIT]){const u=r[Qe.KHR_MATERIALS_UNLIT];a=u.getMaterialType(),c.push(u.extendParams(o,s,t))}else{const u=s.pbrMetallicRoughness||{};if(o.color=new Ie(1,1,1),o.opacity=1,Array.isArray(u.baseColorFactor)){const h=u.baseColorFactor;o.color.setRGB(h[0],h[1],h[2],nn),o.opacity=h[3]}u.baseColorTexture!==void 0&&c.push(t.assignTexture(o,"map",u.baseColorTexture,_t)),o.metalness=u.metallicFactor!==void 0?u.metallicFactor:1,o.roughness=u.roughnessFactor!==void 0?u.roughnessFactor:1,u.metallicRoughnessTexture!==void 0&&(c.push(t.assignTexture(o,"metalnessMap",u.metallicRoughnessTexture)),c.push(t.assignTexture(o,"roughnessMap",u.metallicRoughnessTexture))),a=this._invokeOne(function(h){return h.getMaterialType&&h.getMaterialType(e)}),c.push(Promise.all(this._invokeAll(function(h){return h.extendMaterialParams&&h.extendMaterialParams(e,o)})))}s.doubleSided===!0&&(o.side=Et);const d=s.alphaMode||_l.OPAQUE;if(d===_l.BLEND?(o.transparent=!0,o.depthWrite=!1):(o.transparent=!1,d===_l.MASK&&(o.alphaTest=s.alphaCutoff!==void 0?s.alphaCutoff:.5)),s.normalTexture!==void 0&&a!==Ut&&(c.push(t.assignTexture(o,"normalMap",s.normalTexture)),o.normalScale=new Ce(1,1),s.normalTexture.scale!==void 0)){const u=s.normalTexture.scale;o.normalScale.set(u,u)}if(s.occlusionTexture!==void 0&&a!==Ut&&(c.push(t.assignTexture(o,"aoMap",s.occlusionTexture)),s.occlusionTexture.strength!==void 0&&(o.aoMapIntensity=s.occlusionTexture.strength)),s.emissiveFactor!==void 0&&a!==Ut){const u=s.emissiveFactor;o.emissive=new Ie().setRGB(u[0],u[1],u[2],nn)}return s.emissiveTexture!==void 0&&a!==Ut&&c.push(t.assignTexture(o,"emissiveMap",s.emissiveTexture,_t)),Promise.all(c).then(function(){const u=new a(o);return s.name&&(u.name=s.name),Wn(u,s),t.associations.set(u,{materials:e}),s.extensions&&qi(r,u,s),u})}createUniqueName(e){const t=lt.sanitizeNodeName(e||"");return t in this.nodeNamesUsed?t+"_"+ ++this.nodeNamesUsed[t]:(this.nodeNamesUsed[t]=0,t)}loadGeometries(e){const t=this,n=this.extensions,r=this.primitiveCache;function s(o){return n[Qe.KHR_DRACO_MESH_COMPRESSION].decodePrimitive(o,t).then(function(l){return jd(l,o,t)})}const a=[];for(let o=0,l=e.length;o<l;o++){const c=e[o],d=Pb(c),u=r[d];if(u)a.push(u.promise);else{let h;c.extensions&&c.extensions[Qe.KHR_DRACO_MESH_COMPRESSION]?h=s(c):h=jd(new Lt,c,t),r[d]={primitive:c,promise:h},a.push(h)}}return Promise.all(a)}loadMesh(e){const t=this,n=this.json,r=this.extensions,s=n.meshes[e],a=s.primitives,o=[];for(let l=0,c=a.length;l<c;l++){const d=a[l].material===void 0?Rb(this.cache):this.getDependency("material",a[l].material);o.push(d)}return o.push(t.loadGeometries(a)),Promise.all(o).then(function(l){const c=l.slice(0,l.length-1),d=l[l.length-1],u=[];for(let p=0,g=d.length;p<g;p++){const v=d[p],m=a[p];let f;const y=c[p];if(m.mode===Tn.TRIANGLES||m.mode===Tn.TRIANGLE_STRIP||m.mode===Tn.TRIANGLE_FAN||m.mode===void 0)f=s.isSkinnedMesh===!0?new Gc(v,y):new ht(v,y),f.isSkinnedMesh===!0&&f.normalizeSkinWeights(),m.mode===Tn.TRIANGLE_STRIP?f.geometry=Gd(f.geometry,Jh):m.mode===Tn.TRIANGLE_FAN&&(f.geometry=Gd(f.geometry,pc));else if(m.mode===Tn.LINES)f=new ff(v,y);else if(m.mode===Tn.LINE_STRIP)f=new qc(v,y);else if(m.mode===Tn.LINE_LOOP)f=new tg(v,y);else if(m.mode===Tn.POINTS)f=new Yc(v,y);else throw new Error("THREE.GLTFLoader: Primitive mode unsupported: "+m.mode);Object.keys(f.geometry.morphAttributes).length>0&&Ib(f,s),f.name=t.createUniqueName(s.name||"mesh_"+e),Wn(f,s),m.extensions&&qi(r,f,m),t.assignFinalMaterial(f),u.push(f)}for(let p=0,g=u.length;p<g;p++)t.associations.set(u[p],{meshes:e,primitives:p});if(u.length===1)return s.extensions&&qi(r,u[0],s),u[0];const h=new Ct;s.extensions&&qi(r,h,s),t.associations.set(h,{meshes:e});for(let p=0,g=u.length;p<g;p++)h.add(u[p]);return h})}loadCamera(e){let t;const n=this.json.cameras[e],r=n[n.type];if(!r){console.warn("THREE.GLTFLoader: Missing camera parameters.");return}return n.type==="perspective"?t=new Zt(_e.radToDeg(r.yfov),r.aspectRatio||1,r.znear||1,r.zfar||2e6):n.type==="orthographic"&&(t=new qs(-r.xmag,r.xmag,r.ymag,-r.ymag,r.znear,r.zfar)),n.name&&(t.name=this.createUniqueName(n.name)),Wn(t,n),Promise.resolve(t)}loadSkin(e){const t=this.json.skins[e],n=[];for(let r=0,s=t.joints.length;r<s;r++)n.push(this._loadNodeShallow(t.joints[r]));return t.inverseBindMatrices!==void 0?n.push(this.getDependency("accessor",t.inverseBindMatrices)):n.push(null),Promise.all(n).then(function(r){const s=r.pop(),a=r,o=[],l=[];for(let c=0,d=a.length;c<d;c++){const u=a[c];if(u){o.push(u);const h=new qe;s!==null&&h.fromArray(s.array,c*16),l.push(h)}else console.warn('THREE.GLTFLoader: Joint "%s" could not be found.',t.joints[c])}return new Ws(o,l)})}loadAnimation(e){const t=this.json,n=this,r=t.animations[e],s=r.name?r.name:"animation_"+e,a=[],o=[],l=[],c=[],d=[];for(let u=0,h=r.channels.length;u<h;u++){const p=r.channels[u],g=r.samplers[p.sampler],v=p.target,m=v.node,f=r.parameters!==void 0?r.parameters[g.input]:g.input,y=r.parameters!==void 0?r.parameters[g.output]:g.output;v.node!==void 0&&(a.push(this.getDependency("node",m)),o.push(this.getDependency("accessor",f)),l.push(this.getDependency("accessor",y)),c.push(g),d.push(v))}return Promise.all([Promise.all(a),Promise.all(o),Promise.all(l),Promise.all(c),Promise.all(d)]).then(function(u){const h=u[0],p=u[1],g=u[2],v=u[3],m=u[4],f=[];for(let _=0,x=h.length;_<x;_++){const R=h[_],M=p[_],w=g[_],A=v[_],S=m[_];if(R===void 0)continue;R.updateMatrix&&R.updateMatrix();const b=n._createAnimationTracks(R,M,w,A,S);if(b)for(let T=0;T<b.length;T++)f.push(b[T])}const y=new dg(s,void 0,f);return Wn(y,r),y})}createNodeMesh(e){const t=this.json,n=this,r=t.nodes[e];return r.mesh===void 0?null:n.getDependency("mesh",r.mesh).then(function(s){const a=n._getNodeRef(n.meshCache,r.mesh,s);return r.weights!==void 0&&a.traverse(function(o){if(o.isMesh)for(let l=0,c=r.weights.length;l<c;l++)o.morphTargetInfluences[l]=r.weights[l]}),a})}loadNode(e){const t=this.json,n=this,r=t.nodes[e],s=n._loadNodeShallow(e),a=[],o=r.children||[];for(let c=0,d=o.length;c<d;c++)a.push(n.getDependency("node",o[c]));const l=r.skin===void 0?Promise.resolve(null):n.getDependency("skin",r.skin);return Promise.all([s,Promise.all(a),l]).then(function(c){const d=c[0],u=c[1],h=c[2];h!==null&&d.traverse(function(p){p.isSkinnedMesh&&p.bind(h,Db)});for(let p=0,g=u.length;p<g;p++)d.add(u[p]);return d})}_loadNodeShallow(e){const t=this.json,n=this.extensions,r=this;if(this.nodeCache[e]!==void 0)return this.nodeCache[e];const s=t.nodes[e],a=s.name?r.createUniqueName(s.name):"",o=[],l=r._invokeOne(function(c){return c.createNodeMesh&&c.createNodeMesh(e)});return l&&o.push(l),s.camera!==void 0&&o.push(r.getDependency("camera",s.camera).then(function(c){return r._getNodeRef(r.cameraCache,s.camera,c)})),r._invokeAll(function(c){return c.createNodeAttachment&&c.createNodeAttachment(e)}).forEach(function(c){o.push(c)}),this.nodeCache[e]=Promise.all(o).then(function(c){let d;if(s.isBone===!0?d=new ho:c.length>1?d=new Ct:c.length===1?d=c[0]:d=new Mt,d!==c[0])for(let u=0,h=c.length;u<h;u++)d.add(c[u]);if(s.name&&(d.userData.name=s.name,d.name=a),Wn(d,s),s.extensions&&qi(n,d,s),s.matrix!==void 0){const u=new qe;u.fromArray(s.matrix),d.applyMatrix4(u)}else s.translation!==void 0&&d.position.fromArray(s.translation),s.rotation!==void 0&&d.quaternion.fromArray(s.rotation),s.scale!==void 0&&d.scale.fromArray(s.scale);if(!r.associations.has(d))r.associations.set(d,{});else if(s.mesh!==void 0&&r.meshCache.refs[s.mesh]>1){const u=r.associations.get(d);r.associations.set(d,{...u})}return r.associations.get(d).nodes=e,d}),this.nodeCache[e]}loadScene(e){const t=this.extensions,n=this.json.scenes[e],r=this,s=new Ct;n.name&&(s.name=r.createUniqueName(n.name)),Wn(s,n),n.extensions&&qi(t,s,n);const a=n.nodes||[],o=[];for(let l=0,c=a.length;l<c;l++)o.push(r.getDependency("node",a[l]));return Promise.all(o).then(function(l){for(let d=0,u=l.length;d<u;d++)s.add(l[d]);const c=d=>{const u=new Map;for(const[h,p]of r.associations)(h instanceof Cn||h instanceof Ft)&&u.set(h,p);return d.traverse(h=>{const p=r.associations.get(h);p!=null&&u.set(h,p)}),u};return r.associations=c(s),s})}_createAnimationTracks(e,t,n,r,s){const a=[],o=e.name?e.name:e.uuid,l=[];Si[s.path]===Si.weights?e.traverse(function(h){h.morphTargetInfluences&&l.push(h.name?h.name:h.uuid)}):l.push(o);let c;switch(Si[s.path]){case Si.weights:c=qr;break;case Si.rotation:c=Yr;break;case Si.translation:case Si.scale:c=jr;break;default:switch(n.itemSize){case 1:c=qr;break;case 2:case 3:default:c=jr;break}break}const d=r.interpolation!==void 0?wb[r.interpolation]:Os,u=this._getArrayFromAccessor(n);for(let h=0,p=l.length;h<p;h++){const g=new c(l[h]+"."+Si[s.path],t.array,u,d);r.interpolation==="CUBICSPLINE"&&this._createCubicSplineTrackInterpolant(g),a.push(g)}return a}_getArrayFromAccessor(e){let t=e.array;if(e.normalized){const n=yc(t.constructor),r=new Float32Array(t.length);for(let s=0,a=t.length;s<a;s++)r[s]=t[s]*n;t=r}return t}_createCubicSplineTrackInterpolant(e){e.createInterpolant=function(n){const r=this instanceof Yr?Ab:Pf;return new r(this.times,this.values,this.getValueSize()/3,n)},e.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline=!0}}function Ob(i,e,t){const n=e.attributes,r=new jn;if(n.POSITION!==void 0){const o=t.json.accessors[n.POSITION],l=o.min,c=o.max;if(l!==void 0&&c!==void 0){if(r.set(new U(l[0],l[1],l[2]),new U(c[0],c[1],c[2])),o.normalized){const d=yc(Nr[o.componentType]);r.min.multiplyScalar(d),r.max.multiplyScalar(d)}}else{console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.");return}}else return;const s=e.targets;if(s!==void 0){const o=new U,l=new U;for(let c=0,d=s.length;c<d;c++){const u=s[c];if(u.POSITION!==void 0){const h=t.json.accessors[u.POSITION],p=h.min,g=h.max;if(p!==void 0&&g!==void 0){if(l.setX(Math.max(Math.abs(p[0]),Math.abs(g[0]))),l.setY(Math.max(Math.abs(p[1]),Math.abs(g[1]))),l.setZ(Math.max(Math.abs(p[2]),Math.abs(g[2]))),h.normalized){const v=yc(Nr[h.componentType]);l.multiplyScalar(v)}o.max(l)}else console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.")}}r.expandByVector(o)}i.boundingBox=r;const a=new $n;r.getCenter(a.center),a.radius=r.min.distanceTo(r.max)/2,i.boundingSphere=a}function jd(i,e,t){const n=e.attributes,r=[];function s(a,o){return t.getDependency("accessor",a).then(function(l){i.setAttribute(o,l)})}for(const a in n){const o=xc[a]||a.toLowerCase();o in i.attributes||r.push(s(n[a],o))}if(e.indices!==void 0&&!i.index){const a=t.getDependency("accessor",e.indices).then(function(o){i.setIndex(o)});r.push(a)}return tt.workingColorSpace!==nn&&"COLOR_0"in n&&console.warn(`THREE.GLTFLoader: Converting vertex colors from "srgb-linear" to "${tt.workingColorSpace}" not supported.`),Wn(i,e),Ob(i,e,t),Promise.all(r).then(function(){return e.targets!==void 0?Cb(i,e.targets,t):i})}const Ub="/models/wrad-arms.glb",Fb=["finger_index","finger_middle","finger_ring","finger_pinky","finger_thumb"],Bb=new U(1,0,0),$d=new dt,Kd=new U;function kb(i,{enabled:e=!0,reducedMotion:t=!1}={}){const n={mode:"rig",enabled:!!e,visible:!!e,motionEnabled:!t,loaded:!1,loadError:null,joints:0,fingerJoints:0,drawSurfaces:0,textureCount:0,triangles:0,leftX:0,rightX:0,swayX:0,swayY:0};if(!e)return{state:n,meshes:[],ready:Promise.resolve(!1),update(){},resize(){},beginTravel(){},dispose(){}};const r=new Ct;r.name="Órion · viewmodel rigado de primeira pessoa",i.add(r);const s=[],a=[],o=[],l=[],c={disposed:!1};let d=0,u=0,h=-.4,p=1,g=null,v=null;const m={depth:2.5,wristNdcX:.47,wristNdcY:-.84,pitch:Math.PI};function f(){if(!n.loaded||!v)return;const A=Math.tan(_e.degToRad(i.fov*.5)),S=A*i.aspect,{left:b,right:T}=v,D=Math.abs(T.x-b.x)*.5,k=(T.z+b.z)*.5,z=-k,H=m.wristNdcX*S*m.depth/(D+m.wristNdcX*S*z);p=_e.clamp(H,.06,.45);const L=m.depth-z*p,N=(T.y+b.y)*.5;r.scale.setScalar(p),r.rotation.set(m.pitch,0,0),r.position.set(-(b.x+T.x)*.5*p,m.wristNdcY*A*L+N*p,-2.5),h=r.position.y,n.leftX=-.47*S*L,n.rightX=m.wristNdcX*S*L,n.framing={...m,scale:p,baseY:h,wristDepth:L,halfSpan:D,localWristY:N,localWristZ:k},i.updateMatrixWorld(!0),r.updateMatrixWorld(!0);function B(V){if(!V)return null;const Y=V.getWorldPosition(new U).project(i);return{x:Y.x,y:Y.y,z:Y.z}}n.projectedWristLeft=B(g?.get("wristl")),n.projectedWristRight=B(g?.get("wristr")),n.projectedMiddleLeft=B(g?.get("finger_middle3l")),n.projectedMiddleRight=B(g?.get("finger_middle3r")),n.projectedShoulderLeft=B(g?.get("shoulderl")),n.projectedShoulderRight=B(g?.get("shoulderr"))}function y(A){if(c.disposed){A.scene.traverse(H=>{H.isMesh&&(H.geometry?.dispose?.(),H.material?.dispose?.())});return}const S=A.scene;S.updateMatrixWorld(!0);const b=new jn().setFromObject(S),T=new U,D=new U;if(b.getSize(T),b.getCenter(D),!Number.isFinite(T.x)||T.x<.001)throw new Error("Bounding box inválida no WRAD ARMS");n.modelBounds={width:T.x,centerX:D.x,top:b.max.y};const k=new Map;if(S.traverse(H=>{if(H.isBone&&k.set(H.name,H),!H.isMesh)return;const N=(Array.isArray(H.material)?H.material[0]:H.material)?.map||null;N&&!l.includes(N)&&l.push(N);const B=H.geometry,V=B.getAttribute("position"),Y=new Float32Array(V.count*4);for(let $=0;$<V.count;$++){const re=_e.smoothstep(Math.abs(V.getX($)),3.65,4.87);Y[$*4]=1,Y[$*4+1]=1,Y[$*4+2]=1,Y[$*4+3]=re}B.setAttribute("color",new nt(Y,4));const ee=new Ut({map:N,color:7830173,vertexColors:!0,transparent:!0,opacity:.86,depthTest:!1,depthWrite:!1,toneMapped:!1,side:Et});o.push(ee),H.material=ee,H.layers.set(0),H.renderOrder=30,H.frustumCulled=!1,s.push(H),n.triangles+=(B.index?.count||B.attributes.position?.count||0)/3}),!s.some(H=>H.isSkinnedMesh))throw new Error("WRAD ARMS veio sem malha SkinnedMesh");for(const[H,L]of k){if(!/^finger_(index|middle|ring|pinky|thumb)[123][._]?[lr]$/.test(H))continue;const N=/^finger_([a-z]+)([123])[._]?([lr])$/.exec(H),B=Number(N[2]),V=N[3];a.push({name:H,bone:L,base:L.quaternion.clone(),side:V==="l"?1:-1,segment:B,offset:Fb.indexOf("finger_"+N[1])*.73})}if(a.length<30)throw new Error("Rig incompleto: "+a.length+" falanges de "+k.size+" ossos");g=k,n.joints=k.size,n.fingerJoints=a.length,n.textureCount=l.length,n.drawSurfaces=s.length,S.name="WRAD ARMS CC0 · 50 ossos",r.add(S),r.updateMatrixWorld(!0);const z=H=>{const L=k.get(H);if(!L)throw new Error("Ausência de landmark do punho: "+H);return r.worldToLocal(L.getWorldPosition(new U))};v={left:z("wristl"),right:z("wristr")},n.loaded=!0,f(),r.visible=n.visible}const _=new Promise(A=>{new nu().load(Ub,S=>{try{y(S),A(!0)}catch(b){n.loadError=String(b.message||b),A(!1)}},void 0,S=>{n.loadError=String(S?.message||S),A(!1)})});function x(A,S,b=0,T=0){if(!n.loaded||!n.visible)return;const D=_e.clamp(b,-1,1),k=_e.clamp(T,-1,1),z=n.motionEnabled?1-Math.exp(-Math.min(Math.max(S,0),.06)*7.5):1;d+=(D-d)*z,u+=(k-u)*z,n.swayX=n.motionEnabled?d:0,n.swayY=n.motionEnabled?u:0;const H=Math.tan(_e.degToRad(i.fov*.5))*1.35,L=H*i.aspect,N=n.motionEnabled?Math.sin(A*.72)*.007:0;r.position.x=-(n.modelBounds?.centerX||0)*p-n.swayX*L*.023,r.position.y=h-n.swayY*H*.02+N*H,r.rotation.set(m.pitch+(n.motionEnabled?n.swayY*.012:0),0,n.motionEnabled?n.swayX*.015:0);const B=A*.91;for(const V of a){const ee=(n.motionEnabled?.027*Math.sin(B+V.offset+(V.side>0?.4:1.1))+.012*n.swayY:0)*(V.segment===1?1:V.segment===2?.72:.48)*V.side;Kd.copy(Bb),$d.setFromAxisAngle(Kd,ee),V.bone.quaternion.copy(V.base).multiply($d)}}function R(){f()}function M(){n.visible=!1,r.visible=!1}function w(){c.disposed=!0,i.remove(r);for(const A of s)A.geometry?.dispose?.();for(const A of o)A.dispose();for(const A of l)A.dispose();r.clear()}return{state:n,meshes:s,rigRoot:r,driven:a,ready:_,update:x,resize:R,beginTravel:M,dispose:w}}const zb=["/models/wonderland-left.glb","/models/wonderland-right.glb"],Vb=["left","right"],Hb=/(index|middle|ring|pinky|thumb)[_-]finger[_-]phalanx[_-](proximal|intermediate|distal)/i,Gb={relaxed:{index:.44,middle:.53,ring:.61,pinky:.69,thumb:.26},open:{index:.37,middle:.47,ring:.56,pinky:.63,thumb:.22}},Wb=new URLSearchParams(location.search).get("handPose"),js=Wb==="open"?"open":"relaxed",Xb=Gb[js],Zd=js==="relaxed"?2.11:Math.PI-.36,Jd=js==="relaxed"?.3:.42,Qd=js==="relaxed"?.22:.29,qb=new U(1,0,0),eh=new dt;function Yb(i,{enabled:e=!0,reducedMotion:t=!1}={}){const n={mode:"vr",enabled:!!e,visible:!!e,loaded:!1,loadError:null,motionEnabled:!t,drawSurfaces:0,textureCount:0,joints:0,fingerJoints:0,triangles:0,swayX:0,swayY:0,leftX:0,rightX:0,pose:js};if(!e)return{state:n,meshes:[],ready:Promise.resolve(!1),update(){},resize(){},beginTravel(){},dispose(){}};const r=new Ct;r.name="Órion · mãos anatômicas (viewmodel independente)",i.add(r);const s=Vb.map(w=>{const A=new Ct;return A.name="Órion · "+w,r.add(A),A}),a=[],o=[],l=[],c=[],d=[];let u=!1,h=0,p=0,g=0;function v(w){return new Promise((A,S)=>{new nu().load(w,A,void 0,S)})}function m(w,A){const S=w.scene,b=s[A];S.traverse(T=>{if(T.isBone){o.push(T);const N=T.name.match(Hb);N&&N[2]!=="metacarpal"&&l.push({bone:T,base:T.quaternion.clone(),side:A===0?-1:1,finger:N[1],segment:N[2]==="proximal"?1:N[2]==="intermediate"?2:3,phase:["index","middle","ring","pinky","thumb"].indexOf(N[1])*.64})}if(!T.isMesh)return;const D=T.geometry.clone(),k=D.getAttribute("position"),z=D.getAttribute("normal"),H=new Float32Array(k.count*4);for(let N=0;N<k.count;N++){const B=_e.clamp(.38+.37*z.getZ(N)+.23*z.getY(N),.24,.95),V=k.getY(N),Y=1-_e.smoothstep(V,-.045,.018)*.75,ee=1-_e.smoothstep(V,-.17,-.04);H[N*4]=B*(.74+.13*ee),H[N*4+1]=B*(.65+.07*ee),H[N*4+2]=B*(.95+.04*ee),H[N*4+3]=Y}D.setAttribute("color",new nt(H,4)),d.push(D);const L=new Ut({color:11708107,vertexColors:!0,transparent:!0,opacity:.97,depthTest:!1,depthWrite:!1,toneMapped:!1,side:Et});c.push(L),T.geometry=D,T.material=L,T.layers.set(0),T.renderOrder=30,T.frustumCulled=!1,a.push(T),n.triangles+=(D.index?.count||D.attributes.position.count)/3}),b.add(S)}function f(w){const A=Math.tan(_e.degToRad(i.fov*.5))*Math.abs(w);return{h:A,w:A*i.aspect}}function y(){if(!n.loaded)return;const w=1.38,{h:A,w:S}=f(w),b=A*.45/.1774;for(let T=0;T<2;T++){const D=s[T],k=T===0?-1:1;D.scale.setScalar(b),D.rotation.set(Zd,k*-Jd,k*Qd),D.position.set(k*S*.54,-A*.94,-w)}n.leftX=s[0].position.x,n.rightX=s[1].position.x}const _=Promise.all(zb.map(v)).then(w=>{if(u)return!1;if(w.forEach(m),a.length!==2||o.length<50||l.length<24)throw new Error("GLB anatômico não contém malhas/juntas suficientes");return n.drawSurfaces=a.length,n.joints=o.length,n.fingerJoints=l.length,n.loaded=!0,y(),r.visible=n.visible,!0}).catch(w=>(n.loadError=String(w?.message||w),n.loaded=!1,!1));function x(w,A,S=0,b=0){if(!n.loaded||!n.visible)return;const T=n.motionEnabled?1-Math.exp(-Math.min(.06,Math.max(0,A))*7.5):1;p+=(_e.clamp(S,-1,1)-p)*T,g+=(_e.clamp(b,-1,1)-g)*T,n.swayX=n.motionEnabled?p:0,n.swayY=n.motionEnabled?g:0;const{h:D,w:k}=f(1.38),z=n.motionEnabled?Math.sin(w*.72)*D*.005:0;for(let H=0;H<2;H++){const L=s[H],N=H===0?-1:1;L.position.x=N*k*.54-n.swayX*k*.016,L.position.y=-D*.94-n.swayY*D*.018+z*(H===0?.9:1),L.rotation.set(Zd+(n.motionEnabled?n.swayY*.009:0),N*-Jd,N*Qd+(n.motionEnabled?n.swayX*.014:0))}if(w-h>=0)for(const H of l){const L=n.motionEnabled?.018*Math.sin(w*.7+H.phase+H.side*.3):0,N=(Xb[H.finger]+L)*(H.segment===1?1:H.segment===2?.78:.48);eh.setFromAxisAngle(qb,N),H.bone.quaternion.copy(H.base).multiply(eh)}h=w}function R(){n.visible=!1,r.visible=!1}function M(){u=!0,i.remove(r),d.forEach(w=>w.dispose()),c.forEach(w=>w.dispose()),r.clear()}return{state:n,meshes:a,bones:o,driven:l,groups:s,root:r,ready:_,update:x,resize:y,beginTravel:R,dispose:M}}const jb="/models/david-fischer-fps-hands.glb",$b=/^(?:f_)?(index|middle|ring|pinky)(?:\.|_)?0?([123])(?:\.|_)?([lr])/i,Kb=/^thumb(?:\.|_)?0?([123])(?:\.|_)?([lr])/i,Zb=new U,th=new dt,Jb=new U(1,0,0),Qb=new U(0,0,1),nh=new dt,ks=new URLSearchParams(window.location.search),eS=ks.get("fpsPose")==="open"?"open":"relaxed",La=ks.get("fpsLight")==="basic"?"basic":"lit",Vt=["original","calm","cinematic","natural","frame"].includes(ks.get("fpsStyle"))?ks.get("fpsStyle"):"frame",Ai={original:{wristY:-.84,fadeFrom:.615,fadeTo:.725,wristBend:0,wristRoll:0,opacity:.94,fadeInvert:!1},calm:{wristY:-.88,fadeFrom:.735,fadeTo:.865,wristBend:-.43,wristRoll:-.16,opacity:.96,fadeInvert:!0},cinematic:{wristY:-.84,fadeFrom:.73,fadeTo:.87,wristBend:-.55,wristRoll:-.35,opacity:.98,fadeInvert:!0},natural:{wristY:-.85,fadeFrom:.72,fadeTo:.88,wristBend:0,wristRoll:0,opacity:.96,fadeInvert:!0},frame:{wristY:-.89,fadeFrom:.7,fadeTo:.89,wristBend:0,wristRoll:0,opacity:1,fadeInvert:!0,scaleFactor:1.74}}[Vt],bc=ks.get("fpsTune")||"base",ih={base:Vt==="frame"?{bend:.36,yaw:.46,roll:-.4}:Vt==="natural"?{bend:1,yaw:.36,roll:-.38}:{bend:Ai.wristBend,yaw:0,roll:Ai.wristRoll},forward:{bend:-1.12,yaw:.26,roll:-.25},reach:{bend:-1.47,yaw:.4,roll:-.18},inward:{bend:-1.04,yaw:.62,roll:-.48},back:{bend:.7,yaw:.3,roll:-.3},rest1:{bend:1,yaw:.36,roll:-.38},rest2:{bend:1.24,yaw:.38,roll:-.4},rest3:{bend:.86,yaw:.48,roll:-.48},frameA:{bend:.76,yaw:.47,roll:-.43},frameB:{bend:.6,yaw:.56,roll:-.5},frameC:{bend:.94,yaw:.39,roll:-.35},frameD:{bend:.36,yaw:.46,roll:-.4}},yl=ih[bc]||ih.base,tS=new U(1,0,0),nS=new U(0,1,0),iS=new U(0,0,1),rh=new dt,sh=new dt,ah=new dt;function rS(i){return String(i||"").toLowerCase().replace(/[^a-z0-9]/g,"")}function oh(i,e){const t=Math.tan(_e.degToRad(i.fov*.5))*e;return{h:t,w:t*i.aspect}}function sS(i,{enabled:e=!0,reducedMotion:t=!1}={}){const n={mode:"fps",enabled:!!e,visible:!!e,loaded:!1,motionEnabled:!t,loadError:null,pose:eS,joints:0,fingerJoints:0,triangles:0,textureCount:0,drawSurfaces:0,swayX:0,swayY:0,leftX:0,rightX:0,framing:null,artStyle:Vt,lightMode:La,tune:bc,referencePose:Vt==="frame"?"arcane-frame":null};if(!e)return{state:n,meshes:[],driven:[],ready:Promise.resolve(!1),update(){},resize(){},beginTravel(){},dispose(){}};const r=new Ct;r.name="Órion · mãos FPS de David Fischer, viewmodel local",i.add(r);const s=[];if(La==="lit"){const L=new _g(15524607,6772868,1.85),N=new yf(16774399,1.22);N.position.set(-.7,1.6,2.3),N.target.position.set(0,0,-2),i.add(L,N,N.target),s.push(L,N,N.target)}const a=[],o=[],l=[],c=[],d=[],u={wristL:null,wristR:null,tipL:null,tipR:null},h=[];let p=!1,g=new U,v=1,m=0;const f={left:0,right:0},y={left:0,right:0};let _=0,x=0;const R=2.05,M={open:.07,relaxed:.17},w={index:[.055,.045,.025],middle:[.22,.32,.24],ring:[.33,.43,.31],pinky:[.42,.48,.37],thumb:[.035,.045,.015]};function A(L=0){rh.setFromAxisAngle(tS,yl.bend);for(const N of h)sh.setFromAxisAngle(nS,yl.yaw*N.side),ah.setFromAxisAngle(iS,yl.roll*N.side),N.bone.quaternion.copy(N.aimed||N.base),N.aimed||N.bone.quaternion.multiply(rh).multiply(sh).multiply(ah);for(let N=0;N<c.length;N++){const B=c[N],V=n.motionEnabled?Math.sin(L*.7+N*.79)*.012:0,Y=Vt==="frame"?w[B.digit][B.segment-1]+V*.35:(M[n.pose]+V)*(B.segment===1?.52:B.segment===2?.71:.36)*(B.digit==="thumb"?.45:1);th.setFromAxisAngle(Jb,Y),B.bone.quaternion.copy(B.base).multiply(th),Vt==="frame"&&B.digit==="thumb"&&B.segment===1&&(nh.setFromAxisAngle(Qb,.12*B.side),B.bone.quaternion.multiply(nh))}}function S(){if(Vt!=="natural"||bc!=="base")return;i.updateMatrixWorld(!0),r.updateMatrixWorld(!0);const L=O=>O.getWorldPosition(new U).project(i),N=L(u.wristL),B=L(u.wristR),V=L(u.tipL),Y=L(u.tipR);if(V.x-N.x>.09&&V.x-N.x<.23&&B.x-Y.x>.09&&B.x-Y.x<.23&&V.y-N.y>.25&&V.y-N.y<.42&&Y.y-B.y>.25&&Y.y-B.y<.42)return;const ee=i.getWorldQuaternion(new dt),$=new U(0,0,1).applyQuaternion(ee),re=new U(1,0,0).applyQuaternion(ee),te=[0,-.34,.34,-.5,.5,-.65,.65,-.8,.8],F=[0,-.14,.14,-.26,.26,-.38,.38,-.46,.46];for(const O of h){const G=O.side===-1?u.tipL:u.tipR;if(!G)continue;const ne=O.bone.parent.getWorldQuaternion(new dt).invert(),xe=$.clone().applyQuaternion(ne).normalize(),fe=re.clone().applyQuaternion(ne).normalize(),we=O.bone.quaternion.clone(),me=O.side===-1?.115:-.115,P=O.side===-1?.26:.245;let Le={score:1/0,pitch:0,roll:0,quaternion:we.clone()};for(const ge of te){const ae=new dt().setFromAxisAngle(fe,ge);for(const ze of F){const oe=new dt().setFromAxisAngle(xe,ze);O.bone.quaternion.copy(we).premultiply(ae).premultiply(oe),r.updateMatrixWorld(!0);const Se=O.bone.getWorldPosition(new U),Ye=G.getWorldPosition(new U),De=Se.clone().project(i),I=Ye.clone().project(i),E=i.worldToLocal(Ye).z-i.worldToLocal(Se).z,j=I.x-De.x,Q=I.y-De.y,ie=Math.abs(j-me)*1.4+Math.abs(Q-P)*.8+Math.abs(E+.38)*.32+Math.abs(ge)*.022+Math.abs(ze)*.027+(Q<.13?.8:0)+(Q>.39?.15:0)+(I.x*O.side<0?.35:0);ie<Le.score&&(Le={score:ie,pitch:ge,roll:ze,quaternion:O.bone.quaternion.clone()})}}O.aimed=Le.quaternion,O.bone.quaternion.copy(Le.quaternion);const Te=O.side===-1?"left":"right";f[Te]=Le.roll,y[Te]=Le.pitch,r.updateMatrixWorld(!0)}}function b(){if(!n.loaded||!u.wristL||!u.wristR)return;for(const G of h)G.aimed=null;A(0),r.position.set(0,0,0),r.scale.setScalar(1),r.rotation.set(0,0,0),r.updateMatrixWorld(!0);const L=G=>r.worldToLocal(G.getWorldPosition(new U)),N=L(u.wristL),B=L(u.wristR),V=u.tipL?L(u.tipL):N.clone().add(new U(0,.1,0)),Y=u.tipR?L(u.tipR):B.clone().add(new U(0,.1,0));N.clone().add(B).multiplyScalar(.5);const ee=[-.35,.18,.45,Math.PI-.35,Math.PI+.18,Math.PI+.45];let $=null;const{h:re,w:te}=oh(i,R);for(const G of ee){const ne=new xn(G,0,0),xe=N.clone().applyEuler(ne),fe=B.clone().applyEuler(ne),we=V.clone().applyEuler(ne),me=Y.clone().applyEuler(ne),P=Math.abs(fe.x-xe.x);if(P<.005)continue;const Le=_e.clamp(te*.54/(P*.5),.003,6.5),Te=(we.y-xe.y+(me.y-fe.y))*.5*Le/re,ge=Math.abs(Te-.32)+(Te<=.05?3:0)+(Te>.72?2:0)+Math.abs(we.y-xe.y-(me.y-fe.y))*Le/re*.25;(!$||ge<$.score)&&($={pitch:G,score:ge,s:Le,l:xe,r:fe,tl:we,tr:me,rise:Te})}if(!$)throw new Error("Não foi possível calibrar o rig FPS por punhos");m=$.pitch,v=$.s*(Ai.scaleFactor||1);const F=$.l.clone().add($.r).multiplyScalar(.5);r.rotation.set(m,0,0),r.scale.set(-v,v,v),g.set(F.x*v,re*Ai.wristY-F.y*v,-R-F.z*v),r.position.copy(g),r.updateMatrixWorld(!0),i.updateMatrixWorld(!0),S(),r.updateMatrixWorld(!0);const O=G=>{if(!G)return null;const ne=G.getWorldPosition(Zb.clone()).project(i);return{x:ne.x,y:ne.y,z:ne.z}};n.framing={pitch:m,scale:v,rawRise:$.rise,aimAngles:{...f},depthAngles:{...y},posedLandmarks:!0,wristLeft:O(u.wristL),wristRight:O(u.wristR),tipLeft:O(u.tipL),tipRight:O(u.tipR)},n.leftX=n.framing.wristLeft?.x||0,n.rightX=n.framing.wristRight?.x||0}const T=new Promise(L=>{new nu().load(jb,N=>{try{if(p){L(!1);return}const B=N.scene;if(B.updateMatrixWorld(!0),B.traverse(V=>{if(V.isBone&&d.push(V),!V.isSkinnedMesh)return;const Y=V.geometry;if(Y.getAttribute("position")?.count<1e3){V.visible=!1;return}const ee=Y.clone(),$=ee.getAttribute("normal"),re=ee.getAttribute("position"),te=new Float32Array(re.count*4);for(let G=0;G<re.count;G++){const ne=re.getY(G),xe=$?.getZ(G)??0,fe=$?.getY(G)??0,we=Vt==="frame"?_e.clamp(.51+.13*xe+.1*fe,.34,.8):_e.clamp(.66+.2*xe+.12*fe,.45,.95),me=_e.smoothstep(ne,Ai.fadeFrom,Ai.fadeTo),P=Ai.fadeInvert?1-me:me;te[G*4]=we*(Vt==="frame"?.69:.94),te[G*4+1]=we*(Vt==="frame"?.72:.84),te[G*4+2]=we*(Vt==="frame"?.97:1.05),te[G*4+3]=P}ee.setAttribute("color",new nt(te,4)),l.push(ee);const F=La==="lit"?ng:Ut,O=new F({color:Vt==="frame"?8418710:La==="lit"?13681889:12235468,vertexColors:!0,transparent:!0,opacity:Ai.opacity,side:Et,depthTest:!1,depthWrite:!1,toneMapped:!1});O.onBeforeCompile=G=>{G.vertexShader=`varying float vOrionFpsClipY;
`+(Vt==="frame"?`varying float vOrionFpsRim;
`:"")+G.vertexShader,G.vertexShader=G.vertexShader.replace("#include <project_vertex>",`#include <project_vertex>
vOrionFpsClipY = gl_Position.y / gl_Position.w;`+(Vt==="frame"?`
vOrionFpsRim = 1.0 - abs(dot(normalize(transformedNormal), normalize(-mvPosition.xyz)));`:"")),G.fragmentShader=`varying float vOrionFpsClipY;
`+(Vt==="frame"?`varying float vOrionFpsRim;
`:"")+G.fragmentShader,G.fragmentShader=G.fragmentShader.replace("#include <opaque_fragment>",`#include <opaque_fragment>
gl_FragColor.a *= smoothstep(-1.08, -0.74, vOrionFpsClipY);`+(Vt==="frame"?`
float orionRim = pow(clamp(vOrionFpsRim, 0.0, 1.0), 1.25);
gl_FragColor.rgb = gl_FragColor.rgb * 0.13 + vec3(0.82,0.83,1.0) * orionRim * 1.23;`:""))},O.customProgramCacheKey=()=>Vt==="frame"?"orion-fps-arcane-frame-v3":"orion-fps-screen-feather-v1",o.push(O),V.geometry=ee,V.material=O,V.frustumCulled=!1,V.renderOrder=35,V.layers.set(0),a.push(V),n.triangles+=(ee.index?.count||re.count)/3}),a.length===0)throw new Error("Modelo de David sem SkinnedMesh principal");for(const V of d){const Y=rS(V.name);/^handl/.test(Y)&&(u.wristL=V),/^handr/.test(Y)&&(u.wristR=V),/^fmiddle03l/.test(Y)&&(u.tipL=V),/^fmiddle03r/.test(Y)&&(u.tipR=V);const ee=String(V.name||""),$=ee.match($b),re=ee.match(Kb);!$&&!re||c.push({bone:V,base:V.quaternion.clone(),digit:re?"thumb":$[1].toLowerCase(),segment:Number(re?re[1]:$[2]),side:(re?re[2]:$[3]).toLowerCase()==="l"?1:-1})}if(!u.wristL||!u.wristR)throw new Error("Mãos importadas sem ossos dos punhos");if(h.push({bone:u.wristL,side:-1,base:u.wristL.quaternion.clone()}),h.push({bone:u.wristR,side:1,base:u.wristR.quaternion.clone()}),c.length<25)throw new Error("Rig importado não fornece falanges suficientes: "+c.length);r.add(B),n.joints=d.length,n.fingerJoints=c.length,n.drawSurfaces=a.length,n.textureCount=0,n.loaded=!0,b(),r.visible=n.visible,L(!0)}catch(B){n.loaded=!1,n.loadError=String(B.message||B),L(!1)}},void 0,N=>{n.loadError=String(N?.message||N),L(!1)})});function D(L,N,B=0,V=0){if(!n.loaded||!n.visible)return;const Y=n.motionEnabled?1-Math.exp(-Math.min(Math.max(N,0),.06)*7.5):1;_+=(_e.clamp(B,-1,1)-_)*Y,x+=(_e.clamp(V,-1,1)-x)*Y,n.swayX=n.motionEnabled?_:0,n.swayY=n.motionEnabled?x:0;const{h:ee,w:$}=oh(i,R),re=n.motionEnabled?Math.sin(L*.67)*ee*.005:0;r.position.set(g.x-n.swayX*$*.018,g.y-n.swayY*ee*.016+re,g.z),r.rotation.set(m+(n.motionEnabled?n.swayY*.008:0),0,n.motionEnabled?n.swayX*.012:0),A(L)}function k(){b()}function z(){n.visible=!1,r.visible=!1}function H(){p=!0,i.remove(r),s.forEach(L=>i.remove(L)),l.forEach(L=>L.dispose()),o.forEach(L=>L.dispose()),r.clear()}return{state:n,root:r,meshes:a,driven:c,ready:T,update:D,resize:k,beginTravel:z,dispose:H}}const lh="/overlay/orion-hands-frame.webp";function aS(i,{enabled:e=!0,reducedMotion:t=!1}={}){const n={enabled:!!e,visible:!!e,loaded:!1,mode:"overlay",motionEnabled:!t,loadError:null,drawSurfaces:0,triangles:0,textureCount:0,joints:0,fingerJoints:0,swayX:0,swayY:0,elementCount:0};if(!e)return{state:n,meshes:[],ready:Promise.resolve(!1),update(){},resize(){},beginTravel(){},dispose(){}};const r=document.createElement("div");r.id="orionEtherealHands",r.className="orion-ethereal-hands",r.setAttribute("aria-hidden","true");const s=[];for(const v of["left","right"]){const m=document.createElement("div");m.className="orion-ethereal-hand orion-ethereal-hand--"+v,m.dataset.side=v;const f=document.createElement("img");f.src=lh,f.alt="",f.decoding="async",f.loading="eager",f.draggable=!1,m.appendChild(f),r.appendChild(m),s.push(m)}i.appendChild(r),n.elementCount=2;let a=!1,o=0,l=0;const c=new Image;c.decoding="async";const d=new Promise(v=>{c.onload=()=>{if(a)return v(!1);n.loaded=!0,n.textureCount=1,r.classList.add("is-ready"),v(!0)},c.onerror=()=>{if(a)return v(!1);n.loadError="Falha ao carregar mãos etéreas locais",r.remove(),v(!1)},c.src=lh,c.complete&&c.naturalWidth>0&&c.onload()});function u(v,m,f=0,y=0){if(a||!n.visible||!n.loaded)return;const _=Math.min(Math.max(m,0),.06),x=n.motionEnabled?1-Math.exp(-_*6.2):1;o+=(Math.max(-1,Math.min(1,f))-o)*x,l+=(Math.max(-1,Math.min(1,y))-l)*x,n.swayX=n.motionEnabled?o:0,n.swayY=n.motionEnabled?l:0;const R=n.motionEnabled?Math.sin(v*.92)*2:0;for(let M=0;M<s.length;M++){const w=M===0?1:-1,A=n.swayX*(M===0?-5.5:-5.2)+w*.6*Math.sin(v*.37),S=n.swayY*-3.8+(M===0?R:R*.85),b=n.motionEnabled?n.swayX*(M===0?-.23:.23):0,T=n.motionEnabled?A:0,D=n.motionEnabled?S:0;s[M].style.transform="translate3d("+T.toFixed(2)+"px,"+D.toFixed(2)+"px,0) rotate("+b.toFixed(3)+"deg)"}}function h(){n.visible&&(n.visible=!1,r.classList.add("is-leaving"))}function p(){}function g(){a=!0,n.visible=!1,c.onload=null,c.onerror=null,r.remove()}return{state:n,meshes:[],ready:d,update:u,resize:p,beginTravel:h,dispose:g,layer:r}}function oS(){const i=new Ce(1,1);function e(t){return t.onBeforeCompile=n=>{n.uniforms.uHandViewport={value:i},n.fragmentShader=`uniform vec2 uHandViewport;
`+n.fragmentShader,n.fragmentShader=n.fragmentShader.replace("#include <alphatest_fragment>",`vec2 handScreen=gl_FragCoord.xy/max(uHandViewport,vec2(1.));
    float handEdge=min(min(handScreen.x,1.-handScreen.x),min(handScreen.y,1.-handScreen.y));
    float handPresence=1.-smoothstep(.02,.32,handEdge);
    diffuseColor.a*=mix(1.,2.5,handPresence);
    #include <alphatest_fragment>`)},t.customProgramCacheKey=()=>"orion-hand-edge-v24",t.userData.edgeOpacity=!0,t}return{material:e,bind(t){t.onBeforeRender=n=>n.getDrawingBufferSize(i)}}}const lS=32,cS=24,Sc=Object.freeze({left:Object.freeze({id:"left-framing",limit:.009,index:{x:.58,y:.73,px:.48,py:.48,rx:.25,ry:.31},thumb:{x:.72,y:.44,px:.55,py:.37,rx:.24,ry:.2},indexAmplitude:.027,thumbAmplitude:.018,phase:.38}),right:Object.freeze({id:"right-pointing",limit:.012,index:{x:.27,y:.79,px:.43,py:.63,rx:.25,ry:.24},thumb:{x:.28,y:.52,px:.45,py:.43,rx:.22,ry:.18},indexAmplitude:.046,thumbAmplitude:.026,phase:1.16})}),Da=(i,e,t)=>Math.max(e,Math.min(t,i));function ch(i,e,t){const n=(i-t.x)/t.rx,r=(e-t.y)/t.ry;return Math.exp(-2.3*(n*n+r*r))}function uh(i,e,t,n){const r=i-t.px,s=e-t.py,a=Math.sin(n),o=Math.cos(n);return[r*o-s*a-r,r*a+s*o-s]}function uS(i,e,t,n,r,s=0,a=0,o=!1){if(!Sc[n])throw new Error("Lado da mão não reconhecido");if(i.length!==e.length||i.length/3*2!==t.length)throw new Error("Geometria de mãos incompatível");if(o)return e.set(i),0;const l=Sc[n],c=Da(s,-1,1),d=Da(a,-1,1),u=l.indexAmplitude*Math.sin(r*.83+l.phase)+c*.012,h=l.thumbAmplitude*Math.sin(r*.65+l.phase+1.4)-d*.008;let p=0;for(let g=0,v=i.length/3;g<v;g++){const m=g*3,f=g*2,y=t[f],_=t[f+1],x=ch(y,_,l.index),R=ch(y,_,l.thumb),[M,w]=uh(y,_,l.index,u),[A,S]=uh(y,_,l.thumb,h),b=Da(M*x+A*R,-l.limit,l.limit),T=Da(w*x+S*R,-l.limit,l.limit);e[m]=i[m]+b,e[m+1]=i[m+1]+T,e[m+2]=i[m+2],p=Math.max(p,Math.abs(b),Math.abs(T))}return p}const Lf=.14,dS=.6,Df=.5,on=[100,150,180,220,270,320,370,420,480,530],hS=[[500,519],[465,534],[450,522],[425,504],[401,485],[390,475],[416,510],[439,550],[477,590],[501,620]],fS=[[335,354],[333,402],[344,416],[358,437],[379,463],[399,484],[416,510],[439,550],[477,590],[501,620]],Nf=[0,.25,.5,.75,1].map(i=>hS.map((e,t)=>e.map((n,r)=>n+(fS[t][r]-n)*i)));function pS(i){const e=i.slice(1).map((t,n)=>(t-i[n])/(on[n+1]-on[n]));return i.map((t,n)=>{if(n===0||n===i.length-1||e[n-1]*e[n]<=0)return 0;const r=on[n]-on[n-1],s=on[n+1]-on[n],a=2*s+r,o=s+2*r;return(a+o)/(a/e[n-1]+o/e[n])})}const Mc=Nf.map(i=>[0,1].map(e=>pS(i.map(t=>t[e]))));for(const i of Mc)for(let e=0;e<2;e++)i[e][on.indexOf(370)]=Mc[4][e][on.indexOf(370)];function dh(i,e){let t=0;for(;t<on.length-2&&e>on[t+1]/1122;)t++;const n=on[t+1]-on[t],r=Math.max(0,Math.min(1,(e*1122-on[t])/n)),s=r*r,a=s*r,o=Nf[i],l=Mc[i],c=[0,1].map(d=>(2*a-3*s+1)*o[t][d]+(a-2*s+r)*n*l[d][t]+(-2*a+3*s)*o[t+1][d]+(a-s)*n*l[d][t+1]);return[1-c[1]/1402,1-c[0]/1402]}function mS(i,e,t,n){if(t>on.at(-1)/1122||n<=.54||i===e)return n;const[r,s]=dh(i,t),[a,o]=dh(e,t),l=Math.max(.54,Math.min(r,a)-Math.max(.005,Math.abs(a-r)*.65));return n<=l?n:n<r?l+(a-l)*(n-l)/(r-l):n<s?a+(o-a)*(n-r)/(s-r):n+o-s}function Of(i){const e=Math.max(0,Math.min(1,i)),t=e*4,n=Math.min(3,Math.floor(t)),r=t-n,s=r*r*(3-2*r),a=[0,0,0,0,0];return a[n]=1-s,a[n+1]=s,a}const Or={left:{wrist:[.23,.17],palm:[.47,.44],index:[.49,.62],indexDistal:[.63,.74],indexTip:[.75,.8],thumb:[.54,.36],thumbDistal:[.73,.37],thumbTip:[.9,.38],middle:[.52,.6],middleTip:[.76,.61],ring:[.5,.54],ringTip:[.7,.49],little:[.47,.49],littleTip:[.64,.44],phase:.4},pointing:{wrist:[.8,.2],palm:[.59,.44],index:[.45,.63],indexDistal:[.32,.74],indexTip:[.17,.8],thumb:[.49,.39],thumbDistal:[.35,.43],thumbTip:[.23,.45],middle:[.48,.59],middleTip:[.24,.5],ring:[.52,.55],ringTip:[.34,.47],little:[.57,.52],littleTip:[.43,.47],phase:1.2},neutral:{wrist:[.8,.2],palm:[.59,.44],index:[.45,.63],indexDistal:[.29,.71],indexTip:[.15,.65],thumb:[.49,.39],thumbDistal:[.35,.43],thumbTip:[.23,.45],middle:[.48,.59],middleTip:[.2,.5],ring:[.52,.55],ringTip:[.29,.46],little:[.57,.52],littleTip:[.38,.46],phase:1.2}};Or.perspective={...Or.neutral,indexDistal:[.28,.72],indexTip:[.1,.75]};const Ss=[["wrist",null,.014,.7],["palm","wrist",.009,.81],["index","palm",.03,1.03],["indexDistal","index",.039,1.12],["thumb","palm",.024,.85],["thumbDistal","thumb",.03,.93],["middle","palm",.021,.96],["ring","palm",.018,.89],["little","palm",.015,.83]],bl=["wrist","palm","indexTip","thumbTip","middleTip","ringTip","littleTip"];for(const[i,e]of[["reach025",.25],["reach050",.5],["reach075",.75]])Or[i]=Object.fromEntries(Object.entries(Or.neutral).map(([t,n])=>[t,Array.isArray(n)?n.map((r,s)=>_e.lerp(r,Or.pointing[t][s],e)):n]));const Na=[[150,503,490,314,291],[180,522,461,359,279],[220,518,427,391,300],[270,489,402,420,330],[320,478,389,446,358],[370,495,380,486,381],[420,525,401,525,404],[480,550,455,550,458],[530,565,493,565,496]].map(([i,e,t,n,r])=>[i/1122,1-e/1402,1-t/1402,1-n/1402,1-r/1402]);function gS(i,e,t){if(i>Na.at(-1)[0])return e;let n=Na[0],r=n;for(let h=1;h<Na.length&&(r=Na[h],!(i<=r[0]));h++)n=r;const s=n===r?0:_e.clamp((i-n[0])/(r[0]-n[0]),0,1),a=n.map((h,p)=>_e.lerp(h,r[p],s)),o=a[t?3:1],l=a[t?4:2],c=a[t?1:3],d=a[t?2:4],u=.54;return e<=u?e:e<o?_e.lerp(u,c,(e-u)/(o-u)):e<l?_e.lerp(c,d,(e-o)/(l-o)):e+d-l}function hh(i,e,t,n,r){const s=n[0]-t[0],a=n[1]-t[1],o=s*s+a*a,l=_e.clamp(((i-t[0])*s+(e-t[1])*a)/o,0,1),c=((i-t[0]-l*s)**2+(e-t[1]-l*a)**2)/(r*r);return Math.exp(-2.5*c)}function fh(i,e,t,{perspective:n=!1}={}){const r=Or[t];if(!r)throw new Error("Pose de rig de mãos desconhecida");const s=[],a={};for(const[m,f]of Ss){const y=new ho,_=r[m];y.name="MMV_"+t+"_"+m;const x=f?r[f]:[.5,.5];y.position.set(_[0]-x[0],_[1]-x[1],0),f&&a[f].add(y),s.push(y),a[m]=y}const o=i.getAttribute("uv"),l=new Uint16Array(o.count*4),c=new Float32Array(o.count*4),d=Object.fromEntries(bl.map(m=>[m,{index:0,distance:1/0}]));for(let m=0;m<o.count;m++){const f=o.getX(m),y=o.getY(m),_=1-_e.smoothstep(y,.18,.46),x=[{index:0,weight:.04+_*4},{index:1,weight:.15+hh(f,y,r.wrist,r.palm,.24)}];for(let M=2;M<Ss.length;M++){const[w]=Ss[M],A=r[w+"Tip"]||r.indexTip,S=r[w],b=w.endsWith("Distal")?r[w.replace("Distal","")+"Tip"]:r[w+"Distal"]||A,T=w.startsWith("index")?.14:w.startsWith("thumb")?.08:.065;x.push({index:M,weight:hh(f,y,S,b,T)*(1-_)*3})}x.sort((M,w)=>w.weight-M.weight);const R=x.slice(0,4).reduce((M,w)=>M+w.weight,0);for(let M=0;M<4;M++)l[m*4+M]=x[M].index,c[m*4+M]=x[M].weight/R;for(const M of bl){const w=r[M],A=(f-w[0])**2+(y-w[1])**2;A<d[M].distance&&(d[M]={index:m,distance:A})}}if(t!=="left"){const m=i.getAttribute("position"),f=[];if(n)for(let _=0;_<4;_++){const x=new Float32Array(m.array);for(let R=0;R<o.count;R++){const M=o.getX(R),w=o.getY(R);x[R*3+1]+=mS(4,_,M,w)-w}f.push(new nt(x,3))}const y=new Float32Array(m.array);for(let _=0;_<o.count;_++)n?y[_*3+2]=-Lf*_e.smoothstep(o.getY(_),.2,.72)*_e.smoothstep(o.getX(_),0,.15):y[_*3+1]=gS(o.getX(_),o.getY(_),t==="pointing")-.5;f.push(new nt(y,3)),i.morphAttributes.position=f}i.setAttribute("skinIndex",new co(l,4)),i.setAttribute("skinWeight",new nt(c,4));const u=new Gc(i,e);u.add(s[0]),u.bind(new Ws(s)),u.frustumCulled=!1;let h=!1;function p(m,f=!1,y=t==="pointing"?1:0,_=0,x=null){if(h)return;const R=n?_e.smoothstep(y,0,1):0;for(let M=0;M<Ss.length;M++){const[,,w,A]=Ss[M];if(f){s[M].rotation.z=0;continue}const S=Math.sin(m*A+r.phase+M*.43),b=R>0?_e.lerp(S,Math.sin(m*A*.57+r.phase+M*.61),.16*R):S,T=(M>=2?1-.18*R:1)*(x?1-(M>=2?.55:.25)*x.selectionPress:1);s[M].rotation.z=b*w*T}if(t==="left"&&!f){const M=_e.clamp(_,0,1);a.wrist.rotation.z+=.012*M,a.palm.rotation.z-=.006*M,a.index.rotation.z-=.17*M,a.indexDistal.rotation.z-=.13*M,a.middle.rotation.z-=.15*M,a.ring.rotation.z-=.12*M,a.little.rotation.z-=.09*M,a.thumb.rotation.z+=.09*M,a.thumbDistal.rotation.z+=.06*M}if(t!=="left"&&x&&!f){const M=x.selectionPress,w=x.selectionReach;a.wrist.rotation.z+=.008*w-.01*M,a.palm.rotation.z-=.012*M,a.thumb.rotation.z-=.025*M,a.thumbDistal.rotation.z-=.018*M,a.middle.rotation.z+=.02*M,a.ring.rotation.z+=.015*M,a.little.rotation.z+=.01*M}if(t!=="left"){const M=_e.clamp(y,0,1);if(n){const w=Of(M);for(let A=0;A<4;A++)u.morphTargetInfluences[A]=w[A];u.morphTargetInfluences[4]=f?0:M*Df}else u.morphTargetInfluences[0]=f?0:t==="neutral"?M:1-M}}function g(){u.parent?.updateWorldMatrix(!0,!1),u.updateMatrixWorld(!0);const m=i.getAttribute("position"),f=new U,y=new U;let _=0;for(let R=0;R<m.count;R++)f.fromBufferAttribute(m,R),u.getVertexPosition(R,y),_=Math.max(_,y.distanceTo(f));const x={};for(const R of bl){const M=d[R].index;x[R]=u.getVertexPosition(M,new U).applyMatrix4(u.matrixWorld)}return{pose:t,maxVertexDelta:_,landmarks:x,boneCount:s.length,boneTextureBytes:u.skeleton.boneTexture?.image?.data?.byteLength||0}}function v(){h||(h=!0,u.skeleton.dispose())}return{pose:t,mesh:u,bones:s,update:p,measure:g,dispose:v}}const ph=Object.freeze({baseOpacity:.38,height:.565,edgeInset:-.03,bottom:-.02}),Mi=Object.freeze({left:{...ph,edgeInset:-.042,rotation:-.2,file:"/overlay/left-hand-ethereal.webp",swayX:-.006,swayY:-.005,breath:.003,phase:.45,pointer:!1,columns:lS,rows:cS},right:{...ph,rotation:0,file:"/overlay/right-hand-pointing.webp",neutralFile:"/overlay/right-hand-neutral.webp",swayX:-.006,swayY:-.005,breath:.003,phase:1.15,pointer:!0,columns:36,rows:28}}),sn=(i,e,t)=>Math.max(e,Math.min(t,i));function vS(i,{enabled:e=!0,reducedMotion:t=!1,animation:n="mesh",touchLayout:r=!1}={}){const s=n==="perspective",a=n==="rig"||s,o={mode:"mesh",enabled:!!e,visible:!1,loaded:!1,loadError:null,motionEnabled:!t,drawSurfaces:0,triangles:0,textureCount:0,joints:0,fingerJoints:0,swayX:0,swayY:0,maxVertexDelta:0,pose:"feminine-star-hover",handProfiles:Object.keys(Sc),rightHover:!1,rightBlend:0,hoverBlend:0,leftFollow:0,animation:s?"perspective":a?"rig":"mesh",rightFrameWeights:[],rightDepth:0,selecting:!1,selectionReach:0,selectionPress:0,selectionAnticipation:0,selectionFollowThrough:0,selectionLift:0,touchLayout:r,targetDirectionX:0,targetDirectionY:.18},l=new Ct;l.name="OrionFeminineHands2p5D",l.visible=!1,i.add(l);const c=[],d=[],u=[],h=[],p=oS();a&&Object.defineProperty(o,"maxVertexDelta",{enumerable:!0,get:()=>Math.max(0,...u.map(te=>te.measure().maxVertexDelta))});let g=null,v=!1,m=0,f=0;if(!e)return{state:o,root:l,meshes:c,rigs:u,rightFrames:h,ready:Promise.resolve(!1),update(){},resize(){},setStarHovered(){},setStarDirection(){},setStarSelection(){},beginTravel(){},dispose(){i.remove(l)}};let y=!1,_=!1,x=!1,R=0,M=1,w=0,A=0;const S=[],b=new rs,T=te=>new Promise((F,O)=>b.load(te,F,void 0,O));let D=!1;function k(){const F=2*Math.tan(_e.degToRad(i.fov*.5))*2.5;return{depth:2.5,height:F,width:F*i.aspect}}function z(te,F=0,O=0){const G=k(),ne=te.config,xe=r&&i.aspect<1,fe=Math.min(G.height*ne.height,G.width*(xe?.27:.3)/te.aspect),we=fe*te.aspect;te.mesh.scale.set(we,fe,1);const me=(te.side==="left"?-G.width/2+ne.edgeInset*G.width+we/2:G.width/2-ne.edgeInset*G.width-we/2)+F*G.width,P=xe?.19+(t?0:.19*m):r?.015:ne.bottom,Le=-G.height/2+(P+O)*G.height+fe/2;te.mesh.position.set(me,Le,-2.5)}function H(){if(!y){for(const te of d)z(te);g&&c[1]&&(g.scale.copy(c[1].scale),g.position.copy(c[1].position))}}const L=s?[Mi.left.file,"/overlay/right-hand-pointing-smooth.webp"]:[Mi.left.file,Mi.right.file,Mi.right.neutralFile],N=Promise.all(L.map(T)).then(te=>{if(y)return te.forEach(F=>F.dispose()),!1;for(const F of te)F.colorSpace=_t,F.magFilter=Dt,F.minFilter=Gt,S.push(F);for(let F=0;F<2;F++){const O=F===0?"left":"right",G=te[F],ne=s&&O==="right"?{...Mi[O],columns:72,rows:72}:Mi[O],xe=new yn(1,1,ne.columns,ne.rows),fe=xe.getAttribute("position"),we=xe.getAttribute("uv");if(s&&O==="right")for(let Se=0;Se<we.count;Se++){const Ye=we.getY(Se),De=10/72,I=66/72,E=Ye<=De?Ye/De*.38:Ye<=I?.38+(Ye-De)/(I-De)*.47:.85+(Ye-I)/(1-I)*.15;we.setY(Se,E),fe.setY(Se,E-.5)}const me=new Float32Array(fe.array),P=new Float32Array(we.array);{const Se=new Float32Array(we.count*4),Ye=De=>(De=sn(De,0,1),De*De*(3-2*De));for(let De=0;De<we.count;De++){const I=P[De*2],E=P[De*2+1],j=Ye((I-.68)/.26),Q=1-Ye((E-.16)/.22),ie=De*4;Se[ie]=1,Se[ie+1]=1,Se[ie+2]=1,Se[ie+3]=O==="left"?Ye((E-.09)/.21):1-j*Q}xe.setAttribute("color",new nt(Se,4))}const Le=new Ut({map:G,transparent:!0,opacity:ne.baseOpacity,side:Et,depthTest:!1,depthWrite:!1,toneMapped:!1,vertexColors:!0});p.material(Le);const Te=a?fh(xe,Le,O==="left"?"left":s?"perspective":"pointing",{perspective:s&&O==="right"}):null;Te&&u.push(Te);const ge=Te?Te.mesh:new ht(xe,Le);p.bind(ge),ge.name=O==="left"?"OrionFeminineLeftFraming":"OrionFeminineRightPointing",ge.renderOrder=300+F,ge.frustumCulled=!1,c.push(ge),l.add(ge);const ae=G.image?.naturalWidth||G.image?.width||1122,ze=G.image?.naturalHeight||G.image?.height||1402,oe={side:O,config:ne,mesh:ge,rest:me,uvLocal:P,aspect:s&&O==="right"?1122/1402:ae/ze};d.push(oe),z(oe)}if(s)h.push(c[1]);else{const F=a?c[1].geometry.clone():c[1].geometry,O=new Ut({map:S[2],transparent:!0,opacity:Mi.right.baseOpacity,side:Et,depthTest:!1,depthWrite:!1,toneMapped:!1,vertexColors:!0});p.material(O);const G=a?fh(F,O,"neutral",{perspective:s}):null;G&&u.push(G),g=G?G.mesh:new ht(F,O),p.bind(g),g.name="OrionFeminineRightNeutral",g.renderOrder=301,g.frustumCulled=!1,l.add(g),g.scale.copy(c[1].scale),g.position.copy(c[1].position)}return o.loaded=!0,o.visible=!0,o.textureCount=S.length,o.edgeOpacity=!0,o.joints=u.reduce((F,O)=>F+O.bones.length,0),o.fingerJoints=u.reduce((F,O)=>F+O.bones.length-2,0),l.visible=!0,D=!0,B(0,0),!0}).catch(te=>(o.loadError="Falha ao carregar os assets das mãos",o.loaded=!1,o.visible=!1,l.visible=!1,S.forEach(F=>F.dispose()),console.warn("[Observatório] Assets das mãos indisponíveis",te),!1));function B(te,F,O=0,G=0){if(!D||y)return;const ne=sn(F,0,.06),xe=1-Math.exp(-ne*5.7);if(w+=(sn(O,-1,1)-w)*xe,A+=(sn(G,-1,1)-A)*xe,o.swayX=t?0:w,o.swayY=t?0:A,_){R+=ne;const ae=sn(R/.38,0,1);M=1-ae*ae*ae*(ae*(ae*6-15)+10)}const fe=(v||o.selecting)&&(!_||x)?1:0;if(t)m=fe,f=0;else if(a){const ze=m-fe,oe=Math.exp(-6.5*ne),Se=(f+6.5*ze)*ne;m=fe+(ze+Se)*oe,f=(f-6.5*Se)*oe}else m+=(fe-m)*(1-Math.exp(-ne*9.5));m=sn(m,0,1),o.hoverBlend=m,o.leftFollow=t?0:m;const we=s?dS:1,me=s?.1:.16,P=sn(m*we-(t?0:me*o.selectionPress+.015*o.selectionAnticipation),0,we);o.rightBlend=P;const Le=r?0:M;if(Le<.001){l.visible=!1,o.visible=!1,o.drawSurfaces=0,o.triangles=0;return}l.visible=!0,o.visible=!0;let Te=0;for(const ae of u)ae.update(te,t,P,ae.pose==="left"?o.leftFollow:0,o.selecting&&ae.pose!=="left"?o:null);const ge=a&&!t?_e.smoothstep(P,.25,.75):P;for(const ae of d){const ze=ae.config,{mesh:oe,rest:Se,uvLocal:Ye}=ae,De=oe.geometry.getAttribute("position");a||(Te=Math.max(Te,uS(Se,De.array,Ye,ae.side,te,o.swayX,o.swayY,t)),De.needsUpdate=!t);const I=t?0:o.swayX*ze.swayX,E=t?0:o.swayY*ze.swayY+Math.sin(te*.94+ze.phase)*ze.breath;if(z(ae,I,E),oe.rotation.set(0,0,ze.rotation+(t?0:Math.sin(te*.72+ze.phase)*(ze.pointer?.01:.006))),ae.side==="right"&&s&&!t&&(oe.rotation.z+=(-o.targetDirectionX*.018+(o.targetDirectionY-.18)*.012)*m,oe.rotation.y+=o.targetDirectionX*.012*m),_&&!t&&(oe.position.y-=k().height*.018*(1-M)),ae.side==="left"&&o.leftFollow>0){const j=k();oe.position.x+=j.width*.0025*o.leftFollow,oe.position.y+=j.height*.0035*o.leftFollow,a||(oe.rotation.z+=.008*o.leftFollow)}if(ae.side==="right"&&o.selecting&&!t){const j=k(),Q=o.selectionReach,ie=o.selectionAnticipation,K=o.selectionFollowThrough;oe.position.x+=j.width*(-.0055*Q+.001*ie),oe.position.y+=j.height*(.007*Q+.005*o.selectionLift-.002*ie+.001*K),oe.position.z+=.052*Q-.01*ie,oe.rotation.x+=.035*Q-.018*o.selectionPress,oe.rotation.y+=-.045*Q+.012*K,oe.rotation.z+=.02*Q-.028*o.selectionPress+.01*ie+.007*K}oe.material.opacity=ze.baseOpacity*Le*(ae.side==="right"&&!s?ge:1)}if(g&&c[1]&&(g.position.copy(c[1].position),g.scale.copy(c[1].scale),g.rotation.copy(c[1].rotation),g.material.opacity=Mi.right.baseOpacity*Le*(1-ge)),c[1].visible=s||ge>.003,g&&(g.visible=ge<.997),s){const ae=Of(P);o.rightFrameWeights=ae,o.rightDepth=t?0:P*Lf*Df}o.drawSurfaces=s?2:1+Number(c[1].visible)+Number(g.visible),o.triangles=c[0].geometry.index.count/3+(o.drawSurfaces-1)*c[1].geometry.index.count/3,a||(o.maxVertexDelta=Te)}function V(te){v=!!te&&!_,o.rightHover=v}function Y(te,F){o.targetDirectionX=sn(te,-1,1),o.targetDirectionY=sn(F,-1,1)}function ee(te){o.selecting=!!te&&(!_||x)&&!y,o.selectionReach=o.selecting&&!t?sn(te.reach,0,1):0,o.selectionPress=o.selecting&&!t?sn(te.press,0,1):0,o.selectionAnticipation=o.selecting&&!t?sn(te.anticipation??0,0,1):0,o.selectionLift=o.selecting&&!t?sn(te.lift??0,0,1):0,o.selectionFollowThrough=o.selecting&&!t?sn(te.followThrough??0,0,1):0}function $(){_||(x=o.selecting&&!t,_=!0,x||ee(null),V(!1))}function re(){if(!y){y=!0,l.visible=!1;for(const te of c)te.geometry.dispose(),te.material.dispose(),l.remove(te);g&&(a&&g.geometry.dispose(),g.material.dispose(),l.remove(g));for(const te of u)te.dispose();for(const te of S)te.dispose();i.remove(l),c.length=0,d.length=0,u.length=0,h.length=0,o.visible=!1,o.loaded=!1}}return{state:o,root:l,meshes:c,rigs:u,rightFrames:h,ready:N,update:B,resize:H,setStarHovered:V,setStarDirection:Y,setStarSelection:ee,beginTravel:$,dispose:re}}const Sl="orion-complete-draft-v1";function Ka(i,e=Sl){try{const t=i.getItem(e);if(!t||t.length>5e5)return null;const n=JSON.parse(t);return e===Sl&&n?.format!=="orion-observatorio-draft"||n?.version!==1||typeof n.name!="string"||!n.name.trim()||!["menina","menino","nao-definir"].includes(n.gender)||!["COMBATENTE","ESPECIALISTA","OCULTISTA"].includes(n.classCode)||typeof n.origin?.code!="string"||!n.character||typeof n.character!="object"?null:{...n,step:"class",creationStep:e===Sl?"review":n.creationStep||"attributes"}}catch{return null}}const Za="orion-herald-creation-v1",Uf=Object.freeze(["menino","menina","nao-definir"]);function _S(){return{phase:"sealed",name:"",gender:null,continued:!1}}function Er(i,e){return e.type==="reveal"&&i.phase==="sealed"?{...i,phase:"revealed"}:e.type==="mark"&&i.phase==="revealed"?{...i,phase:"breaking"}:e.type==="released"&&i.phase==="breaking"?{...i,phase:"identity"}:i.phase!=="identity"?i:e.type==="name"?{...i,name:String(e.value).slice(0,60),continued:!1}:e.type==="gender"&&(Uf.includes(e.value)||e.value===null)?{...i,gender:e.value,continued:!1}:e.type==="continue"&&Ec(i)&&!i.continued?{...i,name:i.name.trim(),continued:!0}:i}function Ec(i){return i.phase==="identity"&&Uf.includes(i.gender)&&i.name.trim().length>0&&i.name.trim().length<=60}const xS={fetal:{root:[.48,.46],spine:[.38,.49],neck:[.47,.69],head:[.48,.78],armL:[.48,.59],elbowL:[.6,.52],handL:[.61,.61],armR:[.48,.57],elbowR:[.58,.51],handR:[.58,.6],hipL:[.43,.37],kneeL:[.66,.44],footL:[.6,.28],hipR:[.42,.36],kneeR:[.6,.41],footR:[.54,.27]},menina:{root:[.5,.49],spine:[.5,.63],neck:[.52,.78],head:[.53,.88],armL:[.33,.73],elbowL:[.23,.62],handL:[.12,.56],armR:[.65,.73],elbowR:[.76,.63],handR:[.84,.68],hipL:[.4,.45],kneeL:[.38,.29],footL:[.36,.1],hipR:[.61,.45],kneeR:[.66,.3],footR:[.65,.1]},menino:{root:[.5,.49],spine:[.5,.63],neck:[.49,.78],head:[.48,.88],armL:[.31,.73],elbowL:[.22,.63],handL:[.12,.65],armR:[.68,.73],elbowR:[.79,.61],handR:[.88,.52],hipL:[.4,.45],kneeL:[.37,.28],footL:[.35,.1],hipR:[.6,.45],kneeR:[.64,.3],footR:[.66,.1]}},Ml={root:null,spine:"root",neck:"spine",head:"neck",armL:"spine",elbowL:"armL",handL:"elbowL",armR:"spine",elbowR:"armR",handR:"elbowR",hipL:"root",kneeL:"hipL",footL:"kneeL",hipR:"root",kneeR:"hipR",footR:"kneeR"};function yS(i,e,t,n){const r=n[0]-t[0],s=n[1]-t[1],a=_e.clamp(((i-t[0])*r+(e-t[1])*s)/(r*r+s*s||1),0,1);return Math.hypot(i-t[0]-a*r,e-t[1]-a*s)}function bS(i,e){const t=xS[e];if(!t)throw new Error("Unknown silhouette rig");const n=Object.keys(Ml),r=[],s={},a=new yn(1,1,48,64);for(const p of n){const g=new ho,v=Ml[p],m=t[p],f=v?t[v]:[.5,.5];g.name="Soul_"+e+"_"+p,g.position.set(m[0]-f[0],m[1]-f[1],0),v&&s[v].add(g),s[p]=g,r.push(g)}const o=a.getAttribute("uv"),l=[],c=[];for(let p=0;p<o.count;p++){const g=o.getX(p),v=o.getY(p),m=n.map((y,_)=>{const x=Ml[y],R=t[y],M=x?t[x]:R,w=yS(g,v,R,M);return{index:_,weight:Math.exp(-Math.pow(w/.075,2)*2)+1e-15}}).sort((y,_)=>_.weight-y.weight).slice(0,4),f=m.reduce((y,_)=>y+_.weight,0);for(const y of m)l.push(y.index),c.push(y.weight/f)}a.setAttribute("skinIndex",new co(l,4)),a.setAttribute("skinWeight",new nt(c,4));const d=new Gc(a,i);d.add(r[0]),d.bind(new Ws(r)),d.frustumCulled=!1;const u=e==="menina"?.6:e==="menino"?2.7:1.3;function h(p,g=!1,v=0){for(const y of r)y.rotation.set(0,0,0);if(g)return;const m=Math.sin(p*.7+u),f=Math.sin(p*.42+u);s.spine.rotation.z=m*.007,s.neck.rotation.z=f*.012,s.head.rotation.z=-f*.006-v*.018,s.armL.rotation.z=Math.sin(p*.53+u)*.012,s.armR.rotation.z=Math.sin(p*.49+u+1)*.012,s.elbowL.rotation.z=m*.008,s.elbowR.rotation.z=-m*.009,s.hipL.rotation.z=f*.006,s.hipR.rotation.z=-f*.005,s.kneeL.rotation.z=m*.008,s.kneeR.rotation.z=-m*.007}return{mesh:d,bones:r,geometry:a,update:h,dispose(){d.skeleton.dispose(),a.dispose()}}}const SS=`
#include <common>
#include <skinning_pars_vertex>
varying vec2 vUv;varying float vEdge,vSeed,vLife;
void main(){vUv=uv;vEdge=1.;vSeed=0.;vLife=1.;
#include <skinbase_vertex>
#include <begin_vertex>
#include <skinning_vertex>
gl_Position=projectionMatrix*modelViewMatrix*vec4(transformed,1.);
}`,Ff="Acorrentado pela realidade",mh="/fonts/SigilosDeConhecimento.ttf",Oa="OrionKnowledge",Ja=[{tilt:.52,slope:.95,radius:.46,speed:.115},{tilt:-.46,slope:1.12,radius:.44,speed:-.087},{tilt:.12,slope:.42,radius:.47,speed:.065},{tilt:1.05,slope:.92,radius:.45,speed:-.055},{tilt:-1.08,slope:.86,radius:.43,speed:.095}];function MS(){const i=Ff+"   ";return Ja.flatMap((e,t)=>Array.from(i.repeat(2)).map((n,r)=>({char:n,ring:t,slot:r,slots:i.length*2}))).filter(e=>e.char!==" ")}function gh(i){const e=new Eg,t=new yn(1,1);e.index=t.index.clone(),e.attributes.position=t.attributes.position.clone(),e.attributes.uv=t.attributes.uv.clone(),t.dispose();const n=[...new Set(i.map(l=>l.char))],r=[],s=[],a=[],o=[];i.forEach((l,c)=>{r.push(l.slot/l.slots*Math.PI*2),s.push(l.ring),a.push(n.indexOf(l.char)),o.push(c*.6180339%1)});for(const[l,c]of[["aAngle",r],["aRing",s],["aCell",a],["aSeed",o]])e.setAttribute(l,new Xr(new Float32Array(c),1));return e.instanceCount=i.length,{geometry:e,chars:n}}function ES({reducedMotion:i=!1}={}){const e=new Ct;e.name="AcorrentadoPelaRealidade";const t=MS(),{geometry:n,chars:r}=gh(t),s={uMap:{value:null},uTime:{value:0},uRelease:{value:0},uCharge:{value:0},uOpacity:{value:0}},o=`attribute float aAngle,aRing,aCell,aSeed;uniform float uTime,uRelease;varying vec2 vUv;varying float vDepth,vSeed,vCell;
 vec4 orbitConfig(float ring){${Ja.map((A,S)=>`${S?"else ":""}if(ring<${(S+.5).toFixed(1)})return vec4(${A.tilt},${A.slope},${A.radius},${A.speed});`).join("")}return vec4(0.,1.,.46,.1);}
 vec3 orbit(float angle,float ring){vec4 o=orbitConfig(ring);vec3 p=vec3(cos(angle)*o.z,sin(angle)*o.z*cos(o.y),sin(angle)*o.z*sin(o.y));return vec3(p.x*cos(o.x)-p.y*sin(o.x),p.x*sin(o.x)+p.y*cos(o.x),p.z);}
 void main(){float speed=orbitConfig(aRing).w;float angle=aAngle+uTime*speed+aRing*.7;
 vec3 center=orbit(angle,aRing);vec3 tangent=orbit(angle+.002,aRing)-center;float rotation=atan(tangent.y,tangent.x);
 float release=smoothstep(.02+aSeed*.12,.9,uRelease);float spread=release*release*(.35+aSeed*.5);
 center+=normalize(center)*spread;center.y-=release*release*.12;
 rotation+=release*(aSeed-.5)*2.;mat2 turn=mat2(cos(rotation),sin(rotation),-sin(rotation),cos(rotation));
 float compression=max(.28,length(tangent.xy)/max(.00001,length(tangent)));
 vec2 local=turn*(position.xy*vec2(.039*compression,.039));vec3 p=center+vec3(local,0.);
 vDepth=center.z;vUv=uv;vSeed=aSeed;vCell=aCell;
 gl_Position=projectionMatrix*modelViewMatrix*vec4(p,1.);}`,l=`uniform sampler2D uMap;uniform float uFront,uOpacity,uRelease,uCharge,uTime;varying vec2 vUv;varying float vDepth,vSeed,vCell;
 void main(){float cellIndex=floor(vCell+.5);vec2 cell=vec2(mod(cellIndex,8.),floor(cellIndex/8.));vec2 at=vec2((cell.x+vUv.x)/8.,1.-(cell.y+1.-vUv.y)/4.);vec4 stencil=texture2D(uMap,at);float glyph=stencil.r;float halo=stencil.g*.72+stencil.b*.62;
 float side=smoothstep(-.013,.013,vDepth);float mask=mix(1.-side,side,uFront);float fade=1.-smoothstep(.35+vSeed*.2,1.,uRelease);
 float alpha=max(glyph,halo*.85)*mask*uOpacity*fade;if(alpha<.006)discard;
 float breathe=.94+.06*sin(uTime*.8+vSeed*6.);vec3 gold=mix(vec3(1.04,.56,.10),vec3(1.95,1.20,.30),uFront*.65+.15)*breathe*(1.+uCharge*.9);gold*=mix(.70,1.15,smoothstep(.05,.8,glyph));
 gl_FragColor=vec4(gold,alpha);
 #include <colorspace_fragment>
 }`,c=[],d=[!1,!0].map(A=>{const S=new Rt({transparent:!0,depthTest:!1,depthWrite:!1,toneMapped:!1,blending:tn,side:Et,forceSinglePass:!0,uniforms:{...s,uFront:{value:A?1:0}},vertexShader:o,fragmentShader:l});c.push(S);const b=new ht(n,S);return b.frustumCulled=!1,b.renderOrder=A?14:8,b.layers.enable(1),e.add(b),b}),u=t.filter((A,S)=>S%5===0),h=gh(u),p=[];u.forEach((A,S)=>{const b=S%2?1:-1;p.push(b*(.86+S%3*.022),-.82+Math.floor(S/2)/24*1.64,0)}),h.geometry.setAttribute("aCell",new Xr(new Float32Array(u.map(A=>r.indexOf(A.char))),1)),h.geometry.setAttribute("aAnchor",new Xr(new Float32Array(p),3));const g={uMap:s.uMap,uTime:{value:0},uOpacity:{value:0},uAspect:{value:1}},v=new Rt({transparent:!0,depthTest:!1,depthWrite:!1,toneMapped:!1,blending:tn,uniforms:g,vertexShader:`attribute vec3 aAnchor;attribute float aCell,aSeed;uniform float uTime,uAspect;varying vec2 vUv;varying float vCell,vSeed;
  void main(){vUv=uv;vCell=aCell;vSeed=aSeed;float a=sin(uTime*.07+aSeed*6.)*.16;mat2 turn=mat2(cos(a),sin(a),-sin(a),cos(a));vec2 at=aAnchor.xy+vec2(sin(uTime*.09+aSeed*13.),cos(uTime*.06+aSeed*9.))*.006;vec2 size=vec2(.028/max(.3,uAspect),.028)*(.65+aSeed*.4);gl_Position=vec4(at+turn*(position.xy*size),0.,1.);}`,fragmentShader:`uniform sampler2D uMap;uniform float uTime,uOpacity;varying vec2 vUv;varying float vCell,vSeed;
  void main(){float index=floor(vCell+.5);vec2 cell=vec2(mod(index,8.),floor(index/8.));vec2 at=vec2((cell.x+vUv.x)/8.,1.-(cell.y+1.-vUv.y)/4.);vec4 glyph=texture2D(uMap,at);float light=.76+.24*sin(uTime*.35+vSeed*12.);float alpha=max(glyph.r,glyph.g*.55+glyph.b*.4)*uOpacity*light*(.45+vSeed*.55);if(alpha<.003)discard;gl_FragColor=vec4(.95,.72,.38,alpha);}`}),m=new ht(h.geometry,v);m.name="KnowledgeMistGlyphs",m.frustumCulled=!1,m.renderOrder=5,m.visible=!1;let f,y,_=!1;const x={phrase:Ff,fontFamily:Oa,fontURL:mh,loaded:!1,glyphs:t.length,rings:Ja.length,time:0,release:0,reducedMotion:i,glowAtlasPacked:!0,ambientGlyphs:u.length,ambientVisible:!1},R=(async()=>{if(y=new FontFace(Oa,`url("${mh}")`),await y.load(),_)return!1;document.fonts.add(y);const A=document.createElement("canvas");A.width=2048,A.height=1024;const S=A.getContext("2d");S.fillStyle="#fff",S.textAlign="center",S.textBaseline="alphabetic",S.font=`192px "${Oa}"`;const b=r.map(N=>S.measureText(N)),T=192*Math.min(208/Math.max(...b.map(N=>N.width)),208/Math.max(...b.map(N=>N.actualBoundingBoxAscent+N.actualBoundingBoxDescent)));S.font=`${T}px "${Oa}"`,r.forEach((N,B)=>{const V=S.measureText(N),Y=B%8*256+128,ee=Math.floor(B/8)*256+128+(V.actualBoundingBoxAscent-V.actualBoundingBoxDescent)/2;S.fillText(N,Y,ee)});const D=S.getImageData(0,0,A.width,A.height).data,k=[];for(const N of[5,8]){const B=document.createElement("canvas");B.width=A.width,B.height=A.height;const V=B.getContext("2d");V.filter=`blur(${N}px)`,V.drawImage(A,0,0),k.push(V.getImageData(0,0,B.width,B.height).data)}const z=document.createElement("canvas");z.width=A.width,z.height=A.height;const H=z.getContext("2d"),L=H.createImageData(z.width,z.height);for(let N=0;N<D.length;N+=4)L.data[N]=D[N+3],L.data[N+1]=k[0][N+3],L.data[N+2]=k[1][N+3],L.data[N+3]=255;return H.putImageData(L,0,0),f=new fo(z),f.colorSpace=ci,f.minFilter=Gt,f.magFilter=Dt,s.uMap.value=f,x.loaded=!0,!0})();function M(A,S,b,T=0){const D=i?0:T;s.uTime.value=D,s.uRelease.value=i?0:A,s.uCharge.value=S,s.uOpacity.value=b*(i?1-A:1),e.visible=x.loaded&&b>.001&&A<1,x.time=D,x.release=A}function w(A,S=0,b=1){g.uTime.value=i?0:S,g.uAspect.value=b,g.uOpacity.value=Math.max(0,Math.min(1,A))*.2,m.visible=x.loaded&&A>.001,x.ambientVisible=m.visible}return{root:e,atmosphere:m,setAtmosphere:w,front:d[1],back:d[0],count:t.length,state:x,ready:R,update:M,dispose(){_=!0,e.remove(...d),n.dispose(),c.forEach(A=>A.dispose()),h.geometry.dispose(),v.dispose(),f?.dispose(),y&&document.fonts.delete(y)}}}const Bf=2.8,TS=i=>Math.max(0,Math.min(1,i)),Ei=(i,e,t)=>{const n=TS((t-i)/(e-i));return n*n*(3-2*n)};function AS(i,e=!1){const t=Math.max(0,i);if(e){const n=Ei(0,.18,t);return{charge:0,fracture:n,baby:1-n,children:n,separation:1,particles:0,complete:t>=.18}}return{charge:Ei(0,.25,t)*(1-Ei(.5,.9,t)),fracture:Ei(.22,1.95,t),baby:1-Ei(.85,1.9,t),children:Ei(1.15,2.65,t),separation:Ei(1.15,2.8,t),particles:Ei(.6,.9,t),complete:t>=Bf}}const wS=[{file:"/assets/creation/gray-far-v9.png",kind:"gray-far",z:-280,opacity:.3},{file:"/assets/creation/gray-near-v9.png",kind:"gray-near",z:-180,opacity:.21},{file:"/assets/creation/red-left-v14.png",kind:"red-left",z:-110,opacity:.64},{file:"/assets/creation/red-right-v14.png",kind:"red-right",z:-65,opacity:.59}],vh=.3,RS=.75;function CS(i){return vh+(1-vh)*i}function IS(i){return .5-.5*Math.cos(i*2*Math.PI/4.8)}function PS(i,e,{reducedMotion:t=!1,parallaxEnabled:n=!0}={}){const r=e.material,s=r.map;r.dispose(),e.material=new Rt({depthTest:!1,depthWrite:!1,uniforms:{},vertexShader:"void main(){gl_Position=vec4(position.xy*2.,.999,1.);}",fragmentShader:"void main(){gl_FragColor=vec4(0.,0.,0.,1.);}"}),e.material.map=s;const a={active:4,loaded:0,components:5,transition:0,parallaxEnabled:n&&!t,parallaxStrength:1,foregroundEnabled:!0,pulse:[0,0],reducedMotion:t},o=new rs,l=[],c=`uniform vec2 pan;uniform float aspect,plateAspect,time,transition,red,anchorSide,beat,motion,driftPhase;varying vec2 vUv;
 void main(){vec2 cover=vec2(min(1.,aspect/plateAspect),min(1.,plateAspect/aspect));vec2 at=.5+(uv-.5)*cover*.96;
 float portrait=1.-smoothstep(.75,1.2,aspect);at.x+=red*.23*portrait*(anchorSide<.5?-1.:1.);
 vec2 anchor=vec2(anchorSide<.5?.20:.80,anchorSide<.5?.25:.78);float live=beat*red*(1.-transition)*motion;
 at=anchor+(at-anchor)/(1.+live*.02);at+=pan;
 at+=vec2(sin(time*.09+driftPhase),cos(time*.07+driftPhase))*.0018*motion*transition*(1.-red);
 vUv=at;gl_Position=vec4(position.xy*2.,.998,1.);}`,d=`uniform sampler2D map;uniform float transition,opacity,red,saturation,brightness;varying vec2 vUv;
 void main(){vec4 cloud=texture2D(map,clamp(vUv,vec2(.001),vec2(.999)));float grey=dot(cloud.rgb,vec3(.2126,.7152,.0722));
 vec3 color=mix(vec3(grey),cloud.rgb,mix(1.,saturation,red));
 color=mix(color,grey*vec3(.82,.80,.95),transition);
 float layerOpacity=mix(opacity,red>.5?0.:opacity*1.65,transition);
 float alpha=cloud.a*layerOpacity;gl_FragColor=vec4(color,alpha);
 #include <colorspace_fragment>
 gl_FragColor.rgb*=mix(1.,brightness,red);
 }`,u=Promise.all(wS.map(async(p,g)=>{const v=await o.loadAsync(p.file);v.colorSpace=_t,v.minFilter=Gt,v.magFilter=Dt;const m=new Rt({transparent:!0,depthTest:!1,depthWrite:!1,toneMapped:!1,uniforms:{map:{value:v},pan:{value:new Ce},aspect:{value:innerWidth/innerHeight},plateAspect:{value:v.image.width/v.image.height},time:{value:0},transition:{value:0},opacity:{value:p.opacity},red:{value:g>1?1:0},anchorSide:{value:g===3?1:0},motion:{value:t?0:1},beat:{value:1},saturation:{value:1},brightness:{value:RS},driftPhase:{value:g*1.9}},vertexShader:c,fragmentShader:d}),f=new ht(new yn(1,1),m);return f.position.z=p.z,f.frustumCulled=!1,f.renderOrder=3+g*.1,f.userData={kind:p.kind,volumeFragment:!0,baseX:0,baseY:0,parallaxOffsetX:0,parallaxOffsetY:0},l[g]=f,i.add(f),a.loaded++,!0}));function h(p,g,v,m){const f=1-Math.exp(-Math.min(.1,Math.max(0,m))*2.4),y=t||a.transition===1?1:IS(p);a.pulse=[y,y],a.active=a.transition===1?2:4,l.forEach((_,x)=>{if(!_)return;const R=_.userData,M=_.material.uniforms;R.parallaxOffsetX+=((a.parallaxEnabled?-g*(.7+x*.25)*a.parallaxStrength:0)-R.parallaxOffsetX)*f,R.parallaxOffsetY+=((a.parallaxEnabled?-v*(.4+x*.18)*a.parallaxStrength:0)-R.parallaxOffsetY)*f,_.visible=x<2||a.transition<1,M.pan.value.set(R.parallaxOffsetX*.004,R.parallaxOffsetY*.004),M.aspect.value=innerWidth/innerHeight,M.time.value=t?0:p,M.transition.value=a.transition,M.beat.value=x<2?1:_e.lerp(y,1,a.transition),M.saturation.value=x<2?1:CS(M.beat.value)})}return{ready:u,layers:l,state:a,resize(){},update:h,applyQuality(){a.active=a.transition===1?2:4},setTransition(p){a.transition=p},setParallaxStrength(p){a.parallaxStrength=_e.clamp(p,.45,1.6)}}}const Qa={nebula:"/assets/creation/gray-far-v9.png",nebulaPortrait:"/assets/creation/gray-far-v9.png",baby:"/assets/creation/unborn-v5.png",children:"/assets/creation/souls-v9.png"};function kf(i=innerWidth/innerHeight){return i<.85?Qa.nebulaPortrait:Qa.nebula}const Ua=(i,e,t)=>_e.smoothstep(t,i,e),LS=`
 uniform sampler2D uMap;uniform vec4 uUV;uniform float uOpacity,uReveal,uTime,uCharge,uSelected,uFlip,uHover;
 varying vec2 vUv;varying float vEdge,vSeed,vLife;
 float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(fract(sin(dot(i,vec2(127.1,311.7)))*43758.5453),fract(sin(dot(i+vec2(1.,0.),vec2(127.1,311.7)))*43758.5453),f.x),mix(fract(sin(dot(i+vec2(0.,1.),vec2(127.1,311.7)))*43758.5453),fract(sin(dot(i+1.,vec2(127.1,311.7)))*43758.5453),f.x),f.y);}
 void main(){
  vec2 at=uUV.xy+vec2(mix(vUv.x,1.-vUv.x,uFlip),vUv.y)*uUV.zw;
  vec4 texel=texture2D(uMap,at);
  // A complete reveal is identically one: avoid procedural noise at rest.
  float mask=1.;
  if(uReveal<1.){
   float n=noise(vUv*10.)*.65+noise(vUv*23.)*.35;
   mask=smoothstep(n-.13,n+.13,uReveal*1.35-.12);
  }
  // Solid alpha core: only the antialiased contour may blend.
  float coverage=smoothstep(.12,.65,texel.a);
  // Fully covered pixels cannot have an outer rim. Keep all four taps at
  // the contour, including transparent pixels that contribute its glow.
  float rim=0.;
  if(coverage<1.){
   vec2 stepUV=uUV.zw*.006;
   float nearAlpha=max(max(texture2D(uMap,at+vec2(stepUV.x,0.)).a,texture2D(uMap,at-vec2(stepUV.x,0.)).a),max(texture2D(uMap,at+vec2(0.,stepUV.y)).a,texture2D(uMap,at-vec2(0.,stepUV.y)).a));
   rim=max(0.,smoothstep(.12,.65,nearAlpha)-coverage);
  }
  float emphasis=.38+uHover*.45+uSelected*.35;
  float alpha=max(coverage,rim*emphasis)*uOpacity*mask*vLife;
  alpha*=smoothstep(0.,.025,vUv.x)*(1.-smoothstep(.975,1.,vUv.x))*smoothstep(0.,.025,vUv.y)*(1.-smoothstep(.975,1.,vUv.y));
  if(alpha<.006)discard;
  vec3 color=mix(vec3(0.),vec3(.8,.53,.20),rim*emphasis)+vec3(.9,.87,.96)*uCharge*.9;
  color*=1.+uCharge*.24;
  gl_FragColor=vec4(color,alpha);
  #include <colorspace_fragment>
 }`;function DS(i,{opacity:e=1,uv:t=[0,0,1,1],motion:n=1,flip:r=!1}={}){return new Rt({transparent:!0,depthTest:!1,depthWrite:!1,side:Et,forceSinglePass:!0,toneMapped:!1,uniforms:{uMap:{value:i},uUV:{value:new rt(...t)},uOpacity:{value:e},uMotion:{value:n},uTime:{value:0},uCharge:{value:0},uReveal:{value:1},uSelected:{value:0},uHover:{value:0},uFlip:{value:r?1:0}},vertexShader:SS,fragmentShader:LS})}function NS({scene:i,camera:e,panel:t,reducedMotion:n=!1,environment:r}){const s=new rs,a={},o={},l={},c=new Ct;c.name="CreationCinematicLayers",i.add(c);const d={rigMode:"image-skinned-2.5D",joints:48,fieldLayers:0,bindingType:"knowledge-sigils",bindingLayers:Ja.length,ready:!1,phase:"sealed",releaseProgress:0,selected:null,surfaces:0,fragments:0,particleCount:64,gestureFromMark:!1};let u=null,h=null,p=null,g={x:0,y:0},v=!0,m=null;const f={},y=new U,_=new U,x=new dt;function R($,re,te){return _.set($/innerWidth*2-1,1-re/innerHeight*2,.5).unproject(e).sub(y).normalize(),y.clone().addScaledVector(_,(te-y.z)/_.z)}function M($,re,te,F,O=0,G=0){const ne=$.material.uniforms.uMap.value.image;if(!ne||!re.width||!re.height)return;const xe=ne.width*F[2]/(ne.height*F[3]),fe=Math.min(re.height,re.width/xe),we=fe*xe,me=R(re.x+re.width/2,re.y+re.height/2+G,te),P=R(re.x+re.width/2-we/2,re.y+re.height/2,te),Le=R(re.x+re.width/2+we/2,re.y+re.height/2,te);n||(me.x+=g.x*($.userData.parallax??.12),me.y+=g.y*.07),$.position.copy(me),$.scale.set(P.distanceTo(Le),P.distanceTo(Le)/xe,P.distanceTo(Le)),$.quaternion.copy(x),$.material.uniforms.uTime.value=n?0:O}const w={baby:[.1494140625,.17578125,.69140625,.6966145833],menina:[.145833333,.072265625,.266927083,.8515625],menino:[.588541667,.072265625,.279947917,.8515625]},A=ES({reducedMotion:n});c.add(A.root,A.atmosphere),d.links=0,d.glyphs=A.count;const S=Promise.all([A.ready,...["baby","children"].map(async $=>{const re=await s.loadAsync(Qa[$]);re.colorSpace=_t,re.minFilter=Gt,re.magFilter=Dt,a[$]=re})]).then(()=>{for(const $ of["baby","menina","menino"]){const re=DS(a[$==="baby"?"baby":"children"],{uv:w[$],motion:n?0:1,flip:!1}),te=bS(re,$==="baby"?"fetal":$);l[$]=te;const F=te.mesh;F.userData.parallax=.1,F.frustumCulled=!1,F.layers.enable(1),F.renderOrder=11,F.visible=$==="baby",c.add(F),o[$]=F}return r?.ready}).then(()=>(u=performance.now(),d.ready=!0,d.surfaces=5,!0)),b=64,T=new Float32Array(b*3),D=new Float32Array(b*3),k=new Float32Array(b);for(let $=0;$<b;$++){const re=$*2.3999632,te=.28+$%7/35;T[$*3]=Math.cos(re)*te,T[$*3+1]=Math.sin(re)*te,D[$*3]=Math.cos(re)*(1.1+$%5*.2),D[$*3+1]=Math.sin(re)*.9,D[$*3+2]=($%3-1)*.3,k[$]=$*.6180339%1}const z=new Lt;z.setAttribute("position",new ct(T,3)),z.setAttribute("aVelocity",new ct(D,3)),z.setAttribute("aSeed",new ct(k,1));const H=new Rt({transparent:!0,depthTest:!1,depthWrite:!1,blending:tn,toneMapped:!1,uniforms:{uTime:{value:0},uElapsed:{value:0},uActive:{value:0},uExtent:{value:new Ce(1,1)},uDpr:{value:Math.min(devicePixelRatio,1.5)}},vertexShader:"attribute vec3 aVelocity;attribute float aSeed;uniform float uTime,uElapsed,uActive,uDpr;uniform vec2 uExtent;varying float alpha;void main(){float t=max(0.,uElapsed-.6);float flight=min(t,4.);float drag=1.-exp(-flight*.9);vec3 p=position+aVelocity*drag;p.y-=.025*flight*flight;p.xy+=vec2(sin(uTime*.2+aSeed*10.),cos(uTime*.17+aSeed*8.))*.012*step(4.,t);vec4 mv=modelViewMatrix*vec4(p.xy*uExtent,p.z,1.);gl_Position=projectionMatrix*mv;gl_PointSize=(1.5+aSeed*2.8)*uDpr;alpha=uActive*smoothstep(0.,.2,t)*(.38+.22*sin(uTime*.7+aSeed*10.))*mix(1.,step(.75,aSeed)*.22,smoothstep(4.,8.,t));}",fragmentShader:"varying float alpha;void main(){float r=length(gl_PointCoord-.5);float a=(1.-smoothstep(.02,.5,r))*alpha;gl_FragColor=vec4(1.,.84,.5,a);}"}),L=new Yc(z,H);L.layers.enable(1),L.renderOrder=15,L.frustumCulled=!1,L.visible=!n,c.add(L);function N(){for(const[$,re]of[["baby",".baby-target"],["orbit",".sealed-being"],["menina",'[data-gender="menina"] .soul-anchor'],["menino",'[data-gender="menino"] .soul-anchor']])f[$]=t.querySelector(re).getBoundingClientRect();v=!1,d.layoutPasses=(d.layoutPasses||0)+1}function B(){v=!0}const V=new ResizeObserver(B);for(const $ of t.querySelectorAll(".baby-target,.sealed-being,.soul-anchor,.identity-form,.birth-stage"))V.observe($);t.addEventListener("scroll",B,!0),window.addEventListener("resize",B);function Y($){if(!d.ready)return;for(const[ae,ze]of Object.entries(o)){const oe=ze.material.uniforms.uHover;oe.value=_e.lerp(oe.value,m===ae?1:0,n?1:.15)}const re=$*.001;e.updateWorldMatrix(!0,!1),e.getWorldPosition(y),e.getWorldQuaternion(x),v&&N();const te=n?1:Ua(.5,2.1,($-u)/1e3);d.introProgress=te,d.phase==="sealed"&&(t.querySelector(".baby-target").disabled=te<1);const F=h===null?0:($-h)/1e3,O=AS(F,n),G=h!==null,ne=G?n?Math.min(1,F/.18):Ua(.5,1.65,F):0;r?.setTransition(ne),d.environmentTransition=ne;const xe=G&&!n?Ua(.12,.52,F)*(1-Ua(.62,1.3,F)):0;t.style.setProperty("--birth-flash",String(xe)),t.style.setProperty("--birth-transition",String(ne)),G&&(d.releaseProgress=Math.min(1,F/(n?.18:2.8)));const fe=o.baby,we=n?0:Math.sin(re*.6)*4;M(fe,f.baby,-42,w.baby,re,we),l.baby.update(re,n,0),fe.material.uniforms.uCharge.value=G?O.charge:0,fe.material.uniforms.uReveal.value=G?O.baby:1,fe.material.uniforms.uOpacity.value=te,fe.visible=!(G&&O.complete);const me=f.orbit,P=Math.min(me.width,me.height),Le=R(me.x+me.width/2,me.y+me.height/2+we,-44),Te=R(me.x+me.width/2-P/2,me.y+me.height/2,-44),ge=R(me.x+me.width/2+P/2,me.y+me.height/2,-44);A.root.position.copy(Le),A.root.quaternion.copy(x),A.root.scale.setScalar(Te.distanceTo(ge)),A.update(G?O.fracture:0,G?O.charge:0,te,re),A.setAtmosphere(G?O.separation:0,re,innerWidth/innerHeight),d.bindingFracture=G?O.fracture:0;for(const ae of["menina","menino"]){const ze=o[ae];if(ze.visible=G,!G)continue;const oe=f[ae],Se=f.baby,Ye=O.separation,De=n?0:Math.sin(Ye*Math.PI)*28,I={width:oe.width,height:oe.height,x:_e.lerp(Se.x+Se.width/2-oe.width/2,oe.x,Ye),y:_e.lerp(Se.y+Se.height/2-oe.height/2,oe.y,Ye)-De};M(ze,I,-39,w[ae],re,n?0:Math.sin(re*.55+(ae==="menina"?0:2))*4);const E=ze.material.uniforms;l[ae].update(re,n,E.uSelected.value),E.uReveal.value=O.children,E.uSelected.value=_e.lerp(E.uSelected.value,d.selected===ae?1:0,n?1:.12)}if(G&&!n){L.visible=!0;const ae=A.root.position;L.position.copy(ae),L.quaternion.copy(x),H.uniforms.uTime.value=re,H.uniforms.uElapsed.value=F,H.uniforms.uActive.value=O.particles,H.uniforms.uExtent.value.set(A.root.scale.x,A.root.scale.y)}if(G&&O.complete&&p){d.phase="identity";const ae=p;p=null,ae()}}function ee({immediate:$=!1}={}){return h!==null?Promise.resolve(!1):(d.phase="breaking",h=performance.now()-($?Bf*1e3+1:0),new Promise(re=>{p=re}))}return{ready:S,state:d,update:Y,release:ee,invalidateLayout:B,get meshes(){return o},rigs:l,bindings:A,hover($){m=$},select($){d.selected=$},point($){g=$},dispose(){V.disconnect(),t.removeEventListener("scroll",B,!0),window.removeEventListener("resize",B),i.remove(c),A.dispose();for(const $ of Object.values(l))$.dispose();z.dispose(),H.dispose();for(const $ of Object.values(o))$.material.dispose();for(const $ of Object.values(a))$.dispose()}}}const OS=i=>(1-Math.cos(Math.PI*Math.max(0,Math.min(1,i))))/2;function US(i,{reducedMotion:e=!1}={}){let t=null,n=null,r=!1;function s(){t!==null&&cancelAnimationFrame(t),t=null,delete i.dataset.autoScrolling,n?.(!1),n=null}function a(c){if(s(),r)return Promise.resolve(!1);const d=i.scrollTop,u=Math.max(0,Math.min(Number(c)||0,i.scrollHeight-i.clientHeight)),h=u-d;if(e||Math.abs(h)<2)return i.scrollTop=u,Promise.resolve(!0);i.dataset.autoScrolling="1";const p=Math.min(850,480+Math.abs(h)*.14);let g=0,v=null;return new Promise(m=>{n=m;function f(y){g+=v===null?16:Math.min(64,Math.max(0,y-v)),v=y;const _=Math.min(1,g/p);i.scrollTop=d+h*OS(_),_<1?t=requestAnimationFrame(f):(t=null,delete i.dataset.autoScrolling,n=null,m(!0))}t=requestAnimationFrame(f)})}function o(c,{offset:d=24}={}){return c?a(i.scrollTop+c.getBoundingClientRect().top-i.getBoundingClientRect().top-d):Promise.resolve(!1)}const l=c=>{(["Tab","ArrowUp","ArrowDown","PageUp","PageDown","Home","End"," "].includes(c.key)||c.target.matches?.("input,textarea,select")&&!["Shift","Control","Alt","Meta"].includes(c.key))&&s()};for(const c of["wheel","touchstart","pointerdown"])i.addEventListener(c,s,{passive:!0});return i.addEventListener("keydown",l),{top:a,to:o,cancel:s,get running(){return t!==null},dispose(){r=!0,s();for(const c of["wheel","touchstart","pointerdown"])i.removeEventListener(c,s);i.removeEventListener("keydown",l)}}}const pe=i=>`<path d="${i}"/>`,Xe=(i,e,t)=>`<circle cx="${i}" cy="${e}" r="${t}"/>`,_h=(i,e,t,n)=>`<ellipse cx="${i}" cy="${e}" rx="${t}" ry="${n}"/>`,xh=pe("M7 12q9-5 17 1 8-6 17-1v25q-9-4-17 1-8-5-17-1ZM24 13v25M11 18l8 1m-8 5 8 1m10-6 8-1m-8 7 8-1"),FS=pe("M21 17h6v7h7v6h-7v7h-6v-7h-7v-6h7Z"),BS=Xe(16,16,3)+Xe(24,12,3)+Xe(32,16,3)+pe("M24 21c-5 0-7 6-10 9-4 6 1 10 6 7 3-2 5-2 8 0 5 3 10-1 6-7-3-3-5-9-10-9Z"),kS=pe("M24 34 12 22c-9-10 7-18 12-8 5-10 21-2 12 8Z"),yh=pe("M18 32v-4c-10-8-5-22 6-22s16 14 6 22v4ZM18 36h12m-10 5h8M24 4V1M9 12l-4-3m34 3 4-3"),zS=pe("M7 15q17 6 34 0v8c0 13-17 19-17 19S7 36 7 23ZM13 24q4-5 8 0m6 0q4-5 8 0M19 32q5 4 10 0"),bh=pe("M14 15v-4q0-4 4-4h12q4 0 4 4v4M7 16h34v25H7ZM18 7v8m12-8v8"),VS=Xe(24,24,17)+pe("m29 14-2 13-13 7 7-13ZM24 4v5m0 30v5M4 24h5m30 0h5"),El=pe("M24 5q-8 6-17 6v12c0 11 17 20 17 20s17-9 17-20V11q-9 0-17-6Z"),Sh=pe("M12 26c-13-3-8-20 4-15 2-11 17-11 19 0 12-4 16 12 2 15v13H12ZM12 33h25"),Mh=pe("M13 18q-1-10 11-10t11 10l3 22H10ZM18 9V5h12v4M14 25h20v11H14Zm4-7h12m-20 5-5 4v12h5m28-16 5 4v12h-5"),Eh=pe("M4 24q20-22 40 0-20 22-40 0Z")+Xe(24,24,7)+Xe(24,24,2),HS=Object.freeze({ACADEMICO:xh+pe("M31 9V4h6v9l-3-2Z"),AGENTE_SAUDE:bh+FS,ARTISTA:pe("M24 6C3 6 1 34 15 39c8 3 6-6 12-7 8-2 13 7 17-4C49 15 36 6 24 6Z")+Xe(14,19,2)+Xe(20,13,2)+Xe(29,13,2)+Xe(36,19,2)+pe("m14 42 15-22 4 3-15 21Z"),ATLETA:pe("M6 31c5-1 8-10 11-20l8 3-1 9 9 4 9 3v9H6ZM7 35h34M21 22l5 4m-9-1 5 4m7-3 4 4"),CHEF:Sh+pe("M18 30v-5m7 5v-5m6 5v-5"),CRIMINOSO:pe("M5 17q19-9 38 0l-3 13q-8 4-16-2-8 6-16 2ZM10 21q5-4 10 0-4 8-10 0Zm18 0q5-4 10 0-4 8-10 0ZM20 36h8m-5-4v8"),CULTISTA_ARREPENDIDO:Xe(24,24,17)+pe("m24 9 9 27-23-17h28L15 36ZM7 41 41 7M18 5l3 6m17 29-4-5"),DESGARRADO:pe("M8 39h32M24 36V18m0 7L12 13m12 8 9-15M5 12l7-2 4 6m14-9 7-2 2 8M8 42l4-6m22 6-4-6")+Xe(24,12,4),ENGENHEIRO:pe("M9 38 29 18c-5-10 4-17 13-13l-8 7 3 6 8-7c4 9-5 17-13 12L14 43Z")+Xe(11,38,2)+pe("M6 9h13M12 3v13m-6 8 6-6"),EXECUTIVO:bh+pe("M7 25q17 8 34 0M20 25h8v7h-8ZM30 10l6-5 5 4"),INVESTIGADOR:Xe(20,19,12)+pe("m29 28 14 14-4 4-14-14M13 16q4-5 10-4")+Xe(18,22,1),LUTADOR:pe("M15 38 8 27q-3-6 2-8l4 5V11q1-5 5-2v13-15q3-4 6 0v15-13q3-4 6 0v15-9q3-3 6 0v13l-7 10v6H15ZM15 34l20-4M16 39h14m-12 3h12"),MAGNATA:pe("m24 5 12 10-12 12-12-12ZM12 15h24M24 5l-5 10 5 12 5-12ZM12 27c-9 20 33 20 24 0M9 34h30"),MERCENARIO:pe("M14 7h19l6 6v24l-6 6H14V7Zm5 0v-4m8 0v4M19 16h12m-12 6h12m-12 6h7M8 35l32-28m-6 0 6 0v6"),MILITAR:pe("m24 5 7 13 14 2-10 10 2 14-13-7-13 7 2-14L3 20l14-2ZM15 25l9-6 9 6m-18 6 9-6 9 6"),OPERARIO:pe("m7 8 10-3 9 9-5 5-9-9-5 3ZM17 17l24 24-5 5-24-24M38 5c-9-3-15 5-11 12L7 37l4 4 21-20c8 3 16-6 12-13l-7 7-4-4Z"),POLICIAL:El+pe("m24 13 3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1Z"),RELIGIOSO:pe("M18 23h12v19H18Zm6-3c-10-6 5-12 0-19 11 8 7 15 0 19ZM12 43h24M11 14l-6-2m32 2 6-2M14 6l-3-4m23 4 3-4"),SERVIDOR_PUBLICO:pe("m5 16 19-11 19 11ZM8 19h32M10 19v19m9-19v19m10-19v19m9-19v19M6 39h36v5H6Z")+Xe(24,11,1),TEORICO_CONSPIRACAO:pe("M6 7h36v34H6ZM11 13l7 5 13-4 6 13-16 8-10-10 7-7m3 17 10-21M11 25l26 2")+Xe(18,18,3)+Xe(31,14,2)+Xe(21,35,2),TI:pe("M8 7h32v26H8ZM4 39h40l-3 4H7ZM14 15l6 5-6 5m10 0h9M18 37h12"),TRABALHADOR_RURAL:pe("M24 43V18M24 28C7 32 4 20 4 20s17-3 20 8Zm0-10C39 21 43 9 43 9S27 6 24 18ZM8 43h32M11 5l-5 7 9 3"),TRAMBIQUEIRO:pe("m5 13 22-7 11 30-22 7ZM19 9l15-3 8 31-5 1M11 19l4-1m7 18 4-1")+pe("m20 18-4 9 9-3Z"),UNIVERSITARIO:pe("m3 17 21-11 21 11-21 11ZM12 22v13q12 9 24 0V22M43 19v19m-3 0h6M18 41h12"),VITIMA:El+pe("m25 8-8 12 12 7-9 15M17 22l5-5m-1 12 6-6m-8 12 7-5"),AMIGO_ANIMAIS:BS+pe("M7 7c-5-7 7-9 8-3 1-6 13-4 8 3l-8 8Z"),ASTRONAUTA:pe("M9 28V21c0-22 30-22 30 0v7M8 27h32v14H8ZM13 20q11-8 22 0v11H13ZM16 41v4h16v-4M17 15l8-3")+Xe(13,36,1)+Xe(35,36,1),CHEF_OUTRO_LADO:Sh+pe("m24 17 2 5 5 1-4 3 1 5-4-3-4 3 1-5-4-3 5-1ZM8 30c-10-2-7 13-1 10m34-10c9-2 7 13 0 10"),COLEGIAL:Mh+pe("m19 28 4 4 7-6M20 17h8"),COSPLAYER:zS+pe("m8 5 2 5 5 2-5 2-2 5-2-5-5-2 5-2ZM37 5v7m-4-3h8"),DIPLOMATA:pe("M4 22 12 12l9 5 7-3 16 10-9 14-14-3-7-7-5 1ZM18 18l-6 8 6 5 8-9 12 10m-20 3 7-9m-1 11 7-8M4 22l6 5m28-10 5 5"),EXPLORADOR:VS+pe("m16 35 8-5 9 5M21 10h6"),EXPERIMENTO:pe("M18 4h12m-10 0v14L8 38q-2 6 4 6h24q6 0 4-6L28 18V4M14 30h20M20 14l8 5m-12 5 15 4")+Xe(21,35,2)+Xe(29,38,1),FANATICO_CRIATURAS:xh+pe("M16 12 11 3l11 8m9 1 6-9-1 10M17 25l4 3m7 0 4-3"),FOTOGRAFO:pe("M5 15h10l4-7h12l4 7h8v26H5ZM8 20h6m22 0h3")+Xe(25,28,9)+Xe(25,28,5),INVENTOR_PARANORMAL:yh+pe("m24 12 3 7 7 1-6 4 2 7-6-4-6 4 2-7-6-4 7-1Z"),JOVEM_MISTICO:pe("m9 22 7-11 7 11-7 21ZM9 22h14M16 11v32m10-18 6-7 6 7-6 16ZM26 25h12M33 4c-11 3-8 15 2 15-6-5-6-10-2-15Z"),LEGISTA_NOTURNO:pe("M12 23C2 0 46 0 36 23l-5 5v11H17V28ZM17 34h14m-10-6v11m6-11v11M20 18h-6v6h6Zm8 0h6v6h-6ZM22 27l2-5 2 5M7 42h34"),MATEIRO:pe("M11 32C5 12 25 7 39 6 39 27 30 38 11 32ZM10 39 33 13M17 31v-9m7 3 9-2m-10-4v-7M5 43h8m13-3 6-4m7 6h5"),MERGULHADOR:pe("M4 20h40v14H31l-7-5-7 5H4ZM8 24h10v6H8Zm22 0h10v6H30ZM41 18V6h-7v9m10-9v22M17 40q7 5 14 0")+Xe(10,11,2),MOTORISTA:Xe(24,24,19)+Xe(24,24,14)+Xe(24,24,4)+pe("M6 19l15 4m6 0 15-4M24 28v14M11 16q13-7 26 0"),NERD_ENTUSIASTA:pe("M4 18h17v11H6Zm23 0h17l-2 11H27ZM21 22h6M4 18l3-6m37 6-3-6M12 38l12-5 12 5-12 7Z")+Xe(24,39,1),PSICOLOGO:pe("M17 42v-9c-10-7-9-24 3-27 16-5 23 9 19 17l5 6h-7v8H27v5M19 14c-7-5-12 4-6 8m6-8c8-8 16 2 9 7m-8-7v13m-5-7c-5 5 2 11 5 7m0-6c8-5 14 5 6 8"),REPORTER_INVESTIGATIVO:pe("M7 8h24v34H7ZM12 14h13m-13 6h10m-10 6h13m-13 6h8M37 6c-8 0-8 13 0 13s8-13 0-13ZM37 19v15m-7-17v5q7 9 14 0v-5m-12 17h10"),ACALENTADOR:kS+pe("M4 31l8 7 12 5 12-5 8-7M5 31l5-6 10 9m23-3-5-6-10 9"),ALFAIATE:Xe(12,34,6)+Xe(34,34,6)+pe("m16 30 19-25 2 4-14 20L13 5l-2 4 20 21M23 25l-3 5")+Xe(23,25,1),APOSTADOR:pe("m7 14 22-7 11 28-22 7ZM8 14l14 8 18-1M22 22l-4 20m4-20 7-15")+Xe(15,21,1)+Xe(22,34,1)+Xe(32,28,1)+Xe(34,33,1),ATIRADOR_EXIMIO:Xe(24,24,14)+Xe(24,24,7)+pe("M24 2v15m0 14v15M2 24h15m14 0h15M9 5l5 5m20 28 5 5"),BOMBADO:pe("M8 36c3-6 8-6 13-5l-3-8-8-3 2-8 9-5 7 5-2 6-6-1 9 13c10-5 17 2 13 9-8 8-28 6-34-3ZM19 12l7 2m3 16-7 3M10 40l3-6"),BOTICARIO:pe("M8 26h32q-1 15-16 15T8 26ZM16 41h16v4H16ZM25 25l9-19 6 3-9 16M10 17C6 6 16 5 21 4c2 9-2 16-11 13Zm1-1 6-6"),COLECIONADOR:pe("M5 7h38v36H5ZM5 27h38M11 11h8v12h-8ZM26 10h6v4l4 3v6H22v-6l4-3ZM12 32h8v8h-8Zm16 0h9v8h-9Z"),CRIANCA_AMALDICOADA:Xe(13,11,5)+Xe(35,11,5)+_h(24,20,13,12)+_h(24,37,11,8)+pe("M18 18l5 5m0-5-5 5M29 19h3M21 27h6M9 33l7 4m16 0 7-4M24 32v11"),DESOCUPADO:pe("M11 23V12q13-8 26 0v11M6 24q5-6 10 0v10h16V24q5-6 10 0v18H6ZM12 42v3m24-3v3M17 18h14M2 10h5m-3-5 3 2"),HERDEIRO:pe("m9 9 8 7 7-13 7 13 8-7-4 17H13ZM15 21h18M24 30v15m0-5h8m-8 5h5")+Xe(24,31,5),INVENTOR:yh+pe("M20 17h8v9h-8ZM24 13v4m0 9v5m-8-10h4m8 0h5"),LINHA_FRENTE:El+pe("M9 20h30M8 28h32M17 13v7m14-7v7M24 20v8m-8 0v8m16-8v8"),MOCHILEIRO_ORIGEM:Mh+pe("m16 33 7-11 9 11ZM7 8l-3-4m35 4 5-4"),PLAYER:pe("M12 14h24c8 1 13 25 6 26-5 1-8-8-13-8H19c-5 0-8 9-13 8-7-1-2-25 6-26ZM16 18v12m-6-6h12M24 14V7h8")+Xe(33,21,2)+Xe(38,27,2),PROFETA:Eh+pe("M24 2v5m-13 0 3 5m23-5-3 5M24 41v5m-13-5 3-5m23 5-3-5"),REVOLUCIONARIO:pe("M10 45V4m0 2c10-8 19 10 30 2v20c-11 8-20-10-30-2M18 13l5 5 9-5M5 45h10"),VETERINARIO:Xe(24,29,6)+pe("M24 35v3c0 10 18 10 18-3V19M7 5v11c0 14 19 14 19 0V5M4 5h7m12 0h7")+Xe(41,15,4)+pe("M22 29h4m-2-2v4"),BODYBUILDER:pe("M17 24h14M7 13h5v22H7ZM12 9h6v30h-6ZM30 9h6v30h-6Zm6 4h5v22h-5M5 24H2m39 0h5M15 43l9 3 9-3M20 3h8"),BLASTER:pe("M8 16h10v26H8Zm11 0h10v26H19Zm11 0h10v26H30ZM8 25h32m-32 9h32M24 16V9q0-8 10-6m0 0 3 5m-3-5 5-1m-5 1-2-3"),PERSONAL_TRAINER:Xe(24,26,16)+pe("M19 4h10v6H19ZM24 14v12l8 5M9 10l4 4m22 0 4-4M8 42l-4 3m36-3 4 3"),EXORCIZADO:pe("M16 8C-1 18 7 42 23 42m9-3C48 29 40 8 28 7M22 4l-3 9 7-2-4 9M20 26h8v14h-8ZM24 23c-6-5 4-8 0-13 8 7 5 10 0 13Z"),SENSITIVO_REBELDE:Eh+pe("m27 2-9 16 10-2-8 13 9-2-7 18M7 8l5 4m24 24 5 4")});function Lr(i){const e=HS[i];if(!e)throw new Error("Missing origin pictogram: "+i);return`<svg class="origin-icon" data-origin-icon="${i}" viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${e}</svg>`}const GS=Object.freeze({ACADEMICO:"Você pesquisava documentos antigos na biblioteca de uma universidade.",AGENTE_SAUDE:"Você cuidava de pacientes no plantão noturno de um hospital.",ARTISTA:"Você pintava murais pela cidade para pagar as contas.",ATLETA:"Você treinava todos os dias para disputar o campeonato da sua cidade.",CHEF:"Você comandava a cozinha de um pequeno restaurante de bairro.",CRIMINOSO:"Você abria fechaduras para uma quadrilha de ladrões.",CULTISTA_ARREPENDIDO:"Você abandonou uma seita e tentou reconstruir a vida longe dela.",DESGARRADO:"Você mudava de cidade com uma mochila e aceitava trabalhos temporários.",ENGENHEIRO:"Você projetava máquinas e passava as tardes entre ferramentas e plantas.",EXECUTIVO:"Você negociava contratos e resolvia problemas de uma grande empresa.",INVESTIGADOR:"Você procurava pessoas desaparecidas num pequeno escritório de detetive.",LUTADOR:"Você dava aulas de luta numa academia e competia nos fins de semana.",MAGNATA:"Você administrava os negócios da família e frequentava eventos exclusivos.",MERCENARIO:"Você aceitava trabalhos perigosos para quem pudesse pagar.",MILITAR:"Você servia numa unidade militar e participava dos treinamentos de campo.",OPERARIO:"Você consertava equipamentos durante o turno de uma fábrica.",POLICIAL:"Você atendia ocorrências e fazia patrulhas nas ruas do seu bairro.",RELIGIOSO:"Você acolhia os moradores de uma pequena comunidade religiosa.",SERVIDOR_PUBLICO:"Você atendia o público e organizava documentos numa repartição.",TEORICO_CONSPIRACAO:"Você reunia recortes de jornal sobre casos que ninguém conseguia explicar.",TI:"Você mantinha os computadores de uma empresa funcionando.",TRABALHADOR_RURAL:"Você cuidava da plantação e dos animais numa propriedade do interior.",TRAMBIQUEIRO:"Você vivia de pequenos golpes, sempre inventando uma nova história.",UNIVERSITARIO:"Você dividia os dias entre aulas, estágio e trabalhos da faculdade.",VITIMA:"Você tentava retomar a rotina depois de sobreviver a um acontecimento terrível.",AMIGO_ANIMAIS:"Você resgatava animais de rua e ajudava a encontrar novos lares para eles.",ASTRONAUTA:"Você passou anos treinando para integrar uma missão espacial.",CHEF_OUTRO_LADO:"Você começou a investigar uma receita estranha encontrada no caderno da família.",COLEGIAL:"Você estudava de manhã e passava as tardes com os amigos da escola.",COSPLAYER:"Você costurava fantasias e participava de encontros de fãs.",DIPLOMATA:"Você representava uma instituição em reuniões e negociações delicadas.",EXPLORADOR:"Você participava de expedições para conhecer regiões pouco visitadas.",EXPERIMENTO:"Você escapou de um laboratório e tentou descobrir o que fizeram com você.",FANATICO_CRIATURAS:"Você mantinha um caderno cheio de relatos sobre criaturas misteriosas.",FOTOGRAFO:"Você fotografava festas e eventos para pagar o aluguel.",INVENTOR_PARANORMAL:"Você montava aparelhos para tentar registrar fenômenos inexplicáveis.",JOVEM_MISTICO:"Você lia cartas para os amigos e colecionava histórias sobre o oculto.",LEGISTA_NOTURNO:"Você examinava corpos no turno da noite de um instituto médico-legal.",MATEIRO:"Você guiava viajantes pelas trilhas e matas da região onde cresceu.",MERGULHADOR:"Você trabalhava inspecionando embarcações debaixo d’água.",MOTORISTA:"Você atravessava estradas fazendo entregas entre cidades.",NERD_ENTUSIASTA:"Você organizava encontros para conversar sobre seu assunto favorito.",PSICOLOGO:"Você atendia pessoas num consultório e ouvia suas histórias.",REPORTER_INVESTIGATIVO:"Você seguia denúncias anônimas para escrever reportagens sobre gente poderosa.",ACALENTADOR:"Você acolhia vizinhos que precisavam conversar depois de um dia difícil.",ALFAIATE:"Você ajustava roupas e costurava peças sob medida numa pequena oficina.",APOSTADOR:"Você frequentava mesas de cartas e apostava parte do que ganhava.",ATIRADOR_EXIMIO:"Você treinava tiro esportivo e participava de competições locais.",BOMBADO:"Você passava boa parte do tempo na academia, seguindo uma rotina de treino.",BOTICARIO:"Você preparava remédios e misturas numa pequena botica.",COLECIONADOR:"Você visitava feiras de antiguidades em busca de objetos incomuns.",CRIANCA_AMALDICOADA:"Você cresceu ouvindo a família contar histórias sobre coisas estranhas ao seu redor.",DESOCUPADO:"Você fazia bicos quando precisava e passava o tempo explorando seus interesses.",HERDEIRO:"Você recebeu uma herança de um parente que quase não conhecia.",INVENTOR:"Você desmontava aparelhos velhos para construir suas próprias invenções.",LINHA_FRENTE:"Você trabalhava protegendo pessoas em lugares onde havia perigo.",MOCHILEIRO_ORIGEM:"Você viajava de carona, conhecendo pessoas e dormindo onde conseguia.",PLAYER:"Você jogava com os amigos e participava de pequenos torneios.",PROFETA:"Você anotava sonhos estranhos num caderno que levava a todo lugar.",REVOLUCIONARIO:"Você organizava protestos para mudar uma situação injusta na sua comunidade.",VETERINARIO:"Você atendia animais numa clínica e ajudava um abrigo nos fins de semana.",BODYBUILDER:"Você se preparava para subir ao palco de uma competição de fisiculturismo.",BLASTER:"Você trabalhava com demolições e acompanhava a preparação de explosivos.",PERSONAL_TRAINER:"Você montava treinos e acompanhava os alunos de uma academia.",EXORCIZADO:"Você tentou retomar a rotina depois de passar por um exorcismo.",SENSITIVO_REBELDE:"Você escondia suas percepções estranhas de uma família que não acreditava."});function iu(i){return GS[i.code]??""}const oi=Object.freeze([{code:"ACADEMICO",label:"Acadêmico",source:"Livro Base",fixedSkills:["CIENCIAS","INVESTIGACAO"],variableSkillCount:0,professionRequired:!1,powerName:"Saber é Poder"},{code:"AGENTE_SAUDE",label:"Agente de Saúde",source:"Livro Base",fixedSkills:["INTUICAO","MEDICINA"],variableSkillCount:0,professionRequired:!1,powerName:"Técnica Medicinal"},{code:"ARTISTA",label:"Artista",source:"Livro Base",fixedSkills:["ARTES","ENGANACAO"],variableSkillCount:0,professionRequired:!1,powerName:"Magnum Opus"},{code:"ATLETA",label:"Atleta",source:"Livro Base",fixedSkills:["ACROBACIA","ATLETISMO"],variableSkillCount:0,professionRequired:!1,powerName:"110%"},{code:"CHEF",label:"Chef",source:"Livro Base",fixedSkills:["FORTITUDE","PROFISSAO"],variableSkillCount:0,professionRequired:!0,powerName:"Prato do Dia"},{code:"CRIMINOSO",label:"Criminoso",source:"Livro Base",fixedSkills:["CRIME","FURTIVIDADE"],variableSkillCount:0,professionRequired:!1,powerName:"Artifício"},{code:"CULTISTA_ARREPENDIDO",label:"Cultista Arrependido",source:"Livro Base",fixedSkills:["OCULTISMO","RELIGIAO"],variableSkillCount:0,professionRequired:!1,powerName:"Traços do Outro Lado"},{code:"DESGARRADO",label:"Desgarrado",source:"Livro Base",fixedSkills:["FORTITUDE","SOBREVIVENCIA"],variableSkillCount:0,professionRequired:!1,powerName:"Calejado"},{code:"ENGENHEIRO",label:"Engenheiro",source:"Livro Base",fixedSkills:["PROFISSAO","TECNOLOGIA"],variableSkillCount:0,professionRequired:!0,powerName:"Ferramenta Favorita"},{code:"EXECUTIVO",label:"Executivo",source:"Livro Base",fixedSkills:["DIPLOMACIA","PROFISSAO"],variableSkillCount:0,professionRequired:!0,powerName:"Processo Otimizado"},{code:"INVESTIGADOR",label:"Investigador",source:"Livro Base",fixedSkills:["INVESTIGACAO","PERCEPCAO"],variableSkillCount:0,professionRequired:!1,powerName:"Faro para Pistas"},{code:"LUTADOR",label:"Lutador",source:"Livro Base",fixedSkills:["LUTA","REFLEXOS"],variableSkillCount:0,professionRequired:!1,powerName:"Lutador Exímio"},{code:"MAGNATA",label:"Magnata",source:"Livro Base",fixedSkills:["DIPLOMACIA","PILOTAGEM"],variableSkillCount:0,professionRequired:!1,powerName:"Ajudante Fiel"},{code:"MERCENARIO",label:"Mercenário",source:"Livro Base",fixedSkills:["INICIATIVA","INTIMIDACAO"],variableSkillCount:0,professionRequired:!1,powerName:"Posição de Combate"},{code:"MILITAR",label:"Militar",source:"Livro Base",fixedSkills:["PONTARIA","TATICA"],variableSkillCount:0,professionRequired:!1,powerName:"Em Formação"},{code:"OPERARIO",label:"Operário",source:"Livro Base",fixedSkills:["FORTITUDE","PROFISSAO"],variableSkillCount:0,professionRequired:!0,powerName:"Ferramenta de Trabalho"},{code:"POLICIAL",label:"Policial",source:"Livro Base",fixedSkills:["PERCEPCAO","PONTARIA"],variableSkillCount:0,professionRequired:!1,powerName:"Patrulha"},{code:"RELIGIOSO",label:"Religioso",source:"Livro Base",fixedSkills:["RELIGIAO","VONTADE"],variableSkillCount:0,professionRequired:!1,powerName:"Acalentar"},{code:"SERVIDOR_PUBLICO",label:"Servidor Público",source:"Livro Base",fixedSkills:["INTUICAO","VONTADE"],variableSkillCount:0,professionRequired:!1,powerName:"Espírito Cívico"},{code:"TEORICO_CONSPIRACAO",label:"Teórico da Conspiração",source:"Livro Base",fixedSkills:["INVESTIGACAO","OCULTISMO"],variableSkillCount:0,professionRequired:!1,powerName:"Eu Já Sabia"},{code:"TI",label:"T.I.",source:"Livro Base",fixedSkills:["INVESTIGACAO","TECNOLOGIA"],variableSkillCount:0,professionRequired:!1,powerName:"Motor de Busca"},{code:"TRABALHADOR_RURAL",label:"Trabalhador Rural",source:"Livro Base",fixedSkills:["ADESTRAMENTO","SOBREVIVENCIA"],variableSkillCount:0,professionRequired:!1,powerName:"Desbravador"},{code:"TRAMBIQUEIRO",label:"Trambiqueiro",source:"Livro Base",fixedSkills:["CRIME","ENGANACAO"],variableSkillCount:0,professionRequired:!1,powerName:"Impostor"},{code:"UNIVERSITARIO",label:"Universitário",source:"Livro Base",fixedSkills:["ATUALIDADES","INVESTIGACAO"],variableSkillCount:0,professionRequired:!1,powerName:"Dedicação"},{code:"VITIMA",label:"Vítima",source:"Livro Base",fixedSkills:["REFLEXOS","VONTADE"],variableSkillCount:0,professionRequired:!1,powerName:"Cicatrizes Psicológicas"},{code:"AMIGO_ANIMAIS",label:"Amigo dos Animais",source:"Sobrevivendo ao Horror",fixedSkills:["ADESTRAMENTO","PERCEPCAO"],variableSkillCount:0,professionRequired:!1,powerName:"Companheiro Animal"},{code:"ASTRONAUTA",label:"Astronauta",source:"Sobrevivendo ao Horror",fixedSkills:["CIENCIAS","FORTITUDE"],variableSkillCount:0,professionRequired:!1,powerName:"Acostumado ao Extremo"},{code:"CHEF_OUTRO_LADO",label:"Chef do Outro Lado",source:"Sobrevivendo ao Horror",fixedSkills:["OCULTISMO","PROFISSAO"],variableSkillCount:0,professionRequired:!0,powerName:"Fome do Outro Lado"},{code:"COLEGIAL",label:"Colegial",source:"Sobrevivendo ao Horror",fixedSkills:["ATUALIDADES","TECNOLOGIA"],variableSkillCount:0,professionRequired:!1,powerName:"Poder da Amizade"},{code:"COSPLAYER",label:"Cosplayer",source:"Sobrevivendo ao Horror",fixedSkills:["ARTES","VONTADE"],variableSkillCount:0,professionRequired:!1,powerName:"Não é fantasia, é cosplay!"},{code:"DIPLOMATA",label:"Diplomata",source:"Sobrevivendo ao Horror",fixedSkills:["ATUALIDADES","DIPLOMACIA"],variableSkillCount:0,professionRequired:!1,powerName:"Conexões"},{code:"EXPLORADOR",label:"Explorador",source:"Sobrevivendo ao Horror",fixedSkills:["FORTITUDE","SOBREVIVENCIA"],variableSkillCount:0,professionRequired:!1,powerName:"Manual do Sobrevivente"},{code:"EXPERIMENTO",label:"Experimento",source:"Sobrevivendo ao Horror",fixedSkills:["ATLETISMO","FORTITUDE"],variableSkillCount:0,professionRequired:!1,powerName:"Mutação"},{code:"FANATICO_CRIATURAS",label:"Fanático por Criaturas",source:"Sobrevivendo ao Horror",fixedSkills:["INVESTIGACAO","OCULTISMO"],variableSkillCount:0,professionRequired:!1,powerName:"Conhecimento Oculto"},{code:"FOTOGRAFO",label:"Fotógrafo",source:"Sobrevivendo ao Horror",fixedSkills:["ARTES","PERCEPCAO"],variableSkillCount:0,professionRequired:!1,powerName:"Através da Lente"},{code:"INVENTOR_PARANORMAL",label:"Inventor Paranormal",source:"Sobrevivendo ao Horror",fixedSkills:["PROFISSAO","VONTADE"],variableSkillCount:0,professionRequired:!0,powerName:"Invenção Paranormal"},{code:"JOVEM_MISTICO",label:"Jovem Místico",source:"Sobrevivendo ao Horror",fixedSkills:["OCULTISMO","RELIGIAO"],variableSkillCount:0,professionRequired:!1,powerName:"A Culpa é das Estrelas"},{code:"LEGISTA_NOTURNO",label:"Legista do Turno da Noite",source:"Sobrevivendo ao Horror",fixedSkills:["CIENCIAS","MEDICINA"],variableSkillCount:0,professionRequired:!1,powerName:"Luto Habitual"},{code:"MATEIRO",label:"Mateiro",source:"Sobrevivendo ao Horror",fixedSkills:["PERCEPCAO","SOBREVIVENCIA"],variableSkillCount:0,professionRequired:!1,powerName:"Mapa Celeste"},{code:"MERGULHADOR",label:"Mergulhador",source:"Sobrevivendo ao Horror",fixedSkills:["ATLETISMO","FORTITUDE"],variableSkillCount:0,professionRequired:!1,powerName:"Fôlego de Nadador"},{code:"MOTORISTA",label:"Motorista",source:"Sobrevivendo ao Horror",fixedSkills:["PILOTAGEM","REFLEXOS"],variableSkillCount:0,professionRequired:!1,powerName:"Mãos no Volante"},{code:"NERD_ENTUSIASTA",label:"Nerd Entusiasta",source:"Sobrevivendo ao Horror",fixedSkills:["CIENCIAS","TECNOLOGIA"],variableSkillCount:0,professionRequired:!1,powerName:"O Inteligentão"},{code:"PSICOLOGO",label:"Psicólogo",source:"Sobrevivendo ao Horror",fixedSkills:["INTUICAO","PROFISSAO"],variableSkillCount:0,professionRequired:!0,powerName:"Terapia"},{code:"REPORTER_INVESTIGATIVO",label:"Repórter Investigativo",source:"Sobrevivendo ao Horror",fixedSkills:["ATUALIDADES","INVESTIGACAO"],variableSkillCount:0,professionRequired:!1,powerName:"Encontrar a Verdade"},{code:"ACALENTADOR",label:"Acalentador",source:"Suplemento Órion",fixedSkills:["DIPLOMACIA","INTUICAO"],variableSkillCount:0,professionRequired:!1,powerName:"Apoio Emocional"},{code:"ALFAIATE",label:"Alfaiate",source:"Suplemento Órion",fixedSkills:["ARTES","PROFISSAO"],variableSkillCount:0,professionRequired:!0,powerName:"Fada Madrinha"},{code:"APOSTADOR",label:"Apostador",source:"Suplemento Órion",fixedSkills:["CRIME","ENGANACAO"],variableSkillCount:0,professionRequired:!1,powerName:"Carta na Manga"},{code:"ATIRADOR_EXIMIO",label:"Atirador Exímio",source:"Suplemento Órion",fixedSkills:["PERCEPCAO","PONTARIA"],variableSkillCount:0,professionRequired:!1,powerName:"Precisão Mortal"},{code:"BOMBADO",label:"Bombado",source:"Suplemento Órion",fixedSkills:["ATLETISMO","FORTITUDE"],variableSkillCount:0,professionRequired:!1,powerName:"AESTHETIC!"},{code:"BOTICARIO",label:"Boticário",source:"Suplemento Órion",fixedSkills:["CIENCIAS","MEDICINA"],variableSkillCount:0,professionRequired:!1,powerName:"Medicina Amarga"},{code:"COLECIONADOR",label:"Colecionador",source:"Suplemento Órion",fixedSkills:["OCULTISMO","SOBREVIVENCIA"],variableSkillCount:0,professionRequired:!1,powerName:"Recompensa de Espólios"},{code:"CRIANCA_AMALDICOADA",label:"Criança Amaldiçoada",source:"Suplemento Órion",fixedSkills:["OCULTISMO","VONTADE"],variableSkillCount:0,professionRequired:!1,powerName:"Feito de Medo"},{code:"DESOCUPADO",label:"Desocupado",source:"Suplemento Órion",fixedSkills:["ATUALIDADES"],variableSkillCount:1,professionRequired:!1,powerName:"Conhecimento Específico"},{code:"HERDEIRO",label:"Herdeiro",source:"Suplemento Órion",fixedSkills:["ATUALIDADES","OCULTISMO"],variableSkillCount:0,professionRequired:!1,powerName:"Herança"},{code:"INVENTOR",label:"Inventor",source:"Suplemento Órion",fixedSkills:["INTUICAO","PROFISSAO"],variableSkillCount:0,professionRequired:!0,powerName:"Gambiarra Aprimorada"},{code:"LINHA_FRENTE",label:"Linha de Frente",source:"Suplemento Órion",fixedSkills:["FORTITUDE","LUTA"],variableSkillCount:0,professionRequired:!1,powerName:"O Tanque"},{code:"MOCHILEIRO_ORIGEM",label:"Mochileiro",source:"Suplemento Órion",fixedSkills:["DIPLOMACIA","SOBREVIVENCIA"],variableSkillCount:0,professionRequired:!1,powerName:"Bom Mochileiro"},{code:"PLAYER",label:"Player",source:"Suplemento Órion",fixedSkills:["REFLEXOS","TECNOLOGIA"],variableSkillCount:0,professionRequired:!1,powerName:"Easter Egg"},{code:"PROFETA",label:"Profeta",source:"Suplemento Órion",fixedSkills:["INTUICAO","RELIGIAO"],variableSkillCount:0,professionRequired:!1,powerName:"Voz do Além"},{code:"REVOLUCIONARIO",label:"Revolucionário",source:"Suplemento Órion",fixedSkills:["DIPLOMACIA","INTIMIDACAO"],variableSkillCount:0,professionRequired:!1,powerName:"Contra à Opressão"},{code:"VETERINARIO",label:"Veterinário",source:"Suplemento Órion",fixedSkills:["ADESTRAMENTO","MEDICINA"],variableSkillCount:0,professionRequired:!1,powerName:"Animalis"},{code:"BODYBUILDER",label:"Bodybuilder",source:"Suplemento Órion",fixedSkills:["ATLETISMO","FORTITUDE"],variableSkillCount:0,professionRequired:!1,powerName:"Saindo da Jaula"},{code:"BLASTER",label:"Blaster",source:"Suplemento Órion",fixedSkills:["CIENCIAS","PROFISSAO"],variableSkillCount:0,professionRequired:!0,powerName:"Explosão Solidária"},{code:"PERSONAL_TRAINER",label:"Personal Trainer",source:"Suplemento Órion",fixedSkills:["ATLETISMO","CIENCIAS"],variableSkillCount:0,professionRequired:!1,powerName:"Todo Mundo Pagando 10"},{code:"EXORCIZADO",label:"Exorcizado",source:"Arquivos Secretos #7",fixedSkills:["FORTITUDE","OCULTISMO"],variableSkillCount:0,professionRequired:!1,powerName:"O Que Restou"},{code:"SENSITIVO_REBELDE",label:"Sensitivo Rebelde",source:"Arquivos Secretos #7",fixedSkills:["INTUICAO","VONTADE"],variableSkillCount:0,professionRequired:!1,powerName:"Sussurros e Vultos"}].map(i=>Object.freeze({...i,fixedSkills:Object.freeze(i.fixedSkills)}))),zf=Object.freeze([{code:"ACROBACIA",label:"Acrobacia",attribute:"AGI",trainedOnly:!1,usesKit:!1},{code:"ADESTRAMENTO",label:"Adestramento",attribute:"PRE",trainedOnly:!0,usesKit:!1},{code:"ARTES",label:"Artes",attribute:"PRE",trainedOnly:!0,usesKit:!1},{code:"ATLETISMO",label:"Atletismo",attribute:"FOR",trainedOnly:!1,usesKit:!1},{code:"ATUALIDADES",label:"Atualidades",attribute:"INT",trainedOnly:!1,usesKit:!1},{code:"CIENCIAS",label:"Ciências",attribute:"INT",trainedOnly:!0,usesKit:!1},{code:"CRIME",label:"Crime",attribute:"AGI",trainedOnly:!0,usesKit:!0},{code:"DIPLOMACIA",label:"Diplomacia",attribute:"PRE",trainedOnly:!1,usesKit:!1},{code:"ENGANACAO",label:"Enganação",attribute:"PRE",trainedOnly:!1,usesKit:!0},{code:"FORTITUDE",label:"Fortitude",attribute:"VIG",trainedOnly:!1,usesKit:!1},{code:"FURTIVIDADE",label:"Furtividade",attribute:"AGI",trainedOnly:!1,usesKit:!1},{code:"INICIATIVA",label:"Iniciativa",attribute:"AGI",trainedOnly:!1,usesKit:!1},{code:"INTIMIDACAO",label:"Intimidação",attribute:"PRE",trainedOnly:!1,usesKit:!1},{code:"INTUICAO",label:"Intuição",attribute:"PRE",trainedOnly:!1,usesKit:!1},{code:"INVESTIGACAO",label:"Investigação",attribute:"INT",trainedOnly:!1,usesKit:!1},{code:"LUTA",label:"Luta",attribute:"FOR",trainedOnly:!1,usesKit:!1},{code:"MEDICINA",label:"Medicina",attribute:"INT",trainedOnly:!1,usesKit:!0},{code:"OCULTISMO",label:"Ocultismo",attribute:"INT",trainedOnly:!0,usesKit:!1},{code:"PERCEPCAO",label:"Percepção",attribute:"PRE",trainedOnly:!1,usesKit:!1},{code:"PILOTAGEM",label:"Pilotagem",attribute:"AGI",trainedOnly:!0,usesKit:!1},{code:"PONTARIA",label:"Pontaria",attribute:"AGI",trainedOnly:!1,usesKit:!1},{code:"PROFISSAO",label:"Profissão",attribute:"INT",trainedOnly:!0,usesKit:!1},{code:"REFLEXOS",label:"Reflexos",attribute:"AGI",trainedOnly:!1,usesKit:!1},{code:"RELIGIAO",label:"Religião",attribute:"PRE",trainedOnly:!0,usesKit:!1},{code:"SOBREVIVENCIA",label:"Sobrevivência",attribute:"INT",trainedOnly:!1,usesKit:!1},{code:"TATICA",label:"Tática",attribute:"INT",trainedOnly:!0,usesKit:!1},{code:"TECNOLOGIA",label:"Tecnologia",attribute:"INT",trainedOnly:!0,usesKit:!0},{code:"VONTADE",label:"Vontade",attribute:"PRE",trainedOnly:!1,usesKit:!1}].map(Object.freeze)),Ts=Object.freeze([{id:"investigar",label:"Investigar",prompt:"Quero descobrir o que está escondido.",skills:["INVESTIGACAO","PERCEPCAO","CIENCIAS","ATUALIDADES"]},{id:"cuidar",label:"Cuidar",prompt:"Quero cuidar de pessoas ou animais.",skills:["MEDICINA","ADESTRAMENTO","INTUICAO"]},{id:"criar",label:"Criar e consertar",prompt:"Quero criar, consertar ou entender máquinas.",skills:["TECNOLOGIA","PROFISSAO","ARTES"]},{id:"convencer",label:"Convencer",prompt:"Quero lidar com pessoas e influenciar decisões.",skills:["DIPLOMACIA","ENGANACAO","INTIMIDACAO"]},{id:"sobreviver",label:"Sobreviver",prompt:"Quero explorar e me virar em lugares difíceis.",skills:["SOBREVIVENCIA","FORTITUDE","PILOTAGEM"]},{id:"agir",label:"Agir sob pressão",prompt:"Quero uma história ligada à ação e ao esforço físico.",skills:["LUTA","PONTARIA","ATLETISMO","REFLEXOS","INICIATIVA"]},{id:"paranormal",label:"Paranormal",prompt:"Quero um passado próximo do inexplicável.",skills:["OCULTISMO","RELIGIAO"]},{id:"discricao",label:"Agir com discrição",prompt:"Quero alguém que saiba agir sem chamar atenção.",skills:["CRIME","FURTIVIDADE"]}].map(i=>Object.freeze({...i,skills:Object.freeze(i.skills)}))),WS={ACADEMICO:"Uma vida entre estudos, perguntas e conhecimento. Nem toda resposta estava nos livros.",AGENTE_SAUDE:"Cuidar de pessoas fazia parte da sua rotina, muito antes do inexplicável.",ARTISTA:"Você encontrava na arte uma forma de dizer o que palavras comuns não alcançavam.",ATLETA:"Treino, disciplina e movimento marcaram sua vida.",CHEF:"Sua história passava pela cozinha, pelos sabores e pelas pessoas ao redor da mesa.",CRIMINOSO:"Você conheceu caminhos que as pessoas preferem não mencionar.",CULTISTA_ARREPENDIDO:"Seu passado se aproximou de uma crença que você decidiu abandonar.",DESGARRADO:"Você aprendeu a seguir em frente mesmo sem um lugar ao qual pertencer.",ENGENHEIRO:"Entender como as coisas funcionam sempre foi parte da sua maneira de ver o mundo.",EXECUTIVO:"Decisões, negociações e responsabilidades preenchiam seus dias.",INVESTIGADOR:"Você aprendeu a procurar pistas onde outras pessoas só viam detalhes.",LUTADOR:"Seu corpo, seu treino e sua determinação contam parte da sua história.",MAGNATA:"Dinheiro, influência e os círculos que os acompanham fizeram parte da sua vida.",MERCENARIO:"Você já esteve em situações perigosas em troca de pagamento.",MILITAR:"Disciplina e treinamento militar deixaram marcas no seu passado.",OPERARIO:"Seu conhecimento nasceu do trabalho e da prática cotidiana.",POLICIAL:"Sua rotina envolvia ocorrências, investigação e a vida nas ruas.",RELIGIOSO:"A fé foi uma presença importante na sua trajetória.",SERVIDOR_PUBLICO:"Você conheceu o trabalho diário de atender pessoas e fazer instituições funcionarem.",TEORICO_CONSPIRACAO:"Você suspeitava que havia algo por trás das versões oficiais.",TI:"Computadores, sistemas e informação faziam parte do seu cotidiano.",TRABALHADOR_RURAL:"Sua vida estava ligada à terra, aos animais e aos ritmos do campo.",TRAMBIQUEIRO:"Você aprendeu a sair de situações difíceis com conversa e esperteza.",UNIVERSITARIO:"Estudos, descobertas e uma vida ainda em construção compunham sua rotina.",VITIMA:"Algo que você viveu deixou marcas. Sua história continua para além delas.",AMIGO_ANIMAIS:"Sua relação com os animais sempre teve um lugar especial na sua vida.",ASTRONAUTA:"Você construiu uma trajetória ligada ao espaço e aos seus desafios.",CHEF_OUTRO_LADO:"A cozinha e o inexplicável se encontram na ideia desse passado.",COLEGIAL:"Sua história começou entre aulas, amizades e descobertas da vida escolar.",COSPLAYER:"Criar e interpretar outras figuras era uma forma de expressão para você.",DIPLOMATA:"Sua experiência passava por diálogo, negociações e relações entre pessoas.",EXPLORADOR:"Lugares desconhecidos e a vontade de descobrir marcaram sua trajetória.",EXPERIMENTO:"Uma experiência incomum faz parte da história que você quer contar.",FANATICO_CRIATURAS:"O interesse por criaturas e pelo desconhecido ocupava seus pensamentos.",FOTOGRAFO:"Você aprendeu a perceber o mundo por meio de enquadramentos e imagens.",INVENTOR_PARANORMAL:"Criar coisas e se aproximar do inexplicável se cruzam no seu passado.",JOVEM_MISTICO:"Crenças e sinais incomuns acompanharam suas primeiras descobertas.",LEGISTA_NOTURNO:"Seu trabalho passava por perguntas que os mortos deixavam para os vivos.",MATEIRO:"Você se acostumou a observar caminhos, rastros e a vida fora das cidades.",MERGULHADOR:"Seu passado está ligado às profundezas e à experiência de mergulhar.",MOTORISTA:"Estradas, trajetos e o tempo ao volante fizeram parte da sua rotina.",NERD_ENTUSIASTA:"Seus interesses renderam horas de estudo, curiosidade e dedicação.",PSICOLOGO:"Ouvir pessoas e buscar compreender suas experiências marcou sua vida.",REPORTER_INVESTIGATIVO:"Você buscava histórias, fontes e os fatos por trás das aparências.",ACALENTADOR:"Acolher pessoas e estar presente para elas era parte da sua história.",ALFAIATE:"Seu trabalho transformava tecido, medidas e ideias em vestimentas.",APOSTADOR:"Jogos, apostas e decisões arriscadas atravessaram seu passado.",ATIRADOR_EXIMIO:"Precisão e treinamento de tiro fazem parte da história que você quer contar.",BOMBADO:"A dedicação ao treino físico deixou marcas na sua rotina.",BOTICARIO:"Preparos, ingredientes e cuidados faziam parte do seu conhecimento.",COLECIONADOR:"Você reunia objetos e histórias que tinham um significado particular.",CRIANCA_AMALDICOADA:"Um passado de infância atravessado pelo inexplicável compõe essa ideia de história.",DESOCUPADO:"Sua trajetória não cabe facilmente em uma profissão ou rotina definida.",HERDEIRO:"O que veio antes de você deixou uma herança na sua história.",INVENTOR:"Você procurava soluções e gostava de transformar ideias em coisas.",LINHA_FRENTE:"Estar perto do perigo faz parte da história que você quer contar.",MOCHILEIRO_ORIGEM:"Viagens, encontros e caminhos abertos marcaram sua vida.",PLAYER:"Jogos e suas descobertas fazem parte dos seus interesses.",PROFETA:"Sua história se aproxima da fé e de sinais difíceis de explicar.",REVOLUCIONARIO:"Mudar a realidade ao seu redor era uma motivação importante para você.",VETERINARIO:"Cuidar da saúde dos animais fazia parte da sua vida.",BODYBUILDER:"Construir o próprio corpo era um projeto feito de rotina e dedicação.",BLASTER:"Seu interesse por explosivos faz parte da ideia desse passado.",PERSONAL_TRAINER:"Você ajudava outras pessoas a desenvolver o corpo por meio do treino.",EXORCIZADO:"Um exorcismo atravessa a história que você quer contar.",SENSITIVO_REBELDE:"Percepções incomuns e uma postura de questionamento atravessam essa ideia de passado."},XS={AGENTE_SAUDE:"médico médica enfermeiro enfermeira hospital",TI:"computador informática hacker programador programação",RELIGIOSO:"padre pastor freira igreja",OPERARIO:"fábrica construção trabalhador",INVESTIGADOR:"detetive pistas mistério",TRABALHADOR_RURAL:"fazenda campo agricultor",ACALENTADOR:"acolhimento apoio",VETERINARIO:"bicho pet animal",BOTICARIO:"remédio farmácia",PERSONAL_TRAINER:"academia exercício"};function Th(i){return String(i??"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLocaleLowerCase("pt-BR").replace(/[^a-z0-9]+/g," ").trim()}function eo(i){return zf.find(e=>e.code===i)?.label??i}function Vf(i){return WS[i.code]??"Escolha esta origem para explorar uma possibilidade para o seu passado."}function qS(i){return Ts.filter(e=>i.fixedSkills.some(t=>e.skills.includes(t)))}function Ah({query:i="",interest:e="",source:t="",skill:n=""}={}){const r=Th(i).split(" ").filter(Boolean);return oi.filter(s=>{const a=Th([s.label,s.powerName,s.source,Vf(s),iu(s),XS[s.code]??"",...s.fixedSkills.map(eo)].join(" "));return(!t||s.source===t)&&(!n||s.fixedSkills.includes(n))&&(!e||qS(s).some(o=>o.id===e))&&r.every(o=>a.includes(o))}).sort((s,a)=>s.label.localeCompare(a.label,"pt-BR"))}const YS=Object.freeze({ACROBACIA:["Equilíbrio e movimentos delicados.","Atravessar uma viga ou escapar de uma queda."],ADESTRAMENTO:["Entender e conduzir animais.","Acalmar um cão assustado ou orientar um animal treinado."],ARTES:["Criar e reconhecer expressões artísticas.","Identificar uma obra ou fazer uma apresentação."],ATLETISMO:["Correr, saltar, nadar e escalar.","Subir um muro para alcançar uma testemunha."],ATUALIDADES:["Saber o que acontece no mundo.","Lembrar uma notícia ou reconhecer uma pessoa conhecida."],CIENCIAS:["Analisar fenômenos e conhecimentos científicos.","Reconhecer uma substância ou examinar uma amostra."],CRIME:["Executar tarefas discretas e técnicas de invasão.","Abrir uma fechadura ou lidar com um mecanismo de segurança."],DIPLOMACIA:["Conversar, negociar e mediar conflitos.","Convencer uma testemunha a colaborar sem ameaçá-la."],ENGANACAO:["Mentir, disfarçar intenções e criar distrações.","Sustentar uma identidade falsa durante uma investigação."],FORTITUDE:["Resistir a desgaste e agressões ao corpo.","Suportar uma toxina ou um esforço prolongado."],FURTIVIDADE:["Passar despercebido.","Cruzar um corredor sem alertar quem está vigiando."],INICIATIVA:["Reagir quando o perigo começa.","Agir rapidamente quando uma emboscada é revelada."],INTIMIDACAO:["Impor presença por meio de ameaças.","Fazer um agressor hesitar diante da sua postura."],INTUICAO:["Perceber intenções e sinais de comportamento.","Notar que uma resposta ensaiada esconde alguma coisa."],INVESTIGACAO:["Encontrar pistas e conectar informações.","Reconstituir o que aconteceu numa sala revirada."],LUTA:["Atacar em combate corpo a corpo.","Usar os punhos ou uma arma de contato."],MEDICINA:["Prestar cuidados e reconhecer problemas de saúde.","Socorrer um aliado ou examinar um ferimento."],OCULTISMO:["Reconhecer sinais e conhecimentos do paranormal.","Relacionar um símbolo a um ritual conhecido."],PERCEPCAO:["Notar detalhes com os sentidos.","Ouvir passos atrás de uma porta ou avistar uma ameaça."],PILOTAGEM:["Controlar veículos em situações difíceis.","Manter o carro sob controle durante uma perseguição."],PONTARIA:["Atacar à distância.","Mirar com uma arma de fogo ou arremessar uma arma."],PROFISSAO:["Aplicar o conhecimento de uma ocupação específica.","Usar Profissão (mecânico) para trabalhar num motor."],REFLEXOS:["Reagir fisicamente a perigos imediatos.","Desviar de uma armadilha que acabou de disparar."],RELIGIAO:["Conhecer práticas, crenças e tradições religiosas.","Entender uma cerimônia ou reconhecer uma referência sagrada."],SOBREVIVENCIA:["Orientar-se e enfrentar ambientes hostis.","Seguir rastros ou encontrar abrigo numa mata."],TATICA:["Entender e organizar situações de confronto.","Avaliar acessos e posições antes de uma entrada arriscada."],TECNOLOGIA:["Lidar com computadores e sistemas eletrônicos.","Analisar um dispositivo ou recuperar informações digitais."],VONTADE:["Resistir a pressões e ameaças à mente.","Manter a determinação diante de uma influência assustadora."]});function jS(i){const[e,t]=YS[i]||["Conhecimento do personagem.",""];return{purpose:e,example:t}}const si=i=>String(i??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]);function $S(i){if(i.length<2)return`<div class="comparison-missing">${i[0]?Lr(i[0].code)+`<h3>${si(i[0].label)}</h3>`:""}<p>Escolha outra origem para ver as diferenças.</p><button type="button" class="ink-primary" data-compare-browse>Escolher outra origem</button></div>`;const e=i[0].fixedSkills.filter(n=>i[1].fixedSkills.includes(n)),t=(n,r)=>`<tr><th scope="row">${n}</th>${i.map(s=>`<td>${r(s)}</td>`).join("")}</tr>`;return`<p class="comparison-intro">Compare o passado e os conhecimentos que cada origem traz. Sua classe será escolhida depois.</p><table class="comparison-table"><thead><tr><th scope="col"><span class="sr-only">O que muda</span></th>${i.map(n=>`<th scope="col"><div class="comparison-origin-heading">${Lr(n.code)}<h3>${si(n.label)}</h3></div></th>`).join("")}</tr></thead><tbody>${t("Um exemplo de passado",n=>`<p>${si(iu(n))}</p>`)}${t("Você saberia…",n=>n.fixedSkills.map(r=>`<div class="comparison-skill"><strong>${si(eo(r))}${e.includes(r)?"<small>Em comum</small>":""}</strong><p>${si(jS(r).purpose)}</p></div>`).join("")+(n.variableSkillCount?`<p>+${n.variableSkillCount} perícia(s) à escolha.</p>`:""))}${t("Habilidade da origem",n=>`<strong>${si(n.powerName)}</strong>${n.professionRequired?"<p>Você também define uma profissão.</p>":""}`)}${t("Livro",n=>si(n.source))}<tr><th scope="row"><span class="sr-only">Decidir</span></th>${i.map(n=>`<td><button type="button" class="ink-primary" data-choose-compared="${n.code}">Escolher ${si(n.label)}</button><button type="button" class="ink-link" data-remove-compare="${n.code}">Retirar ${si(n.label)}</button></td>`).join("")}</tr></tbody></table>`}function KS(i,{reducedMotion:e=!1}={}){let t=!1,n=!1,r=[];const s=i.querySelector(".paper-content"),a=i.querySelector(".paper-landing"),o=i.querySelector(".physical-sheet"),l=document.createElement("div");l.className="paper-fold-light",l.setAttribute("aria-hidden","true"),a.append(l);async function c(d,u,h){const p=d.animate(u,h);r.push(p),await p.finished.catch(()=>{}),p.cancel()}return{get busy(){return t},async turn(d,{backward:u=!1,focus:h=null}={}){if(t||n)return!1;t=!0,i.inert=!0,i.dataset.turn="out",o.setAttribute("aria-busy","true");const p=u?-1:1;try{return e||await c(s,[{opacity:1,transform:"none"},{opacity:0,transform:`perspective(1400px) translateX(${-p*24}px) rotateY(${-p*7}deg)`}],{duration:220,easing:"cubic-bezier(.4,0,.7,1)",fill:"forwards"}),s.style.opacity="0",n||(await d(),n)?!1:(i.dataset.turn="in",s.style.opacity="1",await Promise.all([c(s,e?[{opacity:0},{opacity:1}]:[{opacity:0,transform:`perspective(1400px) translateX(${p*28}px) rotateY(${p*9}deg)`},{opacity:1,transform:"none"}],{duration:e?100:390,easing:"cubic-bezier(.16,.8,.22,1)",fill:"both"}),...e?[]:[c(l,[{opacity:0,transform:`translateX(${p*80}%)`},{opacity:.8,offset:.35},{opacity:0,transform:`translateX(${-p*80}%)`}],{duration:500,easing:"ease-out"})]]),!0)}finally{n||(i.inert=!1,s.style.opacity="",delete i.dataset.turn,o.setAttribute("aria-busy","false"),h?.()?.focus({preventScroll:!0})),r=[],t=!1}},dispose(){n=!0,r.forEach(d=>d.cancel()),l.remove()}}}async function ZS(i,{reducedMotion:e=!1}={}){const t=[...i.querySelectorAll(".workshop-plank")];i.dataset.phase="landing",e?t.forEach(s=>s.style.transform="none"):await Promise.all(t.map(async(s,a)=>{const o=a%2?1:-1,l=s.animate([{transform:`translate3d(${o*4}%, -120vh, 340px) rotateX(58deg) rotateZ(${o*2.5}deg)`,opacity:0,easing:"cubic-bezier(.48,0,.8,.65)"},{transform:`translate3d(0, 7px, 0) rotateX(-1deg) rotateZ(${o*.12}deg)`,opacity:1,offset:.69,easing:"ease-out"},{transform:"translate3d(0,-3px,0) rotateX(.5deg)",offset:.83},{transform:"none",opacity:1}],{duration:880+a*22,delay:a*65,fill:"both"});await l.finished.catch(()=>{}),s.style.transform="none",l.cancel()})),document.documentElement.dataset.paperActive="1",i.dataset.phase="paper";const n=i.querySelector(".paper-landing"),r=n.animate(e?[{opacity:0},{opacity:1}]:[{transform:"translate3d(0,-90vh,180px) rotateX(25deg) rotateZ(-3deg)",opacity:0,easing:"cubic-bezier(.32,0,.64,.78)"},{transform:"translate3d(0,4px,0) rotateX(-1deg) rotateZ(.3deg)",opacity:1,offset:.78},{transform:"translate3d(0,-1px,0) rotateZ(-.1deg)",offset:.9},{transform:"none",opacity:1}],{duration:e?120:820,fill:"both"});await r.finished.catch(()=>{}),n.style.opacity="1",r.cancel()}const an=Object.freeze([{code:"COMBATENTE",label:"Combatente",atlas:0,theme:"Confronto e proteção",summary:"Treinamento para enfrentar ameaças de forma direta.",strengths:["Mais Pontos de Vida na base.","Treinamento voltado a armas e confronto."],limits:["Menos escolhas livres de perícias na base.","Menos Esforço e Sanidade na base."],example:"Você era segurança e passou a treinar para enfrentar as ameaças que antes tentava conter.",base:{pv:20,pe:2,san:12,freeSkills:1}},{code:"ESPECIALISTA",label:"Especialista",atlas:1,theme:"Perícias e soluções",summary:"Versatilidade para investigar e resolver problemas com técnica.",strengths:["Mais perícias livres na base.","Versatilidade em tarefas especializadas."],limits:["Base de Vida abaixo do Combatente.","Base de Esforço abaixo do Ocultista."],example:"Você era técnico de manutenção e usava seu conhecimento para investigar casos estranhos.",base:{pv:16,pe:3,san:16,freeSkills:7}},{code:"OCULTISTA",label:"Ocultista",atlas:2,theme:"Rituais e paranormal",summary:"Estudo e uso do paranormal por meio de rituais.",strengths:["Mais Esforço e Sanidade na base.","Acesso a rituais pela classe."],limits:["Menor base de Pontos de Vida.","Rituais exigem gerenciar custos e condições."],example:"Você era pesquisador e começou a estudar rituais ao encontrar registros do Outro Lado.",base:{pv:12,pe:4,san:20,freeSkills:3}}].map(i=>Object.freeze({...i,base:Object.freeze(i.base),strengths:Object.freeze(i.strengths),limits:Object.freeze(i.limits)})));function ru(i){return an.find(e=>e.code===i)??null}function wh(i){return(i%an.length+an.length)%an.length}function Rh(i,e,t){const n=(i*120-e)*Math.PI/180,r=(Math.cos(n)+1)/2;return{x:Math.sin(n)*t,y:-30*(1-r),scale:.62+.38*r,z:Math.round(r*100)}}function JS(i,e){const t=ru(e);return!t||!i?.origin?.code||typeof i.name!="string"||!i.name.trim()?null:{...i,step:"class",classCode:t.code}}function Tc(i,e){let t=null,n=-1/0;const r=c=>{c.isPrimary&&(c.pointerType==="touch"||c.pointerType==="pen")&&!i.disabled&&(t={id:c.pointerId,x:c.clientX,y:c.clientY})},s=c=>{t&&c.pointerId===t.id&&Math.hypot(c.clientX-t.x,c.clientY-t.y)>10&&(t=null)},a=()=>{t=null},o=c=>{const d=t;t=null,!(!d||c.pointerId!==d.id||i.disabled||Math.hypot(c.clientX-d.x,c.clientY-d.y)>10)&&i.contains(document.elementFromPoint(c.clientX,c.clientY))&&(n=performance.now(),e(c))},l=c=>{if(c.detail>0&&c.pointerType!=="mouse"&&performance.now()-n<700){c.preventDefault();return}e(c)};return i.addEventListener("pointerdown",r),i.addEventListener("pointermove",s),i.addEventListener("pointerup",o),i.addEventListener("pointercancel",a),i.addEventListener("click",l),()=>{i.removeEventListener("pointerdown",r),i.removeEventListener("pointermove",s),i.removeEventListener("pointerup",o),i.removeEventListener("pointercancel",a),i.removeEventListener("click",l)}}const QS=["combatente","especialista","ocultista"].map(i=>`/assets/workshop/${i}-v20.png`);let Tl=null;function Hf(){return Tl||(Tl=Promise.all(QS.map(i=>{const e=new Image;return e.src=i,e.decode()})).then(()=>!0).catch(()=>!1)),Tl}const Ch=i=>({transform:`translate(-50%,-50%) translate(${i.x}px,${i.y}px) scale(${i.scale})`,zIndex:i.z});function eM(i,{name:e,originLabel:t,classCode:n=null,reducedMotion:r=!1,onConfirm:s=()=>!1,onBack:a=()=>{},onContinue:o=null}){const l={index:Math.max(0,an.findIndex(T=>T.code===n)),rotation:0,busy:!1,confirmed:ru(n)?.code??null};l.rotation=l.index*120;let c=!1,d=[],u=[],h=null,p=0;i.innerHTML=`<div class="paper-chapter"><span>03 / CLASSE</span></div><h1 id="classPaperTitle" tabindex="-1">Escolha sua classe.</h1><p class="paper-intro">Gire ou use as setas. Confirme a classe que você quer.</p>
  <p class="class-context"><strong class="class-arauto"></strong><span aria-hidden="true"> · </span><span class="class-origin"></span></p>
  <div class="class-layout"><section class="class-picker" aria-label="Roleta de classes" aria-roledescription="carrossel"><div class="class-orbit" tabindex="0" aria-label="Use as setas esquerda e direita para explorar as classes"><div class="roulette-ink-ring" aria-hidden="true"></div><svg class="roulette-inscription" viewBox="0 0 400 400" aria-hidden="true"><defs><path id="classInscriptionPath" d="M200 30a170 170 0 1 1-.1 0"/></defs><text textLength="1000" lengthAdjust="spacing"><textPath href="#classInscriptionPath">Acorrentado pela realidade   Acorrentado pela realidade   Acorrentado pela realidade</textPath></text></svg>${an.map(T=>`<button type="button" class="roulette-option" data-class-index="${T.atlas}" aria-label="Ver classe ${T.label}" aria-pressed="false"><span class="class-art-layer" aria-hidden="true"><span class="class-silhouette class-silhouette-${T.atlas}"></span></span><span class="roulette-label">${T.label}</span></button>`).join("")}<p class="class-art-loading" role="status">Preparando as silhuetas…</p></div>
   <div class="class-rotation-controls"><button type="button" class="class-previous ink-link" aria-label="Classe anterior">←</button><button type="button" class="class-spin ink-primary">Girar roleta <span aria-hidden="true">↻</span></button><button type="button" class="class-next ink-link" aria-label="Próxima classe">→</button></div>
   <nav class="class-pages" aria-label="Escolher classe em destaque">${an.map(T=>`<button type="button" data-class-page="${T.atlas}" aria-pressed="false">${T.label}</button>`).join("")}</nav><p class="class-position" aria-live="off"></p>
  </section><section class="class-reading" aria-labelledby="className"><span class="class-theme"></span><h2 id="className"></h2><p class="class-summary"></p><div class="class-tradeoffs"><section><h3>Pontos fortes</h3><ul class="class-strengths"></ul></section><section><h3>Limitações</h3><ul class="class-limits"></ul></section></div><section class="origin-example class-example" aria-label="Exemplo de personagem"><span>Por exemplo…</span><p></p></section>
   <details class="class-comparison"><summary>Comparar as três classes</summary><p>Valores-base da classe. Atributos, origem e outras escolhas alteram o total.</p><div class="class-table-scroll"><table><caption>Bases de recursos e escolhas livres de perícias</caption><thead><tr><th scope="col">Base</th>${an.map(T=>`<th scope="col">${T.label}</th>`).join("")}</tr></thead><tbody>${[["PV","pv"],["PE","pe"],["SAN","san"],["Perícias livres","freeSkills"]].map(([T,D])=>`<tr><th scope="row">${T}</th>${an.map(k=>`<td>${k.base[D]}${D==="freeSkills"?" + INT":""}</td>`).join("")}</tr>`).join("")}</tbody></table></div><dl class="class-resource-key"><div><dt>PV</dt><dd>Pontos de Vida</dd></div><div><dt>PE</dt><dd>Pontos de Esforço</dd></div><div><dt>SAN</dt><dd>Sanidade</dd></div></dl><small>Perícias livres não incluem os treinamentos fixos de classe e origem.</small></details>
   <button type="button" class="confirm-class ink-primary">Escolher esta classe <span aria-hidden="true">→</span></button><p class="class-status" role="status" aria-live="polite"></p><button type="button" class="continue-creation ink-primary" hidden>Continuar para atributos <span aria-hidden="true">→</span></button>
  </section></div><footer class="paper-footer class-footer"><button type="button" class="back-to-origins ink-link">← Rever origem</button><span class="paper-page">ÓRION / 03</span></footer>`;const g=T=>i.querySelector(T),v=g(".class-orbit"),m=[...i.querySelectorAll("[data-class-index]")],f=[...i.querySelectorAll("[data-class-page]")],y=[],_=(T,D)=>y.push(Tc(T,D));g(".class-arauto").textContent=e,g(".class-origin").textContent=t;function x(){return Math.min(210,v.clientWidth*.36)}function R(T){m.forEach((D,k)=>Object.assign(D.style,Ch(Rh(k,T,x()))))}function M(T=!1){const D=an[l.index];g(".class-theme").textContent=D.theme,g("#className").textContent=D.label,g(".class-summary").textContent=D.summary;for(const[z,H]of[[".class-strengths",D.strengths],[".class-limits",D.limits]])g(z).replaceChildren(...H.map(N=>{const B=document.createElement("li");return B.textContent=N,B}));g(".class-example p").textContent=D.example,g(".class-position").textContent=`${l.index+1} / 3 · ${D.label}`,m.forEach((z,H)=>{z.setAttribute("aria-pressed",String(H===l.index)),z.classList.toggle("is-front",H===l.index)}),f.forEach((z,H)=>{z.setAttribute("aria-pressed",String(H===l.index)),z.disabled=l.busy});for(const z of[".class-previous",".class-next",".class-spin"])g(z).disabled=l.busy;const k=g(".confirm-class");if(k.disabled=l.busy||l.confirmed===D.code,k.firstChild.textContent=l.confirmed===D.code?"✓ Classe escolhida ":"Escolher esta classe ",i.setAttribute("aria-busy",String(l.busy)),g(".continue-creation").hidden=!o||l.confirmed!==D.code,g(".continue-creation").disabled=l.busy,T&&!r){for(const z of u)z.cancel();u=["#className",".class-summary",".class-tradeoffs",".class-example"].map((z,H)=>g(z).animate([{opacity:0,transform:"translateY(9px)"},{opacity:1,transform:"translateY(0)"}],{duration:280,delay:H*35,easing:"cubic-bezier(.2,.7,.2,1)"}))}}async function w(T,D=!1){if(c||l.busy||!T)return;const k=l.rotation,z=k+T*120;if(l.busy=!0,M(),g(".class-status").textContent=D?"Girando a roleta…":"Mudando a classe em destaque…",!r){const H=D?72:18,L=x();d=m.map((N,B)=>N.animate(Array.from({length:H+1},(V,Y)=>{const ee=Y/H,$=1-(1-ee)**3;return{offset:ee,...Ch(Rh(B,k+(z-k)*$,L))}}),{duration:D?1550:460,easing:"linear",fill:"forwards"})),await Promise.all(d.map(N=>N.finished.catch(()=>{})))}if(!c){l.rotation=z,l.index=wh(Math.round(z/120)),R(z);for(const H of d)H.cancel();d=[],l.busy=!1,M(!0),g(".class-status").textContent=`${an[l.index].label} em destaque. Confirme se quiser escolher.`}}_(g(".class-previous"),()=>w(-1)),_(g(".class-next"),()=>w(1)),_(g(".class-spin"),()=>w(6+Math.floor(Math.random()*3),!0));for(const T of[...m,...f])_(T,D=>{if(D.type==="click"&&D.detail>0&&D.pointerType!=="mouse"&&performance.now()<p)return;const k=Number(T.dataset.classIndex??T.dataset.classPage),z=wh(k-l.index);w(z===2?-1:z)});v.addEventListener("keydown",T=>{(T.key==="ArrowLeft"||T.key==="ArrowRight")&&(T.preventDefault(),w(T.key==="ArrowLeft"?-1:1))}),v.addEventListener("pointerdown",T=>{T.isPrimary&&(T.pointerType==="touch"||T.pointerType==="pen")&&(h={x:T.clientX,y:T.clientY})}),v.addEventListener("pointerup",T=>{if(!h)return;const D=T.clientX-h.x,k=T.clientY-h.y;h=null,Math.abs(D)>45&&Math.abs(D)>Math.abs(k)*1.3&&(p=performance.now()+400,w(D<0?1:-1))}),v.addEventListener("pointercancel",()=>{h=null}),_(g(".confirm-class"),()=>{if(l.busy||l.confirmed===an[l.index].code)return;const T=an[l.index];s(T.code)?(l.confirmed=T.code,M(),r||m[l.index].animate([{transform:m[l.index].style.transform,opacity:.7},{opacity:1}],{duration:380,easing:"ease-out"}),g(".class-status").textContent=`${T.label} é a classe de ${e}. Você pode revisar sua escolha.`):g(".class-status").textContent="Não foi possível guardar esta classe. Tente novamente."}),_(g(".back-to-origins"),a),_(g(".continue-creation"),()=>{l.confirmed===an[l.index].code&&o?.()});const A=T=>{if(r||T.pointerType!=="mouse")return;const D=v.getBoundingClientRect();v.style.setProperty("--class-look-x",`${((T.clientX-D.x)/D.width-.5)*5}px`),v.style.setProperty("--class-look-y",`${((T.clientY-D.y)/D.height-.5)*3}px`)},S=()=>{v.style.setProperty("--class-look-x","0px"),v.style.setProperty("--class-look-y","0px")};v.addEventListener("pointermove",A),v.addEventListener("pointerleave",S);const b=new ResizeObserver(()=>{l.busy||R(l.rotation)});return b.observe(v),i.dataset.classMotion=r?"reduced":"full",M(!0),R(l.rotation),Hf().then(T=>{c||(i.dataset.classArt=T?"ready":"error",g(".class-art-loading").textContent=T?"":"As silhuetas não carregaram. As descrições continuam disponíveis.",g(".class-art-loading").hidden=T)}),{get state(){return{...l}},dispose(){c=!0,b.disconnect();for(const T of y)T();for(const T of[...d,...u])T.cancel();i.replaceChildren()}}}const tM="/assets/workshop/walnut-v15.png",Gn=i=>String(i??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),nM={investigar:"INVESTIGADOR",cuidar:"AGENTE_SAUDE",criar:"INVENTOR",convencer:"DIPLOMATA",sobreviver:"EXPLORADOR",agir:"LUTADOR",paranormal:"JOVEM_MISTICO",discricao:"CRIMINOSO"};let Tr=null,Al=null;function Gf(){if(!Al){const i=new Image;i.src=tM,Al=i.decode().catch(()=>{})}return Al}function iM(i,{onReturn:e=()=>{},onChoose:t=()=>{},reducedMotion:n=!1,resume:r=!1}={}){if(Tr)return Tr;const s=document.activeElement,a=document.createElement("section"),o={query:"",interest:"",source:"",skill:"",selected:null,compared:[],confirmed:null};let l=ru(i.classCode)?.code??null,c=null,d=null;a.className="paper-workshop",a.setAttribute("aria-label","Ficha de criação: origem"),a.dataset.phase="preparing",a.innerHTML=`<div class="workshop-mist" aria-hidden="true"></div><svg class="workshop-binding" viewBox="0 0 400 400" aria-hidden="true"><defs><path id="workshopBindingPath" d="M200 35a165 165 0 1 1-.1 0"/></defs><text><textPath href="#workshopBindingPath">Acorrentado pela realidade   Acorrentado pela realidade</textPath></text></svg><p class="paper-preparing" role="status">Materializando sua história…</p>
  <div class="workshop-planks" aria-hidden="true">${Array.from({length:6},(F,O)=>`<div class="workshop-plank" style="--plank:${O};--grain:${O*19}%"></div>`).join("")}</div>
  <div class="paper-scroll"><div class="paper-landing"><article class="physical-sheet" aria-labelledby="paperTitle" aria-busy="true">
   <div class="paper-content" inert>
    <header class="paper-header"><div class="paper-imprint"><span>ÓRION</span><small>Ficha do arauto</small></div><button class="paper-return ink-link" type="button">← Voltar à identidade</button></header>
    <section class="origin-chapter-content">
    <div class="paper-chapter"><span>02 / ORIGEM</span></div>
    <h1 id="paperTitle" tabindex="-1">Toda história deixa marcas.</h1>
    <p class="paper-intro">Escolha o passado do seu arauto.</p>
    <div class="paper-identity"><div><span>Nome do arauto</span><strong class="paper-name"></strong></div><div><span>Origem</span><strong class="paper-chosen-name">Ainda por escrever</strong></div></div>
    <nav class="discovery-modes" aria-label="Como explorar as origens"><button type="button" data-mode="explore" aria-pressed="true">Explorar origens</button><button type="button" data-mode="guide" aria-pressed="false">Me ajude a escolher</button></nav>
    <section class="origin-guide" aria-label="Ajuda para escolher uma origem" hidden><h2>Que passado você imagina?</h2><p>Comece por uma ideia.</p><div>${Ts.map(F=>`<button type="button" data-guide="${F.id}" aria-label="${F.prompt}" aria-pressed="false">${Lr(nM[F.id])}<strong>${F.label}</strong><span class="guide-check" aria-hidden="true">✓</span></button>`).join("")}</div></section>
    <section class="origin-tools" aria-label="Buscar e filtrar origens">
     <div class="paper-search"><label for="originSearch">Encontre uma história</label><div><span aria-hidden="true">⌕</span><input id="originSearch" type="search" placeholder="Nome, profissão ou perícia…" autocomplete="off" aria-controls="originResults"><button class="clear-search ink-link" type="button" aria-label="Limpar busca" hidden>×</button></div></div>
     <div class="interest-filters" role="group" aria-label="Filtrar por interesse"><button type="button" data-interest="" aria-pressed="true">Todas</button>${Ts.map(F=>`<button type="button" data-interest="${F.id}" aria-pressed="false">${F.label}</button>`).join("")}</div>
     <details class="advanced-origins"><summary>Filtrar por livro e perícia</summary><div><label>Livro de origem<select id="originSource"><option value="">Todos os livros</option>${[...new Set(oi.map(F=>F.source))].map(F=>`<option>${F}</option>`).join("")}</select></label><label>Perícia associada<select id="originSkill"><option value="">Todas as perícias</option>${zf.map(F=>`<option value="${F.code}">${F.label}</option>`).join("")}</select></label></div></details>
    </section>
    <section class="origin-filter-feedback" id="originFilters" aria-label="Filtros aplicados" hidden><span class="filter-seal" aria-hidden="true">✓</span><div><small>Filtro aplicado</small><strong class="filter-applied-label"></strong><p class="filter-result-count"></p></div><div class="filter-feedback-actions"><button type="button" class="change-interest ink-link">Trocar interesse</button><button type="button" class="reset-filters ink-link">Limpar filtros</button></div></section>
    <aside class="comparison-tray" aria-label="Origens na comparação"><div><strong>Compare dois caminhos</strong><p class="comparison-tray-hint">Use Comparar nas origens que chamarem sua atenção.</p></div><div class="comparison-slots"></div><button class="open-comparison ink-primary" type="button" disabled>Comparar origens (0/2)</button></aside><div class="origin-library"><section class="origin-index" aria-labelledby="originCount"><div class="index-heading"><h2 id="originCount" tabindex="-1"></h2></div><ol id="originResults"></ol><p class="origin-empty" hidden>Nenhuma origem com esses filtros. Tente outra palavra ou limpe os filtros.</p></section>
     <section class="origin-detail" id="originDetail" aria-labelledby="originDetailTitle"><div class="detail-placeholder"><span class="ink-star" aria-hidden="true">✧</span><h2 id="originDetailTitle">Seu passado começa aqui.</h2><small>Abra uma origem para ver um exemplo.</small></div></section></div>
    <footer class="paper-footer"><div><p class="paper-status" role="status" aria-live="polite">Abra uma origem para começar.</p><button type="button" class="origin-next ink-primary" hidden>Continuar para classe <span aria-hidden="true">→</span></button><small class="origin-next-hint" hidden>Confirme a origem aberta para continuar.</small></div><span class="paper-page">ÓRION / 02</span></footer>
    </section><section class="class-chapter" aria-label="Escolha da classe" hidden></section><section class="creation-journey" aria-label="Continuar criação do arauto" hidden></section>
   </div>
  </article></div></div>
  <dialog class="origin-comparison" aria-labelledby="compareTitle"><header><div><small>Duas possibilidades para sua história</small><h2 id="compareTitle">Lado a lado</h2></div><button type="button" class="close-comparison ink-link" aria-label="Fechar comparação">×</button></header><div class="comparison-content"></div></dialog>`,document.body.append(a),document.documentElement.dataset.paperTransition="1",a.querySelector(".paper-name").textContent=i.name;const u=F=>a.querySelector(F),h=u(".paper-status"),p=u("#originResults"),g=u("#originDetail"),v=u(".paper-content"),m=u(".physical-sheet"),f=u("dialog"),y=g.innerHTML;let _=!1,x=0;const R=KS(a,{reducedMotion:n}),M=US(u(".paper-scroll"),{reducedMotion:n});function w(F){i={...F},t(F)}function A(F){h.textContent=F}function S(){const F=u(".origin-next"),O=!!(o.selected&&o.selected!==o.confirmed);F.hidden=!o.confirmed,F.disabled=O,u(".origin-next-hint").hidden=!o.confirmed||!O,F.firstChild.textContent=l?"Rever classe ":"Continuar para classe "}function b(){return d?.save(),d?.dispose(),d=null,c?.dispose(),c=null,u(".class-chapter").hidden=!0,u(".creation-journey").hidden=!0,u(".origin-chapter-content").hidden=!1,a.dataset.chapter="origin",a.setAttribute("aria-label","Ficha de criação: origem"),m.setAttribute("aria-labelledby","paperTitle"),u(".paper-return").textContent="← Voltar à identidade",S(),M.top(x)}function T(){if(!(_||R.busy))return R.turn(b,{backward:!0,focus:()=>u(".origin-next")})}function D(){d?.save(),d?.dispose(),d=null,c?.dispose();const F=oi.find(O=>O.code===o.confirmed);return u(".origin-chapter-content").hidden=!0,u(".creation-journey").hidden=!0,u(".class-chapter").hidden=!1,a.dataset.chapter="class",a.setAttribute("aria-label","Ficha de criação: classe"),m.setAttribute("aria-labelledby","classPaperTitle"),u(".paper-return").textContent="← Voltar às origens",c=eM(u(".class-chapter"),{name:i.name,originLabel:F.label,classCode:l,reducedMotion:n,onBack:T,onContinue:()=>H(),onConfirm(O){const G=JS({...i,origin:{code:F.code,label:F.label,source:F.source}},O);if(!G)return!1;try{return sessionStorage.setItem(Za,JSON.stringify(G)),l=O,w(G),a.dispatchEvent(new CustomEvent("orion:class-chosen",{detail:G,bubbles:!0})),S(),!0}catch{return!1}}}),M.top(0)}function k(){if(!(_||R.busy||!o.confirmed||u(".origin-next").disabled))return a.dataset.chapter==="origin"&&(x=u(".paper-scroll").scrollTop),R.turn(D,{backward:a.dataset.chapter==="journey",focus:()=>u("#classPaperTitle")})}async function z(){const{mountCreationJourney:F}=await vp(async()=>{const{mountCreationJourney:O}=await import("./creation-journey-BlpuVZUr.js");return{mountCreationJourney:O}},__vite__mapDeps([0,1,2,3,4,5,6,7]));_||(c?.dispose(),c=null,d?.dispose(),u(".class-chapter").hidden=!0,u(".origin-chapter-content").hidden=!0,u(".creation-journey").hidden=!1,a.dataset.chapter="journey",a.setAttribute("aria-label","Ficha de criação: decisões do arauto"),m.setAttribute("aria-labelledby","journeyTitle"),u(".paper-return").textContent="← Rever classe",d=F(u(".creation-journey"),{draft:i,onSave:w,onBack:k,onOrigin:T,onTurn:(O,G)=>R.turn(O,G),scroll:()=>M.top(0),reducedMotion:n}),await M.top(0))}async function H(){if(!(_||R.busy||!l))try{await R.turn(z,{focus:()=>u("#journeyTitle")})}catch{const F=u(".class-status");F&&(F.textContent="Não foi possível abrir a próxima etapa. Suas escolhas foram preservadas; tente novamente.")}}function L(){const F=u(".open-comparison");F.textContent=`Comparar origens (${o.compared.length}/2)`,F.disabled=o.compared.length!==2,u(".comparison-tray-hint").textContent=o.compared.length===2?"Duas origens separadas. Veja as diferenças e escolha uma.":o.compared.length===1?"Falta uma origem. Use Comparar em outra opção da lista.":"Use Comparar nas origens que chamarem sua atenção.",u(".comparison-slots").innerHTML=Array.from({length:2},(O,G)=>{const ne=oi.find(xe=>xe.code===o.compared[G]);return ne?`<div class="comparison-slot">${Lr(ne.code)}<span>${Gn(ne.label)}</span><button type="button" data-remove-tray="${ne.code}" aria-label="Retirar ${Gn(ne.label)} da comparação">×</button></div>`:`<div class="comparison-slot is-empty"><span>${G+1}. Escolha uma origem</span></div>`}).join("");for(const O of p.querySelectorAll("[data-compare-origin]")){const G=o.compared.includes(O.dataset.compareOrigin);O.setAttribute("aria-pressed",String(G)),O.querySelector("span").textContent=G?"✓ Comparando":"Comparar"}}function N(F){if(o.compared.includes(F))o.compared=o.compared.filter(O=>O!==F);else if(o.compared.length<2)o.compared.push(F);else{A("A comparação já tem duas origens. Retire uma pelo × para trocar."),M.to(u(".comparison-tray"));return}if(L(),o.selected===F){const O=u(".compare-origin");O&&(O.setAttribute("aria-pressed",String(o.compared.includes(F))),O.textContent=o.compared.includes(F)?"✓ Na comparação":"Comparar esta origem")}A(o.compared.length===2?"Duas origens escolhidas para comparar. Abra Comparar origens.":`${o.compared.length} de 2 origens na comparação.`)}function B(){const F=o.compared.map(O=>oi.find(G=>G.code===O));u(".comparison-content").innerHTML=$S(F)}function V(){for(const F of p.querySelectorAll("[data-origin]"))F.setAttribute("aria-pressed",String(F.dataset.origin===o.selected)),F.querySelector(".origin-row-arrow").textContent=F.dataset.origin===o.selected?"✓":"→"}function Y(){const F=Ah(o);u("#originCount").textContent=`${F.length} ${F.length===1?"origem":"origens"}`,p.innerHTML=F.map(G=>`<li><button type="button" data-origin="${G.code}" aria-pressed="${G.code===o.selected}" aria-controls="originDetail"><span class="origin-row-symbol">${Lr(G.code)}</span><strong>${Gn(G.label)}</strong><span class="origin-row-arrow" aria-hidden="true">${G.code===o.selected?"✓":"→"}</span></button><button type="button" class="origin-compare-toggle" data-compare-origin="${G.code}" aria-label="Comparar ${Gn(G.label)}" aria-pressed="${o.compared.includes(G.code)}"><span>${o.compared.includes(G.code)?"✓ Comparando":"Comparar"}</span></button></li>`).join(""),u(".origin-empty").hidden=F.length>0,u(".reset-filters").hidden=!(o.query||o.interest||o.source||o.skill),u(".clear-search").hidden=!o.query;for(const G of a.querySelectorAll("[data-interest]"))G.setAttribute("aria-pressed",String(G.dataset.interest===o.interest));for(const G of a.querySelectorAll("[data-guide]"))G.setAttribute("aria-pressed",String(G.dataset.guide===o.interest));const O=[Ts.find(G=>G.id===o.interest)?.label,o.query?`Busca: ${o.query}`:"",o.source,o.skill?eo(o.skill):""].filter(Boolean);u("#originFilters").hidden=!O.length,u(".filter-applied-label").textContent=O.join(" · "),u(".filter-result-count").textContent=`${F.length} ${F.length===1?"origem para explorar":"origens para explorar"}`,u(".change-interest").hidden=!o.interest,A(`${F.length} ${F.length===1?"origem encontrada":"origens encontradas"}.${o.selected?" A origem aberta continua disponível para revisão.":""}`)}function ee(){S();const F=oi.find(O=>O.code===o.selected);if(!F){g.innerHTML=y;return}g.innerHTML=`<div class="detail-overline"><button class="back-to-index ink-link" type="button">↑ Voltar à lista</button></div><div class="origin-heading"><div class="origin-portrait">${Lr(F.code)}</div><h2 id="originDetailTitle" tabindex="-1">${Gn(F.label)}</h2></div><section class="origin-example" aria-label="Exemplo de passado"><span>Por exemplo…</span><p>${Gn(iu(F))}</p></section><dl class="origin-facts"><div><dt>Perícias</dt><dd><ul class="origin-skill-chips">${F.fixedSkills.map(O=>`<li>${Gn(eo(O))}</li>`).join("")}${F.variableSkillCount?`<li>+${F.variableSkillCount} à escolha</li>`:""}</ul></dd></div><div><dt>Habilidade</dt><dd>${Gn(F.powerName)}</dd></div></dl>${F.professionRequired?'<p class="origin-choice-note">Exige uma especialidade de Profissão.</p>':""}<details class="origin-more"><summary>Ver contexto e fonte</summary><p class="origin-story">${Gn(Vf(F))}</p><p class="origin-book">${Gn(F.source)}</p><small>O exemplo é só uma inspiração para sua história.</small></details><div class="origin-detail-actions"><button type="button" class="choose-origin ink-primary" ${o.confirmed===F.code?"disabled":""}>${o.confirmed===F.code?"✓ Origem escolhida":"Escolher esta origem"}<span aria-hidden="true">→</span></button><button type="button" class="compare-origin ink-link" aria-pressed="${o.compared.includes(F.code)}">${o.compared.includes(F.code)?"✓ Na comparação":"Comparar esta origem"}</button></div>`,u(".choose-origin").addEventListener("click",()=>{const O={...i,step:"origin",origin:{code:F.code,label:F.label,source:F.source},...l?{classCode:l}:{}};try{sessionStorage.setItem(Za,JSON.stringify(O)),o.confirmed=F.code,u(".paper-chosen-name").textContent=F.label,ee(),Hf(),A(`${F.label} é a origem de ${i.name}. Continue para escolher a classe.`),w(O),a.dispatchEvent(new CustomEvent("orion:origin-chosen",{detail:O,bubbles:!0}))}catch{A("Não foi possível guardar esta escolha. Você pode continuar explorando e tentar novamente.")}}),u(".compare-origin").addEventListener("click",()=>N(F.code)),u(".back-to-index").addEventListener("click",()=>{p.querySelector(`[data-origin="${F.code}"]`)?.focus({preventScroll:!0}),M.to(u(".origin-index"))})}p.addEventListener("click",F=>{const O=F.target.closest("[data-compare-origin]");if(O){N(O.dataset.compareOrigin);return}const G=F.target.closest("[data-origin]");G&&(o.selected=G.dataset.origin,V(),ee(),A(`${oi.find(ne=>ne.code===o.selected).label} aberta. Confira os detalhes antes de escolher.`),matchMedia("(max-width: 760px)").matches&&(u("#originDetailTitle").focus({preventScroll:!0}),M.to(g)))}),u("#originSearch").addEventListener("input",F=>{o.query=F.target.value,Y()}),u(".clear-search").addEventListener("click",()=>{o.query="",u("#originSearch").value="",Y(),u("#originSearch").focus()});function $(F){o.interest=F,Y()}function re(F){for(const O of a.querySelectorAll("[data-mode]"))O.setAttribute("aria-pressed",String(O.dataset.mode==="guide"===F));u(".origin-guide").hidden=!F,u(".origin-tools").hidden=F,u(".origin-library").hidden=F,u("#originFilters").hidden=F||!(o.query||o.interest||o.source||o.skill)}function te(){const F=u("#originFilters").hidden?u(".origin-library"):u("#originFilters");M.to(F),u("#originCount").focus({preventScroll:!0})}for(const F of a.querySelectorAll("[data-interest]"))F.addEventListener("click",()=>$(F.dataset.interest));for(const F of a.querySelectorAll("[data-guide]"))F.addEventListener("click",()=>{Object.assign(o,{query:"",source:"",skill:"",selected:null}),u("#originSearch").value="",u("#originSource").value="",u("#originSkill").value="",$(F.dataset.guide),ee(),re(!1),te(),A(`${Ts.find(O=>O.id===o.interest).label}: filtro aplicado. ${Ah(o).length} origens para explorar.`)});for(const F of a.querySelectorAll("[data-mode]"))F.addEventListener("click",()=>re(F.dataset.mode==="guide"));return u(".change-interest").addEventListener("click",()=>{re(!0),M.to(u(".origin-guide")),a.querySelector(`[data-guide="${o.interest}"]`)?.focus({preventScroll:!0})}),u("#originSource").addEventListener("change",F=>{o.source=F.target.value,Y()}),u("#originSkill").addEventListener("change",F=>{o.skill=F.target.value,Y()}),u(".reset-filters").addEventListener("click",()=>{Object.assign(o,{query:"",interest:"",source:"",skill:""}),u("#originSearch").value="",u("#originSource").value="",u("#originSkill").value="",Y(),te()}),u(".open-comparison").addEventListener("click",()=>{B(),f.showModal()}),u(".comparison-slots").addEventListener("click",F=>{const O=F.target.closest("[data-remove-tray]");O&&N(O.dataset.removeTray)}),u(".comparison-content").addEventListener("click",F=>{const O=F.target.closest("[data-remove-compare]"),G=F.target.closest("[data-choose-compared]");if(O){N(O.dataset.removeCompare),B();return}if(F.target.closest("[data-compare-browse]")){f.close(),M.to(u(".origin-index"));return}G&&(o.selected=G.dataset.chooseCompared,V(),ee(),u(".choose-origin")?.click(),o.confirmed===o.selected&&(f.close(),M.to(g)))}),u(".close-comparison").addEventListener("click",()=>f.close()),Tc(u(".origin-next"),k),Tc(u(".paper-return"),async()=>{if(!(_||R.busy)){if(a.dataset.chapter==="class"){T();return}if(a.dataset.chapter==="journey"){k();return}if(_=!0,R.dispose(),M.dispose(),c?.dispose(),d?.save(),d?.dispose(),a.inert=!0,delete document.documentElement.dataset.paperActive,document.documentElement.dataset.paperTransition="1",!n){const F=[u(".paper-landing").animate([{opacity:1,transform:"none"},{opacity:0,transform:"translateY(-70px) rotateX(6deg)"}],{duration:360,fill:"forwards"}),u(".workshop-planks").animate([{opacity:1},{opacity:0}],{duration:360,delay:120,fill:"forwards"})];await Promise.all(F.map(O=>O.finished.catch(()=>{})))}a.remove(),delete document.documentElement.dataset.paperReady,delete document.documentElement.dataset.paperTransition,Tr=null,e(),s?.focus({preventScroll:!0})}}),i.origin&&oi.some(F=>F.code===i.origin.code)&&(o.selected=o.confirmed=i.origin.code,u(".paper-chosen-name").textContent=oi.find(F=>F.code===o.selected).label,ee()),Y(),L(),S(),a.dataset.chapter="origin",Tr=(async()=>{await Gf(),!_&&(u(".paper-preparing").textContent="",r&&i.character&&l&&await z(),await ZS(a,{reducedMotion:n}),!_&&(a.dataset.phase="ready",v.inert=!1,m.setAttribute("aria-busy","false"),document.documentElement.dataset.paperReady="1",delete document.documentElement.dataset.paperTransition,(a.dataset.chapter==="journey"?u("#journeyTitle"):u("#paperTitle")).focus({preventScroll:!0})))})().catch(F=>{throw a.remove(),Tr=null,delete document.documentElement.dataset.paperActive,delete document.documentElement.dataset.paperReady,delete document.documentElement.dataset.paperTransition,R.dispose(),M.dispose(),F}),Tr}function rM(i,{hands:e,reducedMotion:t=!1,scene:n,camera:r,environment:s}){let a=_S(),o=null,l={x:0,y:0},c=!1,d=null,u=null,h=null;const p=document.createElement("section");p.className="herald-creation",p.setAttribute("aria-label","O nascimento do Marcado"),p.innerHTML=`
 <a class="creation-back" href="index.html?stars=0" aria-label="Voltar ao observatório">←</a>
 <span class="creation-label">O despertar</span>
 <div class="creation-stage">
  <section class="birth-stage" aria-label="O despertar">
   <h1 class="blood-prologue">Tudo começa pelo sangue.</h1>
   <div class="sealed-being"><button class="baby-target" type="button" data-creation-point aria-label="Contemplar a silhueta etérea" aria-controls="markBeing" aria-expanded="false"><span class="sr-only">Acorrentado pela realidade: uma silhueta cercada por sigilos de conhecimento</span><span class="interaction-cue" aria-hidden="true">Despertar</span></button></div>
   <div class="mark-slot"><button class="mark-being" id="markBeing" aria-label="Tornar Marcado" type="button" hidden disabled><span class="mark-sigil" aria-hidden="true">✧</span><span class="mark-title">Tornar Marcado</span><span class="mark-hint">Romper o vínculo</span></button></div>
  </section>
  <form id="identityForm" class="identity-form" hidden>
   <header class="identity-title" hidden><h1>O início de uma história.</h1><p>Escolha uma representação para seu arauto.</p></header>
   <fieldset class="child-choices"><legend class="sr-only">Escolha a silhueta ou não defina gênero</legend>${["menina","menino"].map(L=>`<button type="button" class="child-choice" data-gender="${L}" data-creation-point aria-label="Escolher ${L}" aria-pressed="false"><i class="soul-anchor" aria-hidden="true"></i><span>${L==="menina"?"Menina":"Menino"}<small>Selecionar</small></span></button>`).join("")}</fieldset>
   <div class="identity-controls">
    <div class="identity-fields"><label for="herald-name" class="name-label">Nome do arauto</label><input id="herald-name" name="name" type="text" placeholder="Nomeie seu arauto" maxlength="60" required autocomplete="off" aria-describedby="creationStatus"><label class="undefined-choice"><input type="checkbox" id="undefinedGender">Não definir gênero</label></div>
    <div class="identity-action" hidden><button class="creation-next" type="submit" aria-label="Continuar com esta identidade" hidden disabled><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14m-6-6 6 6-6 6"/></svg></button><span aria-hidden="true">Continuar</span></div>
   </div>
  </form>
 </div>
 <p id="creationStatus" class="creation-status" role="status" aria-live="polite"></p>`,i.append(p);const g=dp(location.href);g.searchParams.set("stars","0"),p.querySelector(".creation-back").href=g.href;const v=p.querySelector(".baby-target"),m=p.querySelector("#markBeing"),f=p.querySelector(".sealed-being"),y=p.querySelector("form"),_=p.querySelector("#herald-name"),x=p.querySelector("#undefinedGender"),R=p.querySelector(".creation-next"),M=p.querySelector("#creationStatus"),w=NS({scene:n,camera:r,panel:p,reducedMotion:t,environment:s});v.disabled=!0,w.ready.then(()=>{i.dataset.creationArt="ready",v.disabled=!1,m.disabled=!1,M.textContent=""}).catch(()=>{i.dataset.creationArt="error",M.textContent="Não foi possível carregar a cena. Recarregue a página."}),new URLSearchParams(location.search).has("debug")&&(window.__orionCreationDebug=w);function A(){p.dataset.phase=a.phase,i.dataset.creationPhase=a.phase,p.querySelector(".creation-label").textContent=a.phase==="identity"?"Identidade":"O despertar",p.querySelector(".identity-title").hidden=a.phase!=="identity",p.querySelector(".birth-stage").hidden=a.phase==="identity",p.querySelector(".identity-action").hidden=a.gender===null,p.querySelector(".blood-prologue").setAttribute("aria-hidden",String(a.phase==="identity"));for(const L of p.querySelectorAll("[data-gender]"))L.setAttribute("aria-pressed",String(L.dataset.gender===a.gender)),L.querySelector("small").textContent=L.dataset.gender===a.gender?"✓ Selecionado":"Selecionar";x.checked=a.gender==="nao-definir",R.hidden=a.gender===null,R.disabled=!Ec(a)||a.continued,w.invalidateLayout()}function S(){o=performance.now(),e.setStarHovered?.(!0)}function b(L){if(w.update(L),e.setStarDirection?.(l.x,l.y),o!==null){const N=wf((L-o)/1e3,t);e.setStarSelection?.(N.progress<1?N:null),N.progress>=1&&(o=null)}}function T(L){l={x:(L.clientX/innerWidth-.5)*2,y:(.5-L.clientY/innerHeight)*2},e.setStarHovered?.(!!L.target.closest("[data-creation-point]")),w.point(l),w.hover(L.target.closest(".baby-target")?"baby":L.target.closest("[data-gender]")?.dataset.gender??null)}p.addEventListener("focusin",L=>{e.setStarHovered?.(L.target.matches(":focus-visible")&&!!L.target.closest("[data-creation-point]")),w.hover(L.target===v?"baby":L.target.dataset.gender??null)}),p.addEventListener("focusout",()=>{e.setStarHovered?.(!1),w.hover(null)}),p.addEventListener("pointerleave",()=>w.hover(null)),v.addEventListener("click",()=>{a.phase==="sealed"&&(a=Er(a,{type:"reveal"}),S(),A(),v.setAttribute("aria-expanded","true"),m.hidden=!1,M.textContent="Acorrentado pela realidade.",m.focus({preventScroll:!0}))}),m.addEventListener("click",async()=>{a.phase==="revealed"&&(Gf(),a=Er(a,{type:"mark"}),A(),o=null,e.setStarSelection?.(null),e.setStarHovered?.(!1),m.disabled=!0,v.inert=!0,y.append(M),y.hidden=!1,y.inert=!0,M.textContent="Os sigilos se desfazem. A alma desperta.",await w.release(),a=Er(a,{type:"released"}),A(),f.hidden=!0,m.hidden=!0,y.hidden=!1,y.inert=!1,M.textContent="Dê um nome ao seu arauto e escolha como deseja representá-lo.",p.querySelector(".child-choice").focus({preventScroll:!0}))});function D(L){a=Er(a,{type:"gender",value:L}),w.select(L),(L==="menina"||L==="menino")&&S(),A(),M.textContent=a.name.trim()?"Sua identidade começa a tomar forma.":"Digite um nome para continuar."}for(const L of p.querySelectorAll("[data-gender]"))L.addEventListener("click",()=>D(L.dataset.gender));x.addEventListener("change",()=>D(x.checked?"nao-definir":null)),_.addEventListener("input",()=>{a=Er(a,{type:"name",value:_.value}),A(),M.textContent=a.gender===null?"Escolha uma silhueta ou não defina gênero.":a.name.trim()?"Sua identidade está pronta para continuar.":"Digite um nome para continuar."}),y.addEventListener("submit",L=>{if(L.preventDefault(),!Ec(a)||a.continued){a.name.trim()||(_.setCustomValidity("Dê um nome ao seu arauto."),_.reportValidity(),_.setCustomValidity(""));return}a=Er(a,{type:"continue"}),A();const N={...h,version:1,name:a.name,gender:a.gender,step:"identity",...d?{origin:d}:{},...u?{classCode:u}:{}};try{sessionStorage.setItem(Za,JSON.stringify(N))}catch{c=!0}M.textContent=c?"Seu navegador não permitiu guardar o rascunho. Você ainda pode explorar as origens.":"Preparando sua ficha…",i.dispatchEvent(new CustomEvent("orion:creation-continue",{detail:N,bubbles:!0})),k(N)});function k(L,N=!1){return i.inert=!0,iM(L,{reducedMotion:t,resume:N,onChoose(B){d=B.origin,u=B.classCode??null,B.character&&(h={character:B.character,creationStep:B.creationStep,creationVisited:B.creationVisited,localDraftId:B.localDraftId})},onReturn(){i.inert=!1,a={...a,continued:!1},A(),M.textContent="Revise sua identidade e continue quando quiser."}}).catch(()=>{i.inert=!1,delete document.documentElement.dataset.paperActive,a={...a,continued:!1},A(),M.textContent="Não foi possível abrir a ficha. Tente continuar novamente."})}let z=null,H="session";try{z=Ka(sessionStorage,Za),z||(z=Ka(localStorage),H="local")}catch{}if(z)if(new URLSearchParams(location.search).has("resume"))a={phase:"identity",name:z.name,gender:z.gender,continued:!0},d=z.origin,u=z.classCode,h={character:z.character,creationStep:z.creationStep,creationVisited:z.creationVisited,localDraftId:z.localDraftId},_.value=z.name,y.hidden=!1,f.hidden=!0,m.hidden=!0,y.append(M),A(),w.select(z.gender),w.ready.then(()=>w.release({immediate:!0})).then(()=>k(z,!0)).catch(()=>{M.textContent="Não foi possível retomar a criação. O rascunho guardado não foi apagado.",i.inert=!1});else{const L=document.createElement("a");L.className="creation-resume ink-link",L.href="criacao.html?stars=0&resume="+H,L.textContent="Retomar criação anterior →",p.append(L)}return A(),{ready:w.ready,point:T,update:b,finishFrame(){if(e.state.mode==="mesh")return;const L=new Set;e.root?.traverse(N=>{N.isMesh&&N.material&&!L.has(N.material)&&(L.add(N.material),N.material.opacity*=.56)})},get state(){return{...a}}}}function sM({root:i,isLocked:e,onDismiss:t,onSwipe:n}){const r={dragging:!1,gestures:0};let s=null,a=!1;const o=g=>{const v=g.closest("button,a,input,summary,#heraldCard,.debug");return v&&!v.matches(".herald-target")};function l(g){if(g.pointerType!=="touch"){a=!1;return}if(!e()){if(s){u();return}a=!1,!(!g.isPrimary||o(g.target))&&(s={id:g.pointerId,x:g.clientX,y:g.clientY,star:!!g.target.closest(".herald-target")})}}function c(g){if(!s||g.pointerId!==s.id||e())return;const v=g.clientX-s.x,m=g.clientY-s.y;!r.dragging&&Math.hypot(v,m)<10||r.dragging||(r.dragging=!0,r.gestures++,t(),i.setPointerCapture(g.pointerId))}function d(g){if(!s||g.pointerId!==s.id)return;c(g);const v=g.clientX-s.x,m=g.clientY-s.y,f=Math.max(48,Math.min(80,i.clientWidth*.14));r.dragging&&Math.abs(v)>=f&&Math.abs(v)>Math.abs(m)*1.25&&n(v<0?1:-1),a=r.dragging,!r.dragging&&!s.star&&t();const y=s.id;s=null,r.dragging=!1,i.hasPointerCapture(y)&&i.releasePointerCapture(y)}function u(){if(!s)return;const g=s.id;s=null,r.dragging=!1,a=!0,i.hasPointerCapture(g)&&i.releasePointerCapture(g)}function h(g){g.target===i&&!i.hasPointerCapture(g.pointerId)&&u()}function p(g){!a||g.detail===0||(a=!1,g.preventDefault(),g.stopImmediatePropagation())}return i.addEventListener("pointerdown",l),i.addEventListener("pointermove",c),i.addEventListener("pointerup",d),i.addEventListener("pointercancel",u),i.addEventListener("lostpointercapture",h),i.addEventListener("click",p,!0),window.addEventListener("blur",u),{state:r,cancel:u,dispose(){u(),i.removeEventListener("pointerdown",l),i.removeEventListener("pointermove",c),i.removeEventListener("pointerup",d),i.removeEventListener("pointercancel",u),i.removeEventListener("lostpointercapture",h),i.removeEventListener("click",p,!0),window.removeEventListener("blur",u)}}}function Wf(i,e,t=0,n=0){const r=2*Math.tan(52*Math.PI/360)*496,s=r*e,a=e>1,o=a?.5-.22*n:.5,l=a?.34+.12*n:.36-.13*n;return Array.from({length:i},(c,d)=>({x:(d-t)*s*1.12+(o-.5)*s+t*8,y:(.5-l)*r,z:-470,scale:Math.min(1,Math.max(.65,e/.95))}))}function aM({root:i,heralds:e,reducedMotion:t,isLocked:n,onChange:r}){const s=document.getElementById("starBrowser"),a=document.getElementById("browseName"),o=document.getElementById("browseCount"),l=document.getElementById("starPages"),c=document.getElementById("previousStar"),d=document.getElementById("nextStar"),u=document.getElementById("swipeHint"),h={index:0,position:0,summary:0,settled:!0,changes:0},p=e.map((f,y)=>{const _=document.createElement("button");return _.type="button",_.className="star-page",_.setAttribute("aria-label",`Mostrar ${f.data.name}, ${y+1} de ${e.length}`),_.addEventListener("click",()=>v(y)),l.appendChild(_),_});s.hidden=!1,s.dataset.single=String(e.length===1);function g(){a.textContent=e[h.index].data.name,o.textContent=`${h.index+1} / ${e.length}`,c.disabled=h.index===0,d.disabled=h.index===e.length-1,p.forEach((f,y)=>f.setAttribute("aria-current",String(y===h.index))),u.textContent="Deslize para mudar de estrela"}function v(f){if(n())return!1;const y=Math.max(0,Math.min(e.length-1,f));return y===h.index?!1:(h.index=y,h.changes++,h.settled=t,t&&(h.position=y),i.dataset.browseMoving=String(!h.settled),r(e[y]),g(),!0)}function m(f,y){const _=t?1:1-Math.exp(-Math.max(0,f)*12);h.position+=(h.index-h.position)*_,h.summary+=(Number(y)-h.summary)*_,h.settled=Math.abs(h.index-h.position)<.002,h.settled&&(h.position=h.index);const x=String(!h.settled);i.dataset.browseMoving!==x&&(i.dataset.browseMoving=x);const R=!!y||n();s.inert!==R&&(s.inert=R);for(const[M,w]of e.entries()){const A=M!==h.index,S=A||!h.settled||n();w.target.hidden!==A&&(w.target.hidden=A),w.target.tabIndex!==(A?-1:0)&&(w.target.tabIndex=A?-1:0),w.target.disabled!==S&&(w.target.disabled=S)}}return c.addEventListener("click",()=>v(h.index-1)),d.addEventListener("click",()=>v(h.index+1)),i.addEventListener("keydown",f=>{!["ArrowLeft","ArrowRight"].includes(f.key)||f.target.closest("#heraldCard,input,.debug")||(f.preventDefault(),v(h.index+(f.key==="ArrowRight"?1:-1)))}),g(),m(0,!1),{state:h,choose:v,step:f=>v(h.index+f),update:m}}function oM(i,e,t,n){return Math.min(Math.max(.5,e||1),i.dpr,Math.sqrt(i.maxPixels/Math.max(1,t*n)))}function lM({interval:i=2400,minSamples:e=12}={}){let t=null,n=0,r=0,s=0;const a={averageMs:null,samples:0,updatedAt:null,windowMs:0};function o(c=null){t=c,n=0,r=0,s=0,a.averageMs=null,a.samples=0,a.updatedAt=null,a.windowMs=0}function l(c,d){if(!Number.isFinite(d)||d<=0||d>1e3)return o(c),!1;if(t===null&&(t=c),n+=d,r++,c-t<i||r<e)return!1;const u=n/r;a.averageMs=u,a.samples=r,a.updatedAt=c,a.windowMs=c-t,t=c,n=0,r=0,s=u>24?s+1:0;const h=u>38||s>=2;return h&&(s=0),h}return{state:a,record:l,reset:o}}function cM({creationPage:i=!1}={}){const e=document.getElementById("sceneLoading");if(!e||i)return{play:async()=>{}};const t=document.createElement("div");t.className="entrance-map",t.setAttribute("aria-hidden","true"),t.innerHTML='<svg viewBox="0 0 280 180"><path class="entrance-orbit" d="M140 24C222 24 257 135 140 157C23 135 58 24 140 24Z"/><path class="entrance-route" d="m58 115 43-62 42 51 58-70 26 84-84-14-34 49-51-38"/><g><circle cx="58" cy="115" r="2"/><circle cx="101" cy="53" r="3"/><circle cx="143" cy="104" r="4"/><circle cx="201" cy="34" r="2"/><circle cx="227" cy="118" r="3"/><circle cx="109" cy="153" r="2"/></g></svg>',e.prepend(t);const n=document.createElement("button");return n.type="button",n.className="entrance-skip",n.textContent="Pular introdução",n.hidden=!0,e.append(n),{async play({reducedMotion:r=!1}={}){let s=!1;try{s=sessionStorage.getItem("orion-entrance-v24")==="seen"}catch{}if(r||s)return;e.dataset.entrance="reveal",e.querySelector("p").textContent="Uma luz. Uma história.",n.hidden=!1;const a=e.animate([{opacity:1},{opacity:1,offset:.25},{opacity:0}],{duration:1450,easing:"cubic-bezier(.22,.65,.3,1)",fill:"forwards"}),l=document.querySelector("#world").animate([{opacity:.3,transform:"scale(1.035)"},{opacity:1,transform:"scale(1)"}],{duration:1450,easing:"cubic-bezier(.2,.7,.2,1)"}),c=()=>{a.finish(),l.finish()};n.addEventListener("click",c,{once:!0}),await a.finished.catch(()=>{}),n.removeEventListener("click",c),a.cancel(),l.cancel(),n.hidden=!0,e.dataset.entrance="done";try{sessionStorage.setItem("orion-entrance-v24","seen")}catch{}}}}const Xf="orion-render-quality-v1",qf=[["auto","Automático"],["eco","Mais fluidez"],["high","Mais detalhe"]];function uM(){try{const i=localStorage.getItem(Xf);return qf.some(([e])=>e===i)?i:null}catch{return null}}function dM(i,{value:e="auto",onChange:t,diagnostic:n,graphics:r={}}){const s=document.createElement("button");s.type="button",s.className="quality-toggle",s.textContent="◐ Fluidez",s.setAttribute("aria-label","Ajustar qualidade visual"),s.setAttribute("aria-haspopup","dialog");const a=document.createElement("dialog");a.className="quality-dialog",a.setAttribute("aria-labelledby","qualityTitle"),a.innerHTML=`<button class="quality-close" type="button" aria-label="Fechar ajustes de qualidade">×</button><h2 id="qualityTitle">Qualidade visual</h2><p>Escolha o equilíbrio entre detalhe e movimento.</p><fieldset><legend>Preferência de imagem</legend>${qf.map(([f,y])=>`<label><input type="radio" name="renderQuality" value="${f}"><span>${y}</span></label>`).join("")}</fieldset><p class="quality-feedback" role="status"></p><details><summary>Diagnóstico deste navegador</summary><pre></pre><button type="button" class="quality-copy">Copiar diagnóstico</button><p class="quality-copy-feedback" role="status"></p></details>`,i.append(s,a);const o=_p(i,a,r);new MutationObserver(()=>{s.disabled=i.classList.contains("jumping")||i.classList.contains("selecting"),s.disabled&&a.open&&a.close()}).observe(i,{attributes:!0,attributeFilter:["class"]});const c=[...a.querySelectorAll('input[name="renderQuality"]')],d=a.querySelector(".quality-feedback"),u=a.querySelector("details"),h=a.querySelector("pre");let p=null;function g(){c.forEach(f=>f.checked=f.value===e),h.textContent=n()}function v(){p!==null&&clearInterval(p),p=null}function m(){v(),!(!a.open||!u.open)&&(g(),p=setInterval(()=>{const f=document.getSelection();!a.open||!u.open||document.hidden||f&&!f.isCollapsed&&h.contains(f.anchorNode)||g()},1e3))}s.addEventListener("click",()=>{g(),a.showModal(),m(),(c.find(f=>f.checked)||c[0]).focus()}),a.querySelector(".quality-close").addEventListener("click",()=>a.close()),a.addEventListener("close",()=>{v(),s.focus()}),u.addEventListener("toggle",m);for(const f of c)f.addEventListener("change",()=>{e=f.value,t(e);let y=!1;try{localStorage.setItem(Xf,e),y=!0}catch{}d.textContent=y?"Ajuste aplicado e salvo neste navegador.":"Ajuste aplicado nesta aba.",g()});return a.querySelector(".quality-copy").addEventListener("click",async()=>{const f=n();a.querySelector("pre").textContent=f;try{await navigator.clipboard.writeText(f),a.querySelector(".quality-copy-feedback").textContent="Diagnóstico copiado."}catch{a.querySelector(".quality-copy-feedback").textContent="Selecione e copie os dados acima."}}),{button:s,dialog:a,observeSample:o.observeSample,openGraphicsHelp:o.open}}const Xt=document.getElementById("observatory"),Tt=document.body.dataset.page==="creation",hM=cM({creationPage:Tt});let Zr=null;const fM=document.getElementById("world");let Qi=document.getElementById("heraldTarget");const Wt=document.getElementById("heraldCard"),Di=document.getElementById("hint"),wl=document.getElementById("notice"),Ac=document.getElementById("loading"),Jr=document.getElementById("arrivalFlash"),Qr=document.getElementById("debug"),wc=document.getElementById("depth"),Yf=document.getElementById("depthValue"),at=matchMedia("(prefers-reduced-motion: reduce)").matches,xt=matchMedia("(pointer: coarse)").matches;Xt.dataset.input=xt?"touch":"pointer";const jf=xt?"Toque na estrela para conhecer":"Concentre seu olhar sobre uma estrela";Di.textContent=jf;let _n=Number(new URLSearchParams(location.search).get("depth")||1);Number.isFinite(_n)||(_n=1);_n=_e.clamp(_n,.5,2.5);wc.value=String(_n);Yf.textContent=_n.toFixed(1).replace(".",",")+"×";const un=new URLSearchParams(location.search),hn=un.has("debug"),pM=un.get("depthMotion")!=="off",mM=un.get("foreground")!=="off",li=un.get("hands"),Ti=["on","fps","vr","rig","3d","2d"].includes(li)||["overlay","mesh"].includes(li)||li!=="off",wi=li==="2d"?"2d":li==="3d"?"3d":li==="rig"?"rig":li==="vr"?"vr":li==="fps"?"fps":li==="overlay"?"overlay":"mesh",Ih=document.getElementById("fpsHandsCredit");Ih&&(Ih.hidden=!Ti||wi!=="fps");Qr.hidden=!hn;const $f=xt||navigator.deviceMemory!==void 0&&navigator.deviceMemory<=4||navigator.hardwareConcurrency!==void 0&&navigator.hardwareConcurrency<=4,Ri=un.get("quality")||uM();let Rr=["eco","eco-plus","lite","low","balanced","high"].includes(Ri);const to=["no-bloom","no-gas"].includes(un.get("effects"))?un.get("effects"):"normal",gM=Ri==="eco"?"eco":Ri==="eco-plus"?"eco-plus":Ri==="lite"||Ri==="low"?"lite":Ri==="high"?"high":Ri==="balanced"?"balanced":$f?"lite":"balanced",Ph=["eco","eco-plus","lite","balanced","high"];let In=gM,su=0;const vM={eco:{dpr:.53,maxPixels:5e5,bloomScale:.2,gas:[],fpsCap:60},"eco-plus":{dpr:.6,maxPixels:67e4,bloomScale:.22,gas:[],fpsCap:60},lite:{dpr:.75,maxPixels:95e4,bloomScale:.24,gas:[2],fpsCap:60},balanced:{dpr:1,maxPixels:22e5,bloomScale:.34,gas:[0,2],fpsCap:60},high:{dpr:1.25,maxPixels:32e5,bloomScale:.42,gas:[0,1,2,3,4],fpsCap:60}};function $s(){return vM[In]}function Kf(){return oM($s(),window.devicePixelRatio,innerWidth,innerHeight)}const _M={get mode(){return In},get pixelRatio(){return St.getPixelRatio()},get maxPixels(){return $s().maxPixels},get visibleGas(){return Rn.layers.filter(i=>i.visible).length},get adaptations(){return su},get drawCalls(){return St.info.render.calls},get textures(){return St.info.memory.textures}};hn&&(window.__orionPerformance=_M);let Lh=0;function xM(i){wl.textContent=i,wl.hidden=!1,clearTimeout(Lh),Lh=setTimeout(()=>{wl.hidden=!0},5500)}document.getElementById("leave").addEventListener("click",()=>xM("Protótipo visual: não há conta conectada para sair."));wc.addEventListener("input",()=>{_n=Number(wc.value),Yf.textContent=_n.toFixed(1).replace(".",",")+"×"});window.addEventListener("keydown",i=>{i.key.toLowerCase()==="d"&&!["INPUT","TEXTAREA"].includes(document.activeElement.tagName)&&(Qr.hidden=!Qr.hidden)});let St;try{St=new yy({antialias:In==="high",alpha:!0,powerPreference:"high-performance"})}catch(i){throw Ac.textContent="WebGL indisponível neste navegador. Tente no Chrome com aceleração de hardware ativada.",i}St.setPixelRatio(Kf());St.setSize(innerWidth,innerHeight);St.outputColorSpace=_t;St.toneMapping=Hh;St.toneMappingExposure=1.24;St.info.autoReset=!1;fM.appendChild(St.domElement);const Dn=new cf,ut=new Zt(52,innerWidth/innerHeight,.2,900),Ks=new Ct,vo=new Ct,_o=new Ct,xo=new Ct;Dn.add(Ks);Ks.add(vo);vo.add(_o);_o.add(xo);xo.add(ut);Ks.position.set(0,0,26);ut.position.set(0,0,0);const vt=wi==="mesh"?vS(ut,{enabled:Ti,reducedMotion:at,animation:["mesh","rig","perspective"].includes(un.get("handsMotion"))?un.get("handsMotion"):"perspective",touchLayout:xt}):wi==="overlay"?aS(Xt,{enabled:Ti,reducedMotion:at}):wi==="2d"?Ky(ut,{enabled:Ti,reducedMotion:at}):wi==="3d"?tb(ut,{enabled:Ti,reducedMotion:at}):wi==="rig"?kb(ut,{enabled:Ti,reducedMotion:at}):wi==="vr"?Yb(ut,{enabled:Ti,reducedMotion:at}):sS(ut,{enabled:Ti,reducedMotion:at});vt.state.mode=wi;hn&&(window.__orionHandsDebug=vt);const er=[],yM=new rs;function Zf(i){const e=yM.load(i,void 0,void 0,t=>console.warn("[nebula]",i,t));return e.colorSpace=_t,e.anisotropy=1,e.minFilter=Gt,e.magFilter=Dt,e.generateMipmaps=!0,e}function as(i,e,t,n,r,s,a,o=2048/768,l={}){const c=new Ut({map:Zf(i),transparent:!0,opacity:t,depthTest:!1,depthWrite:!1,toneMapped:!1,side:Et,forceSinglePass:!0,blending:l.additive?tn:Pi}),d=new ht(new yn(1,1),c);return d.position.set(n,r,e),d.renderOrder=a,d.userData.factor=s,d.userData.aspect=o,d.userData.layerName=l.name||i.split("/").pop(),Dn.add(d),er.push(d),d}const bM=as("/assets/00-starfield-base.jpg",-700,1,0,0,1.58,-1,2,{name:"00 · Fundo espacial"});bM.visible=!1;const Jf=as("/assets/01-nebula-far.webp",-360,.11,0,-5,1.53,1,3072/1152,{name:"01 · Nebulosa distante"});Jf.visible=!1;const Ni=as(Tt?kf():"/assets/nebula-eso-photographic.jpg",-540,1,0,-3,1.31,2,Tt?16/9:5e3/1850,{name:Tt?"Interior da nebulosa":"02 · Via Láctea fotográfica · ESO"});Ni.material.color.setRGB(.43,.46,.53);Tt&&Ni.material.color.setRGB(.55,.56,.68);const no=Oy(Ni,ut),SM=as("/assets/03-mid-clouds.webp",-155,.031,-2,-4,1.42,3,3072/1152,{name:"03 · Detalhe da nebulosa",additive:!0}),MM=as("/assets/04-front-fog.png",-92,.027,9,-10,1.56,4,2560/960,{name:"04 · Névoa frontal",additive:!0}),Qf=as("/assets/05-star-dust.png",-58,.062,0,0,1.62,5,3072/1152,{name:"05 · Poeira estelar",additive:!0});Qf.visible=!1;const au=[{mesh:Jf,base:.11,amp:.045,rate:.43,phase:.5},{mesh:SM,base:.031,amp:.052,rate:.59,phase:1.8},{mesh:MM,base:.027,amp:.048,rate:.49,phase:3.1},{mesh:Qf,base:.062,amp:.03,rate:.69,phase:2.6}],Cr={gas:1,star:1,beacon:0},Rn=Ey(Dn,{reducedMotion:at||xt});er.push(...Rn.layers);if(Tt)for(const i of au)i.mesh.visible=!1;const Dh={reducedMotion:at||xt&&!Tt,parallaxEnabled:pM&&(!Tt||!xt),foregroundEnabled:mM},Jt=Tt?PS(Dn,Ni,Dh):Wy(Dn,Ni,Dh);er.push(...Jt.layers);function ou(){const i=new Set(Tt||to==="no-gas"?[]:$s().gas);Rn.layers.forEach((e,t)=>{e.visible=i.has(t)}),Jt.applyQuality(In)}ou();if(hn){const i=document.createElement("fieldset");i.className="layer-inspector";const e=document.createElement("legend");e.textContent="Camadas da nebulosa",i.appendChild(e);for(const r of er){const s=document.createElement("label");s.className="layer-switch";const a=document.createElement("input");a.type="checkbox",a.checked=r.visible,a.addEventListener("change",()=>{r.visible=a.checked});const o=document.createElement("span");o.textContent=r.userData.layerName,s.append(a,o),i.appendChild(s)}Qr.appendChild(i);const t=document.createElement("fieldset");t.className="layer-inspector",t.innerHTML="<legend>Nebulosa Viva</legend>";const n=(r,s,a,o,l,c)=>{const d=document.createElement("label");d.className="atmosphere-slider";const u=document.createElement("span");u.textContent=r;const h=document.createElement("output");h.textContent=Number(s).toFixed(2);const p=document.createElement("input");p.type="range",p.min=String(a),p.max=String(o),p.step=String(l),p.value=String(s),p.setAttribute("aria-label",r),p.addEventListener("input",()=>{const g=Number(p.value);h.textContent=g.toFixed(2),c(g)}),d.append(u,h,p),t.appendChild(d)};n("Densidade do gás",Rn.state.density,0,1.5,.05,Rn.setDensity),n("Fluxo orgânico",Rn.state.flow,0,1,.05,Rn.setFlow),n("Paralaxe da nebulosa",Jt.state.parallaxStrength,.45,1.6,.05,Jt.setParallaxStrength),window.__orionBloomSliderFactory=n,Qr.appendChild(t)}const lu=[],yo=new Ct;Dn.add(yo);function bo(i,e,t,n,r,s,a,o={}){const l=new Float32Array(i*3),c=new Float32Array(i),d=new Float32Array(i),u=new Float32Array(i),h=new Float32Array(i),p=new Float32Array(i),g=new Float32Array(i*3),v=a.map(R=>new Ie(R)),m=Math.tan(_e.degToRad(52/2)),f=innerWidth/innerHeight,y=43/496;for(let R=0;R<i;R++){const M=R*3;let w,A,S,b,T,D=0;do{w=(Math.random()-.5)*n,A=(Math.random()-.5)*r,S=e+Math.random()*(t-e);const H=26-S;b=w/H/(m*f),T=(A/H-y)/m,D++}while((b/.51)**2+(T/.42)**2<1&&D<150);l[M]=w,l[M+1]=A,l[M+2]=S,c[R]=s[0]+Math.random()*(s[1]-s[0]),d[R]=Math.random()*6.283;const k=o.group?{low:.46,high:1.05,min:.04,max:.11}:t<-255?{low:.2,high:.66,min:.035,max:.095}:t<-95?{low:.32,high:.91,min:.05,max:.14}:{low:.55,high:1.23,min:.07,max:.17};u[R]=k.low+Math.random()*(k.high-k.low),h[R]=k.min+Math.random()*(k.max-k.min),p[R]=Math.random()*6.283;const z=v[Math.floor(Math.random()*v.length)];g[M]=z.r,g[M+1]=z.g,g[M+2]=z.b}const _=new Lt;_.setAttribute("position",new ct(l,3)),_.setAttribute("aSize",new ct(c,1)),_.setAttribute("aPhase",new ct(d,1)),_.setAttribute("aTwinkleRate",new ct(u,1)),_.setAttribute("aTwinkleAmp",new ct(h,1)),_.setAttribute("aTwinkleSecondary",new ct(p,1)),_.setAttribute("aColor",new ct(g,3));const x=new Rt({transparent:!0,depthWrite:!1,blending:tn,uniforms:{uTime:{value:0},uDpr:{value:Math.min(devicePixelRatio||1,2)},uOpacity:{value:1}},vertexShader:`
      attribute float aSize;attribute float aPhase;attribute float aTwinkleRate;attribute float aTwinkleAmp;attribute float aTwinkleSecondary;attribute vec3 aColor;
      uniform float uTime;uniform float uDpr;uniform float uOpacity;
      varying vec3 vColor;varying float vOpacity;
      void main(){
        vec4 mv=modelViewMatrix*vec4(position,1.0);
        gl_Position=projectionMatrix*mv;
        gl_PointSize=clamp(aSize*96.0/max(5.0,-mv.z)*uDpr,0.6,3.7);
        vColor=aColor;
        // Estrelas não cintilam em sincronismo. Cada ponto tem frequência,
        // amplitude e segunda fase independente (sem gasto extra de draw calls).
        float low=sin(uTime*aTwinkleRate+aPhase);
        float irregular=sin(uTime*(aTwinkleRate*1.753+.12)+aTwinkleSecondary);
        vOpacity=clamp(.61+low*aTwinkleAmp*.40+irregular*aTwinkleAmp*.18,.32,.78)*uOpacity;
      }`,fragmentShader:`
      varying vec3 vColor;varying float vOpacity;
      void main(){
        float r=length(gl_PointCoord-vec2(.5));
        float alpha=(1.0-smoothstep(.1,.48,r))*vOpacity;
        gl_FragColor=vec4(vColor,alpha);
      }`});x.userData.baseOpacity=o.opacity??1,lu.push(x),(o.group||yo).add(new Yc(_,x))}bo(110,-540,-270,1100,570,[1.3,3.2],["#c1cce1","#8791c8","#d5c9c4"],{opacity:.38});bo(28,-255,-105,510,290,[.8,2],["#c9d0ed","#a99cc9","#d5c8a9"],{opacity:.34});bo(8,-95,-15,250,140,[.6,1.15],["#bfc6dd","#a5a8ce","#d2c8bc"],{opacity:.28});const So=new Ct;Dn.add(So);bo(0,-56,-6,128,72,[.65,1],["#d6dfff","#d3baff","#f7eacf"],{group:So,opacity:0});hn&&(window.__orionDepthDebug={rigRoot:Ks,rigYaw:vo,rigPitch:_o,rigRoll:xo,camera:ut,foregroundParticles:So,layers:er,nebulaMotion:Jt.state});const Mo=new U(0,43,-470),io=Mo.clone();let dn=new Ct;dn.position.copy(Mo);Dn.add(dn);function EM(){const i=document.createElement("canvas");i.width=i.height=512;const e=i.getContext("2d"),t=e.createRadialGradient(256,256,5,256,256,245);t.addColorStop(0,"rgba(255,255,255,1)"),t.addColorStop(.03,"rgba(255,252,233,1)"),t.addColorStop(.08,"rgba(255,222,158,.87)"),t.addColorStop(.18,"rgba(249,209,133,.34)"),t.addColorStop(.42,"rgba(225,190,122,.105)"),t.addColorStop(1,"rgba(215,185,140,0)"),e.fillStyle=t,e.fillRect(0,0,512,512);const n=[[0,1.4,190],[1.4,0,192],[-.7,.7,96],[.7,.7,96]];e.save(),e.translate(256,256);for(const[s,a,o]of n){const l=Math.hypot(s,a),c=s/l,d=a/l;for(const u of[-1,1]){const h=e.createLinearGradient(0,0,c*o*u,d*o*u);h.addColorStop(0,"rgba(255,250,237,.7)"),h.addColorStop(1,"rgba(255,250,237,0)"),e.strokeStyle=h,e.lineWidth=s===0||a===0?1.6:.7,e.beginPath(),e.moveTo(0,0),e.lineTo(c*o*u,d*o*u),e.stroke()}}e.restore();const r=new fo(i);return r.colorSpace=_t,r}const TM=EM();function Eo(i,e){const t=new Gs({map:TM,transparent:!0,opacity:e,blending:tn,depthWrite:!1,depthTest:!1,toneMapped:!1}),n=new uo(t);return n.scale.set(i,i,1),n.renderOrder=12,dn.add(n),n}let tr=new uo(new Gs({map:Zf("/assets/06-star-glow.png"),transparent:!0,opacity:.16,blending:tn,depthTest:!1,depthWrite:!1,toneMapped:!1}));tr.scale.set(60,60,1);tr.renderOrder=10;dn.add(tr);let To=Eo(47,.25),Ao=Eo(22,.8),wo=Eo(7,1),Zs=new ht(new po(7.25,7.28,144),new Ut({color:15257490,transparent:!0,opacity:.015,side:Et,depthWrite:!1,depthTest:!1}));Zs.renderOrder=14;dn.add(Zs);let nr=Eo(178,0);nr.renderOrder=11;nr.layers.enable(1);let Js=Rf(dn,{reducedMotion:at}),Oi=new uo(new Gs({color:16777215,transparent:!0,opacity:0,depthTest:!1,depthWrite:!1}));Oi.scale.setScalar(56);Oi.layers.set(2);Oi.renderOrder=0;dn.add(Oi);const ro=new Fg;ro.layers.set(2);const Nh=new Ce;tr.layers.enable(1);To.layers.enable(1);Ao.layers.enable(1);wo.layers.enable(1);const so=Tt?[]:up(),Ro=hp(un,{localRecords:so}),Ui=Ro.length===0,AM={id:"new-herald",name:"Sua primeira estrela",subtitle:"Um novo começo",creation:!0,stats:{level:"—",origin:"—",trail:"—",rank:"—",em:"—",ec:"—"}},wM=Ui||Tt?[AM]:Ro;Xt.dataset.empty=String(Ui);Ui&&(Di.textContent="Uma nova história espera por você");const Oh={group:dn,glows:{halo:tr,soft:To,main:Ao,core:wo},orbit:Zs,beacon:nr,spikes:Js,pick:Oi,target:Qi},Pt=wM.map((i,e)=>{let t=Oh;if(e){const n=new Ct;Dn.add(n);const r=o=>{const l=o.clone();return l.material=o.material.clone(),n.add(l),l},s=Object.fromEntries(Object.entries(Oh.glows).map(([o,l])=>[o,r(l)])),a=Qi.cloneNode(!1);a.id=`heraldTarget-${i.id}`,Qi.parentNode.insertBefore(a,Wt),t={group:n,glows:s,orbit:r(Zs),beacon:r(nr),pick:r(Oi),target:a,spikes:Rf(n,{reducedMotion:at,sharedTexture:Js.primary.material.map})}}return t.pick.userData.heraldIndex=e,t.target.setAttribute("aria-label",i.creation?"Criar meu primeiro arauto":`Selecionar ${i.name}${i.local?`, personagem salvo neste navegador, nível ${i.stats.level}`:i.demo?", estrela de demonstração":", arauto ativo, nível 9"}`),{data:i,...t,basePosition:new U,screen:{x:NaN,y:NaN},focus:0}});let Qt=Pt[0],Pn=null;document.getElementById("heraldCount").textContent=Ro[0]?.local?`${so.length} ${so.length===1?"personagem":"personagens"} · arquivo local`:Ui?"Sua primeira história":Pt.length===1?"1 arauto ativo":`${Pt.length} estrelas · prévia`;const cu=mp(Jr);function ep(){const i=Qt.data;document.getElementById("heraldName").textContent=i.name,document.getElementById("heraldSubtitle").textContent=i.subtitle,document.getElementById("heraldStatus").textContent=i.local?"Registrado neste navegador":i.demo?"Demonstração":"Arauto ativo",Wt.setAttribute("aria-label",`Resumo de ${i.name}`),document.getElementById("dismissHerald").setAttribute("aria-label",`Fechar resumo de ${i.name}`);for(const e of Wt.querySelectorAll("[data-herald-stat]"))e.textContent=i.stats[e.dataset.heraldStat];uu=Wt.offsetHeight}function Ur(i){if(i===Qt)return!0;if(bt||Ht.state.active||Pn)return!1;Qt=i,Qi=i.target,dn=i.group,{halo:tr,soft:To,main:Ao,core:wo}=i.glows,Zs=i.orbit,nr=i.beacon,Js=i.spikes,Oi=i.pick,Mo.copy(i.group.position),io.copy(i.basePosition),Ht=i.selection,ep();for(const e of Pt)e.target.setAttribute("aria-expanded",String(Ln&&e===i));return Ln&&(Di.textContent=`${i.data.name} · ${xt?"Escolha":"Clique para"} atravessar o véu`),!0}const Fr=Dy(St,Dn,ut,{initial:xt?.1:.18,reducedMotion:at});hn&&(window.__orionBloomSliderFactory("Bloom seletivo",Fr.state.intensity,0,1.5,.05,Fr.setIntensity),window.__orionAtmosphereDebug={atmosphere:Rn,selectiveBloom:Fr},window.__orionRespirationDebug={state:Cr,veils:au,nebula:Ni,get beaconGlow(){return nr},get heraldGroup(){return dn}},window.__orionCinematicDebug={get spikes(){return Js},starsGroup:yo,foregroundParticles:So},delete window.__orionBloomSliderFactory);let ln={x:0,y:0},vn={x:0,y:0},Ln=!1,bt=!1,tp=0,Ar=0,Rc=!1,uu=Wt.offsetHeight;Qt.data.local&&ep();const En={cx:NaN,cy:NaN,focusAt:0,focusX:NaN,focusY:NaN},Br={pointerEvents:0,raycasts:0,focusWrites:0};hn&&(window.__orionInteractionMetrics={get pointerEvents(){return Br.pointerEvents},get raycasts(){return Br.raycasts},get focusWrites(){return Br.focusWrites}});const RM={get x(){return vn.x},get y(){return vn.y},get targetX(){return ln.x},get targetY(){return ln.y},get volumeLayers(){return Jt.layers.length}};hn&&(window.__orionMotionDebug=RM);let Cs=performance.now();const Rl=new U;function CM(){for(const a of Pt){Rl.copy(a.group.position).project(ut);const o=(Rl.x*.5+.5)*innerWidth,l=(-Rl.y*.5+.5)*innerHeight;!Number.isFinite(o)||!Number.isFinite(l)||(!Number.isFinite(a.screen.x)||Math.abs(o-a.screen.x)>.45||Math.abs(l-a.screen.y)>.45)&&(a.target.style.left=o.toFixed(1)+"px",a.target.style.top=l.toFixed(1)+"px",a.screen.x=o,a.screen.y=l)}const{x:i,y:e}=Qt.screen;vt.setStarDirection?.((i/innerWidth-.5)*2,(.5-e/innerHeight)*2),bt&&(Jr.style.setProperty("--arrival-x",(i/innerWidth*100).toFixed(2)+"%"),Jr.style.setProperty("--arrival-y",(e/innerHeight*100).toFixed(2)+"%"));const t=performance.now();if(t-En.focusAt>90&&(!Number.isFinite(En.focusX)||Math.abs(i-En.focusX)>2||Math.abs(e-En.focusY)>2)&&(Xt.style.setProperty("--nox-focus-x",(i/innerWidth*100).toFixed(1)+"%"),Xt.style.setProperty("--nox-focus-y",(e/innerHeight*100).toFixed(1)+"%"),En.focusAt=t,En.focusX=i,En.focusY=e,Br.focusWrites++),xt)return;const n=265,r=_e.clamp(i+170+n<innerWidth-15?i+119:i-150-n,12,innerWidth-n-12),s=_e.clamp(e-93,110,Math.max(112,innerHeight-uu-18));(!Number.isFinite(En.cx)||Math.abs(r-En.cx)>.5||Math.abs(s-En.cy)>.5)&&(Wt.style.left=r.toFixed(1)+"px",Wt.style.top=s.toFixed(1)+"px",En.cx=r,En.cy=s)}function Ci(i){if(!Tt){if(Ui){if(bt||Ht.state.active)return;vt.setStarHovered?.(i),Di.textContent="Clique na estrela para começar sua história";return}if(!(bt||Ht.state.active)){Ln=i,Xt.dataset.summary=String(i),Wt.classList.toggle("visible",i),Wt.setAttribute("aria-hidden",String(!i)),Wt.inert=!i;for(const e of Pt)e.target.setAttribute("aria-expanded",String(i&&e===Qt));vt.setStarHovered?.(i),Di.textContent=i?`${Qt.data.name} · ${xt?"Escolha":"Clique para"} atravessar o véu`:jf}}}function Qs(i=!1){bt||Ht.state.active||(i&&(Rc=!0,Qi.focus({preventScroll:!0}),Rc=!1),Ci(!1))}document.getElementById("dismissHerald").addEventListener("click",()=>Qs(!0));document.getElementById("confirmHerald").addEventListener("click",()=>{Ln&&ao()});window.addEventListener("keydown",i=>{i.key==="Escape"&&Ln&&(i.preventDefault(),Qs(!0))});const di=xt?aM({root:Xt,heralds:Pt,reducedMotion:at,isLocked:()=>bt||!!Pn,onChange:i=>{Qs(),Ur(i),Di.textContent=`${i.data.name} · Toque na estrela para conhecer`}}):null,du=xt?sM({root:Xt,isLocked:()=>bt||!!Pn,onDismiss:()=>Qs(),onSwipe:i=>di.step(i)}):null;hn&&(window.__orionMobileDebug=di);hn&&(window.__orionTouchDebug=du);for(const i of Pt){const e=i.target;e.addEventListener("mouseenter",()=>{!xt&&Ur(i)&&Ci(!0)}),e.addEventListener("mouseleave",()=>{xt||Ci(!1)}),e.addEventListener("focus",()=>{!Rc&&(!xt||e.matches(":focus-visible"))&&Ur(i)&&Ci(!0)}),e.addEventListener("blur",()=>{xt||Ci(!1)}),e.addEventListener("click",t=>{if(!(bt||Ht.state.active||!Ur(i))){if(Ui){ao(i);return}if(xt){if(!di.state.settled)return;Ci(!0);return}if(t.detail===0&&!Ln){Ci(!0);return}ao(i)}})}function np(i,e){if(bt||Tt)return null;const t=Math.max(120,innerHeight*.15),n=Pt.filter(s=>Math.abs(i-s.screen.x)<=t&&Math.abs(e-s.screen.y)<=t);if(!n.length)return null;Br.raycasts++,Nh.set(i/innerWidth*2-1,1-e/innerHeight*2),ut.updateWorldMatrix(!0,!1);for(const s of n)s.group.updateWorldMatrix(!0,!0);ro.setFromCamera(Nh,ut);const r=ro.intersectObjects(n.map(s=>s.pick),!1)[0];return r?Pt[r.object.userData.heraldIndex]:null}window.addEventListener("pointermove",i=>{if(Zr){!xt&&i.pointerType!=="touch"&&(ln.x=(i.clientX/innerWidth-.5)*2,ln.y=(.5-i.clientY/innerHeight)*2),Zr.point(i);return}if(xt||i.pointerType==="touch"||bt||Ht.state.active)return;Br.pointerEvents++,ln.x=(i.clientX/innerWidth-.5)*2,ln.y=(.5-i.clientY/innerHeight)*2;const e=np(i.clientX,i.clientY),t=Pt.find(r=>document.activeElement===r.target&&r.target.matches(":focus-visible"));(e||t)&&Ur(e||t);const n=!!(e||t);document.body.classList.toggle("star-aimed",!!e),vt.setStarHovered?.(n),Ln!==n&&Ci(n)},{passive:!0});const hu=()=>{Qs(),document.body.classList.remove("star-aimed"),vt.setStarHovered?.(!1)};document.documentElement.addEventListener("pointerleave",i=>{i.pointerType!=="touch"&&hu()});window.addEventListener("blur",hu);window.addEventListener("pointerdown",i=>{if(i.pointerType==="touch"||bt||Ht.state.active||i.button!==0||i.target.closest("a,button,input,.debug"))return;const e=np(i.clientX,i.clientY);e&&(i.preventDefault(),ao(e))});const zs=Fy({scene:Dn,camera:ut,star:dn,glows:{halo:tr,soft:To,main:Ao,core:wo},layers:er,gasLayers:Rn.layers,selectiveBloom:Fr,flash:Jr,sky:no,reducedMotion:at,onArrive:()=>{try{sessionStorage.setItem("orion-last-trip-v09",JSON.stringify({heraldId:Pn.data.id,passedGasLayers:Rn.layers.filter(i=>ut.position.z<i.position.z).length,endZ:ut.position.z,starZ:dn.position.z}))}catch{}cu.navigate(zh(location.href,Pn.data))}});for(const i of Pt)i.selection=Vy(i.group,{camera:ut,hands:vt,reducedMotion:at,onDepart:Uh,onConfirm:Uh});let Ht=Qt.selection;hn&&(window.__orionStarDebug={journey:zs,get selection(){return Ht},get heraldGroup(){return dn},get heraldPickSprite(){return Oi},raycaster:ro,heralds:Pt,get selectedHeraldId(){return Pn?.data.id},transition:cu.state,sky:no});function ao(i=Qt){if(!(bt||!Ur(i)||!Ht.begin())){if(Pn=i,xt&&(Xt.dataset.confirming="true",document.getElementById("starBrowser").inert=!0),i.data.creation)for(const e of Object.values(Qa)){if(document.querySelector(`link[data-creation-preload="${e}"]`))continue;const t=document.createElement("link");t.rel="prefetch",t.as="image",t.href=e,t.dataset.creationPreload=e,document.head.append(t)}cu.prepare(zh(location.href,i.data)),tp=performance.now(),du?.cancel(),Ln=!1,Wt.classList.remove("visible"),Wt.setAttribute("aria-hidden","true"),Wt.inert=!0,Qi.setAttribute("aria-expanded","false"),document.body.classList.remove("star-aimed"),Di.textContent=`${i.data.name} selecionada · Atravessando o véu…`}}function Uh(){if(!bt&&(zs.setDestination(Pn.group,Pn.glows),!!zs.begin())){for(const i of Pt)i.beacon.visible=!1,i!==Pn&&i.group.traverse(e=>{e.material&&(e.userData.departureOpacity=e.material.opacity)});bt=!0,vt.setStarHovered?.(!1),vt.beginTravel(),Ln=!1,Wt.classList.remove("visible"),Wt.setAttribute("aria-hidden","true"),Wt.inert=!0,Qi.setAttribute("aria-expanded","false"),Xt.classList.add("jumping"),document.body.classList.remove("star-aimed"),Di.textContent="Atravessando o véu…"}}const Zi=lM();function Co(){if(uu=Wt.offsetHeight,ut.aspect=innerWidth/innerHeight,ut.updateProjectionMatrix(),!bt&&!Pn){const i=xt?Wf(Pt.length,ut.aspect,di.state.position,di.state.summary):gp(Pt.length,ut.aspect);Pt.forEach((e,t)=>{const n=Ui?{x:0,y:0,z:-470,scale:1}:i[t];e.group.position.set(n.x,n.y,n.z),e.group.scale.setScalar(n.scale),e.basePosition.copy(e.group.position)}),Mo.copy(Qt.group.position),io.copy(Qt.basePosition)}vt.resize(),St.setPixelRatio(Kf()),St.setSize(innerWidth,innerHeight),Fr.resize(innerWidth,innerHeight,$s().bloomScale);for(const i of er){if(i.userData.volumeFragment||i===Ni&&no.state.active)continue;const e=26-i.position.z,t=2*Math.tan(_e.degToRad(52/2))*e*i.userData.factor;i.scale.set(t*i.userData.aspect,t,1)}no.state.active||Jt.resize();for(const i of lu)i.uniforms.uDpr.value=St.getPixelRatio();Zi.reset(performance.now())}window.addEventListener("resize",Co);Co();window.addEventListener("pageshow",i=>{i.persisted&&bt&&location.reload()});const oo=hn?jy(Qr,()=>({quality:In,effects:to,bloomRest:In!=="eco"&&to!=="no-bloom",canvasPixels:St.domElement.width*St.domElement.height,dpr:Number(St.getPixelRatio().toFixed(2)),gasLayers:Rn.layers.filter(i=>i.visible).length,volumeLayers:Jt.layers.filter(i=>i.visible).length,foregroundNear:Jt.layers.some(i=>i.visible&&i.userData.volumeFragment&&i.position.z>-100),handsVisible:vt.state.visible,handsSurfaces:vt.state.drawSurfaces,handsMode:vt.state.mode,handsTriangles:vt.state.triangles||0,handsTextures:vt.state.textureCount,handsReady:vt.state.loaded??vt.state.enabled,handsJoints:vt.state.joints||0,handsFingerJoints:vt.state.fingerJoints||0,handsLoadError:vt.state.loadError||null,depthMotion:Jt.state.parallaxEnabled,parallaxStrength:Jt.state.parallaxStrength,drawCalls:St.info.render.calls,textures:St.info.memory.textures,mouseDeltaPx:Number(Math.hypot((vn.x-ln.x)*innerWidth*.5,(vn.y-ln.y)*innerHeight*.5).toFixed(1)),adaptations:su,viewport:innerWidth+"×"+innerHeight})):null;hn&&(window.__orionDiagnostic=oo);let wr=0;function IM(i,e){if(bt||document.hidden||document.documentElement.dataset.paperTransition==="1"||document.documentElement.dataset.presentationReady!=="1"){Zi.reset(i);return}const t=Zi.record(i,e);PM.observeSample(Zi.state,i),t&&!Rr&&In!=="eco"&&(In=Ph[Math.max(0,Ph.indexOf(In)-1)],su++,ou(),Co())}document.addEventListener("visibilitychange",()=>{document.hidden&&(du?.cancel(),hu()),document.hidden||(Cs=performance.now(),Zi.reset(Cs),oo?.reset())});const Cc=St.getContext(),Fh=Cc.getExtension("WEBGL_debug_renderer_info"),Bh=String(Cc.getParameter(Fh?Fh.UNMASKED_RENDERER_WEBGL:Cc.RENDERER)||""),PM=dM(Xt,{graphics:{renderer:Bh,brave:!!navigator.brave||Bh==="Brave",creationPage:Tt},value:Rr?Ri:"auto",onChange(i){Rr=i!=="auto",In=Rr?i:$f?"lite":"balanced",Rr?un.set("quality",i):un.delete("quality"),history.replaceState(history.state,"",location.pathname+"?"+un.toString()+location.hash),Zi.reset(performance.now()),ou(),Co()},diagnostic(){const i=St.getContext(),e=i.getExtension("WEBGL_debug_renderer_info"),t=e?i.getParameter(e.UNMASKED_RENDERER_WEBGL):i.getParameter(i.RENDERER),n=Zi.state;return["Órion · diagnóstico local","Diagnóstico: V25",navigator.userAgent,"Cena: "+(Tt?"criação / "+(Xt.dataset.creationPhase||"carregando"):"observatório"),"Renderizador: "+t,...String(t).trim().toLowerCase()==="brave"?["GPU física: não identificada pelo nome genérico fornecido pelo navegador."]:[],"Modo: "+(Rr?"manual":"automático")+" / "+In,"Canvas: "+St.domElement.width+" × "+St.domElement.height,"FPS da aba (última janela concluída): "+(n.averageMs?Math.round(1e3/n.averageMs):"coletando nova amostra"),"Amostra: "+(n.updatedAt===null?"aguardando uma janela completa neste perfil":n.samples+" quadros / "+(n.windowMs/1e3).toFixed(1)+" s; concluída há "+(Math.max(0,performance.now()-n.updatedAt)/1e3).toFixed(1)+" s"),"MSAA na inicialização: "+(i.getContextAttributes().antialias?"sim":"não"),"Nenhum dado é enviado."].join(`
`)}});let kh=0;function ip(i){if(requestAnimationFrame(ip),Tt&&document.documentElement.dataset.paperActive==="1"){Cs=i,wr=i;return}if(document.hidden)return;const e=$s();if(!bt&&e.fpsCap<60&&wr&&i-wr<1e3/e.fpsCap-1)return;const t=wr?i-wr:16.67;wr=i,oo?.record(i,t),IM(i,t);const n=Math.max(0,(i-Cs)/1e3),r=Math.min(n,.05);Cs=i;const s=i*.001;if(Ht.update(Math.min(n,Math.max(0,(i-tp)/1e3))),bt)nr.visible=!1,zs.update(i,r);else{if(xt&&!Pn){di.update(n,Ln);const f=Wf(Pt.length,ut.aspect,di.state.position,di.state.summary);Pt.forEach((y,_)=>{const x=Ui?{x:0,y:0,z:-470,scale:1}:f[_];y.group.position.set(x.x,x.y,x.z),y.group.scale.setScalar(x.scale),y.basePosition.copy(y.group.position)}),io.copy(Qt.basePosition)}else xt||dn.position.copy(io);yo.position.z=0;const a=at?1:1-Math.exp(-Math.max(.001,r)*(Tt?4:18)),o=Tt?.35:1;vn.x=_e.lerp(vn.x,ln.x,a),vn.y=_e.lerp(vn.y,ln.y,a);const l=at?0:Math.sin(s*.29)*.23;Ks.position.set(xt?di.state.position*8:vn.x*6.8*_n*o,vn.y*4.35*_n*o+l,26+(at?0:Math.sin(s*.21)*.25)),vo.rotation.y=-vn.x*.068*_n*o,_o.rotation.x=vn.y*.052*_n*o,xo.rotation.z=at||xt?0:-vn.x*.011*_n*o+Math.sin(s*.27)*.0015;const c=Ln||Ht.state.active,d=c?1:0;Ar=at?0:_e.lerp(Ar,d,1-Math.exp(-r*12)),Math.abs(Ar-d)<5e-4&&(Ar=d),ut.position.z=-.9*Ar;const u=52-Ar;Math.abs(ut.fov-u)>.001&&(ut.fov=u,ut.updateProjectionMatrix());const h=at?0:Math.sin(s*.42+.6),p=at?0:Math.sin(s*.24+1.5);Cr.gas=1+.019*h+.011*p;for(const f of au){const y=at?0:.68*Math.sin(s*f.rate+f.phase)+.32*Math.sin(s*f.rate*.57+f.phase*1.73);f.mesh.material.opacity=f.base*(1+f.amp*y+(Cr.gas-1)*.5)}const g=at?0:Math.sin(s*.77+.4),v=at?0:.65*Math.sin(s*2.16+1.1)+.35*Math.sin(s*3.24+2.4),m=at?0:Math.pow(Math.max(0,Math.cos(s*.7392-1.35)),10);Cr.beacon=m,Cr.star=1+.028*g+.013*v;for(const f of Pt){const{halo:y,soft:_,main:x,core:R}=f.glows,{beacon:M,orbit:w}=f;f.focus=at?0:_e.lerp(f.focus,f===Qt&&c?1:0,1-Math.exp(-r*12));const A=1+.22*f.focus;if(y.scale.setScalar(156*(Cr.star+.055*m)*A),_.scale.setScalar(118*(1+.034*g+.045*m)*A),x.scale.setScalar(66*(1+.048*g+.022*v+.075*m)*A),R.scale.setScalar(18*(1+.026*v)*(1+.18*f.focus)),y.material.opacity=.075+.045*f.focus+.012*g+.028*m,_.material.opacity=.13+.085*f.focus+.012*g+.024*m,x.material.opacity=.48+.19*f.focus+.015*v+.04*m,R.material.opacity=.94,M.scale.setScalar(154+42*m),M.material.opacity=.046*m*(1+.55*f.focus),w.material.opacity=0,f===Qt&&Ht.state.active){const S=Ht.state.light,b=Ht.state.charge,T=Ht.state.burst;x.material.opacity+=.3*S,_.material.opacity+=.22*b+.18*T,y.material.opacity+=.12*T,x.scale.multiplyScalar(1+.12*b+.22*T),R.scale.multiplyScalar(1+.12*b+.45*T),y.scale.multiplyScalar(1+.1*b+.12*T)}}Jt.update(s,ln.x,ln.y,r),Jr.style.opacity="0",Jr.style.setProperty("--veil-opacity","0")}Zr?.update(i),vt.update(s,r,ln.x,ln.y),Zr?.finishFrame();for(const a of lu)a.uniforms.uTime.value=at?0:s,a.uniforms.uOpacity.value=a.userData.baseOpacity*(bt?1.24:1);Js.update(s,Ln||Ht.state.active,bt);for(const a of Pt)if(a!==Qt&&(a.spikes.update(s,!1,bt),bt)){const o=zs.companionOpacity;a.group.traverse(l=>{l.material&&(l.material.opacity=l.userData.departureOpacity*o)})}ut.updateWorldMatrix(!0,!1),CM(),Rn.update(s),kh++,St.info.reset(),Fr.render(bt||kh%2===1,bt||In!=="eco"&&to!=="no-bloom"),oo?.refresh(i)}if(Tt){Xt.classList.add("creation-scene");for(const i of Pt)i.group.visible=!1,i.target.hidden=!0,i.target.inert=!0;Zr=rM(Xt,{hands:vt,reducedMotion:at,scene:Dn,camera:ut,environment:Jt}),hn&&(window.__orionCreationEnvironment={state:Jt.state,layers:Jt.layers,photo:Ni})}if(!Tt&&Ro[0]?.local){const i=Xt.querySelector(".creation-preview-link");i&&(i.hidden=!0);const e=Xt.querySelector(".bottom-ui"),t=document.createElement("nav");t.className="local-collection-nav",t.setAttribute("aria-label","Arquivo de personagens");const n=fp(so,un.get("page")),r=(s,a)=>{const o=document.createElement("a");o.href=a,o.textContent=s,t.append(o)};if(n.index>0&&r("← Estrelas anteriores",`index.html?stars=0&collection=local&page=${n.index-1}`),n.pages>1){const s=document.createElement("span");s.textContent=`${n.index+1} / ${n.pages}`,t.append(s)}n.index<n.pages-1&&r("Mais estrelas →",`index.html?stars=0&collection=local&page=${n.index+1}`),r("Criar outro personagem","criacao.html?stars=0&new=1"),e.append(t)}if(!Tt)try{if(Ka(sessionStorage,"orion-herald-creation-v1")||Ka(localStorage)){const e=document.createElement("a");e.className="resume-creation-link",e.href="criacao.html?stars=0&resume=1",e.textContent="Retomar criação →",Xt.querySelector(".bottom-ui").append(e)}}catch{}requestAnimationFrame(ip);document.documentElement.dataset.sceneReady="1";const LM=new Promise((i,e)=>{const t=new Image;t.onload=i,t.onerror=()=>e(new Error("Não foi possível carregar o fundo.")),t.src=Tt?kf():"/assets/nebula-eso-photographic.jpg"});Promise.all([LM,vt.ready,Zr?.ready]).then(async()=>{if(vt.state.loadError)throw new Error(vt.state.loadError);await new Promise(i=>requestAnimationFrame(()=>requestAnimationFrame(i))),await hM.play({reducedMotion:at}),document.documentElement.dataset.presentationReady="1",Ac.classList.add("done"),Tt&&await pp()}).catch(i=>{document.documentElement.dataset.sceneError=i.message,document.getElementById("loadErrorText").textContent=i.message,document.getElementById("loadIssue").hidden=!1,Ac.hidden=!0});const FM=Object.freeze(Object.defineProperty({__proto__:null},Symbol.toStringTag,{value:"Module"}));export{Za as C,Sl as L,oi as O,zf as S,US as a,ru as c,FM as m,jS as s};

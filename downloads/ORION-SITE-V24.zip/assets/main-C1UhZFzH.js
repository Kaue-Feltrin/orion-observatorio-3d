const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/creation-journey-DTCdLQ_H.js","assets/page-transition-B8Pdkv8g.js","assets/graphics-advisor-BEPHE5Yw.js","assets/graphics-advisor-Dy5bEt4Q.css","assets/creation-journey-DdbarkcK.css"])))=>i.map(i=>d[i]);
import{o as op,g as lp,a as Fh,r as cp,c as up,b as dp}from"./page-transition-B8Pdkv8g.js";import{_ as hp,m as fp}from"./graphics-advisor-BEPHE5Yw.js";/**
 * @license
 * Copyright 2010-2025 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const Rc="180",pp=0,gu=1,mp=2,Bh=1,gp=2,si=3,fi=0,cn=1,Et=2,ui=0,Ii=1,Qt=2,vu=3,_u=4,vp=5,ji=100,_p=101,xp=102,yp=103,bp=104,Sp=200,Mp=201,Ep=202,Tp=203,Al=204,wl=205,Ap=206,wp=207,Rp=208,Cp=209,Ip=210,Pp=211,Lp=212,Dp=213,Np=214,Rl=0,Cl=1,Il=2,Fr=3,Pl=4,Ll=5,Dl=6,Nl=7,Cc=0,Op=1,Up=2,Pi=0,Fp=1,Bp=2,kp=3,kh=4,zp=5,Vp=6,Hp=7,xu="attached",Gp="detached",zh=300,Br=301,kr=302,Ol=303,Ul=304,ao=306,zr=1e3,Ci=1001,Ga=1002,Jt=1003,Vh=1004,bs=1005,Dt=1006,Ua=1007,Gt=1008,Yn=1009,Hh=1010,Gh=1011,Rs=1012,Ic=1013,Zi=1014,kn=1015,di=1016,Pc=1017,Lc=1018,Cs=1020,Wh=35902,Xh=35899,qh=1021,Yh=1022,Rn=1023,Is=1026,Ps=1027,Dc=1028,Nc=1029,jh=1030,Oc=1031,Uc=1033,Fa=33776,Ba=33777,ka=33778,za=33779,Fl=35840,Bl=35841,kl=35842,zl=35843,Vl=36196,Hl=37492,Gl=37496,Wl=37808,Xl=37809,ql=37810,Yl=37811,jl=37812,$l=37813,Kl=37814,Zl=37815,Jl=37816,Ql=37817,ec=37818,tc=37819,nc=37820,ic=37821,rc=36492,sc=36494,ac=36495,oc=36283,lc=36284,cc=36285,uc=36286,Ls=2300,Ds=2301,Co=2302,yu=2400,bu=2401,Su=2402,Wp=2500,Xp=0,$h=1,dc=2,qp=3200,Yp=3201,Fc=0,jp=1,oi="",_t="srgb",en="srgb-linear",Wa="linear",pt="srgb",ir=7680,Mu=519,$p=512,Kp=513,Zp=514,Kh=515,Jp=516,Qp=517,em=518,tm=519,hc=35044,Zh=35048,Eu="300 es",qn=2e3,Xa=2001;class Jr{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});const n=this._listeners;n[e]===void 0&&(n[e]=[]),n[e].indexOf(t)===-1&&n[e].push(t)}hasEventListener(e,t){const n=this._listeners;return n===void 0?!1:n[e]!==void 0&&n[e].indexOf(t)!==-1}removeEventListener(e,t){const n=this._listeners;if(n===void 0)return;const r=n[e];if(r!==void 0){const s=r.indexOf(t);s!==-1&&r.splice(s,1)}}dispatchEvent(e){const t=this._listeners;if(t===void 0)return;const n=t[e.type];if(n!==void 0){e.target=this;const r=n.slice(0);for(let s=0,a=r.length;s<a;s++)r[s].call(this,e);e.target=null}}}const Xt=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];let Tu=1234567;const Es=Math.PI/180,Vr=180/Math.PI;function zn(){const i=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(Xt[i&255]+Xt[i>>8&255]+Xt[i>>16&255]+Xt[i>>24&255]+"-"+Xt[e&255]+Xt[e>>8&255]+"-"+Xt[e>>16&15|64]+Xt[e>>24&255]+"-"+Xt[t&63|128]+Xt[t>>8&255]+"-"+Xt[t>>16&255]+Xt[t>>24&255]+Xt[n&255]+Xt[n>>8&255]+Xt[n>>16&255]+Xt[n>>24&255]).toLowerCase()}function Je(i,e,t){return Math.max(e,Math.min(t,i))}function Bc(i,e){return(i%e+e)%e}function nm(i,e,t,n,r){return n+(i-e)*(r-n)/(t-e)}function im(i,e,t){return i!==e?(t-i)/(e-i):0}function Ts(i,e,t){return(1-t)*i+t*e}function rm(i,e,t,n){return Ts(i,e,1-Math.exp(-t*n))}function sm(i,e=1){return e-Math.abs(Bc(i,e*2)-e)}function am(i,e,t){return i<=e?0:i>=t?1:(i=(i-e)/(t-e),i*i*(3-2*i))}function om(i,e,t){return i<=e?0:i>=t?1:(i=(i-e)/(t-e),i*i*i*(i*(i*6-15)+10))}function lm(i,e){return i+Math.floor(Math.random()*(e-i+1))}function cm(i,e){return i+Math.random()*(e-i)}function um(i){return i*(.5-Math.random())}function dm(i){i!==void 0&&(Tu=i);let e=Tu+=1831565813;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}function hm(i){return i*Es}function fm(i){return i*Vr}function pm(i){return(i&i-1)===0&&i!==0}function mm(i){return Math.pow(2,Math.ceil(Math.log(i)/Math.LN2))}function gm(i){return Math.pow(2,Math.floor(Math.log(i)/Math.LN2))}function vm(i,e,t,n,r){const s=Math.cos,a=Math.sin,o=s(t/2),l=a(t/2),c=s((e+n)/2),d=a((e+n)/2),u=s((e-n)/2),h=a((e-n)/2),p=s((n-e)/2),g=a((n-e)/2);switch(r){case"XYX":i.set(o*d,l*u,l*h,o*c);break;case"YZY":i.set(l*h,o*d,l*u,o*c);break;case"ZXZ":i.set(l*u,l*h,o*d,o*c);break;case"XZX":i.set(o*d,l*g,l*p,o*c);break;case"YXY":i.set(l*p,o*d,l*g,o*c);break;case"ZYZ":i.set(l*g,l*p,o*d,o*c);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+r)}}function Bn(i,e){switch(e.constructor){case Float32Array:return i;case Uint32Array:return i/4294967295;case Uint16Array:return i/65535;case Uint8Array:return i/255;case Int32Array:return Math.max(i/2147483647,-1);case Int16Array:return Math.max(i/32767,-1);case Int8Array:return Math.max(i/127,-1);default:throw new Error("Invalid component type.")}}function ot(i,e){switch(e.constructor){case Float32Array:return i;case Uint32Array:return Math.round(i*4294967295);case Uint16Array:return Math.round(i*65535);case Uint8Array:return Math.round(i*255);case Int32Array:return Math.round(i*2147483647);case Int16Array:return Math.round(i*32767);case Int8Array:return Math.round(i*127);default:throw new Error("Invalid component type.")}}const _e={DEG2RAD:Es,RAD2DEG:Vr,generateUUID:zn,clamp:Je,euclideanModulo:Bc,mapLinear:nm,inverseLerp:im,lerp:Ts,damp:rm,pingpong:sm,smoothstep:am,smootherstep:om,randInt:lm,randFloat:cm,randFloatSpread:um,seededRandom:dm,degToRad:hm,radToDeg:fm,isPowerOfTwo:pm,ceilPowerOfTwo:mm,floorPowerOfTwo:gm,setQuaternionFromProperEuler:vm,normalize:ot,denormalize:Bn};class Ce{constructor(e=0,t=0){Ce.prototype.isVector2=!0,this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const t=this.x,n=this.y,r=e.elements;return this.x=r[0]*t+r[3]*n+r[6],this.y=r[1]*t+r[4]*n+r[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Je(this.x,e.x,t.x),this.y=Je(this.y,e.y,t.y),this}clampScalar(e,t){return this.x=Je(this.x,e,t),this.y=Je(this.y,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Je(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(Je(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){const n=Math.cos(t),r=Math.sin(t),s=this.x-e.x,a=this.y-e.y;return this.x=s*n-a*r+e.x,this.y=s*r+a*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class dt{constructor(e=0,t=0,n=0,r=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=r}static slerpFlat(e,t,n,r,s,a,o){let l=n[r+0],c=n[r+1],d=n[r+2],u=n[r+3];const h=s[a+0],p=s[a+1],g=s[a+2],v=s[a+3];if(o===0){e[t+0]=l,e[t+1]=c,e[t+2]=d,e[t+3]=u;return}if(o===1){e[t+0]=h,e[t+1]=p,e[t+2]=g,e[t+3]=v;return}if(u!==v||l!==h||c!==p||d!==g){let m=1-o;const f=l*h+c*p+d*g+u*v,b=f>=0?1:-1,_=1-f*f;if(_>Number.EPSILON){const R=Math.sqrt(_),M=Math.atan2(R,f*b);m=Math.sin(m*M)/R,o=Math.sin(o*M)/R}const x=o*b;if(l=l*m+h*x,c=c*m+p*x,d=d*m+g*x,u=u*m+v*x,m===1-o){const R=1/Math.sqrt(l*l+c*c+d*d+u*u);l*=R,c*=R,d*=R,u*=R}}e[t]=l,e[t+1]=c,e[t+2]=d,e[t+3]=u}static multiplyQuaternionsFlat(e,t,n,r,s,a){const o=n[r],l=n[r+1],c=n[r+2],d=n[r+3],u=s[a],h=s[a+1],p=s[a+2],g=s[a+3];return e[t]=o*g+d*u+l*p-c*h,e[t+1]=l*g+d*h+c*u-o*p,e[t+2]=c*g+d*p+o*h-l*u,e[t+3]=d*g-o*u-l*h-c*p,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,r){return this._x=e,this._y=t,this._z=n,this._w=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){const n=e._x,r=e._y,s=e._z,a=e._order,o=Math.cos,l=Math.sin,c=o(n/2),d=o(r/2),u=o(s/2),h=l(n/2),p=l(r/2),g=l(s/2);switch(a){case"XYZ":this._x=h*d*u+c*p*g,this._y=c*p*u-h*d*g,this._z=c*d*g+h*p*u,this._w=c*d*u-h*p*g;break;case"YXZ":this._x=h*d*u+c*p*g,this._y=c*p*u-h*d*g,this._z=c*d*g-h*p*u,this._w=c*d*u+h*p*g;break;case"ZXY":this._x=h*d*u-c*p*g,this._y=c*p*u+h*d*g,this._z=c*d*g+h*p*u,this._w=c*d*u-h*p*g;break;case"ZYX":this._x=h*d*u-c*p*g,this._y=c*p*u+h*d*g,this._z=c*d*g-h*p*u,this._w=c*d*u+h*p*g;break;case"YZX":this._x=h*d*u+c*p*g,this._y=c*p*u+h*d*g,this._z=c*d*g-h*p*u,this._w=c*d*u-h*p*g;break;case"XZY":this._x=h*d*u-c*p*g,this._y=c*p*u-h*d*g,this._z=c*d*g+h*p*u,this._w=c*d*u+h*p*g;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+a)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){const n=t/2,r=Math.sin(n);return this._x=e.x*r,this._y=e.y*r,this._z=e.z*r,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){const t=e.elements,n=t[0],r=t[4],s=t[8],a=t[1],o=t[5],l=t[9],c=t[2],d=t[6],u=t[10],h=n+o+u;if(h>0){const p=.5/Math.sqrt(h+1);this._w=.25/p,this._x=(d-l)*p,this._y=(s-c)*p,this._z=(a-r)*p}else if(n>o&&n>u){const p=2*Math.sqrt(1+n-o-u);this._w=(d-l)/p,this._x=.25*p,this._y=(r+a)/p,this._z=(s+c)/p}else if(o>u){const p=2*Math.sqrt(1+o-n-u);this._w=(s-c)/p,this._x=(r+a)/p,this._y=.25*p,this._z=(l+d)/p}else{const p=2*Math.sqrt(1+u-n-o);this._w=(a-r)/p,this._x=(s+c)/p,this._y=(l+d)/p,this._z=.25*p}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;return n<1e-8?(n=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=n):(this._x=0,this._y=-e.z,this._z=e.y,this._w=n)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(Je(this.dot(e),-1,1)))}rotateTowards(e,t){const n=this.angleTo(e);if(n===0)return this;const r=Math.min(1,t/n);return this.slerp(e,r),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){const n=e._x,r=e._y,s=e._z,a=e._w,o=t._x,l=t._y,c=t._z,d=t._w;return this._x=n*d+a*o+r*c-s*l,this._y=r*d+a*l+s*o-n*c,this._z=s*d+a*c+n*l-r*o,this._w=a*d-n*o-r*l-s*c,this._onChangeCallback(),this}slerp(e,t){if(t===0)return this;if(t===1)return this.copy(e);const n=this._x,r=this._y,s=this._z,a=this._w;let o=a*e._w+n*e._x+r*e._y+s*e._z;if(o<0?(this._w=-e._w,this._x=-e._x,this._y=-e._y,this._z=-e._z,o=-o):this.copy(e),o>=1)return this._w=a,this._x=n,this._y=r,this._z=s,this;const l=1-o*o;if(l<=Number.EPSILON){const p=1-t;return this._w=p*a+t*this._w,this._x=p*n+t*this._x,this._y=p*r+t*this._y,this._z=p*s+t*this._z,this.normalize(),this}const c=Math.sqrt(l),d=Math.atan2(c,o),u=Math.sin((1-t)*d)/c,h=Math.sin(t*d)/c;return this._w=a*u+this._w*h,this._x=n*u+this._x*h,this._y=r*u+this._y*h,this._z=s*u+this._z*h,this._onChangeCallback(),this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){const e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),n=Math.random(),r=Math.sqrt(1-n),s=Math.sqrt(n);return this.set(r*Math.sin(e),r*Math.cos(e),s*Math.sin(t),s*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class U{constructor(e=0,t=0,n=0){U.prototype.isVector3=!0,this.x=e,this.y=t,this.z=n}set(e,t,n){return n===void 0&&(n=this.z),this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(Au.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(Au.setFromAxisAngle(e,t))}applyMatrix3(e){const t=this.x,n=this.y,r=this.z,s=e.elements;return this.x=s[0]*t+s[3]*n+s[6]*r,this.y=s[1]*t+s[4]*n+s[7]*r,this.z=s[2]*t+s[5]*n+s[8]*r,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const t=this.x,n=this.y,r=this.z,s=e.elements,a=1/(s[3]*t+s[7]*n+s[11]*r+s[15]);return this.x=(s[0]*t+s[4]*n+s[8]*r+s[12])*a,this.y=(s[1]*t+s[5]*n+s[9]*r+s[13])*a,this.z=(s[2]*t+s[6]*n+s[10]*r+s[14])*a,this}applyQuaternion(e){const t=this.x,n=this.y,r=this.z,s=e.x,a=e.y,o=e.z,l=e.w,c=2*(a*r-o*n),d=2*(o*t-s*r),u=2*(s*n-a*t);return this.x=t+l*c+a*u-o*d,this.y=n+l*d+o*c-s*u,this.z=r+l*u+s*d-a*c,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const t=this.x,n=this.y,r=this.z,s=e.elements;return this.x=s[0]*t+s[4]*n+s[8]*r,this.y=s[1]*t+s[5]*n+s[9]*r,this.z=s[2]*t+s[6]*n+s[10]*r,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Je(this.x,e.x,t.x),this.y=Je(this.y,e.y,t.y),this.z=Je(this.z,e.z,t.z),this}clampScalar(e,t){return this.x=Je(this.x,e,t),this.y=Je(this.y,e,t),this.z=Je(this.z,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Je(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){const n=e.x,r=e.y,s=e.z,a=t.x,o=t.y,l=t.z;return this.x=r*l-s*o,this.y=s*a-n*l,this.z=n*o-r*a,this}projectOnVector(e){const t=e.lengthSq();if(t===0)return this.set(0,0,0);const n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return Io.copy(this).projectOnVector(e),this.sub(Io)}reflect(e){return this.sub(Io.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(Je(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y,r=this.z-e.z;return t*t+n*n+r*r}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,n){const r=Math.sin(t)*e;return this.x=r*Math.sin(n),this.y=Math.cos(t)*e,this.z=r*Math.cos(n),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){const t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),r=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=r,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,t=Math.random()*2-1,n=Math.sqrt(1-t*t);return this.x=n*Math.cos(e),this.y=t,this.z=n*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const Io=new U,Au=new dt;class $e{constructor(e,t,n,r,s,a,o,l,c){$e.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,n,r,s,a,o,l,c)}set(e,t,n,r,s,a,o,l,c){const d=this.elements;return d[0]=e,d[1]=r,d[2]=o,d[3]=t,d[4]=s,d[5]=l,d[6]=n,d[7]=a,d[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,r=t.elements,s=this.elements,a=n[0],o=n[3],l=n[6],c=n[1],d=n[4],u=n[7],h=n[2],p=n[5],g=n[8],v=r[0],m=r[3],f=r[6],b=r[1],_=r[4],x=r[7],R=r[2],M=r[5],A=r[8];return s[0]=a*v+o*b+l*R,s[3]=a*m+o*_+l*M,s[6]=a*f+o*x+l*A,s[1]=c*v+d*b+u*R,s[4]=c*m+d*_+u*M,s[7]=c*f+d*x+u*A,s[2]=h*v+p*b+g*R,s[5]=h*m+p*_+g*M,s[8]=h*f+p*x+g*A,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[1],r=e[2],s=e[3],a=e[4],o=e[5],l=e[6],c=e[7],d=e[8];return t*a*d-t*o*c-n*s*d+n*o*l+r*s*c-r*a*l}invert(){const e=this.elements,t=e[0],n=e[1],r=e[2],s=e[3],a=e[4],o=e[5],l=e[6],c=e[7],d=e[8],u=d*a-o*c,h=o*l-d*s,p=c*s-a*l,g=t*u+n*h+r*p;if(g===0)return this.set(0,0,0,0,0,0,0,0,0);const v=1/g;return e[0]=u*v,e[1]=(r*c-d*n)*v,e[2]=(o*n-r*a)*v,e[3]=h*v,e[4]=(d*t-r*l)*v,e[5]=(r*s-o*t)*v,e[6]=p*v,e[7]=(n*l-c*t)*v,e[8]=(a*t-n*s)*v,this}transpose(){let e;const t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,r,s,a,o){const l=Math.cos(s),c=Math.sin(s);return this.set(n*l,n*c,-n*(l*a+c*o)+a+e,-r*c,r*l,-r*(-c*a+l*o)+o+t,0,0,1),this}scale(e,t){return this.premultiply(Po.makeScale(e,t)),this}rotate(e){return this.premultiply(Po.makeRotation(-e)),this}translate(e,t){return this.premultiply(Po.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){const t=this.elements,n=e.elements;for(let r=0;r<9;r++)if(t[r]!==n[r])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new this.constructor().fromArray(this.elements)}}const Po=new $e;function Jh(i){for(let e=i.length-1;e>=0;--e)if(i[e]>=65535)return!0;return!1}function Ns(i){return document.createElementNS("http://www.w3.org/1999/xhtml",i)}function _m(){const i=Ns("canvas");return i.style.display="block",i}const wu={};function Os(i){i in wu||(wu[i]=!0,console.warn(i))}function xm(i,e,t){return new Promise(function(n,r){function s(){switch(i.clientWaitSync(e,i.SYNC_FLUSH_COMMANDS_BIT,0)){case i.WAIT_FAILED:r();break;case i.TIMEOUT_EXPIRED:setTimeout(s,t);break;default:n()}}setTimeout(s,t)})}const Ru=new $e().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),Cu=new $e().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function ym(){const i={enabled:!0,workingColorSpace:en,spaces:{},convert:function(r,s,a){return this.enabled===!1||s===a||!s||!a||(this.spaces[s].transfer===pt&&(r.r=hi(r.r),r.g=hi(r.g),r.b=hi(r.b)),this.spaces[s].primaries!==this.spaces[a].primaries&&(r.applyMatrix3(this.spaces[s].toXYZ),r.applyMatrix3(this.spaces[a].fromXYZ)),this.spaces[a].transfer===pt&&(r.r=Pr(r.r),r.g=Pr(r.g),r.b=Pr(r.b))),r},workingToColorSpace:function(r,s){return this.convert(r,this.workingColorSpace,s)},colorSpaceToWorking:function(r,s){return this.convert(r,s,this.workingColorSpace)},getPrimaries:function(r){return this.spaces[r].primaries},getTransfer:function(r){return r===oi?Wa:this.spaces[r].transfer},getToneMappingMode:function(r){return this.spaces[r].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(r,s=this.workingColorSpace){return r.fromArray(this.spaces[s].luminanceCoefficients)},define:function(r){Object.assign(this.spaces,r)},_getMatrix:function(r,s,a){return r.copy(this.spaces[s].toXYZ).multiply(this.spaces[a].fromXYZ)},_getDrawingBufferColorSpace:function(r){return this.spaces[r].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(r=this.workingColorSpace){return this.spaces[r].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(r,s){return Os("THREE.ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),i.workingToColorSpace(r,s)},toWorkingColorSpace:function(r,s){return Os("THREE.ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),i.colorSpaceToWorking(r,s)}},e=[.64,.33,.3,.6,.15,.06],t=[.2126,.7152,.0722],n=[.3127,.329];return i.define({[en]:{primaries:e,whitePoint:n,transfer:Wa,toXYZ:Ru,fromXYZ:Cu,luminanceCoefficients:t,workingColorSpaceConfig:{unpackColorSpace:_t},outputColorSpaceConfig:{drawingBufferColorSpace:_t}},[_t]:{primaries:e,whitePoint:n,transfer:pt,toXYZ:Ru,fromXYZ:Cu,luminanceCoefficients:t,outputColorSpaceConfig:{drawingBufferColorSpace:_t}}}),i}const tt=ym();function hi(i){return i<.04045?i*.0773993808:Math.pow(i*.9478672986+.0521327014,2.4)}function Pr(i){return i<.0031308?i*12.92:1.055*Math.pow(i,.41666)-.055}let rr;class bm{static getDataURL(e,t="image/png"){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let n;if(e instanceof HTMLCanvasElement)n=e;else{rr===void 0&&(rr=Ns("canvas")),rr.width=e.width,rr.height=e.height;const r=rr.getContext("2d");e instanceof ImageData?r.putImageData(e,0,0):r.drawImage(e,0,0,e.width,e.height),n=rr}return n.toDataURL(t)}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const t=Ns("canvas");t.width=e.width,t.height=e.height;const n=t.getContext("2d");n.drawImage(e,0,0,e.width,e.height);const r=n.getImageData(0,0,e.width,e.height),s=r.data;for(let a=0;a<s.length;a++)s[a]=hi(s[a]/255)*255;return n.putImageData(r,0,0),t}else if(e.data){const t=e.data.slice(0);for(let n=0;n<t.length;n++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[n]=Math.floor(hi(t[n]/255)*255):t[n]=hi(t[n]);return{data:t,width:e.width,height:e.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let Sm=0;class kc{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:Sm++}),this.uuid=zn(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){const t=this.data;return typeof HTMLVideoElement<"u"&&t instanceof HTMLVideoElement?e.set(t.videoWidth,t.videoHeight,0):t instanceof VideoFrame?e.set(t.displayHeight,t.displayWidth,0):t!==null?e.set(t.width,t.height,t.depth||0):e.set(0,0,0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const n={uuid:this.uuid,url:""},r=this.data;if(r!==null){let s;if(Array.isArray(r)){s=[];for(let a=0,o=r.length;a<o;a++)r[a].isDataTexture?s.push(Lo(r[a].image)):s.push(Lo(r[a]))}else s=Lo(r);n.url=s}return t||(e.images[this.uuid]=n),n}}function Lo(i){return typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&i instanceof ImageBitmap?bm.getDataURL(i):i.data?{data:Array.from(i.data),width:i.width,height:i.height,type:i.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}let Mm=0;const Do=new U;class Ft extends Jr{constructor(e=Ft.DEFAULT_IMAGE,t=Ft.DEFAULT_MAPPING,n=Ci,r=Ci,s=Dt,a=Gt,o=Rn,l=Yn,c=Ft.DEFAULT_ANISOTROPY,d=oi){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Mm++}),this.uuid=zn(),this.name="",this.source=new kc(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=n,this.wrapT=r,this.magFilter=s,this.minFilter=a,this.anisotropy=c,this.format=o,this.internalFormat=null,this.type=l,this.offset=new Ce(0,0),this.repeat=new Ce(1,1),this.center=new Ce(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new $e,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=d,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0}get width(){return this.source.getSize(Do).x}get height(){return this.source.getSize(Do).y}get depth(){return this.source.getSize(Do).z}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(const t in e){const n=e[t];if(n===void 0){console.warn(`THREE.Texture.setValues(): parameter '${t}' has value of undefined.`);continue}const r=this[t];if(r===void 0){console.warn(`THREE.Texture.setValues(): property '${t}' does not exist.`);continue}r&&n&&r.isVector2&&n.isVector2||r&&n&&r.isVector3&&n.isVector3||r&&n&&r.isMatrix3&&n.isMatrix3?r.copy(n):this[t]=n}}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const n={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),t||(e.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==zh)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case zr:e.x=e.x-Math.floor(e.x);break;case Ci:e.x=e.x<0?0:1;break;case Ga:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case zr:e.y=e.y-Math.floor(e.y);break;case Ci:e.y=e.y<0?0:1;break;case Ga:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}Ft.DEFAULT_IMAGE=null;Ft.DEFAULT_MAPPING=zh;Ft.DEFAULT_ANISOTROPY=1;class rt{constructor(e=0,t=0,n=0,r=1){rt.prototype.isVector4=!0,this.x=e,this.y=t,this.z=n,this.w=r}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,r){return this.x=e,this.y=t,this.z=n,this.w=r,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const t=this.x,n=this.y,r=this.z,s=this.w,a=e.elements;return this.x=a[0]*t+a[4]*n+a[8]*r+a[12]*s,this.y=a[1]*t+a[5]*n+a[9]*r+a[13]*s,this.z=a[2]*t+a[6]*n+a[10]*r+a[14]*s,this.w=a[3]*t+a[7]*n+a[11]*r+a[15]*s,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,n,r,s;const l=e.elements,c=l[0],d=l[4],u=l[8],h=l[1],p=l[5],g=l[9],v=l[2],m=l[6],f=l[10];if(Math.abs(d-h)<.01&&Math.abs(u-v)<.01&&Math.abs(g-m)<.01){if(Math.abs(d+h)<.1&&Math.abs(u+v)<.1&&Math.abs(g+m)<.1&&Math.abs(c+p+f-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;const _=(c+1)/2,x=(p+1)/2,R=(f+1)/2,M=(d+h)/4,A=(u+v)/4,w=(g+m)/4;return _>x&&_>R?_<.01?(n=0,r=.707106781,s=.707106781):(n=Math.sqrt(_),r=M/n,s=A/n):x>R?x<.01?(n=.707106781,r=0,s=.707106781):(r=Math.sqrt(x),n=M/r,s=w/r):R<.01?(n=.707106781,r=.707106781,s=0):(s=Math.sqrt(R),n=A/s,r=w/s),this.set(n,r,s,t),this}let b=Math.sqrt((m-g)*(m-g)+(u-v)*(u-v)+(h-d)*(h-d));return Math.abs(b)<.001&&(b=1),this.x=(m-g)/b,this.y=(u-v)/b,this.z=(h-d)/b,this.w=Math.acos((c+p+f-1)/2),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Je(this.x,e.x,t.x),this.y=Je(this.y,e.y,t.y),this.z=Je(this.z,e.z,t.z),this.w=Je(this.w,e.w,t.w),this}clampScalar(e,t){return this.x=Je(this.x,e,t),this.y=Je(this.y,e,t),this.z=Je(this.z,e,t),this.w=Je(this.w,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Je(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class Em extends Jr{constructor(e=1,t=1,n={}){super(),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Dt,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1},n),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=n.depth,this.scissor=new rt(0,0,e,t),this.scissorTest=!1,this.viewport=new rt(0,0,e,t);const r={width:e,height:t,depth:n.depth},s=new Ft(r);this.textures=[];const a=n.count;for(let o=0;o<a;o++)this.textures[o]=s.clone(),this.textures[o].isRenderTargetTexture=!0,this.textures[o].renderTarget=this;this._setTextureOptions(n),this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=n.depthTexture,this.samples=n.samples,this.multiview=n.multiview}_setTextureOptions(e={}){const t={minFilter:Dt,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(t.mapping=e.mapping),e.wrapS!==void 0&&(t.wrapS=e.wrapS),e.wrapT!==void 0&&(t.wrapT=e.wrapT),e.wrapR!==void 0&&(t.wrapR=e.wrapR),e.magFilter!==void 0&&(t.magFilter=e.magFilter),e.minFilter!==void 0&&(t.minFilter=e.minFilter),e.format!==void 0&&(t.format=e.format),e.type!==void 0&&(t.type=e.type),e.anisotropy!==void 0&&(t.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(t.colorSpace=e.colorSpace),e.flipY!==void 0&&(t.flipY=e.flipY),e.generateMipmaps!==void 0&&(t.generateMipmaps=e.generateMipmaps),e.internalFormat!==void 0&&(t.internalFormat=e.internalFormat);for(let n=0;n<this.textures.length;n++)this.textures[n].setValues(t)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),e!==null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,t,n=1){if(this.width!==e||this.height!==t||this.depth!==n){this.width=e,this.height=t,this.depth=n;for(let r=0,s=this.textures.length;r<s;r++)this.textures[r].image.width=e,this.textures[r].image.height=t,this.textures[r].image.depth=n,this.textures[r].isArrayTexture=this.textures[r].image.depth>1;this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let t=0,n=e.textures.length;t<n;t++){this.textures[t]=e.textures[t].clone(),this.textures[t].isRenderTargetTexture=!0,this.textures[t].renderTarget=this;const r=Object.assign({},e.textures[t].image);this.textures[t].source=new kc(r)}return this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class Vn extends Em{constructor(e=1,t=1,n={}){super(e,t,n),this.isWebGLRenderTarget=!0}}class Qh extends Ft{constructor(e=null,t=1,n=1,r=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:n,depth:r},this.magFilter=Jt,this.minFilter=Jt,this.wrapR=Ci,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class Tm extends Ft{constructor(e=null,t=1,n=1,r=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:n,depth:r},this.magFilter=Jt,this.minFilter=Jt,this.wrapR=Ci,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class jn{constructor(e=new U(1/0,1/0,1/0),t=new U(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t+=3)this.expandByPoint(On.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,n=e.count;t<n;t++)this.expandByPoint(On.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const n=On.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);const n=e.geometry;if(n!==void 0){const s=n.getAttribute("position");if(t===!0&&s!==void 0&&e.isInstancedMesh!==!0)for(let a=0,o=s.count;a<o;a++)e.isMesh===!0?e.getVertexPosition(a,On):On.fromBufferAttribute(s,a),On.applyMatrix4(e.matrixWorld),this.expandByPoint(On);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),ea.copy(e.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),ea.copy(n.boundingBox)),ea.applyMatrix4(e.matrixWorld),this.union(ea)}const r=e.children;for(let s=0,a=r.length;s<a;s++)this.expandByObject(r[s],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,On),On.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,n;return e.normal.x>0?(t=e.normal.x*this.min.x,n=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,n=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,n+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,n+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,n+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,n+=e.normal.z*this.min.z),t<=-e.constant&&n>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(as),ta.subVectors(this.max,as),sr.subVectors(e.a,as),ar.subVectors(e.b,as),or.subVectors(e.c,as),pi.subVectors(ar,sr),mi.subVectors(or,ar),Bi.subVectors(sr,or);let t=[0,-pi.z,pi.y,0,-mi.z,mi.y,0,-Bi.z,Bi.y,pi.z,0,-pi.x,mi.z,0,-mi.x,Bi.z,0,-Bi.x,-pi.y,pi.x,0,-mi.y,mi.x,0,-Bi.y,Bi.x,0];return!No(t,sr,ar,or,ta)||(t=[1,0,0,0,1,0,0,0,1],!No(t,sr,ar,or,ta))?!1:(na.crossVectors(pi,mi),t=[na.x,na.y,na.z],No(t,sr,ar,or,ta))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,On).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(On).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(Jn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),Jn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),Jn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),Jn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),Jn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),Jn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),Jn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),Jn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(Jn),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}}const Jn=[new U,new U,new U,new U,new U,new U,new U,new U],On=new U,ea=new jn,sr=new U,ar=new U,or=new U,pi=new U,mi=new U,Bi=new U,as=new U,ta=new U,na=new U,ki=new U;function No(i,e,t,n,r){for(let s=0,a=i.length-3;s<=a;s+=3){ki.fromArray(i,s);const o=r.x*Math.abs(ki.x)+r.y*Math.abs(ki.y)+r.z*Math.abs(ki.z),l=e.dot(ki),c=t.dot(ki),d=n.dot(ki);if(Math.max(-Math.max(l,c,d),Math.min(l,c,d))>o)return!1}return!0}const Am=new jn,os=new U,Oo=new U;class $n{constructor(e=new U,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){const n=this.center;t!==void 0?n.copy(t):Am.setFromPoints(e).getCenter(n);let r=0;for(let s=0,a=e.length;s<a;s++)r=Math.max(r,n.distanceToSquared(e[s]));return this.radius=Math.sqrt(r),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){const n=this.center.distanceToSquared(e);return t.copy(e),n>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;os.subVectors(e,this.center);const t=os.lengthSq();if(t>this.radius*this.radius){const n=Math.sqrt(t),r=(n-this.radius)*.5;this.center.addScaledVector(os,r/n),this.radius+=r}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Oo.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(os.copy(e.center).add(Oo)),this.expandByPoint(os.copy(e.center).sub(Oo))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}}const Qn=new U,Uo=new U,ia=new U,gi=new U,Fo=new U,ra=new U,Bo=new U;class ks{constructor(e=new U,t=new U(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,Qn)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);const n=t.dot(this.direction);return n<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const t=Qn.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(Qn.copy(this.origin).addScaledVector(this.direction,t),Qn.distanceToSquared(e))}distanceSqToSegment(e,t,n,r){Uo.copy(e).add(t).multiplyScalar(.5),ia.copy(t).sub(e).normalize(),gi.copy(this.origin).sub(Uo);const s=e.distanceTo(t)*.5,a=-this.direction.dot(ia),o=gi.dot(this.direction),l=-gi.dot(ia),c=gi.lengthSq(),d=Math.abs(1-a*a);let u,h,p,g;if(d>0)if(u=a*l-o,h=a*o-l,g=s*d,u>=0)if(h>=-g)if(h<=g){const v=1/d;u*=v,h*=v,p=u*(u+a*h+2*o)+h*(a*u+h+2*l)+c}else h=s,u=Math.max(0,-(a*h+o)),p=-u*u+h*(h+2*l)+c;else h=-s,u=Math.max(0,-(a*h+o)),p=-u*u+h*(h+2*l)+c;else h<=-g?(u=Math.max(0,-(-a*s+o)),h=u>0?-s:Math.min(Math.max(-s,-l),s),p=-u*u+h*(h+2*l)+c):h<=g?(u=0,h=Math.min(Math.max(-s,-l),s),p=h*(h+2*l)+c):(u=Math.max(0,-(a*s+o)),h=u>0?s:Math.min(Math.max(-s,-l),s),p=-u*u+h*(h+2*l)+c);else h=a>0?-s:s,u=Math.max(0,-(a*h+o)),p=-u*u+h*(h+2*l)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,u),r&&r.copy(Uo).addScaledVector(ia,h),p}intersectSphere(e,t){Qn.subVectors(e.center,this.origin);const n=Qn.dot(this.direction),r=Qn.dot(Qn)-n*n,s=e.radius*e.radius;if(r>s)return null;const a=Math.sqrt(s-r),o=n-a,l=n+a;return l<0?null:o<0?this.at(l,t):this.at(o,t)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;const n=-(this.origin.dot(e.normal)+e.constant)/t;return n>=0?n:null}intersectPlane(e,t){const n=this.distanceToPlane(e);return n===null?null:this.at(n,t)}intersectsPlane(e){const t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let n,r,s,a,o,l;const c=1/this.direction.x,d=1/this.direction.y,u=1/this.direction.z,h=this.origin;return c>=0?(n=(e.min.x-h.x)*c,r=(e.max.x-h.x)*c):(n=(e.max.x-h.x)*c,r=(e.min.x-h.x)*c),d>=0?(s=(e.min.y-h.y)*d,a=(e.max.y-h.y)*d):(s=(e.max.y-h.y)*d,a=(e.min.y-h.y)*d),n>a||s>r||((s>n||isNaN(n))&&(n=s),(a<r||isNaN(r))&&(r=a),u>=0?(o=(e.min.z-h.z)*u,l=(e.max.z-h.z)*u):(o=(e.max.z-h.z)*u,l=(e.min.z-h.z)*u),n>l||o>r)||((o>n||n!==n)&&(n=o),(l<r||r!==r)&&(r=l),r<0)?null:this.at(n>=0?n:r,t)}intersectsBox(e){return this.intersectBox(e,Qn)!==null}intersectTriangle(e,t,n,r,s){Fo.subVectors(t,e),ra.subVectors(n,e),Bo.crossVectors(Fo,ra);let a=this.direction.dot(Bo),o;if(a>0){if(r)return null;o=1}else if(a<0)o=-1,a=-a;else return null;gi.subVectors(this.origin,e);const l=o*this.direction.dot(ra.crossVectors(gi,ra));if(l<0)return null;const c=o*this.direction.dot(Fo.cross(gi));if(c<0||l+c>a)return null;const d=-o*gi.dot(Bo);return d<0?null:this.at(d/a,s)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class qe{constructor(e,t,n,r,s,a,o,l,c,d,u,h,p,g,v,m){qe.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,n,r,s,a,o,l,c,d,u,h,p,g,v,m)}set(e,t,n,r,s,a,o,l,c,d,u,h,p,g,v,m){const f=this.elements;return f[0]=e,f[4]=t,f[8]=n,f[12]=r,f[1]=s,f[5]=a,f[9]=o,f[13]=l,f[2]=c,f[6]=d,f[10]=u,f[14]=h,f[3]=p,f[7]=g,f[11]=v,f[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new qe().fromArray(this.elements)}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){const t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){const t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){return e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){const t=this.elements,n=e.elements,r=1/lr.setFromMatrixColumn(e,0).length(),s=1/lr.setFromMatrixColumn(e,1).length(),a=1/lr.setFromMatrixColumn(e,2).length();return t[0]=n[0]*r,t[1]=n[1]*r,t[2]=n[2]*r,t[3]=0,t[4]=n[4]*s,t[5]=n[5]*s,t[6]=n[6]*s,t[7]=0,t[8]=n[8]*a,t[9]=n[9]*a,t[10]=n[10]*a,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){const t=this.elements,n=e.x,r=e.y,s=e.z,a=Math.cos(n),o=Math.sin(n),l=Math.cos(r),c=Math.sin(r),d=Math.cos(s),u=Math.sin(s);if(e.order==="XYZ"){const h=a*d,p=a*u,g=o*d,v=o*u;t[0]=l*d,t[4]=-l*u,t[8]=c,t[1]=p+g*c,t[5]=h-v*c,t[9]=-o*l,t[2]=v-h*c,t[6]=g+p*c,t[10]=a*l}else if(e.order==="YXZ"){const h=l*d,p=l*u,g=c*d,v=c*u;t[0]=h+v*o,t[4]=g*o-p,t[8]=a*c,t[1]=a*u,t[5]=a*d,t[9]=-o,t[2]=p*o-g,t[6]=v+h*o,t[10]=a*l}else if(e.order==="ZXY"){const h=l*d,p=l*u,g=c*d,v=c*u;t[0]=h-v*o,t[4]=-a*u,t[8]=g+p*o,t[1]=p+g*o,t[5]=a*d,t[9]=v-h*o,t[2]=-a*c,t[6]=o,t[10]=a*l}else if(e.order==="ZYX"){const h=a*d,p=a*u,g=o*d,v=o*u;t[0]=l*d,t[4]=g*c-p,t[8]=h*c+v,t[1]=l*u,t[5]=v*c+h,t[9]=p*c-g,t[2]=-c,t[6]=o*l,t[10]=a*l}else if(e.order==="YZX"){const h=a*l,p=a*c,g=o*l,v=o*c;t[0]=l*d,t[4]=v-h*u,t[8]=g*u+p,t[1]=u,t[5]=a*d,t[9]=-o*d,t[2]=-c*d,t[6]=p*u+g,t[10]=h-v*u}else if(e.order==="XZY"){const h=a*l,p=a*c,g=o*l,v=o*c;t[0]=l*d,t[4]=-u,t[8]=c*d,t[1]=h*u+v,t[5]=a*d,t[9]=p*u-g,t[2]=g*u-p,t[6]=o*d,t[10]=v*u+h}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(wm,e,Rm)}lookAt(e,t,n){const r=this.elements;return pn.subVectors(e,t),pn.lengthSq()===0&&(pn.z=1),pn.normalize(),vi.crossVectors(n,pn),vi.lengthSq()===0&&(Math.abs(n.z)===1?pn.x+=1e-4:pn.z+=1e-4,pn.normalize(),vi.crossVectors(n,pn)),vi.normalize(),sa.crossVectors(pn,vi),r[0]=vi.x,r[4]=sa.x,r[8]=pn.x,r[1]=vi.y,r[5]=sa.y,r[9]=pn.y,r[2]=vi.z,r[6]=sa.z,r[10]=pn.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,r=t.elements,s=this.elements,a=n[0],o=n[4],l=n[8],c=n[12],d=n[1],u=n[5],h=n[9],p=n[13],g=n[2],v=n[6],m=n[10],f=n[14],b=n[3],_=n[7],x=n[11],R=n[15],M=r[0],A=r[4],w=r[8],S=r[12],y=r[1],T=r[5],N=r[9],B=r[13],k=r[2],V=r[6],D=r[10],O=r[14],F=r[3],z=r[7],j=r[11],te=r[15];return s[0]=a*M+o*y+l*k+c*F,s[4]=a*A+o*T+l*V+c*z,s[8]=a*w+o*N+l*D+c*j,s[12]=a*S+o*B+l*O+c*te,s[1]=d*M+u*y+h*k+p*F,s[5]=d*A+u*T+h*V+p*z,s[9]=d*w+u*N+h*D+p*j,s[13]=d*S+u*B+h*O+p*te,s[2]=g*M+v*y+m*k+f*F,s[6]=g*A+v*T+m*V+f*z,s[10]=g*w+v*N+m*D+f*j,s[14]=g*S+v*B+m*O+f*te,s[3]=b*M+_*y+x*k+R*F,s[7]=b*A+_*T+x*V+R*z,s[11]=b*w+_*N+x*D+R*j,s[15]=b*S+_*B+x*O+R*te,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[4],r=e[8],s=e[12],a=e[1],o=e[5],l=e[9],c=e[13],d=e[2],u=e[6],h=e[10],p=e[14],g=e[3],v=e[7],m=e[11],f=e[15];return g*(+s*l*u-r*c*u-s*o*h+n*c*h+r*o*p-n*l*p)+v*(+t*l*p-t*c*h+s*a*h-r*a*p+r*c*d-s*l*d)+m*(+t*c*u-t*o*p-s*a*u+n*a*p+s*o*d-n*c*d)+f*(-r*o*d-t*l*u+t*o*h+r*a*u-n*a*h+n*l*d)}transpose(){const e=this.elements;let t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){const r=this.elements;return e.isVector3?(r[12]=e.x,r[13]=e.y,r[14]=e.z):(r[12]=e,r[13]=t,r[14]=n),this}invert(){const e=this.elements,t=e[0],n=e[1],r=e[2],s=e[3],a=e[4],o=e[5],l=e[6],c=e[7],d=e[8],u=e[9],h=e[10],p=e[11],g=e[12],v=e[13],m=e[14],f=e[15],b=u*m*c-v*h*c+v*l*p-o*m*p-u*l*f+o*h*f,_=g*h*c-d*m*c-g*l*p+a*m*p+d*l*f-a*h*f,x=d*v*c-g*u*c+g*o*p-a*v*p-d*o*f+a*u*f,R=g*u*l-d*v*l-g*o*h+a*v*h+d*o*m-a*u*m,M=t*b+n*_+r*x+s*R;if(M===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const A=1/M;return e[0]=b*A,e[1]=(v*h*s-u*m*s-v*r*p+n*m*p+u*r*f-n*h*f)*A,e[2]=(o*m*s-v*l*s+v*r*c-n*m*c-o*r*f+n*l*f)*A,e[3]=(u*l*s-o*h*s-u*r*c+n*h*c+o*r*p-n*l*p)*A,e[4]=_*A,e[5]=(d*m*s-g*h*s+g*r*p-t*m*p-d*r*f+t*h*f)*A,e[6]=(g*l*s-a*m*s-g*r*c+t*m*c+a*r*f-t*l*f)*A,e[7]=(a*h*s-d*l*s+d*r*c-t*h*c-a*r*p+t*l*p)*A,e[8]=x*A,e[9]=(g*u*s-d*v*s-g*n*p+t*v*p+d*n*f-t*u*f)*A,e[10]=(a*v*s-g*o*s+g*n*c-t*v*c-a*n*f+t*o*f)*A,e[11]=(d*o*s-a*u*s-d*n*c+t*u*c+a*n*p-t*o*p)*A,e[12]=R*A,e[13]=(d*v*r-g*u*r+g*n*h-t*v*h-d*n*m+t*u*m)*A,e[14]=(g*o*r-a*v*r-g*n*l+t*v*l+a*n*m-t*o*m)*A,e[15]=(a*u*r-d*o*r+d*n*l-t*u*l-a*n*h+t*o*h)*A,this}scale(e){const t=this.elements,n=e.x,r=e.y,s=e.z;return t[0]*=n,t[4]*=r,t[8]*=s,t[1]*=n,t[5]*=r,t[9]*=s,t[2]*=n,t[6]*=r,t[10]*=s,t[3]*=n,t[7]*=r,t[11]*=s,this}getMaxScaleOnAxis(){const e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],r=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,r))}makeTranslation(e,t,n){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1),this}makeRotationX(e){const t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){const n=Math.cos(t),r=Math.sin(t),s=1-n,a=e.x,o=e.y,l=e.z,c=s*a,d=s*o;return this.set(c*a+n,c*o-r*l,c*l+r*o,0,c*o+r*l,d*o+n,d*l-r*a,0,c*l-r*o,d*l+r*a,s*l*l+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,r,s,a){return this.set(1,n,s,0,e,1,a,0,t,r,1,0,0,0,0,1),this}compose(e,t,n){const r=this.elements,s=t._x,a=t._y,o=t._z,l=t._w,c=s+s,d=a+a,u=o+o,h=s*c,p=s*d,g=s*u,v=a*d,m=a*u,f=o*u,b=l*c,_=l*d,x=l*u,R=n.x,M=n.y,A=n.z;return r[0]=(1-(v+f))*R,r[1]=(p+x)*R,r[2]=(g-_)*R,r[3]=0,r[4]=(p-x)*M,r[5]=(1-(h+f))*M,r[6]=(m+b)*M,r[7]=0,r[8]=(g+_)*A,r[9]=(m-b)*A,r[10]=(1-(h+v))*A,r[11]=0,r[12]=e.x,r[13]=e.y,r[14]=e.z,r[15]=1,this}decompose(e,t,n){const r=this.elements;let s=lr.set(r[0],r[1],r[2]).length();const a=lr.set(r[4],r[5],r[6]).length(),o=lr.set(r[8],r[9],r[10]).length();this.determinant()<0&&(s=-s),e.x=r[12],e.y=r[13],e.z=r[14],Un.copy(this);const c=1/s,d=1/a,u=1/o;return Un.elements[0]*=c,Un.elements[1]*=c,Un.elements[2]*=c,Un.elements[4]*=d,Un.elements[5]*=d,Un.elements[6]*=d,Un.elements[8]*=u,Un.elements[9]*=u,Un.elements[10]*=u,t.setFromRotationMatrix(Un),n.x=s,n.y=a,n.z=o,this}makePerspective(e,t,n,r,s,a,o=qn,l=!1){const c=this.elements,d=2*s/(t-e),u=2*s/(n-r),h=(t+e)/(t-e),p=(n+r)/(n-r);let g,v;if(l)g=s/(a-s),v=a*s/(a-s);else if(o===qn)g=-(a+s)/(a-s),v=-2*a*s/(a-s);else if(o===Xa)g=-a/(a-s),v=-a*s/(a-s);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return c[0]=d,c[4]=0,c[8]=h,c[12]=0,c[1]=0,c[5]=u,c[9]=p,c[13]=0,c[2]=0,c[6]=0,c[10]=g,c[14]=v,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(e,t,n,r,s,a,o=qn,l=!1){const c=this.elements,d=2/(t-e),u=2/(n-r),h=-(t+e)/(t-e),p=-(n+r)/(n-r);let g,v;if(l)g=1/(a-s),v=a/(a-s);else if(o===qn)g=-2/(a-s),v=-(a+s)/(a-s);else if(o===Xa)g=-1/(a-s),v=-s/(a-s);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return c[0]=d,c[4]=0,c[8]=0,c[12]=h,c[1]=0,c[5]=u,c[9]=0,c[13]=p,c[2]=0,c[6]=0,c[10]=g,c[14]=v,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(e){const t=this.elements,n=e.elements;for(let r=0;r<16;r++)if(t[r]!==n[r])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}}const lr=new U,Un=new qe,wm=new U(0,0,0),Rm=new U(1,1,1),vi=new U,sa=new U,pn=new U,Iu=new qe,Pu=new dt;class xn{constructor(e=0,t=0,n=0,r=xn.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=n,this._order=r}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,r=this._order){return this._x=e,this._y=t,this._z=n,this._order=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){const r=e.elements,s=r[0],a=r[4],o=r[8],l=r[1],c=r[5],d=r[9],u=r[2],h=r[6],p=r[10];switch(t){case"XYZ":this._y=Math.asin(Je(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-d,p),this._z=Math.atan2(-a,s)):(this._x=Math.atan2(h,c),this._z=0);break;case"YXZ":this._x=Math.asin(-Je(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(o,p),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-u,s),this._z=0);break;case"ZXY":this._x=Math.asin(Je(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(-u,p),this._z=Math.atan2(-a,c)):(this._y=0,this._z=Math.atan2(l,s));break;case"ZYX":this._y=Math.asin(-Je(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(h,p),this._z=Math.atan2(l,s)):(this._x=0,this._z=Math.atan2(-a,c));break;case"YZX":this._z=Math.asin(Je(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-d,c),this._y=Math.atan2(-u,s)):(this._x=0,this._y=Math.atan2(o,p));break;case"XZY":this._z=Math.asin(-Je(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(h,c),this._y=Math.atan2(o,s)):(this._x=Math.atan2(-d,p),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,n===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,n){return Iu.makeRotationFromQuaternion(e),this.setFromRotationMatrix(Iu,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return Pu.setFromEuler(this),this.setFromQuaternion(Pu,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}xn.DEFAULT_ORDER="XYZ";class zc{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let Cm=0;const Lu=new U,cr=new dt,ei=new qe,aa=new U,ls=new U,Im=new U,Pm=new dt,Du=new U(1,0,0),Nu=new U(0,1,0),Ou=new U(0,0,1),Uu={type:"added"},Lm={type:"removed"},ur={type:"childadded",child:null},ko={type:"childremoved",child:null};class Mt extends Jr{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Cm++}),this.uuid=zn(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=Mt.DEFAULT_UP.clone();const e=new U,t=new xn,n=new dt,r=new U(1,1,1);function s(){n.setFromEuler(t,!1)}function a(){t.setFromQuaternion(n,void 0,!1)}t._onChange(s),n._onChange(a),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:r},modelViewMatrix:{value:new qe},normalMatrix:{value:new $e}}),this.matrix=new qe,this.matrixWorld=new qe,this.matrixAutoUpdate=Mt.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=Mt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new zc,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return cr.setFromAxisAngle(e,t),this.quaternion.multiply(cr),this}rotateOnWorldAxis(e,t){return cr.setFromAxisAngle(e,t),this.quaternion.premultiply(cr),this}rotateX(e){return this.rotateOnAxis(Du,e)}rotateY(e){return this.rotateOnAxis(Nu,e)}rotateZ(e){return this.rotateOnAxis(Ou,e)}translateOnAxis(e,t){return Lu.copy(e).applyQuaternion(this.quaternion),this.position.add(Lu.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(Du,e)}translateY(e){return this.translateOnAxis(Nu,e)}translateZ(e){return this.translateOnAxis(Ou,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(ei.copy(this.matrixWorld).invert())}lookAt(e,t,n){e.isVector3?aa.copy(e):aa.set(e,t,n);const r=this.parent;this.updateWorldMatrix(!0,!1),ls.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?ei.lookAt(ls,aa,this.up):ei.lookAt(aa,ls,this.up),this.quaternion.setFromRotationMatrix(ei),r&&(ei.extractRotation(r.matrixWorld),cr.setFromRotationMatrix(ei),this.quaternion.premultiply(cr.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(Uu),ur.child=e,this.dispatchEvent(ur),ur.child=null):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}const t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(Lm),ko.child=e,this.dispatchEvent(ko),ko.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),ei.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),ei.multiply(e.parent.matrixWorld)),e.applyMatrix4(ei),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(Uu),ur.child=e,this.dispatchEvent(ur),ur.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let n=0,r=this.children.length;n<r;n++){const a=this.children[n].getObjectByProperty(e,t);if(a!==void 0)return a}}getObjectsByProperty(e,t,n=[]){this[e]===t&&n.push(this);const r=this.children;for(let s=0,a=r.length;s<a;s++)r[s].getObjectsByProperty(e,t,n);return n}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(ls,e,Im),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(ls,Pm,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);const t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].traverseVisible(e)}traverseAncestors(e){const t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].updateMatrixWorld(e)}updateWorldMatrix(e,t){const n=this.parent;if(e===!0&&n!==null&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),t===!0){const r=this.children;for(let s=0,a=r.length;s<a;s++)r[s].updateWorldMatrix(!1,!0)}}toJSON(e){const t=e===void 0||typeof e=="string",n={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const r={};r.uuid=this.uuid,r.type=this.type,this.name!==""&&(r.name=this.name),this.castShadow===!0&&(r.castShadow=!0),this.receiveShadow===!0&&(r.receiveShadow=!0),this.visible===!1&&(r.visible=!1),this.frustumCulled===!1&&(r.frustumCulled=!1),this.renderOrder!==0&&(r.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(r.userData=this.userData),r.layers=this.layers.mask,r.matrix=this.matrix.toArray(),r.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(r.matrixAutoUpdate=!1),this.isInstancedMesh&&(r.type="InstancedMesh",r.count=this.count,r.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(r.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(r.type="BatchedMesh",r.perObjectFrustumCulled=this.perObjectFrustumCulled,r.sortObjects=this.sortObjects,r.drawRanges=this._drawRanges,r.reservedRanges=this._reservedRanges,r.geometryInfo=this._geometryInfo.map(o=>({...o,boundingBox:o.boundingBox?o.boundingBox.toJSON():void 0,boundingSphere:o.boundingSphere?o.boundingSphere.toJSON():void 0})),r.instanceInfo=this._instanceInfo.map(o=>({...o})),r.availableInstanceIds=this._availableInstanceIds.slice(),r.availableGeometryIds=this._availableGeometryIds.slice(),r.nextIndexStart=this._nextIndexStart,r.nextVertexStart=this._nextVertexStart,r.geometryCount=this._geometryCount,r.maxInstanceCount=this._maxInstanceCount,r.maxVertexCount=this._maxVertexCount,r.maxIndexCount=this._maxIndexCount,r.geometryInitialized=this._geometryInitialized,r.matricesTexture=this._matricesTexture.toJSON(e),r.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(r.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(r.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(r.boundingBox=this.boundingBox.toJSON()));function s(o,l){return o[l.uuid]===void 0&&(o[l.uuid]=l.toJSON(e)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?r.background=this.background.toJSON():this.background.isTexture&&(r.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(r.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){r.geometry=s(e.geometries,this.geometry);const o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){const l=o.shapes;if(Array.isArray(l))for(let c=0,d=l.length;c<d;c++){const u=l[c];s(e.shapes,u)}else s(e.shapes,l)}}if(this.isSkinnedMesh&&(r.bindMode=this.bindMode,r.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(s(e.skeletons,this.skeleton),r.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const o=[];for(let l=0,c=this.material.length;l<c;l++)o.push(s(e.materials,this.material[l]));r.material=o}else r.material=s(e.materials,this.material);if(this.children.length>0){r.children=[];for(let o=0;o<this.children.length;o++)r.children.push(this.children[o].toJSON(e).object)}if(this.animations.length>0){r.animations=[];for(let o=0;o<this.animations.length;o++){const l=this.animations[o];r.animations.push(s(e.animations,l))}}if(t){const o=a(e.geometries),l=a(e.materials),c=a(e.textures),d=a(e.images),u=a(e.shapes),h=a(e.skeletons),p=a(e.animations),g=a(e.nodes);o.length>0&&(n.geometries=o),l.length>0&&(n.materials=l),c.length>0&&(n.textures=c),d.length>0&&(n.images=d),u.length>0&&(n.shapes=u),h.length>0&&(n.skeletons=h),p.length>0&&(n.animations=p),g.length>0&&(n.nodes=g)}return n.object=r,n;function a(o){const l=[];for(const c in o){const d=o[c];delete d.metadata,l.push(d)}return l}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let n=0;n<e.children.length;n++){const r=e.children[n];this.add(r.clone())}return this}}Mt.DEFAULT_UP=new U(0,1,0);Mt.DEFAULT_MATRIX_AUTO_UPDATE=!0;Mt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const Fn=new U,ti=new U,zo=new U,ni=new U,dr=new U,hr=new U,Fu=new U,Vo=new U,Ho=new U,Go=new U,Wo=new rt,Xo=new rt,qo=new rt;class wn{constructor(e=new U,t=new U,n=new U){this.a=e,this.b=t,this.c=n}static getNormal(e,t,n,r){r.subVectors(n,t),Fn.subVectors(e,t),r.cross(Fn);const s=r.lengthSq();return s>0?r.multiplyScalar(1/Math.sqrt(s)):r.set(0,0,0)}static getBarycoord(e,t,n,r,s){Fn.subVectors(r,t),ti.subVectors(n,t),zo.subVectors(e,t);const a=Fn.dot(Fn),o=Fn.dot(ti),l=Fn.dot(zo),c=ti.dot(ti),d=ti.dot(zo),u=a*c-o*o;if(u===0)return s.set(0,0,0),null;const h=1/u,p=(c*l-o*d)*h,g=(a*d-o*l)*h;return s.set(1-p-g,g,p)}static containsPoint(e,t,n,r){return this.getBarycoord(e,t,n,r,ni)===null?!1:ni.x>=0&&ni.y>=0&&ni.x+ni.y<=1}static getInterpolation(e,t,n,r,s,a,o,l){return this.getBarycoord(e,t,n,r,ni)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(s,ni.x),l.addScaledVector(a,ni.y),l.addScaledVector(o,ni.z),l)}static getInterpolatedAttribute(e,t,n,r,s,a){return Wo.setScalar(0),Xo.setScalar(0),qo.setScalar(0),Wo.fromBufferAttribute(e,t),Xo.fromBufferAttribute(e,n),qo.fromBufferAttribute(e,r),a.setScalar(0),a.addScaledVector(Wo,s.x),a.addScaledVector(Xo,s.y),a.addScaledVector(qo,s.z),a}static isFrontFacing(e,t,n,r){return Fn.subVectors(n,t),ti.subVectors(e,t),Fn.cross(ti).dot(r)<0}set(e,t,n){return this.a.copy(e),this.b.copy(t),this.c.copy(n),this}setFromPointsAndIndices(e,t,n,r){return this.a.copy(e[t]),this.b.copy(e[n]),this.c.copy(e[r]),this}setFromAttributeAndIndices(e,t,n,r){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,n),this.c.fromBufferAttribute(e,r),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return Fn.subVectors(this.c,this.b),ti.subVectors(this.a,this.b),Fn.cross(ti).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return wn.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return wn.getBarycoord(e,this.a,this.b,this.c,t)}getInterpolation(e,t,n,r,s){return wn.getInterpolation(e,this.a,this.b,this.c,t,n,r,s)}containsPoint(e){return wn.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return wn.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){const n=this.a,r=this.b,s=this.c;let a,o;dr.subVectors(r,n),hr.subVectors(s,n),Vo.subVectors(e,n);const l=dr.dot(Vo),c=hr.dot(Vo);if(l<=0&&c<=0)return t.copy(n);Ho.subVectors(e,r);const d=dr.dot(Ho),u=hr.dot(Ho);if(d>=0&&u<=d)return t.copy(r);const h=l*u-d*c;if(h<=0&&l>=0&&d<=0)return a=l/(l-d),t.copy(n).addScaledVector(dr,a);Go.subVectors(e,s);const p=dr.dot(Go),g=hr.dot(Go);if(g>=0&&p<=g)return t.copy(s);const v=p*c-l*g;if(v<=0&&c>=0&&g<=0)return o=c/(c-g),t.copy(n).addScaledVector(hr,o);const m=d*g-p*u;if(m<=0&&u-d>=0&&p-g>=0)return Fu.subVectors(s,r),o=(u-d)/(u-d+(p-g)),t.copy(r).addScaledVector(Fu,o);const f=1/(m+v+h);return a=v*f,o=h*f,t.copy(n).addScaledVector(dr,a).addScaledVector(hr,o)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}const ef={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},_i={h:0,s:0,l:0},oa={h:0,s:0,l:0};function Yo(i,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?i+(e-i)*6*t:t<1/2?e:t<2/3?i+(e-i)*6*(2/3-t):i}class Ie{constructor(e,t,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,n)}set(e,t,n){if(t===void 0&&n===void 0){const r=e;r&&r.isColor?this.copy(r):typeof r=="number"?this.setHex(r):typeof r=="string"&&this.setStyle(r)}else this.setRGB(e,t,n);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=_t){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,tt.colorSpaceToWorking(this,t),this}setRGB(e,t,n,r=tt.workingColorSpace){return this.r=e,this.g=t,this.b=n,tt.colorSpaceToWorking(this,r),this}setHSL(e,t,n,r=tt.workingColorSpace){if(e=Bc(e,1),t=Je(t,0,1),n=Je(n,0,1),t===0)this.r=this.g=this.b=n;else{const s=n<=.5?n*(1+t):n+t-n*t,a=2*n-s;this.r=Yo(a,s,e+1/3),this.g=Yo(a,s,e),this.b=Yo(a,s,e-1/3)}return tt.colorSpaceToWorking(this,r),this}setStyle(e,t=_t){function n(s){s!==void 0&&parseFloat(s)<1&&console.warn("THREE.Color: Alpha component of "+e+" will be ignored.")}let r;if(r=/^(\w+)\(([^\)]*)\)/.exec(e)){let s;const a=r[1],o=r[2];switch(a){case"rgb":case"rgba":if(s=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(s[4]),this.setRGB(Math.min(255,parseInt(s[1],10))/255,Math.min(255,parseInt(s[2],10))/255,Math.min(255,parseInt(s[3],10))/255,t);if(s=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(s[4]),this.setRGB(Math.min(100,parseInt(s[1],10))/100,Math.min(100,parseInt(s[2],10))/100,Math.min(100,parseInt(s[3],10))/100,t);break;case"hsl":case"hsla":if(s=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(s[4]),this.setHSL(parseFloat(s[1])/360,parseFloat(s[2])/100,parseFloat(s[3])/100,t);break;default:console.warn("THREE.Color: Unknown color model "+e)}}else if(r=/^\#([A-Fa-f\d]+)$/.exec(e)){const s=r[1],a=s.length;if(a===3)return this.setRGB(parseInt(s.charAt(0),16)/15,parseInt(s.charAt(1),16)/15,parseInt(s.charAt(2),16)/15,t);if(a===6)return this.setHex(parseInt(s,16),t);console.warn("THREE.Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=_t){const n=ef[e.toLowerCase()];return n!==void 0?this.setHex(n,t):console.warn("THREE.Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=hi(e.r),this.g=hi(e.g),this.b=hi(e.b),this}copyLinearToSRGB(e){return this.r=Pr(e.r),this.g=Pr(e.g),this.b=Pr(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=_t){return tt.workingToColorSpace(qt.copy(this),e),Math.round(Je(qt.r*255,0,255))*65536+Math.round(Je(qt.g*255,0,255))*256+Math.round(Je(qt.b*255,0,255))}getHexString(e=_t){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=tt.workingColorSpace){tt.workingToColorSpace(qt.copy(this),t);const n=qt.r,r=qt.g,s=qt.b,a=Math.max(n,r,s),o=Math.min(n,r,s);let l,c;const d=(o+a)/2;if(o===a)l=0,c=0;else{const u=a-o;switch(c=d<=.5?u/(a+o):u/(2-a-o),a){case n:l=(r-s)/u+(r<s?6:0);break;case r:l=(s-n)/u+2;break;case s:l=(n-r)/u+4;break}l/=6}return e.h=l,e.s=c,e.l=d,e}getRGB(e,t=tt.workingColorSpace){return tt.workingToColorSpace(qt.copy(this),t),e.r=qt.r,e.g=qt.g,e.b=qt.b,e}getStyle(e=_t){tt.workingToColorSpace(qt.copy(this),e);const t=qt.r,n=qt.g,r=qt.b;return e!==_t?`color(${e} ${t.toFixed(3)} ${n.toFixed(3)} ${r.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(n*255)},${Math.round(r*255)})`}offsetHSL(e,t,n){return this.getHSL(_i),this.setHSL(_i.h+e,_i.s+t,_i.l+n)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,n){return this.r=e.r+(t.r-e.r)*n,this.g=e.g+(t.g-e.g)*n,this.b=e.b+(t.b-e.b)*n,this}lerpHSL(e,t){this.getHSL(_i),e.getHSL(oa);const n=Ts(_i.h,oa.h,t),r=Ts(_i.s,oa.s,t),s=Ts(_i.l,oa.l,t);return this.setHSL(n,r,s),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const t=this.r,n=this.g,r=this.b,s=e.elements;return this.r=s[0]*t+s[3]*n+s[6]*r,this.g=s[1]*t+s[4]*n+s[7]*r,this.b=s[2]*t+s[5]*n+s[8]*r,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const qt=new Ie;Ie.NAMES=ef;let Dm=0;class In extends Jr{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Dm++}),this.uuid=zn(),this.name="",this.type="Material",this.blending=Ii,this.side=fi,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Al,this.blendDst=wl,this.blendEquation=ji,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Ie(0,0,0),this.blendAlpha=0,this.depthFunc=Fr,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Mu,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=ir,this.stencilZFail=ir,this.stencilZPass=ir,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const t in e){const n=e[t];if(n===void 0){console.warn(`THREE.Material: parameter '${t}' has value of undefined.`);continue}const r=this[t];if(r===void 0){console.warn(`THREE.Material: '${t}' is not a property of THREE.${this.type}.`);continue}r&&r.isColor?r.set(n):r&&r.isVector3&&n&&n.isVector3?r.copy(n):this[t]=n}}toJSON(e){const t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});const n={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(n.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(n.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(e).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(e).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(e).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(e).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(e).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==Ii&&(n.blending=this.blending),this.side!==fi&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==Al&&(n.blendSrc=this.blendSrc),this.blendDst!==wl&&(n.blendDst=this.blendDst),this.blendEquation!==ji&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==Fr&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Mu&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==ir&&(n.stencilFail=this.stencilFail),this.stencilZFail!==ir&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==ir&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function r(s){const a=[];for(const o in s){const l=s[o];delete l.metadata,a.push(l)}return a}if(t){const s=r(e.textures),a=r(e.images);s.length>0&&(n.textures=s),a.length>0&&(n.images=a)}return n}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const t=e.clippingPlanes;let n=null;if(t!==null){const r=t.length;n=new Array(r);for(let s=0;s!==r;++s)n[s]=t[s].clone()}return this.clippingPlanes=n,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}class Ut extends In{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Ie(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new xn,this.combine=Cc,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const Nt=new U,la=new Ce;let Nm=0;class ct{constructor(e,t,n=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:Nm++}),this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=n,this.usage=hc,this.updateRanges=[],this.gpuType=kn,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,n){e*=this.itemSize,n*=t.itemSize;for(let r=0,s=this.itemSize;r<s;r++)this.array[e+r]=t.array[n+r];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,n=this.count;t<n;t++)la.fromBufferAttribute(this,t),la.applyMatrix3(e),this.setXY(t,la.x,la.y);else if(this.itemSize===3)for(let t=0,n=this.count;t<n;t++)Nt.fromBufferAttribute(this,t),Nt.applyMatrix3(e),this.setXYZ(t,Nt.x,Nt.y,Nt.z);return this}applyMatrix4(e){for(let t=0,n=this.count;t<n;t++)Nt.fromBufferAttribute(this,t),Nt.applyMatrix4(e),this.setXYZ(t,Nt.x,Nt.y,Nt.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)Nt.fromBufferAttribute(this,t),Nt.applyNormalMatrix(e),this.setXYZ(t,Nt.x,Nt.y,Nt.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)Nt.fromBufferAttribute(this,t),Nt.transformDirection(e),this.setXYZ(t,Nt.x,Nt.y,Nt.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let n=this.array[e*this.itemSize+t];return this.normalized&&(n=Bn(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=ot(n,this.array)),this.array[e*this.itemSize+t]=n,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=Bn(t,this.array)),t}setX(e,t){return this.normalized&&(t=ot(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=Bn(t,this.array)),t}setY(e,t){return this.normalized&&(t=ot(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=Bn(t,this.array)),t}setZ(e,t){return this.normalized&&(t=ot(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=Bn(t,this.array)),t}setW(e,t){return this.normalized&&(t=ot(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,n){return e*=this.itemSize,this.normalized&&(t=ot(t,this.array),n=ot(n,this.array)),this.array[e+0]=t,this.array[e+1]=n,this}setXYZ(e,t,n,r){return e*=this.itemSize,this.normalized&&(t=ot(t,this.array),n=ot(n,this.array),r=ot(r,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=r,this}setXYZW(e,t,n,r,s){return e*=this.itemSize,this.normalized&&(t=ot(t,this.array),n=ot(n,this.array),r=ot(r,this.array),s=ot(s,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=r,this.array[e+3]=s,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==hc&&(e.usage=this.usage),e}}class oo extends ct{constructor(e,t,n){super(new Uint16Array(e),t,n)}}class tf extends ct{constructor(e,t,n){super(new Uint32Array(e),t,n)}}class nt extends ct{constructor(e,t,n){super(new Float32Array(e),t,n)}}let Om=0;const Mn=new qe,jo=new Mt,fr=new U,mn=new jn,cs=new jn,zt=new U;class Lt extends Jr{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:Om++}),this.uuid=zn(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(Jh(e)?tf:oo)(e,1):this.index=e,this}setIndirect(e){return this.indirect=e,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,n=0){this.groups.push({start:e,count:t,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){const t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);const n=this.attributes.normal;if(n!==void 0){const s=new $e().getNormalMatrix(e);n.applyNormalMatrix(s),n.needsUpdate=!0}const r=this.attributes.tangent;return r!==void 0&&(r.transformDirection(e),r.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return Mn.makeRotationFromQuaternion(e),this.applyMatrix4(Mn),this}rotateX(e){return Mn.makeRotationX(e),this.applyMatrix4(Mn),this}rotateY(e){return Mn.makeRotationY(e),this.applyMatrix4(Mn),this}rotateZ(e){return Mn.makeRotationZ(e),this.applyMatrix4(Mn),this}translate(e,t,n){return Mn.makeTranslation(e,t,n),this.applyMatrix4(Mn),this}scale(e,t,n){return Mn.makeScale(e,t,n),this.applyMatrix4(Mn),this}lookAt(e){return jo.lookAt(e),jo.updateMatrix(),this.applyMatrix4(jo.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(fr).negate(),this.translate(fr.x,fr.y,fr.z),this}setFromPoints(e){const t=this.getAttribute("position");if(t===void 0){const n=[];for(let r=0,s=e.length;r<s;r++){const a=e[r];n.push(a.x,a.y,a.z||0)}this.setAttribute("position",new nt(n,3))}else{const n=Math.min(e.length,t.count);for(let r=0;r<n;r++){const s=e[r];t.setXYZ(r,s.x,s.y,s.z||0)}e.length>t.count&&console.warn("THREE.BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new jn);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new U(-1/0,-1/0,-1/0),new U(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let n=0,r=t.length;n<r;n++){const s=t[n];mn.setFromBufferAttribute(s),this.morphTargetsRelative?(zt.addVectors(this.boundingBox.min,mn.min),this.boundingBox.expandByPoint(zt),zt.addVectors(this.boundingBox.max,mn.max),this.boundingBox.expandByPoint(zt)):(this.boundingBox.expandByPoint(mn.min),this.boundingBox.expandByPoint(mn.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new $n);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new U,1/0);return}if(e){const n=this.boundingSphere.center;if(mn.setFromBufferAttribute(e),t)for(let s=0,a=t.length;s<a;s++){const o=t[s];cs.setFromBufferAttribute(o),this.morphTargetsRelative?(zt.addVectors(mn.min,cs.min),mn.expandByPoint(zt),zt.addVectors(mn.max,cs.max),mn.expandByPoint(zt)):(mn.expandByPoint(cs.min),mn.expandByPoint(cs.max))}mn.getCenter(n);let r=0;for(let s=0,a=e.count;s<a;s++)zt.fromBufferAttribute(e,s),r=Math.max(r,n.distanceToSquared(zt));if(t)for(let s=0,a=t.length;s<a;s++){const o=t[s],l=this.morphTargetsRelative;for(let c=0,d=o.count;c<d;c++)zt.fromBufferAttribute(o,c),l&&(fr.fromBufferAttribute(e,c),zt.add(fr)),r=Math.max(r,n.distanceToSquared(zt))}this.boundingSphere.radius=Math.sqrt(r),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const n=t.position,r=t.normal,s=t.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new ct(new Float32Array(4*n.count),4));const a=this.getAttribute("tangent"),o=[],l=[];for(let w=0;w<n.count;w++)o[w]=new U,l[w]=new U;const c=new U,d=new U,u=new U,h=new Ce,p=new Ce,g=new Ce,v=new U,m=new U;function f(w,S,y){c.fromBufferAttribute(n,w),d.fromBufferAttribute(n,S),u.fromBufferAttribute(n,y),h.fromBufferAttribute(s,w),p.fromBufferAttribute(s,S),g.fromBufferAttribute(s,y),d.sub(c),u.sub(c),p.sub(h),g.sub(h);const T=1/(p.x*g.y-g.x*p.y);isFinite(T)&&(v.copy(d).multiplyScalar(g.y).addScaledVector(u,-p.y).multiplyScalar(T),m.copy(u).multiplyScalar(p.x).addScaledVector(d,-g.x).multiplyScalar(T),o[w].add(v),o[S].add(v),o[y].add(v),l[w].add(m),l[S].add(m),l[y].add(m))}let b=this.groups;b.length===0&&(b=[{start:0,count:e.count}]);for(let w=0,S=b.length;w<S;++w){const y=b[w],T=y.start,N=y.count;for(let B=T,k=T+N;B<k;B+=3)f(e.getX(B+0),e.getX(B+1),e.getX(B+2))}const _=new U,x=new U,R=new U,M=new U;function A(w){R.fromBufferAttribute(r,w),M.copy(R);const S=o[w];_.copy(S),_.sub(R.multiplyScalar(R.dot(S))).normalize(),x.crossVectors(M,S);const T=x.dot(l[w])<0?-1:1;a.setXYZW(w,_.x,_.y,_.z,T)}for(let w=0,S=b.length;w<S;++w){const y=b[w],T=y.start,N=y.count;for(let B=T,k=T+N;B<k;B+=3)A(e.getX(B+0)),A(e.getX(B+1)),A(e.getX(B+2))}}computeVertexNormals(){const e=this.index,t=this.getAttribute("position");if(t!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new ct(new Float32Array(t.count*3),3),this.setAttribute("normal",n);else for(let h=0,p=n.count;h<p;h++)n.setXYZ(h,0,0,0);const r=new U,s=new U,a=new U,o=new U,l=new U,c=new U,d=new U,u=new U;if(e)for(let h=0,p=e.count;h<p;h+=3){const g=e.getX(h+0),v=e.getX(h+1),m=e.getX(h+2);r.fromBufferAttribute(t,g),s.fromBufferAttribute(t,v),a.fromBufferAttribute(t,m),d.subVectors(a,s),u.subVectors(r,s),d.cross(u),o.fromBufferAttribute(n,g),l.fromBufferAttribute(n,v),c.fromBufferAttribute(n,m),o.add(d),l.add(d),c.add(d),n.setXYZ(g,o.x,o.y,o.z),n.setXYZ(v,l.x,l.y,l.z),n.setXYZ(m,c.x,c.y,c.z)}else for(let h=0,p=t.count;h<p;h+=3)r.fromBufferAttribute(t,h+0),s.fromBufferAttribute(t,h+1),a.fromBufferAttribute(t,h+2),d.subVectors(a,s),u.subVectors(r,s),d.cross(u),n.setXYZ(h+0,d.x,d.y,d.z),n.setXYZ(h+1,d.x,d.y,d.z),n.setXYZ(h+2,d.x,d.y,d.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let t=0,n=e.count;t<n;t++)zt.fromBufferAttribute(e,t),zt.normalize(),e.setXYZ(t,zt.x,zt.y,zt.z)}toNonIndexed(){function e(o,l){const c=o.array,d=o.itemSize,u=o.normalized,h=new c.constructor(l.length*d);let p=0,g=0;for(let v=0,m=l.length;v<m;v++){o.isInterleavedBufferAttribute?p=l[v]*o.data.stride+o.offset:p=l[v]*d;for(let f=0;f<d;f++)h[g++]=c[p++]}return new ct(h,d,u)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const t=new Lt,n=this.index.array,r=this.attributes;for(const o in r){const l=r[o],c=e(l,n);t.setAttribute(o,c)}const s=this.morphAttributes;for(const o in s){const l=[],c=s[o];for(let d=0,u=c.length;d<u;d++){const h=c[d],p=e(h,n);l.push(p)}t.morphAttributes[o]=l}t.morphTargetsRelative=this.morphTargetsRelative;const a=this.groups;for(let o=0,l=a.length;o<l;o++){const c=a[o];t.addGroup(c.start,c.count,c.materialIndex)}return t}toJSON(){const e={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){const l=this.parameters;for(const c in l)l[c]!==void 0&&(e[c]=l[c]);return e}e.data={attributes:{}};const t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});const n=this.attributes;for(const l in n){const c=n[l];e.data.attributes[l]=c.toJSON(e.data)}const r={};let s=!1;for(const l in this.morphAttributes){const c=this.morphAttributes[l],d=[];for(let u=0,h=c.length;u<h;u++){const p=c[u];d.push(p.toJSON(e.data))}d.length>0&&(r[l]=d,s=!0)}s&&(e.data.morphAttributes=r,e.data.morphTargetsRelative=this.morphTargetsRelative);const a=this.groups;a.length>0&&(e.data.groups=JSON.parse(JSON.stringify(a)));const o=this.boundingSphere;return o!==null&&(e.data.boundingSphere=o.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const t={};this.name=e.name;const n=e.index;n!==null&&this.setIndex(n.clone());const r=e.attributes;for(const c in r){const d=r[c];this.setAttribute(c,d.clone(t))}const s=e.morphAttributes;for(const c in s){const d=[],u=s[c];for(let h=0,p=u.length;h<p;h++)d.push(u[h].clone(t));this.morphAttributes[c]=d}this.morphTargetsRelative=e.morphTargetsRelative;const a=e.groups;for(let c=0,d=a.length;c<d;c++){const u=a[c];this.addGroup(u.start,u.count,u.materialIndex)}const o=e.boundingBox;o!==null&&(this.boundingBox=o.clone());const l=e.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const Bu=new qe,zi=new ks,ca=new $n,ku=new U,ua=new U,da=new U,ha=new U,$o=new U,fa=new U,zu=new U,pa=new U;class ht extends Mt{constructor(e=new Lt,t=new Ut){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const r=t[n[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,a=r.length;s<a;s++){const o=r[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=s}}}}getVertexPosition(e,t){const n=this.geometry,r=n.attributes.position,s=n.morphAttributes.position,a=n.morphTargetsRelative;t.fromBufferAttribute(r,e);const o=this.morphTargetInfluences;if(s&&o){fa.set(0,0,0);for(let l=0,c=s.length;l<c;l++){const d=o[l],u=s[l];d!==0&&($o.fromBufferAttribute(u,e),a?fa.addScaledVector($o,d):fa.addScaledVector($o.sub(t),d))}t.add(fa)}return t}raycast(e,t){const n=this.geometry,r=this.material,s=this.matrixWorld;r!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),ca.copy(n.boundingSphere),ca.applyMatrix4(s),zi.copy(e.ray).recast(e.near),!(ca.containsPoint(zi.origin)===!1&&(zi.intersectSphere(ca,ku)===null||zi.origin.distanceToSquared(ku)>(e.far-e.near)**2))&&(Bu.copy(s).invert(),zi.copy(e.ray).applyMatrix4(Bu),!(n.boundingBox!==null&&zi.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(e,t,zi)))}_computeIntersections(e,t,n){let r;const s=this.geometry,a=this.material,o=s.index,l=s.attributes.position,c=s.attributes.uv,d=s.attributes.uv1,u=s.attributes.normal,h=s.groups,p=s.drawRange;if(o!==null)if(Array.isArray(a))for(let g=0,v=h.length;g<v;g++){const m=h[g],f=a[m.materialIndex],b=Math.max(m.start,p.start),_=Math.min(o.count,Math.min(m.start+m.count,p.start+p.count));for(let x=b,R=_;x<R;x+=3){const M=o.getX(x),A=o.getX(x+1),w=o.getX(x+2);r=ma(this,f,e,n,c,d,u,M,A,w),r&&(r.faceIndex=Math.floor(x/3),r.face.materialIndex=m.materialIndex,t.push(r))}}else{const g=Math.max(0,p.start),v=Math.min(o.count,p.start+p.count);for(let m=g,f=v;m<f;m+=3){const b=o.getX(m),_=o.getX(m+1),x=o.getX(m+2);r=ma(this,a,e,n,c,d,u,b,_,x),r&&(r.faceIndex=Math.floor(m/3),t.push(r))}}else if(l!==void 0)if(Array.isArray(a))for(let g=0,v=h.length;g<v;g++){const m=h[g],f=a[m.materialIndex],b=Math.max(m.start,p.start),_=Math.min(l.count,Math.min(m.start+m.count,p.start+p.count));for(let x=b,R=_;x<R;x+=3){const M=x,A=x+1,w=x+2;r=ma(this,f,e,n,c,d,u,M,A,w),r&&(r.faceIndex=Math.floor(x/3),r.face.materialIndex=m.materialIndex,t.push(r))}}else{const g=Math.max(0,p.start),v=Math.min(l.count,p.start+p.count);for(let m=g,f=v;m<f;m+=3){const b=m,_=m+1,x=m+2;r=ma(this,a,e,n,c,d,u,b,_,x),r&&(r.faceIndex=Math.floor(m/3),t.push(r))}}}}function Um(i,e,t,n,r,s,a,o){let l;if(e.side===cn?l=n.intersectTriangle(a,s,r,!0,o):l=n.intersectTriangle(r,s,a,e.side===fi,o),l===null)return null;pa.copy(o),pa.applyMatrix4(i.matrixWorld);const c=t.ray.origin.distanceTo(pa);return c<t.near||c>t.far?null:{distance:c,point:pa.clone(),object:i}}function ma(i,e,t,n,r,s,a,o,l,c){i.getVertexPosition(o,ua),i.getVertexPosition(l,da),i.getVertexPosition(c,ha);const d=Um(i,e,t,n,ua,da,ha,zu);if(d){const u=new U;wn.getBarycoord(zu,ua,da,ha,u),r&&(d.uv=wn.getInterpolatedAttribute(r,o,l,c,u,new Ce)),s&&(d.uv1=wn.getInterpolatedAttribute(s,o,l,c,u,new Ce)),a&&(d.normal=wn.getInterpolatedAttribute(a,o,l,c,u,new U),d.normal.dot(n.direction)>0&&d.normal.multiplyScalar(-1));const h={a:o,b:l,c,normal:new U,materialIndex:0};wn.getNormal(ua,da,ha,h.normal),d.face=h,d.barycoord=u}return d}class zs extends Lt{constructor(e=1,t=1,n=1,r=1,s=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:n,widthSegments:r,heightSegments:s,depthSegments:a};const o=this;r=Math.floor(r),s=Math.floor(s),a=Math.floor(a);const l=[],c=[],d=[],u=[];let h=0,p=0;g("z","y","x",-1,-1,n,t,e,a,s,0),g("z","y","x",1,-1,n,t,-e,a,s,1),g("x","z","y",1,1,e,n,t,r,a,2),g("x","z","y",1,-1,e,n,-t,r,a,3),g("x","y","z",1,-1,e,t,n,r,s,4),g("x","y","z",-1,-1,e,t,-n,r,s,5),this.setIndex(l),this.setAttribute("position",new nt(c,3)),this.setAttribute("normal",new nt(d,3)),this.setAttribute("uv",new nt(u,2));function g(v,m,f,b,_,x,R,M,A,w,S){const y=x/A,T=R/w,N=x/2,B=R/2,k=M/2,V=A+1,D=w+1;let O=0,F=0;const z=new U;for(let j=0;j<D;j++){const te=j*T-B;for(let L=0;L<V;L++){const $=L*y-N;z[v]=$*b,z[m]=te*_,z[f]=k,c.push(z.x,z.y,z.z),z[v]=0,z[m]=0,z[f]=M>0?1:-1,d.push(z.x,z.y,z.z),u.push(L/A),u.push(1-j/w),O+=1}}for(let j=0;j<w;j++)for(let te=0;te<A;te++){const L=h+te+V*j,$=h+te+V*(j+1),Z=h+(te+1)+V*(j+1),ae=h+(te+1)+V*j;l.push(L,$,ae),l.push($,Z,ae),F+=6}o.addGroup(p,F,S),p+=F,h+=O}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new zs(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}function Hr(i){const e={};for(const t in i){e[t]={};for(const n in i[t]){const r=i[t][n];r&&(r.isColor||r.isMatrix3||r.isMatrix4||r.isVector2||r.isVector3||r.isVector4||r.isTexture||r.isQuaternion)?r.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][n]=null):e[t][n]=r.clone():Array.isArray(r)?e[t][n]=r.slice():e[t][n]=r}}return e}function $t(i){const e={};for(let t=0;t<i.length;t++){const n=Hr(i[t]);for(const r in n)e[r]=n[r]}return e}function Fm(i){const e=[];for(let t=0;t<i.length;t++)e.push(i[t].clone());return e}function nf(i){const e=i.getRenderTarget();return e===null?i.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:tt.workingColorSpace}const qa={clone:Hr,merge:$t};var Bm=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,km=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class wt extends In{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=Bm,this.fragmentShader=km,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=Hr(e.uniforms),this.uniformsGroups=Fm(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this}toJSON(e){const t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(const r in this.uniforms){const a=this.uniforms[r].value;a&&a.isTexture?t.uniforms[r]={type:"t",value:a.toJSON(e).uuid}:a&&a.isColor?t.uniforms[r]={type:"c",value:a.getHex()}:a&&a.isVector2?t.uniforms[r]={type:"v2",value:a.toArray()}:a&&a.isVector3?t.uniforms[r]={type:"v3",value:a.toArray()}:a&&a.isVector4?t.uniforms[r]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?t.uniforms[r]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?t.uniforms[r]={type:"m4",value:a.toArray()}:t.uniforms[r]={value:a}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;const n={};for(const r in this.extensions)this.extensions[r]===!0&&(n[r]=!0);return Object.keys(n).length>0&&(t.extensions=n),t}}class rf extends Mt{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new qe,this.projectionMatrix=new qe,this.projectionMatrixInverse=new qe,this.coordinateSystem=qn,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,t){super.updateWorldMatrix(e,t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}}const xi=new U,Vu=new Ce,Hu=new Ce;class Kt extends rf{constructor(e=50,t=1,n=.1,r=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=n,this.far=r,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const t=.5*this.getFilmHeight()/e;this.fov=Vr*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(Es*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return Vr*2*Math.atan(Math.tan(Es*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,n){xi.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(xi.x,xi.y).multiplyScalar(-e/xi.z),xi.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(xi.x,xi.y).multiplyScalar(-e/xi.z)}getViewSize(e,t){return this.getViewBounds(e,Vu,Hu),t.subVectors(Hu,Vu)}setViewOffset(e,t,n,r,s,a){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=r,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let t=e*Math.tan(Es*.5*this.fov)/this.zoom,n=2*t,r=this.aspect*n,s=-.5*r;const a=this.view;if(this.view!==null&&this.view.enabled){const l=a.fullWidth,c=a.fullHeight;s+=a.offsetX*r/l,t-=a.offsetY*n/c,r*=a.width/l,n*=a.height/c}const o=this.filmOffset;o!==0&&(s+=e*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(s,s+r,t,t-n,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}}const pr=-90,mr=1;class zm extends Mt{constructor(e,t,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;const r=new Kt(pr,mr,e,t);r.layers=this.layers,this.add(r);const s=new Kt(pr,mr,e,t);s.layers=this.layers,this.add(s);const a=new Kt(pr,mr,e,t);a.layers=this.layers,this.add(a);const o=new Kt(pr,mr,e,t);o.layers=this.layers,this.add(o);const l=new Kt(pr,mr,e,t);l.layers=this.layers,this.add(l);const c=new Kt(pr,mr,e,t);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){const e=this.coordinateSystem,t=this.children.concat(),[n,r,s,a,o,l]=t;for(const c of t)this.remove(c);if(e===qn)n.up.set(0,1,0),n.lookAt(1,0,0),r.up.set(0,1,0),r.lookAt(-1,0,0),s.up.set(0,0,-1),s.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(e===Xa)n.up.set(0,-1,0),n.lookAt(-1,0,0),r.up.set(0,-1,0),r.lookAt(1,0,0),s.up.set(0,0,1),s.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const c of t)this.add(c),c.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();const{renderTarget:n,activeMipmapLevel:r}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[s,a,o,l,c,d]=this.children,u=e.getRenderTarget(),h=e.getActiveCubeFace(),p=e.getActiveMipmapLevel(),g=e.xr.enabled;e.xr.enabled=!1;const v=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,e.setRenderTarget(n,0,r),e.render(t,s),e.setRenderTarget(n,1,r),e.render(t,a),e.setRenderTarget(n,2,r),e.render(t,o),e.setRenderTarget(n,3,r),e.render(t,l),e.setRenderTarget(n,4,r),e.render(t,c),n.texture.generateMipmaps=v,e.setRenderTarget(n,5,r),e.render(t,d),e.setRenderTarget(u,h,p),e.xr.enabled=g,n.texture.needsPMREMUpdate=!0}}class sf extends Ft{constructor(e=[],t=Br,n,r,s,a,o,l,c,d){super(e,t,n,r,s,a,o,l,c,d),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class Vm extends Vn{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;const n={width:e,height:e,depth:1},r=[n,n,n,n,n,n];this.texture=new sf(r),this._setTextureOptions(t),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;const n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},r=new zs(5,5,5),s=new wt({name:"CubemapFromEquirect",uniforms:Hr(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:cn,blending:ui});s.uniforms.tEquirect.value=t;const a=new ht(r,s),o=t.minFilter;return t.minFilter===Gt&&(t.minFilter=Dt),new zm(1,10,this).update(e,a),t.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(e,t=!0,n=!0,r=!0){const s=e.getRenderTarget();for(let a=0;a<6;a++)e.setRenderTarget(this,a),e.clear(t,n,r);e.setRenderTarget(s)}}class Rt extends Mt{constructor(){super(),this.isGroup=!0,this.type="Group"}}const Hm={type:"move"};class Ko{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new Rt,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new Rt,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new U,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new U),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new Rt,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new U,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new U),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const t=this._hand;if(t)for(const n of e.hand.values())this._getHandJoint(t,n)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,n){let r=null,s=null,a=null;const o=this._targetRay,l=this._grip,c=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(c&&e.hand){a=!0;for(const v of e.hand.values()){const m=t.getJointPose(v,n),f=this._getHandJoint(c,v);m!==null&&(f.matrix.fromArray(m.transform.matrix),f.matrix.decompose(f.position,f.rotation,f.scale),f.matrixWorldNeedsUpdate=!0,f.jointRadius=m.radius),f.visible=m!==null}const d=c.joints["index-finger-tip"],u=c.joints["thumb-tip"],h=d.position.distanceTo(u.position),p=.02,g=.005;c.inputState.pinching&&h>p+g?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!c.inputState.pinching&&h<=p-g&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else l!==null&&e.gripSpace&&(s=t.getPose(e.gripSpace,n),s!==null&&(l.matrix.fromArray(s.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,s.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(s.linearVelocity)):l.hasLinearVelocity=!1,s.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(s.angularVelocity)):l.hasAngularVelocity=!1));o!==null&&(r=t.getPose(e.targetRaySpace,n),r===null&&s!==null&&(r=s),r!==null&&(o.matrix.fromArray(r.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,r.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(r.linearVelocity)):o.hasLinearVelocity=!1,r.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(r.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(Hm)))}return o!==null&&(o.visible=r!==null),l!==null&&(l.visible=s!==null),c!==null&&(c.visible=a!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){const n=new Rt;n.matrixAutoUpdate=!1,n.visible=!1,e.joints[t.jointName]=n,e.add(n)}return e.joints[t.jointName]}}class af extends Mt{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new xn,this.environmentIntensity=1,this.environmentRotation=new xn,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(t.object.environmentIntensity=this.environmentIntensity),t.object.environmentRotation=this.environmentRotation.toArray(),t}}class of{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e!==void 0?e.length/t:0,this.usage=hc,this.updateRanges=[],this.version=0,this.uuid=zn()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,n){e*=this.stride,n*=t.stride;for(let r=0,s=this.stride;r<s;r++)this.array[e+r]=t.array[n+r];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=zn()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);const t=new this.array.constructor(e.arrayBuffers[this.array.buffer._uuid]),n=new this.constructor(t,this.stride);return n.setUsage(this.usage),n}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){return e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=zn()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}}const jt=new U;class Us{constructor(e,t,n,r=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=e,this.itemSize=t,this.offset=n,this.normalized=r}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let t=0,n=this.data.count;t<n;t++)jt.fromBufferAttribute(this,t),jt.applyMatrix4(e),this.setXYZ(t,jt.x,jt.y,jt.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)jt.fromBufferAttribute(this,t),jt.applyNormalMatrix(e),this.setXYZ(t,jt.x,jt.y,jt.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)jt.fromBufferAttribute(this,t),jt.transformDirection(e),this.setXYZ(t,jt.x,jt.y,jt.z);return this}getComponent(e,t){let n=this.array[e*this.data.stride+this.offset+t];return this.normalized&&(n=Bn(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=ot(n,this.array)),this.data.array[e*this.data.stride+this.offset+t]=n,this}setX(e,t){return this.normalized&&(t=ot(t,this.array)),this.data.array[e*this.data.stride+this.offset]=t,this}setY(e,t){return this.normalized&&(t=ot(t,this.array)),this.data.array[e*this.data.stride+this.offset+1]=t,this}setZ(e,t){return this.normalized&&(t=ot(t,this.array)),this.data.array[e*this.data.stride+this.offset+2]=t,this}setW(e,t){return this.normalized&&(t=ot(t,this.array)),this.data.array[e*this.data.stride+this.offset+3]=t,this}getX(e){let t=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(t=Bn(t,this.array)),t}getY(e){let t=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(t=Bn(t,this.array)),t}getZ(e){let t=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(t=Bn(t,this.array)),t}getW(e){let t=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(t=Bn(t,this.array)),t}setXY(e,t,n){return e=e*this.data.stride+this.offset,this.normalized&&(t=ot(t,this.array),n=ot(n,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this}setXYZ(e,t,n,r){return e=e*this.data.stride+this.offset,this.normalized&&(t=ot(t,this.array),n=ot(n,this.array),r=ot(r,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=r,this}setXYZW(e,t,n,r,s){return e=e*this.data.stride+this.offset,this.normalized&&(t=ot(t,this.array),n=ot(n,this.array),r=ot(r,this.array),s=ot(s,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=r,this.data.array[e+3]=s,this}clone(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let n=0;n<this.count;n++){const r=n*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[r+s])}return new ct(new this.array.constructor(t),this.itemSize,this.normalized)}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.clone(e)),new Us(e.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let n=0;n<this.count;n++){const r=n*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[r+s])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:t,normalized:this.normalized}}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}}class Vs extends In{constructor(e){super(),this.isSpriteMaterial=!0,this.type="SpriteMaterial",this.color=new Ie(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.rotation=e.rotation,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}let gr;const us=new U,vr=new U,_r=new U,xr=new Ce,ds=new Ce,lf=new qe,ga=new U,hs=new U,va=new U,Gu=new Ce,Zo=new Ce,Wu=new Ce;class lo extends Mt{constructor(e=new Vs){if(super(),this.isSprite=!0,this.type="Sprite",gr===void 0){gr=new Lt;const t=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),n=new of(t,5);gr.setIndex([0,1,2,0,2,3]),gr.setAttribute("position",new Us(n,3,0,!1)),gr.setAttribute("uv",new Us(n,2,3,!1))}this.geometry=gr,this.material=e,this.center=new Ce(.5,.5),this.count=1}raycast(e,t){e.camera===null&&console.error('THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),vr.setFromMatrixScale(this.matrixWorld),lf.copy(e.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(e.camera.matrixWorldInverse,this.matrixWorld),_r.setFromMatrixPosition(this.modelViewMatrix),e.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&vr.multiplyScalar(-_r.z);const n=this.material.rotation;let r,s;n!==0&&(s=Math.cos(n),r=Math.sin(n));const a=this.center;_a(ga.set(-.5,-.5,0),_r,a,vr,r,s),_a(hs.set(.5,-.5,0),_r,a,vr,r,s),_a(va.set(.5,.5,0),_r,a,vr,r,s),Gu.set(0,0),Zo.set(1,0),Wu.set(1,1);let o=e.ray.intersectTriangle(ga,hs,va,!1,us);if(o===null&&(_a(hs.set(-.5,.5,0),_r,a,vr,r,s),Zo.set(0,1),o=e.ray.intersectTriangle(ga,va,hs,!1,us),o===null))return;const l=e.ray.origin.distanceTo(us);l<e.near||l>e.far||t.push({distance:l,point:us.clone(),uv:wn.getInterpolation(us,ga,hs,va,Gu,Zo,Wu,new Ce),face:null,object:this})}copy(e,t){return super.copy(e,t),e.center!==void 0&&this.center.copy(e.center),this.material=e.material,this}}function _a(i,e,t,n,r,s){xr.subVectors(i,t).addScalar(.5).multiply(n),r!==void 0?(ds.x=s*xr.x-r*xr.y,ds.y=r*xr.x+s*xr.y):ds.copy(xr),i.copy(e),i.x+=ds.x,i.y+=ds.y,i.applyMatrix4(lf)}const Xu=new U,qu=new rt,Yu=new rt,Gm=new U,ju=new qe,xa=new U,Jo=new $n,$u=new qe,Qo=new ks;class Vc extends ht{constructor(e,t){super(e,t),this.isSkinnedMesh=!0,this.type="SkinnedMesh",this.bindMode=xu,this.bindMatrix=new qe,this.bindMatrixInverse=new qe,this.boundingBox=null,this.boundingSphere=null}computeBoundingBox(){const e=this.geometry;this.boundingBox===null&&(this.boundingBox=new jn),this.boundingBox.makeEmpty();const t=e.getAttribute("position");for(let n=0;n<t.count;n++)this.getVertexPosition(n,xa),this.boundingBox.expandByPoint(xa)}computeBoundingSphere(){const e=this.geometry;this.boundingSphere===null&&(this.boundingSphere=new $n),this.boundingSphere.makeEmpty();const t=e.getAttribute("position");for(let n=0;n<t.count;n++)this.getVertexPosition(n,xa),this.boundingSphere.expandByPoint(xa)}copy(e,t){return super.copy(e,t),this.bindMode=e.bindMode,this.bindMatrix.copy(e.bindMatrix),this.bindMatrixInverse.copy(e.bindMatrixInverse),this.skeleton=e.skeleton,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}raycast(e,t){const n=this.material,r=this.matrixWorld;n!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),Jo.copy(this.boundingSphere),Jo.applyMatrix4(r),e.ray.intersectsSphere(Jo)!==!1&&($u.copy(r).invert(),Qo.copy(e.ray).applyMatrix4($u),!(this.boundingBox!==null&&Qo.intersectsBox(this.boundingBox)===!1)&&this._computeIntersections(e,t,Qo)))}getVertexPosition(e,t){return super.getVertexPosition(e,t),this.applyBoneTransform(e,t),t}bind(e,t){this.skeleton=e,t===void 0&&(this.updateMatrixWorld(!0),this.skeleton.calculateInverses(),t=this.matrixWorld),this.bindMatrix.copy(t),this.bindMatrixInverse.copy(t).invert()}pose(){this.skeleton.pose()}normalizeSkinWeights(){const e=new rt,t=this.geometry.attributes.skinWeight;for(let n=0,r=t.count;n<r;n++){e.fromBufferAttribute(t,n);const s=1/e.manhattanLength();s!==1/0?e.multiplyScalar(s):e.set(1,0,0,0),t.setXYZW(n,e.x,e.y,e.z,e.w)}}updateMatrixWorld(e){super.updateMatrixWorld(e),this.bindMode===xu?this.bindMatrixInverse.copy(this.matrixWorld).invert():this.bindMode===Gp?this.bindMatrixInverse.copy(this.bindMatrix).invert():console.warn("THREE.SkinnedMesh: Unrecognized bindMode: "+this.bindMode)}applyBoneTransform(e,t){const n=this.skeleton,r=this.geometry;qu.fromBufferAttribute(r.attributes.skinIndex,e),Yu.fromBufferAttribute(r.attributes.skinWeight,e),Xu.copy(t).applyMatrix4(this.bindMatrix),t.set(0,0,0);for(let s=0;s<4;s++){const a=Yu.getComponent(s);if(a!==0){const o=qu.getComponent(s);ju.multiplyMatrices(n.bones[o].matrixWorld,n.boneInverses[o]),t.addScaledVector(Gm.copy(Xu).applyMatrix4(ju),a)}}return t.applyMatrix4(this.bindMatrixInverse)}}class co extends Mt{constructor(){super(),this.isBone=!0,this.type="Bone"}}class cf extends Ft{constructor(e=null,t=1,n=1,r,s,a,o,l,c=Jt,d=Jt,u,h){super(null,a,o,l,c,d,r,s,u,h),this.isDataTexture=!0,this.image={data:e,width:t,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const Ku=new qe,Wm=new qe;class Hs{constructor(e=[],t=[]){this.uuid=zn(),this.bones=e.slice(0),this.boneInverses=t,this.boneMatrices=null,this.boneTexture=null,this.init()}init(){const e=this.bones,t=this.boneInverses;if(this.boneMatrices=new Float32Array(e.length*16),t.length===0)this.calculateInverses();else if(e.length!==t.length){console.warn("THREE.Skeleton: Number of inverse bone matrices does not match amount of bones."),this.boneInverses=[];for(let n=0,r=this.bones.length;n<r;n++)this.boneInverses.push(new qe)}}calculateInverses(){this.boneInverses.length=0;for(let e=0,t=this.bones.length;e<t;e++){const n=new qe;this.bones[e]&&n.copy(this.bones[e].matrixWorld).invert(),this.boneInverses.push(n)}}pose(){for(let e=0,t=this.bones.length;e<t;e++){const n=this.bones[e];n&&n.matrixWorld.copy(this.boneInverses[e]).invert()}for(let e=0,t=this.bones.length;e<t;e++){const n=this.bones[e];n&&(n.parent&&n.parent.isBone?(n.matrix.copy(n.parent.matrixWorld).invert(),n.matrix.multiply(n.matrixWorld)):n.matrix.copy(n.matrixWorld),n.matrix.decompose(n.position,n.quaternion,n.scale))}}update(){const e=this.bones,t=this.boneInverses,n=this.boneMatrices,r=this.boneTexture;for(let s=0,a=e.length;s<a;s++){const o=e[s]?e[s].matrixWorld:Wm;Ku.multiplyMatrices(o,t[s]),Ku.toArray(n,s*16)}r!==null&&(r.needsUpdate=!0)}clone(){return new Hs(this.bones,this.boneInverses)}computeBoneTexture(){let e=Math.sqrt(this.bones.length*4);e=Math.ceil(e/4)*4,e=Math.max(e,4);const t=new Float32Array(e*e*4);t.set(this.boneMatrices);const n=new cf(t,e,e,Rn,kn);return n.needsUpdate=!0,this.boneMatrices=t,this.boneTexture=n,this}getBoneByName(e){for(let t=0,n=this.bones.length;t<n;t++){const r=this.bones[t];if(r.name===e)return r}}dispose(){this.boneTexture!==null&&(this.boneTexture.dispose(),this.boneTexture=null)}fromJSON(e,t){this.uuid=e.uuid;for(let n=0,r=e.bones.length;n<r;n++){const s=e.bones[n];let a=t[s];a===void 0&&(console.warn("THREE.Skeleton: No bone found with UUID:",s),a=new co),this.bones.push(a),this.boneInverses.push(new qe().fromArray(e.boneInverses[n]))}return this.init(),this}toJSON(){const e={metadata:{version:4.7,type:"Skeleton",generator:"Skeleton.toJSON"},bones:[],boneInverses:[]};e.uuid=this.uuid;const t=this.bones,n=this.boneInverses;for(let r=0,s=t.length;r<s;r++){const a=t[r];e.bones.push(a.uuid);const o=n[r];e.boneInverses.push(o.toArray())}return e}}class Gr extends ct{constructor(e,t,n,r=1){super(e,t,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=r}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){const e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}}const yr=new qe,Zu=new qe,ya=[],Ju=new jn,Xm=new qe,fs=new ht,ps=new $n;class qm extends ht{constructor(e,t,n){super(e,t),this.isInstancedMesh=!0,this.instanceMatrix=new Gr(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let r=0;r<n;r++)this.setMatrixAt(r,Xm)}computeBoundingBox(){const e=this.geometry,t=this.count;this.boundingBox===null&&(this.boundingBox=new jn),e.boundingBox===null&&e.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,yr),Ju.copy(e.boundingBox).applyMatrix4(yr),this.boundingBox.union(Ju)}computeBoundingSphere(){const e=this.geometry,t=this.count;this.boundingSphere===null&&(this.boundingSphere=new $n),e.boundingSphere===null&&e.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,yr),ps.copy(e.boundingSphere).applyMatrix4(yr),this.boundingSphere.union(ps)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),e.morphTexture!==null&&(this.morphTexture=e.morphTexture.clone()),e.instanceColor!==null&&(this.instanceColor=e.instanceColor.clone()),this.count=e.count,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}getColorAt(e,t){t.fromArray(this.instanceColor.array,e*3)}getMatrixAt(e,t){t.fromArray(this.instanceMatrix.array,e*16)}getMorphAt(e,t){const n=t.morphTargetInfluences,r=this.morphTexture.source.data.data,s=n.length+1,a=e*s+1;for(let o=0;o<n.length;o++)n[o]=r[a+o]}raycast(e,t){const n=this.matrixWorld,r=this.count;if(fs.geometry=this.geometry,fs.material=this.material,fs.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),ps.copy(this.boundingSphere),ps.applyMatrix4(n),e.ray.intersectsSphere(ps)!==!1))for(let s=0;s<r;s++){this.getMatrixAt(s,yr),Zu.multiplyMatrices(n,yr),fs.matrixWorld=Zu,fs.raycast(e,ya);for(let a=0,o=ya.length;a<o;a++){const l=ya[a];l.instanceId=s,l.object=this,t.push(l)}ya.length=0}}setColorAt(e,t){this.instanceColor===null&&(this.instanceColor=new Gr(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),t.toArray(this.instanceColor.array,e*3)}setMatrixAt(e,t){t.toArray(this.instanceMatrix.array,e*16)}setMorphAt(e,t){const n=t.morphTargetInfluences,r=n.length+1;this.morphTexture===null&&(this.morphTexture=new cf(new Float32Array(r*this.count),r,this.count,Dc,kn));const s=this.morphTexture.source.data.data;let a=0;for(let c=0;c<n.length;c++)a+=n[c];const o=this.geometry.morphTargetsRelative?1:1-a,l=r*e;s[l]=o,s.set(n,l+1)}updateMorphTargets(){}dispose(){this.dispatchEvent({type:"dispose"}),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null)}}const el=new U,Ym=new U,jm=new $e;class qi{constructor(e=new U(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,n,r){return this.normal.set(e,t,n),this.constant=r,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,n){const r=el.subVectors(n,t).cross(Ym.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(r,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t){const n=e.delta(el),r=this.normal.dot(n);if(r===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;const s=-(e.start.dot(this.normal)+this.constant)/r;return s<0||s>1?null:t.copy(e.start).addScaledVector(n,s)}intersectsLine(e){const t=this.distanceToPoint(e.start),n=this.distanceToPoint(e.end);return t<0&&n>0||n<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){const n=t||jm.getNormalMatrix(e),r=this.coplanarPoint(el).applyMatrix4(e),s=this.normal.applyMatrix3(n).normalize();return this.constant=-r.dot(s),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const Vi=new $n,$m=new Ce(.5,.5),ba=new U;class Hc{constructor(e=new qi,t=new qi,n=new qi,r=new qi,s=new qi,a=new qi){this.planes=[e,t,n,r,s,a]}set(e,t,n,r,s,a){const o=this.planes;return o[0].copy(e),o[1].copy(t),o[2].copy(n),o[3].copy(r),o[4].copy(s),o[5].copy(a),this}copy(e){const t=this.planes;for(let n=0;n<6;n++)t[n].copy(e.planes[n]);return this}setFromProjectionMatrix(e,t=qn,n=!1){const r=this.planes,s=e.elements,a=s[0],o=s[1],l=s[2],c=s[3],d=s[4],u=s[5],h=s[6],p=s[7],g=s[8],v=s[9],m=s[10],f=s[11],b=s[12],_=s[13],x=s[14],R=s[15];if(r[0].setComponents(c-a,p-d,f-g,R-b).normalize(),r[1].setComponents(c+a,p+d,f+g,R+b).normalize(),r[2].setComponents(c+o,p+u,f+v,R+_).normalize(),r[3].setComponents(c-o,p-u,f-v,R-_).normalize(),n)r[4].setComponents(l,h,m,x).normalize(),r[5].setComponents(c-l,p-h,f-m,R-x).normalize();else if(r[4].setComponents(c-l,p-h,f-m,R-x).normalize(),t===qn)r[5].setComponents(c+l,p+h,f+m,R+x).normalize();else if(t===Xa)r[5].setComponents(l,h,m,x).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),Vi.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),Vi.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(Vi)}intersectsSprite(e){Vi.center.set(0,0,0);const t=$m.distanceTo(e.center);return Vi.radius=.7071067811865476+t,Vi.applyMatrix4(e.matrixWorld),this.intersectsSphere(Vi)}intersectsSphere(e){const t=this.planes,n=e.center,r=-e.radius;for(let s=0;s<6;s++)if(t[s].distanceToPoint(n)<r)return!1;return!0}intersectsBox(e){const t=this.planes;for(let n=0;n<6;n++){const r=t[n];if(ba.x=r.normal.x>0?e.max.x:e.min.x,ba.y=r.normal.y>0?e.max.y:e.min.y,ba.z=r.normal.z>0?e.max.z:e.min.z,r.distanceToPoint(ba)<0)return!1}return!0}containsPoint(e){const t=this.planes;for(let n=0;n<6;n++)if(t[n].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class Gc extends In{constructor(e){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new Ie(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}}const Ya=new U,ja=new U,Qu=new qe,ms=new ks,Sa=new $n,tl=new U,ed=new U;class Wc extends Mt{constructor(e=new Lt,t=new Gc){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,n=[0];for(let r=1,s=t.count;r<s;r++)Ya.fromBufferAttribute(t,r-1),ja.fromBufferAttribute(t,r),n[r]=n[r-1],n[r]+=Ya.distanceTo(ja);e.setAttribute("lineDistance",new nt(n,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(e,t){const n=this.geometry,r=this.matrixWorld,s=e.params.Line.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Sa.copy(n.boundingSphere),Sa.applyMatrix4(r),Sa.radius+=s,e.ray.intersectsSphere(Sa)===!1)return;Qu.copy(r).invert(),ms.copy(e.ray).applyMatrix4(Qu);const o=s/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,c=this.isLineSegments?2:1,d=n.index,h=n.attributes.position;if(d!==null){const p=Math.max(0,a.start),g=Math.min(d.count,a.start+a.count);for(let v=p,m=g-1;v<m;v+=c){const f=d.getX(v),b=d.getX(v+1),_=Ma(this,e,ms,l,f,b,v);_&&t.push(_)}if(this.isLineLoop){const v=d.getX(g-1),m=d.getX(p),f=Ma(this,e,ms,l,v,m,g-1);f&&t.push(f)}}else{const p=Math.max(0,a.start),g=Math.min(h.count,a.start+a.count);for(let v=p,m=g-1;v<m;v+=c){const f=Ma(this,e,ms,l,v,v+1,v);f&&t.push(f)}if(this.isLineLoop){const v=Ma(this,e,ms,l,g-1,p,g-1);v&&t.push(v)}}}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const r=t[n[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,a=r.length;s<a;s++){const o=r[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=s}}}}}function Ma(i,e,t,n,r,s,a){const o=i.geometry.attributes.position;if(Ya.fromBufferAttribute(o,r),ja.fromBufferAttribute(o,s),t.distanceSqToSegment(Ya,ja,tl,ed)>n)return;tl.applyMatrix4(i.matrixWorld);const c=e.ray.origin.distanceTo(tl);if(!(c<e.near||c>e.far))return{distance:c,point:ed.clone().applyMatrix4(i.matrixWorld),index:a,face:null,faceIndex:null,barycoord:null,object:i}}const td=new U,nd=new U;class uf extends Wc{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,n=[];for(let r=0,s=t.count;r<s;r+=2)td.fromBufferAttribute(t,r),nd.fromBufferAttribute(t,r+1),n[r]=r===0?0:n[r-1],n[r+1]=n[r]+td.distanceTo(nd);e.setAttribute("lineDistance",new nt(n,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class Km extends Wc{constructor(e,t){super(e,t),this.isLineLoop=!0,this.type="LineLoop"}}class df extends In{constructor(e){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new Ie(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}const id=new qe,fc=new ks,Ea=new $n,Ta=new U;class Xc extends Mt{constructor(e=new Lt,t=new df){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}raycast(e,t){const n=this.geometry,r=this.matrixWorld,s=e.params.Points.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Ea.copy(n.boundingSphere),Ea.applyMatrix4(r),Ea.radius+=s,e.ray.intersectsSphere(Ea)===!1)return;id.copy(r).invert(),fc.copy(e.ray).applyMatrix4(id);const o=s/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,c=n.index,u=n.attributes.position;if(c!==null){const h=Math.max(0,a.start),p=Math.min(c.count,a.start+a.count);for(let g=h,v=p;g<v;g++){const m=c.getX(g);Ta.fromBufferAttribute(u,m),rd(Ta,m,l,r,e,t,this)}}else{const h=Math.max(0,a.start),p=Math.min(u.count,a.start+a.count);for(let g=h,v=p;g<v;g++)Ta.fromBufferAttribute(u,g),rd(Ta,g,l,r,e,t,this)}}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const r=t[n[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,a=r.length;s<a;s++){const o=r[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=s}}}}}function rd(i,e,t,n,r,s,a){const o=fc.distanceSqToPoint(i);if(o<t){const l=new U;fc.closestPointToPoint(i,l),l.applyMatrix4(n);const c=r.ray.origin.distanceTo(l);if(c<r.near||c>r.far)return;s.push({distance:c,distanceToRay:Math.sqrt(o),point:l,index:e,face:null,faceIndex:null,barycoord:null,object:a})}}class uo extends Ft{constructor(e,t,n,r,s,a,o,l,c){super(e,t,n,r,s,a,o,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}}class hf extends Ft{constructor(e,t,n=Zi,r,s,a,o=Jt,l=Jt,c,d=Is,u=1){if(d!==Is&&d!==Ps)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const h={width:e,height:t,depth:u};super(h,r,s,a,o,l,d,n,c),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new kc(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){const t=super.toJSON(e);return this.compareFunction!==null&&(t.compareFunction=this.compareFunction),t}}class ff extends Ft{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}}class qc extends Lt{constructor(e=1,t=1,n=1,r=32,s=1,a=!1,o=0,l=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:t,height:n,radialSegments:r,heightSegments:s,openEnded:a,thetaStart:o,thetaLength:l};const c=this;r=Math.floor(r),s=Math.floor(s);const d=[],u=[],h=[],p=[];let g=0;const v=[],m=n/2;let f=0;b(),a===!1&&(e>0&&_(!0),t>0&&_(!1)),this.setIndex(d),this.setAttribute("position",new nt(u,3)),this.setAttribute("normal",new nt(h,3)),this.setAttribute("uv",new nt(p,2));function b(){const x=new U,R=new U;let M=0;const A=(t-e)/n;for(let w=0;w<=s;w++){const S=[],y=w/s,T=y*(t-e)+e;for(let N=0;N<=r;N++){const B=N/r,k=B*l+o,V=Math.sin(k),D=Math.cos(k);R.x=T*V,R.y=-y*n+m,R.z=T*D,u.push(R.x,R.y,R.z),x.set(V,A,D).normalize(),h.push(x.x,x.y,x.z),p.push(B,1-y),S.push(g++)}v.push(S)}for(let w=0;w<r;w++)for(let S=0;S<s;S++){const y=v[S][w],T=v[S+1][w],N=v[S+1][w+1],B=v[S][w+1];(e>0||S!==0)&&(d.push(y,T,B),M+=3),(t>0||S!==s-1)&&(d.push(T,N,B),M+=3)}c.addGroup(f,M,0),f+=M}function _(x){const R=g,M=new Ce,A=new U;let w=0;const S=x===!0?e:t,y=x===!0?1:-1;for(let N=1;N<=r;N++)u.push(0,m*y,0),h.push(0,y,0),p.push(.5,.5),g++;const T=g;for(let N=0;N<=r;N++){const k=N/r*l+o,V=Math.cos(k),D=Math.sin(k);A.x=S*D,A.y=m*y,A.z=S*V,u.push(A.x,A.y,A.z),h.push(0,y,0),M.x=V*.5+.5,M.y=D*.5*y+.5,p.push(M.x,M.y),g++}for(let N=0;N<r;N++){const B=R+N,k=T+N;x===!0?d.push(k,k+1,B):d.push(k+1,k,B),w+=3}c.addGroup(f,w,x===!0?1:2),f+=w}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new qc(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class yn extends Lt{constructor(e=1,t=1,n=1,r=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:n,heightSegments:r};const s=e/2,a=t/2,o=Math.floor(n),l=Math.floor(r),c=o+1,d=l+1,u=e/o,h=t/l,p=[],g=[],v=[],m=[];for(let f=0;f<d;f++){const b=f*h-a;for(let _=0;_<c;_++){const x=_*u-s;g.push(x,-b,0),v.push(0,0,1),m.push(_/o),m.push(1-f/l)}}for(let f=0;f<l;f++)for(let b=0;b<o;b++){const _=b+c*f,x=b+c*(f+1),R=b+1+c*(f+1),M=b+1+c*f;p.push(_,x,M),p.push(x,R,M)}this.setIndex(p),this.setAttribute("position",new nt(g,3)),this.setAttribute("normal",new nt(v,3)),this.setAttribute("uv",new nt(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new yn(e.width,e.height,e.widthSegments,e.heightSegments)}}class ho extends Lt{constructor(e=.5,t=1,n=32,r=1,s=0,a=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:e,outerRadius:t,thetaSegments:n,phiSegments:r,thetaStart:s,thetaLength:a},n=Math.max(3,n),r=Math.max(1,r);const o=[],l=[],c=[],d=[];let u=e;const h=(t-e)/r,p=new U,g=new Ce;for(let v=0;v<=r;v++){for(let m=0;m<=n;m++){const f=s+m/n*a;p.x=u*Math.cos(f),p.y=u*Math.sin(f),l.push(p.x,p.y,p.z),c.push(0,0,1),g.x=(p.x/t+1)/2,g.y=(p.y/t+1)/2,d.push(g.x,g.y)}u+=h}for(let v=0;v<r;v++){const m=v*(n+1);for(let f=0;f<n;f++){const b=f+m,_=b,x=b+n+1,R=b+n+2,M=b+1;o.push(_,x,M),o.push(x,R,M)}}this.setIndex(o),this.setAttribute("position",new nt(l,3)),this.setAttribute("normal",new nt(c,3)),this.setAttribute("uv",new nt(d,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new ho(e.innerRadius,e.outerRadius,e.thetaSegments,e.phiSegments,e.thetaStart,e.thetaLength)}}class Yc extends Lt{constructor(e=1,t=32,n=16,r=0,s=Math.PI*2,a=0,o=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:t,heightSegments:n,phiStart:r,phiLength:s,thetaStart:a,thetaLength:o},t=Math.max(3,Math.floor(t)),n=Math.max(2,Math.floor(n));const l=Math.min(a+o,Math.PI);let c=0;const d=[],u=new U,h=new U,p=[],g=[],v=[],m=[];for(let f=0;f<=n;f++){const b=[],_=f/n;let x=0;f===0&&a===0?x=.5/t:f===n&&l===Math.PI&&(x=-.5/t);for(let R=0;R<=t;R++){const M=R/t;u.x=-e*Math.cos(r+M*s)*Math.sin(a+_*o),u.y=e*Math.cos(a+_*o),u.z=e*Math.sin(r+M*s)*Math.sin(a+_*o),g.push(u.x,u.y,u.z),h.copy(u).normalize(),v.push(h.x,h.y,h.z),m.push(M+x,1-_),b.push(c++)}d.push(b)}for(let f=0;f<n;f++)for(let b=0;b<t;b++){const _=d[f][b+1],x=d[f][b],R=d[f+1][b],M=d[f+1][b+1];(f!==0||a>0)&&p.push(_,x,M),(f!==n-1||l<Math.PI)&&p.push(x,R,M)}this.setIndex(p),this.setAttribute("position",new nt(g,3)),this.setAttribute("normal",new nt(v,3)),this.setAttribute("uv",new nt(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Yc(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}}class jc extends In{constructor(e){super(),this.isMeshStandardMaterial=!0,this.type="MeshStandardMaterial",this.defines={STANDARD:""},this.color=new Ie(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Ie(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Fc,this.normalScale=new Ce(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new xn,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class Kn extends jc{constructor(e){super(),this.isMeshPhysicalMaterial=!0,this.defines={STANDARD:"",PHYSICAL:""},this.type="MeshPhysicalMaterial",this.anisotropyRotation=0,this.anisotropyMap=null,this.clearcoatMap=null,this.clearcoatRoughness=0,this.clearcoatRoughnessMap=null,this.clearcoatNormalScale=new Ce(1,1),this.clearcoatNormalMap=null,this.ior=1.5,Object.defineProperty(this,"reflectivity",{get:function(){return Je(2.5*(this.ior-1)/(this.ior+1),0,1)},set:function(t){this.ior=(1+.4*t)/(1-.4*t)}}),this.iridescenceMap=null,this.iridescenceIOR=1.3,this.iridescenceThicknessRange=[100,400],this.iridescenceThicknessMap=null,this.sheenColor=new Ie(0),this.sheenColorMap=null,this.sheenRoughness=1,this.sheenRoughnessMap=null,this.transmissionMap=null,this.thickness=0,this.thicknessMap=null,this.attenuationDistance=1/0,this.attenuationColor=new Ie(1,1,1),this.specularIntensity=1,this.specularIntensityMap=null,this.specularColor=new Ie(1,1,1),this.specularColorMap=null,this._anisotropy=0,this._clearcoat=0,this._dispersion=0,this._iridescence=0,this._sheen=0,this._transmission=0,this.setValues(e)}get anisotropy(){return this._anisotropy}set anisotropy(e){this._anisotropy>0!=e>0&&this.version++,this._anisotropy=e}get clearcoat(){return this._clearcoat}set clearcoat(e){this._clearcoat>0!=e>0&&this.version++,this._clearcoat=e}get iridescence(){return this._iridescence}set iridescence(e){this._iridescence>0!=e>0&&this.version++,this._iridescence=e}get dispersion(){return this._dispersion}set dispersion(e){this._dispersion>0!=e>0&&this.version++,this._dispersion=e}get sheen(){return this._sheen}set sheen(e){this._sheen>0!=e>0&&this.version++,this._sheen=e}get transmission(){return this._transmission}set transmission(e){this._transmission>0!=e>0&&this.version++,this._transmission=e}copy(e){return super.copy(e),this.defines={STANDARD:"",PHYSICAL:""},this.anisotropy=e.anisotropy,this.anisotropyRotation=e.anisotropyRotation,this.anisotropyMap=e.anisotropyMap,this.clearcoat=e.clearcoat,this.clearcoatMap=e.clearcoatMap,this.clearcoatRoughness=e.clearcoatRoughness,this.clearcoatRoughnessMap=e.clearcoatRoughnessMap,this.clearcoatNormalMap=e.clearcoatNormalMap,this.clearcoatNormalScale.copy(e.clearcoatNormalScale),this.dispersion=e.dispersion,this.ior=e.ior,this.iridescence=e.iridescence,this.iridescenceMap=e.iridescenceMap,this.iridescenceIOR=e.iridescenceIOR,this.iridescenceThicknessRange=[...e.iridescenceThicknessRange],this.iridescenceThicknessMap=e.iridescenceThicknessMap,this.sheen=e.sheen,this.sheenColor.copy(e.sheenColor),this.sheenColorMap=e.sheenColorMap,this.sheenRoughness=e.sheenRoughness,this.sheenRoughnessMap=e.sheenRoughnessMap,this.transmission=e.transmission,this.transmissionMap=e.transmissionMap,this.thickness=e.thickness,this.thicknessMap=e.thicknessMap,this.attenuationDistance=e.attenuationDistance,this.attenuationColor.copy(e.attenuationColor),this.specularIntensity=e.specularIntensity,this.specularIntensityMap=e.specularIntensityMap,this.specularColor.copy(e.specularColor),this.specularColorMap=e.specularColorMap,this}}class Zm extends In{constructor(e){super(),this.isMeshLambertMaterial=!0,this.type="MeshLambertMaterial",this.color=new Ie(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Ie(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Fc,this.normalScale=new Ce(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new xn,this.combine=Cc,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class Jm extends In{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=qp,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class Qm extends In{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}function Aa(i,e){return!i||i.constructor===e?i:typeof e.BYTES_PER_ELEMENT=="number"?new e(i):Array.prototype.slice.call(i)}function eg(i){return ArrayBuffer.isView(i)&&!(i instanceof DataView)}function tg(i){function e(r,s){return i[r]-i[s]}const t=i.length,n=new Array(t);for(let r=0;r!==t;++r)n[r]=r;return n.sort(e),n}function sd(i,e,t){const n=i.length,r=new i.constructor(n);for(let s=0,a=0;a!==n;++s){const o=t[s]*e;for(let l=0;l!==e;++l)r[a++]=i[o+l]}return r}function pf(i,e,t,n){let r=1,s=i[0];for(;s!==void 0&&s[n]===void 0;)s=i[r++];if(s===void 0)return;let a=s[n];if(a!==void 0)if(Array.isArray(a))do a=s[n],a!==void 0&&(e.push(s.time),t.push(...a)),s=i[r++];while(s!==void 0);else if(a.toArray!==void 0)do a=s[n],a!==void 0&&(e.push(s.time),a.toArray(t,t.length)),s=i[r++];while(s!==void 0);else do a=s[n],a!==void 0&&(e.push(s.time),t.push(a)),s=i[r++];while(s!==void 0)}class Gs{constructor(e,t,n,r){this.parameterPositions=e,this._cachedIndex=0,this.resultBuffer=r!==void 0?r:new t.constructor(n),this.sampleValues=t,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(e){const t=this.parameterPositions;let n=this._cachedIndex,r=t[n],s=t[n-1];n:{e:{let a;t:{i:if(!(e<r)){for(let o=n+2;;){if(r===void 0){if(e<s)break i;return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===o)break;if(s=r,r=t[++n],e<r)break e}a=t.length;break t}if(!(e>=s)){const o=t[1];e<o&&(n=2,s=o);for(let l=n-2;;){if(s===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===l)break;if(r=s,s=t[--n-1],e>=s)break e}a=n,n=0;break t}break n}for(;n<a;){const o=n+a>>>1;e<t[o]?a=o:n=o+1}if(r=t[n],s=t[n-1],s===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(r===void 0)return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,s,r)}return this.interpolate_(n,s,e,r)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(e){const t=this.resultBuffer,n=this.sampleValues,r=this.valueSize,s=e*r;for(let a=0;a!==r;++a)t[a]=n[s+a];return t}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}}class ng extends Gs{constructor(e,t,n,r){super(e,t,n,r),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:yu,endingEnd:yu}}intervalChanged_(e,t,n){const r=this.parameterPositions;let s=e-2,a=e+1,o=r[s],l=r[a];if(o===void 0)switch(this.getSettings_().endingStart){case bu:s=e,o=2*t-n;break;case Su:s=r.length-2,o=t+r[s]-r[s+1];break;default:s=e,o=n}if(l===void 0)switch(this.getSettings_().endingEnd){case bu:a=e,l=2*n-t;break;case Su:a=1,l=n+r[1]-r[0];break;default:a=e-1,l=t}const c=(n-t)*.5,d=this.valueSize;this._weightPrev=c/(t-o),this._weightNext=c/(l-n),this._offsetPrev=s*d,this._offsetNext=a*d}interpolate_(e,t,n,r){const s=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=e*o,c=l-o,d=this._offsetPrev,u=this._offsetNext,h=this._weightPrev,p=this._weightNext,g=(n-t)/(r-t),v=g*g,m=v*g,f=-h*m+2*h*v-h*g,b=(1+h)*m+(-1.5-2*h)*v+(-.5+h)*g+1,_=(-1-p)*m+(1.5+p)*v+.5*g,x=p*m-p*v;for(let R=0;R!==o;++R)s[R]=f*a[d+R]+b*a[c+R]+_*a[l+R]+x*a[u+R];return s}}class ig extends Gs{constructor(e,t,n,r){super(e,t,n,r)}interpolate_(e,t,n,r){const s=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=e*o,c=l-o,d=(n-t)/(r-t),u=1-d;for(let h=0;h!==o;++h)s[h]=a[c+h]*u+a[l+h]*d;return s}}class rg extends Gs{constructor(e,t,n,r){super(e,t,n,r)}interpolate_(e){return this.copySampleValue_(e-1)}}class Hn{constructor(e,t,n,r){if(e===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(t===void 0||t.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+e);this.name=e,this.times=Aa(t,this.TimeBufferType),this.values=Aa(n,this.ValueBufferType),this.setInterpolation(r||this.DefaultInterpolation)}static toJSON(e){const t=e.constructor;let n;if(t.toJSON!==this.toJSON)n=t.toJSON(e);else{n={name:e.name,times:Aa(e.times,Array),values:Aa(e.values,Array)};const r=e.getInterpolation();r!==e.DefaultInterpolation&&(n.interpolation=r)}return n.type=e.ValueTypeName,n}InterpolantFactoryMethodDiscrete(e){return new rg(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodLinear(e){return new ig(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodSmooth(e){return new ng(this.times,this.values,this.getValueSize(),e)}setInterpolation(e){let t;switch(e){case Ls:t=this.InterpolantFactoryMethodDiscrete;break;case Ds:t=this.InterpolantFactoryMethodLinear;break;case Co:t=this.InterpolantFactoryMethodSmooth;break}if(t===void 0){const n="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(e!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(n);return console.warn("THREE.KeyframeTrack:",n),this}return this.createInterpolant=t,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return Ls;case this.InterpolantFactoryMethodLinear:return Ds;case this.InterpolantFactoryMethodSmooth:return Co}}getValueSize(){return this.values.length/this.times.length}shift(e){if(e!==0){const t=this.times;for(let n=0,r=t.length;n!==r;++n)t[n]+=e}return this}scale(e){if(e!==1){const t=this.times;for(let n=0,r=t.length;n!==r;++n)t[n]*=e}return this}trim(e,t){const n=this.times,r=n.length;let s=0,a=r-1;for(;s!==r&&n[s]<e;)++s;for(;a!==-1&&n[a]>t;)--a;if(++a,s!==0||a!==r){s>=a&&(a=Math.max(a,1),s=a-1);const o=this.getValueSize();this.times=n.slice(s,a),this.values=this.values.slice(s*o,a*o)}return this}validate(){let e=!0;const t=this.getValueSize();t-Math.floor(t)!==0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),e=!1);const n=this.times,r=this.values,s=n.length;s===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),e=!1);let a=null;for(let o=0;o!==s;o++){const l=n[o];if(typeof l=="number"&&isNaN(l)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,o,l),e=!1;break}if(a!==null&&a>l){console.error("THREE.KeyframeTrack: Out of order keys.",this,o,l,a),e=!1;break}a=l}if(r!==void 0&&eg(r))for(let o=0,l=r.length;o!==l;++o){const c=r[o];if(isNaN(c)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,o,c),e=!1;break}}return e}optimize(){const e=this.times.slice(),t=this.values.slice(),n=this.getValueSize(),r=this.getInterpolation()===Co,s=e.length-1;let a=1;for(let o=1;o<s;++o){let l=!1;const c=e[o],d=e[o+1];if(c!==d&&(o!==1||c!==e[0]))if(r)l=!0;else{const u=o*n,h=u-n,p=u+n;for(let g=0;g!==n;++g){const v=t[u+g];if(v!==t[h+g]||v!==t[p+g]){l=!0;break}}}if(l){if(o!==a){e[a]=e[o];const u=o*n,h=a*n;for(let p=0;p!==n;++p)t[h+p]=t[u+p]}++a}}if(s>0){e[a]=e[s];for(let o=s*n,l=a*n,c=0;c!==n;++c)t[l+c]=t[o+c];++a}return a!==e.length?(this.times=e.slice(0,a),this.values=t.slice(0,a*n)):(this.times=e,this.values=t),this}clone(){const e=this.times.slice(),t=this.values.slice(),n=this.constructor,r=new n(this.name,e,t);return r.createInterpolant=this.createInterpolant,r}}Hn.prototype.ValueTypeName="";Hn.prototype.TimeBufferType=Float32Array;Hn.prototype.ValueBufferType=Float32Array;Hn.prototype.DefaultInterpolation=Ds;class Qr extends Hn{constructor(e,t,n){super(e,t,n)}}Qr.prototype.ValueTypeName="bool";Qr.prototype.ValueBufferType=Array;Qr.prototype.DefaultInterpolation=Ls;Qr.prototype.InterpolantFactoryMethodLinear=void 0;Qr.prototype.InterpolantFactoryMethodSmooth=void 0;class mf extends Hn{constructor(e,t,n,r){super(e,t,n,r)}}mf.prototype.ValueTypeName="color";class Wr extends Hn{constructor(e,t,n,r){super(e,t,n,r)}}Wr.prototype.ValueTypeName="number";class sg extends Gs{constructor(e,t,n,r){super(e,t,n,r)}interpolate_(e,t,n,r){const s=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=(n-t)/(r-t);let c=e*o;for(let d=c+o;c!==d;c+=4)dt.slerpFlat(s,0,a,c-o,a,c,l);return s}}class Xr extends Hn{constructor(e,t,n,r){super(e,t,n,r)}InterpolantFactoryMethodLinear(e){return new sg(this.times,this.values,this.getValueSize(),e)}}Xr.prototype.ValueTypeName="quaternion";Xr.prototype.InterpolantFactoryMethodSmooth=void 0;class es extends Hn{constructor(e,t,n){super(e,t,n)}}es.prototype.ValueTypeName="string";es.prototype.ValueBufferType=Array;es.prototype.DefaultInterpolation=Ls;es.prototype.InterpolantFactoryMethodLinear=void 0;es.prototype.InterpolantFactoryMethodSmooth=void 0;class qr extends Hn{constructor(e,t,n,r){super(e,t,n,r)}}qr.prototype.ValueTypeName="vector";class ag{constructor(e="",t=-1,n=[],r=Wp){this.name=e,this.tracks=n,this.duration=t,this.blendMode=r,this.uuid=zn(),this.userData={},this.duration<0&&this.resetDuration()}static parse(e){const t=[],n=e.tracks,r=1/(e.fps||1);for(let a=0,o=n.length;a!==o;++a)t.push(lg(n[a]).scale(r));const s=new this(e.name,e.duration,t,e.blendMode);return s.uuid=e.uuid,s.userData=JSON.parse(e.userData||"{}"),s}static toJSON(e){const t=[],n=e.tracks,r={name:e.name,duration:e.duration,tracks:t,uuid:e.uuid,blendMode:e.blendMode,userData:JSON.stringify(e.userData)};for(let s=0,a=n.length;s!==a;++s)t.push(Hn.toJSON(n[s]));return r}static CreateFromMorphTargetSequence(e,t,n,r){const s=t.length,a=[];for(let o=0;o<s;o++){let l=[],c=[];l.push((o+s-1)%s,o,(o+1)%s),c.push(0,1,0);const d=tg(l);l=sd(l,1,d),c=sd(c,1,d),!r&&l[0]===0&&(l.push(s),c.push(c[0])),a.push(new Wr(".morphTargetInfluences["+t[o].name+"]",l,c).scale(1/n))}return new this(e,-1,a)}static findByName(e,t){let n=e;if(!Array.isArray(e)){const r=e;n=r.geometry&&r.geometry.animations||r.animations}for(let r=0;r<n.length;r++)if(n[r].name===t)return n[r];return null}static CreateClipsFromMorphTargetSequences(e,t,n){const r={},s=/^([\w-]*?)([\d]+)$/;for(let o=0,l=e.length;o<l;o++){const c=e[o],d=c.name.match(s);if(d&&d.length>1){const u=d[1];let h=r[u];h||(r[u]=h=[]),h.push(c)}}const a=[];for(const o in r)a.push(this.CreateFromMorphTargetSequence(o,r[o],t,n));return a}static parseAnimation(e,t){if(console.warn("THREE.AnimationClip: parseAnimation() is deprecated and will be removed with r185"),!e)return console.error("THREE.AnimationClip: No animation in JSONLoader data."),null;const n=function(u,h,p,g,v){if(p.length!==0){const m=[],f=[];pf(p,m,f,g),m.length!==0&&v.push(new u(h,m,f))}},r=[],s=e.name||"default",a=e.fps||30,o=e.blendMode;let l=e.length||-1;const c=e.hierarchy||[];for(let u=0;u<c.length;u++){const h=c[u].keys;if(!(!h||h.length===0))if(h[0].morphTargets){const p={};let g;for(g=0;g<h.length;g++)if(h[g].morphTargets)for(let v=0;v<h[g].morphTargets.length;v++)p[h[g].morphTargets[v]]=-1;for(const v in p){const m=[],f=[];for(let b=0;b!==h[g].morphTargets.length;++b){const _=h[g];m.push(_.time),f.push(_.morphTarget===v?1:0)}r.push(new Wr(".morphTargetInfluence["+v+"]",m,f))}l=p.length*a}else{const p=".bones["+t[u].name+"]";n(qr,p+".position",h,"pos",r),n(Xr,p+".quaternion",h,"rot",r),n(qr,p+".scale",h,"scl",r)}}return r.length===0?null:new this(s,l,r,o)}resetDuration(){const e=this.tracks;let t=0;for(let n=0,r=e.length;n!==r;++n){const s=this.tracks[n];t=Math.max(t,s.times[s.times.length-1])}return this.duration=t,this}trim(){for(let e=0;e<this.tracks.length;e++)this.tracks[e].trim(0,this.duration);return this}validate(){let e=!0;for(let t=0;t<this.tracks.length;t++)e=e&&this.tracks[t].validate();return e}optimize(){for(let e=0;e<this.tracks.length;e++)this.tracks[e].optimize();return this}clone(){const e=[];for(let n=0;n<this.tracks.length;n++)e.push(this.tracks[n].clone());const t=new this.constructor(this.name,this.duration,e,this.blendMode);return t.userData=JSON.parse(JSON.stringify(this.userData)),t}toJSON(){return this.constructor.toJSON(this)}}function og(i){switch(i.toLowerCase()){case"scalar":case"double":case"float":case"number":case"integer":return Wr;case"vector":case"vector2":case"vector3":case"vector4":return qr;case"color":return mf;case"quaternion":return Xr;case"bool":case"boolean":return Qr;case"string":return es}throw new Error("THREE.KeyframeTrack: Unsupported typeName: "+i)}function lg(i){if(i.type===void 0)throw new Error("THREE.KeyframeTrack: track type undefined, can not parse");const e=og(i.type);if(i.times===void 0){const t=[],n=[];pf(i.keys,t,n,"value"),i.times=t,i.values=n}return e.parse!==void 0?e.parse(i):new e(i.name,i.times,i.values,i.interpolation)}const li={enabled:!1,files:{},add:function(i,e){this.enabled!==!1&&(this.files[i]=e)},get:function(i){if(this.enabled!==!1)return this.files[i]},remove:function(i){delete this.files[i]},clear:function(){this.files={}}};class cg{constructor(e,t,n){const r=this;let s=!1,a=0,o=0,l;const c=[];this.onStart=void 0,this.onLoad=e,this.onProgress=t,this.onError=n,this.abortController=new AbortController,this.itemStart=function(d){o++,s===!1&&r.onStart!==void 0&&r.onStart(d,a,o),s=!0},this.itemEnd=function(d){a++,r.onProgress!==void 0&&r.onProgress(d,a,o),a===o&&(s=!1,r.onLoad!==void 0&&r.onLoad())},this.itemError=function(d){r.onError!==void 0&&r.onError(d)},this.resolveURL=function(d){return l?l(d):d},this.setURLModifier=function(d){return l=d,this},this.addHandler=function(d,u){return c.push(d,u),this},this.removeHandler=function(d){const u=c.indexOf(d);return u!==-1&&c.splice(u,2),this},this.getHandler=function(d){for(let u=0,h=c.length;u<h;u+=2){const p=c[u],g=c[u+1];if(p.global&&(p.lastIndex=0),p.test(d))return g}return null},this.abort=function(){return this.abortController.abort(),this.abortController=new AbortController,this}}}const ug=new cg;class ts{constructor(e){this.manager=e!==void 0?e:ug,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(e,t){const n=this;return new Promise(function(r,s){n.load(e,r,t,s)})}parse(){}setCrossOrigin(e){return this.crossOrigin=e,this}setWithCredentials(e){return this.withCredentials=e,this}setPath(e){return this.path=e,this}setResourcePath(e){return this.resourcePath=e,this}setRequestHeader(e){return this.requestHeader=e,this}abort(){return this}}ts.DEFAULT_MATERIAL_NAME="__DEFAULT";const ii={};class dg extends Error{constructor(e,t){super(e),this.response=t}}class gf extends ts{constructor(e){super(e),this.mimeType="",this.responseType="",this._abortController=new AbortController}load(e,t,n,r){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);const s=li.get(`file:${e}`);if(s!==void 0)return this.manager.itemStart(e),setTimeout(()=>{t&&t(s),this.manager.itemEnd(e)},0),s;if(ii[e]!==void 0){ii[e].push({onLoad:t,onProgress:n,onError:r});return}ii[e]=[],ii[e].push({onLoad:t,onProgress:n,onError:r});const a=new Request(e,{headers:new Headers(this.requestHeader),credentials:this.withCredentials?"include":"same-origin",signal:typeof AbortSignal.any=="function"?AbortSignal.any([this._abortController.signal,this.manager.abortController.signal]):this._abortController.signal}),o=this.mimeType,l=this.responseType;fetch(a).then(c=>{if(c.status===200||c.status===0){if(c.status===0&&console.warn("THREE.FileLoader: HTTP Status 0 received."),typeof ReadableStream>"u"||c.body===void 0||c.body.getReader===void 0)return c;const d=ii[e],u=c.body.getReader(),h=c.headers.get("X-File-Size")||c.headers.get("Content-Length"),p=h?parseInt(h):0,g=p!==0;let v=0;const m=new ReadableStream({start(f){b();function b(){u.read().then(({done:_,value:x})=>{if(_)f.close();else{v+=x.byteLength;const R=new ProgressEvent("progress",{lengthComputable:g,loaded:v,total:p});for(let M=0,A=d.length;M<A;M++){const w=d[M];w.onProgress&&w.onProgress(R)}f.enqueue(x),b()}},_=>{f.error(_)})}}});return new Response(m)}else throw new dg(`fetch for "${c.url}" responded with ${c.status}: ${c.statusText}`,c)}).then(c=>{switch(l){case"arraybuffer":return c.arrayBuffer();case"blob":return c.blob();case"document":return c.text().then(d=>new DOMParser().parseFromString(d,o));case"json":return c.json();default:if(o==="")return c.text();{const u=/charset="?([^;"\s]*)"?/i.exec(o),h=u&&u[1]?u[1].toLowerCase():void 0,p=new TextDecoder(h);return c.arrayBuffer().then(g=>p.decode(g))}}}).then(c=>{li.add(`file:${e}`,c);const d=ii[e];delete ii[e];for(let u=0,h=d.length;u<h;u++){const p=d[u];p.onLoad&&p.onLoad(c)}}).catch(c=>{const d=ii[e];if(d===void 0)throw this.manager.itemError(e),c;delete ii[e];for(let u=0,h=d.length;u<h;u++){const p=d[u];p.onError&&p.onError(c)}this.manager.itemError(e)}).finally(()=>{this.manager.itemEnd(e)}),this.manager.itemStart(e)}setResponseType(e){return this.responseType=e,this}setMimeType(e){return this.mimeType=e,this}abort(){return this._abortController.abort(),this._abortController=new AbortController,this}}const br=new WeakMap;class hg extends ts{constructor(e){super(e)}load(e,t,n,r){this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);const s=this,a=li.get(`image:${e}`);if(a!==void 0){if(a.complete===!0)s.manager.itemStart(e),setTimeout(function(){t&&t(a),s.manager.itemEnd(e)},0);else{let u=br.get(a);u===void 0&&(u=[],br.set(a,u)),u.push({onLoad:t,onError:r})}return a}const o=Ns("img");function l(){d(),t&&t(this);const u=br.get(this)||[];for(let h=0;h<u.length;h++){const p=u[h];p.onLoad&&p.onLoad(this)}br.delete(this),s.manager.itemEnd(e)}function c(u){d(),r&&r(u),li.remove(`image:${e}`);const h=br.get(this)||[];for(let p=0;p<h.length;p++){const g=h[p];g.onError&&g.onError(u)}br.delete(this),s.manager.itemError(e),s.manager.itemEnd(e)}function d(){o.removeEventListener("load",l,!1),o.removeEventListener("error",c,!1)}return o.addEventListener("load",l,!1),o.addEventListener("error",c,!1),e.slice(0,5)!=="data:"&&this.crossOrigin!==void 0&&(o.crossOrigin=this.crossOrigin),li.add(`image:${e}`,o),s.manager.itemStart(e),o.src=e,o}}class ns extends ts{constructor(e){super(e)}load(e,t,n,r){const s=new Ft,a=new hg(this.manager);return a.setCrossOrigin(this.crossOrigin),a.setPath(this.path),a.load(e,function(o){s.image=o,s.needsUpdate=!0,t!==void 0&&t(s)},n,r),s}}class fo extends Mt{constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new Ie(e),this.intensity=t}dispose(){}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){const t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,this.groundColor!==void 0&&(t.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(t.object.distance=this.distance),this.angle!==void 0&&(t.object.angle=this.angle),this.decay!==void 0&&(t.object.decay=this.decay),this.penumbra!==void 0&&(t.object.penumbra=this.penumbra),this.shadow!==void 0&&(t.object.shadow=this.shadow.toJSON()),this.target!==void 0&&(t.object.target=this.target.uuid),t}}class fg extends fo{constructor(e,t,n){super(e,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(Mt.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Ie(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}}const nl=new qe,ad=new U,od=new U;class $c{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new Ce(512,512),this.mapType=Yn,this.map=null,this.mapPass=null,this.matrix=new qe,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Hc,this._frameExtents=new Ce(1,1),this._viewportCount=1,this._viewports=[new rt(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){const t=this.camera,n=this.matrix;ad.setFromMatrixPosition(e.matrixWorld),t.position.copy(ad),od.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(od),t.updateMatrixWorld(),nl.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),this._frustum.setFromProjectionMatrix(nl,t.coordinateSystem,t.reversedDepth),t.reversedDepth?n.set(.5,0,0,.5,0,.5,0,.5,0,0,1,0,0,0,0,1):n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(nl)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.autoUpdate=e.autoUpdate,this.needsUpdate=e.needsUpdate,this.normalBias=e.normalBias,this.blurSamples=e.blurSamples,this.mapSize.copy(e.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){const e={};return this.intensity!==1&&(e.intensity=this.intensity),this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}}class pg extends $c{constructor(){super(new Kt(50,1,.5,500)),this.isSpotLightShadow=!0,this.focus=1,this.aspect=1}updateMatrices(e){const t=this.camera,n=Vr*2*e.angle*this.focus,r=this.mapSize.width/this.mapSize.height*this.aspect,s=e.distance||t.far;(n!==t.fov||r!==t.aspect||s!==t.far)&&(t.fov=n,t.aspect=r,t.far=s,t.updateProjectionMatrix()),super.updateMatrices(e)}copy(e){return super.copy(e),this.focus=e.focus,this}}class mg extends fo{constructor(e,t,n=0,r=Math.PI/3,s=0,a=2){super(e,t),this.isSpotLight=!0,this.type="SpotLight",this.position.copy(Mt.DEFAULT_UP),this.updateMatrix(),this.target=new Mt,this.distance=n,this.angle=r,this.penumbra=s,this.decay=a,this.map=null,this.shadow=new pg}get power(){return this.intensity*Math.PI}set power(e){this.intensity=e/Math.PI}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.angle=e.angle,this.penumbra=e.penumbra,this.decay=e.decay,this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}}const ld=new qe,gs=new U,il=new U;class gg extends $c{constructor(){super(new Kt(90,1,.5,500)),this.isPointLightShadow=!0,this._frameExtents=new Ce(4,2),this._viewportCount=6,this._viewports=[new rt(2,1,1,1),new rt(0,1,1,1),new rt(3,1,1,1),new rt(1,1,1,1),new rt(3,0,1,1),new rt(1,0,1,1)],this._cubeDirections=[new U(1,0,0),new U(-1,0,0),new U(0,0,1),new U(0,0,-1),new U(0,1,0),new U(0,-1,0)],this._cubeUps=[new U(0,1,0),new U(0,1,0),new U(0,1,0),new U(0,1,0),new U(0,0,1),new U(0,0,-1)]}updateMatrices(e,t=0){const n=this.camera,r=this.matrix,s=e.distance||n.far;s!==n.far&&(n.far=s,n.updateProjectionMatrix()),gs.setFromMatrixPosition(e.matrixWorld),n.position.copy(gs),il.copy(n.position),il.add(this._cubeDirections[t]),n.up.copy(this._cubeUps[t]),n.lookAt(il),n.updateMatrixWorld(),r.makeTranslation(-gs.x,-gs.y,-gs.z),ld.multiplyMatrices(n.projectionMatrix,n.matrixWorldInverse),this._frustum.setFromProjectionMatrix(ld,n.coordinateSystem,n.reversedDepth)}}class vg extends fo{constructor(e,t,n=0,r=2){super(e,t),this.isPointLight=!0,this.type="PointLight",this.distance=n,this.decay=r,this.shadow=new gg}get power(){return this.intensity*4*Math.PI}set power(e){this.intensity=e/(4*Math.PI)}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.decay=e.decay,this.shadow=e.shadow.clone(),this}}class Ws extends rf{constructor(e=-1,t=1,n=1,r=-1,s=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=n,this.bottom=r,this.near=s,this.far=a,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,n,r,s,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=r,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,r=(this.top+this.bottom)/2;let s=n-e,a=n+e,o=r+t,l=r-t;if(this.view!==null&&this.view.enabled){const c=(this.right-this.left)/this.view.fullWidth/this.zoom,d=(this.top-this.bottom)/this.view.fullHeight/this.zoom;s+=c*this.view.offsetX,a=s+c*this.view.width,o-=d*this.view.offsetY,l=o-d*this.view.height}this.projectionMatrix.makeOrthographic(s,a,o,l,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}}class _g extends $c{constructor(){super(new Ws(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class vf extends fo{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(Mt.DEFAULT_UP),this.updateMatrix(),this.target=new Mt,this.shadow=new _g}dispose(){this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}}class As{static extractUrlBase(e){const t=e.lastIndexOf("/");return t===-1?"./":e.slice(0,t+1)}static resolveURL(e,t){return typeof e!="string"||e===""?"":(/^https?:\/\//i.test(t)&&/^\//.test(e)&&(t=t.replace(/(^https?:\/\/[^\/]+).*/i,"$1")),/^(https?:)?\/\//i.test(e)||/^data:.*,.*$/i.test(e)||/^blob:.*$/i.test(e)?e:t+e)}}class xg extends Lt{constructor(){super(),this.isInstancedBufferGeometry=!0,this.type="InstancedBufferGeometry",this.instanceCount=1/0}copy(e){return super.copy(e),this.instanceCount=e.instanceCount,this}toJSON(){const e=super.toJSON();return e.instanceCount=this.instanceCount,e.isInstancedBufferGeometry=!0,e}}const rl=new WeakMap;class yg extends ts{constructor(e){super(e),this.isImageBitmapLoader=!0,typeof createImageBitmap>"u"&&console.warn("THREE.ImageBitmapLoader: createImageBitmap() not supported."),typeof fetch>"u"&&console.warn("THREE.ImageBitmapLoader: fetch() not supported."),this.options={premultiplyAlpha:"none"},this._abortController=new AbortController}setOptions(e){return this.options=e,this}load(e,t,n,r){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);const s=this,a=li.get(`image-bitmap:${e}`);if(a!==void 0){if(s.manager.itemStart(e),a.then){a.then(c=>{if(rl.has(a)===!0)r&&r(rl.get(a)),s.manager.itemError(e),s.manager.itemEnd(e);else return t&&t(c),s.manager.itemEnd(e),c});return}return setTimeout(function(){t&&t(a),s.manager.itemEnd(e)},0),a}const o={};o.credentials=this.crossOrigin==="anonymous"?"same-origin":"include",o.headers=this.requestHeader,o.signal=typeof AbortSignal.any=="function"?AbortSignal.any([this._abortController.signal,this.manager.abortController.signal]):this._abortController.signal;const l=fetch(e,o).then(function(c){return c.blob()}).then(function(c){return createImageBitmap(c,Object.assign(s.options,{colorSpaceConversion:"none"}))}).then(function(c){return li.add(`image-bitmap:${e}`,c),t&&t(c),s.manager.itemEnd(e),c}).catch(function(c){r&&r(c),rl.set(l,c),li.remove(`image-bitmap:${e}`),s.manager.itemError(e),s.manager.itemEnd(e)});li.add(`image-bitmap:${e}`,l),s.manager.itemStart(e)}abort(){return this._abortController.abort(),this._abortController=new AbortController,this}}class bg extends Kt{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e}}class Sg{constructor(e=!0){this.autoStart=e,this.startTime=0,this.oldTime=0,this.elapsedTime=0,this.running=!1}start(){this.startTime=performance.now(),this.oldTime=this.startTime,this.elapsedTime=0,this.running=!0}stop(){this.getElapsedTime(),this.running=!1,this.autoStart=!1}getElapsedTime(){return this.getDelta(),this.elapsedTime}getDelta(){let e=0;if(this.autoStart&&!this.running)return this.start(),0;if(this.running){const t=performance.now();e=(t-this.oldTime)/1e3,this.oldTime=t,this.elapsedTime+=e}return e}}const Kc="\\[\\]\\.:\\/",Mg=new RegExp("["+Kc+"]","g"),Zc="[^"+Kc+"]",Eg="[^"+Kc.replace("\\.","")+"]",Tg=/((?:WC+[\/:])*)/.source.replace("WC",Zc),Ag=/(WCOD+)?/.source.replace("WCOD",Eg),wg=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",Zc),Rg=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",Zc),Cg=new RegExp("^"+Tg+Ag+wg+Rg+"$"),Ig=["material","materials","bones","map"];class Pg{constructor(e,t,n){const r=n||lt.parseTrackName(t);this._targetGroup=e,this._bindings=e.subscribe_(t,r)}getValue(e,t){this.bind();const n=this._targetGroup.nCachedObjects_,r=this._bindings[n];r!==void 0&&r.getValue(e,t)}setValue(e,t){const n=this._bindings;for(let r=this._targetGroup.nCachedObjects_,s=n.length;r!==s;++r)n[r].setValue(e,t)}bind(){const e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].bind()}unbind(){const e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].unbind()}}class lt{constructor(e,t,n){this.path=t,this.parsedPath=n||lt.parseTrackName(t),this.node=lt.findNode(e,this.parsedPath.nodeName),this.rootNode=e,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(e,t,n){return e&&e.isAnimationObjectGroup?new lt.Composite(e,t,n):new lt(e,t,n)}static sanitizeNodeName(e){return e.replace(/\s/g,"_").replace(Mg,"")}static parseTrackName(e){const t=Cg.exec(e);if(t===null)throw new Error("PropertyBinding: Cannot parse trackName: "+e);const n={nodeName:t[2],objectName:t[3],objectIndex:t[4],propertyName:t[5],propertyIndex:t[6]},r=n.nodeName&&n.nodeName.lastIndexOf(".");if(r!==void 0&&r!==-1){const s=n.nodeName.substring(r+1);Ig.indexOf(s)!==-1&&(n.nodeName=n.nodeName.substring(0,r),n.objectName=s)}if(n.propertyName===null||n.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+e);return n}static findNode(e,t){if(t===void 0||t===""||t==="."||t===-1||t===e.name||t===e.uuid)return e;if(e.skeleton){const n=e.skeleton.getBoneByName(t);if(n!==void 0)return n}if(e.children){const n=function(s){for(let a=0;a<s.length;a++){const o=s[a];if(o.name===t||o.uuid===t)return o;const l=n(o.children);if(l)return l}return null},r=n(e.children);if(r)return r}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(e,t){e[t]=this.targetObject[this.propertyName]}_getValue_array(e,t){const n=this.resolvedProperty;for(let r=0,s=n.length;r!==s;++r)e[t++]=n[r]}_getValue_arrayElement(e,t){e[t]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(e,t){this.resolvedProperty.toArray(e,t)}_setValue_direct(e,t){this.targetObject[this.propertyName]=e[t]}_setValue_direct_setNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(e,t){const n=this.resolvedProperty;for(let r=0,s=n.length;r!==s;++r)n[r]=e[t++]}_setValue_array_setNeedsUpdate(e,t){const n=this.resolvedProperty;for(let r=0,s=n.length;r!==s;++r)n[r]=e[t++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(e,t){const n=this.resolvedProperty;for(let r=0,s=n.length;r!==s;++r)n[r]=e[t++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(e,t){this.resolvedProperty[this.propertyIndex]=e[t]}_setValue_arrayElement_setNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(e,t){this.resolvedProperty.fromArray(e,t)}_setValue_fromArray_setNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(e,t){this.bind(),this.getValue(e,t)}_setValue_unbound(e,t){this.bind(),this.setValue(e,t)}bind(){let e=this.node;const t=this.parsedPath,n=t.objectName,r=t.propertyName;let s=t.propertyIndex;if(e||(e=lt.findNode(this.rootNode,t.nodeName),this.node=e),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!e){console.warn("THREE.PropertyBinding: No target node found for track: "+this.path+".");return}if(n){let c=t.objectIndex;switch(n){case"materials":if(!e.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!e.material.materials){console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}e=e.material.materials;break;case"bones":if(!e.skeleton){console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}e=e.skeleton.bones;for(let d=0;d<e.length;d++)if(e[d].name===c){c=d;break}break;case"map":if("map"in e){e=e.map;break}if(!e.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!e.material.map){console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}e=e.material.map;break;default:if(e[n]===void 0){console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);return}e=e[n]}if(c!==void 0){if(e[c]===void 0){console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,e);return}e=e[c]}}const a=e[r];if(a===void 0){const c=t.nodeName;console.error("THREE.PropertyBinding: Trying to update property for track: "+c+"."+r+" but it wasn't found.",e);return}let o=this.Versioning.None;this.targetObject=e,e.isMaterial===!0?o=this.Versioning.NeedsUpdate:e.isObject3D===!0&&(o=this.Versioning.MatrixWorldNeedsUpdate);let l=this.BindingType.Direct;if(s!==void 0){if(r==="morphTargetInfluences"){if(!e.geometry){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!e.geometry.morphAttributes){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}e.morphTargetDictionary[s]!==void 0&&(s=e.morphTargetDictionary[s])}l=this.BindingType.ArrayElement,this.resolvedProperty=a,this.propertyIndex=s}else a.fromArray!==void 0&&a.toArray!==void 0?(l=this.BindingType.HasFromToArray,this.resolvedProperty=a):Array.isArray(a)?(l=this.BindingType.EntireArray,this.resolvedProperty=a):this.propertyName=r;this.getValue=this.GetterByBindingType[l],this.setValue=this.SetterByBindingTypeAndVersioning[l][o]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}}lt.Composite=Pg;lt.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};lt.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};lt.prototype.GetterByBindingType=[lt.prototype._getValue_direct,lt.prototype._getValue_array,lt.prototype._getValue_arrayElement,lt.prototype._getValue_toArray];lt.prototype.SetterByBindingTypeAndVersioning=[[lt.prototype._setValue_direct,lt.prototype._setValue_direct_setNeedsUpdate,lt.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[lt.prototype._setValue_array,lt.prototype._setValue_array_setNeedsUpdate,lt.prototype._setValue_array_setMatrixWorldNeedsUpdate],[lt.prototype._setValue_arrayElement,lt.prototype._setValue_arrayElement_setNeedsUpdate,lt.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[lt.prototype._setValue_fromArray,lt.prototype._setValue_fromArray_setNeedsUpdate,lt.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];const cd=new qe;class Lg{constructor(e,t,n=0,r=1/0){this.ray=new ks(e,t),this.near=n,this.far=r,this.camera=null,this.layers=new zc,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,(t.near+t.far)/(t.near-t.far)).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):console.error("THREE.Raycaster: Unsupported camera type: "+t.type)}setFromXRController(e){return cd.identity().extractRotation(e.matrixWorld),this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(cd),this}intersectObject(e,t=!0,n=[]){return pc(e,this,n,t),n.sort(ud),n}intersectObjects(e,t=!0,n=[]){for(let r=0,s=e.length;r<s;r++)pc(e[r],this,n,t);return n.sort(ud),n}}function ud(i,e){return i.distance-e.distance}function pc(i,e,t,n){let r=!0;if(i.layers.test(e.layers)&&i.raycast(e,t)===!1&&(r=!1),r===!0&&n===!0){const s=i.children;for(let a=0,o=s.length;a<o;a++)pc(s[a],e,t,!0)}}function dd(i,e,t,n){const r=Dg(n);switch(t){case qh:return i*e;case Dc:return i*e/r.components*r.byteLength;case Nc:return i*e/r.components*r.byteLength;case jh:return i*e*2/r.components*r.byteLength;case Oc:return i*e*2/r.components*r.byteLength;case Yh:return i*e*3/r.components*r.byteLength;case Rn:return i*e*4/r.components*r.byteLength;case Uc:return i*e*4/r.components*r.byteLength;case Fa:case Ba:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case ka:case za:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case Bl:case zl:return Math.max(i,16)*Math.max(e,8)/4;case Fl:case kl:return Math.max(i,8)*Math.max(e,8)/2;case Vl:case Hl:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case Gl:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case Wl:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case Xl:return Math.floor((i+4)/5)*Math.floor((e+3)/4)*16;case ql:return Math.floor((i+4)/5)*Math.floor((e+4)/5)*16;case Yl:return Math.floor((i+5)/6)*Math.floor((e+4)/5)*16;case jl:return Math.floor((i+5)/6)*Math.floor((e+5)/6)*16;case $l:return Math.floor((i+7)/8)*Math.floor((e+4)/5)*16;case Kl:return Math.floor((i+7)/8)*Math.floor((e+5)/6)*16;case Zl:return Math.floor((i+7)/8)*Math.floor((e+7)/8)*16;case Jl:return Math.floor((i+9)/10)*Math.floor((e+4)/5)*16;case Ql:return Math.floor((i+9)/10)*Math.floor((e+5)/6)*16;case ec:return Math.floor((i+9)/10)*Math.floor((e+7)/8)*16;case tc:return Math.floor((i+9)/10)*Math.floor((e+9)/10)*16;case nc:return Math.floor((i+11)/12)*Math.floor((e+9)/10)*16;case ic:return Math.floor((i+11)/12)*Math.floor((e+11)/12)*16;case rc:case sc:case ac:return Math.ceil(i/4)*Math.ceil(e/4)*16;case oc:case lc:return Math.ceil(i/4)*Math.ceil(e/4)*8;case cc:case uc:return Math.ceil(i/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${t} format.`)}function Dg(i){switch(i){case Yn:case Hh:return{byteLength:1,components:1};case Rs:case Gh:case di:return{byteLength:2,components:1};case Pc:case Lc:return{byteLength:2,components:4};case Zi:case Ic:case kn:return{byteLength:4,components:1};case Wh:case Xh:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${i}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Rc}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Rc);/**
 * @license
 * Copyright 2010-2025 Three.js Authors
 * SPDX-License-Identifier: MIT
 */function _f(){let i=null,e=!1,t=null,n=null;function r(s,a){t(s,a),n=i.requestAnimationFrame(r)}return{start:function(){e!==!0&&t!==null&&(n=i.requestAnimationFrame(r),e=!0)},stop:function(){i.cancelAnimationFrame(n),e=!1},setAnimationLoop:function(s){t=s},setContext:function(s){i=s}}}function Ng(i){const e=new WeakMap;function t(o,l){const c=o.array,d=o.usage,u=c.byteLength,h=i.createBuffer();i.bindBuffer(l,h),i.bufferData(l,c,d),o.onUploadCallback();let p;if(c instanceof Float32Array)p=i.FLOAT;else if(typeof Float16Array<"u"&&c instanceof Float16Array)p=i.HALF_FLOAT;else if(c instanceof Uint16Array)o.isFloat16BufferAttribute?p=i.HALF_FLOAT:p=i.UNSIGNED_SHORT;else if(c instanceof Int16Array)p=i.SHORT;else if(c instanceof Uint32Array)p=i.UNSIGNED_INT;else if(c instanceof Int32Array)p=i.INT;else if(c instanceof Int8Array)p=i.BYTE;else if(c instanceof Uint8Array)p=i.UNSIGNED_BYTE;else if(c instanceof Uint8ClampedArray)p=i.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+c);return{buffer:h,type:p,bytesPerElement:c.BYTES_PER_ELEMENT,version:o.version,size:u}}function n(o,l,c){const d=l.array,u=l.updateRanges;if(i.bindBuffer(c,o),u.length===0)i.bufferSubData(c,0,d);else{u.sort((p,g)=>p.start-g.start);let h=0;for(let p=1;p<u.length;p++){const g=u[h],v=u[p];v.start<=g.start+g.count+1?g.count=Math.max(g.count,v.start+v.count-g.start):(++h,u[h]=v)}u.length=h+1;for(let p=0,g=u.length;p<g;p++){const v=u[p];i.bufferSubData(c,v.start*d.BYTES_PER_ELEMENT,d,v.start,v.count)}l.clearUpdateRanges()}l.onUploadCallback()}function r(o){return o.isInterleavedBufferAttribute&&(o=o.data),e.get(o)}function s(o){o.isInterleavedBufferAttribute&&(o=o.data);const l=e.get(o);l&&(i.deleteBuffer(l.buffer),e.delete(o))}function a(o,l){if(o.isInterleavedBufferAttribute&&(o=o.data),o.isGLBufferAttribute){const d=e.get(o);(!d||d.version<o.version)&&e.set(o,{buffer:o.buffer,type:o.type,bytesPerElement:o.elementSize,version:o.version});return}const c=e.get(o);if(c===void 0)e.set(o,t(o,l));else if(c.version<o.version){if(c.size!==o.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(c.buffer,o,l),c.version=o.version}}return{get:r,remove:s,update:a}}var Og=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,Ug=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,Fg=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,Bg=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,kg=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,zg=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,Vg=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,Hg=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,Gg=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,Wg=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,Xg=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,qg=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Yg=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,jg=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,$g=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Kg=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,Zg=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Jg=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Qg=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,e0=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,t0=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,n0=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,i0=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,r0=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,s0=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,a0=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,o0=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,l0=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,c0=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,u0=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,d0="gl_FragColor = linearToOutputTexel( gl_FragColor );",h0=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,f0=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,p0=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,m0=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,g0=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,v0=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,_0=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,x0=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,y0=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,b0=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,S0=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,M0=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,E0=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,T0=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,A0=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,w0=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,R0=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,C0=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,I0=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,P0=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,L0=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,D0=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,N0=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,O0=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,U0=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,F0=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,B0=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,k0=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,z0=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,V0=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,H0=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,G0=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,W0=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,X0=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,q0=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Y0=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,j0=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,$0=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,K0=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,Z0=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,J0=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Q0=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,ev=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,tv=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,nv=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,iv=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,rv=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,sv=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,av=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,ov=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,lv=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,cv=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,uv=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,dv=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,hv=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,fv=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,pv=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,mv=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,gv=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		float depth = unpackRGBAToDepth( texture2D( depths, uv ) );
		#ifdef USE_REVERSED_DEPTH_BUFFER
			return step( depth, compare );
		#else
			return step( compare, depth );
		#endif
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow( sampler2D shadow, vec2 uv, float compare ) {
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		#ifdef USE_REVERSED_DEPTH_BUFFER
			float hard_shadow = step( distribution.x, compare );
		#else
			float hard_shadow = step( compare, distribution.x );
		#endif
		if ( hard_shadow != 1.0 ) {
			float distance = compare - distribution.x;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,vv=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,_v=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,xv=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,yv=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,bv=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Sv=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,Mv=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,Ev=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,Tv=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,Av=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,wv=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,Rv=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,Cv=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,Iv=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Pv=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Lv=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,Dv=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const Nv=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,Ov=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Uv=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Fv=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Bv=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,kv=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,zv=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,Vv=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,Hv=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Gv=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,Wv=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,Xv=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,qv=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Yv=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,jv=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,$v=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Kv=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Zv=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Jv=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Qv=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,e_=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,t_=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,n_=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,i_=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,r_=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,s_=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,a_=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,o_=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,l_=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,c_=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,u_=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,d_=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,h_=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,f_=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Ze={alphahash_fragment:Og,alphahash_pars_fragment:Ug,alphamap_fragment:Fg,alphamap_pars_fragment:Bg,alphatest_fragment:kg,alphatest_pars_fragment:zg,aomap_fragment:Vg,aomap_pars_fragment:Hg,batching_pars_vertex:Gg,batching_vertex:Wg,begin_vertex:Xg,beginnormal_vertex:qg,bsdfs:Yg,iridescence_fragment:jg,bumpmap_pars_fragment:$g,clipping_planes_fragment:Kg,clipping_planes_pars_fragment:Zg,clipping_planes_pars_vertex:Jg,clipping_planes_vertex:Qg,color_fragment:e0,color_pars_fragment:t0,color_pars_vertex:n0,color_vertex:i0,common:r0,cube_uv_reflection_fragment:s0,defaultnormal_vertex:a0,displacementmap_pars_vertex:o0,displacementmap_vertex:l0,emissivemap_fragment:c0,emissivemap_pars_fragment:u0,colorspace_fragment:d0,colorspace_pars_fragment:h0,envmap_fragment:f0,envmap_common_pars_fragment:p0,envmap_pars_fragment:m0,envmap_pars_vertex:g0,envmap_physical_pars_fragment:w0,envmap_vertex:v0,fog_vertex:_0,fog_pars_vertex:x0,fog_fragment:y0,fog_pars_fragment:b0,gradientmap_pars_fragment:S0,lightmap_pars_fragment:M0,lights_lambert_fragment:E0,lights_lambert_pars_fragment:T0,lights_pars_begin:A0,lights_toon_fragment:R0,lights_toon_pars_fragment:C0,lights_phong_fragment:I0,lights_phong_pars_fragment:P0,lights_physical_fragment:L0,lights_physical_pars_fragment:D0,lights_fragment_begin:N0,lights_fragment_maps:O0,lights_fragment_end:U0,logdepthbuf_fragment:F0,logdepthbuf_pars_fragment:B0,logdepthbuf_pars_vertex:k0,logdepthbuf_vertex:z0,map_fragment:V0,map_pars_fragment:H0,map_particle_fragment:G0,map_particle_pars_fragment:W0,metalnessmap_fragment:X0,metalnessmap_pars_fragment:q0,morphinstance_vertex:Y0,morphcolor_vertex:j0,morphnormal_vertex:$0,morphtarget_pars_vertex:K0,morphtarget_vertex:Z0,normal_fragment_begin:J0,normal_fragment_maps:Q0,normal_pars_fragment:ev,normal_pars_vertex:tv,normal_vertex:nv,normalmap_pars_fragment:iv,clearcoat_normal_fragment_begin:rv,clearcoat_normal_fragment_maps:sv,clearcoat_pars_fragment:av,iridescence_pars_fragment:ov,opaque_fragment:lv,packing:cv,premultiplied_alpha_fragment:uv,project_vertex:dv,dithering_fragment:hv,dithering_pars_fragment:fv,roughnessmap_fragment:pv,roughnessmap_pars_fragment:mv,shadowmap_pars_fragment:gv,shadowmap_pars_vertex:vv,shadowmap_vertex:_v,shadowmask_pars_fragment:xv,skinbase_vertex:yv,skinning_pars_vertex:bv,skinning_vertex:Sv,skinnormal_vertex:Mv,specularmap_fragment:Ev,specularmap_pars_fragment:Tv,tonemapping_fragment:Av,tonemapping_pars_fragment:wv,transmission_fragment:Rv,transmission_pars_fragment:Cv,uv_pars_fragment:Iv,uv_pars_vertex:Pv,uv_vertex:Lv,worldpos_vertex:Dv,background_vert:Nv,background_frag:Ov,backgroundCube_vert:Uv,backgroundCube_frag:Fv,cube_vert:Bv,cube_frag:kv,depth_vert:zv,depth_frag:Vv,distanceRGBA_vert:Hv,distanceRGBA_frag:Gv,equirect_vert:Wv,equirect_frag:Xv,linedashed_vert:qv,linedashed_frag:Yv,meshbasic_vert:jv,meshbasic_frag:$v,meshlambert_vert:Kv,meshlambert_frag:Zv,meshmatcap_vert:Jv,meshmatcap_frag:Qv,meshnormal_vert:e_,meshnormal_frag:t_,meshphong_vert:n_,meshphong_frag:i_,meshphysical_vert:r_,meshphysical_frag:s_,meshtoon_vert:a_,meshtoon_frag:o_,points_vert:l_,points_frag:c_,shadow_vert:u_,shadow_frag:d_,sprite_vert:h_,sprite_frag:f_},be={common:{diffuse:{value:new Ie(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new $e},alphaMap:{value:null},alphaMapTransform:{value:new $e},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new $e}},envmap:{envMap:{value:null},envMapRotation:{value:new $e},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new $e}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new $e}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new $e},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new $e},normalScale:{value:new Ce(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new $e},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new $e}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new $e}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new $e}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Ie(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new Ie(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new $e},alphaTest:{value:0},uvTransform:{value:new $e}},sprite:{diffuse:{value:new Ie(16777215)},opacity:{value:1},center:{value:new Ce(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new $e},alphaMap:{value:null},alphaMapTransform:{value:new $e},alphaTest:{value:0}}},Xn={basic:{uniforms:$t([be.common,be.specularmap,be.envmap,be.aomap,be.lightmap,be.fog]),vertexShader:Ze.meshbasic_vert,fragmentShader:Ze.meshbasic_frag},lambert:{uniforms:$t([be.common,be.specularmap,be.envmap,be.aomap,be.lightmap,be.emissivemap,be.bumpmap,be.normalmap,be.displacementmap,be.fog,be.lights,{emissive:{value:new Ie(0)}}]),vertexShader:Ze.meshlambert_vert,fragmentShader:Ze.meshlambert_frag},phong:{uniforms:$t([be.common,be.specularmap,be.envmap,be.aomap,be.lightmap,be.emissivemap,be.bumpmap,be.normalmap,be.displacementmap,be.fog,be.lights,{emissive:{value:new Ie(0)},specular:{value:new Ie(1118481)},shininess:{value:30}}]),vertexShader:Ze.meshphong_vert,fragmentShader:Ze.meshphong_frag},standard:{uniforms:$t([be.common,be.envmap,be.aomap,be.lightmap,be.emissivemap,be.bumpmap,be.normalmap,be.displacementmap,be.roughnessmap,be.metalnessmap,be.fog,be.lights,{emissive:{value:new Ie(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Ze.meshphysical_vert,fragmentShader:Ze.meshphysical_frag},toon:{uniforms:$t([be.common,be.aomap,be.lightmap,be.emissivemap,be.bumpmap,be.normalmap,be.displacementmap,be.gradientmap,be.fog,be.lights,{emissive:{value:new Ie(0)}}]),vertexShader:Ze.meshtoon_vert,fragmentShader:Ze.meshtoon_frag},matcap:{uniforms:$t([be.common,be.bumpmap,be.normalmap,be.displacementmap,be.fog,{matcap:{value:null}}]),vertexShader:Ze.meshmatcap_vert,fragmentShader:Ze.meshmatcap_frag},points:{uniforms:$t([be.points,be.fog]),vertexShader:Ze.points_vert,fragmentShader:Ze.points_frag},dashed:{uniforms:$t([be.common,be.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Ze.linedashed_vert,fragmentShader:Ze.linedashed_frag},depth:{uniforms:$t([be.common,be.displacementmap]),vertexShader:Ze.depth_vert,fragmentShader:Ze.depth_frag},normal:{uniforms:$t([be.common,be.bumpmap,be.normalmap,be.displacementmap,{opacity:{value:1}}]),vertexShader:Ze.meshnormal_vert,fragmentShader:Ze.meshnormal_frag},sprite:{uniforms:$t([be.sprite,be.fog]),vertexShader:Ze.sprite_vert,fragmentShader:Ze.sprite_frag},background:{uniforms:{uvTransform:{value:new $e},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Ze.background_vert,fragmentShader:Ze.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new $e}},vertexShader:Ze.backgroundCube_vert,fragmentShader:Ze.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Ze.cube_vert,fragmentShader:Ze.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Ze.equirect_vert,fragmentShader:Ze.equirect_frag},distanceRGBA:{uniforms:$t([be.common,be.displacementmap,{referencePosition:{value:new U},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Ze.distanceRGBA_vert,fragmentShader:Ze.distanceRGBA_frag},shadow:{uniforms:$t([be.lights,be.fog,{color:{value:new Ie(0)},opacity:{value:1}}]),vertexShader:Ze.shadow_vert,fragmentShader:Ze.shadow_frag}};Xn.physical={uniforms:$t([Xn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new $e},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new $e},clearcoatNormalScale:{value:new Ce(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new $e},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new $e},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new $e},sheen:{value:0},sheenColor:{value:new Ie(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new $e},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new $e},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new $e},transmissionSamplerSize:{value:new Ce},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new $e},attenuationDistance:{value:0},attenuationColor:{value:new Ie(0)},specularColor:{value:new Ie(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new $e},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new $e},anisotropyVector:{value:new Ce},anisotropyMap:{value:null},anisotropyMapTransform:{value:new $e}}]),vertexShader:Ze.meshphysical_vert,fragmentShader:Ze.meshphysical_frag};const wa={r:0,b:0,g:0},Hi=new xn,p_=new qe;function m_(i,e,t,n,r,s,a){const o=new Ie(0);let l=s===!0?0:1,c,d,u=null,h=0,p=null;function g(_){let x=_.isScene===!0?_.background:null;return x&&x.isTexture&&(x=(_.backgroundBlurriness>0?t:e).get(x)),x}function v(_){let x=!1;const R=g(_);R===null?f(o,l):R&&R.isColor&&(f(R,1),x=!0);const M=i.xr.getEnvironmentBlendMode();M==="additive"?n.buffers.color.setClear(0,0,0,1,a):M==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,a),(i.autoClear||x)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil))}function m(_,x){const R=g(x);R&&(R.isCubeTexture||R.mapping===ao)?(d===void 0&&(d=new ht(new zs(1,1,1),new wt({name:"BackgroundCubeMaterial",uniforms:Hr(Xn.backgroundCube.uniforms),vertexShader:Xn.backgroundCube.vertexShader,fragmentShader:Xn.backgroundCube.fragmentShader,side:cn,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),d.geometry.deleteAttribute("normal"),d.geometry.deleteAttribute("uv"),d.onBeforeRender=function(M,A,w){this.matrixWorld.copyPosition(w.matrixWorld)},Object.defineProperty(d.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),r.update(d)),Hi.copy(x.backgroundRotation),Hi.x*=-1,Hi.y*=-1,Hi.z*=-1,R.isCubeTexture&&R.isRenderTargetTexture===!1&&(Hi.y*=-1,Hi.z*=-1),d.material.uniforms.envMap.value=R,d.material.uniforms.flipEnvMap.value=R.isCubeTexture&&R.isRenderTargetTexture===!1?-1:1,d.material.uniforms.backgroundBlurriness.value=x.backgroundBlurriness,d.material.uniforms.backgroundIntensity.value=x.backgroundIntensity,d.material.uniforms.backgroundRotation.value.setFromMatrix4(p_.makeRotationFromEuler(Hi)),d.material.toneMapped=tt.getTransfer(R.colorSpace)!==pt,(u!==R||h!==R.version||p!==i.toneMapping)&&(d.material.needsUpdate=!0,u=R,h=R.version,p=i.toneMapping),d.layers.enableAll(),_.unshift(d,d.geometry,d.material,0,0,null)):R&&R.isTexture&&(c===void 0&&(c=new ht(new yn(2,2),new wt({name:"BackgroundMaterial",uniforms:Hr(Xn.background.uniforms),vertexShader:Xn.background.vertexShader,fragmentShader:Xn.background.fragmentShader,side:fi,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),c.geometry.deleteAttribute("normal"),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),r.update(c)),c.material.uniforms.t2D.value=R,c.material.uniforms.backgroundIntensity.value=x.backgroundIntensity,c.material.toneMapped=tt.getTransfer(R.colorSpace)!==pt,R.matrixAutoUpdate===!0&&R.updateMatrix(),c.material.uniforms.uvTransform.value.copy(R.matrix),(u!==R||h!==R.version||p!==i.toneMapping)&&(c.material.needsUpdate=!0,u=R,h=R.version,p=i.toneMapping),c.layers.enableAll(),_.unshift(c,c.geometry,c.material,0,0,null))}function f(_,x){_.getRGB(wa,nf(i)),n.buffers.color.setClear(wa.r,wa.g,wa.b,x,a)}function b(){d!==void 0&&(d.geometry.dispose(),d.material.dispose(),d=void 0),c!==void 0&&(c.geometry.dispose(),c.material.dispose(),c=void 0)}return{getClearColor:function(){return o},setClearColor:function(_,x=1){o.set(_),l=x,f(o,l)},getClearAlpha:function(){return l},setClearAlpha:function(_){l=_,f(o,l)},render:v,addToRenderList:m,dispose:b}}function g_(i,e){const t=i.getParameter(i.MAX_VERTEX_ATTRIBS),n={},r=h(null);let s=r,a=!1;function o(y,T,N,B,k){let V=!1;const D=u(B,N,T);s!==D&&(s=D,c(s.object)),V=p(y,B,N,k),V&&g(y,B,N,k),k!==null&&e.update(k,i.ELEMENT_ARRAY_BUFFER),(V||a)&&(a=!1,x(y,T,N,B),k!==null&&i.bindBuffer(i.ELEMENT_ARRAY_BUFFER,e.get(k).buffer))}function l(){return i.createVertexArray()}function c(y){return i.bindVertexArray(y)}function d(y){return i.deleteVertexArray(y)}function u(y,T,N){const B=N.wireframe===!0;let k=n[y.id];k===void 0&&(k={},n[y.id]=k);let V=k[T.id];V===void 0&&(V={},k[T.id]=V);let D=V[B];return D===void 0&&(D=h(l()),V[B]=D),D}function h(y){const T=[],N=[],B=[];for(let k=0;k<t;k++)T[k]=0,N[k]=0,B[k]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:T,enabledAttributes:N,attributeDivisors:B,object:y,attributes:{},index:null}}function p(y,T,N,B){const k=s.attributes,V=T.attributes;let D=0;const O=N.getAttributes();for(const F in O)if(O[F].location>=0){const j=k[F];let te=V[F];if(te===void 0&&(F==="instanceMatrix"&&y.instanceMatrix&&(te=y.instanceMatrix),F==="instanceColor"&&y.instanceColor&&(te=y.instanceColor)),j===void 0||j.attribute!==te||te&&j.data!==te.data)return!0;D++}return s.attributesNum!==D||s.index!==B}function g(y,T,N,B){const k={},V=T.attributes;let D=0;const O=N.getAttributes();for(const F in O)if(O[F].location>=0){let j=V[F];j===void 0&&(F==="instanceMatrix"&&y.instanceMatrix&&(j=y.instanceMatrix),F==="instanceColor"&&y.instanceColor&&(j=y.instanceColor));const te={};te.attribute=j,j&&j.data&&(te.data=j.data),k[F]=te,D++}s.attributes=k,s.attributesNum=D,s.index=B}function v(){const y=s.newAttributes;for(let T=0,N=y.length;T<N;T++)y[T]=0}function m(y){f(y,0)}function f(y,T){const N=s.newAttributes,B=s.enabledAttributes,k=s.attributeDivisors;N[y]=1,B[y]===0&&(i.enableVertexAttribArray(y),B[y]=1),k[y]!==T&&(i.vertexAttribDivisor(y,T),k[y]=T)}function b(){const y=s.newAttributes,T=s.enabledAttributes;for(let N=0,B=T.length;N<B;N++)T[N]!==y[N]&&(i.disableVertexAttribArray(N),T[N]=0)}function _(y,T,N,B,k,V,D){D===!0?i.vertexAttribIPointer(y,T,N,k,V):i.vertexAttribPointer(y,T,N,B,k,V)}function x(y,T,N,B){v();const k=B.attributes,V=N.getAttributes(),D=T.defaultAttributeValues;for(const O in V){const F=V[O];if(F.location>=0){let z=k[O];if(z===void 0&&(O==="instanceMatrix"&&y.instanceMatrix&&(z=y.instanceMatrix),O==="instanceColor"&&y.instanceColor&&(z=y.instanceColor)),z!==void 0){const j=z.normalized,te=z.itemSize,L=e.get(z);if(L===void 0)continue;const $=L.buffer,Z=L.type,ae=L.bytesPerElement,G=Z===i.INT||Z===i.UNSIGNED_INT||z.gpuType===Ic;if(z.isInterleavedBufferAttribute){const X=z.data,re=X.stride,ye=z.offset;if(X.isInstancedInterleavedBuffer){for(let fe=0;fe<F.locationSize;fe++)f(F.location+fe,X.meshPerAttribute);y.isInstancedMesh!==!0&&B._maxInstanceCount===void 0&&(B._maxInstanceCount=X.meshPerAttribute*X.count)}else for(let fe=0;fe<F.locationSize;fe++)m(F.location+fe);i.bindBuffer(i.ARRAY_BUFFER,$);for(let fe=0;fe<F.locationSize;fe++)_(F.location+fe,te/F.locationSize,Z,j,re*ae,(ye+te/F.locationSize*fe)*ae,G)}else{if(z.isInstancedBufferAttribute){for(let X=0;X<F.locationSize;X++)f(F.location+X,z.meshPerAttribute);y.isInstancedMesh!==!0&&B._maxInstanceCount===void 0&&(B._maxInstanceCount=z.meshPerAttribute*z.count)}else for(let X=0;X<F.locationSize;X++)m(F.location+X);i.bindBuffer(i.ARRAY_BUFFER,$);for(let X=0;X<F.locationSize;X++)_(F.location+X,te/F.locationSize,Z,j,te*ae,te/F.locationSize*X*ae,G)}}else if(D!==void 0){const j=D[O];if(j!==void 0)switch(j.length){case 2:i.vertexAttrib2fv(F.location,j);break;case 3:i.vertexAttrib3fv(F.location,j);break;case 4:i.vertexAttrib4fv(F.location,j);break;default:i.vertexAttrib1fv(F.location,j)}}}}b()}function R(){w();for(const y in n){const T=n[y];for(const N in T){const B=T[N];for(const k in B)d(B[k].object),delete B[k];delete T[N]}delete n[y]}}function M(y){if(n[y.id]===void 0)return;const T=n[y.id];for(const N in T){const B=T[N];for(const k in B)d(B[k].object),delete B[k];delete T[N]}delete n[y.id]}function A(y){for(const T in n){const N=n[T];if(N[y.id]===void 0)continue;const B=N[y.id];for(const k in B)d(B[k].object),delete B[k];delete N[y.id]}}function w(){S(),a=!0,s!==r&&(s=r,c(s.object))}function S(){r.geometry=null,r.program=null,r.wireframe=!1}return{setup:o,reset:w,resetDefaultState:S,dispose:R,releaseStatesOfGeometry:M,releaseStatesOfProgram:A,initAttributes:v,enableAttribute:m,disableUnusedAttributes:b}}function v_(i,e,t){let n;function r(c){n=c}function s(c,d){i.drawArrays(n,c,d),t.update(d,n,1)}function a(c,d,u){u!==0&&(i.drawArraysInstanced(n,c,d,u),t.update(d,n,u))}function o(c,d,u){if(u===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,c,0,d,0,u);let p=0;for(let g=0;g<u;g++)p+=d[g];t.update(p,n,1)}function l(c,d,u,h){if(u===0)return;const p=e.get("WEBGL_multi_draw");if(p===null)for(let g=0;g<c.length;g++)a(c[g],d[g],h[g]);else{p.multiDrawArraysInstancedWEBGL(n,c,0,d,0,h,0,u);let g=0;for(let v=0;v<u;v++)g+=d[v]*h[v];t.update(g,n,1)}}this.setMode=r,this.render=s,this.renderInstances=a,this.renderMultiDraw=o,this.renderMultiDrawInstances=l}function __(i,e,t,n){let r;function s(){if(r!==void 0)return r;if(e.has("EXT_texture_filter_anisotropic")===!0){const A=e.get("EXT_texture_filter_anisotropic");r=i.getParameter(A.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else r=0;return r}function a(A){return!(A!==Rn&&n.convert(A)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_FORMAT))}function o(A){const w=A===di&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(A!==Yn&&n.convert(A)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_TYPE)&&A!==kn&&!w)}function l(A){if(A==="highp"){if(i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.HIGH_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.HIGH_FLOAT).precision>0)return"highp";A="mediump"}return A==="mediump"&&i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.MEDIUM_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let c=t.precision!==void 0?t.precision:"highp";const d=l(c);d!==c&&(console.warn("THREE.WebGLRenderer:",c,"not supported, using",d,"instead."),c=d);const u=t.logarithmicDepthBuffer===!0,h=t.reversedDepthBuffer===!0&&e.has("EXT_clip_control"),p=i.getParameter(i.MAX_TEXTURE_IMAGE_UNITS),g=i.getParameter(i.MAX_VERTEX_TEXTURE_IMAGE_UNITS),v=i.getParameter(i.MAX_TEXTURE_SIZE),m=i.getParameter(i.MAX_CUBE_MAP_TEXTURE_SIZE),f=i.getParameter(i.MAX_VERTEX_ATTRIBS),b=i.getParameter(i.MAX_VERTEX_UNIFORM_VECTORS),_=i.getParameter(i.MAX_VARYING_VECTORS),x=i.getParameter(i.MAX_FRAGMENT_UNIFORM_VECTORS),R=g>0,M=i.getParameter(i.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:s,getMaxPrecision:l,textureFormatReadable:a,textureTypeReadable:o,precision:c,logarithmicDepthBuffer:u,reversedDepthBuffer:h,maxTextures:p,maxVertexTextures:g,maxTextureSize:v,maxCubemapSize:m,maxAttributes:f,maxVertexUniforms:b,maxVaryings:_,maxFragmentUniforms:x,vertexTextures:R,maxSamples:M}}function x_(i){const e=this;let t=null,n=0,r=!1,s=!1;const a=new qi,o=new $e,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(u,h){const p=u.length!==0||h||n!==0||r;return r=h,n=u.length,p},this.beginShadows=function(){s=!0,d(null)},this.endShadows=function(){s=!1},this.setGlobalState=function(u,h){t=d(u,h,0)},this.setState=function(u,h,p){const g=u.clippingPlanes,v=u.clipIntersection,m=u.clipShadows,f=i.get(u);if(!r||g===null||g.length===0||s&&!m)s?d(null):c();else{const b=s?0:n,_=b*4;let x=f.clippingState||null;l.value=x,x=d(g,h,_,p);for(let R=0;R!==_;++R)x[R]=t[R];f.clippingState=x,this.numIntersection=v?this.numPlanes:0,this.numPlanes+=b}};function c(){l.value!==t&&(l.value=t,l.needsUpdate=n>0),e.numPlanes=n,e.numIntersection=0}function d(u,h,p,g){const v=u!==null?u.length:0;let m=null;if(v!==0){if(m=l.value,g!==!0||m===null){const f=p+v*4,b=h.matrixWorldInverse;o.getNormalMatrix(b),(m===null||m.length<f)&&(m=new Float32Array(f));for(let _=0,x=p;_!==v;++_,x+=4)a.copy(u[_]).applyMatrix4(b,o),a.normal.toArray(m,x),m[x+3]=a.constant}l.value=m,l.needsUpdate=!0}return e.numPlanes=v,e.numIntersection=0,m}}function y_(i){let e=new WeakMap;function t(a,o){return o===Ol?a.mapping=Br:o===Ul&&(a.mapping=kr),a}function n(a){if(a&&a.isTexture){const o=a.mapping;if(o===Ol||o===Ul)if(e.has(a)){const l=e.get(a).texture;return t(l,a.mapping)}else{const l=a.image;if(l&&l.height>0){const c=new Vm(l.height);return c.fromEquirectangularTexture(i,a),e.set(a,c),a.addEventListener("dispose",r),t(c.texture,a.mapping)}else return null}}return a}function r(a){const o=a.target;o.removeEventListener("dispose",r);const l=e.get(o);l!==void 0&&(e.delete(o),l.dispose())}function s(){e=new WeakMap}return{get:n,dispose:s}}const Cr=4,hd=[.125,.215,.35,.446,.526,.582],$i=20,sl=new Ws,fd=new Ie;let al=null,ol=0,ll=0,cl=!1;const Yi=(1+Math.sqrt(5))/2,Sr=1/Yi,pd=[new U(-Yi,Sr,0),new U(Yi,Sr,0),new U(-Sr,0,Yi),new U(Sr,0,Yi),new U(0,Yi,-Sr),new U(0,Yi,Sr),new U(-1,1,-1),new U(1,1,-1),new U(-1,1,1),new U(1,1,1)],b_=new U;class md{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(e,t=0,n=.1,r=100,s={}){const{size:a=256,position:o=b_}=s;al=this._renderer.getRenderTarget(),ol=this._renderer.getActiveCubeFace(),ll=this._renderer.getActiveMipmapLevel(),cl=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(a);const l=this._allocateTargets();return l.depthBuffer=!0,this._sceneToCubeUV(e,n,r,l,o),t>0&&this._blur(l,0,0,t),this._applyPMREM(l),this._cleanup(l),l}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=_d(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=vd(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodPlanes.length;e++)this._lodPlanes[e].dispose()}_cleanup(e){this._renderer.setRenderTarget(al,ol,ll),this._renderer.xr.enabled=cl,e.scissorTest=!1,Ra(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===Br||e.mapping===kr?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),al=this._renderer.getRenderTarget(),ol=this._renderer.getActiveCubeFace(),ll=this._renderer.getActiveMipmapLevel(),cl=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const n=t||this._allocateTargets();return this._textureToCubeUV(e,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,n={magFilter:Dt,minFilter:Dt,generateMipmaps:!1,type:di,format:Rn,colorSpace:en,depthBuffer:!1},r=gd(e,t,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=gd(e,t,n);const{_lodMax:s}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=S_(s)),this._blurMaterial=M_(s,e,t)}return r}_compileMaterial(e){const t=new ht(this._lodPlanes[0],e);this._renderer.compile(t,sl)}_sceneToCubeUV(e,t,n,r,s){const l=new Kt(90,1,t,n),c=[1,-1,1,1,1,1],d=[1,1,1,-1,-1,-1],u=this._renderer,h=u.autoClear,p=u.toneMapping;u.getClearColor(fd),u.toneMapping=Pi,u.autoClear=!1,u.state.buffers.depth.getReversed()&&(u.setRenderTarget(r),u.clearDepth(),u.setRenderTarget(null));const v=new Ut({name:"PMREM.Background",side:cn,depthWrite:!1,depthTest:!1}),m=new ht(new zs,v);let f=!1;const b=e.background;b?b.isColor&&(v.color.copy(b),e.background=null,f=!0):(v.color.copy(fd),f=!0);for(let _=0;_<6;_++){const x=_%3;x===0?(l.up.set(0,c[_],0),l.position.set(s.x,s.y,s.z),l.lookAt(s.x+d[_],s.y,s.z)):x===1?(l.up.set(0,0,c[_]),l.position.set(s.x,s.y,s.z),l.lookAt(s.x,s.y+d[_],s.z)):(l.up.set(0,c[_],0),l.position.set(s.x,s.y,s.z),l.lookAt(s.x,s.y,s.z+d[_]));const R=this._cubeSize;Ra(r,x*R,_>2?R:0,R,R),u.setRenderTarget(r),f&&u.render(m,l),u.render(e,l)}m.geometry.dispose(),m.material.dispose(),u.toneMapping=p,u.autoClear=h,e.background=b}_textureToCubeUV(e,t){const n=this._renderer,r=e.mapping===Br||e.mapping===kr;r?(this._cubemapMaterial===null&&(this._cubemapMaterial=_d()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=vd());const s=r?this._cubemapMaterial:this._equirectMaterial,a=new ht(this._lodPlanes[0],s),o=s.uniforms;o.envMap.value=e;const l=this._cubeSize;Ra(t,0,0,3*l,2*l),n.setRenderTarget(t),n.render(a,sl)}_applyPMREM(e){const t=this._renderer,n=t.autoClear;t.autoClear=!1;const r=this._lodPlanes.length;for(let s=1;s<r;s++){const a=Math.sqrt(this._sigmas[s]*this._sigmas[s]-this._sigmas[s-1]*this._sigmas[s-1]),o=pd[(r-s-1)%pd.length];this._blur(e,s-1,s,a,o)}t.autoClear=n}_blur(e,t,n,r,s){const a=this._pingPongRenderTarget;this._halfBlur(e,a,t,n,r,"latitudinal",s),this._halfBlur(a,e,n,n,r,"longitudinal",s)}_halfBlur(e,t,n,r,s,a,o){const l=this._renderer,c=this._blurMaterial;a!=="latitudinal"&&a!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");const d=3,u=new ht(this._lodPlanes[r],c),h=c.uniforms,p=this._sizeLods[n]-1,g=isFinite(s)?Math.PI/(2*p):2*Math.PI/(2*$i-1),v=s/g,m=isFinite(s)?1+Math.floor(d*v):$i;m>$i&&console.warn(`sigmaRadians, ${s}, is too large and will clip, as it requested ${m} samples when the maximum is set to ${$i}`);const f=[];let b=0;for(let A=0;A<$i;++A){const w=A/v,S=Math.exp(-w*w/2);f.push(S),A===0?b+=S:A<m&&(b+=2*S)}for(let A=0;A<f.length;A++)f[A]=f[A]/b;h.envMap.value=e.texture,h.samples.value=m,h.weights.value=f,h.latitudinal.value=a==="latitudinal",o&&(h.poleAxis.value=o);const{_lodMax:_}=this;h.dTheta.value=g,h.mipInt.value=_-n;const x=this._sizeLods[r],R=3*x*(r>_-Cr?r-_+Cr:0),M=4*(this._cubeSize-x);Ra(t,R,M,3*x,2*x),l.setRenderTarget(t),l.render(u,sl)}}function S_(i){const e=[],t=[],n=[];let r=i;const s=i-Cr+1+hd.length;for(let a=0;a<s;a++){const o=Math.pow(2,r);t.push(o);let l=1/o;a>i-Cr?l=hd[a-i+Cr-1]:a===0&&(l=0),n.push(l);const c=1/(o-2),d=-c,u=1+c,h=[d,d,u,d,u,u,d,d,u,u,d,u],p=6,g=6,v=3,m=2,f=1,b=new Float32Array(v*g*p),_=new Float32Array(m*g*p),x=new Float32Array(f*g*p);for(let M=0;M<p;M++){const A=M%3*2/3-1,w=M>2?0:-1,S=[A,w,0,A+2/3,w,0,A+2/3,w+1,0,A,w,0,A+2/3,w+1,0,A,w+1,0];b.set(S,v*g*M),_.set(h,m*g*M);const y=[M,M,M,M,M,M];x.set(y,f*g*M)}const R=new Lt;R.setAttribute("position",new ct(b,v)),R.setAttribute("uv",new ct(_,m)),R.setAttribute("faceIndex",new ct(x,f)),e.push(R),r>Cr&&r--}return{lodPlanes:e,sizeLods:t,sigmas:n}}function gd(i,e,t){const n=new Vn(i,e,t);return n.texture.mapping=ao,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function Ra(i,e,t,n,r){i.viewport.set(e,t,n,r),i.scissor.set(e,t,n,r)}function M_(i,e,t){const n=new Float32Array($i),r=new U(0,1,0);return new wt({name:"SphericalGaussianBlur",defines:{n:$i,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${i}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:r}},vertexShader:Jc(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:ui,depthTest:!1,depthWrite:!1})}function vd(){return new wt({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Jc(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:ui,depthTest:!1,depthWrite:!1})}function _d(){return new wt({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Jc(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:ui,depthTest:!1,depthWrite:!1})}function Jc(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function E_(i){let e=new WeakMap,t=null;function n(o){if(o&&o.isTexture){const l=o.mapping,c=l===Ol||l===Ul,d=l===Br||l===kr;if(c||d){let u=e.get(o);const h=u!==void 0?u.texture.pmremVersion:0;if(o.isRenderTargetTexture&&o.pmremVersion!==h)return t===null&&(t=new md(i)),u=c?t.fromEquirectangular(o,u):t.fromCubemap(o,u),u.texture.pmremVersion=o.pmremVersion,e.set(o,u),u.texture;if(u!==void 0)return u.texture;{const p=o.image;return c&&p&&p.height>0||d&&p&&r(p)?(t===null&&(t=new md(i)),u=c?t.fromEquirectangular(o):t.fromCubemap(o),u.texture.pmremVersion=o.pmremVersion,e.set(o,u),o.addEventListener("dispose",s),u.texture):null}}}return o}function r(o){let l=0;const c=6;for(let d=0;d<c;d++)o[d]!==void 0&&l++;return l===c}function s(o){const l=o.target;l.removeEventListener("dispose",s);const c=e.get(l);c!==void 0&&(e.delete(l),c.dispose())}function a(){e=new WeakMap,t!==null&&(t.dispose(),t=null)}return{get:n,dispose:a}}function T_(i){const e={};function t(n){if(e[n]!==void 0)return e[n];let r;switch(n){case"WEBGL_depth_texture":r=i.getExtension("WEBGL_depth_texture")||i.getExtension("MOZ_WEBGL_depth_texture")||i.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":r=i.getExtension("EXT_texture_filter_anisotropic")||i.getExtension("MOZ_EXT_texture_filter_anisotropic")||i.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":r=i.getExtension("WEBGL_compressed_texture_s3tc")||i.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":r=i.getExtension("WEBGL_compressed_texture_pvrtc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:r=i.getExtension(n)}return e[n]=r,r}return{has:function(n){return t(n)!==null},init:function(){t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance"),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture"),t("WEBGL_render_shared_exponent")},get:function(n){const r=t(n);return r===null&&Os("THREE.WebGLRenderer: "+n+" extension not supported."),r}}}function A_(i,e,t,n){const r={},s=new WeakMap;function a(u){const h=u.target;h.index!==null&&e.remove(h.index);for(const g in h.attributes)e.remove(h.attributes[g]);h.removeEventListener("dispose",a),delete r[h.id];const p=s.get(h);p&&(e.remove(p),s.delete(h)),n.releaseStatesOfGeometry(h),h.isInstancedBufferGeometry===!0&&delete h._maxInstanceCount,t.memory.geometries--}function o(u,h){return r[h.id]===!0||(h.addEventListener("dispose",a),r[h.id]=!0,t.memory.geometries++),h}function l(u){const h=u.attributes;for(const p in h)e.update(h[p],i.ARRAY_BUFFER)}function c(u){const h=[],p=u.index,g=u.attributes.position;let v=0;if(p!==null){const b=p.array;v=p.version;for(let _=0,x=b.length;_<x;_+=3){const R=b[_+0],M=b[_+1],A=b[_+2];h.push(R,M,M,A,A,R)}}else if(g!==void 0){const b=g.array;v=g.version;for(let _=0,x=b.length/3-1;_<x;_+=3){const R=_+0,M=_+1,A=_+2;h.push(R,M,M,A,A,R)}}else return;const m=new(Jh(h)?tf:oo)(h,1);m.version=v;const f=s.get(u);f&&e.remove(f),s.set(u,m)}function d(u){const h=s.get(u);if(h){const p=u.index;p!==null&&h.version<p.version&&c(u)}else c(u);return s.get(u)}return{get:o,update:l,getWireframeAttribute:d}}function w_(i,e,t){let n;function r(h){n=h}let s,a;function o(h){s=h.type,a=h.bytesPerElement}function l(h,p){i.drawElements(n,p,s,h*a),t.update(p,n,1)}function c(h,p,g){g!==0&&(i.drawElementsInstanced(n,p,s,h*a,g),t.update(p,n,g))}function d(h,p,g){if(g===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,p,0,s,h,0,g);let m=0;for(let f=0;f<g;f++)m+=p[f];t.update(m,n,1)}function u(h,p,g,v){if(g===0)return;const m=e.get("WEBGL_multi_draw");if(m===null)for(let f=0;f<h.length;f++)c(h[f]/a,p[f],v[f]);else{m.multiDrawElementsInstancedWEBGL(n,p,0,s,h,0,v,0,g);let f=0;for(let b=0;b<g;b++)f+=p[b]*v[b];t.update(f,n,1)}}this.setMode=r,this.setIndex=o,this.render=l,this.renderInstances=c,this.renderMultiDraw=d,this.renderMultiDrawInstances=u}function R_(i){const e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function n(s,a,o){switch(t.calls++,a){case i.TRIANGLES:t.triangles+=o*(s/3);break;case i.LINES:t.lines+=o*(s/2);break;case i.LINE_STRIP:t.lines+=o*(s-1);break;case i.LINE_LOOP:t.lines+=o*s;break;case i.POINTS:t.points+=o*s;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",a);break}}function r(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:r,update:n}}function C_(i,e,t){const n=new WeakMap,r=new rt;function s(a,o,l){const c=a.morphTargetInfluences,d=o.morphAttributes.position||o.morphAttributes.normal||o.morphAttributes.color,u=d!==void 0?d.length:0;let h=n.get(o);if(h===void 0||h.count!==u){let S=function(){A.dispose(),n.delete(o),o.removeEventListener("dispose",S)};h!==void 0&&h.texture.dispose();const p=o.morphAttributes.position!==void 0,g=o.morphAttributes.normal!==void 0,v=o.morphAttributes.color!==void 0,m=o.morphAttributes.position||[],f=o.morphAttributes.normal||[],b=o.morphAttributes.color||[];let _=0;p===!0&&(_=1),g===!0&&(_=2),v===!0&&(_=3);let x=o.attributes.position.count*_,R=1;x>e.maxTextureSize&&(R=Math.ceil(x/e.maxTextureSize),x=e.maxTextureSize);const M=new Float32Array(x*R*4*u),A=new Qh(M,x,R,u);A.type=kn,A.needsUpdate=!0;const w=_*4;for(let y=0;y<u;y++){const T=m[y],N=f[y],B=b[y],k=x*R*4*y;for(let V=0;V<T.count;V++){const D=V*w;p===!0&&(r.fromBufferAttribute(T,V),M[k+D+0]=r.x,M[k+D+1]=r.y,M[k+D+2]=r.z,M[k+D+3]=0),g===!0&&(r.fromBufferAttribute(N,V),M[k+D+4]=r.x,M[k+D+5]=r.y,M[k+D+6]=r.z,M[k+D+7]=0),v===!0&&(r.fromBufferAttribute(B,V),M[k+D+8]=r.x,M[k+D+9]=r.y,M[k+D+10]=r.z,M[k+D+11]=B.itemSize===4?r.w:1)}}h={count:u,texture:A,size:new Ce(x,R)},n.set(o,h),o.addEventListener("dispose",S)}if(a.isInstancedMesh===!0&&a.morphTexture!==null)l.getUniforms().setValue(i,"morphTexture",a.morphTexture,t);else{let p=0;for(let v=0;v<c.length;v++)p+=c[v];const g=o.morphTargetsRelative?1:1-p;l.getUniforms().setValue(i,"morphTargetBaseInfluence",g),l.getUniforms().setValue(i,"morphTargetInfluences",c)}l.getUniforms().setValue(i,"morphTargetsTexture",h.texture,t),l.getUniforms().setValue(i,"morphTargetsTextureSize",h.size)}return{update:s}}function I_(i,e,t,n){let r=new WeakMap;function s(l){const c=n.render.frame,d=l.geometry,u=e.get(l,d);if(r.get(u)!==c&&(e.update(u),r.set(u,c)),l.isInstancedMesh&&(l.hasEventListener("dispose",o)===!1&&l.addEventListener("dispose",o),r.get(l)!==c&&(t.update(l.instanceMatrix,i.ARRAY_BUFFER),l.instanceColor!==null&&t.update(l.instanceColor,i.ARRAY_BUFFER),r.set(l,c))),l.isSkinnedMesh){const h=l.skeleton;r.get(h)!==c&&(h.update(),r.set(h,c))}return u}function a(){r=new WeakMap}function o(l){const c=l.target;c.removeEventListener("dispose",o),t.remove(c.instanceMatrix),c.instanceColor!==null&&t.remove(c.instanceColor)}return{update:s,dispose:a}}const xf=new Ft,xd=new hf(1,1),yf=new Qh,bf=new Tm,Sf=new sf,yd=[],bd=[],Sd=new Float32Array(16),Md=new Float32Array(9),Ed=new Float32Array(4);function is(i,e,t){const n=i[0];if(n<=0||n>0)return i;const r=e*t;let s=yd[r];if(s===void 0&&(s=new Float32Array(r),yd[r]=s),e!==0){n.toArray(s,0);for(let a=1,o=0;a!==e;++a)o+=t,i[a].toArray(s,o)}return s}function Bt(i,e){if(i.length!==e.length)return!1;for(let t=0,n=i.length;t<n;t++)if(i[t]!==e[t])return!1;return!0}function kt(i,e){for(let t=0,n=e.length;t<n;t++)i[t]=e[t]}function po(i,e){let t=bd[e];t===void 0&&(t=new Int32Array(e),bd[e]=t);for(let n=0;n!==e;++n)t[n]=i.allocateTextureUnit();return t}function P_(i,e){const t=this.cache;t[0]!==e&&(i.uniform1f(this.addr,e),t[0]=e)}function L_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Bt(t,e))return;i.uniform2fv(this.addr,e),kt(t,e)}}function D_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(i.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(Bt(t,e))return;i.uniform3fv(this.addr,e),kt(t,e)}}function N_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Bt(t,e))return;i.uniform4fv(this.addr,e),kt(t,e)}}function O_(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Bt(t,e))return;i.uniformMatrix2fv(this.addr,!1,e),kt(t,e)}else{if(Bt(t,n))return;Ed.set(n),i.uniformMatrix2fv(this.addr,!1,Ed),kt(t,n)}}function U_(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Bt(t,e))return;i.uniformMatrix3fv(this.addr,!1,e),kt(t,e)}else{if(Bt(t,n))return;Md.set(n),i.uniformMatrix3fv(this.addr,!1,Md),kt(t,n)}}function F_(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Bt(t,e))return;i.uniformMatrix4fv(this.addr,!1,e),kt(t,e)}else{if(Bt(t,n))return;Sd.set(n),i.uniformMatrix4fv(this.addr,!1,Sd),kt(t,n)}}function B_(i,e){const t=this.cache;t[0]!==e&&(i.uniform1i(this.addr,e),t[0]=e)}function k_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Bt(t,e))return;i.uniform2iv(this.addr,e),kt(t,e)}}function z_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Bt(t,e))return;i.uniform3iv(this.addr,e),kt(t,e)}}function V_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Bt(t,e))return;i.uniform4iv(this.addr,e),kt(t,e)}}function H_(i,e){const t=this.cache;t[0]!==e&&(i.uniform1ui(this.addr,e),t[0]=e)}function G_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Bt(t,e))return;i.uniform2uiv(this.addr,e),kt(t,e)}}function W_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Bt(t,e))return;i.uniform3uiv(this.addr,e),kt(t,e)}}function X_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Bt(t,e))return;i.uniform4uiv(this.addr,e),kt(t,e)}}function q_(i,e,t){const n=this.cache,r=t.allocateTextureUnit();n[0]!==r&&(i.uniform1i(this.addr,r),n[0]=r);let s;this.type===i.SAMPLER_2D_SHADOW?(xd.compareFunction=Kh,s=xd):s=xf,t.setTexture2D(e||s,r)}function Y_(i,e,t){const n=this.cache,r=t.allocateTextureUnit();n[0]!==r&&(i.uniform1i(this.addr,r),n[0]=r),t.setTexture3D(e||bf,r)}function j_(i,e,t){const n=this.cache,r=t.allocateTextureUnit();n[0]!==r&&(i.uniform1i(this.addr,r),n[0]=r),t.setTextureCube(e||Sf,r)}function $_(i,e,t){const n=this.cache,r=t.allocateTextureUnit();n[0]!==r&&(i.uniform1i(this.addr,r),n[0]=r),t.setTexture2DArray(e||yf,r)}function K_(i){switch(i){case 5126:return P_;case 35664:return L_;case 35665:return D_;case 35666:return N_;case 35674:return O_;case 35675:return U_;case 35676:return F_;case 5124:case 35670:return B_;case 35667:case 35671:return k_;case 35668:case 35672:return z_;case 35669:case 35673:return V_;case 5125:return H_;case 36294:return G_;case 36295:return W_;case 36296:return X_;case 35678:case 36198:case 36298:case 36306:case 35682:return q_;case 35679:case 36299:case 36307:return Y_;case 35680:case 36300:case 36308:case 36293:return j_;case 36289:case 36303:case 36311:case 36292:return $_}}function Z_(i,e){i.uniform1fv(this.addr,e)}function J_(i,e){const t=is(e,this.size,2);i.uniform2fv(this.addr,t)}function Q_(i,e){const t=is(e,this.size,3);i.uniform3fv(this.addr,t)}function ex(i,e){const t=is(e,this.size,4);i.uniform4fv(this.addr,t)}function tx(i,e){const t=is(e,this.size,4);i.uniformMatrix2fv(this.addr,!1,t)}function nx(i,e){const t=is(e,this.size,9);i.uniformMatrix3fv(this.addr,!1,t)}function ix(i,e){const t=is(e,this.size,16);i.uniformMatrix4fv(this.addr,!1,t)}function rx(i,e){i.uniform1iv(this.addr,e)}function sx(i,e){i.uniform2iv(this.addr,e)}function ax(i,e){i.uniform3iv(this.addr,e)}function ox(i,e){i.uniform4iv(this.addr,e)}function lx(i,e){i.uniform1uiv(this.addr,e)}function cx(i,e){i.uniform2uiv(this.addr,e)}function ux(i,e){i.uniform3uiv(this.addr,e)}function dx(i,e){i.uniform4uiv(this.addr,e)}function hx(i,e,t){const n=this.cache,r=e.length,s=po(t,r);Bt(n,s)||(i.uniform1iv(this.addr,s),kt(n,s));for(let a=0;a!==r;++a)t.setTexture2D(e[a]||xf,s[a])}function fx(i,e,t){const n=this.cache,r=e.length,s=po(t,r);Bt(n,s)||(i.uniform1iv(this.addr,s),kt(n,s));for(let a=0;a!==r;++a)t.setTexture3D(e[a]||bf,s[a])}function px(i,e,t){const n=this.cache,r=e.length,s=po(t,r);Bt(n,s)||(i.uniform1iv(this.addr,s),kt(n,s));for(let a=0;a!==r;++a)t.setTextureCube(e[a]||Sf,s[a])}function mx(i,e,t){const n=this.cache,r=e.length,s=po(t,r);Bt(n,s)||(i.uniform1iv(this.addr,s),kt(n,s));for(let a=0;a!==r;++a)t.setTexture2DArray(e[a]||yf,s[a])}function gx(i){switch(i){case 5126:return Z_;case 35664:return J_;case 35665:return Q_;case 35666:return ex;case 35674:return tx;case 35675:return nx;case 35676:return ix;case 5124:case 35670:return rx;case 35667:case 35671:return sx;case 35668:case 35672:return ax;case 35669:case 35673:return ox;case 5125:return lx;case 36294:return cx;case 36295:return ux;case 36296:return dx;case 35678:case 36198:case 36298:case 36306:case 35682:return hx;case 35679:case 36299:case 36307:return fx;case 35680:case 36300:case 36308:case 36293:return px;case 36289:case 36303:case 36311:case 36292:return mx}}class vx{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.setValue=K_(t.type)}}class _x{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=gx(t.type)}}class xx{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,n){const r=this.seq;for(let s=0,a=r.length;s!==a;++s){const o=r[s];o.setValue(e,t[o.id],n)}}}const ul=/(\w+)(\])?(\[|\.)?/g;function Td(i,e){i.seq.push(e),i.map[e.id]=e}function yx(i,e,t){const n=i.name,r=n.length;for(ul.lastIndex=0;;){const s=ul.exec(n),a=ul.lastIndex;let o=s[1];const l=s[2]==="]",c=s[3];if(l&&(o=o|0),c===void 0||c==="["&&a+2===r){Td(t,c===void 0?new vx(o,i,e):new _x(o,i,e));break}else{let u=t.map[o];u===void 0&&(u=new xx(o),Td(t,u)),t=u}}}class Va{constructor(e,t){this.seq=[],this.map={};const n=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let r=0;r<n;++r){const s=e.getActiveUniform(t,r),a=e.getUniformLocation(t,s.name);yx(s,a,this)}}setValue(e,t,n,r){const s=this.map[t];s!==void 0&&s.setValue(e,n,r)}setOptional(e,t,n){const r=t[n];r!==void 0&&this.setValue(e,n,r)}static upload(e,t,n,r){for(let s=0,a=t.length;s!==a;++s){const o=t[s],l=n[o.id];l.needsUpdate!==!1&&o.setValue(e,l.value,r)}}static seqWithValue(e,t){const n=[];for(let r=0,s=e.length;r!==s;++r){const a=e[r];a.id in t&&n.push(a)}return n}}function Ad(i,e,t){const n=i.createShader(e);return i.shaderSource(n,t),i.compileShader(n),n}const bx=37297;let Sx=0;function Mx(i,e){const t=i.split(`
`),n=[],r=Math.max(e-6,0),s=Math.min(e+6,t.length);for(let a=r;a<s;a++){const o=a+1;n.push(`${o===e?">":" "} ${o}: ${t[a]}`)}return n.join(`
`)}const wd=new $e;function Ex(i){tt._getMatrix(wd,tt.workingColorSpace,i);const e=`mat3( ${wd.elements.map(t=>t.toFixed(4))} )`;switch(tt.getTransfer(i)){case Wa:return[e,"LinearTransferOETF"];case pt:return[e,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space: ",i),[e,"LinearTransferOETF"]}}function Rd(i,e,t){const n=i.getShaderParameter(e,i.COMPILE_STATUS),s=(i.getShaderInfoLog(e)||"").trim();if(n&&s==="")return"";const a=/ERROR: 0:(\d+)/.exec(s);if(a){const o=parseInt(a[1]);return t.toUpperCase()+`

`+s+`

`+Mx(i.getShaderSource(e),o)}else return s}function Tx(i,e){const t=Ex(e);return[`vec4 ${i}( vec4 value ) {`,`	return ${t[1]}( vec4( value.rgb * ${t[0]}, value.a ) );`,"}"].join(`
`)}function Ax(i,e){let t;switch(e){case Fp:t="Linear";break;case Bp:t="Reinhard";break;case kp:t="Cineon";break;case kh:t="ACESFilmic";break;case Vp:t="AgX";break;case Hp:t="Neutral";break;case zp:t="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",e),t="Linear"}return"vec3 "+i+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}const Ca=new U;function wx(){tt.getLuminanceCoefficients(Ca);const i=Ca.x.toFixed(4),e=Ca.y.toFixed(4),t=Ca.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${i}, ${e}, ${t} );`,"	return dot( weights, rgb );","}"].join(`
`)}function Rx(i){return[i.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",i.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(Ss).join(`
`)}function Cx(i){const e=[];for(const t in i){const n=i[t];n!==!1&&e.push("#define "+t+" "+n)}return e.join(`
`)}function Ix(i,e){const t={},n=i.getProgramParameter(e,i.ACTIVE_ATTRIBUTES);for(let r=0;r<n;r++){const s=i.getActiveAttrib(e,r),a=s.name;let o=1;s.type===i.FLOAT_MAT2&&(o=2),s.type===i.FLOAT_MAT3&&(o=3),s.type===i.FLOAT_MAT4&&(o=4),t[a]={type:s.type,location:i.getAttribLocation(e,a),locationSize:o}}return t}function Ss(i){return i!==""}function Cd(i,e){const t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return i.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function Id(i,e){return i.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const Px=/^[ \t]*#include +<([\w\d./]+)>/gm;function mc(i){return i.replace(Px,Dx)}const Lx=new Map;function Dx(i,e){let t=Ze[e];if(t===void 0){const n=Lx.get(e);if(n!==void 0)t=Ze[n],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,n);else throw new Error("Can not resolve #include <"+e+">")}return mc(t)}const Nx=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Pd(i){return i.replace(Nx,Ox)}function Ox(i,e,t,n){let r="";for(let s=parseInt(e);s<parseInt(t);s++)r+=n.replace(/\[\s*i\s*\]/g,"[ "+s+" ]").replace(/UNROLLED_LOOP_INDEX/g,s);return r}function Ld(i){let e=`precision ${i.precision} float;
	precision ${i.precision} int;
	precision ${i.precision} sampler2D;
	precision ${i.precision} samplerCube;
	precision ${i.precision} sampler3D;
	precision ${i.precision} sampler2DArray;
	precision ${i.precision} sampler2DShadow;
	precision ${i.precision} samplerCubeShadow;
	precision ${i.precision} sampler2DArrayShadow;
	precision ${i.precision} isampler2D;
	precision ${i.precision} isampler3D;
	precision ${i.precision} isamplerCube;
	precision ${i.precision} isampler2DArray;
	precision ${i.precision} usampler2D;
	precision ${i.precision} usampler3D;
	precision ${i.precision} usamplerCube;
	precision ${i.precision} usampler2DArray;
	`;return i.precision==="highp"?e+=`
#define HIGH_PRECISION`:i.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:i.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}function Ux(i){let e="SHADOWMAP_TYPE_BASIC";return i.shadowMapType===Bh?e="SHADOWMAP_TYPE_PCF":i.shadowMapType===gp?e="SHADOWMAP_TYPE_PCF_SOFT":i.shadowMapType===si&&(e="SHADOWMAP_TYPE_VSM"),e}function Fx(i){let e="ENVMAP_TYPE_CUBE";if(i.envMap)switch(i.envMapMode){case Br:case kr:e="ENVMAP_TYPE_CUBE";break;case ao:e="ENVMAP_TYPE_CUBE_UV";break}return e}function Bx(i){let e="ENVMAP_MODE_REFLECTION";if(i.envMap)switch(i.envMapMode){case kr:e="ENVMAP_MODE_REFRACTION";break}return e}function kx(i){let e="ENVMAP_BLENDING_NONE";if(i.envMap)switch(i.combine){case Cc:e="ENVMAP_BLENDING_MULTIPLY";break;case Op:e="ENVMAP_BLENDING_MIX";break;case Up:e="ENVMAP_BLENDING_ADD";break}return e}function zx(i){const e=i.envMapCubeUVHeight;if(e===null)return null;const t=Math.log2(e)-2,n=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,t),112)),texelHeight:n,maxMip:t}}function Vx(i,e,t,n){const r=i.getContext(),s=t.defines;let a=t.vertexShader,o=t.fragmentShader;const l=Ux(t),c=Fx(t),d=Bx(t),u=kx(t),h=zx(t),p=Rx(t),g=Cx(s),v=r.createProgram();let m,f,b=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(m=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g].filter(Ss).join(`
`),m.length>0&&(m+=`
`),f=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g].filter(Ss).join(`
`),f.length>0&&(f+=`
`)):(m=[Ld(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.batchingColor?"#define USE_BATCHING_COLOR":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.instancingMorph?"#define USE_INSTANCING_MORPH":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+d:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Ss).join(`
`),f=[Ld(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+c:"",t.envMap?"#define "+d:"",t.envMap?"#define "+u:"",h?"#define CUBEUV_TEXEL_WIDTH "+h.texelWidth:"",h?"#define CUBEUV_TEXEL_HEIGHT "+h.texelHeight:"",h?"#define CUBEUV_MAX_MIP "+h.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.dispersion?"#define USE_DISPERSION":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor||t.batchingColor?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==Pi?"#define TONE_MAPPING":"",t.toneMapping!==Pi?Ze.tonemapping_pars_fragment:"",t.toneMapping!==Pi?Ax("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",Ze.colorspace_pars_fragment,Tx("linearToOutputTexel",t.outputColorSpace),wx(),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(Ss).join(`
`)),a=mc(a),a=Cd(a,t),a=Id(a,t),o=mc(o),o=Cd(o,t),o=Id(o,t),a=Pd(a),o=Pd(o),t.isRawShaderMaterial!==!0&&(b=`#version 300 es
`,m=[p,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+m,f=["#define varying in",t.glslVersion===Eu?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===Eu?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+f);const _=b+m+a,x=b+f+o,R=Ad(r,r.VERTEX_SHADER,_),M=Ad(r,r.FRAGMENT_SHADER,x);r.attachShader(v,R),r.attachShader(v,M),t.index0AttributeName!==void 0?r.bindAttribLocation(v,0,t.index0AttributeName):t.morphTargets===!0&&r.bindAttribLocation(v,0,"position"),r.linkProgram(v);function A(T){if(i.debug.checkShaderErrors){const N=r.getProgramInfoLog(v)||"",B=r.getShaderInfoLog(R)||"",k=r.getShaderInfoLog(M)||"",V=N.trim(),D=B.trim(),O=k.trim();let F=!0,z=!0;if(r.getProgramParameter(v,r.LINK_STATUS)===!1)if(F=!1,typeof i.debug.onShaderError=="function")i.debug.onShaderError(r,v,R,M);else{const j=Rd(r,R,"vertex"),te=Rd(r,M,"fragment");console.error("THREE.WebGLProgram: Shader Error "+r.getError()+" - VALIDATE_STATUS "+r.getProgramParameter(v,r.VALIDATE_STATUS)+`

Material Name: `+T.name+`
Material Type: `+T.type+`

Program Info Log: `+V+`
`+j+`
`+te)}else V!==""?console.warn("THREE.WebGLProgram: Program Info Log:",V):(D===""||O==="")&&(z=!1);z&&(T.diagnostics={runnable:F,programLog:V,vertexShader:{log:D,prefix:m},fragmentShader:{log:O,prefix:f}})}r.deleteShader(R),r.deleteShader(M),w=new Va(r,v),S=Ix(r,v)}let w;this.getUniforms=function(){return w===void 0&&A(this),w};let S;this.getAttributes=function(){return S===void 0&&A(this),S};let y=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return y===!1&&(y=r.getProgramParameter(v,bx)),y},this.destroy=function(){n.releaseStatesOfProgram(this),r.deleteProgram(v),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=Sx++,this.cacheKey=e,this.usedTimes=1,this.program=v,this.vertexShader=R,this.fragmentShader=M,this}let Hx=0;class Gx{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){const t=e.vertexShader,n=e.fragmentShader,r=this._getShaderStage(t),s=this._getShaderStage(n),a=this._getShaderCacheForMaterial(e);return a.has(r)===!1&&(a.add(r),r.usedTimes++),a.has(s)===!1&&(a.add(s),s.usedTimes++),this}remove(e){const t=this.materialCache.get(e);for(const n of t)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const t=this.materialCache;let n=t.get(e);return n===void 0&&(n=new Set,t.set(e,n)),n}_getShaderStage(e){const t=this.shaderCache;let n=t.get(e);return n===void 0&&(n=new Wx(e),t.set(e,n)),n}}class Wx{constructor(e){this.id=Hx++,this.code=e,this.usedTimes=0}}function Xx(i,e,t,n,r,s,a){const o=new zc,l=new Gx,c=new Set,d=[],u=r.logarithmicDepthBuffer,h=r.vertexTextures;let p=r.precision;const g={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function v(S){return c.add(S),S===0?"uv":`uv${S}`}function m(S,y,T,N,B){const k=N.fog,V=B.geometry,D=S.isMeshStandardMaterial?N.environment:null,O=(S.isMeshStandardMaterial?t:e).get(S.envMap||D),F=O&&O.mapping===ao?O.image.height:null,z=g[S.type];S.precision!==null&&(p=r.getMaxPrecision(S.precision),p!==S.precision&&console.warn("THREE.WebGLProgram.getParameters:",S.precision,"not supported, using",p,"instead."));const j=V.morphAttributes.position||V.morphAttributes.normal||V.morphAttributes.color,te=j!==void 0?j.length:0;let L=0;V.morphAttributes.position!==void 0&&(L=1),V.morphAttributes.normal!==void 0&&(L=2),V.morphAttributes.color!==void 0&&(L=3);let $,Z,ae,G;if(z){const st=Xn[z];$=st.vertexShader,Z=st.fragmentShader}else $=S.vertexShader,Z=S.fragmentShader,l.update(S),ae=l.getVertexShaderID(S),G=l.getFragmentShaderID(S);const X=i.getRenderTarget(),re=i.state.buffers.depth.getReversed(),ye=B.isInstancedMesh===!0,fe=B.isBatchedMesh===!0,we=!!S.map,me=!!S.matcap,P=!!O,Le=!!S.aoMap,Te=!!S.lightMap,ge=!!S.bumpMap,se=!!S.normalMap,ze=!!S.displacementMap,oe=!!S.emissiveMap,Se=!!S.metalnessMap,Ye=!!S.roughnessMap,De=S.anisotropy>0,I=S.clearcoat>0,E=S.dispersion>0,Y=S.iridescence>0,ee=S.sheen>0,ne=S.transmission>0,K=De&&!!S.anisotropyMap,xe=I&&!!S.clearcoatMap,le=I&&!!S.clearcoatNormalMap,Ue=I&&!!S.clearcoatRoughnessMap,Fe=Y&&!!S.iridescenceMap,de=Y&&!!S.iridescenceThicknessMap,Ae=ee&&!!S.sheenColorMap,Ge=ee&&!!S.sheenRoughnessMap,Be=!!S.specularMap,Me=!!S.specularColorMap,Ke=!!S.specularIntensityMap,H=ne&&!!S.transmissionMap,he=ne&&!!S.thicknessMap,ve=!!S.gradientMap,Pe=!!S.alphaMap,ce=S.alphaTest>0,ie=!!S.alphaHash,Oe=!!S.extensions;let je=Pi;S.toneMapped&&(X===null||X.isXRRenderTarget===!0)&&(je=i.toneMapping);const gt={shaderID:z,shaderType:S.type,shaderName:S.name,vertexShader:$,fragmentShader:Z,defines:S.defines,customVertexShaderID:ae,customFragmentShaderID:G,isRawShaderMaterial:S.isRawShaderMaterial===!0,glslVersion:S.glslVersion,precision:p,batching:fe,batchingColor:fe&&B._colorsTexture!==null,instancing:ye,instancingColor:ye&&B.instanceColor!==null,instancingMorph:ye&&B.morphTexture!==null,supportsVertexTextures:h,outputColorSpace:X===null?i.outputColorSpace:X.isXRRenderTarget===!0?X.texture.colorSpace:en,alphaToCoverage:!!S.alphaToCoverage,map:we,matcap:me,envMap:P,envMapMode:P&&O.mapping,envMapCubeUVHeight:F,aoMap:Le,lightMap:Te,bumpMap:ge,normalMap:se,displacementMap:h&&ze,emissiveMap:oe,normalMapObjectSpace:se&&S.normalMapType===jp,normalMapTangentSpace:se&&S.normalMapType===Fc,metalnessMap:Se,roughnessMap:Ye,anisotropy:De,anisotropyMap:K,clearcoat:I,clearcoatMap:xe,clearcoatNormalMap:le,clearcoatRoughnessMap:Ue,dispersion:E,iridescence:Y,iridescenceMap:Fe,iridescenceThicknessMap:de,sheen:ee,sheenColorMap:Ae,sheenRoughnessMap:Ge,specularMap:Be,specularColorMap:Me,specularIntensityMap:Ke,transmission:ne,transmissionMap:H,thicknessMap:he,gradientMap:ve,opaque:S.transparent===!1&&S.blending===Ii&&S.alphaToCoverage===!1,alphaMap:Pe,alphaTest:ce,alphaHash:ie,combine:S.combine,mapUv:we&&v(S.map.channel),aoMapUv:Le&&v(S.aoMap.channel),lightMapUv:Te&&v(S.lightMap.channel),bumpMapUv:ge&&v(S.bumpMap.channel),normalMapUv:se&&v(S.normalMap.channel),displacementMapUv:ze&&v(S.displacementMap.channel),emissiveMapUv:oe&&v(S.emissiveMap.channel),metalnessMapUv:Se&&v(S.metalnessMap.channel),roughnessMapUv:Ye&&v(S.roughnessMap.channel),anisotropyMapUv:K&&v(S.anisotropyMap.channel),clearcoatMapUv:xe&&v(S.clearcoatMap.channel),clearcoatNormalMapUv:le&&v(S.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Ue&&v(S.clearcoatRoughnessMap.channel),iridescenceMapUv:Fe&&v(S.iridescenceMap.channel),iridescenceThicknessMapUv:de&&v(S.iridescenceThicknessMap.channel),sheenColorMapUv:Ae&&v(S.sheenColorMap.channel),sheenRoughnessMapUv:Ge&&v(S.sheenRoughnessMap.channel),specularMapUv:Be&&v(S.specularMap.channel),specularColorMapUv:Me&&v(S.specularColorMap.channel),specularIntensityMapUv:Ke&&v(S.specularIntensityMap.channel),transmissionMapUv:H&&v(S.transmissionMap.channel),thicknessMapUv:he&&v(S.thicknessMap.channel),alphaMapUv:Pe&&v(S.alphaMap.channel),vertexTangents:!!V.attributes.tangent&&(se||De),vertexColors:S.vertexColors,vertexAlphas:S.vertexColors===!0&&!!V.attributes.color&&V.attributes.color.itemSize===4,pointsUvs:B.isPoints===!0&&!!V.attributes.uv&&(we||Pe),fog:!!k,useFog:S.fog===!0,fogExp2:!!k&&k.isFogExp2,flatShading:S.flatShading===!0&&S.wireframe===!1,sizeAttenuation:S.sizeAttenuation===!0,logarithmicDepthBuffer:u,reversedDepthBuffer:re,skinning:B.isSkinnedMesh===!0,morphTargets:V.morphAttributes.position!==void 0,morphNormals:V.morphAttributes.normal!==void 0,morphColors:V.morphAttributes.color!==void 0,morphTargetsCount:te,morphTextureStride:L,numDirLights:y.directional.length,numPointLights:y.point.length,numSpotLights:y.spot.length,numSpotLightMaps:y.spotLightMap.length,numRectAreaLights:y.rectArea.length,numHemiLights:y.hemi.length,numDirLightShadows:y.directionalShadowMap.length,numPointLightShadows:y.pointShadowMap.length,numSpotLightShadows:y.spotShadowMap.length,numSpotLightShadowsWithMaps:y.numSpotLightShadowsWithMaps,numLightProbes:y.numLightProbes,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:S.dithering,shadowMapEnabled:i.shadowMap.enabled&&T.length>0,shadowMapType:i.shadowMap.type,toneMapping:je,decodeVideoTexture:we&&S.map.isVideoTexture===!0&&tt.getTransfer(S.map.colorSpace)===pt,decodeVideoTextureEmissive:oe&&S.emissiveMap.isVideoTexture===!0&&tt.getTransfer(S.emissiveMap.colorSpace)===pt,premultipliedAlpha:S.premultipliedAlpha,doubleSided:S.side===Et,flipSided:S.side===cn,useDepthPacking:S.depthPacking>=0,depthPacking:S.depthPacking||0,index0AttributeName:S.index0AttributeName,extensionClipCullDistance:Oe&&S.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Oe&&S.extensions.multiDraw===!0||fe)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:S.customProgramCacheKey()};return gt.vertexUv1s=c.has(1),gt.vertexUv2s=c.has(2),gt.vertexUv3s=c.has(3),c.clear(),gt}function f(S){const y=[];if(S.shaderID?y.push(S.shaderID):(y.push(S.customVertexShaderID),y.push(S.customFragmentShaderID)),S.defines!==void 0)for(const T in S.defines)y.push(T),y.push(S.defines[T]);return S.isRawShaderMaterial===!1&&(b(y,S),_(y,S),y.push(i.outputColorSpace)),y.push(S.customProgramCacheKey),y.join()}function b(S,y){S.push(y.precision),S.push(y.outputColorSpace),S.push(y.envMapMode),S.push(y.envMapCubeUVHeight),S.push(y.mapUv),S.push(y.alphaMapUv),S.push(y.lightMapUv),S.push(y.aoMapUv),S.push(y.bumpMapUv),S.push(y.normalMapUv),S.push(y.displacementMapUv),S.push(y.emissiveMapUv),S.push(y.metalnessMapUv),S.push(y.roughnessMapUv),S.push(y.anisotropyMapUv),S.push(y.clearcoatMapUv),S.push(y.clearcoatNormalMapUv),S.push(y.clearcoatRoughnessMapUv),S.push(y.iridescenceMapUv),S.push(y.iridescenceThicknessMapUv),S.push(y.sheenColorMapUv),S.push(y.sheenRoughnessMapUv),S.push(y.specularMapUv),S.push(y.specularColorMapUv),S.push(y.specularIntensityMapUv),S.push(y.transmissionMapUv),S.push(y.thicknessMapUv),S.push(y.combine),S.push(y.fogExp2),S.push(y.sizeAttenuation),S.push(y.morphTargetsCount),S.push(y.morphAttributeCount),S.push(y.numDirLights),S.push(y.numPointLights),S.push(y.numSpotLights),S.push(y.numSpotLightMaps),S.push(y.numHemiLights),S.push(y.numRectAreaLights),S.push(y.numDirLightShadows),S.push(y.numPointLightShadows),S.push(y.numSpotLightShadows),S.push(y.numSpotLightShadowsWithMaps),S.push(y.numLightProbes),S.push(y.shadowMapType),S.push(y.toneMapping),S.push(y.numClippingPlanes),S.push(y.numClipIntersection),S.push(y.depthPacking)}function _(S,y){o.disableAll(),y.supportsVertexTextures&&o.enable(0),y.instancing&&o.enable(1),y.instancingColor&&o.enable(2),y.instancingMorph&&o.enable(3),y.matcap&&o.enable(4),y.envMap&&o.enable(5),y.normalMapObjectSpace&&o.enable(6),y.normalMapTangentSpace&&o.enable(7),y.clearcoat&&o.enable(8),y.iridescence&&o.enable(9),y.alphaTest&&o.enable(10),y.vertexColors&&o.enable(11),y.vertexAlphas&&o.enable(12),y.vertexUv1s&&o.enable(13),y.vertexUv2s&&o.enable(14),y.vertexUv3s&&o.enable(15),y.vertexTangents&&o.enable(16),y.anisotropy&&o.enable(17),y.alphaHash&&o.enable(18),y.batching&&o.enable(19),y.dispersion&&o.enable(20),y.batchingColor&&o.enable(21),y.gradientMap&&o.enable(22),S.push(o.mask),o.disableAll(),y.fog&&o.enable(0),y.useFog&&o.enable(1),y.flatShading&&o.enable(2),y.logarithmicDepthBuffer&&o.enable(3),y.reversedDepthBuffer&&o.enable(4),y.skinning&&o.enable(5),y.morphTargets&&o.enable(6),y.morphNormals&&o.enable(7),y.morphColors&&o.enable(8),y.premultipliedAlpha&&o.enable(9),y.shadowMapEnabled&&o.enable(10),y.doubleSided&&o.enable(11),y.flipSided&&o.enable(12),y.useDepthPacking&&o.enable(13),y.dithering&&o.enable(14),y.transmission&&o.enable(15),y.sheen&&o.enable(16),y.opaque&&o.enable(17),y.pointsUvs&&o.enable(18),y.decodeVideoTexture&&o.enable(19),y.decodeVideoTextureEmissive&&o.enable(20),y.alphaToCoverage&&o.enable(21),S.push(o.mask)}function x(S){const y=g[S.type];let T;if(y){const N=Xn[y];T=qa.clone(N.uniforms)}else T=S.uniforms;return T}function R(S,y){let T;for(let N=0,B=d.length;N<B;N++){const k=d[N];if(k.cacheKey===y){T=k,++T.usedTimes;break}}return T===void 0&&(T=new Vx(i,y,S,s),d.push(T)),T}function M(S){if(--S.usedTimes===0){const y=d.indexOf(S);d[y]=d[d.length-1],d.pop(),S.destroy()}}function A(S){l.remove(S)}function w(){l.dispose()}return{getParameters:m,getProgramCacheKey:f,getUniforms:x,acquireProgram:R,releaseProgram:M,releaseShaderCache:A,programs:d,dispose:w}}function qx(){let i=new WeakMap;function e(a){return i.has(a)}function t(a){let o=i.get(a);return o===void 0&&(o={},i.set(a,o)),o}function n(a){i.delete(a)}function r(a,o,l){i.get(a)[o]=l}function s(){i=new WeakMap}return{has:e,get:t,remove:n,update:r,dispose:s}}function Yx(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.material.id!==e.material.id?i.material.id-e.material.id:i.z!==e.z?i.z-e.z:i.id-e.id}function Dd(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.z!==e.z?e.z-i.z:i.id-e.id}function Nd(){const i=[];let e=0;const t=[],n=[],r=[];function s(){e=0,t.length=0,n.length=0,r.length=0}function a(u,h,p,g,v,m){let f=i[e];return f===void 0?(f={id:u.id,object:u,geometry:h,material:p,groupOrder:g,renderOrder:u.renderOrder,z:v,group:m},i[e]=f):(f.id=u.id,f.object=u,f.geometry=h,f.material=p,f.groupOrder=g,f.renderOrder=u.renderOrder,f.z=v,f.group=m),e++,f}function o(u,h,p,g,v,m){const f=a(u,h,p,g,v,m);p.transmission>0?n.push(f):p.transparent===!0?r.push(f):t.push(f)}function l(u,h,p,g,v,m){const f=a(u,h,p,g,v,m);p.transmission>0?n.unshift(f):p.transparent===!0?r.unshift(f):t.unshift(f)}function c(u,h){t.length>1&&t.sort(u||Yx),n.length>1&&n.sort(h||Dd),r.length>1&&r.sort(h||Dd)}function d(){for(let u=e,h=i.length;u<h;u++){const p=i[u];if(p.id===null)break;p.id=null,p.object=null,p.geometry=null,p.material=null,p.group=null}}return{opaque:t,transmissive:n,transparent:r,init:s,push:o,unshift:l,finish:d,sort:c}}function jx(){let i=new WeakMap;function e(n,r){const s=i.get(n);let a;return s===void 0?(a=new Nd,i.set(n,[a])):r>=s.length?(a=new Nd,s.push(a)):a=s[r],a}function t(){i=new WeakMap}return{get:e,dispose:t}}function $x(){const i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"DirectionalLight":t={direction:new U,color:new Ie};break;case"SpotLight":t={position:new U,direction:new U,color:new Ie,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new U,color:new Ie,distance:0,decay:0};break;case"HemisphereLight":t={direction:new U,skyColor:new Ie,groundColor:new Ie};break;case"RectAreaLight":t={color:new Ie,position:new U,halfWidth:new U,halfHeight:new U};break}return i[e.id]=t,t}}}function Kx(){const i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"DirectionalLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ce};break;case"SpotLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ce};break;case"PointLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ce,shadowCameraNear:1,shadowCameraFar:1e3};break}return i[e.id]=t,t}}}let Zx=0;function Jx(i,e){return(e.castShadow?2:0)-(i.castShadow?2:0)+(e.map?1:0)-(i.map?1:0)}function Qx(i){const e=new $x,t=Kx(),n={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let c=0;c<9;c++)n.probe.push(new U);const r=new U,s=new qe,a=new qe;function o(c){let d=0,u=0,h=0;for(let S=0;S<9;S++)n.probe[S].set(0,0,0);let p=0,g=0,v=0,m=0,f=0,b=0,_=0,x=0,R=0,M=0,A=0;c.sort(Jx);for(let S=0,y=c.length;S<y;S++){const T=c[S],N=T.color,B=T.intensity,k=T.distance,V=T.shadow&&T.shadow.map?T.shadow.map.texture:null;if(T.isAmbientLight)d+=N.r*B,u+=N.g*B,h+=N.b*B;else if(T.isLightProbe){for(let D=0;D<9;D++)n.probe[D].addScaledVector(T.sh.coefficients[D],B);A++}else if(T.isDirectionalLight){const D=e.get(T);if(D.color.copy(T.color).multiplyScalar(T.intensity),T.castShadow){const O=T.shadow,F=t.get(T);F.shadowIntensity=O.intensity,F.shadowBias=O.bias,F.shadowNormalBias=O.normalBias,F.shadowRadius=O.radius,F.shadowMapSize=O.mapSize,n.directionalShadow[p]=F,n.directionalShadowMap[p]=V,n.directionalShadowMatrix[p]=T.shadow.matrix,b++}n.directional[p]=D,p++}else if(T.isSpotLight){const D=e.get(T);D.position.setFromMatrixPosition(T.matrixWorld),D.color.copy(N).multiplyScalar(B),D.distance=k,D.coneCos=Math.cos(T.angle),D.penumbraCos=Math.cos(T.angle*(1-T.penumbra)),D.decay=T.decay,n.spot[v]=D;const O=T.shadow;if(T.map&&(n.spotLightMap[R]=T.map,R++,O.updateMatrices(T),T.castShadow&&M++),n.spotLightMatrix[v]=O.matrix,T.castShadow){const F=t.get(T);F.shadowIntensity=O.intensity,F.shadowBias=O.bias,F.shadowNormalBias=O.normalBias,F.shadowRadius=O.radius,F.shadowMapSize=O.mapSize,n.spotShadow[v]=F,n.spotShadowMap[v]=V,x++}v++}else if(T.isRectAreaLight){const D=e.get(T);D.color.copy(N).multiplyScalar(B),D.halfWidth.set(T.width*.5,0,0),D.halfHeight.set(0,T.height*.5,0),n.rectArea[m]=D,m++}else if(T.isPointLight){const D=e.get(T);if(D.color.copy(T.color).multiplyScalar(T.intensity),D.distance=T.distance,D.decay=T.decay,T.castShadow){const O=T.shadow,F=t.get(T);F.shadowIntensity=O.intensity,F.shadowBias=O.bias,F.shadowNormalBias=O.normalBias,F.shadowRadius=O.radius,F.shadowMapSize=O.mapSize,F.shadowCameraNear=O.camera.near,F.shadowCameraFar=O.camera.far,n.pointShadow[g]=F,n.pointShadowMap[g]=V,n.pointShadowMatrix[g]=T.shadow.matrix,_++}n.point[g]=D,g++}else if(T.isHemisphereLight){const D=e.get(T);D.skyColor.copy(T.color).multiplyScalar(B),D.groundColor.copy(T.groundColor).multiplyScalar(B),n.hemi[f]=D,f++}}m>0&&(i.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=be.LTC_FLOAT_1,n.rectAreaLTC2=be.LTC_FLOAT_2):(n.rectAreaLTC1=be.LTC_HALF_1,n.rectAreaLTC2=be.LTC_HALF_2)),n.ambient[0]=d,n.ambient[1]=u,n.ambient[2]=h;const w=n.hash;(w.directionalLength!==p||w.pointLength!==g||w.spotLength!==v||w.rectAreaLength!==m||w.hemiLength!==f||w.numDirectionalShadows!==b||w.numPointShadows!==_||w.numSpotShadows!==x||w.numSpotMaps!==R||w.numLightProbes!==A)&&(n.directional.length=p,n.spot.length=v,n.rectArea.length=m,n.point.length=g,n.hemi.length=f,n.directionalShadow.length=b,n.directionalShadowMap.length=b,n.pointShadow.length=_,n.pointShadowMap.length=_,n.spotShadow.length=x,n.spotShadowMap.length=x,n.directionalShadowMatrix.length=b,n.pointShadowMatrix.length=_,n.spotLightMatrix.length=x+R-M,n.spotLightMap.length=R,n.numSpotLightShadowsWithMaps=M,n.numLightProbes=A,w.directionalLength=p,w.pointLength=g,w.spotLength=v,w.rectAreaLength=m,w.hemiLength=f,w.numDirectionalShadows=b,w.numPointShadows=_,w.numSpotShadows=x,w.numSpotMaps=R,w.numLightProbes=A,n.version=Zx++)}function l(c,d){let u=0,h=0,p=0,g=0,v=0;const m=d.matrixWorldInverse;for(let f=0,b=c.length;f<b;f++){const _=c[f];if(_.isDirectionalLight){const x=n.directional[u];x.direction.setFromMatrixPosition(_.matrixWorld),r.setFromMatrixPosition(_.target.matrixWorld),x.direction.sub(r),x.direction.transformDirection(m),u++}else if(_.isSpotLight){const x=n.spot[p];x.position.setFromMatrixPosition(_.matrixWorld),x.position.applyMatrix4(m),x.direction.setFromMatrixPosition(_.matrixWorld),r.setFromMatrixPosition(_.target.matrixWorld),x.direction.sub(r),x.direction.transformDirection(m),p++}else if(_.isRectAreaLight){const x=n.rectArea[g];x.position.setFromMatrixPosition(_.matrixWorld),x.position.applyMatrix4(m),a.identity(),s.copy(_.matrixWorld),s.premultiply(m),a.extractRotation(s),x.halfWidth.set(_.width*.5,0,0),x.halfHeight.set(0,_.height*.5,0),x.halfWidth.applyMatrix4(a),x.halfHeight.applyMatrix4(a),g++}else if(_.isPointLight){const x=n.point[h];x.position.setFromMatrixPosition(_.matrixWorld),x.position.applyMatrix4(m),h++}else if(_.isHemisphereLight){const x=n.hemi[v];x.direction.setFromMatrixPosition(_.matrixWorld),x.direction.transformDirection(m),v++}}}return{setup:o,setupView:l,state:n}}function Od(i){const e=new Qx(i),t=[],n=[];function r(d){c.camera=d,t.length=0,n.length=0}function s(d){t.push(d)}function a(d){n.push(d)}function o(){e.setup(t)}function l(d){e.setupView(t,d)}const c={lightsArray:t,shadowsArray:n,camera:null,lights:e,transmissionRenderTarget:{}};return{init:r,state:c,setupLights:o,setupLightsView:l,pushLight:s,pushShadow:a}}function ey(i){let e=new WeakMap;function t(r,s=0){const a=e.get(r);let o;return a===void 0?(o=new Od(i),e.set(r,[o])):s>=a.length?(o=new Od(i),a.push(o)):o=a[s],o}function n(){e=new WeakMap}return{get:t,dispose:n}}const ty=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,ny=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function iy(i,e,t){let n=new Hc;const r=new Ce,s=new Ce,a=new rt,o=new Jm({depthPacking:Yp}),l=new Qm,c={},d=t.maxTextureSize,u={[fi]:cn,[cn]:fi,[Et]:Et},h=new wt({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Ce},radius:{value:4}},vertexShader:ty,fragmentShader:ny}),p=h.clone();p.defines.HORIZONTAL_PASS=1;const g=new Lt;g.setAttribute("position",new ct(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const v=new ht(g,h),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Bh;let f=this.type;this.render=function(M,A,w){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||M.length===0)return;const S=i.getRenderTarget(),y=i.getActiveCubeFace(),T=i.getActiveMipmapLevel(),N=i.state;N.setBlending(ui),N.buffers.depth.getReversed()===!0?N.buffers.color.setClear(0,0,0,0):N.buffers.color.setClear(1,1,1,1),N.buffers.depth.setTest(!0),N.setScissorTest(!1);const B=f!==si&&this.type===si,k=f===si&&this.type!==si;for(let V=0,D=M.length;V<D;V++){const O=M[V],F=O.shadow;if(F===void 0){console.warn("THREE.WebGLShadowMap:",O,"has no shadow.");continue}if(F.autoUpdate===!1&&F.needsUpdate===!1)continue;r.copy(F.mapSize);const z=F.getFrameExtents();if(r.multiply(z),s.copy(F.mapSize),(r.x>d||r.y>d)&&(r.x>d&&(s.x=Math.floor(d/z.x),r.x=s.x*z.x,F.mapSize.x=s.x),r.y>d&&(s.y=Math.floor(d/z.y),r.y=s.y*z.y,F.mapSize.y=s.y)),F.map===null||B===!0||k===!0){const te=this.type!==si?{minFilter:Jt,magFilter:Jt}:{};F.map!==null&&F.map.dispose(),F.map=new Vn(r.x,r.y,te),F.map.texture.name=O.name+".shadowMap",F.camera.updateProjectionMatrix()}i.setRenderTarget(F.map),i.clear();const j=F.getViewportCount();for(let te=0;te<j;te++){const L=F.getViewport(te);a.set(s.x*L.x,s.y*L.y,s.x*L.z,s.y*L.w),N.viewport(a),F.updateMatrices(O,te),n=F.getFrustum(),x(A,w,F.camera,O,this.type)}F.isPointLightShadow!==!0&&this.type===si&&b(F,w),F.needsUpdate=!1}f=this.type,m.needsUpdate=!1,i.setRenderTarget(S,y,T)};function b(M,A){const w=e.update(v);h.defines.VSM_SAMPLES!==M.blurSamples&&(h.defines.VSM_SAMPLES=M.blurSamples,p.defines.VSM_SAMPLES=M.blurSamples,h.needsUpdate=!0,p.needsUpdate=!0),M.mapPass===null&&(M.mapPass=new Vn(r.x,r.y)),h.uniforms.shadow_pass.value=M.map.texture,h.uniforms.resolution.value=M.mapSize,h.uniforms.radius.value=M.radius,i.setRenderTarget(M.mapPass),i.clear(),i.renderBufferDirect(A,null,w,h,v,null),p.uniforms.shadow_pass.value=M.mapPass.texture,p.uniforms.resolution.value=M.mapSize,p.uniforms.radius.value=M.radius,i.setRenderTarget(M.map),i.clear(),i.renderBufferDirect(A,null,w,p,v,null)}function _(M,A,w,S){let y=null;const T=w.isPointLight===!0?M.customDistanceMaterial:M.customDepthMaterial;if(T!==void 0)y=T;else if(y=w.isPointLight===!0?l:o,i.localClippingEnabled&&A.clipShadows===!0&&Array.isArray(A.clippingPlanes)&&A.clippingPlanes.length!==0||A.displacementMap&&A.displacementScale!==0||A.alphaMap&&A.alphaTest>0||A.map&&A.alphaTest>0||A.alphaToCoverage===!0){const N=y.uuid,B=A.uuid;let k=c[N];k===void 0&&(k={},c[N]=k);let V=k[B];V===void 0&&(V=y.clone(),k[B]=V,A.addEventListener("dispose",R)),y=V}if(y.visible=A.visible,y.wireframe=A.wireframe,S===si?y.side=A.shadowSide!==null?A.shadowSide:A.side:y.side=A.shadowSide!==null?A.shadowSide:u[A.side],y.alphaMap=A.alphaMap,y.alphaTest=A.alphaToCoverage===!0?.5:A.alphaTest,y.map=A.map,y.clipShadows=A.clipShadows,y.clippingPlanes=A.clippingPlanes,y.clipIntersection=A.clipIntersection,y.displacementMap=A.displacementMap,y.displacementScale=A.displacementScale,y.displacementBias=A.displacementBias,y.wireframeLinewidth=A.wireframeLinewidth,y.linewidth=A.linewidth,w.isPointLight===!0&&y.isMeshDistanceMaterial===!0){const N=i.properties.get(y);N.light=w}return y}function x(M,A,w,S,y){if(M.visible===!1)return;if(M.layers.test(A.layers)&&(M.isMesh||M.isLine||M.isPoints)&&(M.castShadow||M.receiveShadow&&y===si)&&(!M.frustumCulled||n.intersectsObject(M))){M.modelViewMatrix.multiplyMatrices(w.matrixWorldInverse,M.matrixWorld);const B=e.update(M),k=M.material;if(Array.isArray(k)){const V=B.groups;for(let D=0,O=V.length;D<O;D++){const F=V[D],z=k[F.materialIndex];if(z&&z.visible){const j=_(M,z,S,y);M.onBeforeShadow(i,M,A,w,B,j,F),i.renderBufferDirect(w,null,B,j,M,F),M.onAfterShadow(i,M,A,w,B,j,F)}}}else if(k.visible){const V=_(M,k,S,y);M.onBeforeShadow(i,M,A,w,B,V,null),i.renderBufferDirect(w,null,B,V,M,null),M.onAfterShadow(i,M,A,w,B,V,null)}}const N=M.children;for(let B=0,k=N.length;B<k;B++)x(N[B],A,w,S,y)}function R(M){M.target.removeEventListener("dispose",R);for(const w in c){const S=c[w],y=M.target.uuid;y in S&&(S[y].dispose(),delete S[y])}}}const ry={[Rl]:Cl,[Il]:Dl,[Pl]:Nl,[Fr]:Ll,[Cl]:Rl,[Dl]:Il,[Nl]:Pl,[Ll]:Fr};function sy(i,e){function t(){let H=!1;const he=new rt;let ve=null;const Pe=new rt(0,0,0,0);return{setMask:function(ce){ve!==ce&&!H&&(i.colorMask(ce,ce,ce,ce),ve=ce)},setLocked:function(ce){H=ce},setClear:function(ce,ie,Oe,je,gt){gt===!0&&(ce*=je,ie*=je,Oe*=je),he.set(ce,ie,Oe,je),Pe.equals(he)===!1&&(i.clearColor(ce,ie,Oe,je),Pe.copy(he))},reset:function(){H=!1,ve=null,Pe.set(-1,0,0,0)}}}function n(){let H=!1,he=!1,ve=null,Pe=null,ce=null;return{setReversed:function(ie){if(he!==ie){const Oe=e.get("EXT_clip_control");ie?Oe.clipControlEXT(Oe.LOWER_LEFT_EXT,Oe.ZERO_TO_ONE_EXT):Oe.clipControlEXT(Oe.LOWER_LEFT_EXT,Oe.NEGATIVE_ONE_TO_ONE_EXT),he=ie;const je=ce;ce=null,this.setClear(je)}},getReversed:function(){return he},setTest:function(ie){ie?X(i.DEPTH_TEST):re(i.DEPTH_TEST)},setMask:function(ie){ve!==ie&&!H&&(i.depthMask(ie),ve=ie)},setFunc:function(ie){if(he&&(ie=ry[ie]),Pe!==ie){switch(ie){case Rl:i.depthFunc(i.NEVER);break;case Cl:i.depthFunc(i.ALWAYS);break;case Il:i.depthFunc(i.LESS);break;case Fr:i.depthFunc(i.LEQUAL);break;case Pl:i.depthFunc(i.EQUAL);break;case Ll:i.depthFunc(i.GEQUAL);break;case Dl:i.depthFunc(i.GREATER);break;case Nl:i.depthFunc(i.NOTEQUAL);break;default:i.depthFunc(i.LEQUAL)}Pe=ie}},setLocked:function(ie){H=ie},setClear:function(ie){ce!==ie&&(he&&(ie=1-ie),i.clearDepth(ie),ce=ie)},reset:function(){H=!1,ve=null,Pe=null,ce=null,he=!1}}}function r(){let H=!1,he=null,ve=null,Pe=null,ce=null,ie=null,Oe=null,je=null,gt=null;return{setTest:function(st){H||(st?X(i.STENCIL_TEST):re(i.STENCIL_TEST))},setMask:function(st){he!==st&&!H&&(i.stencilMask(st),he=st)},setFunc:function(st,Zn,Gn){(ve!==st||Pe!==Zn||ce!==Gn)&&(i.stencilFunc(st,Zn,Gn),ve=st,Pe=Zn,ce=Gn)},setOp:function(st,Zn,Gn){(ie!==st||Oe!==Zn||je!==Gn)&&(i.stencilOp(st,Zn,Gn),ie=st,Oe=Zn,je=Gn)},setLocked:function(st){H=st},setClear:function(st){gt!==st&&(i.clearStencil(st),gt=st)},reset:function(){H=!1,he=null,ve=null,Pe=null,ce=null,ie=null,Oe=null,je=null,gt=null}}}const s=new t,a=new n,o=new r,l=new WeakMap,c=new WeakMap;let d={},u={},h=new WeakMap,p=[],g=null,v=!1,m=null,f=null,b=null,_=null,x=null,R=null,M=null,A=new Ie(0,0,0),w=0,S=!1,y=null,T=null,N=null,B=null,k=null;const V=i.getParameter(i.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let D=!1,O=0;const F=i.getParameter(i.VERSION);F.indexOf("WebGL")!==-1?(O=parseFloat(/^WebGL (\d)/.exec(F)[1]),D=O>=1):F.indexOf("OpenGL ES")!==-1&&(O=parseFloat(/^OpenGL ES (\d)/.exec(F)[1]),D=O>=2);let z=null,j={};const te=i.getParameter(i.SCISSOR_BOX),L=i.getParameter(i.VIEWPORT),$=new rt().fromArray(te),Z=new rt().fromArray(L);function ae(H,he,ve,Pe){const ce=new Uint8Array(4),ie=i.createTexture();i.bindTexture(H,ie),i.texParameteri(H,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(H,i.TEXTURE_MAG_FILTER,i.NEAREST);for(let Oe=0;Oe<ve;Oe++)H===i.TEXTURE_3D||H===i.TEXTURE_2D_ARRAY?i.texImage3D(he,0,i.RGBA,1,1,Pe,0,i.RGBA,i.UNSIGNED_BYTE,ce):i.texImage2D(he+Oe,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,ce);return ie}const G={};G[i.TEXTURE_2D]=ae(i.TEXTURE_2D,i.TEXTURE_2D,1),G[i.TEXTURE_CUBE_MAP]=ae(i.TEXTURE_CUBE_MAP,i.TEXTURE_CUBE_MAP_POSITIVE_X,6),G[i.TEXTURE_2D_ARRAY]=ae(i.TEXTURE_2D_ARRAY,i.TEXTURE_2D_ARRAY,1,1),G[i.TEXTURE_3D]=ae(i.TEXTURE_3D,i.TEXTURE_3D,1,1),s.setClear(0,0,0,1),a.setClear(1),o.setClear(0),X(i.DEPTH_TEST),a.setFunc(Fr),ge(!1),se(gu),X(i.CULL_FACE),Le(ui);function X(H){d[H]!==!0&&(i.enable(H),d[H]=!0)}function re(H){d[H]!==!1&&(i.disable(H),d[H]=!1)}function ye(H,he){return u[H]!==he?(i.bindFramebuffer(H,he),u[H]=he,H===i.DRAW_FRAMEBUFFER&&(u[i.FRAMEBUFFER]=he),H===i.FRAMEBUFFER&&(u[i.DRAW_FRAMEBUFFER]=he),!0):!1}function fe(H,he){let ve=p,Pe=!1;if(H){ve=h.get(he),ve===void 0&&(ve=[],h.set(he,ve));const ce=H.textures;if(ve.length!==ce.length||ve[0]!==i.COLOR_ATTACHMENT0){for(let ie=0,Oe=ce.length;ie<Oe;ie++)ve[ie]=i.COLOR_ATTACHMENT0+ie;ve.length=ce.length,Pe=!0}}else ve[0]!==i.BACK&&(ve[0]=i.BACK,Pe=!0);Pe&&i.drawBuffers(ve)}function we(H){return g!==H?(i.useProgram(H),g=H,!0):!1}const me={[ji]:i.FUNC_ADD,[_p]:i.FUNC_SUBTRACT,[xp]:i.FUNC_REVERSE_SUBTRACT};me[yp]=i.MIN,me[bp]=i.MAX;const P={[Sp]:i.ZERO,[Mp]:i.ONE,[Ep]:i.SRC_COLOR,[Al]:i.SRC_ALPHA,[Ip]:i.SRC_ALPHA_SATURATE,[Rp]:i.DST_COLOR,[Ap]:i.DST_ALPHA,[Tp]:i.ONE_MINUS_SRC_COLOR,[wl]:i.ONE_MINUS_SRC_ALPHA,[Cp]:i.ONE_MINUS_DST_COLOR,[wp]:i.ONE_MINUS_DST_ALPHA,[Pp]:i.CONSTANT_COLOR,[Lp]:i.ONE_MINUS_CONSTANT_COLOR,[Dp]:i.CONSTANT_ALPHA,[Np]:i.ONE_MINUS_CONSTANT_ALPHA};function Le(H,he,ve,Pe,ce,ie,Oe,je,gt,st){if(H===ui){v===!0&&(re(i.BLEND),v=!1);return}if(v===!1&&(X(i.BLEND),v=!0),H!==vp){if(H!==m||st!==S){if((f!==ji||x!==ji)&&(i.blendEquation(i.FUNC_ADD),f=ji,x=ji),st)switch(H){case Ii:i.blendFuncSeparate(i.ONE,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case Qt:i.blendFunc(i.ONE,i.ONE);break;case vu:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case _u:i.blendFuncSeparate(i.DST_COLOR,i.ONE_MINUS_SRC_ALPHA,i.ZERO,i.ONE);break;default:console.error("THREE.WebGLState: Invalid blending: ",H);break}else switch(H){case Ii:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case Qt:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE,i.ONE,i.ONE);break;case vu:console.error("THREE.WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case _u:console.error("THREE.WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:console.error("THREE.WebGLState: Invalid blending: ",H);break}b=null,_=null,R=null,M=null,A.set(0,0,0),w=0,m=H,S=st}return}ce=ce||he,ie=ie||ve,Oe=Oe||Pe,(he!==f||ce!==x)&&(i.blendEquationSeparate(me[he],me[ce]),f=he,x=ce),(ve!==b||Pe!==_||ie!==R||Oe!==M)&&(i.blendFuncSeparate(P[ve],P[Pe],P[ie],P[Oe]),b=ve,_=Pe,R=ie,M=Oe),(je.equals(A)===!1||gt!==w)&&(i.blendColor(je.r,je.g,je.b,gt),A.copy(je),w=gt),m=H,S=!1}function Te(H,he){H.side===Et?re(i.CULL_FACE):X(i.CULL_FACE);let ve=H.side===cn;he&&(ve=!ve),ge(ve),H.blending===Ii&&H.transparent===!1?Le(ui):Le(H.blending,H.blendEquation,H.blendSrc,H.blendDst,H.blendEquationAlpha,H.blendSrcAlpha,H.blendDstAlpha,H.blendColor,H.blendAlpha,H.premultipliedAlpha),a.setFunc(H.depthFunc),a.setTest(H.depthTest),a.setMask(H.depthWrite),s.setMask(H.colorWrite);const Pe=H.stencilWrite;o.setTest(Pe),Pe&&(o.setMask(H.stencilWriteMask),o.setFunc(H.stencilFunc,H.stencilRef,H.stencilFuncMask),o.setOp(H.stencilFail,H.stencilZFail,H.stencilZPass)),oe(H.polygonOffset,H.polygonOffsetFactor,H.polygonOffsetUnits),H.alphaToCoverage===!0?X(i.SAMPLE_ALPHA_TO_COVERAGE):re(i.SAMPLE_ALPHA_TO_COVERAGE)}function ge(H){y!==H&&(H?i.frontFace(i.CW):i.frontFace(i.CCW),y=H)}function se(H){H!==pp?(X(i.CULL_FACE),H!==T&&(H===gu?i.cullFace(i.BACK):H===mp?i.cullFace(i.FRONT):i.cullFace(i.FRONT_AND_BACK))):re(i.CULL_FACE),T=H}function ze(H){H!==N&&(D&&i.lineWidth(H),N=H)}function oe(H,he,ve){H?(X(i.POLYGON_OFFSET_FILL),(B!==he||k!==ve)&&(i.polygonOffset(he,ve),B=he,k=ve)):re(i.POLYGON_OFFSET_FILL)}function Se(H){H?X(i.SCISSOR_TEST):re(i.SCISSOR_TEST)}function Ye(H){H===void 0&&(H=i.TEXTURE0+V-1),z!==H&&(i.activeTexture(H),z=H)}function De(H,he,ve){ve===void 0&&(z===null?ve=i.TEXTURE0+V-1:ve=z);let Pe=j[ve];Pe===void 0&&(Pe={type:void 0,texture:void 0},j[ve]=Pe),(Pe.type!==H||Pe.texture!==he)&&(z!==ve&&(i.activeTexture(ve),z=ve),i.bindTexture(H,he||G[H]),Pe.type=H,Pe.texture=he)}function I(){const H=j[z];H!==void 0&&H.type!==void 0&&(i.bindTexture(H.type,null),H.type=void 0,H.texture=void 0)}function E(){try{i.compressedTexImage2D(...arguments)}catch(H){console.error("THREE.WebGLState:",H)}}function Y(){try{i.compressedTexImage3D(...arguments)}catch(H){console.error("THREE.WebGLState:",H)}}function ee(){try{i.texSubImage2D(...arguments)}catch(H){console.error("THREE.WebGLState:",H)}}function ne(){try{i.texSubImage3D(...arguments)}catch(H){console.error("THREE.WebGLState:",H)}}function K(){try{i.compressedTexSubImage2D(...arguments)}catch(H){console.error("THREE.WebGLState:",H)}}function xe(){try{i.compressedTexSubImage3D(...arguments)}catch(H){console.error("THREE.WebGLState:",H)}}function le(){try{i.texStorage2D(...arguments)}catch(H){console.error("THREE.WebGLState:",H)}}function Ue(){try{i.texStorage3D(...arguments)}catch(H){console.error("THREE.WebGLState:",H)}}function Fe(){try{i.texImage2D(...arguments)}catch(H){console.error("THREE.WebGLState:",H)}}function de(){try{i.texImage3D(...arguments)}catch(H){console.error("THREE.WebGLState:",H)}}function Ae(H){$.equals(H)===!1&&(i.scissor(H.x,H.y,H.z,H.w),$.copy(H))}function Ge(H){Z.equals(H)===!1&&(i.viewport(H.x,H.y,H.z,H.w),Z.copy(H))}function Be(H,he){let ve=c.get(he);ve===void 0&&(ve=new WeakMap,c.set(he,ve));let Pe=ve.get(H);Pe===void 0&&(Pe=i.getUniformBlockIndex(he,H.name),ve.set(H,Pe))}function Me(H,he){const Pe=c.get(he).get(H);l.get(he)!==Pe&&(i.uniformBlockBinding(he,Pe,H.__bindingPointIndex),l.set(he,Pe))}function Ke(){i.disable(i.BLEND),i.disable(i.CULL_FACE),i.disable(i.DEPTH_TEST),i.disable(i.POLYGON_OFFSET_FILL),i.disable(i.SCISSOR_TEST),i.disable(i.STENCIL_TEST),i.disable(i.SAMPLE_ALPHA_TO_COVERAGE),i.blendEquation(i.FUNC_ADD),i.blendFunc(i.ONE,i.ZERO),i.blendFuncSeparate(i.ONE,i.ZERO,i.ONE,i.ZERO),i.blendColor(0,0,0,0),i.colorMask(!0,!0,!0,!0),i.clearColor(0,0,0,0),i.depthMask(!0),i.depthFunc(i.LESS),a.setReversed(!1),i.clearDepth(1),i.stencilMask(4294967295),i.stencilFunc(i.ALWAYS,0,4294967295),i.stencilOp(i.KEEP,i.KEEP,i.KEEP),i.clearStencil(0),i.cullFace(i.BACK),i.frontFace(i.CCW),i.polygonOffset(0,0),i.activeTexture(i.TEXTURE0),i.bindFramebuffer(i.FRAMEBUFFER,null),i.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),i.bindFramebuffer(i.READ_FRAMEBUFFER,null),i.useProgram(null),i.lineWidth(1),i.scissor(0,0,i.canvas.width,i.canvas.height),i.viewport(0,0,i.canvas.width,i.canvas.height),d={},z=null,j={},u={},h=new WeakMap,p=[],g=null,v=!1,m=null,f=null,b=null,_=null,x=null,R=null,M=null,A=new Ie(0,0,0),w=0,S=!1,y=null,T=null,N=null,B=null,k=null,$.set(0,0,i.canvas.width,i.canvas.height),Z.set(0,0,i.canvas.width,i.canvas.height),s.reset(),a.reset(),o.reset()}return{buffers:{color:s,depth:a,stencil:o},enable:X,disable:re,bindFramebuffer:ye,drawBuffers:fe,useProgram:we,setBlending:Le,setMaterial:Te,setFlipSided:ge,setCullFace:se,setLineWidth:ze,setPolygonOffset:oe,setScissorTest:Se,activeTexture:Ye,bindTexture:De,unbindTexture:I,compressedTexImage2D:E,compressedTexImage3D:Y,texImage2D:Fe,texImage3D:de,updateUBOMapping:Be,uniformBlockBinding:Me,texStorage2D:le,texStorage3D:Ue,texSubImage2D:ee,texSubImage3D:ne,compressedTexSubImage2D:K,compressedTexSubImage3D:xe,scissor:Ae,viewport:Ge,reset:Ke}}function ay(i,e,t,n,r,s,a){const o=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),c=new Ce,d=new WeakMap;let u;const h=new WeakMap;let p=!1;try{p=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function g(I,E){return p?new OffscreenCanvas(I,E):Ns("canvas")}function v(I,E,Y){let ee=1;const ne=De(I);if((ne.width>Y||ne.height>Y)&&(ee=Y/Math.max(ne.width,ne.height)),ee<1)if(typeof HTMLImageElement<"u"&&I instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&I instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&I instanceof ImageBitmap||typeof VideoFrame<"u"&&I instanceof VideoFrame){const K=Math.floor(ee*ne.width),xe=Math.floor(ee*ne.height);u===void 0&&(u=g(K,xe));const le=E?g(K,xe):u;return le.width=K,le.height=xe,le.getContext("2d").drawImage(I,0,0,K,xe),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+ne.width+"x"+ne.height+") to ("+K+"x"+xe+")."),le}else return"data"in I&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+ne.width+"x"+ne.height+")."),I;return I}function m(I){return I.generateMipmaps}function f(I){i.generateMipmap(I)}function b(I){return I.isWebGLCubeRenderTarget?i.TEXTURE_CUBE_MAP:I.isWebGL3DRenderTarget?i.TEXTURE_3D:I.isWebGLArrayRenderTarget||I.isCompressedArrayTexture?i.TEXTURE_2D_ARRAY:i.TEXTURE_2D}function _(I,E,Y,ee,ne=!1){if(I!==null){if(i[I]!==void 0)return i[I];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+I+"'")}let K=E;if(E===i.RED&&(Y===i.FLOAT&&(K=i.R32F),Y===i.HALF_FLOAT&&(K=i.R16F),Y===i.UNSIGNED_BYTE&&(K=i.R8)),E===i.RED_INTEGER&&(Y===i.UNSIGNED_BYTE&&(K=i.R8UI),Y===i.UNSIGNED_SHORT&&(K=i.R16UI),Y===i.UNSIGNED_INT&&(K=i.R32UI),Y===i.BYTE&&(K=i.R8I),Y===i.SHORT&&(K=i.R16I),Y===i.INT&&(K=i.R32I)),E===i.RG&&(Y===i.FLOAT&&(K=i.RG32F),Y===i.HALF_FLOAT&&(K=i.RG16F),Y===i.UNSIGNED_BYTE&&(K=i.RG8)),E===i.RG_INTEGER&&(Y===i.UNSIGNED_BYTE&&(K=i.RG8UI),Y===i.UNSIGNED_SHORT&&(K=i.RG16UI),Y===i.UNSIGNED_INT&&(K=i.RG32UI),Y===i.BYTE&&(K=i.RG8I),Y===i.SHORT&&(K=i.RG16I),Y===i.INT&&(K=i.RG32I)),E===i.RGB_INTEGER&&(Y===i.UNSIGNED_BYTE&&(K=i.RGB8UI),Y===i.UNSIGNED_SHORT&&(K=i.RGB16UI),Y===i.UNSIGNED_INT&&(K=i.RGB32UI),Y===i.BYTE&&(K=i.RGB8I),Y===i.SHORT&&(K=i.RGB16I),Y===i.INT&&(K=i.RGB32I)),E===i.RGBA_INTEGER&&(Y===i.UNSIGNED_BYTE&&(K=i.RGBA8UI),Y===i.UNSIGNED_SHORT&&(K=i.RGBA16UI),Y===i.UNSIGNED_INT&&(K=i.RGBA32UI),Y===i.BYTE&&(K=i.RGBA8I),Y===i.SHORT&&(K=i.RGBA16I),Y===i.INT&&(K=i.RGBA32I)),E===i.RGB&&(Y===i.UNSIGNED_INT_5_9_9_9_REV&&(K=i.RGB9_E5),Y===i.UNSIGNED_INT_10F_11F_11F_REV&&(K=i.R11F_G11F_B10F)),E===i.RGBA){const xe=ne?Wa:tt.getTransfer(ee);Y===i.FLOAT&&(K=i.RGBA32F),Y===i.HALF_FLOAT&&(K=i.RGBA16F),Y===i.UNSIGNED_BYTE&&(K=xe===pt?i.SRGB8_ALPHA8:i.RGBA8),Y===i.UNSIGNED_SHORT_4_4_4_4&&(K=i.RGBA4),Y===i.UNSIGNED_SHORT_5_5_5_1&&(K=i.RGB5_A1)}return(K===i.R16F||K===i.R32F||K===i.RG16F||K===i.RG32F||K===i.RGBA16F||K===i.RGBA32F)&&e.get("EXT_color_buffer_float"),K}function x(I,E){let Y;return I?E===null||E===Zi||E===Cs?Y=i.DEPTH24_STENCIL8:E===kn?Y=i.DEPTH32F_STENCIL8:E===Rs&&(Y=i.DEPTH24_STENCIL8,console.warn("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):E===null||E===Zi||E===Cs?Y=i.DEPTH_COMPONENT24:E===kn?Y=i.DEPTH_COMPONENT32F:E===Rs&&(Y=i.DEPTH_COMPONENT16),Y}function R(I,E){return m(I)===!0||I.isFramebufferTexture&&I.minFilter!==Jt&&I.minFilter!==Dt?Math.log2(Math.max(E.width,E.height))+1:I.mipmaps!==void 0&&I.mipmaps.length>0?I.mipmaps.length:I.isCompressedTexture&&Array.isArray(I.image)?E.mipmaps.length:1}function M(I){const E=I.target;E.removeEventListener("dispose",M),w(E),E.isVideoTexture&&d.delete(E)}function A(I){const E=I.target;E.removeEventListener("dispose",A),y(E)}function w(I){const E=n.get(I);if(E.__webglInit===void 0)return;const Y=I.source,ee=h.get(Y);if(ee){const ne=ee[E.__cacheKey];ne.usedTimes--,ne.usedTimes===0&&S(I),Object.keys(ee).length===0&&h.delete(Y)}n.remove(I)}function S(I){const E=n.get(I);i.deleteTexture(E.__webglTexture);const Y=I.source,ee=h.get(Y);delete ee[E.__cacheKey],a.memory.textures--}function y(I){const E=n.get(I);if(I.depthTexture&&(I.depthTexture.dispose(),n.remove(I.depthTexture)),I.isWebGLCubeRenderTarget)for(let ee=0;ee<6;ee++){if(Array.isArray(E.__webglFramebuffer[ee]))for(let ne=0;ne<E.__webglFramebuffer[ee].length;ne++)i.deleteFramebuffer(E.__webglFramebuffer[ee][ne]);else i.deleteFramebuffer(E.__webglFramebuffer[ee]);E.__webglDepthbuffer&&i.deleteRenderbuffer(E.__webglDepthbuffer[ee])}else{if(Array.isArray(E.__webglFramebuffer))for(let ee=0;ee<E.__webglFramebuffer.length;ee++)i.deleteFramebuffer(E.__webglFramebuffer[ee]);else i.deleteFramebuffer(E.__webglFramebuffer);if(E.__webglDepthbuffer&&i.deleteRenderbuffer(E.__webglDepthbuffer),E.__webglMultisampledFramebuffer&&i.deleteFramebuffer(E.__webglMultisampledFramebuffer),E.__webglColorRenderbuffer)for(let ee=0;ee<E.__webglColorRenderbuffer.length;ee++)E.__webglColorRenderbuffer[ee]&&i.deleteRenderbuffer(E.__webglColorRenderbuffer[ee]);E.__webglDepthRenderbuffer&&i.deleteRenderbuffer(E.__webglDepthRenderbuffer)}const Y=I.textures;for(let ee=0,ne=Y.length;ee<ne;ee++){const K=n.get(Y[ee]);K.__webglTexture&&(i.deleteTexture(K.__webglTexture),a.memory.textures--),n.remove(Y[ee])}n.remove(I)}let T=0;function N(){T=0}function B(){const I=T;return I>=r.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+I+" texture units while this GPU supports only "+r.maxTextures),T+=1,I}function k(I){const E=[];return E.push(I.wrapS),E.push(I.wrapT),E.push(I.wrapR||0),E.push(I.magFilter),E.push(I.minFilter),E.push(I.anisotropy),E.push(I.internalFormat),E.push(I.format),E.push(I.type),E.push(I.generateMipmaps),E.push(I.premultiplyAlpha),E.push(I.flipY),E.push(I.unpackAlignment),E.push(I.colorSpace),E.join()}function V(I,E){const Y=n.get(I);if(I.isVideoTexture&&Se(I),I.isRenderTargetTexture===!1&&I.isExternalTexture!==!0&&I.version>0&&Y.__version!==I.version){const ee=I.image;if(ee===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(ee.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{G(Y,I,E);return}}else I.isExternalTexture&&(Y.__webglTexture=I.sourceTexture?I.sourceTexture:null);t.bindTexture(i.TEXTURE_2D,Y.__webglTexture,i.TEXTURE0+E)}function D(I,E){const Y=n.get(I);if(I.isRenderTargetTexture===!1&&I.version>0&&Y.__version!==I.version){G(Y,I,E);return}t.bindTexture(i.TEXTURE_2D_ARRAY,Y.__webglTexture,i.TEXTURE0+E)}function O(I,E){const Y=n.get(I);if(I.isRenderTargetTexture===!1&&I.version>0&&Y.__version!==I.version){G(Y,I,E);return}t.bindTexture(i.TEXTURE_3D,Y.__webglTexture,i.TEXTURE0+E)}function F(I,E){const Y=n.get(I);if(I.version>0&&Y.__version!==I.version){X(Y,I,E);return}t.bindTexture(i.TEXTURE_CUBE_MAP,Y.__webglTexture,i.TEXTURE0+E)}const z={[zr]:i.REPEAT,[Ci]:i.CLAMP_TO_EDGE,[Ga]:i.MIRRORED_REPEAT},j={[Jt]:i.NEAREST,[Vh]:i.NEAREST_MIPMAP_NEAREST,[bs]:i.NEAREST_MIPMAP_LINEAR,[Dt]:i.LINEAR,[Ua]:i.LINEAR_MIPMAP_NEAREST,[Gt]:i.LINEAR_MIPMAP_LINEAR},te={[$p]:i.NEVER,[tm]:i.ALWAYS,[Kp]:i.LESS,[Kh]:i.LEQUAL,[Zp]:i.EQUAL,[em]:i.GEQUAL,[Jp]:i.GREATER,[Qp]:i.NOTEQUAL};function L(I,E){if(E.type===kn&&e.has("OES_texture_float_linear")===!1&&(E.magFilter===Dt||E.magFilter===Ua||E.magFilter===bs||E.magFilter===Gt||E.minFilter===Dt||E.minFilter===Ua||E.minFilter===bs||E.minFilter===Gt)&&console.warn("THREE.WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),i.texParameteri(I,i.TEXTURE_WRAP_S,z[E.wrapS]),i.texParameteri(I,i.TEXTURE_WRAP_T,z[E.wrapT]),(I===i.TEXTURE_3D||I===i.TEXTURE_2D_ARRAY)&&i.texParameteri(I,i.TEXTURE_WRAP_R,z[E.wrapR]),i.texParameteri(I,i.TEXTURE_MAG_FILTER,j[E.magFilter]),i.texParameteri(I,i.TEXTURE_MIN_FILTER,j[E.minFilter]),E.compareFunction&&(i.texParameteri(I,i.TEXTURE_COMPARE_MODE,i.COMPARE_REF_TO_TEXTURE),i.texParameteri(I,i.TEXTURE_COMPARE_FUNC,te[E.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(E.magFilter===Jt||E.minFilter!==bs&&E.minFilter!==Gt||E.type===kn&&e.has("OES_texture_float_linear")===!1)return;if(E.anisotropy>1||n.get(E).__currentAnisotropy){const Y=e.get("EXT_texture_filter_anisotropic");i.texParameterf(I,Y.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(E.anisotropy,r.getMaxAnisotropy())),n.get(E).__currentAnisotropy=E.anisotropy}}}function $(I,E){let Y=!1;I.__webglInit===void 0&&(I.__webglInit=!0,E.addEventListener("dispose",M));const ee=E.source;let ne=h.get(ee);ne===void 0&&(ne={},h.set(ee,ne));const K=k(E);if(K!==I.__cacheKey){ne[K]===void 0&&(ne[K]={texture:i.createTexture(),usedTimes:0},a.memory.textures++,Y=!0),ne[K].usedTimes++;const xe=ne[I.__cacheKey];xe!==void 0&&(ne[I.__cacheKey].usedTimes--,xe.usedTimes===0&&S(E)),I.__cacheKey=K,I.__webglTexture=ne[K].texture}return Y}function Z(I,E,Y){return Math.floor(Math.floor(I/Y)/E)}function ae(I,E,Y,ee){const K=I.updateRanges;if(K.length===0)t.texSubImage2D(i.TEXTURE_2D,0,0,0,E.width,E.height,Y,ee,E.data);else{K.sort((de,Ae)=>de.start-Ae.start);let xe=0;for(let de=1;de<K.length;de++){const Ae=K[xe],Ge=K[de],Be=Ae.start+Ae.count,Me=Z(Ge.start,E.width,4),Ke=Z(Ae.start,E.width,4);Ge.start<=Be+1&&Me===Ke&&Z(Ge.start+Ge.count-1,E.width,4)===Me?Ae.count=Math.max(Ae.count,Ge.start+Ge.count-Ae.start):(++xe,K[xe]=Ge)}K.length=xe+1;const le=i.getParameter(i.UNPACK_ROW_LENGTH),Ue=i.getParameter(i.UNPACK_SKIP_PIXELS),Fe=i.getParameter(i.UNPACK_SKIP_ROWS);i.pixelStorei(i.UNPACK_ROW_LENGTH,E.width);for(let de=0,Ae=K.length;de<Ae;de++){const Ge=K[de],Be=Math.floor(Ge.start/4),Me=Math.ceil(Ge.count/4),Ke=Be%E.width,H=Math.floor(Be/E.width),he=Me,ve=1;i.pixelStorei(i.UNPACK_SKIP_PIXELS,Ke),i.pixelStorei(i.UNPACK_SKIP_ROWS,H),t.texSubImage2D(i.TEXTURE_2D,0,Ke,H,he,ve,Y,ee,E.data)}I.clearUpdateRanges(),i.pixelStorei(i.UNPACK_ROW_LENGTH,le),i.pixelStorei(i.UNPACK_SKIP_PIXELS,Ue),i.pixelStorei(i.UNPACK_SKIP_ROWS,Fe)}}function G(I,E,Y){let ee=i.TEXTURE_2D;(E.isDataArrayTexture||E.isCompressedArrayTexture)&&(ee=i.TEXTURE_2D_ARRAY),E.isData3DTexture&&(ee=i.TEXTURE_3D);const ne=$(I,E),K=E.source;t.bindTexture(ee,I.__webglTexture,i.TEXTURE0+Y);const xe=n.get(K);if(K.version!==xe.__version||ne===!0){t.activeTexture(i.TEXTURE0+Y);const le=tt.getPrimaries(tt.workingColorSpace),Ue=E.colorSpace===oi?null:tt.getPrimaries(E.colorSpace),Fe=E.colorSpace===oi||le===Ue?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,E.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,E.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,E.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,Fe);let de=v(E.image,!1,r.maxTextureSize);de=Ye(E,de);const Ae=s.convert(E.format,E.colorSpace),Ge=s.convert(E.type);let Be=_(E.internalFormat,Ae,Ge,E.colorSpace,E.isVideoTexture);L(ee,E);let Me;const Ke=E.mipmaps,H=E.isVideoTexture!==!0,he=xe.__version===void 0||ne===!0,ve=K.dataReady,Pe=R(E,de);if(E.isDepthTexture)Be=x(E.format===Ps,E.type),he&&(H?t.texStorage2D(i.TEXTURE_2D,1,Be,de.width,de.height):t.texImage2D(i.TEXTURE_2D,0,Be,de.width,de.height,0,Ae,Ge,null));else if(E.isDataTexture)if(Ke.length>0){H&&he&&t.texStorage2D(i.TEXTURE_2D,Pe,Be,Ke[0].width,Ke[0].height);for(let ce=0,ie=Ke.length;ce<ie;ce++)Me=Ke[ce],H?ve&&t.texSubImage2D(i.TEXTURE_2D,ce,0,0,Me.width,Me.height,Ae,Ge,Me.data):t.texImage2D(i.TEXTURE_2D,ce,Be,Me.width,Me.height,0,Ae,Ge,Me.data);E.generateMipmaps=!1}else H?(he&&t.texStorage2D(i.TEXTURE_2D,Pe,Be,de.width,de.height),ve&&ae(E,de,Ae,Ge)):t.texImage2D(i.TEXTURE_2D,0,Be,de.width,de.height,0,Ae,Ge,de.data);else if(E.isCompressedTexture)if(E.isCompressedArrayTexture){H&&he&&t.texStorage3D(i.TEXTURE_2D_ARRAY,Pe,Be,Ke[0].width,Ke[0].height,de.depth);for(let ce=0,ie=Ke.length;ce<ie;ce++)if(Me=Ke[ce],E.format!==Rn)if(Ae!==null)if(H){if(ve)if(E.layerUpdates.size>0){const Oe=dd(Me.width,Me.height,E.format,E.type);for(const je of E.layerUpdates){const gt=Me.data.subarray(je*Oe/Me.data.BYTES_PER_ELEMENT,(je+1)*Oe/Me.data.BYTES_PER_ELEMENT);t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,ce,0,0,je,Me.width,Me.height,1,Ae,gt)}E.clearLayerUpdates()}else t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,ce,0,0,0,Me.width,Me.height,de.depth,Ae,Me.data)}else t.compressedTexImage3D(i.TEXTURE_2D_ARRAY,ce,Be,Me.width,Me.height,de.depth,0,Me.data,0,0);else console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else H?ve&&t.texSubImage3D(i.TEXTURE_2D_ARRAY,ce,0,0,0,Me.width,Me.height,de.depth,Ae,Ge,Me.data):t.texImage3D(i.TEXTURE_2D_ARRAY,ce,Be,Me.width,Me.height,de.depth,0,Ae,Ge,Me.data)}else{H&&he&&t.texStorage2D(i.TEXTURE_2D,Pe,Be,Ke[0].width,Ke[0].height);for(let ce=0,ie=Ke.length;ce<ie;ce++)Me=Ke[ce],E.format!==Rn?Ae!==null?H?ve&&t.compressedTexSubImage2D(i.TEXTURE_2D,ce,0,0,Me.width,Me.height,Ae,Me.data):t.compressedTexImage2D(i.TEXTURE_2D,ce,Be,Me.width,Me.height,0,Me.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):H?ve&&t.texSubImage2D(i.TEXTURE_2D,ce,0,0,Me.width,Me.height,Ae,Ge,Me.data):t.texImage2D(i.TEXTURE_2D,ce,Be,Me.width,Me.height,0,Ae,Ge,Me.data)}else if(E.isDataArrayTexture)if(H){if(he&&t.texStorage3D(i.TEXTURE_2D_ARRAY,Pe,Be,de.width,de.height,de.depth),ve)if(E.layerUpdates.size>0){const ce=dd(de.width,de.height,E.format,E.type);for(const ie of E.layerUpdates){const Oe=de.data.subarray(ie*ce/de.data.BYTES_PER_ELEMENT,(ie+1)*ce/de.data.BYTES_PER_ELEMENT);t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,ie,de.width,de.height,1,Ae,Ge,Oe)}E.clearLayerUpdates()}else t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,0,de.width,de.height,de.depth,Ae,Ge,de.data)}else t.texImage3D(i.TEXTURE_2D_ARRAY,0,Be,de.width,de.height,de.depth,0,Ae,Ge,de.data);else if(E.isData3DTexture)H?(he&&t.texStorage3D(i.TEXTURE_3D,Pe,Be,de.width,de.height,de.depth),ve&&t.texSubImage3D(i.TEXTURE_3D,0,0,0,0,de.width,de.height,de.depth,Ae,Ge,de.data)):t.texImage3D(i.TEXTURE_3D,0,Be,de.width,de.height,de.depth,0,Ae,Ge,de.data);else if(E.isFramebufferTexture){if(he)if(H)t.texStorage2D(i.TEXTURE_2D,Pe,Be,de.width,de.height);else{let ce=de.width,ie=de.height;for(let Oe=0;Oe<Pe;Oe++)t.texImage2D(i.TEXTURE_2D,Oe,Be,ce,ie,0,Ae,Ge,null),ce>>=1,ie>>=1}}else if(Ke.length>0){if(H&&he){const ce=De(Ke[0]);t.texStorage2D(i.TEXTURE_2D,Pe,Be,ce.width,ce.height)}for(let ce=0,ie=Ke.length;ce<ie;ce++)Me=Ke[ce],H?ve&&t.texSubImage2D(i.TEXTURE_2D,ce,0,0,Ae,Ge,Me):t.texImage2D(i.TEXTURE_2D,ce,Be,Ae,Ge,Me);E.generateMipmaps=!1}else if(H){if(he){const ce=De(de);t.texStorage2D(i.TEXTURE_2D,Pe,Be,ce.width,ce.height)}ve&&t.texSubImage2D(i.TEXTURE_2D,0,0,0,Ae,Ge,de)}else t.texImage2D(i.TEXTURE_2D,0,Be,Ae,Ge,de);m(E)&&f(ee),xe.__version=K.version,E.onUpdate&&E.onUpdate(E)}I.__version=E.version}function X(I,E,Y){if(E.image.length!==6)return;const ee=$(I,E),ne=E.source;t.bindTexture(i.TEXTURE_CUBE_MAP,I.__webglTexture,i.TEXTURE0+Y);const K=n.get(ne);if(ne.version!==K.__version||ee===!0){t.activeTexture(i.TEXTURE0+Y);const xe=tt.getPrimaries(tt.workingColorSpace),le=E.colorSpace===oi?null:tt.getPrimaries(E.colorSpace),Ue=E.colorSpace===oi||xe===le?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,E.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,E.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,E.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,Ue);const Fe=E.isCompressedTexture||E.image[0].isCompressedTexture,de=E.image[0]&&E.image[0].isDataTexture,Ae=[];for(let ie=0;ie<6;ie++)!Fe&&!de?Ae[ie]=v(E.image[ie],!0,r.maxCubemapSize):Ae[ie]=de?E.image[ie].image:E.image[ie],Ae[ie]=Ye(E,Ae[ie]);const Ge=Ae[0],Be=s.convert(E.format,E.colorSpace),Me=s.convert(E.type),Ke=_(E.internalFormat,Be,Me,E.colorSpace),H=E.isVideoTexture!==!0,he=K.__version===void 0||ee===!0,ve=ne.dataReady;let Pe=R(E,Ge);L(i.TEXTURE_CUBE_MAP,E);let ce;if(Fe){H&&he&&t.texStorage2D(i.TEXTURE_CUBE_MAP,Pe,Ke,Ge.width,Ge.height);for(let ie=0;ie<6;ie++){ce=Ae[ie].mipmaps;for(let Oe=0;Oe<ce.length;Oe++){const je=ce[Oe];E.format!==Rn?Be!==null?H?ve&&t.compressedTexSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ie,Oe,0,0,je.width,je.height,Be,je.data):t.compressedTexImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ie,Oe,Ke,je.width,je.height,0,je.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):H?ve&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ie,Oe,0,0,je.width,je.height,Be,Me,je.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ie,Oe,Ke,je.width,je.height,0,Be,Me,je.data)}}}else{if(ce=E.mipmaps,H&&he){ce.length>0&&Pe++;const ie=De(Ae[0]);t.texStorage2D(i.TEXTURE_CUBE_MAP,Pe,Ke,ie.width,ie.height)}for(let ie=0;ie<6;ie++)if(de){H?ve&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ie,0,0,0,Ae[ie].width,Ae[ie].height,Be,Me,Ae[ie].data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ie,0,Ke,Ae[ie].width,Ae[ie].height,0,Be,Me,Ae[ie].data);for(let Oe=0;Oe<ce.length;Oe++){const gt=ce[Oe].image[ie].image;H?ve&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ie,Oe+1,0,0,gt.width,gt.height,Be,Me,gt.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ie,Oe+1,Ke,gt.width,gt.height,0,Be,Me,gt.data)}}else{H?ve&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ie,0,0,0,Be,Me,Ae[ie]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ie,0,Ke,Be,Me,Ae[ie]);for(let Oe=0;Oe<ce.length;Oe++){const je=ce[Oe];H?ve&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ie,Oe+1,0,0,Be,Me,je.image[ie]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ie,Oe+1,Ke,Be,Me,je.image[ie])}}}m(E)&&f(i.TEXTURE_CUBE_MAP),K.__version=ne.version,E.onUpdate&&E.onUpdate(E)}I.__version=E.version}function re(I,E,Y,ee,ne,K){const xe=s.convert(Y.format,Y.colorSpace),le=s.convert(Y.type),Ue=_(Y.internalFormat,xe,le,Y.colorSpace),Fe=n.get(E),de=n.get(Y);if(de.__renderTarget=E,!Fe.__hasExternalTextures){const Ae=Math.max(1,E.width>>K),Ge=Math.max(1,E.height>>K);ne===i.TEXTURE_3D||ne===i.TEXTURE_2D_ARRAY?t.texImage3D(ne,K,Ue,Ae,Ge,E.depth,0,xe,le,null):t.texImage2D(ne,K,Ue,Ae,Ge,0,xe,le,null)}t.bindFramebuffer(i.FRAMEBUFFER,I),oe(E)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,ee,ne,de.__webglTexture,0,ze(E)):(ne===i.TEXTURE_2D||ne>=i.TEXTURE_CUBE_MAP_POSITIVE_X&&ne<=i.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&i.framebufferTexture2D(i.FRAMEBUFFER,ee,ne,de.__webglTexture,K),t.bindFramebuffer(i.FRAMEBUFFER,null)}function ye(I,E,Y){if(i.bindRenderbuffer(i.RENDERBUFFER,I),E.depthBuffer){const ee=E.depthTexture,ne=ee&&ee.isDepthTexture?ee.type:null,K=x(E.stencilBuffer,ne),xe=E.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,le=ze(E);oe(E)?o.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,le,K,E.width,E.height):Y?i.renderbufferStorageMultisample(i.RENDERBUFFER,le,K,E.width,E.height):i.renderbufferStorage(i.RENDERBUFFER,K,E.width,E.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,xe,i.RENDERBUFFER,I)}else{const ee=E.textures;for(let ne=0;ne<ee.length;ne++){const K=ee[ne],xe=s.convert(K.format,K.colorSpace),le=s.convert(K.type),Ue=_(K.internalFormat,xe,le,K.colorSpace),Fe=ze(E);Y&&oe(E)===!1?i.renderbufferStorageMultisample(i.RENDERBUFFER,Fe,Ue,E.width,E.height):oe(E)?o.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,Fe,Ue,E.width,E.height):i.renderbufferStorage(i.RENDERBUFFER,Ue,E.width,E.height)}}i.bindRenderbuffer(i.RENDERBUFFER,null)}function fe(I,E){if(E&&E.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(t.bindFramebuffer(i.FRAMEBUFFER,I),!(E.depthTexture&&E.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const ee=n.get(E.depthTexture);ee.__renderTarget=E,(!ee.__webglTexture||E.depthTexture.image.width!==E.width||E.depthTexture.image.height!==E.height)&&(E.depthTexture.image.width=E.width,E.depthTexture.image.height=E.height,E.depthTexture.needsUpdate=!0),V(E.depthTexture,0);const ne=ee.__webglTexture,K=ze(E);if(E.depthTexture.format===Is)oe(E)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,ne,0,K):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,ne,0);else if(E.depthTexture.format===Ps)oe(E)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,ne,0,K):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,ne,0);else throw new Error("Unknown depthTexture format")}function we(I){const E=n.get(I),Y=I.isWebGLCubeRenderTarget===!0;if(E.__boundDepthTexture!==I.depthTexture){const ee=I.depthTexture;if(E.__depthDisposeCallback&&E.__depthDisposeCallback(),ee){const ne=()=>{delete E.__boundDepthTexture,delete E.__depthDisposeCallback,ee.removeEventListener("dispose",ne)};ee.addEventListener("dispose",ne),E.__depthDisposeCallback=ne}E.__boundDepthTexture=ee}if(I.depthTexture&&!E.__autoAllocateDepthBuffer){if(Y)throw new Error("target.depthTexture not supported in Cube render targets");const ee=I.texture.mipmaps;ee&&ee.length>0?fe(E.__webglFramebuffer[0],I):fe(E.__webglFramebuffer,I)}else if(Y){E.__webglDepthbuffer=[];for(let ee=0;ee<6;ee++)if(t.bindFramebuffer(i.FRAMEBUFFER,E.__webglFramebuffer[ee]),E.__webglDepthbuffer[ee]===void 0)E.__webglDepthbuffer[ee]=i.createRenderbuffer(),ye(E.__webglDepthbuffer[ee],I,!1);else{const ne=I.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,K=E.__webglDepthbuffer[ee];i.bindRenderbuffer(i.RENDERBUFFER,K),i.framebufferRenderbuffer(i.FRAMEBUFFER,ne,i.RENDERBUFFER,K)}}else{const ee=I.texture.mipmaps;if(ee&&ee.length>0?t.bindFramebuffer(i.FRAMEBUFFER,E.__webglFramebuffer[0]):t.bindFramebuffer(i.FRAMEBUFFER,E.__webglFramebuffer),E.__webglDepthbuffer===void 0)E.__webglDepthbuffer=i.createRenderbuffer(),ye(E.__webglDepthbuffer,I,!1);else{const ne=I.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,K=E.__webglDepthbuffer;i.bindRenderbuffer(i.RENDERBUFFER,K),i.framebufferRenderbuffer(i.FRAMEBUFFER,ne,i.RENDERBUFFER,K)}}t.bindFramebuffer(i.FRAMEBUFFER,null)}function me(I,E,Y){const ee=n.get(I);E!==void 0&&re(ee.__webglFramebuffer,I,I.texture,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,0),Y!==void 0&&we(I)}function P(I){const E=I.texture,Y=n.get(I),ee=n.get(E);I.addEventListener("dispose",A);const ne=I.textures,K=I.isWebGLCubeRenderTarget===!0,xe=ne.length>1;if(xe||(ee.__webglTexture===void 0&&(ee.__webglTexture=i.createTexture()),ee.__version=E.version,a.memory.textures++),K){Y.__webglFramebuffer=[];for(let le=0;le<6;le++)if(E.mipmaps&&E.mipmaps.length>0){Y.__webglFramebuffer[le]=[];for(let Ue=0;Ue<E.mipmaps.length;Ue++)Y.__webglFramebuffer[le][Ue]=i.createFramebuffer()}else Y.__webglFramebuffer[le]=i.createFramebuffer()}else{if(E.mipmaps&&E.mipmaps.length>0){Y.__webglFramebuffer=[];for(let le=0;le<E.mipmaps.length;le++)Y.__webglFramebuffer[le]=i.createFramebuffer()}else Y.__webglFramebuffer=i.createFramebuffer();if(xe)for(let le=0,Ue=ne.length;le<Ue;le++){const Fe=n.get(ne[le]);Fe.__webglTexture===void 0&&(Fe.__webglTexture=i.createTexture(),a.memory.textures++)}if(I.samples>0&&oe(I)===!1){Y.__webglMultisampledFramebuffer=i.createFramebuffer(),Y.__webglColorRenderbuffer=[],t.bindFramebuffer(i.FRAMEBUFFER,Y.__webglMultisampledFramebuffer);for(let le=0;le<ne.length;le++){const Ue=ne[le];Y.__webglColorRenderbuffer[le]=i.createRenderbuffer(),i.bindRenderbuffer(i.RENDERBUFFER,Y.__webglColorRenderbuffer[le]);const Fe=s.convert(Ue.format,Ue.colorSpace),de=s.convert(Ue.type),Ae=_(Ue.internalFormat,Fe,de,Ue.colorSpace,I.isXRRenderTarget===!0),Ge=ze(I);i.renderbufferStorageMultisample(i.RENDERBUFFER,Ge,Ae,I.width,I.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+le,i.RENDERBUFFER,Y.__webglColorRenderbuffer[le])}i.bindRenderbuffer(i.RENDERBUFFER,null),I.depthBuffer&&(Y.__webglDepthRenderbuffer=i.createRenderbuffer(),ye(Y.__webglDepthRenderbuffer,I,!0)),t.bindFramebuffer(i.FRAMEBUFFER,null)}}if(K){t.bindTexture(i.TEXTURE_CUBE_MAP,ee.__webglTexture),L(i.TEXTURE_CUBE_MAP,E);for(let le=0;le<6;le++)if(E.mipmaps&&E.mipmaps.length>0)for(let Ue=0;Ue<E.mipmaps.length;Ue++)re(Y.__webglFramebuffer[le][Ue],I,E,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+le,Ue);else re(Y.__webglFramebuffer[le],I,E,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+le,0);m(E)&&f(i.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(xe){for(let le=0,Ue=ne.length;le<Ue;le++){const Fe=ne[le],de=n.get(Fe);let Ae=i.TEXTURE_2D;(I.isWebGL3DRenderTarget||I.isWebGLArrayRenderTarget)&&(Ae=I.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),t.bindTexture(Ae,de.__webglTexture),L(Ae,Fe),re(Y.__webglFramebuffer,I,Fe,i.COLOR_ATTACHMENT0+le,Ae,0),m(Fe)&&f(Ae)}t.unbindTexture()}else{let le=i.TEXTURE_2D;if((I.isWebGL3DRenderTarget||I.isWebGLArrayRenderTarget)&&(le=I.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),t.bindTexture(le,ee.__webglTexture),L(le,E),E.mipmaps&&E.mipmaps.length>0)for(let Ue=0;Ue<E.mipmaps.length;Ue++)re(Y.__webglFramebuffer[Ue],I,E,i.COLOR_ATTACHMENT0,le,Ue);else re(Y.__webglFramebuffer,I,E,i.COLOR_ATTACHMENT0,le,0);m(E)&&f(le),t.unbindTexture()}I.depthBuffer&&we(I)}function Le(I){const E=I.textures;for(let Y=0,ee=E.length;Y<ee;Y++){const ne=E[Y];if(m(ne)){const K=b(I),xe=n.get(ne).__webglTexture;t.bindTexture(K,xe),f(K),t.unbindTexture()}}}const Te=[],ge=[];function se(I){if(I.samples>0){if(oe(I)===!1){const E=I.textures,Y=I.width,ee=I.height;let ne=i.COLOR_BUFFER_BIT;const K=I.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,xe=n.get(I),le=E.length>1;if(le)for(let Fe=0;Fe<E.length;Fe++)t.bindFramebuffer(i.FRAMEBUFFER,xe.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Fe,i.RENDERBUFFER,null),t.bindFramebuffer(i.FRAMEBUFFER,xe.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Fe,i.TEXTURE_2D,null,0);t.bindFramebuffer(i.READ_FRAMEBUFFER,xe.__webglMultisampledFramebuffer);const Ue=I.texture.mipmaps;Ue&&Ue.length>0?t.bindFramebuffer(i.DRAW_FRAMEBUFFER,xe.__webglFramebuffer[0]):t.bindFramebuffer(i.DRAW_FRAMEBUFFER,xe.__webglFramebuffer);for(let Fe=0;Fe<E.length;Fe++){if(I.resolveDepthBuffer&&(I.depthBuffer&&(ne|=i.DEPTH_BUFFER_BIT),I.stencilBuffer&&I.resolveStencilBuffer&&(ne|=i.STENCIL_BUFFER_BIT)),le){i.framebufferRenderbuffer(i.READ_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.RENDERBUFFER,xe.__webglColorRenderbuffer[Fe]);const de=n.get(E[Fe]).__webglTexture;i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,de,0)}i.blitFramebuffer(0,0,Y,ee,0,0,Y,ee,ne,i.NEAREST),l===!0&&(Te.length=0,ge.length=0,Te.push(i.COLOR_ATTACHMENT0+Fe),I.depthBuffer&&I.resolveDepthBuffer===!1&&(Te.push(K),ge.push(K),i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,ge)),i.invalidateFramebuffer(i.READ_FRAMEBUFFER,Te))}if(t.bindFramebuffer(i.READ_FRAMEBUFFER,null),t.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),le)for(let Fe=0;Fe<E.length;Fe++){t.bindFramebuffer(i.FRAMEBUFFER,xe.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Fe,i.RENDERBUFFER,xe.__webglColorRenderbuffer[Fe]);const de=n.get(E[Fe]).__webglTexture;t.bindFramebuffer(i.FRAMEBUFFER,xe.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Fe,i.TEXTURE_2D,de,0)}t.bindFramebuffer(i.DRAW_FRAMEBUFFER,xe.__webglMultisampledFramebuffer)}else if(I.depthBuffer&&I.resolveDepthBuffer===!1&&l){const E=I.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,[E])}}}function ze(I){return Math.min(r.maxSamples,I.samples)}function oe(I){const E=n.get(I);return I.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&E.__useRenderToTexture!==!1}function Se(I){const E=a.render.frame;d.get(I)!==E&&(d.set(I,E),I.update())}function Ye(I,E){const Y=I.colorSpace,ee=I.format,ne=I.type;return I.isCompressedTexture===!0||I.isVideoTexture===!0||Y!==en&&Y!==oi&&(tt.getTransfer(Y)===pt?(ee!==Rn||ne!==Yn)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",Y)),E}function De(I){return typeof HTMLImageElement<"u"&&I instanceof HTMLImageElement?(c.width=I.naturalWidth||I.width,c.height=I.naturalHeight||I.height):typeof VideoFrame<"u"&&I instanceof VideoFrame?(c.width=I.displayWidth,c.height=I.displayHeight):(c.width=I.width,c.height=I.height),c}this.allocateTextureUnit=B,this.resetTextureUnits=N,this.setTexture2D=V,this.setTexture2DArray=D,this.setTexture3D=O,this.setTextureCube=F,this.rebindTextures=me,this.setupRenderTarget=P,this.updateRenderTargetMipmap=Le,this.updateMultisampleRenderTarget=se,this.setupDepthRenderbuffer=we,this.setupFrameBufferTexture=re,this.useMultisampledRTT=oe}function oy(i,e){function t(n,r=oi){let s;const a=tt.getTransfer(r);if(n===Yn)return i.UNSIGNED_BYTE;if(n===Pc)return i.UNSIGNED_SHORT_4_4_4_4;if(n===Lc)return i.UNSIGNED_SHORT_5_5_5_1;if(n===Wh)return i.UNSIGNED_INT_5_9_9_9_REV;if(n===Xh)return i.UNSIGNED_INT_10F_11F_11F_REV;if(n===Hh)return i.BYTE;if(n===Gh)return i.SHORT;if(n===Rs)return i.UNSIGNED_SHORT;if(n===Ic)return i.INT;if(n===Zi)return i.UNSIGNED_INT;if(n===kn)return i.FLOAT;if(n===di)return i.HALF_FLOAT;if(n===qh)return i.ALPHA;if(n===Yh)return i.RGB;if(n===Rn)return i.RGBA;if(n===Is)return i.DEPTH_COMPONENT;if(n===Ps)return i.DEPTH_STENCIL;if(n===Dc)return i.RED;if(n===Nc)return i.RED_INTEGER;if(n===jh)return i.RG;if(n===Oc)return i.RG_INTEGER;if(n===Uc)return i.RGBA_INTEGER;if(n===Fa||n===Ba||n===ka||n===za)if(a===pt)if(s=e.get("WEBGL_compressed_texture_s3tc_srgb"),s!==null){if(n===Fa)return s.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===Ba)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===ka)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===za)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(s=e.get("WEBGL_compressed_texture_s3tc"),s!==null){if(n===Fa)return s.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===Ba)return s.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===ka)return s.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===za)return s.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===Fl||n===Bl||n===kl||n===zl)if(s=e.get("WEBGL_compressed_texture_pvrtc"),s!==null){if(n===Fl)return s.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===Bl)return s.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===kl)return s.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===zl)return s.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===Vl||n===Hl||n===Gl)if(s=e.get("WEBGL_compressed_texture_etc"),s!==null){if(n===Vl||n===Hl)return a===pt?s.COMPRESSED_SRGB8_ETC2:s.COMPRESSED_RGB8_ETC2;if(n===Gl)return a===pt?s.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:s.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(n===Wl||n===Xl||n===ql||n===Yl||n===jl||n===$l||n===Kl||n===Zl||n===Jl||n===Ql||n===ec||n===tc||n===nc||n===ic)if(s=e.get("WEBGL_compressed_texture_astc"),s!==null){if(n===Wl)return a===pt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:s.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===Xl)return a===pt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:s.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===ql)return a===pt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:s.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===Yl)return a===pt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:s.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===jl)return a===pt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:s.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===$l)return a===pt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:s.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===Kl)return a===pt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:s.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===Zl)return a===pt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:s.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===Jl)return a===pt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:s.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===Ql)return a===pt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:s.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===ec)return a===pt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:s.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===tc)return a===pt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:s.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===nc)return a===pt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:s.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===ic)return a===pt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:s.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===rc||n===sc||n===ac)if(s=e.get("EXT_texture_compression_bptc"),s!==null){if(n===rc)return a===pt?s.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:s.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===sc)return s.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===ac)return s.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===oc||n===lc||n===cc||n===uc)if(s=e.get("EXT_texture_compression_rgtc"),s!==null){if(n===oc)return s.COMPRESSED_RED_RGTC1_EXT;if(n===lc)return s.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===cc)return s.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===uc)return s.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===Cs?i.UNSIGNED_INT_24_8:i[n]!==void 0?i[n]:null}return{convert:t}}const ly=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,cy=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class uy{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t){if(this.texture===null){const n=new ff(e.texture);(e.depthNear!==t.depthNear||e.depthFar!==t.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=n}}getMesh(e){if(this.texture!==null&&this.mesh===null){const t=e.cameras[0].viewport,n=new wt({vertexShader:ly,fragmentShader:cy,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new ht(new yn(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class dy extends Jr{constructor(e,t){super();const n=this;let r=null,s=1,a=null,o="local-floor",l=1,c=null,d=null,u=null,h=null,p=null,g=null;const v=typeof XRWebGLBinding<"u",m=new uy,f={},b=t.getContextAttributes();let _=null,x=null;const R=[],M=[],A=new Ce;let w=null;const S=new Kt;S.viewport=new rt;const y=new Kt;y.viewport=new rt;const T=[S,y],N=new bg;let B=null,k=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(G){let X=R[G];return X===void 0&&(X=new Ko,R[G]=X),X.getTargetRaySpace()},this.getControllerGrip=function(G){let X=R[G];return X===void 0&&(X=new Ko,R[G]=X),X.getGripSpace()},this.getHand=function(G){let X=R[G];return X===void 0&&(X=new Ko,R[G]=X),X.getHandSpace()};function V(G){const X=M.indexOf(G.inputSource);if(X===-1)return;const re=R[X];re!==void 0&&(re.update(G.inputSource,G.frame,c||a),re.dispatchEvent({type:G.type,data:G.inputSource}))}function D(){r.removeEventListener("select",V),r.removeEventListener("selectstart",V),r.removeEventListener("selectend",V),r.removeEventListener("squeeze",V),r.removeEventListener("squeezestart",V),r.removeEventListener("squeezeend",V),r.removeEventListener("end",D),r.removeEventListener("inputsourceschange",O);for(let G=0;G<R.length;G++){const X=M[G];X!==null&&(M[G]=null,R[G].disconnect(X))}B=null,k=null,m.reset();for(const G in f)delete f[G];e.setRenderTarget(_),p=null,h=null,u=null,r=null,x=null,ae.stop(),n.isPresenting=!1,e.setPixelRatio(w),e.setSize(A.width,A.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(G){s=G,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(G){o=G,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||a},this.setReferenceSpace=function(G){c=G},this.getBaseLayer=function(){return h!==null?h:p},this.getBinding=function(){return u===null&&v&&(u=new XRWebGLBinding(r,t)),u},this.getFrame=function(){return g},this.getSession=function(){return r},this.setSession=async function(G){if(r=G,r!==null){if(_=e.getRenderTarget(),r.addEventListener("select",V),r.addEventListener("selectstart",V),r.addEventListener("selectend",V),r.addEventListener("squeeze",V),r.addEventListener("squeezestart",V),r.addEventListener("squeezeend",V),r.addEventListener("end",D),r.addEventListener("inputsourceschange",O),b.xrCompatible!==!0&&await t.makeXRCompatible(),w=e.getPixelRatio(),e.getSize(A),v&&"createProjectionLayer"in XRWebGLBinding.prototype){let re=null,ye=null,fe=null;b.depth&&(fe=b.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,re=b.stencil?Ps:Is,ye=b.stencil?Cs:Zi);const we={colorFormat:t.RGBA8,depthFormat:fe,scaleFactor:s};u=this.getBinding(),h=u.createProjectionLayer(we),r.updateRenderState({layers:[h]}),e.setPixelRatio(1),e.setSize(h.textureWidth,h.textureHeight,!1),x=new Vn(h.textureWidth,h.textureHeight,{format:Rn,type:Yn,depthTexture:new hf(h.textureWidth,h.textureHeight,ye,void 0,void 0,void 0,void 0,void 0,void 0,re),stencilBuffer:b.stencil,colorSpace:e.outputColorSpace,samples:b.antialias?4:0,resolveDepthBuffer:h.ignoreDepthValues===!1,resolveStencilBuffer:h.ignoreDepthValues===!1})}else{const re={antialias:b.antialias,alpha:!0,depth:b.depth,stencil:b.stencil,framebufferScaleFactor:s};p=new XRWebGLLayer(r,t,re),r.updateRenderState({baseLayer:p}),e.setPixelRatio(1),e.setSize(p.framebufferWidth,p.framebufferHeight,!1),x=new Vn(p.framebufferWidth,p.framebufferHeight,{format:Rn,type:Yn,colorSpace:e.outputColorSpace,stencilBuffer:b.stencil,resolveDepthBuffer:p.ignoreDepthValues===!1,resolveStencilBuffer:p.ignoreDepthValues===!1})}x.isXRRenderTarget=!0,this.setFoveation(l),c=null,a=await r.requestReferenceSpace(o),ae.setContext(r),ae.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(r!==null)return r.environmentBlendMode},this.getDepthTexture=function(){return m.getDepthTexture()};function O(G){for(let X=0;X<G.removed.length;X++){const re=G.removed[X],ye=M.indexOf(re);ye>=0&&(M[ye]=null,R[ye].disconnect(re))}for(let X=0;X<G.added.length;X++){const re=G.added[X];let ye=M.indexOf(re);if(ye===-1){for(let we=0;we<R.length;we++)if(we>=M.length){M.push(re),ye=we;break}else if(M[we]===null){M[we]=re,ye=we;break}if(ye===-1)break}const fe=R[ye];fe&&fe.connect(re)}}const F=new U,z=new U;function j(G,X,re){F.setFromMatrixPosition(X.matrixWorld),z.setFromMatrixPosition(re.matrixWorld);const ye=F.distanceTo(z),fe=X.projectionMatrix.elements,we=re.projectionMatrix.elements,me=fe[14]/(fe[10]-1),P=fe[14]/(fe[10]+1),Le=(fe[9]+1)/fe[5],Te=(fe[9]-1)/fe[5],ge=(fe[8]-1)/fe[0],se=(we[8]+1)/we[0],ze=me*ge,oe=me*se,Se=ye/(-ge+se),Ye=Se*-ge;if(X.matrixWorld.decompose(G.position,G.quaternion,G.scale),G.translateX(Ye),G.translateZ(Se),G.matrixWorld.compose(G.position,G.quaternion,G.scale),G.matrixWorldInverse.copy(G.matrixWorld).invert(),fe[10]===-1)G.projectionMatrix.copy(X.projectionMatrix),G.projectionMatrixInverse.copy(X.projectionMatrixInverse);else{const De=me+Se,I=P+Se,E=ze-Ye,Y=oe+(ye-Ye),ee=Le*P/I*De,ne=Te*P/I*De;G.projectionMatrix.makePerspective(E,Y,ee,ne,De,I),G.projectionMatrixInverse.copy(G.projectionMatrix).invert()}}function te(G,X){X===null?G.matrixWorld.copy(G.matrix):G.matrixWorld.multiplyMatrices(X.matrixWorld,G.matrix),G.matrixWorldInverse.copy(G.matrixWorld).invert()}this.updateCamera=function(G){if(r===null)return;let X=G.near,re=G.far;m.texture!==null&&(m.depthNear>0&&(X=m.depthNear),m.depthFar>0&&(re=m.depthFar)),N.near=y.near=S.near=X,N.far=y.far=S.far=re,(B!==N.near||k!==N.far)&&(r.updateRenderState({depthNear:N.near,depthFar:N.far}),B=N.near,k=N.far),N.layers.mask=G.layers.mask|6,S.layers.mask=N.layers.mask&3,y.layers.mask=N.layers.mask&5;const ye=G.parent,fe=N.cameras;te(N,ye);for(let we=0;we<fe.length;we++)te(fe[we],ye);fe.length===2?j(N,S,y):N.projectionMatrix.copy(S.projectionMatrix),L(G,N,ye)};function L(G,X,re){re===null?G.matrix.copy(X.matrixWorld):(G.matrix.copy(re.matrixWorld),G.matrix.invert(),G.matrix.multiply(X.matrixWorld)),G.matrix.decompose(G.position,G.quaternion,G.scale),G.updateMatrixWorld(!0),G.projectionMatrix.copy(X.projectionMatrix),G.projectionMatrixInverse.copy(X.projectionMatrixInverse),G.isPerspectiveCamera&&(G.fov=Vr*2*Math.atan(1/G.projectionMatrix.elements[5]),G.zoom=1)}this.getCamera=function(){return N},this.getFoveation=function(){if(!(h===null&&p===null))return l},this.setFoveation=function(G){l=G,h!==null&&(h.fixedFoveation=G),p!==null&&p.fixedFoveation!==void 0&&(p.fixedFoveation=G)},this.hasDepthSensing=function(){return m.texture!==null},this.getDepthSensingMesh=function(){return m.getMesh(N)},this.getCameraTexture=function(G){return f[G]};let $=null;function Z(G,X){if(d=X.getViewerPose(c||a),g=X,d!==null){const re=d.views;p!==null&&(e.setRenderTargetFramebuffer(x,p.framebuffer),e.setRenderTarget(x));let ye=!1;re.length!==N.cameras.length&&(N.cameras.length=0,ye=!0);for(let P=0;P<re.length;P++){const Le=re[P];let Te=null;if(p!==null)Te=p.getViewport(Le);else{const se=u.getViewSubImage(h,Le);Te=se.viewport,P===0&&(e.setRenderTargetTextures(x,se.colorTexture,se.depthStencilTexture),e.setRenderTarget(x))}let ge=T[P];ge===void 0&&(ge=new Kt,ge.layers.enable(P),ge.viewport=new rt,T[P]=ge),ge.matrix.fromArray(Le.transform.matrix),ge.matrix.decompose(ge.position,ge.quaternion,ge.scale),ge.projectionMatrix.fromArray(Le.projectionMatrix),ge.projectionMatrixInverse.copy(ge.projectionMatrix).invert(),ge.viewport.set(Te.x,Te.y,Te.width,Te.height),P===0&&(N.matrix.copy(ge.matrix),N.matrix.decompose(N.position,N.quaternion,N.scale)),ye===!0&&N.cameras.push(ge)}const fe=r.enabledFeatures;if(fe&&fe.includes("depth-sensing")&&r.depthUsage=="gpu-optimized"&&v){u=n.getBinding();const P=u.getDepthInformation(re[0]);P&&P.isValid&&P.texture&&m.init(P,r.renderState)}if(fe&&fe.includes("camera-access")&&v){e.state.unbindTexture(),u=n.getBinding();for(let P=0;P<re.length;P++){const Le=re[P].camera;if(Le){let Te=f[Le];Te||(Te=new ff,f[Le]=Te);const ge=u.getCameraImage(Le);Te.sourceTexture=ge}}}}for(let re=0;re<R.length;re++){const ye=M[re],fe=R[re];ye!==null&&fe!==void 0&&fe.update(ye,X,c||a)}$&&$(G,X),X.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:X}),g=null}const ae=new _f;ae.setAnimationLoop(Z),this.setAnimationLoop=function(G){$=G},this.dispose=function(){}}}const Gi=new xn,hy=new qe;function fy(i,e){function t(m,f){m.matrixAutoUpdate===!0&&m.updateMatrix(),f.value.copy(m.matrix)}function n(m,f){f.color.getRGB(m.fogColor.value,nf(i)),f.isFog?(m.fogNear.value=f.near,m.fogFar.value=f.far):f.isFogExp2&&(m.fogDensity.value=f.density)}function r(m,f,b,_,x){f.isMeshBasicMaterial||f.isMeshLambertMaterial?s(m,f):f.isMeshToonMaterial?(s(m,f),u(m,f)):f.isMeshPhongMaterial?(s(m,f),d(m,f)):f.isMeshStandardMaterial?(s(m,f),h(m,f),f.isMeshPhysicalMaterial&&p(m,f,x)):f.isMeshMatcapMaterial?(s(m,f),g(m,f)):f.isMeshDepthMaterial?s(m,f):f.isMeshDistanceMaterial?(s(m,f),v(m,f)):f.isMeshNormalMaterial?s(m,f):f.isLineBasicMaterial?(a(m,f),f.isLineDashedMaterial&&o(m,f)):f.isPointsMaterial?l(m,f,b,_):f.isSpriteMaterial?c(m,f):f.isShadowMaterial?(m.color.value.copy(f.color),m.opacity.value=f.opacity):f.isShaderMaterial&&(f.uniformsNeedUpdate=!1)}function s(m,f){m.opacity.value=f.opacity,f.color&&m.diffuse.value.copy(f.color),f.emissive&&m.emissive.value.copy(f.emissive).multiplyScalar(f.emissiveIntensity),f.map&&(m.map.value=f.map,t(f.map,m.mapTransform)),f.alphaMap&&(m.alphaMap.value=f.alphaMap,t(f.alphaMap,m.alphaMapTransform)),f.bumpMap&&(m.bumpMap.value=f.bumpMap,t(f.bumpMap,m.bumpMapTransform),m.bumpScale.value=f.bumpScale,f.side===cn&&(m.bumpScale.value*=-1)),f.normalMap&&(m.normalMap.value=f.normalMap,t(f.normalMap,m.normalMapTransform),m.normalScale.value.copy(f.normalScale),f.side===cn&&m.normalScale.value.negate()),f.displacementMap&&(m.displacementMap.value=f.displacementMap,t(f.displacementMap,m.displacementMapTransform),m.displacementScale.value=f.displacementScale,m.displacementBias.value=f.displacementBias),f.emissiveMap&&(m.emissiveMap.value=f.emissiveMap,t(f.emissiveMap,m.emissiveMapTransform)),f.specularMap&&(m.specularMap.value=f.specularMap,t(f.specularMap,m.specularMapTransform)),f.alphaTest>0&&(m.alphaTest.value=f.alphaTest);const b=e.get(f),_=b.envMap,x=b.envMapRotation;_&&(m.envMap.value=_,Gi.copy(x),Gi.x*=-1,Gi.y*=-1,Gi.z*=-1,_.isCubeTexture&&_.isRenderTargetTexture===!1&&(Gi.y*=-1,Gi.z*=-1),m.envMapRotation.value.setFromMatrix4(hy.makeRotationFromEuler(Gi)),m.flipEnvMap.value=_.isCubeTexture&&_.isRenderTargetTexture===!1?-1:1,m.reflectivity.value=f.reflectivity,m.ior.value=f.ior,m.refractionRatio.value=f.refractionRatio),f.lightMap&&(m.lightMap.value=f.lightMap,m.lightMapIntensity.value=f.lightMapIntensity,t(f.lightMap,m.lightMapTransform)),f.aoMap&&(m.aoMap.value=f.aoMap,m.aoMapIntensity.value=f.aoMapIntensity,t(f.aoMap,m.aoMapTransform))}function a(m,f){m.diffuse.value.copy(f.color),m.opacity.value=f.opacity,f.map&&(m.map.value=f.map,t(f.map,m.mapTransform))}function o(m,f){m.dashSize.value=f.dashSize,m.totalSize.value=f.dashSize+f.gapSize,m.scale.value=f.scale}function l(m,f,b,_){m.diffuse.value.copy(f.color),m.opacity.value=f.opacity,m.size.value=f.size*b,m.scale.value=_*.5,f.map&&(m.map.value=f.map,t(f.map,m.uvTransform)),f.alphaMap&&(m.alphaMap.value=f.alphaMap,t(f.alphaMap,m.alphaMapTransform)),f.alphaTest>0&&(m.alphaTest.value=f.alphaTest)}function c(m,f){m.diffuse.value.copy(f.color),m.opacity.value=f.opacity,m.rotation.value=f.rotation,f.map&&(m.map.value=f.map,t(f.map,m.mapTransform)),f.alphaMap&&(m.alphaMap.value=f.alphaMap,t(f.alphaMap,m.alphaMapTransform)),f.alphaTest>0&&(m.alphaTest.value=f.alphaTest)}function d(m,f){m.specular.value.copy(f.specular),m.shininess.value=Math.max(f.shininess,1e-4)}function u(m,f){f.gradientMap&&(m.gradientMap.value=f.gradientMap)}function h(m,f){m.metalness.value=f.metalness,f.metalnessMap&&(m.metalnessMap.value=f.metalnessMap,t(f.metalnessMap,m.metalnessMapTransform)),m.roughness.value=f.roughness,f.roughnessMap&&(m.roughnessMap.value=f.roughnessMap,t(f.roughnessMap,m.roughnessMapTransform)),f.envMap&&(m.envMapIntensity.value=f.envMapIntensity)}function p(m,f,b){m.ior.value=f.ior,f.sheen>0&&(m.sheenColor.value.copy(f.sheenColor).multiplyScalar(f.sheen),m.sheenRoughness.value=f.sheenRoughness,f.sheenColorMap&&(m.sheenColorMap.value=f.sheenColorMap,t(f.sheenColorMap,m.sheenColorMapTransform)),f.sheenRoughnessMap&&(m.sheenRoughnessMap.value=f.sheenRoughnessMap,t(f.sheenRoughnessMap,m.sheenRoughnessMapTransform))),f.clearcoat>0&&(m.clearcoat.value=f.clearcoat,m.clearcoatRoughness.value=f.clearcoatRoughness,f.clearcoatMap&&(m.clearcoatMap.value=f.clearcoatMap,t(f.clearcoatMap,m.clearcoatMapTransform)),f.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=f.clearcoatRoughnessMap,t(f.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),f.clearcoatNormalMap&&(m.clearcoatNormalMap.value=f.clearcoatNormalMap,t(f.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(f.clearcoatNormalScale),f.side===cn&&m.clearcoatNormalScale.value.negate())),f.dispersion>0&&(m.dispersion.value=f.dispersion),f.iridescence>0&&(m.iridescence.value=f.iridescence,m.iridescenceIOR.value=f.iridescenceIOR,m.iridescenceThicknessMinimum.value=f.iridescenceThicknessRange[0],m.iridescenceThicknessMaximum.value=f.iridescenceThicknessRange[1],f.iridescenceMap&&(m.iridescenceMap.value=f.iridescenceMap,t(f.iridescenceMap,m.iridescenceMapTransform)),f.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=f.iridescenceThicknessMap,t(f.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),f.transmission>0&&(m.transmission.value=f.transmission,m.transmissionSamplerMap.value=b.texture,m.transmissionSamplerSize.value.set(b.width,b.height),f.transmissionMap&&(m.transmissionMap.value=f.transmissionMap,t(f.transmissionMap,m.transmissionMapTransform)),m.thickness.value=f.thickness,f.thicknessMap&&(m.thicknessMap.value=f.thicknessMap,t(f.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=f.attenuationDistance,m.attenuationColor.value.copy(f.attenuationColor)),f.anisotropy>0&&(m.anisotropyVector.value.set(f.anisotropy*Math.cos(f.anisotropyRotation),f.anisotropy*Math.sin(f.anisotropyRotation)),f.anisotropyMap&&(m.anisotropyMap.value=f.anisotropyMap,t(f.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=f.specularIntensity,m.specularColor.value.copy(f.specularColor),f.specularColorMap&&(m.specularColorMap.value=f.specularColorMap,t(f.specularColorMap,m.specularColorMapTransform)),f.specularIntensityMap&&(m.specularIntensityMap.value=f.specularIntensityMap,t(f.specularIntensityMap,m.specularIntensityMapTransform))}function g(m,f){f.matcap&&(m.matcap.value=f.matcap)}function v(m,f){const b=e.get(f).light;m.referencePosition.value.setFromMatrixPosition(b.matrixWorld),m.nearDistance.value=b.shadow.camera.near,m.farDistance.value=b.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:r}}function py(i,e,t,n){let r={},s={},a=[];const o=i.getParameter(i.MAX_UNIFORM_BUFFER_BINDINGS);function l(b,_){const x=_.program;n.uniformBlockBinding(b,x)}function c(b,_){let x=r[b.id];x===void 0&&(g(b),x=d(b),r[b.id]=x,b.addEventListener("dispose",m));const R=_.program;n.updateUBOMapping(b,R);const M=e.render.frame;s[b.id]!==M&&(h(b),s[b.id]=M)}function d(b){const _=u();b.__bindingPointIndex=_;const x=i.createBuffer(),R=b.__size,M=b.usage;return i.bindBuffer(i.UNIFORM_BUFFER,x),i.bufferData(i.UNIFORM_BUFFER,R,M),i.bindBuffer(i.UNIFORM_BUFFER,null),i.bindBufferBase(i.UNIFORM_BUFFER,_,x),x}function u(){for(let b=0;b<o;b++)if(a.indexOf(b)===-1)return a.push(b),b;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function h(b){const _=r[b.id],x=b.uniforms,R=b.__cache;i.bindBuffer(i.UNIFORM_BUFFER,_);for(let M=0,A=x.length;M<A;M++){const w=Array.isArray(x[M])?x[M]:[x[M]];for(let S=0,y=w.length;S<y;S++){const T=w[S];if(p(T,M,S,R)===!0){const N=T.__offset,B=Array.isArray(T.value)?T.value:[T.value];let k=0;for(let V=0;V<B.length;V++){const D=B[V],O=v(D);typeof D=="number"||typeof D=="boolean"?(T.__data[0]=D,i.bufferSubData(i.UNIFORM_BUFFER,N+k,T.__data)):D.isMatrix3?(T.__data[0]=D.elements[0],T.__data[1]=D.elements[1],T.__data[2]=D.elements[2],T.__data[3]=0,T.__data[4]=D.elements[3],T.__data[5]=D.elements[4],T.__data[6]=D.elements[5],T.__data[7]=0,T.__data[8]=D.elements[6],T.__data[9]=D.elements[7],T.__data[10]=D.elements[8],T.__data[11]=0):(D.toArray(T.__data,k),k+=O.storage/Float32Array.BYTES_PER_ELEMENT)}i.bufferSubData(i.UNIFORM_BUFFER,N,T.__data)}}}i.bindBuffer(i.UNIFORM_BUFFER,null)}function p(b,_,x,R){const M=b.value,A=_+"_"+x;if(R[A]===void 0)return typeof M=="number"||typeof M=="boolean"?R[A]=M:R[A]=M.clone(),!0;{const w=R[A];if(typeof M=="number"||typeof M=="boolean"){if(w!==M)return R[A]=M,!0}else if(w.equals(M)===!1)return w.copy(M),!0}return!1}function g(b){const _=b.uniforms;let x=0;const R=16;for(let A=0,w=_.length;A<w;A++){const S=Array.isArray(_[A])?_[A]:[_[A]];for(let y=0,T=S.length;y<T;y++){const N=S[y],B=Array.isArray(N.value)?N.value:[N.value];for(let k=0,V=B.length;k<V;k++){const D=B[k],O=v(D),F=x%R,z=F%O.boundary,j=F+z;x+=z,j!==0&&R-j<O.storage&&(x+=R-j),N.__data=new Float32Array(O.storage/Float32Array.BYTES_PER_ELEMENT),N.__offset=x,x+=O.storage}}}const M=x%R;return M>0&&(x+=R-M),b.__size=x,b.__cache={},this}function v(b){const _={boundary:0,storage:0};return typeof b=="number"||typeof b=="boolean"?(_.boundary=4,_.storage=4):b.isVector2?(_.boundary=8,_.storage=8):b.isVector3||b.isColor?(_.boundary=16,_.storage=12):b.isVector4?(_.boundary=16,_.storage=16):b.isMatrix3?(_.boundary=48,_.storage=48):b.isMatrix4?(_.boundary=64,_.storage=64):b.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",b),_}function m(b){const _=b.target;_.removeEventListener("dispose",m);const x=a.indexOf(_.__bindingPointIndex);a.splice(x,1),i.deleteBuffer(r[_.id]),delete r[_.id],delete s[_.id]}function f(){for(const b in r)i.deleteBuffer(r[b]);a=[],r={},s={}}return{bind:l,update:c,dispose:f}}class my{constructor(e={}){const{canvas:t=_m(),context:n=null,depth:r=!0,stencil:s=!1,alpha:a=!1,antialias:o=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:d="default",failIfMajorPerformanceCaveat:u=!1,reversedDepthBuffer:h=!1}=e;this.isWebGLRenderer=!0;let p;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");p=n.getContextAttributes().alpha}else p=a;const g=new Uint32Array(4),v=new Int32Array(4);let m=null,f=null;const b=[],_=[];this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=Pi,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const x=this;let R=!1;this._outputColorSpace=_t;let M=0,A=0,w=null,S=-1,y=null;const T=new rt,N=new rt;let B=null;const k=new Ie(0);let V=0,D=t.width,O=t.height,F=1,z=null,j=null;const te=new rt(0,0,D,O),L=new rt(0,0,D,O);let $=!1;const Z=new Hc;let ae=!1,G=!1;const X=new qe,re=new U,ye=new rt,fe={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let we=!1;function me(){return w===null?F:1}let P=n;function Le(C,W){return t.getContext(C,W)}try{const C={alpha:!0,depth:r,stencil:s,antialias:o,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:d,failIfMajorPerformanceCaveat:u};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${Rc}`),t.addEventListener("webglcontextlost",ve,!1),t.addEventListener("webglcontextrestored",Pe,!1),t.addEventListener("webglcontextcreationerror",ce,!1),P===null){const W="webgl2";if(P=Le(W,C),P===null)throw Le(W)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(C){throw console.error("THREE.WebGLRenderer: "+C.message),C}let Te,ge,se,ze,oe,Se,Ye,De,I,E,Y,ee,ne,K,xe,le,Ue,Fe,de,Ae,Ge,Be,Me,Ke;function H(){Te=new T_(P),Te.init(),Be=new oy(P,Te),ge=new __(P,Te,e,Be),se=new sy(P,Te),ge.reversedDepthBuffer&&h&&se.buffers.depth.setReversed(!0),ze=new R_(P),oe=new qx,Se=new ay(P,Te,se,oe,ge,Be,ze),Ye=new y_(x),De=new E_(x),I=new Ng(P),Me=new g_(P,I),E=new A_(P,I,ze,Me),Y=new I_(P,E,I,ze),de=new C_(P,ge,Se),le=new x_(oe),ee=new Xx(x,Ye,De,Te,ge,Me,le),ne=new fy(x,oe),K=new jx,xe=new ey(Te),Fe=new m_(x,Ye,De,se,Y,p,l),Ue=new iy(x,Y,ge),Ke=new py(P,ze,ge,se),Ae=new v_(P,Te,ze),Ge=new w_(P,Te,ze),ze.programs=ee.programs,x.capabilities=ge,x.extensions=Te,x.properties=oe,x.renderLists=K,x.shadowMap=Ue,x.state=se,x.info=ze}H();const he=new dy(x,P);this.xr=he,this.getContext=function(){return P},this.getContextAttributes=function(){return P.getContextAttributes()},this.forceContextLoss=function(){const C=Te.get("WEBGL_lose_context");C&&C.loseContext()},this.forceContextRestore=function(){const C=Te.get("WEBGL_lose_context");C&&C.restoreContext()},this.getPixelRatio=function(){return F},this.setPixelRatio=function(C){C!==void 0&&(F=C,this.setSize(D,O,!1))},this.getSize=function(C){return C.set(D,O)},this.setSize=function(C,W,J=!0){if(he.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}D=C,O=W,t.width=Math.floor(C*F),t.height=Math.floor(W*F),J===!0&&(t.style.width=C+"px",t.style.height=W+"px"),this.setViewport(0,0,C,W)},this.getDrawingBufferSize=function(C){return C.set(D*F,O*F).floor()},this.setDrawingBufferSize=function(C,W,J){D=C,O=W,F=J,t.width=Math.floor(C*J),t.height=Math.floor(W*J),this.setViewport(0,0,C,W)},this.getCurrentViewport=function(C){return C.copy(T)},this.getViewport=function(C){return C.copy(te)},this.setViewport=function(C,W,J,Q){C.isVector4?te.set(C.x,C.y,C.z,C.w):te.set(C,W,J,Q),se.viewport(T.copy(te).multiplyScalar(F).round())},this.getScissor=function(C){return C.copy(L)},this.setScissor=function(C,W,J,Q){C.isVector4?L.set(C.x,C.y,C.z,C.w):L.set(C,W,J,Q),se.scissor(N.copy(L).multiplyScalar(F).round())},this.getScissorTest=function(){return $},this.setScissorTest=function(C){se.setScissorTest($=C)},this.setOpaqueSort=function(C){z=C},this.setTransparentSort=function(C){j=C},this.getClearColor=function(C){return C.copy(Fe.getClearColor())},this.setClearColor=function(){Fe.setClearColor(...arguments)},this.getClearAlpha=function(){return Fe.getClearAlpha()},this.setClearAlpha=function(){Fe.setClearAlpha(...arguments)},this.clear=function(C=!0,W=!0,J=!0){let Q=0;if(C){let q=!1;if(w!==null){const ue=w.texture.format;q=ue===Uc||ue===Oc||ue===Nc}if(q){const ue=w.texture.type,Ee=ue===Yn||ue===Zi||ue===Rs||ue===Cs||ue===Pc||ue===Lc,Ne=Fe.getClearColor(),Re=Fe.getClearAlpha(),He=Ne.r,We=Ne.g,ke=Ne.b;Ee?(g[0]=He,g[1]=We,g[2]=ke,g[3]=Re,P.clearBufferuiv(P.COLOR,0,g)):(v[0]=He,v[1]=We,v[2]=ke,v[3]=Re,P.clearBufferiv(P.COLOR,0,v))}else Q|=P.COLOR_BUFFER_BIT}W&&(Q|=P.DEPTH_BUFFER_BIT),J&&(Q|=P.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),P.clear(Q)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){t.removeEventListener("webglcontextlost",ve,!1),t.removeEventListener("webglcontextrestored",Pe,!1),t.removeEventListener("webglcontextcreationerror",ce,!1),Fe.dispose(),K.dispose(),xe.dispose(),oe.dispose(),Ye.dispose(),De.dispose(),Y.dispose(),Me.dispose(),Ke.dispose(),ee.dispose(),he.dispose(),he.removeEventListener("sessionstart",Gn),he.removeEventListener("sessionend",uu),Ui.stop()};function ve(C){C.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),R=!0}function Pe(){console.log("THREE.WebGLRenderer: Context Restored."),R=!1;const C=ze.autoReset,W=Ue.enabled,J=Ue.autoUpdate,Q=Ue.needsUpdate,q=Ue.type;H(),ze.autoReset=C,Ue.enabled=W,Ue.autoUpdate=J,Ue.needsUpdate=Q,Ue.type=q}function ce(C){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",C.statusMessage)}function ie(C){const W=C.target;W.removeEventListener("dispose",ie),Oe(W)}function Oe(C){je(C),oe.remove(C)}function je(C){const W=oe.get(C).programs;W!==void 0&&(W.forEach(function(J){ee.releaseProgram(J)}),C.isShaderMaterial&&ee.releaseShaderCache(C))}this.renderBufferDirect=function(C,W,J,Q,q,ue){W===null&&(W=fe);const Ee=q.isMesh&&q.matrixWorld.determinant()<0,Ne=tp(C,W,J,Q,q);se.setMaterial(Q,Ee);let Re=J.index,He=1;if(Q.wireframe===!0){if(Re=E.getWireframeAttribute(J),Re===void 0)return;He=2}const We=J.drawRange,ke=J.attributes.position;let et=We.start*He,ft=(We.start+We.count)*He;ue!==null&&(et=Math.max(et,ue.start*He),ft=Math.min(ft,(ue.start+ue.count)*He)),Re!==null?(et=Math.max(et,0),ft=Math.min(ft,Re.count)):ke!=null&&(et=Math.max(et,0),ft=Math.min(ft,ke.count));const Ct=ft-et;if(Ct<0||Ct===1/0)return;Me.setup(q,Q,Ne,J,Re);let yt,mt=Ae;if(Re!==null&&(yt=I.get(Re),mt=Ge,mt.setIndex(yt)),q.isMesh)Q.wireframe===!0?(se.setLineWidth(Q.wireframeLinewidth*me()),mt.setMode(P.LINES)):mt.setMode(P.TRIANGLES);else if(q.isLine){let Ve=Q.linewidth;Ve===void 0&&(Ve=1),se.setLineWidth(Ve*me()),q.isLineSegments?mt.setMode(P.LINES):q.isLineLoop?mt.setMode(P.LINE_LOOP):mt.setMode(P.LINE_STRIP)}else q.isPoints?mt.setMode(P.POINTS):q.isSprite&&mt.setMode(P.TRIANGLES);if(q.isBatchedMesh)if(q._multiDrawInstances!==null)Os("THREE.WebGLRenderer: renderMultiDrawInstances has been deprecated and will be removed in r184. Append to renderMultiDraw arguments and use indirection."),mt.renderMultiDrawInstances(q._multiDrawStarts,q._multiDrawCounts,q._multiDrawCount,q._multiDrawInstances);else if(Te.get("WEBGL_multi_draw"))mt.renderMultiDraw(q._multiDrawStarts,q._multiDrawCounts,q._multiDrawCount);else{const Ve=q._multiDrawStarts,Tt=q._multiDrawCounts,it=q._multiDrawCount,hn=Re?I.get(Re).bytesPerElement:1,nr=oe.get(Q).currentProgram.getUniforms();for(let fn=0;fn<it;fn++)nr.setValue(P,"_gl_DrawID",fn),mt.render(Ve[fn]/hn,Tt[fn])}else if(q.isInstancedMesh)mt.renderInstances(et,Ct,q.count);else if(J.isInstancedBufferGeometry){const Ve=J._maxInstanceCount!==void 0?J._maxInstanceCount:1/0,Tt=Math.min(J.instanceCount,Ve);mt.renderInstances(et,Ct,Tt)}else mt.render(et,Ct)};function gt(C,W,J){C.transparent===!0&&C.side===Et&&C.forceSinglePass===!1?(C.side=cn,C.needsUpdate=!0,Qs(C,W,J),C.side=fi,C.needsUpdate=!0,Qs(C,W,J),C.side=Et):Qs(C,W,J)}this.compile=function(C,W,J=null){J===null&&(J=C),f=xe.get(J),f.init(W),_.push(f),J.traverseVisible(function(q){q.isLight&&q.layers.test(W.layers)&&(f.pushLight(q),q.castShadow&&f.pushShadow(q))}),C!==J&&C.traverseVisible(function(q){q.isLight&&q.layers.test(W.layers)&&(f.pushLight(q),q.castShadow&&f.pushShadow(q))}),f.setupLights();const Q=new Set;return C.traverse(function(q){if(!(q.isMesh||q.isPoints||q.isLine||q.isSprite))return;const ue=q.material;if(ue)if(Array.isArray(ue))for(let Ee=0;Ee<ue.length;Ee++){const Ne=ue[Ee];gt(Ne,J,q),Q.add(Ne)}else gt(ue,J,q),Q.add(ue)}),f=_.pop(),Q},this.compileAsync=function(C,W,J=null){const Q=this.compile(C,W,J);return new Promise(q=>{function ue(){if(Q.forEach(function(Ee){oe.get(Ee).currentProgram.isReady()&&Q.delete(Ee)}),Q.size===0){q(C);return}setTimeout(ue,10)}Te.get("KHR_parallel_shader_compile")!==null?ue():setTimeout(ue,10)})};let st=null;function Zn(C){st&&st(C)}function Gn(){Ui.stop()}function uu(){Ui.start()}const Ui=new _f;Ui.setAnimationLoop(Zn),typeof self<"u"&&Ui.setContext(self),this.setAnimationLoop=function(C){st=C,he.setAnimationLoop(C),C===null?Ui.stop():Ui.start()},he.addEventListener("sessionstart",Gn),he.addEventListener("sessionend",uu),this.render=function(C,W){if(W!==void 0&&W.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(R===!0)return;if(C.matrixWorldAutoUpdate===!0&&C.updateMatrixWorld(),W.parent===null&&W.matrixWorldAutoUpdate===!0&&W.updateMatrixWorld(),he.enabled===!0&&he.isPresenting===!0&&(he.cameraAutoUpdate===!0&&he.updateCamera(W),W=he.getCamera()),C.isScene===!0&&C.onBeforeRender(x,C,W,w),f=xe.get(C,_.length),f.init(W),_.push(f),X.multiplyMatrices(W.projectionMatrix,W.matrixWorldInverse),Z.setFromProjectionMatrix(X,qn,W.reversedDepth),G=this.localClippingEnabled,ae=le.init(this.clippingPlanes,G),m=K.get(C,b.length),m.init(),b.push(m),he.enabled===!0&&he.isPresenting===!0){const ue=x.xr.getDepthSensingMesh();ue!==null&&wo(ue,W,-1/0,x.sortObjects)}wo(C,W,0,x.sortObjects),m.finish(),x.sortObjects===!0&&m.sort(z,j),we=he.enabled===!1||he.isPresenting===!1||he.hasDepthSensing()===!1,we&&Fe.addToRenderList(m,C),this.info.render.frame++,ae===!0&&le.beginShadows();const J=f.state.shadowsArray;Ue.render(J,C,W),ae===!0&&le.endShadows(),this.info.autoReset===!0&&this.info.reset();const Q=m.opaque,q=m.transmissive;if(f.setupLights(),W.isArrayCamera){const ue=W.cameras;if(q.length>0)for(let Ee=0,Ne=ue.length;Ee<Ne;Ee++){const Re=ue[Ee];hu(Q,q,C,Re)}we&&Fe.render(C);for(let Ee=0,Ne=ue.length;Ee<Ne;Ee++){const Re=ue[Ee];du(m,C,Re,Re.viewport)}}else q.length>0&&hu(Q,q,C,W),we&&Fe.render(C),du(m,C,W);w!==null&&A===0&&(Se.updateMultisampleRenderTarget(w),Se.updateRenderTargetMipmap(w)),C.isScene===!0&&C.onAfterRender(x,C,W),Me.resetDefaultState(),S=-1,y=null,_.pop(),_.length>0?(f=_[_.length-1],ae===!0&&le.setGlobalState(x.clippingPlanes,f.state.camera)):f=null,b.pop(),b.length>0?m=b[b.length-1]:m=null};function wo(C,W,J,Q){if(C.visible===!1)return;if(C.layers.test(W.layers)){if(C.isGroup)J=C.renderOrder;else if(C.isLOD)C.autoUpdate===!0&&C.update(W);else if(C.isLight)f.pushLight(C),C.castShadow&&f.pushShadow(C);else if(C.isSprite){if(!C.frustumCulled||Z.intersectsSprite(C)){Q&&ye.setFromMatrixPosition(C.matrixWorld).applyMatrix4(X);const Ee=Y.update(C),Ne=C.material;Ne.visible&&m.push(C,Ee,Ne,J,ye.z,null)}}else if((C.isMesh||C.isLine||C.isPoints)&&(!C.frustumCulled||Z.intersectsObject(C))){const Ee=Y.update(C),Ne=C.material;if(Q&&(C.boundingSphere!==void 0?(C.boundingSphere===null&&C.computeBoundingSphere(),ye.copy(C.boundingSphere.center)):(Ee.boundingSphere===null&&Ee.computeBoundingSphere(),ye.copy(Ee.boundingSphere.center)),ye.applyMatrix4(C.matrixWorld).applyMatrix4(X)),Array.isArray(Ne)){const Re=Ee.groups;for(let He=0,We=Re.length;He<We;He++){const ke=Re[He],et=Ne[ke.materialIndex];et&&et.visible&&m.push(C,Ee,et,J,ye.z,ke)}}else Ne.visible&&m.push(C,Ee,Ne,J,ye.z,null)}}const ue=C.children;for(let Ee=0,Ne=ue.length;Ee<Ne;Ee++)wo(ue[Ee],W,J,Q)}function du(C,W,J,Q){const q=C.opaque,ue=C.transmissive,Ee=C.transparent;f.setupLightsView(J),ae===!0&&le.setGlobalState(x.clippingPlanes,J),Q&&se.viewport(T.copy(Q)),q.length>0&&Js(q,W,J),ue.length>0&&Js(ue,W,J),Ee.length>0&&Js(Ee,W,J),se.buffers.depth.setTest(!0),se.buffers.depth.setMask(!0),se.buffers.color.setMask(!0),se.setPolygonOffset(!1)}function hu(C,W,J,Q){if((J.isScene===!0?J.overrideMaterial:null)!==null)return;f.state.transmissionRenderTarget[Q.id]===void 0&&(f.state.transmissionRenderTarget[Q.id]=new Vn(1,1,{generateMipmaps:!0,type:Te.has("EXT_color_buffer_half_float")||Te.has("EXT_color_buffer_float")?di:Yn,minFilter:Gt,samples:4,stencilBuffer:s,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:tt.workingColorSpace}));const ue=f.state.transmissionRenderTarget[Q.id],Ee=Q.viewport||T;ue.setSize(Ee.z*x.transmissionResolutionScale,Ee.w*x.transmissionResolutionScale);const Ne=x.getRenderTarget(),Re=x.getActiveCubeFace(),He=x.getActiveMipmapLevel();x.setRenderTarget(ue),x.getClearColor(k),V=x.getClearAlpha(),V<1&&x.setClearColor(16777215,.5),x.clear(),we&&Fe.render(J);const We=x.toneMapping;x.toneMapping=Pi;const ke=Q.viewport;if(Q.viewport!==void 0&&(Q.viewport=void 0),f.setupLightsView(Q),ae===!0&&le.setGlobalState(x.clippingPlanes,Q),Js(C,J,Q),Se.updateMultisampleRenderTarget(ue),Se.updateRenderTargetMipmap(ue),Te.has("WEBGL_multisampled_render_to_texture")===!1){let et=!1;for(let ft=0,Ct=W.length;ft<Ct;ft++){const yt=W[ft],mt=yt.object,Ve=yt.geometry,Tt=yt.material,it=yt.group;if(Tt.side===Et&&mt.layers.test(Q.layers)){const hn=Tt.side;Tt.side=cn,Tt.needsUpdate=!0,fu(mt,J,Q,Ve,Tt,it),Tt.side=hn,Tt.needsUpdate=!0,et=!0}}et===!0&&(Se.updateMultisampleRenderTarget(ue),Se.updateRenderTargetMipmap(ue))}x.setRenderTarget(Ne,Re,He),x.setClearColor(k,V),ke!==void 0&&(Q.viewport=ke),x.toneMapping=We}function Js(C,W,J){const Q=W.isScene===!0?W.overrideMaterial:null;for(let q=0,ue=C.length;q<ue;q++){const Ee=C[q],Ne=Ee.object,Re=Ee.geometry,He=Ee.group;let We=Ee.material;We.allowOverride===!0&&Q!==null&&(We=Q),Ne.layers.test(J.layers)&&fu(Ne,W,J,Re,We,He)}}function fu(C,W,J,Q,q,ue){C.onBeforeRender(x,W,J,Q,q,ue),C.modelViewMatrix.multiplyMatrices(J.matrixWorldInverse,C.matrixWorld),C.normalMatrix.getNormalMatrix(C.modelViewMatrix),q.onBeforeRender(x,W,J,Q,C,ue),q.transparent===!0&&q.side===Et&&q.forceSinglePass===!1?(q.side=cn,q.needsUpdate=!0,x.renderBufferDirect(J,W,Q,q,C,ue),q.side=fi,q.needsUpdate=!0,x.renderBufferDirect(J,W,Q,q,C,ue),q.side=Et):x.renderBufferDirect(J,W,Q,q,C,ue),C.onAfterRender(x,W,J,Q,q,ue)}function Qs(C,W,J){W.isScene!==!0&&(W=fe);const Q=oe.get(C),q=f.state.lights,ue=f.state.shadowsArray,Ee=q.state.version,Ne=ee.getParameters(C,q.state,ue,W,J),Re=ee.getProgramCacheKey(Ne);let He=Q.programs;Q.environment=C.isMeshStandardMaterial?W.environment:null,Q.fog=W.fog,Q.envMap=(C.isMeshStandardMaterial?De:Ye).get(C.envMap||Q.environment),Q.envMapRotation=Q.environment!==null&&C.envMap===null?W.environmentRotation:C.envMapRotation,He===void 0&&(C.addEventListener("dispose",ie),He=new Map,Q.programs=He);let We=He.get(Re);if(We!==void 0){if(Q.currentProgram===We&&Q.lightsStateVersion===Ee)return mu(C,Ne),We}else Ne.uniforms=ee.getUniforms(C),C.onBeforeCompile(Ne,x),We=ee.acquireProgram(Ne,Re),He.set(Re,We),Q.uniforms=Ne.uniforms;const ke=Q.uniforms;return(!C.isShaderMaterial&&!C.isRawShaderMaterial||C.clipping===!0)&&(ke.clippingPlanes=le.uniform),mu(C,Ne),Q.needsLights=ip(C),Q.lightsStateVersion=Ee,Q.needsLights&&(ke.ambientLightColor.value=q.state.ambient,ke.lightProbe.value=q.state.probe,ke.directionalLights.value=q.state.directional,ke.directionalLightShadows.value=q.state.directionalShadow,ke.spotLights.value=q.state.spot,ke.spotLightShadows.value=q.state.spotShadow,ke.rectAreaLights.value=q.state.rectArea,ke.ltc_1.value=q.state.rectAreaLTC1,ke.ltc_2.value=q.state.rectAreaLTC2,ke.pointLights.value=q.state.point,ke.pointLightShadows.value=q.state.pointShadow,ke.hemisphereLights.value=q.state.hemi,ke.directionalShadowMap.value=q.state.directionalShadowMap,ke.directionalShadowMatrix.value=q.state.directionalShadowMatrix,ke.spotShadowMap.value=q.state.spotShadowMap,ke.spotLightMatrix.value=q.state.spotLightMatrix,ke.spotLightMap.value=q.state.spotLightMap,ke.pointShadowMap.value=q.state.pointShadowMap,ke.pointShadowMatrix.value=q.state.pointShadowMatrix),Q.currentProgram=We,Q.uniformsList=null,We}function pu(C){if(C.uniformsList===null){const W=C.currentProgram.getUniforms();C.uniformsList=Va.seqWithValue(W.seq,C.uniforms)}return C.uniformsList}function mu(C,W){const J=oe.get(C);J.outputColorSpace=W.outputColorSpace,J.batching=W.batching,J.batchingColor=W.batchingColor,J.instancing=W.instancing,J.instancingColor=W.instancingColor,J.instancingMorph=W.instancingMorph,J.skinning=W.skinning,J.morphTargets=W.morphTargets,J.morphNormals=W.morphNormals,J.morphColors=W.morphColors,J.morphTargetsCount=W.morphTargetsCount,J.numClippingPlanes=W.numClippingPlanes,J.numIntersection=W.numClipIntersection,J.vertexAlphas=W.vertexAlphas,J.vertexTangents=W.vertexTangents,J.toneMapping=W.toneMapping}function tp(C,W,J,Q,q){W.isScene!==!0&&(W=fe),Se.resetTextureUnits();const ue=W.fog,Ee=Q.isMeshStandardMaterial?W.environment:null,Ne=w===null?x.outputColorSpace:w.isXRRenderTarget===!0?w.texture.colorSpace:en,Re=(Q.isMeshStandardMaterial?De:Ye).get(Q.envMap||Ee),He=Q.vertexColors===!0&&!!J.attributes.color&&J.attributes.color.itemSize===4,We=!!J.attributes.tangent&&(!!Q.normalMap||Q.anisotropy>0),ke=!!J.morphAttributes.position,et=!!J.morphAttributes.normal,ft=!!J.morphAttributes.color;let Ct=Pi;Q.toneMapped&&(w===null||w.isXRRenderTarget===!0)&&(Ct=x.toneMapping);const yt=J.morphAttributes.position||J.morphAttributes.normal||J.morphAttributes.color,mt=yt!==void 0?yt.length:0,Ve=oe.get(Q),Tt=f.state.lights;if(ae===!0&&(G===!0||C!==y)){const Yt=C===y&&Q.id===S;le.setState(Q,C,Yt)}let it=!1;Q.version===Ve.__version?(Ve.needsLights&&Ve.lightsStateVersion!==Tt.state.version||Ve.outputColorSpace!==Ne||q.isBatchedMesh&&Ve.batching===!1||!q.isBatchedMesh&&Ve.batching===!0||q.isBatchedMesh&&Ve.batchingColor===!0&&q.colorTexture===null||q.isBatchedMesh&&Ve.batchingColor===!1&&q.colorTexture!==null||q.isInstancedMesh&&Ve.instancing===!1||!q.isInstancedMesh&&Ve.instancing===!0||q.isSkinnedMesh&&Ve.skinning===!1||!q.isSkinnedMesh&&Ve.skinning===!0||q.isInstancedMesh&&Ve.instancingColor===!0&&q.instanceColor===null||q.isInstancedMesh&&Ve.instancingColor===!1&&q.instanceColor!==null||q.isInstancedMesh&&Ve.instancingMorph===!0&&q.morphTexture===null||q.isInstancedMesh&&Ve.instancingMorph===!1&&q.morphTexture!==null||Ve.envMap!==Re||Q.fog===!0&&Ve.fog!==ue||Ve.numClippingPlanes!==void 0&&(Ve.numClippingPlanes!==le.numPlanes||Ve.numIntersection!==le.numIntersection)||Ve.vertexAlphas!==He||Ve.vertexTangents!==We||Ve.morphTargets!==ke||Ve.morphNormals!==et||Ve.morphColors!==ft||Ve.toneMapping!==Ct||Ve.morphTargetsCount!==mt)&&(it=!0):(it=!0,Ve.__version=Q.version);let hn=Ve.currentProgram;it===!0&&(hn=Qs(Q,W,q));let nr=!1,fn=!1,ss=!1;const At=hn.getUniforms(),bn=Ve.uniforms;if(se.useProgram(hn.program)&&(nr=!0,fn=!0,ss=!0),Q.id!==S&&(S=Q.id,fn=!0),nr||y!==C){se.buffers.depth.getReversed()&&C.reversedDepth!==!0&&(C._reversedDepth=!0,C.updateProjectionMatrix()),At.setValue(P,"projectionMatrix",C.projectionMatrix),At.setValue(P,"viewMatrix",C.matrixWorldInverse);const nn=At.map.cameraPosition;nn!==void 0&&nn.setValue(P,re.setFromMatrixPosition(C.matrixWorld)),ge.logarithmicDepthBuffer&&At.setValue(P,"logDepthBufFC",2/(Math.log(C.far+1)/Math.LN2)),(Q.isMeshPhongMaterial||Q.isMeshToonMaterial||Q.isMeshLambertMaterial||Q.isMeshBasicMaterial||Q.isMeshStandardMaterial||Q.isShaderMaterial)&&At.setValue(P,"isOrthographic",C.isOrthographicCamera===!0),y!==C&&(y=C,fn=!0,ss=!0)}if(q.isSkinnedMesh){At.setOptional(P,q,"bindMatrix"),At.setOptional(P,q,"bindMatrixInverse");const Yt=q.skeleton;Yt&&(Yt.boneTexture===null&&Yt.computeBoneTexture(),At.setValue(P,"boneTexture",Yt.boneTexture,Se))}q.isBatchedMesh&&(At.setOptional(P,q,"batchingTexture"),At.setValue(P,"batchingTexture",q._matricesTexture,Se),At.setOptional(P,q,"batchingIdTexture"),At.setValue(P,"batchingIdTexture",q._indirectTexture,Se),At.setOptional(P,q,"batchingColorTexture"),q._colorsTexture!==null&&At.setValue(P,"batchingColorTexture",q._colorsTexture,Se));const Sn=J.morphAttributes;if((Sn.position!==void 0||Sn.normal!==void 0||Sn.color!==void 0)&&de.update(q,J,hn),(fn||Ve.receiveShadow!==q.receiveShadow)&&(Ve.receiveShadow=q.receiveShadow,At.setValue(P,"receiveShadow",q.receiveShadow)),Q.isMeshGouraudMaterial&&Q.envMap!==null&&(bn.envMap.value=Re,bn.flipEnvMap.value=Re.isCubeTexture&&Re.isRenderTargetTexture===!1?-1:1),Q.isMeshStandardMaterial&&Q.envMap===null&&W.environment!==null&&(bn.envMapIntensity.value=W.environmentIntensity),fn&&(At.setValue(P,"toneMappingExposure",x.toneMappingExposure),Ve.needsLights&&np(bn,ss),ue&&Q.fog===!0&&ne.refreshFogUniforms(bn,ue),ne.refreshMaterialUniforms(bn,Q,F,O,f.state.transmissionRenderTarget[C.id]),Va.upload(P,pu(Ve),bn,Se)),Q.isShaderMaterial&&Q.uniformsNeedUpdate===!0&&(Va.upload(P,pu(Ve),bn,Se),Q.uniformsNeedUpdate=!1),Q.isSpriteMaterial&&At.setValue(P,"center",q.center),At.setValue(P,"modelViewMatrix",q.modelViewMatrix),At.setValue(P,"normalMatrix",q.normalMatrix),At.setValue(P,"modelMatrix",q.matrixWorld),Q.isShaderMaterial||Q.isRawShaderMaterial){const Yt=Q.uniformsGroups;for(let nn=0,Ro=Yt.length;nn<Ro;nn++){const Fi=Yt[nn];Ke.update(Fi,hn),Ke.bind(Fi,hn)}}return hn}function np(C,W){C.ambientLightColor.needsUpdate=W,C.lightProbe.needsUpdate=W,C.directionalLights.needsUpdate=W,C.directionalLightShadows.needsUpdate=W,C.pointLights.needsUpdate=W,C.pointLightShadows.needsUpdate=W,C.spotLights.needsUpdate=W,C.spotLightShadows.needsUpdate=W,C.rectAreaLights.needsUpdate=W,C.hemisphereLights.needsUpdate=W}function ip(C){return C.isMeshLambertMaterial||C.isMeshToonMaterial||C.isMeshPhongMaterial||C.isMeshStandardMaterial||C.isShadowMaterial||C.isShaderMaterial&&C.lights===!0}this.getActiveCubeFace=function(){return M},this.getActiveMipmapLevel=function(){return A},this.getRenderTarget=function(){return w},this.setRenderTargetTextures=function(C,W,J){const Q=oe.get(C);Q.__autoAllocateDepthBuffer=C.resolveDepthBuffer===!1,Q.__autoAllocateDepthBuffer===!1&&(Q.__useRenderToTexture=!1),oe.get(C.texture).__webglTexture=W,oe.get(C.depthTexture).__webglTexture=Q.__autoAllocateDepthBuffer?void 0:J,Q.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(C,W){const J=oe.get(C);J.__webglFramebuffer=W,J.__useDefaultFramebuffer=W===void 0};const rp=P.createFramebuffer();this.setRenderTarget=function(C,W=0,J=0){w=C,M=W,A=J;let Q=!0,q=null,ue=!1,Ee=!1;if(C){const Re=oe.get(C);if(Re.__useDefaultFramebuffer!==void 0)se.bindFramebuffer(P.FRAMEBUFFER,null),Q=!1;else if(Re.__webglFramebuffer===void 0)Se.setupRenderTarget(C);else if(Re.__hasExternalTextures)Se.rebindTextures(C,oe.get(C.texture).__webglTexture,oe.get(C.depthTexture).__webglTexture);else if(C.depthBuffer){const ke=C.depthTexture;if(Re.__boundDepthTexture!==ke){if(ke!==null&&oe.has(ke)&&(C.width!==ke.image.width||C.height!==ke.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");Se.setupDepthRenderbuffer(C)}}const He=C.texture;(He.isData3DTexture||He.isDataArrayTexture||He.isCompressedArrayTexture)&&(Ee=!0);const We=oe.get(C).__webglFramebuffer;C.isWebGLCubeRenderTarget?(Array.isArray(We[W])?q=We[W][J]:q=We[W],ue=!0):C.samples>0&&Se.useMultisampledRTT(C)===!1?q=oe.get(C).__webglMultisampledFramebuffer:Array.isArray(We)?q=We[J]:q=We,T.copy(C.viewport),N.copy(C.scissor),B=C.scissorTest}else T.copy(te).multiplyScalar(F).floor(),N.copy(L).multiplyScalar(F).floor(),B=$;if(J!==0&&(q=rp),se.bindFramebuffer(P.FRAMEBUFFER,q)&&Q&&se.drawBuffers(C,q),se.viewport(T),se.scissor(N),se.setScissorTest(B),ue){const Re=oe.get(C.texture);P.framebufferTexture2D(P.FRAMEBUFFER,P.COLOR_ATTACHMENT0,P.TEXTURE_CUBE_MAP_POSITIVE_X+W,Re.__webglTexture,J)}else if(Ee){const Re=W;for(let He=0;He<C.textures.length;He++){const We=oe.get(C.textures[He]);P.framebufferTextureLayer(P.FRAMEBUFFER,P.COLOR_ATTACHMENT0+He,We.__webglTexture,J,Re)}}else if(C!==null&&J!==0){const Re=oe.get(C.texture);P.framebufferTexture2D(P.FRAMEBUFFER,P.COLOR_ATTACHMENT0,P.TEXTURE_2D,Re.__webglTexture,J)}S=-1},this.readRenderTargetPixels=function(C,W,J,Q,q,ue,Ee,Ne=0){if(!(C&&C.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Re=oe.get(C).__webglFramebuffer;if(C.isWebGLCubeRenderTarget&&Ee!==void 0&&(Re=Re[Ee]),Re){se.bindFramebuffer(P.FRAMEBUFFER,Re);try{const He=C.textures[Ne],We=He.format,ke=He.type;if(!ge.textureFormatReadable(We)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!ge.textureTypeReadable(ke)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}W>=0&&W<=C.width-Q&&J>=0&&J<=C.height-q&&(C.textures.length>1&&P.readBuffer(P.COLOR_ATTACHMENT0+Ne),P.readPixels(W,J,Q,q,Be.convert(We),Be.convert(ke),ue))}finally{const He=w!==null?oe.get(w).__webglFramebuffer:null;se.bindFramebuffer(P.FRAMEBUFFER,He)}}},this.readRenderTargetPixelsAsync=async function(C,W,J,Q,q,ue,Ee,Ne=0){if(!(C&&C.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let Re=oe.get(C).__webglFramebuffer;if(C.isWebGLCubeRenderTarget&&Ee!==void 0&&(Re=Re[Ee]),Re)if(W>=0&&W<=C.width-Q&&J>=0&&J<=C.height-q){se.bindFramebuffer(P.FRAMEBUFFER,Re);const He=C.textures[Ne],We=He.format,ke=He.type;if(!ge.textureFormatReadable(We))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!ge.textureTypeReadable(ke))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const et=P.createBuffer();P.bindBuffer(P.PIXEL_PACK_BUFFER,et),P.bufferData(P.PIXEL_PACK_BUFFER,ue.byteLength,P.STREAM_READ),C.textures.length>1&&P.readBuffer(P.COLOR_ATTACHMENT0+Ne),P.readPixels(W,J,Q,q,Be.convert(We),Be.convert(ke),0);const ft=w!==null?oe.get(w).__webglFramebuffer:null;se.bindFramebuffer(P.FRAMEBUFFER,ft);const Ct=P.fenceSync(P.SYNC_GPU_COMMANDS_COMPLETE,0);return P.flush(),await xm(P,Ct,4),P.bindBuffer(P.PIXEL_PACK_BUFFER,et),P.getBufferSubData(P.PIXEL_PACK_BUFFER,0,ue),P.deleteBuffer(et),P.deleteSync(Ct),ue}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(C,W=null,J=0){const Q=Math.pow(2,-J),q=Math.floor(C.image.width*Q),ue=Math.floor(C.image.height*Q),Ee=W!==null?W.x:0,Ne=W!==null?W.y:0;Se.setTexture2D(C,0),P.copyTexSubImage2D(P.TEXTURE_2D,J,0,0,Ee,Ne,q,ue),se.unbindTexture()};const sp=P.createFramebuffer(),ap=P.createFramebuffer();this.copyTextureToTexture=function(C,W,J=null,Q=null,q=0,ue=null){ue===null&&(q!==0?(Os("WebGLRenderer: copyTextureToTexture function signature has changed to support src and dst mipmap levels."),ue=q,q=0):ue=0);let Ee,Ne,Re,He,We,ke,et,ft,Ct;const yt=C.isCompressedTexture?C.mipmaps[ue]:C.image;if(J!==null)Ee=J.max.x-J.min.x,Ne=J.max.y-J.min.y,Re=J.isBox3?J.max.z-J.min.z:1,He=J.min.x,We=J.min.y,ke=J.isBox3?J.min.z:0;else{const Sn=Math.pow(2,-q);Ee=Math.floor(yt.width*Sn),Ne=Math.floor(yt.height*Sn),C.isDataArrayTexture?Re=yt.depth:C.isData3DTexture?Re=Math.floor(yt.depth*Sn):Re=1,He=0,We=0,ke=0}Q!==null?(et=Q.x,ft=Q.y,Ct=Q.z):(et=0,ft=0,Ct=0);const mt=Be.convert(W.format),Ve=Be.convert(W.type);let Tt;W.isData3DTexture?(Se.setTexture3D(W,0),Tt=P.TEXTURE_3D):W.isDataArrayTexture||W.isCompressedArrayTexture?(Se.setTexture2DArray(W,0),Tt=P.TEXTURE_2D_ARRAY):(Se.setTexture2D(W,0),Tt=P.TEXTURE_2D),P.pixelStorei(P.UNPACK_FLIP_Y_WEBGL,W.flipY),P.pixelStorei(P.UNPACK_PREMULTIPLY_ALPHA_WEBGL,W.premultiplyAlpha),P.pixelStorei(P.UNPACK_ALIGNMENT,W.unpackAlignment);const it=P.getParameter(P.UNPACK_ROW_LENGTH),hn=P.getParameter(P.UNPACK_IMAGE_HEIGHT),nr=P.getParameter(P.UNPACK_SKIP_PIXELS),fn=P.getParameter(P.UNPACK_SKIP_ROWS),ss=P.getParameter(P.UNPACK_SKIP_IMAGES);P.pixelStorei(P.UNPACK_ROW_LENGTH,yt.width),P.pixelStorei(P.UNPACK_IMAGE_HEIGHT,yt.height),P.pixelStorei(P.UNPACK_SKIP_PIXELS,He),P.pixelStorei(P.UNPACK_SKIP_ROWS,We),P.pixelStorei(P.UNPACK_SKIP_IMAGES,ke);const At=C.isDataArrayTexture||C.isData3DTexture,bn=W.isDataArrayTexture||W.isData3DTexture;if(C.isDepthTexture){const Sn=oe.get(C),Yt=oe.get(W),nn=oe.get(Sn.__renderTarget),Ro=oe.get(Yt.__renderTarget);se.bindFramebuffer(P.READ_FRAMEBUFFER,nn.__webglFramebuffer),se.bindFramebuffer(P.DRAW_FRAMEBUFFER,Ro.__webglFramebuffer);for(let Fi=0;Fi<Re;Fi++)At&&(P.framebufferTextureLayer(P.READ_FRAMEBUFFER,P.COLOR_ATTACHMENT0,oe.get(C).__webglTexture,q,ke+Fi),P.framebufferTextureLayer(P.DRAW_FRAMEBUFFER,P.COLOR_ATTACHMENT0,oe.get(W).__webglTexture,ue,Ct+Fi)),P.blitFramebuffer(He,We,Ee,Ne,et,ft,Ee,Ne,P.DEPTH_BUFFER_BIT,P.NEAREST);se.bindFramebuffer(P.READ_FRAMEBUFFER,null),se.bindFramebuffer(P.DRAW_FRAMEBUFFER,null)}else if(q!==0||C.isRenderTargetTexture||oe.has(C)){const Sn=oe.get(C),Yt=oe.get(W);se.bindFramebuffer(P.READ_FRAMEBUFFER,sp),se.bindFramebuffer(P.DRAW_FRAMEBUFFER,ap);for(let nn=0;nn<Re;nn++)At?P.framebufferTextureLayer(P.READ_FRAMEBUFFER,P.COLOR_ATTACHMENT0,Sn.__webglTexture,q,ke+nn):P.framebufferTexture2D(P.READ_FRAMEBUFFER,P.COLOR_ATTACHMENT0,P.TEXTURE_2D,Sn.__webglTexture,q),bn?P.framebufferTextureLayer(P.DRAW_FRAMEBUFFER,P.COLOR_ATTACHMENT0,Yt.__webglTexture,ue,Ct+nn):P.framebufferTexture2D(P.DRAW_FRAMEBUFFER,P.COLOR_ATTACHMENT0,P.TEXTURE_2D,Yt.__webglTexture,ue),q!==0?P.blitFramebuffer(He,We,Ee,Ne,et,ft,Ee,Ne,P.COLOR_BUFFER_BIT,P.NEAREST):bn?P.copyTexSubImage3D(Tt,ue,et,ft,Ct+nn,He,We,Ee,Ne):P.copyTexSubImage2D(Tt,ue,et,ft,He,We,Ee,Ne);se.bindFramebuffer(P.READ_FRAMEBUFFER,null),se.bindFramebuffer(P.DRAW_FRAMEBUFFER,null)}else bn?C.isDataTexture||C.isData3DTexture?P.texSubImage3D(Tt,ue,et,ft,Ct,Ee,Ne,Re,mt,Ve,yt.data):W.isCompressedArrayTexture?P.compressedTexSubImage3D(Tt,ue,et,ft,Ct,Ee,Ne,Re,mt,yt.data):P.texSubImage3D(Tt,ue,et,ft,Ct,Ee,Ne,Re,mt,Ve,yt):C.isDataTexture?P.texSubImage2D(P.TEXTURE_2D,ue,et,ft,Ee,Ne,mt,Ve,yt.data):C.isCompressedTexture?P.compressedTexSubImage2D(P.TEXTURE_2D,ue,et,ft,yt.width,yt.height,mt,yt.data):P.texSubImage2D(P.TEXTURE_2D,ue,et,ft,Ee,Ne,mt,Ve,yt);P.pixelStorei(P.UNPACK_ROW_LENGTH,it),P.pixelStorei(P.UNPACK_IMAGE_HEIGHT,hn),P.pixelStorei(P.UNPACK_SKIP_PIXELS,nr),P.pixelStorei(P.UNPACK_SKIP_ROWS,fn),P.pixelStorei(P.UNPACK_SKIP_IMAGES,ss),ue===0&&W.generateMipmaps&&P.generateMipmap(Tt),se.unbindTexture()},this.initRenderTarget=function(C){oe.get(C).__webglFramebuffer===void 0&&Se.setupRenderTarget(C)},this.initTexture=function(C){C.isCubeTexture?Se.setTextureCube(C,0):C.isData3DTexture?Se.setTexture3D(C,0):C.isDataArrayTexture||C.isCompressedArrayTexture?Se.setTexture2DArray(C,0):Se.setTexture2D(C,0),se.unbindTexture()},this.resetState=function(){M=0,A=0,w=null,se.reset(),Me.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return qn}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const t=this.getContext();t.drawingBufferColorSpace=tt._getDrawingBufferColorSpace(e),t.unpackColorSpace=tt._getUnpackColorSpace()}}const gy=`
  varying vec2 vUv;
  void main() {
    vUv = uv;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`,vy=`
  precision highp float;
  varying vec2 vUv;
  uniform float uTime;
  uniform float uFlow;
  uniform float uDensity;
  uniform float uStrength;
  uniform float uSeed;
  uniform float uBreath;
  uniform vec3 uCool;
  uniform vec3 uWarm;

  float hash21(vec2 p) {
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
  }
  float noise2(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(
      mix(hash21(i), hash21(i + vec2(1.0, 0.0)), u.x),
      mix(hash21(i + vec2(0.0, 1.0)), hash21(i + vec2(1.0, 1.0)), u.x),
      u.y
    );
  }
  float fbm(vec2 p) {
    float v = 0.0;
    float a = .5;
    for (int i = 0; i < 3; ++i) {
      v += a * noise2(p);
      p = p * 2.03 + vec2(3.73, 4.17);
      a *= .5;
    }
    return v;
  }
  void main() {
    vec2 uv = vUv;
    float motion = uTime * uFlow;
    vec2 drift = vec2(motion * .012, -motion * .006);
    // So a nuvem e deformada. A imagem principal da ESO nunca usa este shader.
    float domain = fbm(uv * 2.9 + drift + vec2(uSeed, uSeed * .34));
    vec2 advected = uv * vec2(4.6, 3.7) + vec2(domain * .62, -domain * .37);
    advected += drift;
    float body = fbm(advected + uSeed * .13);
    float wisps = fbm(advected * 2.8 + vec2(.0, motion * .014));
    float horizontal = uv.y - (.51 + .08 * sin(uv.x * 5.4 + uSeed));
    float band = exp(-horizontal * horizontal * 10.5);
    float edges = smoothstep(.01, .22, uv.x) * smoothstep(.01, .22, 1.0-uv.x)
      * smoothstep(.02, .18, uv.y) * smoothstep(.02, .18, 1.0-uv.y);
    float volume = smoothstep(.45, .68, body);
    float threads = smoothstep(.57, .78, wisps) * smoothstep(.35, .76, body);
    float alpha = (volume * .68 + threads * .32) * band * edges
      * uDensity * uStrength * uBreath;
    vec3 color = mix(uCool, uWarm, clamp(body * .85 + threads * .24, 0.0, 1.0));
    color *= (.68 + .56 * threads) * (1.0 + (uBreath-1.0)*.35);
    gl_FragColor = vec4(color, clamp(alpha, 0.0, .16));
    #include <colorspace_fragment>
  }
`,_y=[{name:"07 · Gás profundo",z:-225,x:-20,y:6,aspect:2.72,factor:1.55,order:2.6,opacity:.44,seed:1.7,cool:"#314778",warm:"#7853a8"},{name:"08 · Filamentos violetas",z:-195,x:12,y:-6,aspect:2.72,factor:1.54,order:3.3,opacity:.57,seed:8.3,cool:"#403d80",warm:"#ac70c5"},{name:"09 · Nuvens intermediárias",z:-169,x:-9,y:1,aspect:2.66,factor:1.5,order:3.7,opacity:.51,seed:13.6,cool:"#345a91",warm:"#8d59a8"},{name:"10 · Reflexos no gás",z:-112,x:5,y:-4,aspect:2.55,factor:1.56,order:4.6,opacity:.35,seed:23.8,cool:"#406aa3",warm:"#b47aab"},{name:"11 · Véu próximo",z:-73,x:13,y:-10,aspect:2.52,factor:1.65,order:5.3,opacity:.28,seed:31.2,cool:"#343d77",warm:"#6b578e"}];function xy(i,{reducedMotion:e=!1}={}){const t={density:.46,flow:.27,bloom:.18},n=[];for(const o of _y){const l=new wt({vertexShader:gy,fragmentShader:vy,transparent:!0,depthTest:!1,depthWrite:!1,blending:Qt,side:Et,toneMapped:!1,uniforms:{uTime:{value:0},uFlow:{value:e?0:t.flow},uDensity:{value:t.density},uStrength:{value:o.opacity},uSeed:{value:o.seed},uBreath:{value:1},uCool:{value:new Ie(o.cool)},uWarm:{value:new Ie(o.warm)}}}),c=new ht(new yn(1,1),l);c.position.set(o.x,o.y,o.z),c.renderOrder=o.order,c.userData.aspect=o.aspect,c.userData.factor=o.factor,c.userData.layerName=o.name,c.userData.breathRate=.38+o.seed%5*.045,c.userData.breathPhase=o.seed*.83,i.add(c),n.push(c)}function r(o){for(const l of n){l.material.uniforms.uTime.value=e?0:o,l.material.uniforms.uFlow.value=e?0:t.flow,l.material.uniforms.uDensity.value=t.density;const c=l.userData.breathRate,d=l.userData.breathPhase;l.material.uniforms.uBreath.value=e?1:1+.036*Math.sin(o*c+d)+.016*Math.sin(o*(c*.61)+d*1.71)}}function s(o){t.density=_e.clamp(o,0,1.5)}function a(o){t.flow=_e.clamp(o,0,1)}return{layers:n,state:t,update:r,setDensity:s,setFlow:a}}const Ha={name:"CopyShader",uniforms:{tDiffuse:{value:null},opacity:{value:1}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform float opacity;

		uniform sampler2D tDiffuse;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );
			gl_FragColor = opacity * texel;


		}`};class Xs{constructor(){this.isPass=!0,this.enabled=!0,this.needsSwap=!0,this.clear=!1,this.renderToScreen=!1}setSize(){}render(){console.error("THREE.Pass: .render() must be implemented in derived pass.")}dispose(){}}const yy=new Ws(-1,1,1,-1,0,1);class by extends Lt{constructor(){super(),this.setAttribute("position",new nt([-1,3,0,-1,-1,0,3,-1,0],3)),this.setAttribute("uv",new nt([0,2,0,0,2,0],2))}}const Sy=new by;class Mf{constructor(e){this._mesh=new ht(Sy,e)}dispose(){this._mesh.geometry.dispose()}render(e){e.render(this._mesh,yy)}get material(){return this._mesh.material}set material(e){this._mesh.material=e}}class My extends Xs{constructor(e,t="tDiffuse"){super(),this.textureID=t,this.uniforms=null,this.material=null,e instanceof wt?(this.uniforms=e.uniforms,this.material=e):e&&(this.uniforms=qa.clone(e.uniforms),this.material=new wt({name:e.name!==void 0?e.name:"unspecified",defines:Object.assign({},e.defines),uniforms:this.uniforms,vertexShader:e.vertexShader,fragmentShader:e.fragmentShader})),this._fsQuad=new Mf(this.material)}render(e,t,n){this.uniforms[this.textureID]&&(this.uniforms[this.textureID].value=n.texture),this._fsQuad.material=this.material,this.renderToScreen?(e.setRenderTarget(null),this._fsQuad.render(e)):(e.setRenderTarget(t),this.clear&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),this._fsQuad.render(e))}dispose(){this.material.dispose(),this._fsQuad.dispose()}}class Ud extends Xs{constructor(e,t){super(),this.scene=e,this.camera=t,this.clear=!0,this.needsSwap=!1,this.inverse=!1}render(e,t,n){const r=e.getContext(),s=e.state;s.buffers.color.setMask(!1),s.buffers.depth.setMask(!1),s.buffers.color.setLocked(!0),s.buffers.depth.setLocked(!0);let a,o;this.inverse?(a=0,o=1):(a=1,o=0),s.buffers.stencil.setTest(!0),s.buffers.stencil.setOp(r.REPLACE,r.REPLACE,r.REPLACE),s.buffers.stencil.setFunc(r.ALWAYS,a,4294967295),s.buffers.stencil.setClear(o),s.buffers.stencil.setLocked(!0),e.setRenderTarget(n),this.clear&&e.clear(),e.render(this.scene,this.camera),e.setRenderTarget(t),this.clear&&e.clear(),e.render(this.scene,this.camera),s.buffers.color.setLocked(!1),s.buffers.depth.setLocked(!1),s.buffers.color.setMask(!0),s.buffers.depth.setMask(!0),s.buffers.stencil.setLocked(!1),s.buffers.stencil.setFunc(r.EQUAL,1,4294967295),s.buffers.stencil.setOp(r.KEEP,r.KEEP,r.KEEP),s.buffers.stencil.setLocked(!0)}}class Ey extends Xs{constructor(){super(),this.needsSwap=!1}render(e){e.state.buffers.stencil.setLocked(!1),e.state.buffers.stencil.setTest(!1)}}class Ty{constructor(e,t){if(this.renderer=e,this._pixelRatio=e.getPixelRatio(),t===void 0){const n=e.getSize(new Ce);this._width=n.width,this._height=n.height,t=new Vn(this._width*this._pixelRatio,this._height*this._pixelRatio,{type:di}),t.texture.name="EffectComposer.rt1"}else this._width=t.width,this._height=t.height;this.renderTarget1=t,this.renderTarget2=t.clone(),this.renderTarget2.texture.name="EffectComposer.rt2",this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2,this.renderToScreen=!0,this.passes=[],this.copyPass=new My(Ha),this.copyPass.material.blending=ui,this.clock=new Sg}swapBuffers(){const e=this.readBuffer;this.readBuffer=this.writeBuffer,this.writeBuffer=e}addPass(e){this.passes.push(e),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}insertPass(e,t){this.passes.splice(t,0,e),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}removePass(e){const t=this.passes.indexOf(e);t!==-1&&this.passes.splice(t,1)}isLastEnabledPass(e){for(let t=e+1;t<this.passes.length;t++)if(this.passes[t].enabled)return!1;return!0}render(e){e===void 0&&(e=this.clock.getDelta());const t=this.renderer.getRenderTarget();let n=!1;for(let r=0,s=this.passes.length;r<s;r++){const a=this.passes[r];if(a.enabled!==!1){if(a.renderToScreen=this.renderToScreen&&this.isLastEnabledPass(r),a.render(this.renderer,this.writeBuffer,this.readBuffer,e,n),a.needsSwap){if(n){const o=this.renderer.getContext(),l=this.renderer.state.buffers.stencil;l.setFunc(o.NOTEQUAL,1,4294967295),this.copyPass.render(this.renderer,this.writeBuffer,this.readBuffer,e),l.setFunc(o.EQUAL,1,4294967295)}this.swapBuffers()}Ud!==void 0&&(a instanceof Ud?n=!0:a instanceof Ey&&(n=!1))}}this.renderer.setRenderTarget(t)}reset(e){if(e===void 0){const t=this.renderer.getSize(new Ce);this._pixelRatio=this.renderer.getPixelRatio(),this._width=t.width,this._height=t.height,e=this.renderTarget1.clone(),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.renderTarget1=e,this.renderTarget2=e.clone(),this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2}setSize(e,t){this._width=e,this._height=t;const n=this._width*this._pixelRatio,r=this._height*this._pixelRatio;this.renderTarget1.setSize(n,r),this.renderTarget2.setSize(n,r);for(let s=0;s<this.passes.length;s++)this.passes[s].setSize(n,r)}setPixelRatio(e){this._pixelRatio=e,this.setSize(this._width,this._height)}dispose(){this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.copyPass.dispose()}}class Ay extends Xs{constructor(e,t,n=null,r=null,s=null){super(),this.scene=e,this.camera=t,this.overrideMaterial=n,this.clearColor=r,this.clearAlpha=s,this.clear=!0,this.clearDepth=!1,this.needsSwap=!1,this._oldClearColor=new Ie}render(e,t,n){const r=e.autoClear;e.autoClear=!1;let s,a;this.overrideMaterial!==null&&(a=this.scene.overrideMaterial,this.scene.overrideMaterial=this.overrideMaterial),this.clearColor!==null&&(e.getClearColor(this._oldClearColor),e.setClearColor(this.clearColor,e.getClearAlpha())),this.clearAlpha!==null&&(s=e.getClearAlpha(),e.setClearAlpha(this.clearAlpha)),this.clearDepth==!0&&e.clearDepth(),e.setRenderTarget(this.renderToScreen?null:n),this.clear===!0&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),e.render(this.scene,this.camera),this.clearColor!==null&&e.setClearColor(this._oldClearColor),this.clearAlpha!==null&&e.setClearAlpha(s),this.overrideMaterial!==null&&(this.scene.overrideMaterial=a),e.autoClear=r}}const wy={uniforms:{tDiffuse:{value:null},luminosityThreshold:{value:1},smoothWidth:{value:1},defaultColor:{value:new Ie(0)},defaultOpacity:{value:0}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;

			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform sampler2D tDiffuse;
		uniform vec3 defaultColor;
		uniform float defaultOpacity;
		uniform float luminosityThreshold;
		uniform float smoothWidth;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );

			float v = luminance( texel.xyz );

			vec4 outputColor = vec4( defaultColor.rgb, defaultOpacity );

			float alpha = smoothstep( luminosityThreshold, luminosityThreshold + smoothWidth, v );

			gl_FragColor = mix( outputColor, texel, alpha );

		}`};class Yr extends Xs{constructor(e,t=1,n,r){super(),this.strength=t,this.radius=n,this.threshold=r,this.resolution=e!==void 0?new Ce(e.x,e.y):new Ce(256,256),this.clearColor=new Ie(0,0,0),this.needsSwap=!1,this.renderTargetsHorizontal=[],this.renderTargetsVertical=[],this.nMips=5;let s=Math.round(this.resolution.x/2),a=Math.round(this.resolution.y/2);this.renderTargetBright=new Vn(s,a,{type:di}),this.renderTargetBright.texture.name="UnrealBloomPass.bright",this.renderTargetBright.texture.generateMipmaps=!1;for(let d=0;d<this.nMips;d++){const u=new Vn(s,a,{type:di});u.texture.name="UnrealBloomPass.h"+d,u.texture.generateMipmaps=!1,this.renderTargetsHorizontal.push(u);const h=new Vn(s,a,{type:di});h.texture.name="UnrealBloomPass.v"+d,h.texture.generateMipmaps=!1,this.renderTargetsVertical.push(h),s=Math.round(s/2),a=Math.round(a/2)}const o=wy;this.highPassUniforms=qa.clone(o.uniforms),this.highPassUniforms.luminosityThreshold.value=r,this.highPassUniforms.smoothWidth.value=.01,this.materialHighPassFilter=new wt({uniforms:this.highPassUniforms,vertexShader:o.vertexShader,fragmentShader:o.fragmentShader}),this.separableBlurMaterials=[];const l=[3,5,7,9,11];s=Math.round(this.resolution.x/2),a=Math.round(this.resolution.y/2);for(let d=0;d<this.nMips;d++)this.separableBlurMaterials.push(this._getSeparableBlurMaterial(l[d])),this.separableBlurMaterials[d].uniforms.invSize.value=new Ce(1/s,1/a),s=Math.round(s/2),a=Math.round(a/2);this.compositeMaterial=this._getCompositeMaterial(this.nMips),this.compositeMaterial.uniforms.blurTexture1.value=this.renderTargetsVertical[0].texture,this.compositeMaterial.uniforms.blurTexture2.value=this.renderTargetsVertical[1].texture,this.compositeMaterial.uniforms.blurTexture3.value=this.renderTargetsVertical[2].texture,this.compositeMaterial.uniforms.blurTexture4.value=this.renderTargetsVertical[3].texture,this.compositeMaterial.uniforms.blurTexture5.value=this.renderTargetsVertical[4].texture,this.compositeMaterial.uniforms.bloomStrength.value=t,this.compositeMaterial.uniforms.bloomRadius.value=.1;const c=[1,.8,.6,.4,.2];this.compositeMaterial.uniforms.bloomFactors.value=c,this.bloomTintColors=[new U(1,1,1),new U(1,1,1),new U(1,1,1),new U(1,1,1),new U(1,1,1)],this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors,this.copyUniforms=qa.clone(Ha.uniforms),this.blendMaterial=new wt({uniforms:this.copyUniforms,vertexShader:Ha.vertexShader,fragmentShader:Ha.fragmentShader,blending:Qt,depthTest:!1,depthWrite:!1,transparent:!0}),this._oldClearColor=new Ie,this._oldClearAlpha=1,this._basic=new Ut,this._fsQuad=new Mf(null)}dispose(){for(let e=0;e<this.renderTargetsHorizontal.length;e++)this.renderTargetsHorizontal[e].dispose();for(let e=0;e<this.renderTargetsVertical.length;e++)this.renderTargetsVertical[e].dispose();this.renderTargetBright.dispose();for(let e=0;e<this.separableBlurMaterials.length;e++)this.separableBlurMaterials[e].dispose();this.compositeMaterial.dispose(),this.blendMaterial.dispose(),this._basic.dispose(),this._fsQuad.dispose()}setSize(e,t){let n=Math.round(e/2),r=Math.round(t/2);this.renderTargetBright.setSize(n,r);for(let s=0;s<this.nMips;s++)this.renderTargetsHorizontal[s].setSize(n,r),this.renderTargetsVertical[s].setSize(n,r),this.separableBlurMaterials[s].uniforms.invSize.value=new Ce(1/n,1/r),n=Math.round(n/2),r=Math.round(r/2)}render(e,t,n,r,s){e.getClearColor(this._oldClearColor),this._oldClearAlpha=e.getClearAlpha();const a=e.autoClear;e.autoClear=!1,e.setClearColor(this.clearColor,0),s&&e.state.buffers.stencil.setTest(!1),this.renderToScreen&&(this._fsQuad.material=this._basic,this._basic.map=n.texture,e.setRenderTarget(null),e.clear(),this._fsQuad.render(e)),this.highPassUniforms.tDiffuse.value=n.texture,this.highPassUniforms.luminosityThreshold.value=this.threshold,this._fsQuad.material=this.materialHighPassFilter,e.setRenderTarget(this.renderTargetBright),e.clear(),this._fsQuad.render(e);let o=this.renderTargetBright;for(let l=0;l<this.nMips;l++)this._fsQuad.material=this.separableBlurMaterials[l],this.separableBlurMaterials[l].uniforms.colorTexture.value=o.texture,this.separableBlurMaterials[l].uniforms.direction.value=Yr.BlurDirectionX,e.setRenderTarget(this.renderTargetsHorizontal[l]),e.clear(),this._fsQuad.render(e),this.separableBlurMaterials[l].uniforms.colorTexture.value=this.renderTargetsHorizontal[l].texture,this.separableBlurMaterials[l].uniforms.direction.value=Yr.BlurDirectionY,e.setRenderTarget(this.renderTargetsVertical[l]),e.clear(),this._fsQuad.render(e),o=this.renderTargetsVertical[l];this._fsQuad.material=this.compositeMaterial,this.compositeMaterial.uniforms.bloomStrength.value=this.strength,this.compositeMaterial.uniforms.bloomRadius.value=this.radius,this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors,e.setRenderTarget(this.renderTargetsHorizontal[0]),e.clear(),this._fsQuad.render(e),this._fsQuad.material=this.blendMaterial,this.copyUniforms.tDiffuse.value=this.renderTargetsHorizontal[0].texture,s&&e.state.buffers.stencil.setTest(!0),this.renderToScreen?(e.setRenderTarget(null),this._fsQuad.render(e)):(e.setRenderTarget(n),this._fsQuad.render(e)),e.setClearColor(this._oldClearColor,this._oldClearAlpha),e.autoClear=a}_getSeparableBlurMaterial(e){const t=[];for(let n=0;n<e;n++)t.push(.39894*Math.exp(-.5*n*n/(e*e))/e);return new wt({defines:{KERNEL_RADIUS:e},uniforms:{colorTexture:{value:null},invSize:{value:new Ce(.5,.5)},direction:{value:new Ce(.5,.5)},gaussianCoefficients:{value:t}},vertexShader:`varying vec2 vUv;
				void main() {
					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
				}`,fragmentShader:`#include <common>
				varying vec2 vUv;
				uniform sampler2D colorTexture;
				uniform vec2 invSize;
				uniform vec2 direction;
				uniform float gaussianCoefficients[KERNEL_RADIUS];

				void main() {
					float weightSum = gaussianCoefficients[0];
					vec3 diffuseSum = texture2D( colorTexture, vUv ).rgb * weightSum;
					for( int i = 1; i < KERNEL_RADIUS; i ++ ) {
						float x = float(i);
						float w = gaussianCoefficients[i];
						vec2 uvOffset = direction * invSize * x;
						vec3 sample1 = texture2D( colorTexture, vUv + uvOffset ).rgb;
						vec3 sample2 = texture2D( colorTexture, vUv - uvOffset ).rgb;
						diffuseSum += (sample1 + sample2) * w;
						weightSum += 2.0 * w;
					}
					gl_FragColor = vec4(diffuseSum/weightSum, 1.0);
				}`})}_getCompositeMaterial(e){return new wt({defines:{NUM_MIPS:e},uniforms:{blurTexture1:{value:null},blurTexture2:{value:null},blurTexture3:{value:null},blurTexture4:{value:null},blurTexture5:{value:null},bloomStrength:{value:1},bloomFactors:{value:null},bloomTintColors:{value:null},bloomRadius:{value:0}},vertexShader:`varying vec2 vUv;
				void main() {
					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
				}`,fragmentShader:`varying vec2 vUv;
				uniform sampler2D blurTexture1;
				uniform sampler2D blurTexture2;
				uniform sampler2D blurTexture3;
				uniform sampler2D blurTexture4;
				uniform sampler2D blurTexture5;
				uniform float bloomStrength;
				uniform float bloomRadius;
				uniform float bloomFactors[NUM_MIPS];
				uniform vec3 bloomTintColors[NUM_MIPS];

				float lerpBloomFactor(const in float factor) {
					float mirrorFactor = 1.2 - factor;
					return mix(factor, mirrorFactor, bloomRadius);
				}

				void main() {
					gl_FragColor = bloomStrength * ( lerpBloomFactor(bloomFactors[0]) * vec4(bloomTintColors[0], 1.0) * texture2D(blurTexture1, vUv) +
						lerpBloomFactor(bloomFactors[1]) * vec4(bloomTintColors[1], 1.0) * texture2D(blurTexture2, vUv) +
						lerpBloomFactor(bloomFactors[2]) * vec4(bloomTintColors[2], 1.0) * texture2D(blurTexture3, vUv) +
						lerpBloomFactor(bloomFactors[3]) * vec4(bloomTintColors[3], 1.0) * texture2D(blurTexture4, vUv) +
						lerpBloomFactor(bloomFactors[4]) * vec4(bloomTintColors[4], 1.0) * texture2D(blurTexture5, vUv) );
				}`})}}Yr.BlurDirectionX=new Ce(1,0);Yr.BlurDirectionY=new Ce(0,1);function Ry(i,e,t,{initial:n=.48,reducedMotion:r=!1}={}){const s={intensity:r?.23:n},a=new Ty(i);a.renderToScreen=!1,a.setPixelRatio(1);const o=new Yr(new Ce(512,288),.72,.3,.72);a.addPass(new Ay(e,t)),a.addPass(o);const l=new af,c=new Ws(-1,1,1,-1,0,1),d=new wt({depthTest:!1,depthWrite:!1,transparent:!0,blending:Qt,toneMapped:!1,uniforms:{uTexture:{value:null},uOpacity:{value:s.intensity}},vertexShader:"varying vec2 vUv;void main(){vUv=uv;gl_Position=vec4(position.xy,0.0,1.0);}",fragmentShader:`uniform sampler2D uTexture; uniform float uOpacity;varying vec2 vUv;
      void main(){vec3 c=texture2D(uTexture,vUv).rgb;gl_FragColor=vec4(c*uOpacity,1.0);}`});l.add(new ht(new yn(2,2),d));function u(g,v,m=.34){const f=_e.clamp(m,.2,.5);a.setSize(Math.max(64,Math.floor(g*f)),Math.max(64,Math.floor(v*f)))}function h(g=!0,v=!0){if(!v){t.layers.set(0),i.setRenderTarget(null),i.render(e,t);return}g&&(t.layers.set(1),a.render(),t.layers.set(0),d.uniforms.uTexture.value=a.readBuffer.texture),i.setRenderTarget(null),i.render(e,t);const m=i.autoClear;i.autoClear=!1,i.render(l,c),i.autoClear=m}function p(g){s.intensity=_e.clamp(g,0,1.5),d.uniforms.uOpacity.value=s.intensity}return{state:s,render:h,resize:u,setIntensity:p}}const Cy=1.32;function Iy(i,e){const t={uSkyActive:{value:0},uSkyBasis:{value:new $e},uSkyEye:{value:new Ce},uSkyCenter:{value:new Ce},uSkySize:{value:new Ce},uSkyDistance:{value:1},uSkyTanHalf:{value:1},uSkyAspect:{value:e.aspect},uSkyPan:{value:new Ce},uSkyZoom:{value:1}},n={active:!1,projection:"angular-sky",panX:0,panY:0,approach:0,zoom:1,newTextures:0,newSurfaces:0},r=new dt,s=new dt,a=new dt,o=new U,l=new U,c=new U,d=new U,u=new qe,h=new xn(0,0,0,"YXZ");i.material.onBeforeCompile=v=>{Object.assign(v.uniforms,t),v.vertexShader=v.vertexShader.replace("#include <common>",`#include <common>
      varying vec2 vSkyScreen;`).replace("#include <project_vertex>",`#include <project_vertex>
      vSkyScreen=gl_Position.xy/gl_Position.w;`),v.fragmentShader=v.fragmentShader.replace("#include <common>",`#include <common>
      varying vec2 vSkyScreen;
      uniform float uSkyActive,uSkyDistance,uSkyTanHalf,uSkyAspect,uSkyZoom;
      uniform mat3 uSkyBasis;
      uniform vec2 uSkyEye,uSkyCenter,uSkySize,uSkyPan;`).replace("#include <map_fragment>",`
      if(uSkyActive>.5){
        // A projeção de partida fica fixa. O giro acrescenta o mesmo
        // deslocamento angular a todos os pixels, sem cisalhar a fotografia.
        // Zoom uniforme no espaço da tela, centrado na direção de chegada.
        // A mesma escala nos dois eixos conserva o formato durante o giro.
        vec2 screen=vSkyScreen/uSkyZoom;
        vec3 ray=uSkyBasis*vec3(screen.x*uSkyTanHalf*uSkyAspect,screen.y*uSkyTanHalf,-1.);
        vec2 uv=(uSkyEye+ray.xy*uSkyDistance/max(.00001,-ray.z)-uSkyCenter)/uSkySize+.5+uSkyPan;
        vec4 sky=texture2D(map,clamp(uv,vec2(0.),vec2(1.)));
        // Fora da região fotografada há céu escuro, sem repetir/esticar bordas.
        vec2 edge=smoothstep(vec2(0.),vec2(.035),uv)*(1.-smoothstep(vec2(.965),vec2(1.),uv));
        sky.rgb=mix(vec3(.0006,.0004,.0012),sky.rgb,edge.x*edge.y);
        diffuseColor*=sky;
      }else{
        #include <map_fragment>
      }`)},i.material.customProgramCacheKey=()=>"orion-angular-sky-v2",i.material.needsUpdate=!0;function p(){return n.active?!1:(e.updateWorldMatrix(!0,!1),i.updateWorldMatrix(!0,!1),e.getWorldPosition(o),e.getWorldQuaternion(r),s.copy(r).invert(),i.getWorldPosition(l),i.getWorldScale(c),t.uSkyBasis.value.setFromMatrix4(u.makeRotationFromQuaternion(r)),t.uSkyEye.value.set(o.x,o.y),t.uSkyCenter.value.set(l.x,l.y),t.uSkySize.value.set(c.x,c.y),t.uSkyDistance.value=o.z-l.z,t.uSkyTanHalf.value=Math.tan(_e.degToRad(e.fov/2)),e.add(i),i.quaternion.identity(),t.uSkyActive.value=1,n.active=!0,g(0),!0)}function g(v=n.approach){if(!n.active)return;n.approach=_e.clamp(Number.isFinite(v)?v:0,0,1),n.zoom=1+(Cy-1)*n.approach,t.uSkyZoom.value=n.zoom,e.getWorldQuaternion(a),a.premultiply(s),h.setFromQuaternion(a,"YXZ"),d.set(-h.y,h.x,0).applyQuaternion(r);const m=t.uSkyDistance.value;t.uSkyPan.value.set(d.x*m/c.x,d.y*m/c.y),n.panX=t.uSkyPan.value.x,n.panY=t.uSkyPan.value.y,t.uSkyAspect.value=e.aspect;const f=Math.max(e.near*2,Math.min(100,e.far*.5)),b=2*f*Math.tan(_e.degToRad(e.fov/2));i.position.set(0,0,-f),i.scale.set(b*e.aspect*1.0001,b*1.0001,1),i.quaternion.identity()}return{begin:p,update:g,state:n,uniforms:t,photo:i}}const Ir=i=>Math.min(1,Math.max(0,i)),vs=(i,e,t)=>{const n=Ir((i-e)/(t-e));return n*n*n*(n*(n*6-15)+10)},Py=2550,_s=(i,e,t)=>{const n=Ir((i-e)/(t-e));return n*n*(3-2*n)};function Ly({scene:i,camera:e,star:t,glows:n,layers:r,gasLayers:s,selectiveBloom:a,flash:o,reducedMotion:l,onArrive:c,sky:d=null}){const u=[{object:n.halo,scale:156,opacity:.22},{object:n.soft,scale:118,opacity:.3},{object:n.main,scale:66,opacity:.8},{object:n.core,scale:18,opacity:1}];let h=52,p=t.position.z;const g=new U(t.position.x,t.position.y,p+53),v=l?850:Py,m=l?80:700,f=l?0:160,b=l?.7:.77,_=new U,x=new dt,R=new dt,M=new qe,A=new U(0,1,0),w=a.state.intensity;let S=!1,y=!1,T=0,N=0,B=1;const k=s.map(me=>[me,me.material.uniforms.uStrength.value,1]),V=r.filter(me=>me.material?.opacity!==void 0).map(me=>[me,me.material.opacity,1]),D=[...new Set([...s,...r.filter(me=>me!==d?.photo&&me.material?.opacity!==void 0)])].map(me=>({layer:me,quaternion:new dt})),O=new U,F=new U,z=me=>F.copy(me.position).sub(e.position).dot(O),j=me=>_s(z(me),6,55),te=l?0:540,L=new Float32Array(te*6),$=new Float32Array(te*6),Z=[],ae=[new Ie("#c8d5ff"),new Ie("#9f8dd8"),new Ie("#fce1b4")];for(let me=0;me<te;me++){const P=Math.random()*Math.PI*2,Le=6+Math.sqrt(Math.random())*100,Te=Math.cos(P)*Le,ge=Math.sin(P)*Le*.65,se=-14-Math.random()*200,ze=3+Math.random()*18,oe=.65+Math.random()*.8;Z.push({x:Te,y:ge,z:se,len:ze,speed:oe});const Se=ae[me%ae.length],Ye=me*6;for(let De=0;De<2;De++)$[Ye+De*3]=Se.r,$[Ye+De*3+1]=Se.g,$[Ye+De*3+2]=Se.b}const G=new Lt;G.setAttribute("position",new ct(L,3).setUsage(Zh)),G.setAttribute("color",new ct($,3));const X=new Gc({vertexColors:!0,transparent:!0,opacity:0,depthTest:!1,depthWrite:!1,blending:Qt}),re=new uf(G,X);re.frustumCulled=!1,re.renderOrder=18,re.visible=!1,e.add(re);function ye(me,P){if(S||y)return!1;t=me,n=P,p=t.position.z,g.set(t.position.x,t.position.y,p+53);for(const[Le,Te]of["halo","soft","main","core"].entries())u[Le].object=n[Te];return!0}function fe(me=performance.now()){if(S||y)return!1;e.updateWorldMatrix(!0,!1),i.attach(e),e.updateWorldMatrix(!0,!1),_.copy(e.position),x.copy(e.quaternion),h=e.fov,d?.begin(),B=1,O.set(0,0,-1).applyQuaternion(e.quaternion);for(const P of D)P.quaternion.copy(P.layer.quaternion);for(const P of k)P[1]=P[0].material.uniforms.uStrength.value,P[2]=j(P[0]);for(const P of V)P[1]=P[0].material.opacity,P[2]=j(P[0]);g.copy(_).lerp(t.position,(_.z-(p+53))/(_.z-p));for(const P of u)P.startScale=P.object.scale.x,P.startOpacity=P.object.material.opacity;return M.lookAt(_,t.position,A),R.setFromRotationMatrix(M),T=me,S=!0,N=0,re.visible=!l,!0}function we(me,P){if(!S)return 0;const Le=me-T,Te=Ir(Le/v);N=Te;const ge=Ir((Le-m)/(v-m));B=l?0:1-vs(Le,0,f);const se=vs(ge,0,1),ze=_e.lerp(_.x,g.x,se),oe=_e.lerp(_.y,g.y,se);e.position.set(ze,oe,_e.lerp(_.z,g.z,se)),e.quaternion.slerpQuaternions(x,R,vs(Le,f,m));const Se=vs(Le,0,m);e.fov=_e.lerp(h,52,Se)+(l?0:4*Math.sin(Math.PI*ge)**2),e.updateProjectionMatrix(),d?.update(l?0:se),O.set(0,0,-1).applyQuaternion(e.quaternion);const Ye=l?1:1+1.4*vs(ge,0,.35);for(const{layer:K,quaternion:xe}of D)K.quaternion.slerpQuaternions(xe,e.quaternion,Se);for(const[K,xe,le]of k)K.material.uniforms.uStrength.value=xe*Ye*Ir(j(K)/Math.max(1e-6,le));for(const[K,xe,le]of V)K===d?.photo||K.position.z<p-25||(K.material.opacity=Math.min(1,xe*Ye*Ir(j(K)/Math.max(1e-6,le))));const De=_s(Te,b,.995),I=Math.max(35,e.position.distanceTo(t.position)),E=Math.max(1,_.distanceTo(t.position)),Y=I/E,ee=1+De*De*22;for(const K of u)K.object.scale.setScalar(_e.lerp(K.startScale,K.scale*Y*ee,Se));for(const[K,xe]of[.2+.47*De,.3+.47*De,.85+.22*De,1].entries())u[K].object.material.opacity=_e.lerp(u[K].startOpacity,xe,Se);a.setIntensity(Math.min(1.5,w+.75*De));const ne=140+1700*Math.pow(ge,1.7);for(let K=0;K<Z.length;K++){const xe=Z[K];xe.z+=P*ne*xe.speed,xe.z>2&&(xe.z=-220-Math.random()*45);const le=K*6;L[le]=xe.x,L[le+1]=xe.y,L[le+2]=xe.z,L[le+3]=xe.x,L[le+4]=xe.y,L[le+5]=xe.z-Math.min(28,xe.len*(1+2.2*ge))}return G.attributes.position.needsUpdate=!0,X.opacity=l?0:_s(ge,0,.18)*(.04+.5*_s(ge,0,.55))*(1-De*.88),o.style.opacity=String(De),o.style.setProperty("--veil-opacity",String(_s(Te,.9,1))),Te>=1&&!y&&(y=!0,S=!1,c()),Te}return{begin:fe,update:we,setDestination:ye,get active(){return S},get progress(){return N},get companionOpacity(){return B},get streakCount(){return te},get passedLayers(){return s.filter(me=>e.position.z<me.position.z).length}}}const jr=i=>Math.max(0,Math.min(1,i)),Ot=(i,e,t)=>{const n=jr((i-e)/(t-e));return jr(n*n*n*(n*(n*6-15)+10))},Dy=1.12,Ny=.16,Oy=.78;function Ef(i,e=!1){const t=jr(i/(e?Ny:Dy));if(e)return{progress:t,reach:0,press:0,anticipation:0,followThrough:0,lift:0,charge:0,burst:0,light:t<1?.3:0};const n=Ot(t,0,.07)*(1-Ot(t,.1,.24)),r=Ot(t,.08,.4)*(1-Ot(t,.68,1)),s=Ot(t,.05,.28)*(1-Ot(t,.57,.94)),a=Ot(t,.32,.49)*(1-Ot(t,.6,.88)),o=Ot(t,.6,.78)*(1-Ot(t,.86,1)),l=Ot(t,0,.34)*(1-Ot(t,.44,.64)),c=Ot(t,.32,.49)*(1-Ot(t,.6,.98)),d=1-(1-.65*l)*(1-.95*c);return{progress:t,reach:r,press:a,anticipation:n,followThrough:o,lift:s,charge:l,burst:c,light:d}}function Fd(i,e,t=Math.PI*2){const n=new ho(i,1,e,4,0,t),r=n.attributes.position,s=new Float32Array(r.count*4);for(let a=0;a<r.count;a++){const o=r.getX(a),l=r.getY(a),c=Math.hypot(o,l),d=Math.sin(Math.PI*jr((c-i)/(1-i)))**2;let u=Math.atan2(l,o);u<0&&(u+=Math.PI*2);const h=t<Math.PI*2?Math.sin(Math.PI*jr(u/t))**2:1;s.set([1,1,1,d*h],a*4)}return n.setAttribute("color",new nt(s,4)),n}function Uy(i,{camera:e,hands:t,reducedMotion:n=!1,onConfirm:r,onDepart:s}){const a={active:!1,completed:!1,departed:!1,elapsed:0,progress:0,reach:0,press:0,anticipation:0,followThrough:0,lift:0,charge:0,burst:0,light:0,activations:0,surfaces:0,triangles:0},o=new Rt;o.name="NoxSelectionLight",o.visible=!1,i.add(o);const l=[],c=[],d=[],u=new Set,h=new dt,p=new dt,g=new Ie(16113064),v=new Ie(12166639);let m=null,f=null,b=!1,_=!1;function x(S,y,T){u.add(S);const N=new Ut({color:y,vertexColors:!0,transparent:!0,opacity:0,side:Et,depthTest:!1,depthWrite:!1,blending:Qt,toneMapped:!1,forceSinglePass:!0}),B=new ht(S,N);return B.renderOrder=15,B.frustumCulled=!1,B.userData.selectionType=T,o.add(B),c.push(B),B}function R(){if(c.length)return;const S=Fd(.86,96);for(const y of[g,v])l.push(x(S,y,"wave"));if(!n){const y=Fd(.91,80,Math.PI*1.65);for(const O of[v,g])d.push(x(y,O,"ribbon"));const T=[],N=[];for(let O=0;O<12;O++){const F=O*Math.PI/6+.12,z=O%3===0?78:O%2===0?54:35,j=O%3===0?1.9:1.1,te=O%2?v:g;for(const[L,$,Z]of[[8,0,0],[18,-j,0],[18,0,.85],[18,-j,0],[z,0,0],[18,0,.85],[8,0,0],[18,0,.85],[18,j,0],[18,j,0],[18,0,.85],[z,0,0]])T.push(Math.cos(F)*L-Math.sin(F)*$,Math.sin(F)*L+Math.cos(F)*$,0),N.push(te.r,te.g,te.b,Z)}const B=new Lt;B.setAttribute("position",new nt(T,3)),B.setAttribute("color",new nt(N,4)),m=x(B,16777215,"corona");const k=new Lt,V=new Float32Array(648),D=new Float32Array(864);for(let O=0;O<18;O++)for(let F=0;F<12;F++){const z=O%2?v:g,j=F%3===1?.9:0;D.set([z.r,z.g,z.b,j],(O*12+F)*4)}k.setAttribute("position",new ct(V,3).setUsage(Zh)),k.setAttribute("color",new nt(D,4)),f=x(k,16777215,"motes")}a.surfaces=c.length,a.triangles=[...c].reduce((y,T)=>y+(T.geometry.index?.count??T.geometry.attributes.position.count)/3,0)}function M(){return b||a.active||a.completed?!1:(R(),a.active=!0,a.activations++,o.visible=!0,t.setStarSelection?.({reach:0,press:0}),A(0),_=n,!0)}function A(S){if(!(!a.active||b)){_&&(_=!1,S=0),a.elapsed+=Math.max(0,n?S:Math.min(S,.1)),Object.assign(a,Ef(a.elapsed,n)),t.setStarSelection?.(a),i.getWorldQuaternion(h),e.getWorldQuaternion(p),o.quaternion.copy(h.invert().multiply(p));for(let y=0;y<l.length;y++){const T=y*.28,N=jr((a.progress-T)/(1-T));l[y].scale.setScalar(n?20:10+(y===0?68:80)*(1-(1-N)**2)),l[y].material.opacity=n?y===0?a.light:0:(y===0?.58:.4)*Ot(N,0,.14)*(1-Ot(N,.42,1))}if(!n){const y=a.progress,T=Ot(y,.46,1);for(let D=0;D<d.length;D++){const O=d[D],F=_e.lerp(38,23,a.charge)+26*T;O.scale.setScalar(F),O.rotation.set(D===0?.85:-.95,D===0?.3:-.35,(D===0?1:-1)*(.35+y*1.8)),O.material.opacity=(D===0?.52:.42)*a.light}m.rotation.z=-.08+y*.18,m.scale.setScalar(.65+.55*T),m.material.opacity=.62*a.burst;const N=f.geometry.attributes.position,B=_e.lerp(64,14,Ot(y,0,.44)),k=14+98*(1-(1-T)**2),V=_e.lerp(B,k,Ot(y,.44,.54));for(let D=0;D<18;D++){const O=D*Math.PI*2/18+.17+y*.85,F=.82+D%5*.09,z=V*F,j=.65+D%3*.17,te=2.2+5*T,L=Math.cos(O)*z,$=Math.sin(O)*z;for(const[Z,[ae,G]]of[[-te,0],[0,0],[0,-j],[0,-j],[0,0],[te,0],[te,0],[0,0],[0,j],[0,j],[0,0],[-te,0]].entries())N.setXYZ(D*12+Z,L+Math.cos(O)*ae-Math.sin(O)*G,$+Math.sin(O)*ae+Math.cos(O)*G,0)}N.needsUpdate=!0,f.material.opacity=.72*(1-(1-.75*a.charge)*(1-a.burst))}!n&&s&&!a.departed&&a.progress>=Oy&&(a.departed=!0,s()),a.progress>=1&&(a.active=!1,a.completed=!0,o.visible=!1,t.setStarSelection?.(null),r?.())}}function w(){if(!b){b=!0,a.active=!1,o.visible=!1,t.setStarSelection?.(null);for(const S of u)S.dispose();for(const S of c)S.material.dispose();i.remove(o)}}return{state:a,root:o,rings:l,effects:c,begin:M,update:A,dispose:w}}function Fy(){const i=document.createElement("canvas");i.width=i.height=512;const e=i.getContext("2d");if(!e)throw Error("Canvas 2D indisponível para o flare da estrela");const t=256;e.translate(t,t),e.globalCompositeOperation="lighter";const n=e.createRadialGradient(0,0,2,0,0,90);n.addColorStop(0,"rgba(255,249,226,.30)"),n.addColorStop(.11,"rgba(247,223,185,.18)"),n.addColorStop(.36,"rgba(199,179,223,.043)"),n.addColorStop(1,"rgba(199,179,223,0)"),e.fillStyle=n,e.fillRect(-96,-96,192,192);function r(a,o,l,c){e.save(),e.rotate(a);for(const[d,u]of[[c*3.4,.1],[c,.48],[.55,1]]){const h=e.createLinearGradient(0,0,o,0),p=l*u;h.addColorStop(0,`rgba(255,252,239,${Math.min(1,p)})`),h.addColorStop(.08,`rgba(255,242,211,${p*.75})`),h.addColorStop(.34,`rgba(228,217,246,${p*.32})`),h.addColorStop(.7,`rgba(205,202,255,${p*.12})`),h.addColorStop(1,"rgba(205,202,255,0)"),e.fillStyle=h,e.beginPath(),e.moveTo(0,-d),e.lineTo(o,0),e.lineTo(0,d),e.closePath(),e.fill()}e.restore()}for(let a=0;a<4;a++)r(a*Math.PI/2,231,.48,1.6);for(let a=0;a<4;a++)r(Math.PI/4+a*Math.PI/2,119,.15,.72);const s=new uo(i);return s.colorSpace=_t,s.minFilter=Gt,s.magFilter=Dt,s.generateMipmaps=!0,s}function Tf(i,{reducedMotion:e=!1,sharedTexture:t=null}={}){const n=t??Fy();function r(h,p,g){const v=new Vs({map:n,transparent:!0,opacity:p,depthTest:!1,depthWrite:!1,blending:Qt,toneMapped:!1}),m=new lo(v);return m.scale.setScalar(h),m.renderOrder=g,i.add(m),m}const s=r(174,.31,11),a=r(123,.085,11);let o=0,l=0,c=null;function d(h,p,g){const v=c===null?0:Math.max(0,Math.min(.1,h-c));c=h;const m=e?1:1-Math.exp(-v*12);o+=((p?1:0)-o)*m,l+=((g?1:0)-l)*m;const f=e?0:Math.sin(h*.79+.9),b=e?0:Math.sin(h*2.11+.7)*.55+Math.sin(h*3.16+2.3)*.45;s.material.rotation=e?.11:.11+h*.019,a.material.rotation=e?-.3:-.3-h*.012,s.material.opacity=.28-.16*l+.04*f+.032*b+.09*o,a.material.opacity=.075-.03*l+.012*f+.035*o,s.scale.setScalar(174*(1+.018*f+.045*o)),a.scale.setScalar(123*(1+.025*b))}function u(){s.material.dispose(),a.material.dispose(),t||n.dispose()}return{primary:s,secondary:a,update:d,dispose:u}}const By=Object.freeze([{id:"01",name:"Massa distante",u:.19,v:.51,w:.23,h:.27,z:-425,opacity:.18,rate:.27,phase:.6,drift:1.5,parallaxX:2.2,parallaxY:.8},{id:"02",name:"Nuvem central",u:.41,v:.52,w:.25,h:.32,z:-342,opacity:.23,rate:.22,phase:1.9,drift:2.1,parallaxX:5.2,parallaxY:2.1},{id:"03",name:"Filamento lateral",u:.61,v:.53,w:.23,h:.3,z:-252,opacity:.19,rate:.3,phase:3,drift:2.9,parallaxX:9,parallaxY:3.1},{id:"04",name:"Véu avançado",u:.8,v:.53,w:.22,h:.26,z:-185,opacity:.14,rate:.36,phase:4.2,drift:3.6,parallaxX:16.5,parallaxY:6.2},{id:"05",name:"Bruma intermediária esquerda",u:.28,v:.43,w:.18,h:.24,z:-130,opacity:.1,rate:.25,phase:5.4,drift:1.2,parallaxX:12,parallaxY:4},{id:"06",name:"Filamento próximo direito",u:.66,v:.61,w:.2,h:.27,z:-42,opacity:.055,rate:.32,phase:6.7,drift:.65,parallaxX:8,parallaxY:3}]);function ky(i,e,{reducedMotion:t=!1,parallaxEnabled:n=!0,foregroundEnabled:r=!0}={}){const s=new ns,a=By.map((g,v)=>{const m=new Ut({transparent:!0,opacity:g.opacity,depthTest:!1,depthWrite:!1,side:Et,forceSinglePass:!0,blending:Ii,toneMapped:!1}),f=new ht(new yn(1,1),m);return f.position.z=g.z,f.renderOrder=2.11+v*.08,f.visible=!1,f.userData.layerName="Foto ESO em volume · "+g.name,f.userData.volumeFragment=!0,f.userData.spec=g,f.userData.loaded=!1,f.userData.parallaxOffsetX=0,f.userData.parallaxOffsetY=0,f.userData.baseScaleX=1,f.userData.baseScaleY=1,i.add(f),f}),o={active:0,loaded:0,parallaxEnabled:n&&!t,parallaxStrength:1,foregroundEnabled:r};function l(g){const v=Number(g);Number.isFinite(v)&&(o.parallaxStrength=_e.clamp(v,.45,1.6))}function c(g){if(g.userData.loaded)return;g.userData.loaded=!0;const v=g.userData.spec.id,m=s.load("/assets/depth/eso-gas-"+v+".webp",void 0,void 0,f=>{console.warn("[Nebulosa em volume] falha ao carregar recorte",v,f),g.visible=!1});m.colorSpace=_t,m.anisotropy=1,m.minFilter=Gt,m.magFilter=Dt,g.material.map=m,g.material.needsUpdate=!0,o.loaded++}function d(g){const v=g==="eco-plus"?o.foregroundEnabled?[1,2,3,4,5]:[1,3]:["lite","eco"].includes(g)?[1,3]:g==="high"?[0,1,2,3,4,5]:[0,1,2,4,5];a.forEach((m,f)=>{const b=g==="eco-plus"&&o.foregroundEnabled&&f===2,_=m.userData.spec;m.position.z=b?-75:_.z,m.userData.opacityFactor=b?.38:1,m.material.opacity=_.opacity*m.userData.opacityFactor,m.renderOrder=2.11+(425+m.position.z)*8e-4,m.visible=v.includes(f),m.visible&&c(m)}),o.active=v.length}function u(){const g=26-e.position.z;for(const v of a){const m=v.userData.spec,f=(26-v.position.z)/g;v.userData.baseX=e.position.x+(m.u-.5)*e.scale.x*f,v.userData.baseY=e.position.y+(.5-m.v)*e.scale.y*f,v.position.x=v.userData.baseX,v.position.y=v.userData.baseY,v.userData.baseScaleX=e.scale.x*m.w*f*1.008,v.userData.baseScaleY=e.scale.y*m.h*f*1.008,v.scale.set(v.userData.baseScaleX,v.userData.baseScaleY,1)}}function h(g,v=0,m=0,f=1/60){const b=o.parallaxEnabled,_=b?1-Math.exp(-Math.max(0,Math.min(.1,f))*14):1,x=b?_e.clamp(v,-1,1):0,R=b?_e.clamp(m,-1,1):0;for(const M of a){if(!M.visible)continue;const A=M.userData.spec,w=t?0:Math.sin(g*A.rate+A.phase),S=t?0:Math.sin(g*A.rate*.55+A.phase*1.43),y=M.userData;y.parallaxOffsetX+=(-x*A.parallaxX*o.parallaxStrength-y.parallaxOffsetX)*_,y.parallaxOffsetY+=(-R*A.parallaxY*o.parallaxStrength-y.parallaxOffsetY)*_,M.position.x=y.baseX+S*A.drift+y.parallaxOffsetX,M.position.y=y.baseY+w*A.drift*.32+y.parallaxOffsetY;const T=t?0:.003*Math.sin(g*A.rate*.67+A.phase);M.scale.x=y.baseScaleX*(1+T),M.scale.y=y.baseScaleY*(1+T*.6),M.material.opacity=A.opacity*y.opacityFactor*(1+w*.085)}}function p(){for(const g of a)g.material.map?.dispose(),g.material.dispose(),g.geometry.dispose(),i.remove(g)}return{layers:a,state:o,resize:u,update:h,applyQuality:d,dispose:p,setParallaxStrength:l}}const Qc="orion-observatorio-hands-ab-v1";function zy(i){return JSON.stringify({quality:i.quality,effects:i.effects,bloomRest:i.bloomRest,viewport:i.viewport,dpr:i.dpr,canvasPixels:i.canvasPixels,gasLayers:i.gasLayers,volumeLayers:i.volumeLayers,foregroundNear:i.foregroundNear,depthMotion:i.depthMotion,parallaxStrength:i.parallaxStrength})}function Bd(i,e){if(!i||!e)return{ok:!1,reason:"Faltam medições dos dois modos."};if(i.mode!=="off"||e.mode!=="fps")return{ok:!1,reason:"Modos A/B inválidos."};if(i.signature!==e.signature)return{ok:!1,reason:"Configurações ou resolução diferentes. Limpe as medições e repita no mesmo tamanho de janela."};for(const t of[i.fps,i.p95Ms,e.fps,e.p95Ms])if(!Number.isFinite(t))return{ok:!1,reason:"Medições incompletas."};return{ok:!0,fpsDifference:e.fps-i.fps,p95Difference:+(e.p95Ms-i.p95Ms).toFixed(1),drawCallsDifference:(e.drawCalls??0)-(i.drawCalls??0),texturesDifference:(e.textures??0)-(i.textures??0)}}function dl(){try{const i=JSON.parse(sessionStorage.getItem(Qc)||"{}");return i&&typeof i=="object"?i:{}}catch{return{}}}function Vy(i){try{return sessionStorage.setItem(Qc,JSON.stringify(i)),!0}catch{return!1}}function Hy(i,e){const t=document.createElement("section");t.className="perf-ab-inspector",t.setAttribute("aria-label","Benchmark local das mãos FPS");const n=document.createElement("strong");n.textContent="Comparação A/B · mãos FPS";const r=document.createElement("small");r.textContent="Mesmo PC e janela: espere 10 s com a aba visível, registre uma amostra, mude de modo e registre a outra. Repita para confirmar. Não mede VRAM nem FPS efetivamente exibido pela GPU.";const s=document.createElement("output");s.id="orionHandsABResult",s.className="perf-values",s.setAttribute("aria-live","polite");const a=document.createElement("button");a.id="orionHandsABCapture",a.className="perf-copy",a.type="button",a.textContent="Registrar amostra atual";const o=document.createElement("a");o.id="orionHandsABSwitch",o.className="perf-depth-compare";const l=document.createElement("button");l.id="orionHandsABClear",l.className="perf-copy",l.type="button",l.textContent="Limpar comparativo";const c=document.createElement("small");c.id="orionHandsABStatus",c.setAttribute("aria-live","polite");const d=new URLSearchParams(location.search),u=d.get("hands")==="off",h=new URL(location.href);h.searchParams.set("debug","1"),h.searchParams.set("quality","eco-plus"),h.searchParams.set("hands",u?"fps":"off"),h.searchParams.set("fpsStyle","frame"),h.searchParams.delete("fpsTune"),o.href=h.pathname+h.search,o.textContent=u?"Testar com mãos FPS":"Testar sem mãos FPS",t.append(n,r,s,a,o,l,c),i.appendChild(t);function p(){const v=dl(),m=v.off,f=v.fps;if(!m&&!f)return"Comparativo A/B: sem dados registrados.";const b=x=>x?"FPS "+x.fps+" | p95 "+x.p95Ms+" ms | >33 ms "+x.longFrames+"% | draw calls "+x.drawCalls+" | texturas "+x.textures+" | amostras "+x.samples+" | viewport "+x.viewport:"pendente",_=Bd(m,f);return["Observatório · mãos FPS · comparação local A/B","Sem mãos: "+b(m),"David Fischer (natural): "+b(f),_.ok?"Diferença com mãos menos sem mãos: FPS "+(_.fpsDifference>=0?"+":"")+_.fpsDifference+" | p95 "+(_.p95Difference>=0?"+":"")+_.p95Difference+" ms | draw calls "+(_.drawCallsDifference>=0?"+":"")+_.drawCallsDifference+" | texturas "+(_.texturesDifference>=0?"+":"")+_.texturesDifference:"Comparação pendente: "+_.reason,"Amostras do loop da página, não benchmark de GPU. Repetir pares A/B na mesma janela."].join(`
`)}function g(){const v=dl(),m=Bd(v.off,v.fps);m.ok?s.textContent="FPS: sem mãos "+v.off.fps+" → com mãos "+v.fps.fps+" ("+(m.fpsDifference>=0?"+":"")+m.fpsDifference+`)
p95: `+v.off.p95Ms+" → "+v.fps.p95Ms+" ms ("+(m.p95Difference>=0?"+":"")+m.p95Difference+` ms)
Draw calls: `+v.off.drawCalls+" → "+v.fps.drawCalls+" | Texturas: "+v.off.textures+" → "+v.fps.textures:s.textContent="Sem mãos: "+(v.off?"registrado":"pendente")+" · Com mãos FPS: "+(v.fps?"registrado":"pendente")+`
`+(v.off&&v.fps?m.reason:"Aguardando duas amostras comparáveis.")}return a.addEventListener("click",()=>{const v=e(),m=d.get("hands")==="off",f=m?"off":"fps";if(document.hidden){c.textContent="Volte para a aba visível antes de medir.";return}if(v.quality!=="eco-plus"){c.textContent="Selecione Eco+ para comparar com resolução fixa.";return}if(!m&&(v.handsMode!=="fps"||!v.handsVisible||!v.handsReady||v.handsLoadError)){c.textContent="O modelo FPS ainda não está pronto para a medição.";return}if(m&&v.handsVisible){c.textContent="Desligue as mãos antes de medir o modo sem mãos.";return}if(performance.now()<1e4||v.samples<30||!Number.isFinite(v.fps)||!Number.isFinite(v.p95Ms)){c.textContent="Espere pelo menos 10 s de cena carregada e 30 quadros de amostra.";return}const b={mode:f,signature:zy(v),fps:v.fps,p95Ms:v.p95Ms,longFrames:v.longFrames,drawCalls:v.drawCalls,textures:v.textures,samples:v.samples,viewport:v.viewport,quality:v.quality,recordedAt:new Date().toISOString()},_=dl();if(_[f]=b,!Vy(_)){c.textContent="Armazenamento da aba bloqueado. Não foi possível preservar a comparação.";return}c.textContent="Amostra "+(f==="fps"?"com mãos FPS":"sem mãos")+" registrada nesta aba.",g()}),l.addEventListener("click",()=>{try{sessionStorage.removeItem(Qc)}catch{}c.textContent="Comparação limpa.",g()}),g(),{report:p}}function Gy(i,e){const t=document.createElement("fieldset");t.className="layer-inspector perf-inspector";const n=document.createElement("legend");n.textContent="Diagnóstico de fluidez · prévia";const r=document.createElement("output");r.id="orionPerfReadout",r.className="perf-values",r.setAttribute("aria-label","Indicadores de desempenho locais"),r.textContent="Coletando amostras do seu navegador…";const s=document.createElement("small");s.textContent="FPS medido na aba, não pela GPU. Texturas e draw calls não representam RAM/VRAM. Para memória total: Shift+Esc no Chrome.";const a=document.createElement("button");a.type="button",a.className="perf-copy",a.textContent="Copiar diagnóstico";const o=document.createElement("small");o.className="perf-copy-status",o.setAttribute("aria-live","polite"),t.append(n,r,s,a,o);const l=document.createElement("nav");l.className="perf-comparisons",l.setAttribute("aria-label","Comparação de custos de renderização");const c=[{label:"Lite original · 950k px",quality:"lite",effects:null},{label:"Lite sem gás GLSL",quality:"lite",effects:"no-gas"},{label:"Eco+ · 670k px + bloom",quality:"eco-plus",effects:null},{label:"Eco+ sem bloom",quality:"eco-plus",effects:"no-bloom"},{label:"Eco · 500k px",quality:"eco",effects:null}];for(const z of c){const j=new URL(window.location.href);j.searchParams.set("debug","1"),j.searchParams.set("quality",z.quality),j.searchParams.delete("depthMotion"),z.effects?j.searchParams.set("effects",z.effects):j.searchParams.delete("effects");const te=document.createElement("a");te.href=j.pathname+j.search,te.textContent=z.label,z.quality===new URLSearchParams(location.search).get("quality")&&(z.effects||"normal")===(new URLSearchParams(location.search).get("effects")||"normal")&&new URLSearchParams(location.search).get("depthMotion")!=="off"&&te.setAttribute("aria-current","page"),l.appendChild(te)}const d=document.createElement("small");d.textContent="Compare após ~10 s em cada modo e repita as medições. Lite sem gás e Eco+ preservam o bloom: a diferença isola principalmente a resolução; Eco+ sem bloom mostra o custo do bloom na mesma resolução.";const u=document.createElement("a"),h=new URL(window.location.href);h.searchParams.set("debug","1"),h.searchParams.set("quality","eco-plus"),h.searchParams.delete("effects"),new URLSearchParams(location.search).get("depthMotion")==="off"?(h.searchParams.delete("depthMotion"),u.textContent="Ativar profundidade orgânica · Eco+"):(h.searchParams.set("depthMotion","off"),u.textContent="Comparar profundidade original · Eco+"),u.href=h.pathname+h.search,u.className="perf-depth-compare";const p=document.createElement("a"),g=new URL(window.location.href);g.searchParams.set("debug","1"),g.searchParams.set("quality","eco-plus"),g.searchParams.delete("effects"),new URLSearchParams(location.search).get("foreground")==="off"?(g.searchParams.delete("foreground"),p.textContent="Ativar véu próximo · Eco+"):(g.searchParams.set("foreground","off"),p.textContent="Comparar sem véu próximo · Eco+"),p.href=g.pathname+g.search,p.className="perf-depth-compare";const m=document.createElement("a"),f=new URL(window.location.href);f.searchParams.set("debug","1"),f.searchParams.set("quality","eco-plus"),new URLSearchParams(location.search).get("hands")==="off"?(f.searchParams.set("hands","fps"),f.searchParams.set("fpsStyle","frame"),f.searchParams.delete("fpsTune"),m.textContent="Ativar mãos FPS David Fischer · Eco+"):(f.searchParams.set("hands","off"),m.textContent="Comparar sem mãos · Eco+"),m.href=f.pathname+f.search,m.className="perf-depth-compare";const _=document.createElement("nav");_.className="perf-comparisons",_.setAttribute("aria-label","Comparar modelos das mãos");const x=new URLSearchParams(location.search).get("hands")||"fps";for(const{mode:z,label:j}of[{mode:"fps",label:"David Fischer · FPS (CC BY)"},{mode:"vr",label:"Mãos anatômicas VR · MIT"},{mode:"rig",label:"WRAD retrô · 50 ossos"},{mode:"3d",label:"Modelo 3D anterior"},{mode:"2d",label:"Silhueta 2,5D"},{mode:"off",label:"Sem mãos"}]){const te=new URL(window.location.href);te.searchParams.set("quality","eco-plus"),te.searchParams.set("debug","1"),te.searchParams.set("hands",z);const L=document.createElement("a");L.href=te.pathname+te.search,L.textContent=j,(z===x||z==="fps"&&x==="on")&&L.setAttribute("aria-current","page"),_.appendChild(L)}t.append(d,l,u,p,_,m),i.appendChild(t);const R=360,M=4e3,A=new Array(R);let w=0,S=0,y=-1/0,T=null;function N(){S=0,w=0,y=-1/0,T=null,r.textContent="Coletando amostras do seu navegador…"}function B(z,j){if(!(!Number.isFinite(z)||!Number.isFinite(j)||j<=0)){if(j>1e3){N();return}A[w]={t:z,dt:j},w=(w+1)%R,S=Math.min(R,S+1)}}function k(z=performance.now()){const j=[];for(let Z=0;Z<S;Z++){const ae=A[(w-S+Z+R)%R];z-ae.t<=M&&j.push(ae.dt)}j.sort((Z,ae)=>Z-ae);const te=j.reduce((Z,ae)=>Z+ae,0),L=e(),$=typeof performance.memory?.usedJSHeapSize=="number"?Math.round(performance.memory.usedJSHeapSize/1048576):null;return{fps:te>0?Math.round(1e3*j.length/te):null,p95Ms:j.length?Math.round(j[Math.min(j.length-1,Math.ceil(j.length*.95)-1)]*10)/10:null,longFrames:j.length?Math.round(100*j.filter(Z=>Z>33.3).length/j.length):null,samples:j.length,jsHeapMB:$,...L}}function V(z){return["FPS médio (~4s): "+(z.fps??"—"),"Quadro p95: "+(z.p95Ms??"—")+" ms","Quadros acima de 33 ms: "+(z.longFrames??"—")+"%","Perfil: "+z.quality+" · DPR: "+z.dpr,"Efeitos: "+z.effects+" · bloom em repouso: "+(z.bloomRest?"sim":"não"),"Pixels do canvas: "+z.canvasPixels,"Camadas: "+z.gasLayers+" gás / "+z.volumeLayers+" recortes","Véu frontal próximo da câmera: "+(z.foregroundNear?"sim":"não"),"Mãos em primeira pessoa: "+(z.handsVisible?"visíveis":"desligadas")+" · modo: "+z.handsMode+" · superfícies: "+z.handsSurfaces+" · texturas de mãos: "+z.handsTextures+" · triângulos por mão: "+z.handsTriangles,"Rig pronto: "+(z.handsReady?"sim":"carregando/indisponível")+" · ossos: "+z.handsJoints+" · juntas de dedos: "+z.handsFingerJoints,...z.handsMode==="fps"&&window.__orionHandsDebug?.state?.framing?["FPS | punhos NDC: "+JSON.stringify(window.__orionHandsDebug.state.framing)]:[],...z.handsLoadError?["Falha no rig: "+z.handsLoadError]:[],"Profundidade orgânica: "+(z.depthMotion?"ativa":"desativada")+" · intensidade: "+z.parallaxStrength,"Draw calls: "+z.drawCalls+" · texturas GPU: "+z.textures,"Diferença interna mouse/câmera: "+z.mouseDeltaPx+" px","Heap JavaScript: "+(z.jsHeapMB==null?"indisponível":z.jsHeapMB+" MB")+" (não é RAM total)"].join(`
`)}function D(){const z=k();return["Projeto Órion · Observatório v0.9.15 (prévia)",new Date().toLocaleString("pt-BR"),V(z),"Amostras: "+z.samples+" · adaptações automáticas: "+z.adaptations,"Janela: "+z.viewport,"Memória total da aba: verificar no Gerenciador de tarefas do Chrome (Shift+Esc).","Os valores são observações locais, não benchmarks de GPU nem medidas de VRAM."].join(`
`)}const O=Hy(t,k);function F(z){z-y<1e3||(y=z,T=k(z),r.textContent=V(T))}return a.addEventListener("click",async()=>{const z=D()+`

`+O.report();try{if(!navigator.clipboard?.writeText)throw new Error("Clipboard indisponível");await navigator.clipboard.writeText(z),o.textContent="Diagnóstico copiado. Pode colar no chat."}catch{o.textContent="Cópia automática indisponível; selecione o texto abaixo.";const j=document.createElement("textarea");j.readOnly=!0,j.className="perf-fallback",j.setAttribute("aria-label","Diagnóstico para cópia manual"),j.value=z,t.querySelector(".perf-fallback")?.remove(),t.appendChild(j),j.focus(),j.select()}}),{record:B,refresh:F,reset:N,snapshot:k,report:D,get latest(){return T}}}function Wy(){const i=document.createElement("canvas");i.width=320,i.height=512;const e=i.getContext("2d");if(!e)throw new Error("Canvas 2D indisponível para as mãos etéreas");const t=new Path2D;t.moveTo(30,520),t.bezierCurveTo(38,460,60,418,89,385),t.bezierCurveTo(108,363,119,352,114,328),t.bezierCurveTo(102,309,99,289,106,279),t.bezierCurveTo(112,269,123,271,132,287),t.bezierCurveTo(137,295,140,315,143,323),t.lineTo(140,264),t.bezierCurveTo(140,247,145,237,155,236),t.bezierCurveTo(167,237,167,249,167,264),t.lineTo(169,304),t.lineTo(169,236),t.bezierCurveTo(169,222,174,213,184,212),t.bezierCurveTo(197,213,199,227,198,243),t.lineTo(199,306),t.lineTo(205,269),t.bezierCurveTo(206,252,214,246,226,250),t.bezierCurveTo(238,256,235,270,232,286),t.lineTo(222,333),t.bezierCurveTo(239,323,251,313,266,316),t.bezierCurveTo(280,319,282,330,273,341),t.bezierCurveTo(261,355,246,365,238,386),t.bezierCurveTo(223,426,226,475,245,520),t.closePath(),e.save(),e.shadowBlur=23,e.shadowColor="rgba(173,96,212,.25)";const n=e.createLinearGradient(74,210,247,502);n.addColorStop(0,"rgba(101,76,149,.96)"),n.addColorStop(.31,"rgba(74,51,115,.98)"),n.addColorStop(.65,"rgba(34,28,69,.99)"),n.addColorStop(1,"rgba(9,15,39,.98)"),e.fillStyle=n,e.fill(t),e.restore(),e.save(),e.clip(t);const r=e.createRadialGradient(194,305,5,178,327,156);r.addColorStop(0,"rgba(209,135,218,.35)"),r.addColorStop(.45,"rgba(136,92,189,.20)"),r.addColorStop(1,"rgba(54,30,99,0)"),e.fillStyle=r,e.fillRect(0,160,320,360),e.lineCap="round",e.lineJoin="round",e.lineWidth=5,e.strokeStyle="rgba(245,203,255,.10)",e.beginPath(),e.moveTo(112,338),e.bezierCurveTo(143,319,170,322,193,339),e.moveTo(123,369),e.bezierCurveTo(162,355,189,358,219,380),e.moveTo(150,266),e.lineTo(151,304),e.moveTo(181,242),e.lineTo(182,298),e.moveTo(217,275),e.lineTo(210,310),e.stroke(),e.strokeStyle="rgba(208,146,244,.28)",e.lineWidth=2,e.beginPath(),e.moveTo(117,308),e.bezierCurveTo(126,349,133,353,144,361),e.moveTo(148,252),e.lineTo(150,289),e.moveTo(177,226),e.lineTo(179,286),e.moveTo(218,263),e.lineTo(211,309),e.moveTo(110,392),e.bezierCurveTo(120,410,121,437,115,452),e.stroke(),e.save(),e.translate(163,409),e.rotate(-.08);const s=e.createLinearGradient(0,-20,0,45);s.addColorStop(0,"rgba(15,16,38,.35)"),s.addColorStop(.22,"rgba(12,16,42,.90)"),s.addColorStop(.7,"rgba(8,12,30,.96)"),s.addColorStop(1,"rgba(26,19,56,.90)"),e.fillStyle=s,e.fillRect(-110,-5,210,63),e.strokeStyle="rgba(186,113,210,.32)",e.lineWidth=3,e.beginPath(),e.moveTo(-107,0),e.lineTo(98,0),e.stroke(),e.restore(),e.strokeStyle="rgba(230,146,233,.13)",e.lineWidth=7,e.shadowBlur=10,e.shadowColor="rgba(177,78,238,.28)",e.beginPath(),e.moveTo(61,418),e.bezierCurveTo(84,392,98,373,103,345),e.moveTo(239,382),e.bezierCurveTo(231,409,224,446,229,470),e.stroke(),e.shadowBlur=0,e.restore(),e.save(),e.strokeStyle="rgba(185,126,212,.38)",e.lineWidth=2.2,e.lineJoin="round",e.stroke(t),e.restore();const a=e.createLinearGradient(0,388,0,512);a.addColorStop(0,"rgba(0,0,0,1)"),a.addColorStop(.77,"rgba(0,0,0,.92)"),a.addColorStop(1,"rgba(0,0,0,.06)"),e.globalCompositeOperation="destination-in",e.fillStyle=a,e.fillRect(0,0,320,512),e.globalCompositeOperation="source-over";const o=new uo(i);return o.colorSpace=_t,o.anisotropy=1,o.minFilter=Gt,o.magFilter=Dt,o}function Xy(i,{enabled:e=!0,reducedMotion:t=!1}={}){const n={enabled:!!e,visible:!!e,motionEnabled:!t,leftX:0,rightX:0,swayX:0,swayY:0,textureCount:e?1:0,drawSurfaces:e?2:0};if(!e)return{state:n,meshes:[],update(){},resize(){},beginTravel(){},dispose(){}};const r=Wy(),s=new yn(1,1),a=new Ut({map:r,transparent:!0,opacity:.78,depthTest:!1,depthWrite:!1,toneMapped:!1,side:Et}),o=new ht(s,a),l=new ht(s,a);o.name="Mão etérea esquerda · pose de primeira pessoa v0.9.11",l.name="Mão etérea direita · pose de primeira pessoa v0.9.11",o.layers.set(0),l.layers.set(0),o.renderOrder=30,l.renderOrder=30,o.frustumCulled=!1,l.frustumCulled=!1,i.add(o,l);const c=[o,l],d={left:{z:-1.1,x:-.7,y:-.72,size:1.1,roll:-.2,pitch:.055,yaw:.025,sway:.86},right:{z:-1,x:.68,y:-.66,size:1.17,roll:.18,pitch:.035,yaw:-.025,sway:1}};let u=0,h=0;function p(b){const _=Math.tan(_e.degToRad(i.fov/2))*Math.abs(b);return{hh:_,hw:_*i.aspect}}function g(){for(const[b,_,x]of[[o,d.left,1],[l,d.right,-1]]){const{hh:R,hw:M}=p(_.z),A=R*_.size;b.scale.set(x*A*(320/512),A,1),b.position.set(M*_.x,R*_.y,_.z),b.rotation.set(_.pitch,_.yaw,_.roll)}n.leftX=o.position.x,n.rightX=l.position.x}g();function v(b,_,x=0,R=0){if(!n.visible)return;const M=_e.clamp(x,-1,1),A=_e.clamp(R,-1,1),w=n.motionEnabled?1-Math.exp(-Math.max(0,Math.min(_,.06))*7.5):1;u+=(M-u)*w,h+=(A-h)*w,n.swayX=n.motionEnabled?u:0,n.swayY=n.motionEnabled?h:0;const S=n.motionEnabled?Math.sin(b*.81)*.006:0;for(const[y,T,N]of[[o,d.left,.9],[l,d.right,1]]){const{hh:B,hw:k}=p(T.z),V=n.swayX*k*.029*T.sway,D=n.swayY*B*.024*T.sway;y.position.set(k*T.x-V,B*T.y-D+S*B*N,T.z),y.rotation.set(T.pitch+(n.motionEnabled?n.swayY*.012:0),T.yaw,T.roll+(n.motionEnabled?n.swayX*.02*T.sway:0))}n.leftX=o.position.x,n.rightX=l.position.x}function m(){n.visible=!1,c.forEach(b=>b.visible=!1)}function f(){i.remove(o,l),s.dispose(),a.dispose(),r.dispose()}return{state:n,meshes:c,update:v,resize:g,beginTravel:m,dispose:f}}function qy(i,e=!1){const t=i[0].index!==null,n=new Set(Object.keys(i[0].attributes)),r=new Set(Object.keys(i[0].morphAttributes)),s={},a={},o=i[0].morphTargetsRelative,l=new Lt;let c=0;for(let d=0;d<i.length;++d){const u=i[d];let h=0;if(t!==(u.index!==null))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."),null;for(const p in u.attributes){if(!n.has(p))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+'. All geometries must have compatible attributes; make sure "'+p+'" attribute exists among all geometries, or in none of them.'),null;s[p]===void 0&&(s[p]=[]),s[p].push(u.attributes[p]),h++}if(h!==n.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+". Make sure all geometries have the same number of attributes."),null;if(o!==u.morphTargetsRelative)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+". .morphTargetsRelative must be consistent throughout all geometries."),null;for(const p in u.morphAttributes){if(!r.has(p))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+".  .morphAttributes must be consistent throughout all geometries."),null;a[p]===void 0&&(a[p]=[]),a[p].push(u.morphAttributes[p])}if(e){let p;if(t)p=u.index.count;else if(u.attributes.position!==void 0)p=u.attributes.position.count;else return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+d+". The geometry must have either an index or a position attribute"),null;l.addGroup(c,p,d),c+=p}}if(t){let d=0;const u=[];for(let h=0;h<i.length;++h){const p=i[h].index;for(let g=0;g<p.count;++g)u.push(p.getX(g)+d);d+=i[h].attributes.position.count}l.setIndex(u)}for(const d in s){const u=kd(s[d]);if(!u)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+d+" attribute."),null;l.setAttribute(d,u)}for(const d in a){const u=a[d][0].length;if(u===0)break;l.morphAttributes=l.morphAttributes||{},l.morphAttributes[d]=[];for(let h=0;h<u;++h){const p=[];for(let v=0;v<a[d].length;++v)p.push(a[d][v][h]);const g=kd(p);if(!g)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+d+" morphAttribute."),null;l.morphAttributes[d].push(g)}}return l}function kd(i){let e,t,n,r=-1,s=0;for(let c=0;c<i.length;++c){const d=i[c];if(e===void 0&&(e=d.array.constructor),e!==d.array.constructor)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."),null;if(t===void 0&&(t=d.itemSize),t!==d.itemSize)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."),null;if(n===void 0&&(n=d.normalized),n!==d.normalized)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."),null;if(r===-1&&(r=d.gpuType),r!==d.gpuType)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."),null;s+=d.count*t}const a=new e(s),o=new ct(a,t,n);let l=0;for(let c=0;c<i.length;++c){const d=i[c];if(d.isInterleavedBufferAttribute){const u=l/t;for(let h=0,p=d.count;h<p;h++)for(let g=0;g<t;g++){const v=d.getComponent(h,g);o.setComponent(h+u,g,v)}}else a.set(d.array,l);l+=d.count*t}return r!==void 0&&(o.gpuType=r),o}function zd(i,e){if(e===Xp)return console.warn("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Geometry already defined as triangles."),i;if(e===dc||e===$h){let t=i.getIndex();if(t===null){const a=[],o=i.getAttribute("position");if(o!==void 0){for(let l=0;l<o.count;l++)a.push(l);i.setIndex(a),t=i.getIndex()}else return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Undefined position attribute. Processing not possible."),i}const n=t.count-2,r=[];if(e===dc)for(let a=1;a<=n;a++)r.push(t.getX(0)),r.push(t.getX(a)),r.push(t.getX(a+1));else for(let a=0;a<n;a++)a%2===0?(r.push(t.getX(a)),r.push(t.getX(a+1)),r.push(t.getX(a+2))):(r.push(t.getX(a+2)),r.push(t.getX(a+1)),r.push(t.getX(a)));r.length/3!==n&&console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unable to generate correct amount of triangles.");const s=i.clone();return s.setIndex(r),s.clearGroups(),s}else return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unknown draw mode:",e),i}const hl=new Ie("#5b3e83"),Yy=new Ie("#171831"),Vd=new Ie("#ba79ca"),jy=new Ie("#101329"),fl=new U(-.48,.64,.64).normalize();function Af(i,{kind:e="skin",strength:t=1}={}){const n=i.getAttribute("position"),r=i.getAttribute("normal"),s=new Float32Array(n.count*4),a=new Ie;for(let o=0;o<n.count;o++){n.getX(o);const l=n.getY(o),c=r.getX(o),d=r.getY(o),u=r.getZ(o),h=Math.max(0,c*fl.x+d*fl.y+u*fl.z),p=Math.max(0,u);if(e==="cuff")a.copy(jy).lerp(hl,Math.min(.22,h*.14));else if(e==="glimmer")a.copy(Vd).lerp(hl,.25);else{a.copy(Yy).lerp(hl,.44+.36*h+.13*p);const v=Math.min(.2,Math.max(0,l-.2)*.42);a.lerp(Vd,Math.min(.44,v+h*.1*t))}const g=_e.smoothstep(l,-1.15,-.79);s[o*4]=a.r,s[o*4+1]=a.g,s[o*4+2]=a.b,s[o*4+3]=(e==="glimmer"?.5:1)*g}return i.setAttribute("color",new nt(s,4)),i}function ri(i,e,t,n="skin",r=12,s=8){const a=new Yc(1,r,s);a.scale(t[0],t[1],t[2]),a.translate(e[0],e[1],e[2]),i.push(Af(a,{kind:n}))}function Wi(i,e,t,n,r,s="skin"){const a=new U(...e),o=new U(...t),l=o.clone().sub(a),c=l.length();if(c<.001)return;const d=new qc(r,n,c,9,1,!1),u=new dt().setFromUnitVectors(new U(0,1,0),l.normalize());d.applyMatrix4(new qe().compose(a.add(o).multiplyScalar(.5),u,new U(1,1,1))),i.push(Af(d,{kind:s}))}function $y(){const i=[];Wi(i,[0,-1.12,-.16],[.025,-.4,-.04],.185,.135,"cuff"),ri(i,[.023,-.49,-.035],[.153,.13,.124],"cuff"),Wi(i,[.025,-.43,-.04],[.02,-.25,.025],.125,.118),ri(i,[0,-.07,.035],[.27,.326,.126]),ri(i,[.002,.13,.063],[.225,.144,.115]),ri(i,[.178,-.16,.114],[.12,.17,.108]);const e=[{x:-.205,len:.265,lean:-.057,r:.047},{x:-.104,len:.344,lean:-.024,r:.053},{x:.011,len:.393,lean:.011,r:.057},{x:.125,len:.334,lean:.064,r:.051}];for(const a of e){const o=[a.x,.187,.067],l=[a.x+a.lean*.43,.187+a.len*.57,.018],c=[a.x+a.lean,.187+a.len,-.1];Wi(i,o,l,a.r*1.18,a.r*.93),ri(i,l,[a.r*.99,a.r*.99,a.r*.94]),Wi(i,l,c,a.r*.94,a.r*.72),ri(i,c,[a.r*.8,a.r*.9,a.r*.78]),ri(i,[c[0],c[1]+a.r*.18,c[2]+a.r*.48],[a.r*.43,a.r*.25,a.r*.12],"glimmer",8,5)}const t=[.196,-.168,.117],n=[.357,-.043,.157],r=[.385,.102,.073];Wi(i,t,n,.083,.062),ri(i,n,[.066,.066,.068]),Wi(i,n,r,.062,.043),ri(i,r,[.051,.062,.048]),Wi(i,[.025,-.53,-.034],[.025,-.49,-.034],.159,.159,"glimmer");const s=qy(i,!1);for(const a of i)a.dispose();if(!s)throw new Error("Não foi possível mesclar a malha das mãos 3D");return s.computeBoundingSphere(),s.userData.fingerCount=5,s.userData.sections=i.length,s.userData.triangles=s.index?.count/3,s}function Ky(i,{enabled:e=!0,reducedMotion:t=!1}={}){const n={mode:"3d",enabled:!!e,visible:!!e,motionEnabled:!t,textureCount:0,drawSurfaces:e?2:0,fingerCount:e?10:0,leftX:0,rightX:0,swayX:0,swayY:0,triangles:0};if(!e)return{state:n,meshes:[],update(){},resize(){},beginTravel(){},dispose(){}};const r=$y();n.triangles=r.userData.triangles;const s=new Ut({color:16777215,vertexColors:!0,transparent:!0,opacity:.92,side:Et,depthTest:!1,depthWrite:!1,toneMapped:!1}),a=new ht(r,s),o=new ht(r,s);a.name="Mão 3D esquerda · primeira pessoa",o.name="Mão 3D direita · primeira pessoa";for(const f of[a,o])f.layers.set(0),f.renderOrder=30,f.frustumCulled=!1;i.add(a,o);const l=[a,o],c={left:{z:-1.1,x:-.78,y:-.82,size:.65,roll:-.2,pitch:-.13,yaw:-.13,sway:.86},right:{z:-1,x:.76,y:-.8,size:.68,roll:.18,pitch:-.11,yaw:.12,sway:1}};function d(f){const b=Math.tan(_e.degToRad(i.fov*.5))*Math.abs(f);return{hh:b,hw:b*i.aspect}}function u(){for(const[f,b,_]of[[a,c.left,1],[o,c.right,-1]]){const{hh:x,hw:R}=d(b.z),M=x*b.size;f.scale.set(_*M,M,M),f.position.set(R*b.x,x*b.y,b.z),f.rotation.set(b.pitch,b.yaw,b.roll)}n.leftX=a.position.x,n.rightX=o.position.x}let h=0,p=0;u();function g(f,b,_=0,x=0){if(!n.visible)return;const R=n.motionEnabled?1-Math.exp(-Math.max(0,Math.min(b,.06))*7.5):1;h+=(_e.clamp(_,-1,1)-h)*R,p+=(_e.clamp(x,-1,1)-p)*R,n.swayX=n.motionEnabled?h:0,n.swayY=n.motionEnabled?p:0;const M=n.motionEnabled?Math.sin(f*.81)*.006:0;for(const[A,w,S]of[[a,c.left,.9],[o,c.right,1]]){const{hh:y,hw:T}=d(w.z);A.position.set(T*(w.x-n.swayX*.029*w.sway),y*(w.y-n.swayY*.024*w.sway+M*S),w.z),A.rotation.set(w.pitch+(n.motionEnabled?n.swayY*.012:0),w.yaw+(n.motionEnabled?n.swayX*.01:0),w.roll+(n.motionEnabled?n.swayX*.02*w.sway:0))}n.leftX=a.position.x,n.rightX=o.position.x}function v(){n.visible=!1;for(const f of l)f.visible=!1}function m(){i.remove(a,o),r.dispose(),s.dispose()}return{state:n,meshes:l,update:g,resize:u,beginTravel:v,dispose:m}}class eu extends ts{constructor(e){super(e),this.dracoLoader=null,this.ktx2Loader=null,this.meshoptDecoder=null,this.pluginCallbacks=[],this.register(function(t){return new tb(t)}),this.register(function(t){return new nb(t)}),this.register(function(t){return new db(t)}),this.register(function(t){return new hb(t)}),this.register(function(t){return new fb(t)}),this.register(function(t){return new rb(t)}),this.register(function(t){return new sb(t)}),this.register(function(t){return new ab(t)}),this.register(function(t){return new ob(t)}),this.register(function(t){return new eb(t)}),this.register(function(t){return new lb(t)}),this.register(function(t){return new ib(t)}),this.register(function(t){return new ub(t)}),this.register(function(t){return new cb(t)}),this.register(function(t){return new Jy(t)}),this.register(function(t){return new pb(t)}),this.register(function(t){return new mb(t)})}load(e,t,n,r){const s=this;let a;if(this.resourcePath!=="")a=this.resourcePath;else if(this.path!==""){const c=As.extractUrlBase(e);a=As.resolveURL(c,this.path)}else a=As.extractUrlBase(e);this.manager.itemStart(e);const o=function(c){r?r(c):console.error(c),s.manager.itemError(e),s.manager.itemEnd(e)},l=new gf(this.manager);l.setPath(this.path),l.setResponseType("arraybuffer"),l.setRequestHeader(this.requestHeader),l.setWithCredentials(this.withCredentials),l.load(e,function(c){try{s.parse(c,a,function(d){t(d),s.manager.itemEnd(e)},o)}catch(d){o(d)}},n,o)}setDRACOLoader(e){return this.dracoLoader=e,this}setKTX2Loader(e){return this.ktx2Loader=e,this}setMeshoptDecoder(e){return this.meshoptDecoder=e,this}register(e){return this.pluginCallbacks.indexOf(e)===-1&&this.pluginCallbacks.push(e),this}unregister(e){return this.pluginCallbacks.indexOf(e)!==-1&&this.pluginCallbacks.splice(this.pluginCallbacks.indexOf(e),1),this}parse(e,t,n,r){let s;const a={},o={},l=new TextDecoder;if(typeof e=="string")s=JSON.parse(e);else if(e instanceof ArrayBuffer)if(l.decode(new Uint8Array(e,0,4))===wf){try{a[Qe.KHR_BINARY_GLTF]=new gb(e)}catch(u){r&&r(u);return}s=JSON.parse(a[Qe.KHR_BINARY_GLTF].content)}else s=JSON.parse(l.decode(e));else s=e;if(s.asset===void 0||s.asset.version[0]<2){r&&r(new Error("THREE.GLTFLoader: Unsupported asset. glTF versions >=2.0 are supported."));return}const c=new Cb(s,{path:t||this.resourcePath||"",crossOrigin:this.crossOrigin,requestHeader:this.requestHeader,manager:this.manager,ktx2Loader:this.ktx2Loader,meshoptDecoder:this.meshoptDecoder});c.fileLoader.setRequestHeader(this.requestHeader);for(let d=0;d<this.pluginCallbacks.length;d++){const u=this.pluginCallbacks[d](c);u.name||console.error("THREE.GLTFLoader: Invalid plugin found: missing name"),o[u.name]=u,a[u.name]=!0}if(s.extensionsUsed)for(let d=0;d<s.extensionsUsed.length;++d){const u=s.extensionsUsed[d],h=s.extensionsRequired||[];switch(u){case Qe.KHR_MATERIALS_UNLIT:a[u]=new Qy;break;case Qe.KHR_DRACO_MESH_COMPRESSION:a[u]=new vb(s,this.dracoLoader);break;case Qe.KHR_TEXTURE_TRANSFORM:a[u]=new _b;break;case Qe.KHR_MESH_QUANTIZATION:a[u]=new xb;break;default:h.indexOf(u)>=0&&o[u]===void 0&&console.warn('THREE.GLTFLoader: Unknown extension "'+u+'".')}}c.setExtensions(a),c.setPlugins(o),c.parse(n,r)}parseAsync(e,t){const n=this;return new Promise(function(r,s){n.parse(e,t,r,s)})}}function Zy(){let i={};return{get:function(e){return i[e]},add:function(e,t){i[e]=t},remove:function(e){delete i[e]},removeAll:function(){i={}}}}const Qe={KHR_BINARY_GLTF:"KHR_binary_glTF",KHR_DRACO_MESH_COMPRESSION:"KHR_draco_mesh_compression",KHR_LIGHTS_PUNCTUAL:"KHR_lights_punctual",KHR_MATERIALS_CLEARCOAT:"KHR_materials_clearcoat",KHR_MATERIALS_DISPERSION:"KHR_materials_dispersion",KHR_MATERIALS_IOR:"KHR_materials_ior",KHR_MATERIALS_SHEEN:"KHR_materials_sheen",KHR_MATERIALS_SPECULAR:"KHR_materials_specular",KHR_MATERIALS_TRANSMISSION:"KHR_materials_transmission",KHR_MATERIALS_IRIDESCENCE:"KHR_materials_iridescence",KHR_MATERIALS_ANISOTROPY:"KHR_materials_anisotropy",KHR_MATERIALS_UNLIT:"KHR_materials_unlit",KHR_MATERIALS_VOLUME:"KHR_materials_volume",KHR_TEXTURE_BASISU:"KHR_texture_basisu",KHR_TEXTURE_TRANSFORM:"KHR_texture_transform",KHR_MESH_QUANTIZATION:"KHR_mesh_quantization",KHR_MATERIALS_EMISSIVE_STRENGTH:"KHR_materials_emissive_strength",EXT_MATERIALS_BUMP:"EXT_materials_bump",EXT_TEXTURE_WEBP:"EXT_texture_webp",EXT_TEXTURE_AVIF:"EXT_texture_avif",EXT_MESHOPT_COMPRESSION:"EXT_meshopt_compression",EXT_MESH_GPU_INSTANCING:"EXT_mesh_gpu_instancing"};class Jy{constructor(e){this.parser=e,this.name=Qe.KHR_LIGHTS_PUNCTUAL,this.cache={refs:{},uses:{}}}_markDefs(){const e=this.parser,t=this.parser.json.nodes||[];for(let n=0,r=t.length;n<r;n++){const s=t[n];s.extensions&&s.extensions[this.name]&&s.extensions[this.name].light!==void 0&&e._addNodeRef(this.cache,s.extensions[this.name].light)}}_loadLight(e){const t=this.parser,n="light:"+e;let r=t.cache.get(n);if(r)return r;const s=t.json,l=((s.extensions&&s.extensions[this.name]||{}).lights||[])[e];let c;const d=new Ie(16777215);l.color!==void 0&&d.setRGB(l.color[0],l.color[1],l.color[2],en);const u=l.range!==void 0?l.range:0;switch(l.type){case"directional":c=new vf(d),c.target.position.set(0,0,-1),c.add(c.target);break;case"point":c=new vg(d),c.distance=u;break;case"spot":c=new mg(d),c.distance=u,l.spot=l.spot||{},l.spot.innerConeAngle=l.spot.innerConeAngle!==void 0?l.spot.innerConeAngle:0,l.spot.outerConeAngle=l.spot.outerConeAngle!==void 0?l.spot.outerConeAngle:Math.PI/4,c.angle=l.spot.outerConeAngle,c.penumbra=1-l.spot.innerConeAngle/l.spot.outerConeAngle,c.target.position.set(0,0,-1),c.add(c.target);break;default:throw new Error("THREE.GLTFLoader: Unexpected light type: "+l.type)}return c.position.set(0,0,0),Wn(c,l),l.intensity!==void 0&&(c.intensity=l.intensity),c.name=t.createUniqueName(l.name||"light_"+e),r=Promise.resolve(c),t.cache.add(n,r),r}getDependency(e,t){if(e==="light")return this._loadLight(t)}createNodeAttachment(e){const t=this,n=this.parser,s=n.json.nodes[e],o=(s.extensions&&s.extensions[this.name]||{}).light;return o===void 0?null:this._loadLight(o).then(function(l){return n._getNodeRef(t.cache,o,l)})}}class Qy{constructor(){this.name=Qe.KHR_MATERIALS_UNLIT}getMaterialType(){return Ut}extendParams(e,t,n){const r=[];e.color=new Ie(1,1,1),e.opacity=1;const s=t.pbrMetallicRoughness;if(s){if(Array.isArray(s.baseColorFactor)){const a=s.baseColorFactor;e.color.setRGB(a[0],a[1],a[2],en),e.opacity=a[3]}s.baseColorTexture!==void 0&&r.push(n.assignTexture(e,"map",s.baseColorTexture,_t))}return Promise.all(r)}}class eb{constructor(e){this.parser=e,this.name=Qe.KHR_MATERIALS_EMISSIVE_STRENGTH}extendMaterialParams(e,t){const r=this.parser.json.materials[e];if(!r.extensions||!r.extensions[this.name])return Promise.resolve();const s=r.extensions[this.name].emissiveStrength;return s!==void 0&&(t.emissiveIntensity=s),Promise.resolve()}}class tb{constructor(e){this.parser=e,this.name=Qe.KHR_MATERIALS_CLEARCOAT}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Kn}extendMaterialParams(e,t){const n=this.parser,r=n.json.materials[e];if(!r.extensions||!r.extensions[this.name])return Promise.resolve();const s=[],a=r.extensions[this.name];if(a.clearcoatFactor!==void 0&&(t.clearcoat=a.clearcoatFactor),a.clearcoatTexture!==void 0&&s.push(n.assignTexture(t,"clearcoatMap",a.clearcoatTexture)),a.clearcoatRoughnessFactor!==void 0&&(t.clearcoatRoughness=a.clearcoatRoughnessFactor),a.clearcoatRoughnessTexture!==void 0&&s.push(n.assignTexture(t,"clearcoatRoughnessMap",a.clearcoatRoughnessTexture)),a.clearcoatNormalTexture!==void 0&&(s.push(n.assignTexture(t,"clearcoatNormalMap",a.clearcoatNormalTexture)),a.clearcoatNormalTexture.scale!==void 0)){const o=a.clearcoatNormalTexture.scale;t.clearcoatNormalScale=new Ce(o,o)}return Promise.all(s)}}class nb{constructor(e){this.parser=e,this.name=Qe.KHR_MATERIALS_DISPERSION}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Kn}extendMaterialParams(e,t){const r=this.parser.json.materials[e];if(!r.extensions||!r.extensions[this.name])return Promise.resolve();const s=r.extensions[this.name];return t.dispersion=s.dispersion!==void 0?s.dispersion:0,Promise.resolve()}}class ib{constructor(e){this.parser=e,this.name=Qe.KHR_MATERIALS_IRIDESCENCE}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Kn}extendMaterialParams(e,t){const n=this.parser,r=n.json.materials[e];if(!r.extensions||!r.extensions[this.name])return Promise.resolve();const s=[],a=r.extensions[this.name];return a.iridescenceFactor!==void 0&&(t.iridescence=a.iridescenceFactor),a.iridescenceTexture!==void 0&&s.push(n.assignTexture(t,"iridescenceMap",a.iridescenceTexture)),a.iridescenceIor!==void 0&&(t.iridescenceIOR=a.iridescenceIor),t.iridescenceThicknessRange===void 0&&(t.iridescenceThicknessRange=[100,400]),a.iridescenceThicknessMinimum!==void 0&&(t.iridescenceThicknessRange[0]=a.iridescenceThicknessMinimum),a.iridescenceThicknessMaximum!==void 0&&(t.iridescenceThicknessRange[1]=a.iridescenceThicknessMaximum),a.iridescenceThicknessTexture!==void 0&&s.push(n.assignTexture(t,"iridescenceThicknessMap",a.iridescenceThicknessTexture)),Promise.all(s)}}class rb{constructor(e){this.parser=e,this.name=Qe.KHR_MATERIALS_SHEEN}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Kn}extendMaterialParams(e,t){const n=this.parser,r=n.json.materials[e];if(!r.extensions||!r.extensions[this.name])return Promise.resolve();const s=[];t.sheenColor=new Ie(0,0,0),t.sheenRoughness=0,t.sheen=1;const a=r.extensions[this.name];if(a.sheenColorFactor!==void 0){const o=a.sheenColorFactor;t.sheenColor.setRGB(o[0],o[1],o[2],en)}return a.sheenRoughnessFactor!==void 0&&(t.sheenRoughness=a.sheenRoughnessFactor),a.sheenColorTexture!==void 0&&s.push(n.assignTexture(t,"sheenColorMap",a.sheenColorTexture,_t)),a.sheenRoughnessTexture!==void 0&&s.push(n.assignTexture(t,"sheenRoughnessMap",a.sheenRoughnessTexture)),Promise.all(s)}}class sb{constructor(e){this.parser=e,this.name=Qe.KHR_MATERIALS_TRANSMISSION}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Kn}extendMaterialParams(e,t){const n=this.parser,r=n.json.materials[e];if(!r.extensions||!r.extensions[this.name])return Promise.resolve();const s=[],a=r.extensions[this.name];return a.transmissionFactor!==void 0&&(t.transmission=a.transmissionFactor),a.transmissionTexture!==void 0&&s.push(n.assignTexture(t,"transmissionMap",a.transmissionTexture)),Promise.all(s)}}class ab{constructor(e){this.parser=e,this.name=Qe.KHR_MATERIALS_VOLUME}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Kn}extendMaterialParams(e,t){const n=this.parser,r=n.json.materials[e];if(!r.extensions||!r.extensions[this.name])return Promise.resolve();const s=[],a=r.extensions[this.name];t.thickness=a.thicknessFactor!==void 0?a.thicknessFactor:0,a.thicknessTexture!==void 0&&s.push(n.assignTexture(t,"thicknessMap",a.thicknessTexture)),t.attenuationDistance=a.attenuationDistance||1/0;const o=a.attenuationColor||[1,1,1];return t.attenuationColor=new Ie().setRGB(o[0],o[1],o[2],en),Promise.all(s)}}class ob{constructor(e){this.parser=e,this.name=Qe.KHR_MATERIALS_IOR}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Kn}extendMaterialParams(e,t){const r=this.parser.json.materials[e];if(!r.extensions||!r.extensions[this.name])return Promise.resolve();const s=r.extensions[this.name];return t.ior=s.ior!==void 0?s.ior:1.5,Promise.resolve()}}class lb{constructor(e){this.parser=e,this.name=Qe.KHR_MATERIALS_SPECULAR}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Kn}extendMaterialParams(e,t){const n=this.parser,r=n.json.materials[e];if(!r.extensions||!r.extensions[this.name])return Promise.resolve();const s=[],a=r.extensions[this.name];t.specularIntensity=a.specularFactor!==void 0?a.specularFactor:1,a.specularTexture!==void 0&&s.push(n.assignTexture(t,"specularIntensityMap",a.specularTexture));const o=a.specularColorFactor||[1,1,1];return t.specularColor=new Ie().setRGB(o[0],o[1],o[2],en),a.specularColorTexture!==void 0&&s.push(n.assignTexture(t,"specularColorMap",a.specularColorTexture,_t)),Promise.all(s)}}class cb{constructor(e){this.parser=e,this.name=Qe.EXT_MATERIALS_BUMP}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Kn}extendMaterialParams(e,t){const n=this.parser,r=n.json.materials[e];if(!r.extensions||!r.extensions[this.name])return Promise.resolve();const s=[],a=r.extensions[this.name];return t.bumpScale=a.bumpFactor!==void 0?a.bumpFactor:1,a.bumpTexture!==void 0&&s.push(n.assignTexture(t,"bumpMap",a.bumpTexture)),Promise.all(s)}}class ub{constructor(e){this.parser=e,this.name=Qe.KHR_MATERIALS_ANISOTROPY}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Kn}extendMaterialParams(e,t){const n=this.parser,r=n.json.materials[e];if(!r.extensions||!r.extensions[this.name])return Promise.resolve();const s=[],a=r.extensions[this.name];return a.anisotropyStrength!==void 0&&(t.anisotropy=a.anisotropyStrength),a.anisotropyRotation!==void 0&&(t.anisotropyRotation=a.anisotropyRotation),a.anisotropyTexture!==void 0&&s.push(n.assignTexture(t,"anisotropyMap",a.anisotropyTexture)),Promise.all(s)}}class db{constructor(e){this.parser=e,this.name=Qe.KHR_TEXTURE_BASISU}loadTexture(e){const t=this.parser,n=t.json,r=n.textures[e];if(!r.extensions||!r.extensions[this.name])return null;const s=r.extensions[this.name],a=t.options.ktx2Loader;if(!a){if(n.extensionsRequired&&n.extensionsRequired.indexOf(this.name)>=0)throw new Error("THREE.GLTFLoader: setKTX2Loader must be called before loading KTX2 textures");return null}return t.loadTextureImage(e,s.source,a)}}class hb{constructor(e){this.parser=e,this.name=Qe.EXT_TEXTURE_WEBP}loadTexture(e){const t=this.name,n=this.parser,r=n.json,s=r.textures[e];if(!s.extensions||!s.extensions[t])return null;const a=s.extensions[t],o=r.images[a.source];let l=n.textureLoader;if(o.uri){const c=n.options.manager.getHandler(o.uri);c!==null&&(l=c)}return n.loadTextureImage(e,a.source,l)}}class fb{constructor(e){this.parser=e,this.name=Qe.EXT_TEXTURE_AVIF}loadTexture(e){const t=this.name,n=this.parser,r=n.json,s=r.textures[e];if(!s.extensions||!s.extensions[t])return null;const a=s.extensions[t],o=r.images[a.source];let l=n.textureLoader;if(o.uri){const c=n.options.manager.getHandler(o.uri);c!==null&&(l=c)}return n.loadTextureImage(e,a.source,l)}}class pb{constructor(e){this.name=Qe.EXT_MESHOPT_COMPRESSION,this.parser=e}loadBufferView(e){const t=this.parser.json,n=t.bufferViews[e];if(n.extensions&&n.extensions[this.name]){const r=n.extensions[this.name],s=this.parser.getDependency("buffer",r.buffer),a=this.parser.options.meshoptDecoder;if(!a||!a.supported){if(t.extensionsRequired&&t.extensionsRequired.indexOf(this.name)>=0)throw new Error("THREE.GLTFLoader: setMeshoptDecoder must be called before loading compressed files");return null}return s.then(function(o){const l=r.byteOffset||0,c=r.byteLength||0,d=r.count,u=r.byteStride,h=new Uint8Array(o,l,c);return a.decodeGltfBufferAsync?a.decodeGltfBufferAsync(d,u,h,r.mode,r.filter).then(function(p){return p.buffer}):a.ready.then(function(){const p=new ArrayBuffer(d*u);return a.decodeGltfBuffer(new Uint8Array(p),d,u,h,r.mode,r.filter),p})})}else return null}}class mb{constructor(e){this.name=Qe.EXT_MESH_GPU_INSTANCING,this.parser=e}createNodeMesh(e){const t=this.parser.json,n=t.nodes[e];if(!n.extensions||!n.extensions[this.name]||n.mesh===void 0)return null;const r=t.meshes[n.mesh];for(const c of r.primitives)if(c.mode!==An.TRIANGLES&&c.mode!==An.TRIANGLE_STRIP&&c.mode!==An.TRIANGLE_FAN&&c.mode!==void 0)return null;const a=n.extensions[this.name].attributes,o=[],l={};for(const c in a)o.push(this.parser.getDependency("accessor",a[c]).then(d=>(l[c]=d,l[c])));return o.length<1?null:(o.push(this.parser.createNodeMesh(e)),Promise.all(o).then(c=>{const d=c.pop(),u=d.isGroup?d.children:[d],h=c[0].count,p=[];for(const g of u){const v=new qe,m=new U,f=new dt,b=new U(1,1,1),_=new qm(g.geometry,g.material,h);for(let x=0;x<h;x++)l.TRANSLATION&&m.fromBufferAttribute(l.TRANSLATION,x),l.ROTATION&&f.fromBufferAttribute(l.ROTATION,x),l.SCALE&&b.fromBufferAttribute(l.SCALE,x),_.setMatrixAt(x,v.compose(m,f,b));for(const x in l)if(x==="_COLOR_0"){const R=l[x];_.instanceColor=new Gr(R.array,R.itemSize,R.normalized)}else x!=="TRANSLATION"&&x!=="ROTATION"&&x!=="SCALE"&&g.geometry.setAttribute(x,l[x]);Mt.prototype.copy.call(_,g),this.parser.assignFinalMaterial(_),p.push(_)}return d.isGroup?(d.clear(),d.add(...p),d):p[0]}))}}const wf="glTF",xs=12,Hd={JSON:1313821514,BIN:5130562};class gb{constructor(e){this.name=Qe.KHR_BINARY_GLTF,this.content=null,this.body=null;const t=new DataView(e,0,xs),n=new TextDecoder;if(this.header={magic:n.decode(new Uint8Array(e.slice(0,4))),version:t.getUint32(4,!0),length:t.getUint32(8,!0)},this.header.magic!==wf)throw new Error("THREE.GLTFLoader: Unsupported glTF-Binary header.");if(this.header.version<2)throw new Error("THREE.GLTFLoader: Legacy binary file detected.");const r=this.header.length-xs,s=new DataView(e,xs);let a=0;for(;a<r;){const o=s.getUint32(a,!0);a+=4;const l=s.getUint32(a,!0);if(a+=4,l===Hd.JSON){const c=new Uint8Array(e,xs+a,o);this.content=n.decode(c)}else if(l===Hd.BIN){const c=xs+a;this.body=e.slice(c,c+o)}a+=o}if(this.content===null)throw new Error("THREE.GLTFLoader: JSON content not found.")}}class vb{constructor(e,t){if(!t)throw new Error("THREE.GLTFLoader: No DRACOLoader instance provided.");this.name=Qe.KHR_DRACO_MESH_COMPRESSION,this.json=e,this.dracoLoader=t,this.dracoLoader.preload()}decodePrimitive(e,t){const n=this.json,r=this.dracoLoader,s=e.extensions[this.name].bufferView,a=e.extensions[this.name].attributes,o={},l={},c={};for(const d in a){const u=gc[d]||d.toLowerCase();o[u]=a[d]}for(const d in e.attributes){const u=gc[d]||d.toLowerCase();if(a[d]!==void 0){const h=n.accessors[e.attributes[d]],p=Lr[h.componentType];c[u]=p.name,l[u]=h.normalized===!0}}return t.getDependency("bufferView",s).then(function(d){return new Promise(function(u,h){r.decodeDracoFile(d,function(p){for(const g in p.attributes){const v=p.attributes[g],m=l[g];m!==void 0&&(v.normalized=m)}u(p)},o,c,en,h)})})}}class _b{constructor(){this.name=Qe.KHR_TEXTURE_TRANSFORM}extendTexture(e,t){return(t.texCoord===void 0||t.texCoord===e.channel)&&t.offset===void 0&&t.rotation===void 0&&t.scale===void 0||(e=e.clone(),t.texCoord!==void 0&&(e.channel=t.texCoord),t.offset!==void 0&&e.offset.fromArray(t.offset),t.rotation!==void 0&&(e.rotation=t.rotation),t.scale!==void 0&&e.repeat.fromArray(t.scale),e.needsUpdate=!0),e}}class xb{constructor(){this.name=Qe.KHR_MESH_QUANTIZATION}}class Rf extends Gs{constructor(e,t,n,r){super(e,t,n,r)}copySampleValue_(e){const t=this.resultBuffer,n=this.sampleValues,r=this.valueSize,s=e*r*3+r;for(let a=0;a!==r;a++)t[a]=n[s+a];return t}interpolate_(e,t,n,r){const s=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=o*2,c=o*3,d=r-t,u=(n-t)/d,h=u*u,p=h*u,g=e*c,v=g-c,m=-2*p+3*h,f=p-h,b=1-m,_=f-h+u;for(let x=0;x!==o;x++){const R=a[v+x+o],M=a[v+x+l]*d,A=a[g+x+o],w=a[g+x]*d;s[x]=b*R+_*M+m*A+f*w}return s}}const yb=new dt;class bb extends Rf{interpolate_(e,t,n,r){const s=super.interpolate_(e,t,n,r);return yb.fromArray(s).normalize().toArray(s),s}}const An={POINTS:0,LINES:1,LINE_LOOP:2,LINE_STRIP:3,TRIANGLES:4,TRIANGLE_STRIP:5,TRIANGLE_FAN:6},Lr={5120:Int8Array,5121:Uint8Array,5122:Int16Array,5123:Uint16Array,5125:Uint32Array,5126:Float32Array},Gd={9728:Jt,9729:Dt,9984:Vh,9985:Ua,9986:bs,9987:Gt},Wd={33071:Ci,33648:Ga,10497:zr},pl={SCALAR:1,VEC2:2,VEC3:3,VEC4:4,MAT2:4,MAT3:9,MAT4:16},gc={POSITION:"position",NORMAL:"normal",TANGENT:"tangent",TEXCOORD_0:"uv",TEXCOORD_1:"uv1",TEXCOORD_2:"uv2",TEXCOORD_3:"uv3",COLOR_0:"color",WEIGHTS_0:"skinWeight",JOINTS_0:"skinIndex"},yi={scale:"scale",translation:"position",rotation:"quaternion",weights:"morphTargetInfluences"},Sb={CUBICSPLINE:void 0,LINEAR:Ds,STEP:Ls},ml={OPAQUE:"OPAQUE",MASK:"MASK",BLEND:"BLEND"};function Mb(i){return i.DefaultMaterial===void 0&&(i.DefaultMaterial=new jc({color:16777215,emissive:0,metalness:1,roughness:1,transparent:!1,depthTest:!0,side:fi})),i.DefaultMaterial}function Xi(i,e,t){for(const n in t.extensions)i[n]===void 0&&(e.userData.gltfExtensions=e.userData.gltfExtensions||{},e.userData.gltfExtensions[n]=t.extensions[n])}function Wn(i,e){e.extras!==void 0&&(typeof e.extras=="object"?Object.assign(i.userData,e.extras):console.warn("THREE.GLTFLoader: Ignoring primitive type .extras, "+e.extras))}function Eb(i,e,t){let n=!1,r=!1,s=!1;for(let c=0,d=e.length;c<d;c++){const u=e[c];if(u.POSITION!==void 0&&(n=!0),u.NORMAL!==void 0&&(r=!0),u.COLOR_0!==void 0&&(s=!0),n&&r&&s)break}if(!n&&!r&&!s)return Promise.resolve(i);const a=[],o=[],l=[];for(let c=0,d=e.length;c<d;c++){const u=e[c];if(n){const h=u.POSITION!==void 0?t.getDependency("accessor",u.POSITION):i.attributes.position;a.push(h)}if(r){const h=u.NORMAL!==void 0?t.getDependency("accessor",u.NORMAL):i.attributes.normal;o.push(h)}if(s){const h=u.COLOR_0!==void 0?t.getDependency("accessor",u.COLOR_0):i.attributes.color;l.push(h)}}return Promise.all([Promise.all(a),Promise.all(o),Promise.all(l)]).then(function(c){const d=c[0],u=c[1],h=c[2];return n&&(i.morphAttributes.position=d),r&&(i.morphAttributes.normal=u),s&&(i.morphAttributes.color=h),i.morphTargetsRelative=!0,i})}function Tb(i,e){if(i.updateMorphTargets(),e.weights!==void 0)for(let t=0,n=e.weights.length;t<n;t++)i.morphTargetInfluences[t]=e.weights[t];if(e.extras&&Array.isArray(e.extras.targetNames)){const t=e.extras.targetNames;if(i.morphTargetInfluences.length===t.length){i.morphTargetDictionary={};for(let n=0,r=t.length;n<r;n++)i.morphTargetDictionary[t[n]]=n}else console.warn("THREE.GLTFLoader: Invalid extras.targetNames length. Ignoring names.")}}function Ab(i){let e;const t=i.extensions&&i.extensions[Qe.KHR_DRACO_MESH_COMPRESSION];if(t?e="draco:"+t.bufferView+":"+t.indices+":"+gl(t.attributes):e=i.indices+":"+gl(i.attributes)+":"+i.mode,i.targets!==void 0)for(let n=0,r=i.targets.length;n<r;n++)e+=":"+gl(i.targets[n]);return e}function gl(i){let e="";const t=Object.keys(i).sort();for(let n=0,r=t.length;n<r;n++)e+=t[n]+":"+i[t[n]]+";";return e}function vc(i){switch(i){case Int8Array:return 1/127;case Uint8Array:return 1/255;case Int16Array:return 1/32767;case Uint16Array:return 1/65535;default:throw new Error("THREE.GLTFLoader: Unsupported normalized accessor component type.")}}function wb(i){return i.search(/\.jpe?g($|\?)/i)>0||i.search(/^data\:image\/jpeg/)===0?"image/jpeg":i.search(/\.webp($|\?)/i)>0||i.search(/^data\:image\/webp/)===0?"image/webp":i.search(/\.ktx2($|\?)/i)>0||i.search(/^data\:image\/ktx2/)===0?"image/ktx2":"image/png"}const Rb=new qe;class Cb{constructor(e={},t={}){this.json=e,this.extensions={},this.plugins={},this.options=t,this.cache=new Zy,this.associations=new Map,this.primitiveCache={},this.nodeCache={},this.meshCache={refs:{},uses:{}},this.cameraCache={refs:{},uses:{}},this.lightCache={refs:{},uses:{}},this.sourceCache={},this.textureCache={},this.nodeNamesUsed={};let n=!1,r=-1,s=!1,a=-1;if(typeof navigator<"u"){const o=navigator.userAgent;n=/^((?!chrome|android).)*safari/i.test(o)===!0;const l=o.match(/Version\/(\d+)/);r=n&&l?parseInt(l[1],10):-1,s=o.indexOf("Firefox")>-1,a=s?o.match(/Firefox\/([0-9]+)\./)[1]:-1}typeof createImageBitmap>"u"||n&&r<17||s&&a<98?this.textureLoader=new ns(this.options.manager):this.textureLoader=new yg(this.options.manager),this.textureLoader.setCrossOrigin(this.options.crossOrigin),this.textureLoader.setRequestHeader(this.options.requestHeader),this.fileLoader=new gf(this.options.manager),this.fileLoader.setResponseType("arraybuffer"),this.options.crossOrigin==="use-credentials"&&this.fileLoader.setWithCredentials(!0)}setExtensions(e){this.extensions=e}setPlugins(e){this.plugins=e}parse(e,t){const n=this,r=this.json,s=this.extensions;this.cache.removeAll(),this.nodeCache={},this._invokeAll(function(a){return a._markDefs&&a._markDefs()}),Promise.all(this._invokeAll(function(a){return a.beforeRoot&&a.beforeRoot()})).then(function(){return Promise.all([n.getDependencies("scene"),n.getDependencies("animation"),n.getDependencies("camera")])}).then(function(a){const o={scene:a[0][r.scene||0],scenes:a[0],animations:a[1],cameras:a[2],asset:r.asset,parser:n,userData:{}};return Xi(s,o,r),Wn(o,r),Promise.all(n._invokeAll(function(l){return l.afterRoot&&l.afterRoot(o)})).then(function(){for(const l of o.scenes)l.updateMatrixWorld();e(o)})}).catch(t)}_markDefs(){const e=this.json.nodes||[],t=this.json.skins||[],n=this.json.meshes||[];for(let r=0,s=t.length;r<s;r++){const a=t[r].joints;for(let o=0,l=a.length;o<l;o++)e[a[o]].isBone=!0}for(let r=0,s=e.length;r<s;r++){const a=e[r];a.mesh!==void 0&&(this._addNodeRef(this.meshCache,a.mesh),a.skin!==void 0&&(n[a.mesh].isSkinnedMesh=!0)),a.camera!==void 0&&this._addNodeRef(this.cameraCache,a.camera)}}_addNodeRef(e,t){t!==void 0&&(e.refs[t]===void 0&&(e.refs[t]=e.uses[t]=0),e.refs[t]++)}_getNodeRef(e,t,n){if(e.refs[t]<=1)return n;const r=n.clone(),s=(a,o)=>{const l=this.associations.get(a);l!=null&&this.associations.set(o,l);for(const[c,d]of a.children.entries())s(d,o.children[c])};return s(n,r),r.name+="_instance_"+e.uses[t]++,r}_invokeOne(e){const t=Object.values(this.plugins);t.push(this);for(let n=0;n<t.length;n++){const r=e(t[n]);if(r)return r}return null}_invokeAll(e){const t=Object.values(this.plugins);t.unshift(this);const n=[];for(let r=0;r<t.length;r++){const s=e(t[r]);s&&n.push(s)}return n}getDependency(e,t){const n=e+":"+t;let r=this.cache.get(n);if(!r){switch(e){case"scene":r=this.loadScene(t);break;case"node":r=this._invokeOne(function(s){return s.loadNode&&s.loadNode(t)});break;case"mesh":r=this._invokeOne(function(s){return s.loadMesh&&s.loadMesh(t)});break;case"accessor":r=this.loadAccessor(t);break;case"bufferView":r=this._invokeOne(function(s){return s.loadBufferView&&s.loadBufferView(t)});break;case"buffer":r=this.loadBuffer(t);break;case"material":r=this._invokeOne(function(s){return s.loadMaterial&&s.loadMaterial(t)});break;case"texture":r=this._invokeOne(function(s){return s.loadTexture&&s.loadTexture(t)});break;case"skin":r=this.loadSkin(t);break;case"animation":r=this._invokeOne(function(s){return s.loadAnimation&&s.loadAnimation(t)});break;case"camera":r=this.loadCamera(t);break;default:if(r=this._invokeOne(function(s){return s!=this&&s.getDependency&&s.getDependency(e,t)}),!r)throw new Error("Unknown type: "+e);break}this.cache.add(n,r)}return r}getDependencies(e){let t=this.cache.get(e);if(!t){const n=this,r=this.json[e+(e==="mesh"?"es":"s")]||[];t=Promise.all(r.map(function(s,a){return n.getDependency(e,a)})),this.cache.add(e,t)}return t}loadBuffer(e){const t=this.json.buffers[e],n=this.fileLoader;if(t.type&&t.type!=="arraybuffer")throw new Error("THREE.GLTFLoader: "+t.type+" buffer type is not supported.");if(t.uri===void 0&&e===0)return Promise.resolve(this.extensions[Qe.KHR_BINARY_GLTF].body);const r=this.options;return new Promise(function(s,a){n.load(As.resolveURL(t.uri,r.path),s,void 0,function(){a(new Error('THREE.GLTFLoader: Failed to load buffer "'+t.uri+'".'))})})}loadBufferView(e){const t=this.json.bufferViews[e];return this.getDependency("buffer",t.buffer).then(function(n){const r=t.byteLength||0,s=t.byteOffset||0;return n.slice(s,s+r)})}loadAccessor(e){const t=this,n=this.json,r=this.json.accessors[e];if(r.bufferView===void 0&&r.sparse===void 0){const a=pl[r.type],o=Lr[r.componentType],l=r.normalized===!0,c=new o(r.count*a);return Promise.resolve(new ct(c,a,l))}const s=[];return r.bufferView!==void 0?s.push(this.getDependency("bufferView",r.bufferView)):s.push(null),r.sparse!==void 0&&(s.push(this.getDependency("bufferView",r.sparse.indices.bufferView)),s.push(this.getDependency("bufferView",r.sparse.values.bufferView))),Promise.all(s).then(function(a){const o=a[0],l=pl[r.type],c=Lr[r.componentType],d=c.BYTES_PER_ELEMENT,u=d*l,h=r.byteOffset||0,p=r.bufferView!==void 0?n.bufferViews[r.bufferView].byteStride:void 0,g=r.normalized===!0;let v,m;if(p&&p!==u){const f=Math.floor(h/p),b="InterleavedBuffer:"+r.bufferView+":"+r.componentType+":"+f+":"+r.count;let _=t.cache.get(b);_||(v=new c(o,f*p,r.count*p/d),_=new of(v,p/d),t.cache.add(b,_)),m=new Us(_,l,h%p/d,g)}else o===null?v=new c(r.count*l):v=new c(o,h,r.count*l),m=new ct(v,l,g);if(r.sparse!==void 0){const f=pl.SCALAR,b=Lr[r.sparse.indices.componentType],_=r.sparse.indices.byteOffset||0,x=r.sparse.values.byteOffset||0,R=new b(a[1],_,r.sparse.count*f),M=new c(a[2],x,r.sparse.count*l);o!==null&&(m=new ct(m.array.slice(),m.itemSize,m.normalized)),m.normalized=!1;for(let A=0,w=R.length;A<w;A++){const S=R[A];if(m.setX(S,M[A*l]),l>=2&&m.setY(S,M[A*l+1]),l>=3&&m.setZ(S,M[A*l+2]),l>=4&&m.setW(S,M[A*l+3]),l>=5)throw new Error("THREE.GLTFLoader: Unsupported itemSize in sparse BufferAttribute.")}m.normalized=g}return m})}loadTexture(e){const t=this.json,n=this.options,s=t.textures[e].source,a=t.images[s];let o=this.textureLoader;if(a.uri){const l=n.manager.getHandler(a.uri);l!==null&&(o=l)}return this.loadTextureImage(e,s,o)}loadTextureImage(e,t,n){const r=this,s=this.json,a=s.textures[e],o=s.images[t],l=(o.uri||o.bufferView)+":"+a.sampler;if(this.textureCache[l])return this.textureCache[l];const c=this.loadImageSource(t,n).then(function(d){d.flipY=!1,d.name=a.name||o.name||"",d.name===""&&typeof o.uri=="string"&&o.uri.startsWith("data:image/")===!1&&(d.name=o.uri);const h=(s.samplers||{})[a.sampler]||{};return d.magFilter=Gd[h.magFilter]||Dt,d.minFilter=Gd[h.minFilter]||Gt,d.wrapS=Wd[h.wrapS]||zr,d.wrapT=Wd[h.wrapT]||zr,d.generateMipmaps=!d.isCompressedTexture&&d.minFilter!==Jt&&d.minFilter!==Dt,r.associations.set(d,{textures:e}),d}).catch(function(){return null});return this.textureCache[l]=c,c}loadImageSource(e,t){const n=this,r=this.json,s=this.options;if(this.sourceCache[e]!==void 0)return this.sourceCache[e].then(u=>u.clone());const a=r.images[e],o=self.URL||self.webkitURL;let l=a.uri||"",c=!1;if(a.bufferView!==void 0)l=n.getDependency("bufferView",a.bufferView).then(function(u){c=!0;const h=new Blob([u],{type:a.mimeType});return l=o.createObjectURL(h),l});else if(a.uri===void 0)throw new Error("THREE.GLTFLoader: Image "+e+" is missing URI and bufferView");const d=Promise.resolve(l).then(function(u){return new Promise(function(h,p){let g=h;t.isImageBitmapLoader===!0&&(g=function(v){const m=new Ft(v);m.needsUpdate=!0,h(m)}),t.load(As.resolveURL(u,s.path),g,void 0,p)})}).then(function(u){return c===!0&&o.revokeObjectURL(l),Wn(u,a),u.userData.mimeType=a.mimeType||wb(a.uri),u}).catch(function(u){throw console.error("THREE.GLTFLoader: Couldn't load texture",l),u});return this.sourceCache[e]=d,d}assignTexture(e,t,n,r){const s=this;return this.getDependency("texture",n.index).then(function(a){if(!a)return null;if(n.texCoord!==void 0&&n.texCoord>0&&(a=a.clone(),a.channel=n.texCoord),s.extensions[Qe.KHR_TEXTURE_TRANSFORM]){const o=n.extensions!==void 0?n.extensions[Qe.KHR_TEXTURE_TRANSFORM]:void 0;if(o){const l=s.associations.get(a);a=s.extensions[Qe.KHR_TEXTURE_TRANSFORM].extendTexture(a,o),s.associations.set(a,l)}}return r!==void 0&&(a.colorSpace=r),e[t]=a,a})}assignFinalMaterial(e){const t=e.geometry;let n=e.material;const r=t.attributes.tangent===void 0,s=t.attributes.color!==void 0,a=t.attributes.normal===void 0;if(e.isPoints){const o="PointsMaterial:"+n.uuid;let l=this.cache.get(o);l||(l=new df,In.prototype.copy.call(l,n),l.color.copy(n.color),l.map=n.map,l.sizeAttenuation=!1,this.cache.add(o,l)),n=l}else if(e.isLine){const o="LineBasicMaterial:"+n.uuid;let l=this.cache.get(o);l||(l=new Gc,In.prototype.copy.call(l,n),l.color.copy(n.color),l.map=n.map,this.cache.add(o,l)),n=l}if(r||s||a){let o="ClonedMaterial:"+n.uuid+":";r&&(o+="derivative-tangents:"),s&&(o+="vertex-colors:"),a&&(o+="flat-shading:");let l=this.cache.get(o);l||(l=n.clone(),s&&(l.vertexColors=!0),a&&(l.flatShading=!0),r&&(l.normalScale&&(l.normalScale.y*=-1),l.clearcoatNormalScale&&(l.clearcoatNormalScale.y*=-1)),this.cache.add(o,l),this.associations.set(l,this.associations.get(n))),n=l}e.material=n}getMaterialType(){return jc}loadMaterial(e){const t=this,n=this.json,r=this.extensions,s=n.materials[e];let a;const o={},l=s.extensions||{},c=[];if(l[Qe.KHR_MATERIALS_UNLIT]){const u=r[Qe.KHR_MATERIALS_UNLIT];a=u.getMaterialType(),c.push(u.extendParams(o,s,t))}else{const u=s.pbrMetallicRoughness||{};if(o.color=new Ie(1,1,1),o.opacity=1,Array.isArray(u.baseColorFactor)){const h=u.baseColorFactor;o.color.setRGB(h[0],h[1],h[2],en),o.opacity=h[3]}u.baseColorTexture!==void 0&&c.push(t.assignTexture(o,"map",u.baseColorTexture,_t)),o.metalness=u.metallicFactor!==void 0?u.metallicFactor:1,o.roughness=u.roughnessFactor!==void 0?u.roughnessFactor:1,u.metallicRoughnessTexture!==void 0&&(c.push(t.assignTexture(o,"metalnessMap",u.metallicRoughnessTexture)),c.push(t.assignTexture(o,"roughnessMap",u.metallicRoughnessTexture))),a=this._invokeOne(function(h){return h.getMaterialType&&h.getMaterialType(e)}),c.push(Promise.all(this._invokeAll(function(h){return h.extendMaterialParams&&h.extendMaterialParams(e,o)})))}s.doubleSided===!0&&(o.side=Et);const d=s.alphaMode||ml.OPAQUE;if(d===ml.BLEND?(o.transparent=!0,o.depthWrite=!1):(o.transparent=!1,d===ml.MASK&&(o.alphaTest=s.alphaCutoff!==void 0?s.alphaCutoff:.5)),s.normalTexture!==void 0&&a!==Ut&&(c.push(t.assignTexture(o,"normalMap",s.normalTexture)),o.normalScale=new Ce(1,1),s.normalTexture.scale!==void 0)){const u=s.normalTexture.scale;o.normalScale.set(u,u)}if(s.occlusionTexture!==void 0&&a!==Ut&&(c.push(t.assignTexture(o,"aoMap",s.occlusionTexture)),s.occlusionTexture.strength!==void 0&&(o.aoMapIntensity=s.occlusionTexture.strength)),s.emissiveFactor!==void 0&&a!==Ut){const u=s.emissiveFactor;o.emissive=new Ie().setRGB(u[0],u[1],u[2],en)}return s.emissiveTexture!==void 0&&a!==Ut&&c.push(t.assignTexture(o,"emissiveMap",s.emissiveTexture,_t)),Promise.all(c).then(function(){const u=new a(o);return s.name&&(u.name=s.name),Wn(u,s),t.associations.set(u,{materials:e}),s.extensions&&Xi(r,u,s),u})}createUniqueName(e){const t=lt.sanitizeNodeName(e||"");return t in this.nodeNamesUsed?t+"_"+ ++this.nodeNamesUsed[t]:(this.nodeNamesUsed[t]=0,t)}loadGeometries(e){const t=this,n=this.extensions,r=this.primitiveCache;function s(o){return n[Qe.KHR_DRACO_MESH_COMPRESSION].decodePrimitive(o,t).then(function(l){return Xd(l,o,t)})}const a=[];for(let o=0,l=e.length;o<l;o++){const c=e[o],d=Ab(c),u=r[d];if(u)a.push(u.promise);else{let h;c.extensions&&c.extensions[Qe.KHR_DRACO_MESH_COMPRESSION]?h=s(c):h=Xd(new Lt,c,t),r[d]={primitive:c,promise:h},a.push(h)}}return Promise.all(a)}loadMesh(e){const t=this,n=this.json,r=this.extensions,s=n.meshes[e],a=s.primitives,o=[];for(let l=0,c=a.length;l<c;l++){const d=a[l].material===void 0?Mb(this.cache):this.getDependency("material",a[l].material);o.push(d)}return o.push(t.loadGeometries(a)),Promise.all(o).then(function(l){const c=l.slice(0,l.length-1),d=l[l.length-1],u=[];for(let p=0,g=d.length;p<g;p++){const v=d[p],m=a[p];let f;const b=c[p];if(m.mode===An.TRIANGLES||m.mode===An.TRIANGLE_STRIP||m.mode===An.TRIANGLE_FAN||m.mode===void 0)f=s.isSkinnedMesh===!0?new Vc(v,b):new ht(v,b),f.isSkinnedMesh===!0&&f.normalizeSkinWeights(),m.mode===An.TRIANGLE_STRIP?f.geometry=zd(f.geometry,$h):m.mode===An.TRIANGLE_FAN&&(f.geometry=zd(f.geometry,dc));else if(m.mode===An.LINES)f=new uf(v,b);else if(m.mode===An.LINE_STRIP)f=new Wc(v,b);else if(m.mode===An.LINE_LOOP)f=new Km(v,b);else if(m.mode===An.POINTS)f=new Xc(v,b);else throw new Error("THREE.GLTFLoader: Primitive mode unsupported: "+m.mode);Object.keys(f.geometry.morphAttributes).length>0&&Tb(f,s),f.name=t.createUniqueName(s.name||"mesh_"+e),Wn(f,s),m.extensions&&Xi(r,f,m),t.assignFinalMaterial(f),u.push(f)}for(let p=0,g=u.length;p<g;p++)t.associations.set(u[p],{meshes:e,primitives:p});if(u.length===1)return s.extensions&&Xi(r,u[0],s),u[0];const h=new Rt;s.extensions&&Xi(r,h,s),t.associations.set(h,{meshes:e});for(let p=0,g=u.length;p<g;p++)h.add(u[p]);return h})}loadCamera(e){let t;const n=this.json.cameras[e],r=n[n.type];if(!r){console.warn("THREE.GLTFLoader: Missing camera parameters.");return}return n.type==="perspective"?t=new Kt(_e.radToDeg(r.yfov),r.aspectRatio||1,r.znear||1,r.zfar||2e6):n.type==="orthographic"&&(t=new Ws(-r.xmag,r.xmag,r.ymag,-r.ymag,r.znear,r.zfar)),n.name&&(t.name=this.createUniqueName(n.name)),Wn(t,n),Promise.resolve(t)}loadSkin(e){const t=this.json.skins[e],n=[];for(let r=0,s=t.joints.length;r<s;r++)n.push(this._loadNodeShallow(t.joints[r]));return t.inverseBindMatrices!==void 0?n.push(this.getDependency("accessor",t.inverseBindMatrices)):n.push(null),Promise.all(n).then(function(r){const s=r.pop(),a=r,o=[],l=[];for(let c=0,d=a.length;c<d;c++){const u=a[c];if(u){o.push(u);const h=new qe;s!==null&&h.fromArray(s.array,c*16),l.push(h)}else console.warn('THREE.GLTFLoader: Joint "%s" could not be found.',t.joints[c])}return new Hs(o,l)})}loadAnimation(e){const t=this.json,n=this,r=t.animations[e],s=r.name?r.name:"animation_"+e,a=[],o=[],l=[],c=[],d=[];for(let u=0,h=r.channels.length;u<h;u++){const p=r.channels[u],g=r.samplers[p.sampler],v=p.target,m=v.node,f=r.parameters!==void 0?r.parameters[g.input]:g.input,b=r.parameters!==void 0?r.parameters[g.output]:g.output;v.node!==void 0&&(a.push(this.getDependency("node",m)),o.push(this.getDependency("accessor",f)),l.push(this.getDependency("accessor",b)),c.push(g),d.push(v))}return Promise.all([Promise.all(a),Promise.all(o),Promise.all(l),Promise.all(c),Promise.all(d)]).then(function(u){const h=u[0],p=u[1],g=u[2],v=u[3],m=u[4],f=[];for(let _=0,x=h.length;_<x;_++){const R=h[_],M=p[_],A=g[_],w=v[_],S=m[_];if(R===void 0)continue;R.updateMatrix&&R.updateMatrix();const y=n._createAnimationTracks(R,M,A,w,S);if(y)for(let T=0;T<y.length;T++)f.push(y[T])}const b=new ag(s,void 0,f);return Wn(b,r),b})}createNodeMesh(e){const t=this.json,n=this,r=t.nodes[e];return r.mesh===void 0?null:n.getDependency("mesh",r.mesh).then(function(s){const a=n._getNodeRef(n.meshCache,r.mesh,s);return r.weights!==void 0&&a.traverse(function(o){if(o.isMesh)for(let l=0,c=r.weights.length;l<c;l++)o.morphTargetInfluences[l]=r.weights[l]}),a})}loadNode(e){const t=this.json,n=this,r=t.nodes[e],s=n._loadNodeShallow(e),a=[],o=r.children||[];for(let c=0,d=o.length;c<d;c++)a.push(n.getDependency("node",o[c]));const l=r.skin===void 0?Promise.resolve(null):n.getDependency("skin",r.skin);return Promise.all([s,Promise.all(a),l]).then(function(c){const d=c[0],u=c[1],h=c[2];h!==null&&d.traverse(function(p){p.isSkinnedMesh&&p.bind(h,Rb)});for(let p=0,g=u.length;p<g;p++)d.add(u[p]);return d})}_loadNodeShallow(e){const t=this.json,n=this.extensions,r=this;if(this.nodeCache[e]!==void 0)return this.nodeCache[e];const s=t.nodes[e],a=s.name?r.createUniqueName(s.name):"",o=[],l=r._invokeOne(function(c){return c.createNodeMesh&&c.createNodeMesh(e)});return l&&o.push(l),s.camera!==void 0&&o.push(r.getDependency("camera",s.camera).then(function(c){return r._getNodeRef(r.cameraCache,s.camera,c)})),r._invokeAll(function(c){return c.createNodeAttachment&&c.createNodeAttachment(e)}).forEach(function(c){o.push(c)}),this.nodeCache[e]=Promise.all(o).then(function(c){let d;if(s.isBone===!0?d=new co:c.length>1?d=new Rt:c.length===1?d=c[0]:d=new Mt,d!==c[0])for(let u=0,h=c.length;u<h;u++)d.add(c[u]);if(s.name&&(d.userData.name=s.name,d.name=a),Wn(d,s),s.extensions&&Xi(n,d,s),s.matrix!==void 0){const u=new qe;u.fromArray(s.matrix),d.applyMatrix4(u)}else s.translation!==void 0&&d.position.fromArray(s.translation),s.rotation!==void 0&&d.quaternion.fromArray(s.rotation),s.scale!==void 0&&d.scale.fromArray(s.scale);if(!r.associations.has(d))r.associations.set(d,{});else if(s.mesh!==void 0&&r.meshCache.refs[s.mesh]>1){const u=r.associations.get(d);r.associations.set(d,{...u})}return r.associations.get(d).nodes=e,d}),this.nodeCache[e]}loadScene(e){const t=this.extensions,n=this.json.scenes[e],r=this,s=new Rt;n.name&&(s.name=r.createUniqueName(n.name)),Wn(s,n),n.extensions&&Xi(t,s,n);const a=n.nodes||[],o=[];for(let l=0,c=a.length;l<c;l++)o.push(r.getDependency("node",a[l]));return Promise.all(o).then(function(l){for(let d=0,u=l.length;d<u;d++)s.add(l[d]);const c=d=>{const u=new Map;for(const[h,p]of r.associations)(h instanceof In||h instanceof Ft)&&u.set(h,p);return d.traverse(h=>{const p=r.associations.get(h);p!=null&&u.set(h,p)}),u};return r.associations=c(s),s})}_createAnimationTracks(e,t,n,r,s){const a=[],o=e.name?e.name:e.uuid,l=[];yi[s.path]===yi.weights?e.traverse(function(h){h.morphTargetInfluences&&l.push(h.name?h.name:h.uuid)}):l.push(o);let c;switch(yi[s.path]){case yi.weights:c=Wr;break;case yi.rotation:c=Xr;break;case yi.translation:case yi.scale:c=qr;break;default:switch(n.itemSize){case 1:c=Wr;break;case 2:case 3:default:c=qr;break}break}const d=r.interpolation!==void 0?Sb[r.interpolation]:Ds,u=this._getArrayFromAccessor(n);for(let h=0,p=l.length;h<p;h++){const g=new c(l[h]+"."+yi[s.path],t.array,u,d);r.interpolation==="CUBICSPLINE"&&this._createCubicSplineTrackInterpolant(g),a.push(g)}return a}_getArrayFromAccessor(e){let t=e.array;if(e.normalized){const n=vc(t.constructor),r=new Float32Array(t.length);for(let s=0,a=t.length;s<a;s++)r[s]=t[s]*n;t=r}return t}_createCubicSplineTrackInterpolant(e){e.createInterpolant=function(n){const r=this instanceof Xr?bb:Rf;return new r(this.times,this.values,this.getValueSize()/3,n)},e.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline=!0}}function Ib(i,e,t){const n=e.attributes,r=new jn;if(n.POSITION!==void 0){const o=t.json.accessors[n.POSITION],l=o.min,c=o.max;if(l!==void 0&&c!==void 0){if(r.set(new U(l[0],l[1],l[2]),new U(c[0],c[1],c[2])),o.normalized){const d=vc(Lr[o.componentType]);r.min.multiplyScalar(d),r.max.multiplyScalar(d)}}else{console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.");return}}else return;const s=e.targets;if(s!==void 0){const o=new U,l=new U;for(let c=0,d=s.length;c<d;c++){const u=s[c];if(u.POSITION!==void 0){const h=t.json.accessors[u.POSITION],p=h.min,g=h.max;if(p!==void 0&&g!==void 0){if(l.setX(Math.max(Math.abs(p[0]),Math.abs(g[0]))),l.setY(Math.max(Math.abs(p[1]),Math.abs(g[1]))),l.setZ(Math.max(Math.abs(p[2]),Math.abs(g[2]))),h.normalized){const v=vc(Lr[h.componentType]);l.multiplyScalar(v)}o.max(l)}else console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.")}}r.expandByVector(o)}i.boundingBox=r;const a=new $n;r.getCenter(a.center),a.radius=r.min.distanceTo(r.max)/2,i.boundingSphere=a}function Xd(i,e,t){const n=e.attributes,r=[];function s(a,o){return t.getDependency("accessor",a).then(function(l){i.setAttribute(o,l)})}for(const a in n){const o=gc[a]||a.toLowerCase();o in i.attributes||r.push(s(n[a],o))}if(e.indices!==void 0&&!i.index){const a=t.getDependency("accessor",e.indices).then(function(o){i.setIndex(o)});r.push(a)}return tt.workingColorSpace!==en&&"COLOR_0"in n&&console.warn(`THREE.GLTFLoader: Converting vertex colors from "srgb-linear" to "${tt.workingColorSpace}" not supported.`),Wn(i,e),Ib(i,e,t),Promise.all(r).then(function(){return e.targets!==void 0?Eb(i,e.targets,t):i})}const Pb="/models/wrad-arms.glb",Lb=["finger_index","finger_middle","finger_ring","finger_pinky","finger_thumb"],Db=new U(1,0,0),qd=new dt,Yd=new U;function Nb(i,{enabled:e=!0,reducedMotion:t=!1}={}){const n={mode:"rig",enabled:!!e,visible:!!e,motionEnabled:!t,loaded:!1,loadError:null,joints:0,fingerJoints:0,drawSurfaces:0,textureCount:0,triangles:0,leftX:0,rightX:0,swayX:0,swayY:0};if(!e)return{state:n,meshes:[],ready:Promise.resolve(!1),update(){},resize(){},beginTravel(){},dispose(){}};const r=new Rt;r.name="Órion · viewmodel rigado de primeira pessoa",i.add(r);const s=[],a=[],o=[],l=[],c={disposed:!1};let d=0,u=0,h=-.4,p=1,g=null,v=null;const m={depth:2.5,wristNdcX:.47,wristNdcY:-.84,pitch:Math.PI};function f(){if(!n.loaded||!v)return;const w=Math.tan(_e.degToRad(i.fov*.5)),S=w*i.aspect,{left:y,right:T}=v,N=Math.abs(T.x-y.x)*.5,B=(T.z+y.z)*.5,k=-B,V=m.wristNdcX*S*m.depth/(N+m.wristNdcX*S*k);p=_e.clamp(V,.06,.45);const D=m.depth-k*p,O=(T.y+y.y)*.5;r.scale.setScalar(p),r.rotation.set(m.pitch,0,0),r.position.set(-(y.x+T.x)*.5*p,m.wristNdcY*w*D+O*p,-2.5),h=r.position.y,n.leftX=-.47*S*D,n.rightX=m.wristNdcX*S*D,n.framing={...m,scale:p,baseY:h,wristDepth:D,halfSpan:N,localWristY:O,localWristZ:B},i.updateMatrixWorld(!0),r.updateMatrixWorld(!0);function F(z){if(!z)return null;const j=z.getWorldPosition(new U).project(i);return{x:j.x,y:j.y,z:j.z}}n.projectedWristLeft=F(g?.get("wristl")),n.projectedWristRight=F(g?.get("wristr")),n.projectedMiddleLeft=F(g?.get("finger_middle3l")),n.projectedMiddleRight=F(g?.get("finger_middle3r")),n.projectedShoulderLeft=F(g?.get("shoulderl")),n.projectedShoulderRight=F(g?.get("shoulderr"))}function b(w){if(c.disposed){w.scene.traverse(V=>{V.isMesh&&(V.geometry?.dispose?.(),V.material?.dispose?.())});return}const S=w.scene;S.updateMatrixWorld(!0);const y=new jn().setFromObject(S),T=new U,N=new U;if(y.getSize(T),y.getCenter(N),!Number.isFinite(T.x)||T.x<.001)throw new Error("Bounding box inválida no WRAD ARMS");n.modelBounds={width:T.x,centerX:N.x,top:y.max.y};const B=new Map;if(S.traverse(V=>{if(V.isBone&&B.set(V.name,V),!V.isMesh)return;const O=(Array.isArray(V.material)?V.material[0]:V.material)?.map||null;O&&!l.includes(O)&&l.push(O);const F=V.geometry,z=F.getAttribute("position"),j=new Float32Array(z.count*4);for(let L=0;L<z.count;L++){const $=_e.smoothstep(Math.abs(z.getX(L)),3.65,4.87);j[L*4]=1,j[L*4+1]=1,j[L*4+2]=1,j[L*4+3]=$}F.setAttribute("color",new nt(j,4));const te=new Ut({map:O,color:7830173,vertexColors:!0,transparent:!0,opacity:.86,depthTest:!1,depthWrite:!1,toneMapped:!1,side:Et});o.push(te),V.material=te,V.layers.set(0),V.renderOrder=30,V.frustumCulled=!1,s.push(V),n.triangles+=(F.index?.count||F.attributes.position?.count||0)/3}),!s.some(V=>V.isSkinnedMesh))throw new Error("WRAD ARMS veio sem malha SkinnedMesh");for(const[V,D]of B){if(!/^finger_(index|middle|ring|pinky|thumb)[123][._]?[lr]$/.test(V))continue;const O=/^finger_([a-z]+)([123])[._]?([lr])$/.exec(V),F=Number(O[2]),z=O[3];a.push({name:V,bone:D,base:D.quaternion.clone(),side:z==="l"?1:-1,segment:F,offset:Lb.indexOf("finger_"+O[1])*.73})}if(a.length<30)throw new Error("Rig incompleto: "+a.length+" falanges de "+B.size+" ossos");g=B,n.joints=B.size,n.fingerJoints=a.length,n.textureCount=l.length,n.drawSurfaces=s.length,S.name="WRAD ARMS CC0 · 50 ossos",r.add(S),r.updateMatrixWorld(!0);const k=V=>{const D=B.get(V);if(!D)throw new Error("Ausência de landmark do punho: "+V);return r.worldToLocal(D.getWorldPosition(new U))};v={left:k("wristl"),right:k("wristr")},n.loaded=!0,f(),r.visible=n.visible}const _=new Promise(w=>{new eu().load(Pb,S=>{try{b(S),w(!0)}catch(y){n.loadError=String(y.message||y),w(!1)}},void 0,S=>{n.loadError=String(S?.message||S),w(!1)})});function x(w,S,y=0,T=0){if(!n.loaded||!n.visible)return;const N=_e.clamp(y,-1,1),B=_e.clamp(T,-1,1),k=n.motionEnabled?1-Math.exp(-Math.min(Math.max(S,0),.06)*7.5):1;d+=(N-d)*k,u+=(B-u)*k,n.swayX=n.motionEnabled?d:0,n.swayY=n.motionEnabled?u:0;const V=Math.tan(_e.degToRad(i.fov*.5))*1.35,D=V*i.aspect,O=n.motionEnabled?Math.sin(w*.72)*.007:0;r.position.x=-(n.modelBounds?.centerX||0)*p-n.swayX*D*.023,r.position.y=h-n.swayY*V*.02+O*V,r.rotation.set(m.pitch+(n.motionEnabled?n.swayY*.012:0),0,n.motionEnabled?n.swayX*.015:0);const F=w*.91;for(const z of a){const te=(n.motionEnabled?.027*Math.sin(F+z.offset+(z.side>0?.4:1.1))+.012*n.swayY:0)*(z.segment===1?1:z.segment===2?.72:.48)*z.side;Yd.copy(Db),qd.setFromAxisAngle(Yd,te),z.bone.quaternion.copy(z.base).multiply(qd)}}function R(){f()}function M(){n.visible=!1,r.visible=!1}function A(){c.disposed=!0,i.remove(r);for(const w of s)w.geometry?.dispose?.();for(const w of o)w.dispose();for(const w of l)w.dispose();r.clear()}return{state:n,meshes:s,rigRoot:r,driven:a,ready:_,update:x,resize:R,beginTravel:M,dispose:A}}const Ob=["/models/wonderland-left.glb","/models/wonderland-right.glb"],Ub=["left","right"],Fb=/(index|middle|ring|pinky|thumb)[_-]finger[_-]phalanx[_-](proximal|intermediate|distal)/i,Bb={relaxed:{index:.44,middle:.53,ring:.61,pinky:.69,thumb:.26},open:{index:.37,middle:.47,ring:.56,pinky:.63,thumb:.22}},kb=new URLSearchParams(location.search).get("handPose"),qs=kb==="open"?"open":"relaxed",zb=Bb[qs],jd=qs==="relaxed"?2.11:Math.PI-.36,$d=qs==="relaxed"?.3:.42,Kd=qs==="relaxed"?.22:.29,Vb=new U(1,0,0),Zd=new dt;function Hb(i,{enabled:e=!0,reducedMotion:t=!1}={}){const n={mode:"vr",enabled:!!e,visible:!!e,loaded:!1,loadError:null,motionEnabled:!t,drawSurfaces:0,textureCount:0,joints:0,fingerJoints:0,triangles:0,swayX:0,swayY:0,leftX:0,rightX:0,pose:qs};if(!e)return{state:n,meshes:[],ready:Promise.resolve(!1),update(){},resize(){},beginTravel(){},dispose(){}};const r=new Rt;r.name="Órion · mãos anatômicas (viewmodel independente)",i.add(r);const s=Ub.map(A=>{const w=new Rt;return w.name="Órion · "+A,r.add(w),w}),a=[],o=[],l=[],c=[],d=[];let u=!1,h=0,p=0,g=0;function v(A){return new Promise((w,S)=>{new eu().load(A,w,void 0,S)})}function m(A,w){const S=A.scene,y=s[w];S.traverse(T=>{if(T.isBone){o.push(T);const O=T.name.match(Fb);O&&O[2]!=="metacarpal"&&l.push({bone:T,base:T.quaternion.clone(),side:w===0?-1:1,finger:O[1],segment:O[2]==="proximal"?1:O[2]==="intermediate"?2:3,phase:["index","middle","ring","pinky","thumb"].indexOf(O[1])*.64})}if(!T.isMesh)return;const N=T.geometry.clone(),B=N.getAttribute("position"),k=N.getAttribute("normal"),V=new Float32Array(B.count*4);for(let O=0;O<B.count;O++){const F=_e.clamp(.38+.37*k.getZ(O)+.23*k.getY(O),.24,.95),z=B.getY(O),j=1-_e.smoothstep(z,-.045,.018)*.75,te=1-_e.smoothstep(z,-.17,-.04);V[O*4]=F*(.74+.13*te),V[O*4+1]=F*(.65+.07*te),V[O*4+2]=F*(.95+.04*te),V[O*4+3]=j}N.setAttribute("color",new nt(V,4)),d.push(N);const D=new Ut({color:11708107,vertexColors:!0,transparent:!0,opacity:.97,depthTest:!1,depthWrite:!1,toneMapped:!1,side:Et});c.push(D),T.geometry=N,T.material=D,T.layers.set(0),T.renderOrder=30,T.frustumCulled=!1,a.push(T),n.triangles+=(N.index?.count||N.attributes.position.count)/3}),y.add(S)}function f(A){const w=Math.tan(_e.degToRad(i.fov*.5))*Math.abs(A);return{h:w,w:w*i.aspect}}function b(){if(!n.loaded)return;const A=1.38,{h:w,w:S}=f(A),y=w*.45/.1774;for(let T=0;T<2;T++){const N=s[T],B=T===0?-1:1;N.scale.setScalar(y),N.rotation.set(jd,B*-$d,B*Kd),N.position.set(B*S*.54,-w*.94,-A)}n.leftX=s[0].position.x,n.rightX=s[1].position.x}const _=Promise.all(Ob.map(v)).then(A=>{if(u)return!1;if(A.forEach(m),a.length!==2||o.length<50||l.length<24)throw new Error("GLB anatômico não contém malhas/juntas suficientes");return n.drawSurfaces=a.length,n.joints=o.length,n.fingerJoints=l.length,n.loaded=!0,b(),r.visible=n.visible,!0}).catch(A=>(n.loadError=String(A?.message||A),n.loaded=!1,!1));function x(A,w,S=0,y=0){if(!n.loaded||!n.visible)return;const T=n.motionEnabled?1-Math.exp(-Math.min(.06,Math.max(0,w))*7.5):1;p+=(_e.clamp(S,-1,1)-p)*T,g+=(_e.clamp(y,-1,1)-g)*T,n.swayX=n.motionEnabled?p:0,n.swayY=n.motionEnabled?g:0;const{h:N,w:B}=f(1.38),k=n.motionEnabled?Math.sin(A*.72)*N*.005:0;for(let V=0;V<2;V++){const D=s[V],O=V===0?-1:1;D.position.x=O*B*.54-n.swayX*B*.016,D.position.y=-N*.94-n.swayY*N*.018+k*(V===0?.9:1),D.rotation.set(jd+(n.motionEnabled?n.swayY*.009:0),O*-$d,O*Kd+(n.motionEnabled?n.swayX*.014:0))}if(A-h>=0)for(const V of l){const D=n.motionEnabled?.018*Math.sin(A*.7+V.phase+V.side*.3):0,O=(zb[V.finger]+D)*(V.segment===1?1:V.segment===2?.78:.48);Zd.setFromAxisAngle(Vb,O),V.bone.quaternion.copy(V.base).multiply(Zd)}h=A}function R(){n.visible=!1,r.visible=!1}function M(){u=!0,i.remove(r),d.forEach(A=>A.dispose()),c.forEach(A=>A.dispose()),r.clear()}return{state:n,meshes:a,bones:o,driven:l,groups:s,root:r,ready:_,update:x,resize:b,beginTravel:R,dispose:M}}const Gb="/models/david-fischer-fps-hands.glb",Wb=/^(?:f_)?(index|middle|ring|pinky)(?:\.|_)?0?([123])(?:\.|_)?([lr])/i,Xb=/^thumb(?:\.|_)?0?([123])(?:\.|_)?([lr])/i,qb=new U,Jd=new dt,Yb=new U(1,0,0),jb=new U(0,0,1),Qd=new dt,Fs=new URLSearchParams(window.location.search),$b=Fs.get("fpsPose")==="open"?"open":"relaxed",Ia=Fs.get("fpsLight")==="basic"?"basic":"lit",Vt=["original","calm","cinematic","natural","frame"].includes(Fs.get("fpsStyle"))?Fs.get("fpsStyle"):"frame",Ti={original:{wristY:-.84,fadeFrom:.615,fadeTo:.725,wristBend:0,wristRoll:0,opacity:.94,fadeInvert:!1},calm:{wristY:-.88,fadeFrom:.735,fadeTo:.865,wristBend:-.43,wristRoll:-.16,opacity:.96,fadeInvert:!0},cinematic:{wristY:-.84,fadeFrom:.73,fadeTo:.87,wristBend:-.55,wristRoll:-.35,opacity:.98,fadeInvert:!0},natural:{wristY:-.85,fadeFrom:.72,fadeTo:.88,wristBend:0,wristRoll:0,opacity:.96,fadeInvert:!0},frame:{wristY:-.89,fadeFrom:.7,fadeTo:.89,wristBend:0,wristRoll:0,opacity:1,fadeInvert:!0,scaleFactor:1.74}}[Vt],_c=Fs.get("fpsTune")||"base",eh={base:Vt==="frame"?{bend:.36,yaw:.46,roll:-.4}:Vt==="natural"?{bend:1,yaw:.36,roll:-.38}:{bend:Ti.wristBend,yaw:0,roll:Ti.wristRoll},forward:{bend:-1.12,yaw:.26,roll:-.25},reach:{bend:-1.47,yaw:.4,roll:-.18},inward:{bend:-1.04,yaw:.62,roll:-.48},back:{bend:.7,yaw:.3,roll:-.3},rest1:{bend:1,yaw:.36,roll:-.38},rest2:{bend:1.24,yaw:.38,roll:-.4},rest3:{bend:.86,yaw:.48,roll:-.48},frameA:{bend:.76,yaw:.47,roll:-.43},frameB:{bend:.6,yaw:.56,roll:-.5},frameC:{bend:.94,yaw:.39,roll:-.35},frameD:{bend:.36,yaw:.46,roll:-.4}},vl=eh[_c]||eh.base,Kb=new U(1,0,0),Zb=new U(0,1,0),Jb=new U(0,0,1),th=new dt,nh=new dt,ih=new dt;function Qb(i){return String(i||"").toLowerCase().replace(/[^a-z0-9]/g,"")}function rh(i,e){const t=Math.tan(_e.degToRad(i.fov*.5))*e;return{h:t,w:t*i.aspect}}function eS(i,{enabled:e=!0,reducedMotion:t=!1}={}){const n={mode:"fps",enabled:!!e,visible:!!e,loaded:!1,motionEnabled:!t,loadError:null,pose:$b,joints:0,fingerJoints:0,triangles:0,textureCount:0,drawSurfaces:0,swayX:0,swayY:0,leftX:0,rightX:0,framing:null,artStyle:Vt,lightMode:Ia,tune:_c,referencePose:Vt==="frame"?"arcane-frame":null};if(!e)return{state:n,meshes:[],driven:[],ready:Promise.resolve(!1),update(){},resize(){},beginTravel(){},dispose(){}};const r=new Rt;r.name="Órion · mãos FPS de David Fischer, viewmodel local",i.add(r);const s=[];if(Ia==="lit"){const D=new fg(15524607,6772868,1.85),O=new vf(16774399,1.22);O.position.set(-.7,1.6,2.3),O.target.position.set(0,0,-2),i.add(D,O,O.target),s.push(D,O,O.target)}const a=[],o=[],l=[],c=[],d=[],u={wristL:null,wristR:null,tipL:null,tipR:null},h=[];let p=!1,g=new U,v=1,m=0;const f={left:0,right:0},b={left:0,right:0};let _=0,x=0;const R=2.05,M={open:.07,relaxed:.17},A={index:[.055,.045,.025],middle:[.22,.32,.24],ring:[.33,.43,.31],pinky:[.42,.48,.37],thumb:[.035,.045,.015]};function w(D=0){th.setFromAxisAngle(Kb,vl.bend);for(const O of h)nh.setFromAxisAngle(Zb,vl.yaw*O.side),ih.setFromAxisAngle(Jb,vl.roll*O.side),O.bone.quaternion.copy(O.aimed||O.base),O.aimed||O.bone.quaternion.multiply(th).multiply(nh).multiply(ih);for(let O=0;O<c.length;O++){const F=c[O],z=n.motionEnabled?Math.sin(D*.7+O*.79)*.012:0,j=Vt==="frame"?A[F.digit][F.segment-1]+z*.35:(M[n.pose]+z)*(F.segment===1?.52:F.segment===2?.71:.36)*(F.digit==="thumb"?.45:1);Jd.setFromAxisAngle(Yb,j),F.bone.quaternion.copy(F.base).multiply(Jd),Vt==="frame"&&F.digit==="thumb"&&F.segment===1&&(Qd.setFromAxisAngle(jb,.12*F.side),F.bone.quaternion.multiply(Qd))}}function S(){if(Vt!=="natural"||_c!=="base")return;i.updateMatrixWorld(!0),r.updateMatrixWorld(!0);const D=G=>G.getWorldPosition(new U).project(i),O=D(u.wristL),F=D(u.wristR),z=D(u.tipL),j=D(u.tipR);if(z.x-O.x>.09&&z.x-O.x<.23&&F.x-j.x>.09&&F.x-j.x<.23&&z.y-O.y>.25&&z.y-O.y<.42&&j.y-F.y>.25&&j.y-F.y<.42)return;const te=i.getWorldQuaternion(new dt),L=new U(0,0,1).applyQuaternion(te),$=new U(1,0,0).applyQuaternion(te),Z=[0,-.34,.34,-.5,.5,-.65,.65,-.8,.8],ae=[0,-.14,.14,-.26,.26,-.38,.38,-.46,.46];for(const G of h){const X=G.side===-1?u.tipL:u.tipR;if(!X)continue;const re=G.bone.parent.getWorldQuaternion(new dt).invert(),ye=L.clone().applyQuaternion(re).normalize(),fe=$.clone().applyQuaternion(re).normalize(),we=G.bone.quaternion.clone(),me=G.side===-1?.115:-.115,P=G.side===-1?.26:.245;let Le={score:1/0,pitch:0,roll:0,quaternion:we.clone()};for(const ge of Z){const se=new dt().setFromAxisAngle(fe,ge);for(const ze of ae){const oe=new dt().setFromAxisAngle(ye,ze);G.bone.quaternion.copy(we).premultiply(se).premultiply(oe),r.updateMatrixWorld(!0);const Se=G.bone.getWorldPosition(new U),Ye=X.getWorldPosition(new U),De=Se.clone().project(i),I=Ye.clone().project(i),E=i.worldToLocal(Ye).z-i.worldToLocal(Se).z,Y=I.x-De.x,ee=I.y-De.y,ne=Math.abs(Y-me)*1.4+Math.abs(ee-P)*.8+Math.abs(E+.38)*.32+Math.abs(ge)*.022+Math.abs(ze)*.027+(ee<.13?.8:0)+(ee>.39?.15:0)+(I.x*G.side<0?.35:0);ne<Le.score&&(Le={score:ne,pitch:ge,roll:ze,quaternion:G.bone.quaternion.clone()})}}G.aimed=Le.quaternion,G.bone.quaternion.copy(Le.quaternion);const Te=G.side===-1?"left":"right";f[Te]=Le.roll,b[Te]=Le.pitch,r.updateMatrixWorld(!0)}}function y(){if(!n.loaded||!u.wristL||!u.wristR)return;for(const X of h)X.aimed=null;w(0),r.position.set(0,0,0),r.scale.setScalar(1),r.rotation.set(0,0,0),r.updateMatrixWorld(!0);const D=X=>r.worldToLocal(X.getWorldPosition(new U)),O=D(u.wristL),F=D(u.wristR),z=u.tipL?D(u.tipL):O.clone().add(new U(0,.1,0)),j=u.tipR?D(u.tipR):F.clone().add(new U(0,.1,0));O.clone().add(F).multiplyScalar(.5);const te=[-.35,.18,.45,Math.PI-.35,Math.PI+.18,Math.PI+.45];let L=null;const{h:$,w:Z}=rh(i,R);for(const X of te){const re=new xn(X,0,0),ye=O.clone().applyEuler(re),fe=F.clone().applyEuler(re),we=z.clone().applyEuler(re),me=j.clone().applyEuler(re),P=Math.abs(fe.x-ye.x);if(P<.005)continue;const Le=_e.clamp(Z*.54/(P*.5),.003,6.5),Te=(we.y-ye.y+(me.y-fe.y))*.5*Le/$,ge=Math.abs(Te-.32)+(Te<=.05?3:0)+(Te>.72?2:0)+Math.abs(we.y-ye.y-(me.y-fe.y))*Le/$*.25;(!L||ge<L.score)&&(L={pitch:X,score:ge,s:Le,l:ye,r:fe,tl:we,tr:me,rise:Te})}if(!L)throw new Error("Não foi possível calibrar o rig FPS por punhos");m=L.pitch,v=L.s*(Ti.scaleFactor||1);const ae=L.l.clone().add(L.r).multiplyScalar(.5);r.rotation.set(m,0,0),r.scale.set(-v,v,v),g.set(ae.x*v,$*Ti.wristY-ae.y*v,-R-ae.z*v),r.position.copy(g),r.updateMatrixWorld(!0),i.updateMatrixWorld(!0),S(),r.updateMatrixWorld(!0);const G=X=>{if(!X)return null;const re=X.getWorldPosition(qb.clone()).project(i);return{x:re.x,y:re.y,z:re.z}};n.framing={pitch:m,scale:v,rawRise:L.rise,aimAngles:{...f},depthAngles:{...b},posedLandmarks:!0,wristLeft:G(u.wristL),wristRight:G(u.wristR),tipLeft:G(u.tipL),tipRight:G(u.tipR)},n.leftX=n.framing.wristLeft?.x||0,n.rightX=n.framing.wristRight?.x||0}const T=new Promise(D=>{new eu().load(Gb,O=>{try{if(p){D(!1);return}const F=O.scene;if(F.updateMatrixWorld(!0),F.traverse(z=>{if(z.isBone&&d.push(z),!z.isSkinnedMesh)return;const j=z.geometry;if(j.getAttribute("position")?.count<1e3){z.visible=!1;return}const te=j.clone(),L=te.getAttribute("normal"),$=te.getAttribute("position"),Z=new Float32Array($.count*4);for(let X=0;X<$.count;X++){const re=$.getY(X),ye=L?.getZ(X)??0,fe=L?.getY(X)??0,we=Vt==="frame"?_e.clamp(.51+.13*ye+.1*fe,.34,.8):_e.clamp(.66+.2*ye+.12*fe,.45,.95),me=_e.smoothstep(re,Ti.fadeFrom,Ti.fadeTo),P=Ti.fadeInvert?1-me:me;Z[X*4]=we*(Vt==="frame"?.69:.94),Z[X*4+1]=we*(Vt==="frame"?.72:.84),Z[X*4+2]=we*(Vt==="frame"?.97:1.05),Z[X*4+3]=P}te.setAttribute("color",new nt(Z,4)),l.push(te);const ae=Ia==="lit"?Zm:Ut,G=new ae({color:Vt==="frame"?8418710:Ia==="lit"?13681889:12235468,vertexColors:!0,transparent:!0,opacity:Ti.opacity,side:Et,depthTest:!1,depthWrite:!1,toneMapped:!1});G.onBeforeCompile=X=>{X.vertexShader=`varying float vOrionFpsClipY;
`+(Vt==="frame"?`varying float vOrionFpsRim;
`:"")+X.vertexShader,X.vertexShader=X.vertexShader.replace("#include <project_vertex>",`#include <project_vertex>
vOrionFpsClipY = gl_Position.y / gl_Position.w;`+(Vt==="frame"?`
vOrionFpsRim = 1.0 - abs(dot(normalize(transformedNormal), normalize(-mvPosition.xyz)));`:"")),X.fragmentShader=`varying float vOrionFpsClipY;
`+(Vt==="frame"?`varying float vOrionFpsRim;
`:"")+X.fragmentShader,X.fragmentShader=X.fragmentShader.replace("#include <opaque_fragment>",`#include <opaque_fragment>
gl_FragColor.a *= smoothstep(-1.08, -0.74, vOrionFpsClipY);`+(Vt==="frame"?`
float orionRim = pow(clamp(vOrionFpsRim, 0.0, 1.0), 1.25);
gl_FragColor.rgb = gl_FragColor.rgb * 0.13 + vec3(0.82,0.83,1.0) * orionRim * 1.23;`:""))},G.customProgramCacheKey=()=>Vt==="frame"?"orion-fps-arcane-frame-v3":"orion-fps-screen-feather-v1",o.push(G),z.geometry=te,z.material=G,z.frustumCulled=!1,z.renderOrder=35,z.layers.set(0),a.push(z),n.triangles+=(te.index?.count||$.count)/3}),a.length===0)throw new Error("Modelo de David sem SkinnedMesh principal");for(const z of d){const j=Qb(z.name);/^handl/.test(j)&&(u.wristL=z),/^handr/.test(j)&&(u.wristR=z),/^fmiddle03l/.test(j)&&(u.tipL=z),/^fmiddle03r/.test(j)&&(u.tipR=z);const te=String(z.name||""),L=te.match(Wb),$=te.match(Xb);!L&&!$||c.push({bone:z,base:z.quaternion.clone(),digit:$?"thumb":L[1].toLowerCase(),segment:Number($?$[1]:L[2]),side:($?$[2]:L[3]).toLowerCase()==="l"?1:-1})}if(!u.wristL||!u.wristR)throw new Error("Mãos importadas sem ossos dos punhos");if(h.push({bone:u.wristL,side:-1,base:u.wristL.quaternion.clone()}),h.push({bone:u.wristR,side:1,base:u.wristR.quaternion.clone()}),c.length<25)throw new Error("Rig importado não fornece falanges suficientes: "+c.length);r.add(F),n.joints=d.length,n.fingerJoints=c.length,n.drawSurfaces=a.length,n.textureCount=0,n.loaded=!0,y(),r.visible=n.visible,D(!0)}catch(F){n.loaded=!1,n.loadError=String(F.message||F),D(!1)}},void 0,O=>{n.loadError=String(O?.message||O),D(!1)})});function N(D,O,F=0,z=0){if(!n.loaded||!n.visible)return;const j=n.motionEnabled?1-Math.exp(-Math.min(Math.max(O,0),.06)*7.5):1;_+=(_e.clamp(F,-1,1)-_)*j,x+=(_e.clamp(z,-1,1)-x)*j,n.swayX=n.motionEnabled?_:0,n.swayY=n.motionEnabled?x:0;const{h:te,w:L}=rh(i,R),$=n.motionEnabled?Math.sin(D*.67)*te*.005:0;r.position.set(g.x-n.swayX*L*.018,g.y-n.swayY*te*.016+$,g.z),r.rotation.set(m+(n.motionEnabled?n.swayY*.008:0),0,n.motionEnabled?n.swayX*.012:0),w(D)}function B(){y()}function k(){n.visible=!1,r.visible=!1}function V(){p=!0,i.remove(r),s.forEach(D=>i.remove(D)),l.forEach(D=>D.dispose()),o.forEach(D=>D.dispose()),r.clear()}return{state:n,root:r,meshes:a,driven:c,ready:T,update:N,resize:B,beginTravel:k,dispose:V}}const sh="/overlay/orion-hands-frame.webp";function tS(i,{enabled:e=!0,reducedMotion:t=!1}={}){const n={enabled:!!e,visible:!!e,loaded:!1,mode:"overlay",motionEnabled:!t,loadError:null,drawSurfaces:0,triangles:0,textureCount:0,joints:0,fingerJoints:0,swayX:0,swayY:0,elementCount:0};if(!e)return{state:n,meshes:[],ready:Promise.resolve(!1),update(){},resize(){},beginTravel(){},dispose(){}};const r=document.createElement("div");r.id="orionEtherealHands",r.className="orion-ethereal-hands",r.setAttribute("aria-hidden","true");const s=[];for(const v of["left","right"]){const m=document.createElement("div");m.className="orion-ethereal-hand orion-ethereal-hand--"+v,m.dataset.side=v;const f=document.createElement("img");f.src=sh,f.alt="",f.decoding="async",f.loading="eager",f.draggable=!1,m.appendChild(f),r.appendChild(m),s.push(m)}i.appendChild(r),n.elementCount=2;let a=!1,o=0,l=0;const c=new Image;c.decoding="async";const d=new Promise(v=>{c.onload=()=>{if(a)return v(!1);n.loaded=!0,n.textureCount=1,r.classList.add("is-ready"),v(!0)},c.onerror=()=>{if(a)return v(!1);n.loadError="Falha ao carregar mãos etéreas locais",r.remove(),v(!1)},c.src=sh,c.complete&&c.naturalWidth>0&&c.onload()});function u(v,m,f=0,b=0){if(a||!n.visible||!n.loaded)return;const _=Math.min(Math.max(m,0),.06),x=n.motionEnabled?1-Math.exp(-_*6.2):1;o+=(Math.max(-1,Math.min(1,f))-o)*x,l+=(Math.max(-1,Math.min(1,b))-l)*x,n.swayX=n.motionEnabled?o:0,n.swayY=n.motionEnabled?l:0;const R=n.motionEnabled?Math.sin(v*.92)*2:0;for(let M=0;M<s.length;M++){const A=M===0?1:-1,w=n.swayX*(M===0?-5.5:-5.2)+A*.6*Math.sin(v*.37),S=n.swayY*-3.8+(M===0?R:R*.85),y=n.motionEnabled?n.swayX*(M===0?-.23:.23):0,T=n.motionEnabled?w:0,N=n.motionEnabled?S:0;s[M].style.transform="translate3d("+T.toFixed(2)+"px,"+N.toFixed(2)+"px,0) rotate("+y.toFixed(3)+"deg)"}}function h(){n.visible&&(n.visible=!1,r.classList.add("is-leaving"))}function p(){}function g(){a=!0,n.visible=!1,c.onload=null,c.onerror=null,r.remove()}return{state:n,meshes:[],ready:d,update:u,resize:p,beginTravel:h,dispose:g,layer:r}}function nS(){const i=new Ce(1,1);function e(t){return t.onBeforeCompile=n=>{n.uniforms.uHandViewport={value:i},n.fragmentShader=`uniform vec2 uHandViewport;
`+n.fragmentShader,n.fragmentShader=n.fragmentShader.replace("#include <alphatest_fragment>",`vec2 handScreen=gl_FragCoord.xy/max(uHandViewport,vec2(1.));
    float handEdge=min(min(handScreen.x,1.-handScreen.x),min(handScreen.y,1.-handScreen.y));
    float handPresence=1.-smoothstep(.02,.32,handEdge);
    diffuseColor.a*=mix(1.,2.5,handPresence);
    #include <alphatest_fragment>`)},t.customProgramCacheKey=()=>"orion-hand-edge-v24",t.userData.edgeOpacity=!0,t}return{material:e,bind(t){t.onBeforeRender=n=>n.getDrawingBufferSize(i)}}}const iS=32,rS=24,xc=Object.freeze({left:Object.freeze({id:"left-framing",limit:.009,index:{x:.58,y:.73,px:.48,py:.48,rx:.25,ry:.31},thumb:{x:.72,y:.44,px:.55,py:.37,rx:.24,ry:.2},indexAmplitude:.027,thumbAmplitude:.018,phase:.38}),right:Object.freeze({id:"right-pointing",limit:.012,index:{x:.27,y:.79,px:.43,py:.63,rx:.25,ry:.24},thumb:{x:.28,y:.52,px:.45,py:.43,rx:.22,ry:.18},indexAmplitude:.046,thumbAmplitude:.026,phase:1.16})}),Pa=(i,e,t)=>Math.max(e,Math.min(t,i));function ah(i,e,t){const n=(i-t.x)/t.rx,r=(e-t.y)/t.ry;return Math.exp(-2.3*(n*n+r*r))}function oh(i,e,t,n){const r=i-t.px,s=e-t.py,a=Math.sin(n),o=Math.cos(n);return[r*o-s*a-r,r*a+s*o-s]}function sS(i,e,t,n,r,s=0,a=0,o=!1){if(!xc[n])throw new Error("Lado da mão não reconhecido");if(i.length!==e.length||i.length/3*2!==t.length)throw new Error("Geometria de mãos incompatível");if(o)return e.set(i),0;const l=xc[n],c=Pa(s,-1,1),d=Pa(a,-1,1),u=l.indexAmplitude*Math.sin(r*.83+l.phase)+c*.012,h=l.thumbAmplitude*Math.sin(r*.65+l.phase+1.4)-d*.008;let p=0;for(let g=0,v=i.length/3;g<v;g++){const m=g*3,f=g*2,b=t[f],_=t[f+1],x=ah(b,_,l.index),R=ah(b,_,l.thumb),[M,A]=oh(b,_,l.index,u),[w,S]=oh(b,_,l.thumb,h),y=Pa(M*x+w*R,-l.limit,l.limit),T=Pa(A*x+S*R,-l.limit,l.limit);e[m]=i[m]+y,e[m+1]=i[m+1]+T,e[m+2]=i[m+2],p=Math.max(p,Math.abs(y),Math.abs(T))}return p}const Cf=.14,aS=.6,If=.5,an=[100,150,180,220,270,320,370,420,480,530],oS=[[500,519],[465,534],[450,522],[425,504],[401,485],[390,475],[416,510],[439,550],[477,590],[501,620]],lS=[[335,354],[333,402],[344,416],[358,437],[379,463],[399,484],[416,510],[439,550],[477,590],[501,620]],Pf=[0,.25,.5,.75,1].map(i=>oS.map((e,t)=>e.map((n,r)=>n+(lS[t][r]-n)*i)));function cS(i){const e=i.slice(1).map((t,n)=>(t-i[n])/(an[n+1]-an[n]));return i.map((t,n)=>{if(n===0||n===i.length-1||e[n-1]*e[n]<=0)return 0;const r=an[n]-an[n-1],s=an[n+1]-an[n],a=2*s+r,o=s+2*r;return(a+o)/(a/e[n-1]+o/e[n])})}const yc=Pf.map(i=>[0,1].map(e=>cS(i.map(t=>t[e]))));for(const i of yc)for(let e=0;e<2;e++)i[e][an.indexOf(370)]=yc[4][e][an.indexOf(370)];function lh(i,e){let t=0;for(;t<an.length-2&&e>an[t+1]/1122;)t++;const n=an[t+1]-an[t],r=Math.max(0,Math.min(1,(e*1122-an[t])/n)),s=r*r,a=s*r,o=Pf[i],l=yc[i],c=[0,1].map(d=>(2*a-3*s+1)*o[t][d]+(a-2*s+r)*n*l[d][t]+(-2*a+3*s)*o[t+1][d]+(a-s)*n*l[d][t+1]);return[1-c[1]/1402,1-c[0]/1402]}function uS(i,e,t,n){if(t>an.at(-1)/1122||n<=.54||i===e)return n;const[r,s]=lh(i,t),[a,o]=lh(e,t),l=Math.max(.54,Math.min(r,a)-Math.max(.005,Math.abs(a-r)*.65));return n<=l?n:n<r?l+(a-l)*(n-l)/(r-l):n<s?a+(o-a)*(n-r)/(s-r):n+o-s}function Lf(i){const e=Math.max(0,Math.min(1,i)),t=e*4,n=Math.min(3,Math.floor(t)),r=t-n,s=r*r*(3-2*r),a=[0,0,0,0,0];return a[n]=1-s,a[n+1]=s,a}const Dr={left:{wrist:[.23,.17],palm:[.47,.44],index:[.49,.62],indexDistal:[.63,.74],indexTip:[.75,.8],thumb:[.54,.36],thumbDistal:[.73,.37],thumbTip:[.9,.38],middle:[.52,.6],middleTip:[.76,.61],ring:[.5,.54],ringTip:[.7,.49],little:[.47,.49],littleTip:[.64,.44],phase:.4},pointing:{wrist:[.8,.2],palm:[.59,.44],index:[.45,.63],indexDistal:[.32,.74],indexTip:[.17,.8],thumb:[.49,.39],thumbDistal:[.35,.43],thumbTip:[.23,.45],middle:[.48,.59],middleTip:[.24,.5],ring:[.52,.55],ringTip:[.34,.47],little:[.57,.52],littleTip:[.43,.47],phase:1.2},neutral:{wrist:[.8,.2],palm:[.59,.44],index:[.45,.63],indexDistal:[.29,.71],indexTip:[.15,.65],thumb:[.49,.39],thumbDistal:[.35,.43],thumbTip:[.23,.45],middle:[.48,.59],middleTip:[.2,.5],ring:[.52,.55],ringTip:[.29,.46],little:[.57,.52],littleTip:[.38,.46],phase:1.2}};Dr.perspective={...Dr.neutral,indexDistal:[.28,.72],indexTip:[.1,.75]};const ys=[["wrist",null,.014,.7],["palm","wrist",.009,.81],["index","palm",.03,1.03],["indexDistal","index",.039,1.12],["thumb","palm",.024,.85],["thumbDistal","thumb",.03,.93],["middle","palm",.021,.96],["ring","palm",.018,.89],["little","palm",.015,.83]],_l=["wrist","palm","indexTip","thumbTip","middleTip","ringTip","littleTip"];for(const[i,e]of[["reach025",.25],["reach050",.5],["reach075",.75]])Dr[i]=Object.fromEntries(Object.entries(Dr.neutral).map(([t,n])=>[t,Array.isArray(n)?n.map((r,s)=>_e.lerp(r,Dr.pointing[t][s],e)):n]));const La=[[150,503,490,314,291],[180,522,461,359,279],[220,518,427,391,300],[270,489,402,420,330],[320,478,389,446,358],[370,495,380,486,381],[420,525,401,525,404],[480,550,455,550,458],[530,565,493,565,496]].map(([i,e,t,n,r])=>[i/1122,1-e/1402,1-t/1402,1-n/1402,1-r/1402]);function dS(i,e,t){if(i>La.at(-1)[0])return e;let n=La[0],r=n;for(let h=1;h<La.length&&(r=La[h],!(i<=r[0]));h++)n=r;const s=n===r?0:_e.clamp((i-n[0])/(r[0]-n[0]),0,1),a=n.map((h,p)=>_e.lerp(h,r[p],s)),o=a[t?3:1],l=a[t?4:2],c=a[t?1:3],d=a[t?2:4],u=.54;return e<=u?e:e<o?_e.lerp(u,c,(e-u)/(o-u)):e<l?_e.lerp(c,d,(e-o)/(l-o)):e+d-l}function ch(i,e,t,n,r){const s=n[0]-t[0],a=n[1]-t[1],o=s*s+a*a,l=_e.clamp(((i-t[0])*s+(e-t[1])*a)/o,0,1),c=((i-t[0]-l*s)**2+(e-t[1]-l*a)**2)/(r*r);return Math.exp(-2.5*c)}function uh(i,e,t,{perspective:n=!1}={}){const r=Dr[t];if(!r)throw new Error("Pose de rig de mãos desconhecida");const s=[],a={};for(const[m,f]of ys){const b=new co,_=r[m];b.name="MMV_"+t+"_"+m;const x=f?r[f]:[.5,.5];b.position.set(_[0]-x[0],_[1]-x[1],0),f&&a[f].add(b),s.push(b),a[m]=b}const o=i.getAttribute("uv"),l=new Uint16Array(o.count*4),c=new Float32Array(o.count*4),d=Object.fromEntries(_l.map(m=>[m,{index:0,distance:1/0}]));for(let m=0;m<o.count;m++){const f=o.getX(m),b=o.getY(m),_=1-_e.smoothstep(b,.18,.46),x=[{index:0,weight:.04+_*4},{index:1,weight:.15+ch(f,b,r.wrist,r.palm,.24)}];for(let M=2;M<ys.length;M++){const[A]=ys[M],w=r[A+"Tip"]||r.indexTip,S=r[A],y=A.endsWith("Distal")?r[A.replace("Distal","")+"Tip"]:r[A+"Distal"]||w,T=A.startsWith("index")?.14:A.startsWith("thumb")?.08:.065;x.push({index:M,weight:ch(f,b,S,y,T)*(1-_)*3})}x.sort((M,A)=>A.weight-M.weight);const R=x.slice(0,4).reduce((M,A)=>M+A.weight,0);for(let M=0;M<4;M++)l[m*4+M]=x[M].index,c[m*4+M]=x[M].weight/R;for(const M of _l){const A=r[M],w=(f-A[0])**2+(b-A[1])**2;w<d[M].distance&&(d[M]={index:m,distance:w})}}if(t!=="left"){const m=i.getAttribute("position"),f=[];if(n)for(let _=0;_<4;_++){const x=new Float32Array(m.array);for(let R=0;R<o.count;R++){const M=o.getX(R),A=o.getY(R);x[R*3+1]+=uS(4,_,M,A)-A}f.push(new nt(x,3))}const b=new Float32Array(m.array);for(let _=0;_<o.count;_++)n?b[_*3+2]=-Cf*_e.smoothstep(o.getY(_),.2,.72)*_e.smoothstep(o.getX(_),0,.15):b[_*3+1]=dS(o.getX(_),o.getY(_),t==="pointing")-.5;f.push(new nt(b,3)),i.morphAttributes.position=f}i.setAttribute("skinIndex",new oo(l,4)),i.setAttribute("skinWeight",new nt(c,4));const u=new Vc(i,e);u.add(s[0]),u.bind(new Hs(s)),u.frustumCulled=!1;let h=!1;function p(m,f=!1,b=t==="pointing"?1:0,_=0,x=null){if(h)return;const R=n?_e.smoothstep(b,0,1):0;for(let M=0;M<ys.length;M++){const[,,A,w]=ys[M];if(f){s[M].rotation.z=0;continue}const S=Math.sin(m*w+r.phase+M*.43),y=R>0?_e.lerp(S,Math.sin(m*w*.57+r.phase+M*.61),.16*R):S,T=(M>=2?1-.18*R:1)*(x?1-(M>=2?.55:.25)*x.selectionPress:1);s[M].rotation.z=y*A*T}if(t==="left"&&!f){const M=_e.clamp(_,0,1);a.wrist.rotation.z+=.012*M,a.palm.rotation.z-=.006*M,a.index.rotation.z-=.17*M,a.indexDistal.rotation.z-=.13*M,a.middle.rotation.z-=.15*M,a.ring.rotation.z-=.12*M,a.little.rotation.z-=.09*M,a.thumb.rotation.z+=.09*M,a.thumbDistal.rotation.z+=.06*M}if(t!=="left"&&x&&!f){const M=x.selectionPress,A=x.selectionReach;a.wrist.rotation.z+=.008*A-.01*M,a.palm.rotation.z-=.012*M,a.thumb.rotation.z-=.025*M,a.thumbDistal.rotation.z-=.018*M,a.middle.rotation.z+=.02*M,a.ring.rotation.z+=.015*M,a.little.rotation.z+=.01*M}if(t!=="left"){const M=_e.clamp(b,0,1);if(n){const A=Lf(M);for(let w=0;w<4;w++)u.morphTargetInfluences[w]=A[w];u.morphTargetInfluences[4]=f?0:M*If}else u.morphTargetInfluences[0]=f?0:t==="neutral"?M:1-M}}function g(){u.parent?.updateWorldMatrix(!0,!1),u.updateMatrixWorld(!0);const m=i.getAttribute("position"),f=new U,b=new U;let _=0;for(let R=0;R<m.count;R++)f.fromBufferAttribute(m,R),u.getVertexPosition(R,b),_=Math.max(_,b.distanceTo(f));const x={};for(const R of _l){const M=d[R].index;x[R]=u.getVertexPosition(M,new U).applyMatrix4(u.matrixWorld)}return{pose:t,maxVertexDelta:_,landmarks:x,boneCount:s.length,boneTextureBytes:u.skeleton.boneTexture?.image?.data?.byteLength||0}}function v(){h||(h=!0,u.skeleton.dispose())}return{pose:t,mesh:u,bones:s,update:p,measure:g,dispose:v}}const dh=Object.freeze({baseOpacity:.38,height:.565,edgeInset:-.03,bottom:-.02}),bi=Object.freeze({left:{...dh,edgeInset:-.042,rotation:-.2,file:"/overlay/left-hand-ethereal.webp",swayX:-.006,swayY:-.005,breath:.003,phase:.45,pointer:!1,columns:iS,rows:rS},right:{...dh,rotation:0,file:"/overlay/right-hand-pointing.webp",neutralFile:"/overlay/right-hand-neutral.webp",swayX:-.006,swayY:-.005,breath:.003,phase:1.15,pointer:!0,columns:36,rows:28}}),rn=(i,e,t)=>Math.max(e,Math.min(t,i));function hS(i,{enabled:e=!0,reducedMotion:t=!1,animation:n="mesh",touchLayout:r=!1}={}){const s=n==="perspective",a=n==="rig"||s,o={mode:"mesh",enabled:!!e,visible:!1,loaded:!1,loadError:null,motionEnabled:!t,drawSurfaces:0,triangles:0,textureCount:0,joints:0,fingerJoints:0,swayX:0,swayY:0,maxVertexDelta:0,pose:"feminine-star-hover",handProfiles:Object.keys(xc),rightHover:!1,rightBlend:0,hoverBlend:0,leftFollow:0,animation:s?"perspective":a?"rig":"mesh",rightFrameWeights:[],rightDepth:0,selecting:!1,selectionReach:0,selectionPress:0,selectionAnticipation:0,selectionFollowThrough:0,selectionLift:0,touchLayout:r,targetDirectionX:0,targetDirectionY:.18},l=new Rt;l.name="OrionFeminineHands2p5D",l.visible=!1,i.add(l);const c=[],d=[],u=[],h=[],p=nS();a&&Object.defineProperty(o,"maxVertexDelta",{enumerable:!0,get:()=>Math.max(0,...u.map(Z=>Z.measure().maxVertexDelta))});let g=null,v=!1,m=0,f=0;if(!e)return{state:o,root:l,meshes:c,rigs:u,rightFrames:h,ready:Promise.resolve(!1),update(){},resize(){},setStarHovered(){},setStarDirection(){},setStarSelection(){},beginTravel(){},dispose(){i.remove(l)}};let b=!1,_=!1,x=!1,R=0,M=1,A=0,w=0;const S=[],y=new ns,T=Z=>new Promise((ae,G)=>y.load(Z,ae,void 0,G));let N=!1;function B(){const ae=2*Math.tan(_e.degToRad(i.fov*.5))*2.5;return{depth:2.5,height:ae,width:ae*i.aspect}}function k(Z,ae=0,G=0){const X=B(),re=Z.config,ye=r&&i.aspect<1,fe=Math.min(X.height*re.height,X.width*(ye?.27:.3)/Z.aspect),we=fe*Z.aspect;Z.mesh.scale.set(we,fe,1);const me=(Z.side==="left"?-X.width/2+re.edgeInset*X.width+we/2:X.width/2-re.edgeInset*X.width-we/2)+ae*X.width,P=ye?.19+(t?0:.19*m):r?.015:re.bottom,Le=-X.height/2+(P+G)*X.height+fe/2;Z.mesh.position.set(me,Le,-2.5)}function V(){if(!b){for(const Z of d)k(Z);g&&c[1]&&(g.scale.copy(c[1].scale),g.position.copy(c[1].position))}}const D=s?[bi.left.file,"/overlay/right-hand-pointing-smooth.webp"]:[bi.left.file,bi.right.file,bi.right.neutralFile],O=Promise.all(D.map(T)).then(Z=>{if(b)return Z.forEach(ae=>ae.dispose()),!1;for(const ae of Z)ae.colorSpace=_t,ae.magFilter=Dt,ae.minFilter=Gt,S.push(ae);for(let ae=0;ae<2;ae++){const G=ae===0?"left":"right",X=Z[ae],re=s&&G==="right"?{...bi[G],columns:72,rows:72}:bi[G],ye=new yn(1,1,re.columns,re.rows),fe=ye.getAttribute("position"),we=ye.getAttribute("uv");if(s&&G==="right")for(let Se=0;Se<we.count;Se++){const Ye=we.getY(Se),De=10/72,I=66/72,E=Ye<=De?Ye/De*.38:Ye<=I?.38+(Ye-De)/(I-De)*.47:.85+(Ye-I)/(1-I)*.15;we.setY(Se,E),fe.setY(Se,E-.5)}const me=new Float32Array(fe.array),P=new Float32Array(we.array);{const Se=new Float32Array(we.count*4),Ye=De=>(De=rn(De,0,1),De*De*(3-2*De));for(let De=0;De<we.count;De++){const I=P[De*2],E=P[De*2+1],Y=Ye((I-.68)/.26),ee=1-Ye((E-.16)/.22),ne=De*4;Se[ne]=1,Se[ne+1]=1,Se[ne+2]=1,Se[ne+3]=G==="left"?Ye((E-.09)/.21):1-Y*ee}ye.setAttribute("color",new nt(Se,4))}const Le=new Ut({map:X,transparent:!0,opacity:re.baseOpacity,side:Et,depthTest:!1,depthWrite:!1,toneMapped:!1,vertexColors:!0});p.material(Le);const Te=a?uh(ye,Le,G==="left"?"left":s?"perspective":"pointing",{perspective:s&&G==="right"}):null;Te&&u.push(Te);const ge=Te?Te.mesh:new ht(ye,Le);p.bind(ge),ge.name=G==="left"?"OrionFeminineLeftFraming":"OrionFeminineRightPointing",ge.renderOrder=300+ae,ge.frustumCulled=!1,c.push(ge),l.add(ge);const se=X.image?.naturalWidth||X.image?.width||1122,ze=X.image?.naturalHeight||X.image?.height||1402,oe={side:G,config:re,mesh:ge,rest:me,uvLocal:P,aspect:s&&G==="right"?1122/1402:se/ze};d.push(oe),k(oe)}if(s)h.push(c[1]);else{const ae=a?c[1].geometry.clone():c[1].geometry,G=new Ut({map:S[2],transparent:!0,opacity:bi.right.baseOpacity,side:Et,depthTest:!1,depthWrite:!1,toneMapped:!1,vertexColors:!0});p.material(G);const X=a?uh(ae,G,"neutral",{perspective:s}):null;X&&u.push(X),g=X?X.mesh:new ht(ae,G),p.bind(g),g.name="OrionFeminineRightNeutral",g.renderOrder=301,g.frustumCulled=!1,l.add(g),g.scale.copy(c[1].scale),g.position.copy(c[1].position)}return o.loaded=!0,o.visible=!0,o.textureCount=S.length,o.edgeOpacity=!0,o.joints=u.reduce((ae,G)=>ae+G.bones.length,0),o.fingerJoints=u.reduce((ae,G)=>ae+G.bones.length-2,0),l.visible=!0,N=!0,F(0,0),!0}).catch(Z=>(o.loadError="Falha ao carregar os assets das mãos",o.loaded=!1,o.visible=!1,l.visible=!1,S.forEach(ae=>ae.dispose()),console.warn("[Observatório] Assets das mãos indisponíveis",Z),!1));function F(Z,ae,G=0,X=0){if(!N||b)return;const re=rn(ae,0,.06),ye=1-Math.exp(-re*5.7);if(A+=(rn(G,-1,1)-A)*ye,w+=(rn(X,-1,1)-w)*ye,o.swayX=t?0:A,o.swayY=t?0:w,_){R+=re;const se=rn(R/.38,0,1);M=1-se*se*se*(se*(se*6-15)+10)}const fe=(v||o.selecting)&&(!_||x)?1:0;if(t)m=fe,f=0;else if(a){const ze=m-fe,oe=Math.exp(-6.5*re),Se=(f+6.5*ze)*re;m=fe+(ze+Se)*oe,f=(f-6.5*Se)*oe}else m+=(fe-m)*(1-Math.exp(-re*9.5));m=rn(m,0,1),o.hoverBlend=m,o.leftFollow=t?0:m;const we=s?aS:1,me=s?.1:.16,P=rn(m*we-(t?0:me*o.selectionPress+.015*o.selectionAnticipation),0,we);o.rightBlend=P;const Le=r?0:M;if(Le<.001){l.visible=!1,o.visible=!1,o.drawSurfaces=0,o.triangles=0;return}l.visible=!0,o.visible=!0;let Te=0;for(const se of u)se.update(Z,t,P,se.pose==="left"?o.leftFollow:0,o.selecting&&se.pose!=="left"?o:null);const ge=a&&!t?_e.smoothstep(P,.25,.75):P;for(const se of d){const ze=se.config,{mesh:oe,rest:Se,uvLocal:Ye}=se,De=oe.geometry.getAttribute("position");a||(Te=Math.max(Te,sS(Se,De.array,Ye,se.side,Z,o.swayX,o.swayY,t)),De.needsUpdate=!t);const I=t?0:o.swayX*ze.swayX,E=t?0:o.swayY*ze.swayY+Math.sin(Z*.94+ze.phase)*ze.breath;if(k(se,I,E),oe.rotation.set(0,0,ze.rotation+(t?0:Math.sin(Z*.72+ze.phase)*(ze.pointer?.01:.006))),se.side==="right"&&s&&!t&&(oe.rotation.z+=(-o.targetDirectionX*.018+(o.targetDirectionY-.18)*.012)*m,oe.rotation.y+=o.targetDirectionX*.012*m),_&&!t&&(oe.position.y-=B().height*.018*(1-M)),se.side==="left"&&o.leftFollow>0){const Y=B();oe.position.x+=Y.width*.0025*o.leftFollow,oe.position.y+=Y.height*.0035*o.leftFollow,a||(oe.rotation.z+=.008*o.leftFollow)}if(se.side==="right"&&o.selecting&&!t){const Y=B(),ee=o.selectionReach,ne=o.selectionAnticipation,K=o.selectionFollowThrough;oe.position.x+=Y.width*(-.0055*ee+.001*ne),oe.position.y+=Y.height*(.007*ee+.005*o.selectionLift-.002*ne+.001*K),oe.position.z+=.052*ee-.01*ne,oe.rotation.x+=.035*ee-.018*o.selectionPress,oe.rotation.y+=-.045*ee+.012*K,oe.rotation.z+=.02*ee-.028*o.selectionPress+.01*ne+.007*K}oe.material.opacity=ze.baseOpacity*Le*(se.side==="right"&&!s?ge:1)}if(g&&c[1]&&(g.position.copy(c[1].position),g.scale.copy(c[1].scale),g.rotation.copy(c[1].rotation),g.material.opacity=bi.right.baseOpacity*Le*(1-ge)),c[1].visible=s||ge>.003,g&&(g.visible=ge<.997),s){const se=Lf(P);o.rightFrameWeights=se,o.rightDepth=t?0:P*Cf*If}o.drawSurfaces=s?2:1+Number(c[1].visible)+Number(g.visible),o.triangles=c[0].geometry.index.count/3+(o.drawSurfaces-1)*c[1].geometry.index.count/3,a||(o.maxVertexDelta=Te)}function z(Z){v=!!Z&&!_,o.rightHover=v}function j(Z,ae){o.targetDirectionX=rn(Z,-1,1),o.targetDirectionY=rn(ae,-1,1)}function te(Z){o.selecting=!!Z&&(!_||x)&&!b,o.selectionReach=o.selecting&&!t?rn(Z.reach,0,1):0,o.selectionPress=o.selecting&&!t?rn(Z.press,0,1):0,o.selectionAnticipation=o.selecting&&!t?rn(Z.anticipation??0,0,1):0,o.selectionLift=o.selecting&&!t?rn(Z.lift??0,0,1):0,o.selectionFollowThrough=o.selecting&&!t?rn(Z.followThrough??0,0,1):0}function L(){_||(x=o.selecting&&!t,_=!0,x||te(null),z(!1))}function $(){if(!b){b=!0,l.visible=!1;for(const Z of c)Z.geometry.dispose(),Z.material.dispose(),l.remove(Z);g&&(a&&g.geometry.dispose(),g.material.dispose(),l.remove(g));for(const Z of u)Z.dispose();for(const Z of S)Z.dispose();i.remove(l),c.length=0,d.length=0,u.length=0,h.length=0,o.visible=!1,o.loaded=!1}}return{state:o,root:l,meshes:c,rigs:u,rightFrames:h,ready:O,update:F,resize:V,setStarHovered:z,setStarDirection:j,setStarSelection:te,beginTravel:L,dispose:$}}const xl="orion-complete-draft-v1";function $a(i,e=xl){try{const t=i.getItem(e);if(!t||t.length>5e5)return null;const n=JSON.parse(t);return e===xl&&n?.format!=="orion-observatorio-draft"||n?.version!==1||typeof n.name!="string"||!n.name.trim()||!["menina","menino","nao-definir"].includes(n.gender)||!["COMBATENTE","ESPECIALISTA","OCULTISTA"].includes(n.classCode)||typeof n.origin?.code!="string"||!n.character||typeof n.character!="object"?null:{...n,step:"class",creationStep:e===xl?"review":n.creationStep||"attributes"}}catch{return null}}const Ka="orion-herald-creation-v1",Df=Object.freeze(["menino","menina","nao-definir"]);function fS(){return{phase:"sealed",name:"",gender:null,continued:!1}}function Mr(i,e){return e.type==="reveal"&&i.phase==="sealed"?{...i,phase:"revealed"}:e.type==="mark"&&i.phase==="revealed"?{...i,phase:"breaking"}:e.type==="released"&&i.phase==="breaking"?{...i,phase:"identity"}:i.phase!=="identity"?i:e.type==="name"?{...i,name:String(e.value).slice(0,60),continued:!1}:e.type==="gender"&&(Df.includes(e.value)||e.value===null)?{...i,gender:e.value,continued:!1}:e.type==="continue"&&bc(i)&&!i.continued?{...i,name:i.name.trim(),continued:!0}:i}function bc(i){return i.phase==="identity"&&Df.includes(i.gender)&&i.name.trim().length>0&&i.name.trim().length<=60}const pS={fetal:{root:[.48,.46],spine:[.38,.49],neck:[.47,.69],head:[.48,.78],armL:[.48,.59],elbowL:[.6,.52],handL:[.61,.61],armR:[.48,.57],elbowR:[.58,.51],handR:[.58,.6],hipL:[.43,.37],kneeL:[.66,.44],footL:[.6,.28],hipR:[.42,.36],kneeR:[.6,.41],footR:[.54,.27]},menina:{root:[.5,.49],spine:[.5,.63],neck:[.52,.78],head:[.53,.88],armL:[.33,.73],elbowL:[.23,.62],handL:[.12,.56],armR:[.65,.73],elbowR:[.76,.63],handR:[.84,.68],hipL:[.4,.45],kneeL:[.38,.29],footL:[.36,.1],hipR:[.61,.45],kneeR:[.66,.3],footR:[.65,.1]},menino:{root:[.5,.49],spine:[.5,.63],neck:[.49,.78],head:[.48,.88],armL:[.31,.73],elbowL:[.22,.63],handL:[.12,.65],armR:[.68,.73],elbowR:[.79,.61],handR:[.88,.52],hipL:[.4,.45],kneeL:[.37,.28],footL:[.35,.1],hipR:[.6,.45],kneeR:[.64,.3],footR:[.66,.1]}},yl={root:null,spine:"root",neck:"spine",head:"neck",armL:"spine",elbowL:"armL",handL:"elbowL",armR:"spine",elbowR:"armR",handR:"elbowR",hipL:"root",kneeL:"hipL",footL:"kneeL",hipR:"root",kneeR:"hipR",footR:"kneeR"};function mS(i,e,t,n){const r=n[0]-t[0],s=n[1]-t[1],a=_e.clamp(((i-t[0])*r+(e-t[1])*s)/(r*r+s*s||1),0,1);return Math.hypot(i-t[0]-a*r,e-t[1]-a*s)}function gS(i,e){const t=pS[e];if(!t)throw new Error("Unknown silhouette rig");const n=Object.keys(yl),r=[],s={},a=new yn(1,1,48,64);for(const p of n){const g=new co,v=yl[p],m=t[p],f=v?t[v]:[.5,.5];g.name="Soul_"+e+"_"+p,g.position.set(m[0]-f[0],m[1]-f[1],0),v&&s[v].add(g),s[p]=g,r.push(g)}const o=a.getAttribute("uv"),l=[],c=[];for(let p=0;p<o.count;p++){const g=o.getX(p),v=o.getY(p),m=n.map((b,_)=>{const x=yl[b],R=t[b],M=x?t[x]:R,A=mS(g,v,R,M);return{index:_,weight:Math.exp(-Math.pow(A/.075,2)*2)+1e-15}}).sort((b,_)=>_.weight-b.weight).slice(0,4),f=m.reduce((b,_)=>b+_.weight,0);for(const b of m)l.push(b.index),c.push(b.weight/f)}a.setAttribute("skinIndex",new oo(l,4)),a.setAttribute("skinWeight",new nt(c,4));const d=new Vc(a,i);d.add(r[0]),d.bind(new Hs(r)),d.frustumCulled=!1;const u=e==="menina"?.6:e==="menino"?2.7:1.3;function h(p,g=!1,v=0){for(const b of r)b.rotation.set(0,0,0);if(g)return;const m=Math.sin(p*.7+u),f=Math.sin(p*.42+u);s.spine.rotation.z=m*.007,s.neck.rotation.z=f*.012,s.head.rotation.z=-f*.006-v*.018,s.armL.rotation.z=Math.sin(p*.53+u)*.012,s.armR.rotation.z=Math.sin(p*.49+u+1)*.012,s.elbowL.rotation.z=m*.008,s.elbowR.rotation.z=-m*.009,s.hipL.rotation.z=f*.006,s.hipR.rotation.z=-f*.005,s.kneeL.rotation.z=m*.008,s.kneeR.rotation.z=-m*.007}return{mesh:d,bones:r,geometry:a,update:h,dispose(){d.skeleton.dispose(),a.dispose()}}}const vS=`
#include <common>
#include <skinning_pars_vertex>
varying vec2 vUv;varying float vEdge,vSeed,vLife;
void main(){vUv=uv;vEdge=1.;vSeed=0.;vLife=1.;
#include <skinbase_vertex>
#include <begin_vertex>
#include <skinning_vertex>
gl_Position=projectionMatrix*modelViewMatrix*vec4(transformed,1.);
}`,Nf="Acorrentado pela realidade",hh="/fonts/SigilosDeConhecimento.ttf",Da="OrionKnowledge",Za=[{tilt:.52,slope:.95,radius:.46,speed:.115},{tilt:-.46,slope:1.12,radius:.44,speed:-.087},{tilt:.12,slope:.42,radius:.47,speed:.065},{tilt:1.05,slope:.92,radius:.45,speed:-.055},{tilt:-1.08,slope:.86,radius:.43,speed:.095}];function _S(){const i=Nf+"   ";return Za.flatMap((e,t)=>Array.from(i.repeat(2)).map((n,r)=>({char:n,ring:t,slot:r,slots:i.length*2}))).filter(e=>e.char!==" ")}function fh(i){const e=new xg,t=new yn(1,1);e.index=t.index.clone(),e.attributes.position=t.attributes.position.clone(),e.attributes.uv=t.attributes.uv.clone(),t.dispose();const n=[...new Set(i.map(l=>l.char))],r=[],s=[],a=[],o=[];i.forEach((l,c)=>{r.push(l.slot/l.slots*Math.PI*2),s.push(l.ring),a.push(n.indexOf(l.char)),o.push(c*.6180339%1)});for(const[l,c]of[["aAngle",r],["aRing",s],["aCell",a],["aSeed",o]])e.setAttribute(l,new Gr(new Float32Array(c),1));return e.instanceCount=i.length,{geometry:e,chars:n}}function xS({reducedMotion:i=!1}={}){const e=new Rt;e.name="AcorrentadoPelaRealidade";const t=_S(),{geometry:n,chars:r}=fh(t),s={uMap:{value:null},uTime:{value:0},uRelease:{value:0},uCharge:{value:0},uOpacity:{value:0}},o=`attribute float aAngle,aRing,aCell,aSeed;uniform float uTime,uRelease;varying vec2 vUv;varying float vDepth,vSeed,vCell;
 vec4 orbitConfig(float ring){${Za.map((w,S)=>`${S?"else ":""}if(ring<${(S+.5).toFixed(1)})return vec4(${w.tilt},${w.slope},${w.radius},${w.speed});`).join("")}return vec4(0.,1.,.46,.1);}
 vec3 orbit(float angle,float ring){vec4 o=orbitConfig(ring);vec3 p=vec3(cos(angle)*o.z,sin(angle)*o.z*cos(o.y),sin(angle)*o.z*sin(o.y));return vec3(p.x*cos(o.x)-p.y*sin(o.x),p.x*sin(o.x)+p.y*cos(o.x),p.z);}
 void main(){float speed=orbitConfig(aRing).w;float angle=aAngle+uTime*speed+aRing*.7;
 vec3 center=orbit(angle,aRing);vec3 tangent=orbit(angle+.002,aRing)-center;float rotation=atan(tangent.y,tangent.x);
 float release=smoothstep(.02+aSeed*.12,.9,uRelease);float spread=release*release*(.35+aSeed*.5);
 center+=normalize(center)*spread;center.y-=release*release*.12;
 rotation+=release*(aSeed-.5)*2.;mat2 turn=mat2(cos(rotation),sin(rotation),-sin(rotation),cos(rotation));
 float compression=max(.28,length(tangent.xy)/max(.00001,length(tangent)));
 vec2 local=turn*(position.xy*vec2(.039*compression,.039));vec3 p=center+vec3(local,0.);
 vDepth=center.z;vUv=uv;vSeed=aSeed;vCell=aCell;
 gl_Position=projectionMatrix*modelViewMatrix*vec4(p,1.);}`,l=`uniform sampler2D uMap;uniform float uFront,uOpacity,uRelease,uCharge,uTime;varying vec2 vUv;varying float vDepth,vSeed,vCell;
 void main(){float cellIndex=floor(vCell+.5);vec2 cell=vec2(mod(cellIndex,8.),floor(cellIndex/8.));vec2 at=vec2((cell.x+vUv.x)/8.,1.-(cell.y+1.-vUv.y)/4.);vec4 stencil=texture2D(uMap,at);float glyph=stencil.r;float halo=stencil.g*.72+stencil.b*.62;
 float side=smoothstep(-.013,.013,vDepth);float mask=mix(1.-side,side,uFront);float fade=1.-smoothstep(.35+vSeed*.2,1.,uRelease);
 float alpha=max(glyph,halo*.85)*mask*uOpacity*fade;if(alpha<.006)discard;
 float breathe=.94+.06*sin(uTime*.8+vSeed*6.);vec3 gold=mix(vec3(1.04,.56,.10),vec3(1.95,1.20,.30),uFront*.65+.15)*breathe*(1.+uCharge*.9);gold*=mix(.70,1.15,smoothstep(.05,.8,glyph));
 gl_FragColor=vec4(gold,alpha);
 #include <colorspace_fragment>
 }`,c=[],d=[!1,!0].map(w=>{const S=new wt({transparent:!0,depthTest:!1,depthWrite:!1,toneMapped:!1,blending:Qt,side:Et,forceSinglePass:!0,uniforms:{...s,uFront:{value:w?1:0}},vertexShader:o,fragmentShader:l});c.push(S);const y=new ht(n,S);return y.frustumCulled=!1,y.renderOrder=w?14:8,y.layers.enable(1),e.add(y),y}),u=t.filter((w,S)=>S%5===0),h=fh(u),p=[];u.forEach((w,S)=>{const y=S%2?1:-1;p.push(y*(.86+S%3*.022),-.82+Math.floor(S/2)/24*1.64,0)}),h.geometry.setAttribute("aCell",new Gr(new Float32Array(u.map(w=>r.indexOf(w.char))),1)),h.geometry.setAttribute("aAnchor",new Gr(new Float32Array(p),3));const g={uMap:s.uMap,uTime:{value:0},uOpacity:{value:0},uAspect:{value:1}},v=new wt({transparent:!0,depthTest:!1,depthWrite:!1,toneMapped:!1,blending:Qt,uniforms:g,vertexShader:`attribute vec3 aAnchor;attribute float aCell,aSeed;uniform float uTime,uAspect;varying vec2 vUv;varying float vCell,vSeed;
  void main(){vUv=uv;vCell=aCell;vSeed=aSeed;float a=sin(uTime*.07+aSeed*6.)*.16;mat2 turn=mat2(cos(a),sin(a),-sin(a),cos(a));vec2 at=aAnchor.xy+vec2(sin(uTime*.09+aSeed*13.),cos(uTime*.06+aSeed*9.))*.006;vec2 size=vec2(.028/max(.3,uAspect),.028)*(.65+aSeed*.4);gl_Position=vec4(at+turn*(position.xy*size),0.,1.);}`,fragmentShader:`uniform sampler2D uMap;uniform float uTime,uOpacity;varying vec2 vUv;varying float vCell,vSeed;
  void main(){float index=floor(vCell+.5);vec2 cell=vec2(mod(index,8.),floor(index/8.));vec2 at=vec2((cell.x+vUv.x)/8.,1.-(cell.y+1.-vUv.y)/4.);vec4 glyph=texture2D(uMap,at);float light=.76+.24*sin(uTime*.35+vSeed*12.);float alpha=max(glyph.r,glyph.g*.55+glyph.b*.4)*uOpacity*light*(.45+vSeed*.55);if(alpha<.003)discard;gl_FragColor=vec4(.95,.72,.38,alpha);}`}),m=new ht(h.geometry,v);m.name="KnowledgeMistGlyphs",m.frustumCulled=!1,m.renderOrder=5,m.visible=!1;let f,b,_=!1;const x={phrase:Nf,fontFamily:Da,fontURL:hh,loaded:!1,glyphs:t.length,rings:Za.length,time:0,release:0,reducedMotion:i,glowAtlasPacked:!0,ambientGlyphs:u.length,ambientVisible:!1},R=(async()=>{if(b=new FontFace(Da,`url("${hh}")`),await b.load(),_)return!1;document.fonts.add(b);const w=document.createElement("canvas");w.width=2048,w.height=1024;const S=w.getContext("2d");S.fillStyle="#fff",S.textAlign="center",S.textBaseline="alphabetic",S.font=`192px "${Da}"`;const y=r.map(O=>S.measureText(O)),T=192*Math.min(208/Math.max(...y.map(O=>O.width)),208/Math.max(...y.map(O=>O.actualBoundingBoxAscent+O.actualBoundingBoxDescent)));S.font=`${T}px "${Da}"`,r.forEach((O,F)=>{const z=S.measureText(O),j=F%8*256+128,te=Math.floor(F/8)*256+128+(z.actualBoundingBoxAscent-z.actualBoundingBoxDescent)/2;S.fillText(O,j,te)});const N=S.getImageData(0,0,w.width,w.height).data,B=[];for(const O of[5,8]){const F=document.createElement("canvas");F.width=w.width,F.height=w.height;const z=F.getContext("2d");z.filter=`blur(${O}px)`,z.drawImage(w,0,0),B.push(z.getImageData(0,0,F.width,F.height).data)}const k=document.createElement("canvas");k.width=w.width,k.height=w.height;const V=k.getContext("2d"),D=V.createImageData(k.width,k.height);for(let O=0;O<N.length;O+=4)D.data[O]=N[O+3],D.data[O+1]=B[0][O+3],D.data[O+2]=B[1][O+3],D.data[O+3]=255;return V.putImageData(D,0,0),f=new uo(k),f.colorSpace=oi,f.minFilter=Gt,f.magFilter=Dt,s.uMap.value=f,x.loaded=!0,!0})();function M(w,S,y,T=0){const N=i?0:T;s.uTime.value=N,s.uRelease.value=i?0:w,s.uCharge.value=S,s.uOpacity.value=y*(i?1-w:1),e.visible=x.loaded&&y>.001&&w<1,x.time=N,x.release=w}function A(w,S=0,y=1){g.uTime.value=i?0:S,g.uAspect.value=y,g.uOpacity.value=Math.max(0,Math.min(1,w))*.2,m.visible=x.loaded&&w>.001,x.ambientVisible=m.visible}return{root:e,atmosphere:m,setAtmosphere:A,front:d[1],back:d[0],count:t.length,state:x,ready:R,update:M,dispose(){_=!0,e.remove(...d),n.dispose(),c.forEach(w=>w.dispose()),h.geometry.dispose(),v.dispose(),f?.dispose(),b&&document.fonts.delete(b)}}}const Of=2.8,yS=i=>Math.max(0,Math.min(1,i)),Si=(i,e,t)=>{const n=yS((t-i)/(e-i));return n*n*(3-2*n)};function bS(i,e=!1){const t=Math.max(0,i);if(e){const n=Si(0,.18,t);return{charge:0,fracture:n,baby:1-n,children:n,separation:1,particles:0,complete:t>=.18}}return{charge:Si(0,.25,t)*(1-Si(.5,.9,t)),fracture:Si(.22,1.95,t),baby:1-Si(.85,1.9,t),children:Si(1.15,2.65,t),separation:Si(1.15,2.8,t),particles:Si(.6,.9,t),complete:t>=Of}}const SS=[{file:"/assets/creation/gray-far-v9.png",kind:"gray-far",z:-280,opacity:.3},{file:"/assets/creation/gray-near-v9.png",kind:"gray-near",z:-180,opacity:.21},{file:"/assets/creation/red-left-v14.png",kind:"red-left",z:-110,opacity:.64},{file:"/assets/creation/red-right-v14.png",kind:"red-right",z:-65,opacity:.59}],ph=.3,MS=.75;function ES(i){return ph+(1-ph)*i}function TS(i){return .5-.5*Math.cos(i*2*Math.PI/4.8)}function AS(i,e,{reducedMotion:t=!1,parallaxEnabled:n=!0}={}){const r=e.material,s=r.map;r.dispose(),e.material=new wt({depthTest:!1,depthWrite:!1,uniforms:{},vertexShader:"void main(){gl_Position=vec4(position.xy*2.,.999,1.);}",fragmentShader:"void main(){gl_FragColor=vec4(0.,0.,0.,1.);}"}),e.material.map=s;const a={active:4,loaded:0,components:5,transition:0,parallaxEnabled:n&&!t,parallaxStrength:1,foregroundEnabled:!0,pulse:[0,0],reducedMotion:t},o=new ns,l=[],c=`uniform vec2 pan;uniform float aspect,plateAspect,time,transition,red,anchorSide,beat,motion,driftPhase;varying vec2 vUv;
 void main(){vec2 cover=vec2(min(1.,aspect/plateAspect),min(1.,plateAspect/aspect));vec2 at=.5+(uv-.5)*cover*.96;
 float portrait=1.-smoothstep(.75,1.2,aspect);at.x+=red*.23*portrait*(anchorSide<.5?-1.:1.);
 vec2 anchor=vec2(anchorSide<.5?.20:.80,anchorSide<.5?.25:.78);float live=beat*red*(1.-transition)*motion;
 at=anchor+(at-anchor)/(1.+live*.02);at+=pan;
 at+=vec2(sin(time*.09+driftPhase),cos(time*.07+driftPhase))*.0018*motion*transition*(1.-red);
 vUv=at;gl_Position=vec4(position.xy*2.,.998,1.);}`,d=`uniform sampler2D map;uniform float transition,opacity,red,saturation,brightness;varying vec2 vUv;
 void main(){vec4 cloud=texture2D(map,clamp(vUv,vec2(.001),vec2(.999)));float grey=dot(cloud.rgb,vec3(.2126,.7152,.0722));
 vec3 color=mix(vec3(grey),cloud.rgb,mix(1.,saturation,red));
 color=mix(color,grey*vec3(.82,.80,.95),transition);
 float layerOpacity=mix(opacity,red>.5?0.:opacity*1.65,transition);
 float alpha=cloud.a*layerOpacity;gl_FragColor=vec4(color,alpha);
 #include <colorspace_fragment>
 gl_FragColor.rgb*=mix(1.,brightness,red);
 }`,u=Promise.all(SS.map(async(p,g)=>{const v=await o.loadAsync(p.file);v.colorSpace=_t,v.minFilter=Gt,v.magFilter=Dt;const m=new wt({transparent:!0,depthTest:!1,depthWrite:!1,toneMapped:!1,uniforms:{map:{value:v},pan:{value:new Ce},aspect:{value:innerWidth/innerHeight},plateAspect:{value:v.image.width/v.image.height},time:{value:0},transition:{value:0},opacity:{value:p.opacity},red:{value:g>1?1:0},anchorSide:{value:g===3?1:0},motion:{value:t?0:1},beat:{value:1},saturation:{value:1},brightness:{value:MS},driftPhase:{value:g*1.9}},vertexShader:c,fragmentShader:d}),f=new ht(new yn(1,1),m);return f.position.z=p.z,f.frustumCulled=!1,f.renderOrder=3+g*.1,f.userData={kind:p.kind,volumeFragment:!0,baseX:0,baseY:0,parallaxOffsetX:0,parallaxOffsetY:0},l[g]=f,i.add(f),a.loaded++,!0}));function h(p,g,v,m){const f=1-Math.exp(-Math.min(.1,Math.max(0,m))*2.4),b=t||a.transition===1?1:TS(p);a.pulse=[b,b],a.active=a.transition===1?2:4,l.forEach((_,x)=>{if(!_)return;const R=_.userData,M=_.material.uniforms;R.parallaxOffsetX+=((a.parallaxEnabled?-g*(.7+x*.25)*a.parallaxStrength:0)-R.parallaxOffsetX)*f,R.parallaxOffsetY+=((a.parallaxEnabled?-v*(.4+x*.18)*a.parallaxStrength:0)-R.parallaxOffsetY)*f,_.visible=x<2||a.transition<1,M.pan.value.set(R.parallaxOffsetX*.004,R.parallaxOffsetY*.004),M.aspect.value=innerWidth/innerHeight,M.time.value=t?0:p,M.transition.value=a.transition,M.beat.value=x<2?1:_e.lerp(b,1,a.transition),M.saturation.value=x<2?1:ES(M.beat.value)})}return{ready:u,layers:l,state:a,resize(){},update:h,applyQuality(){a.active=a.transition===1?2:4},setTransition(p){a.transition=p},setParallaxStrength(p){a.parallaxStrength=_e.clamp(p,.45,1.6)}}}const Ja={nebula:"/assets/creation/gray-far-v9.png",nebulaPortrait:"/assets/creation/gray-far-v9.png",baby:"/assets/creation/unborn-v5.png",children:"/assets/creation/souls-v9.png"};function Uf(i=innerWidth/innerHeight){return i<.85?Ja.nebulaPortrait:Ja.nebula}const Na=(i,e,t)=>_e.smoothstep(t,i,e),wS=`
 uniform sampler2D uMap;uniform vec4 uUV;uniform float uOpacity,uReveal,uTime,uCharge,uSelected,uFlip,uHover;
 varying vec2 vUv;varying float vEdge,vSeed,vLife;
 float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(fract(sin(dot(i,vec2(127.1,311.7)))*43758.5453),fract(sin(dot(i+vec2(1.,0.),vec2(127.1,311.7)))*43758.5453),f.x),mix(fract(sin(dot(i+vec2(0.,1.),vec2(127.1,311.7)))*43758.5453),fract(sin(dot(i+1.,vec2(127.1,311.7)))*43758.5453),f.x),f.y);}
 void main(){
  vec2 at=uUV.xy+vec2(mix(vUv.x,1.-vUv.x,uFlip),vUv.y)*uUV.zw;
  vec4 texel=texture2D(uMap,at);
  // A complete reveal is identically one: avoid procedural noise at rest.
  float mask=1.;
  if(uReveal<1.){
   float n=noise(vUv*10.)*.65+noise(vUv*23.)*.35;
   mask=smoothstep(n-.13,n+.13,uReveal*1.35-.12);
  }
  // Solid alpha core: only the antialiased contour may blend.
  float coverage=smoothstep(.12,.65,texel.a);
  // Fully covered pixels cannot have an outer rim. Keep all four taps at
  // the contour, including transparent pixels that contribute its glow.
  float rim=0.;
  if(coverage<1.){
   vec2 stepUV=uUV.zw*.006;
   float nearAlpha=max(max(texture2D(uMap,at+vec2(stepUV.x,0.)).a,texture2D(uMap,at-vec2(stepUV.x,0.)).a),max(texture2D(uMap,at+vec2(0.,stepUV.y)).a,texture2D(uMap,at-vec2(0.,stepUV.y)).a));
   rim=max(0.,smoothstep(.12,.65,nearAlpha)-coverage);
  }
  float emphasis=.38+uHover*.45+uSelected*.35;
  float alpha=max(coverage,rim*emphasis)*uOpacity*mask*vLife;
  alpha*=smoothstep(0.,.025,vUv.x)*(1.-smoothstep(.975,1.,vUv.x))*smoothstep(0.,.025,vUv.y)*(1.-smoothstep(.975,1.,vUv.y));
  if(alpha<.006)discard;
  vec3 color=mix(vec3(0.),vec3(.8,.53,.20),rim*emphasis)+vec3(.9,.87,.96)*uCharge*.9;
  color*=1.+uCharge*.24;
  gl_FragColor=vec4(color,alpha);
  #include <colorspace_fragment>
 }`;function RS(i,{opacity:e=1,uv:t=[0,0,1,1],motion:n=1,flip:r=!1}={}){return new wt({transparent:!0,depthTest:!1,depthWrite:!1,side:Et,forceSinglePass:!0,toneMapped:!1,uniforms:{uMap:{value:i},uUV:{value:new rt(...t)},uOpacity:{value:e},uMotion:{value:n},uTime:{value:0},uCharge:{value:0},uReveal:{value:1},uSelected:{value:0},uHover:{value:0},uFlip:{value:r?1:0}},vertexShader:vS,fragmentShader:wS})}function CS({scene:i,camera:e,panel:t,reducedMotion:n=!1,environment:r}){const s=new ns,a={},o={},l={},c=new Rt;c.name="CreationCinematicLayers",i.add(c);const d={rigMode:"image-skinned-2.5D",joints:48,fieldLayers:0,bindingType:"knowledge-sigils",bindingLayers:Za.length,ready:!1,phase:"sealed",releaseProgress:0,selected:null,surfaces:0,fragments:0,particleCount:64,gestureFromMark:!1};let u=null,h=null,p=null,g={x:0,y:0},v=!0,m=null;const f={},b=new U,_=new U,x=new dt;function R(L,$,Z){return _.set(L/innerWidth*2-1,1-$/innerHeight*2,.5).unproject(e).sub(b).normalize(),b.clone().addScaledVector(_,(Z-b.z)/_.z)}function M(L,$,Z,ae,G=0,X=0){const re=L.material.uniforms.uMap.value.image;if(!re||!$.width||!$.height)return;const ye=re.width*ae[2]/(re.height*ae[3]),fe=Math.min($.height,$.width/ye),we=fe*ye,me=R($.x+$.width/2,$.y+$.height/2+X,Z),P=R($.x+$.width/2-we/2,$.y+$.height/2,Z),Le=R($.x+$.width/2+we/2,$.y+$.height/2,Z);n||(me.x+=g.x*(L.userData.parallax??.12),me.y+=g.y*.07),L.position.copy(me),L.scale.set(P.distanceTo(Le),P.distanceTo(Le)/ye,P.distanceTo(Le)),L.quaternion.copy(x),L.material.uniforms.uTime.value=n?0:G}const A={baby:[.1494140625,.17578125,.69140625,.6966145833],menina:[.145833333,.072265625,.266927083,.8515625],menino:[.588541667,.072265625,.279947917,.8515625]},w=xS({reducedMotion:n});c.add(w.root,w.atmosphere),d.links=0,d.glyphs=w.count;const S=Promise.all([w.ready,...["baby","children"].map(async L=>{const $=await s.loadAsync(Ja[L]);$.colorSpace=_t,$.minFilter=Gt,$.magFilter=Dt,a[L]=$})]).then(()=>{for(const L of["baby","menina","menino"]){const $=RS(a[L==="baby"?"baby":"children"],{uv:A[L],motion:n?0:1,flip:!1}),Z=gS($,L==="baby"?"fetal":L);l[L]=Z;const ae=Z.mesh;ae.userData.parallax=.1,ae.frustumCulled=!1,ae.layers.enable(1),ae.renderOrder=11,ae.visible=L==="baby",c.add(ae),o[L]=ae}return r?.ready}).then(()=>(u=performance.now(),d.ready=!0,d.surfaces=5,!0)),y=64,T=new Float32Array(y*3),N=new Float32Array(y*3),B=new Float32Array(y);for(let L=0;L<y;L++){const $=L*2.3999632,Z=.28+L%7/35;T[L*3]=Math.cos($)*Z,T[L*3+1]=Math.sin($)*Z,N[L*3]=Math.cos($)*(1.1+L%5*.2),N[L*3+1]=Math.sin($)*.9,N[L*3+2]=(L%3-1)*.3,B[L]=L*.6180339%1}const k=new Lt;k.setAttribute("position",new ct(T,3)),k.setAttribute("aVelocity",new ct(N,3)),k.setAttribute("aSeed",new ct(B,1));const V=new wt({transparent:!0,depthTest:!1,depthWrite:!1,blending:Qt,toneMapped:!1,uniforms:{uTime:{value:0},uElapsed:{value:0},uActive:{value:0},uExtent:{value:new Ce(1,1)},uDpr:{value:Math.min(devicePixelRatio,1.5)}},vertexShader:"attribute vec3 aVelocity;attribute float aSeed;uniform float uTime,uElapsed,uActive,uDpr;uniform vec2 uExtent;varying float alpha;void main(){float t=max(0.,uElapsed-.6);float flight=min(t,4.);float drag=1.-exp(-flight*.9);vec3 p=position+aVelocity*drag;p.y-=.025*flight*flight;p.xy+=vec2(sin(uTime*.2+aSeed*10.),cos(uTime*.17+aSeed*8.))*.012*step(4.,t);vec4 mv=modelViewMatrix*vec4(p.xy*uExtent,p.z,1.);gl_Position=projectionMatrix*mv;gl_PointSize=(1.5+aSeed*2.8)*uDpr;alpha=uActive*smoothstep(0.,.2,t)*(.38+.22*sin(uTime*.7+aSeed*10.))*mix(1.,step(.75,aSeed)*.22,smoothstep(4.,8.,t));}",fragmentShader:"varying float alpha;void main(){float r=length(gl_PointCoord-.5);float a=(1.-smoothstep(.02,.5,r))*alpha;gl_FragColor=vec4(1.,.84,.5,a);}"}),D=new Xc(k,V);D.layers.enable(1),D.renderOrder=15,D.frustumCulled=!1,D.visible=!n,c.add(D);function O(){for(const[L,$]of[["baby",".baby-target"],["orbit",".sealed-being"],["menina",'[data-gender="menina"] .soul-anchor'],["menino",'[data-gender="menino"] .soul-anchor']])f[L]=t.querySelector($).getBoundingClientRect();v=!1,d.layoutPasses=(d.layoutPasses||0)+1}function F(){v=!0}const z=new ResizeObserver(F);for(const L of t.querySelectorAll(".baby-target,.sealed-being,.soul-anchor,.identity-form,.birth-stage"))z.observe(L);t.addEventListener("scroll",F,!0),window.addEventListener("resize",F);function j(L){if(!d.ready)return;for(const[se,ze]of Object.entries(o)){const oe=ze.material.uniforms.uHover;oe.value=_e.lerp(oe.value,m===se?1:0,n?1:.15)}const $=L*.001;e.updateWorldMatrix(!0,!1),e.getWorldPosition(b),e.getWorldQuaternion(x),v&&O();const Z=n?1:Na(.5,2.1,(L-u)/1e3);d.introProgress=Z,d.phase==="sealed"&&(t.querySelector(".baby-target").disabled=Z<1);const ae=h===null?0:(L-h)/1e3,G=bS(ae,n),X=h!==null,re=X?n?Math.min(1,ae/.18):Na(.5,1.65,ae):0;r?.setTransition(re),d.environmentTransition=re;const ye=X&&!n?Na(.12,.52,ae)*(1-Na(.62,1.3,ae)):0;t.style.setProperty("--birth-flash",String(ye)),t.style.setProperty("--birth-transition",String(re)),X&&(d.releaseProgress=Math.min(1,ae/(n?.18:2.8)));const fe=o.baby,we=n?0:Math.sin($*.6)*4;M(fe,f.baby,-42,A.baby,$,we),l.baby.update($,n,0),fe.material.uniforms.uCharge.value=X?G.charge:0,fe.material.uniforms.uReveal.value=X?G.baby:1,fe.material.uniforms.uOpacity.value=Z,fe.visible=!(X&&G.complete);const me=f.orbit,P=Math.min(me.width,me.height),Le=R(me.x+me.width/2,me.y+me.height/2+we,-44),Te=R(me.x+me.width/2-P/2,me.y+me.height/2,-44),ge=R(me.x+me.width/2+P/2,me.y+me.height/2,-44);w.root.position.copy(Le),w.root.quaternion.copy(x),w.root.scale.setScalar(Te.distanceTo(ge)),w.update(X?G.fracture:0,X?G.charge:0,Z,$),w.setAtmosphere(X?G.separation:0,$,innerWidth/innerHeight),d.bindingFracture=X?G.fracture:0;for(const se of["menina","menino"]){const ze=o[se];if(ze.visible=X,!X)continue;const oe=f[se],Se=f.baby,Ye=G.separation,De=n?0:Math.sin(Ye*Math.PI)*28,I={width:oe.width,height:oe.height,x:_e.lerp(Se.x+Se.width/2-oe.width/2,oe.x,Ye),y:_e.lerp(Se.y+Se.height/2-oe.height/2,oe.y,Ye)-De};M(ze,I,-39,A[se],$,n?0:Math.sin($*.55+(se==="menina"?0:2))*4);const E=ze.material.uniforms;l[se].update($,n,E.uSelected.value),E.uReveal.value=G.children,E.uSelected.value=_e.lerp(E.uSelected.value,d.selected===se?1:0,n?1:.12)}if(X&&!n){D.visible=!0;const se=w.root.position;D.position.copy(se),D.quaternion.copy(x),V.uniforms.uTime.value=$,V.uniforms.uElapsed.value=ae,V.uniforms.uActive.value=G.particles,V.uniforms.uExtent.value.set(w.root.scale.x,w.root.scale.y)}if(X&&G.complete&&p){d.phase="identity";const se=p;p=null,se()}}function te({immediate:L=!1}={}){return h!==null?Promise.resolve(!1):(d.phase="breaking",h=performance.now()-(L?Of*1e3+1:0),new Promise($=>{p=$}))}return{ready:S,state:d,update:j,release:te,invalidateLayout:F,get meshes(){return o},rigs:l,bindings:w,hover(L){m=L},select(L){d.selected=L},point(L){g=L},dispose(){z.disconnect(),t.removeEventListener("scroll",F,!0),window.removeEventListener("resize",F),i.remove(c),w.dispose();for(const L of Object.values(l))L.dispose();k.dispose(),V.dispose();for(const L of Object.values(o))L.material.dispose();for(const L of Object.values(a))L.dispose()}}}function IS(i,{reducedMotion:e=!1}={}){let t=!1,n=!1,r=[];const s=i.querySelector(".paper-content"),a=i.querySelector(".paper-landing"),o=i.querySelector(".physical-sheet"),l=document.createElement("div");l.className="paper-fold-light",l.setAttribute("aria-hidden","true"),a.append(l);async function c(d,u,h){const p=d.animate(u,h);r.push(p),await p.finished.catch(()=>{}),p.cancel()}return{get busy(){return t},async turn(d,{backward:u=!1,focus:h=null}={}){if(t||n)return!1;t=!0,i.inert=!0,i.dataset.turn="out",o.setAttribute("aria-busy","true");const p=u?-1:1;try{return e||await c(s,[{opacity:1,transform:"none"},{opacity:0,transform:`perspective(1400px) translateX(${-p*24}px) rotateY(${-p*7}deg)`}],{duration:220,easing:"cubic-bezier(.4,0,.7,1)",fill:"forwards"}),s.style.opacity="0",n||(await d(),n)?!1:(i.dataset.turn="in",s.style.opacity="1",await Promise.all([c(s,e?[{opacity:0},{opacity:1}]:[{opacity:0,transform:`perspective(1400px) translateX(${p*28}px) rotateY(${p*9}deg)`},{opacity:1,transform:"none"}],{duration:e?100:390,easing:"cubic-bezier(.16,.8,.22,1)",fill:"both"}),...e?[]:[c(l,[{opacity:0,transform:`translateX(${p*80}%)`},{opacity:.8,offset:.35},{opacity:0,transform:`translateX(${-p*80}%)`}],{duration:500,easing:"ease-out"})]]),!0)}finally{n||(i.inert=!1,s.style.opacity="",delete i.dataset.turn,o.setAttribute("aria-busy","false"),h?.()?.focus({preventScroll:!0})),r=[],t=!1}},dispose(){n=!0,r.forEach(d=>d.cancel()),l.remove()}}}async function PS(i,{reducedMotion:e=!1}={}){const t=[...i.querySelectorAll(".workshop-plank")];i.dataset.phase="landing",e?t.forEach(s=>s.style.transform="none"):await Promise.all(t.map(async(s,a)=>{const o=a%2?1:-1,l=s.animate([{transform:`translate3d(${o*4}%, -120vh, 340px) rotateX(58deg) rotateZ(${o*2.5}deg)`,opacity:0,easing:"cubic-bezier(.48,0,.8,.65)"},{transform:`translate3d(0, 7px, 0) rotateX(-1deg) rotateZ(${o*.12}deg)`,opacity:1,offset:.69,easing:"ease-out"},{transform:"translate3d(0,-3px,0) rotateX(.5deg)",offset:.83},{transform:"none",opacity:1}],{duration:880+a*22,delay:a*65,fill:"both"});await l.finished.catch(()=>{}),s.style.transform="none",l.cancel()})),document.documentElement.dataset.paperActive="1",i.dataset.phase="paper";const n=i.querySelector(".paper-landing"),r=n.animate(e?[{opacity:0},{opacity:1}]:[{transform:"translate3d(0,-90vh,180px) rotateX(25deg) rotateZ(-3deg)",opacity:0,easing:"cubic-bezier(.32,0,.64,.78)"},{transform:"translate3d(0,4px,0) rotateX(-1deg) rotateZ(.3deg)",opacity:1,offset:.78},{transform:"translate3d(0,-1px,0) rotateZ(-.1deg)",offset:.9},{transform:"none",opacity:1}],{duration:e?120:820,fill:"both"});await r.finished.catch(()=>{}),n.style.opacity="1",r.cancel()}const Mi=Object.freeze([{code:"ACADEMICO",label:"Acadêmico",source:"Livro Base",fixedSkills:["CIENCIAS","INVESTIGACAO"],variableSkillCount:0,professionRequired:!1,powerName:"Saber é Poder"},{code:"AGENTE_SAUDE",label:"Agente de Saúde",source:"Livro Base",fixedSkills:["INTUICAO","MEDICINA"],variableSkillCount:0,professionRequired:!1,powerName:"Técnica Medicinal"},{code:"ARTISTA",label:"Artista",source:"Livro Base",fixedSkills:["ARTES","ENGANACAO"],variableSkillCount:0,professionRequired:!1,powerName:"Magnum Opus"},{code:"ATLETA",label:"Atleta",source:"Livro Base",fixedSkills:["ACROBACIA","ATLETISMO"],variableSkillCount:0,professionRequired:!1,powerName:"110%"},{code:"CHEF",label:"Chef",source:"Livro Base",fixedSkills:["FORTITUDE","PROFISSAO"],variableSkillCount:0,professionRequired:!0,powerName:"Prato do Dia"},{code:"CRIMINOSO",label:"Criminoso",source:"Livro Base",fixedSkills:["CRIME","FURTIVIDADE"],variableSkillCount:0,professionRequired:!1,powerName:"Artifício"},{code:"CULTISTA_ARREPENDIDO",label:"Cultista Arrependido",source:"Livro Base",fixedSkills:["OCULTISMO","RELIGIAO"],variableSkillCount:0,professionRequired:!1,powerName:"Traços do Outro Lado"},{code:"DESGARRADO",label:"Desgarrado",source:"Livro Base",fixedSkills:["FORTITUDE","SOBREVIVENCIA"],variableSkillCount:0,professionRequired:!1,powerName:"Calejado"},{code:"ENGENHEIRO",label:"Engenheiro",source:"Livro Base",fixedSkills:["PROFISSAO","TECNOLOGIA"],variableSkillCount:0,professionRequired:!0,powerName:"Ferramenta Favorita"},{code:"EXECUTIVO",label:"Executivo",source:"Livro Base",fixedSkills:["DIPLOMACIA","PROFISSAO"],variableSkillCount:0,professionRequired:!0,powerName:"Processo Otimizado"},{code:"INVESTIGADOR",label:"Investigador",source:"Livro Base",fixedSkills:["INVESTIGACAO","PERCEPCAO"],variableSkillCount:0,professionRequired:!1,powerName:"Faro para Pistas"},{code:"LUTADOR",label:"Lutador",source:"Livro Base",fixedSkills:["LUTA","REFLEXOS"],variableSkillCount:0,professionRequired:!1,powerName:"Lutador Exímio"},{code:"MAGNATA",label:"Magnata",source:"Livro Base",fixedSkills:["DIPLOMACIA","PILOTAGEM"],variableSkillCount:0,professionRequired:!1,powerName:"Ajudante Fiel"},{code:"MERCENARIO",label:"Mercenário",source:"Livro Base",fixedSkills:["INICIATIVA","INTIMIDACAO"],variableSkillCount:0,professionRequired:!1,powerName:"Posição de Combate"},{code:"MILITAR",label:"Militar",source:"Livro Base",fixedSkills:["PONTARIA","TATICA"],variableSkillCount:0,professionRequired:!1,powerName:"Em Formação"},{code:"OPERARIO",label:"Operário",source:"Livro Base",fixedSkills:["FORTITUDE","PROFISSAO"],variableSkillCount:0,professionRequired:!0,powerName:"Ferramenta de Trabalho"},{code:"POLICIAL",label:"Policial",source:"Livro Base",fixedSkills:["PERCEPCAO","PONTARIA"],variableSkillCount:0,professionRequired:!1,powerName:"Patrulha"},{code:"RELIGIOSO",label:"Religioso",source:"Livro Base",fixedSkills:["RELIGIAO","VONTADE"],variableSkillCount:0,professionRequired:!1,powerName:"Acalentar"},{code:"SERVIDOR_PUBLICO",label:"Servidor Público",source:"Livro Base",fixedSkills:["INTUICAO","VONTADE"],variableSkillCount:0,professionRequired:!1,powerName:"Espírito Cívico"},{code:"TEORICO_CONSPIRACAO",label:"Teórico da Conspiração",source:"Livro Base",fixedSkills:["INVESTIGACAO","OCULTISMO"],variableSkillCount:0,professionRequired:!1,powerName:"Eu Já Sabia"},{code:"TI",label:"T.I.",source:"Livro Base",fixedSkills:["INVESTIGACAO","TECNOLOGIA"],variableSkillCount:0,professionRequired:!1,powerName:"Motor de Busca"},{code:"TRABALHADOR_RURAL",label:"Trabalhador Rural",source:"Livro Base",fixedSkills:["ADESTRAMENTO","SOBREVIVENCIA"],variableSkillCount:0,professionRequired:!1,powerName:"Desbravador"},{code:"TRAMBIQUEIRO",label:"Trambiqueiro",source:"Livro Base",fixedSkills:["CRIME","ENGANACAO"],variableSkillCount:0,professionRequired:!1,powerName:"Impostor"},{code:"UNIVERSITARIO",label:"Universitário",source:"Livro Base",fixedSkills:["ATUALIDADES","INVESTIGACAO"],variableSkillCount:0,professionRequired:!1,powerName:"Dedicação"},{code:"VITIMA",label:"Vítima",source:"Livro Base",fixedSkills:["REFLEXOS","VONTADE"],variableSkillCount:0,professionRequired:!1,powerName:"Cicatrizes Psicológicas"},{code:"AMIGO_ANIMAIS",label:"Amigo dos Animais",source:"Sobrevivendo ao Horror",fixedSkills:["ADESTRAMENTO","PERCEPCAO"],variableSkillCount:0,professionRequired:!1,powerName:"Companheiro Animal"},{code:"ASTRONAUTA",label:"Astronauta",source:"Sobrevivendo ao Horror",fixedSkills:["CIENCIAS","FORTITUDE"],variableSkillCount:0,professionRequired:!1,powerName:"Acostumado ao Extremo"},{code:"CHEF_OUTRO_LADO",label:"Chef do Outro Lado",source:"Sobrevivendo ao Horror",fixedSkills:["OCULTISMO","PROFISSAO"],variableSkillCount:0,professionRequired:!0,powerName:"Fome do Outro Lado"},{code:"COLEGIAL",label:"Colegial",source:"Sobrevivendo ao Horror",fixedSkills:["ATUALIDADES","TECNOLOGIA"],variableSkillCount:0,professionRequired:!1,powerName:"Poder da Amizade"},{code:"COSPLAYER",label:"Cosplayer",source:"Sobrevivendo ao Horror",fixedSkills:["ARTES","VONTADE"],variableSkillCount:0,professionRequired:!1,powerName:"Não é fantasia, é cosplay!"},{code:"DIPLOMATA",label:"Diplomata",source:"Sobrevivendo ao Horror",fixedSkills:["ATUALIDADES","DIPLOMACIA"],variableSkillCount:0,professionRequired:!1,powerName:"Conexões"},{code:"EXPLORADOR",label:"Explorador",source:"Sobrevivendo ao Horror",fixedSkills:["FORTITUDE","SOBREVIVENCIA"],variableSkillCount:0,professionRequired:!1,powerName:"Manual do Sobrevivente"},{code:"EXPERIMENTO",label:"Experimento",source:"Sobrevivendo ao Horror",fixedSkills:["ATLETISMO","FORTITUDE"],variableSkillCount:0,professionRequired:!1,powerName:"Mutação"},{code:"FANATICO_CRIATURAS",label:"Fanático por Criaturas",source:"Sobrevivendo ao Horror",fixedSkills:["INVESTIGACAO","OCULTISMO"],variableSkillCount:0,professionRequired:!1,powerName:"Conhecimento Oculto"},{code:"FOTOGRAFO",label:"Fotógrafo",source:"Sobrevivendo ao Horror",fixedSkills:["ARTES","PERCEPCAO"],variableSkillCount:0,professionRequired:!1,powerName:"Através da Lente"},{code:"INVENTOR_PARANORMAL",label:"Inventor Paranormal",source:"Sobrevivendo ao Horror",fixedSkills:["PROFISSAO","VONTADE"],variableSkillCount:0,professionRequired:!0,powerName:"Invenção Paranormal"},{code:"JOVEM_MISTICO",label:"Jovem Místico",source:"Sobrevivendo ao Horror",fixedSkills:["OCULTISMO","RELIGIAO"],variableSkillCount:0,professionRequired:!1,powerName:"A Culpa é das Estrelas"},{code:"LEGISTA_NOTURNO",label:"Legista do Turno da Noite",source:"Sobrevivendo ao Horror",fixedSkills:["CIENCIAS","MEDICINA"],variableSkillCount:0,professionRequired:!1,powerName:"Luto Habitual"},{code:"MATEIRO",label:"Mateiro",source:"Sobrevivendo ao Horror",fixedSkills:["PERCEPCAO","SOBREVIVENCIA"],variableSkillCount:0,professionRequired:!1,powerName:"Mapa Celeste"},{code:"MERGULHADOR",label:"Mergulhador",source:"Sobrevivendo ao Horror",fixedSkills:["ATLETISMO","FORTITUDE"],variableSkillCount:0,professionRequired:!1,powerName:"Fôlego de Nadador"},{code:"MOTORISTA",label:"Motorista",source:"Sobrevivendo ao Horror",fixedSkills:["PILOTAGEM","REFLEXOS"],variableSkillCount:0,professionRequired:!1,powerName:"Mãos no Volante"},{code:"NERD_ENTUSIASTA",label:"Nerd Entusiasta",source:"Sobrevivendo ao Horror",fixedSkills:["CIENCIAS","TECNOLOGIA"],variableSkillCount:0,professionRequired:!1,powerName:"O Inteligentão"},{code:"PSICOLOGO",label:"Psicólogo",source:"Sobrevivendo ao Horror",fixedSkills:["INTUICAO","PROFISSAO"],variableSkillCount:0,professionRequired:!0,powerName:"Terapia"},{code:"REPORTER_INVESTIGATIVO",label:"Repórter Investigativo",source:"Sobrevivendo ao Horror",fixedSkills:["ATUALIDADES","INVESTIGACAO"],variableSkillCount:0,professionRequired:!1,powerName:"Encontrar a Verdade"},{code:"ACALENTADOR",label:"Acalentador",source:"Suplemento Órion",fixedSkills:["DIPLOMACIA","INTUICAO"],variableSkillCount:0,professionRequired:!1,powerName:"Apoio Emocional"},{code:"ALFAIATE",label:"Alfaiate",source:"Suplemento Órion",fixedSkills:["ARTES","PROFISSAO"],variableSkillCount:0,professionRequired:!0,powerName:"Fada Madrinha"},{code:"APOSTADOR",label:"Apostador",source:"Suplemento Órion",fixedSkills:["CRIME","ENGANACAO"],variableSkillCount:0,professionRequired:!1,powerName:"Carta na Manga"},{code:"ATIRADOR_EXIMIO",label:"Atirador Exímio",source:"Suplemento Órion",fixedSkills:["PERCEPCAO","PONTARIA"],variableSkillCount:0,professionRequired:!1,powerName:"Precisão Mortal"},{code:"BOMBADO",label:"Bombado",source:"Suplemento Órion",fixedSkills:["ATLETISMO","FORTITUDE"],variableSkillCount:0,professionRequired:!1,powerName:"AESTHETIC!"},{code:"BOTICARIO",label:"Boticário",source:"Suplemento Órion",fixedSkills:["CIENCIAS","MEDICINA"],variableSkillCount:0,professionRequired:!1,powerName:"Medicina Amarga"},{code:"COLECIONADOR",label:"Colecionador",source:"Suplemento Órion",fixedSkills:["OCULTISMO","SOBREVIVENCIA"],variableSkillCount:0,professionRequired:!1,powerName:"Recompensa de Espólios"},{code:"CRIANCA_AMALDICOADA",label:"Criança Amaldiçoada",source:"Suplemento Órion",fixedSkills:["OCULTISMO","VONTADE"],variableSkillCount:0,professionRequired:!1,powerName:"Feito de Medo"},{code:"DESOCUPADO",label:"Desocupado",source:"Suplemento Órion",fixedSkills:["ATUALIDADES"],variableSkillCount:1,professionRequired:!1,powerName:"Conhecimento Específico"},{code:"HERDEIRO",label:"Herdeiro",source:"Suplemento Órion",fixedSkills:["ATUALIDADES","OCULTISMO"],variableSkillCount:0,professionRequired:!1,powerName:"Herança"},{code:"INVENTOR",label:"Inventor",source:"Suplemento Órion",fixedSkills:["INTUICAO","PROFISSAO"],variableSkillCount:0,professionRequired:!0,powerName:"Gambiarra Aprimorada"},{code:"LINHA_FRENTE",label:"Linha de Frente",source:"Suplemento Órion",fixedSkills:["FORTITUDE","LUTA"],variableSkillCount:0,professionRequired:!1,powerName:"O Tanque"},{code:"MOCHILEIRO_ORIGEM",label:"Mochileiro",source:"Suplemento Órion",fixedSkills:["DIPLOMACIA","SOBREVIVENCIA"],variableSkillCount:0,professionRequired:!1,powerName:"Bom Mochileiro"},{code:"PLAYER",label:"Player",source:"Suplemento Órion",fixedSkills:["REFLEXOS","TECNOLOGIA"],variableSkillCount:0,professionRequired:!1,powerName:"Easter Egg"},{code:"PROFETA",label:"Profeta",source:"Suplemento Órion",fixedSkills:["INTUICAO","RELIGIAO"],variableSkillCount:0,professionRequired:!1,powerName:"Voz do Além"},{code:"REVOLUCIONARIO",label:"Revolucionário",source:"Suplemento Órion",fixedSkills:["DIPLOMACIA","INTIMIDACAO"],variableSkillCount:0,professionRequired:!1,powerName:"Contra à Opressão"},{code:"VETERINARIO",label:"Veterinário",source:"Suplemento Órion",fixedSkills:["ADESTRAMENTO","MEDICINA"],variableSkillCount:0,professionRequired:!1,powerName:"Animalis"},{code:"BODYBUILDER",label:"Bodybuilder",source:"Suplemento Órion",fixedSkills:["ATLETISMO","FORTITUDE"],variableSkillCount:0,professionRequired:!1,powerName:"Saindo da Jaula"},{code:"BLASTER",label:"Blaster",source:"Suplemento Órion",fixedSkills:["CIENCIAS","PROFISSAO"],variableSkillCount:0,professionRequired:!0,powerName:"Explosão Solidária"},{code:"PERSONAL_TRAINER",label:"Personal Trainer",source:"Suplemento Órion",fixedSkills:["ATLETISMO","CIENCIAS"],variableSkillCount:0,professionRequired:!1,powerName:"Todo Mundo Pagando 10"},{code:"EXORCIZADO",label:"Exorcizado",source:"Arquivos Secretos #7",fixedSkills:["FORTITUDE","OCULTISMO"],variableSkillCount:0,professionRequired:!1,powerName:"O Que Restou"},{code:"SENSITIVO_REBELDE",label:"Sensitivo Rebelde",source:"Arquivos Secretos #7",fixedSkills:["INTUICAO","VONTADE"],variableSkillCount:0,professionRequired:!1,powerName:"Sussurros e Vultos"}].map(i=>Object.freeze({...i,fixedSkills:Object.freeze(i.fixedSkills)}))),Ff=Object.freeze([{code:"ACROBACIA",label:"Acrobacia",attribute:"AGI",trainedOnly:!1,usesKit:!1},{code:"ADESTRAMENTO",label:"Adestramento",attribute:"PRE",trainedOnly:!0,usesKit:!1},{code:"ARTES",label:"Artes",attribute:"PRE",trainedOnly:!0,usesKit:!1},{code:"ATLETISMO",label:"Atletismo",attribute:"FOR",trainedOnly:!1,usesKit:!1},{code:"ATUALIDADES",label:"Atualidades",attribute:"INT",trainedOnly:!1,usesKit:!1},{code:"CIENCIAS",label:"Ciências",attribute:"INT",trainedOnly:!0,usesKit:!1},{code:"CRIME",label:"Crime",attribute:"AGI",trainedOnly:!0,usesKit:!0},{code:"DIPLOMACIA",label:"Diplomacia",attribute:"PRE",trainedOnly:!1,usesKit:!1},{code:"ENGANACAO",label:"Enganação",attribute:"PRE",trainedOnly:!1,usesKit:!0},{code:"FORTITUDE",label:"Fortitude",attribute:"VIG",trainedOnly:!1,usesKit:!1},{code:"FURTIVIDADE",label:"Furtividade",attribute:"AGI",trainedOnly:!1,usesKit:!1},{code:"INICIATIVA",label:"Iniciativa",attribute:"AGI",trainedOnly:!1,usesKit:!1},{code:"INTIMIDACAO",label:"Intimidação",attribute:"PRE",trainedOnly:!1,usesKit:!1},{code:"INTUICAO",label:"Intuição",attribute:"PRE",trainedOnly:!1,usesKit:!1},{code:"INVESTIGACAO",label:"Investigação",attribute:"INT",trainedOnly:!1,usesKit:!1},{code:"LUTA",label:"Luta",attribute:"FOR",trainedOnly:!1,usesKit:!1},{code:"MEDICINA",label:"Medicina",attribute:"INT",trainedOnly:!1,usesKit:!0},{code:"OCULTISMO",label:"Ocultismo",attribute:"INT",trainedOnly:!0,usesKit:!1},{code:"PERCEPCAO",label:"Percepção",attribute:"PRE",trainedOnly:!1,usesKit:!1},{code:"PILOTAGEM",label:"Pilotagem",attribute:"AGI",trainedOnly:!0,usesKit:!1},{code:"PONTARIA",label:"Pontaria",attribute:"AGI",trainedOnly:!1,usesKit:!1},{code:"PROFISSAO",label:"Profissão",attribute:"INT",trainedOnly:!0,usesKit:!1},{code:"REFLEXOS",label:"Reflexos",attribute:"AGI",trainedOnly:!1,usesKit:!1},{code:"RELIGIAO",label:"Religião",attribute:"PRE",trainedOnly:!0,usesKit:!1},{code:"SOBREVIVENCIA",label:"Sobrevivência",attribute:"INT",trainedOnly:!1,usesKit:!1},{code:"TATICA",label:"Tática",attribute:"INT",trainedOnly:!0,usesKit:!1},{code:"TECNOLOGIA",label:"Tecnologia",attribute:"INT",trainedOnly:!0,usesKit:!0},{code:"VONTADE",label:"Vontade",attribute:"PRE",trainedOnly:!1,usesKit:!1}].map(Object.freeze)),LS=Object.freeze({ACADEMICO:"Você pesquisava documentos antigos na biblioteca de uma universidade.",AGENTE_SAUDE:"Você cuidava de pacientes no plantão noturno de um hospital.",ARTISTA:"Você pintava murais pela cidade para pagar as contas.",ATLETA:"Você treinava todos os dias para disputar o campeonato da sua cidade.",CHEF:"Você comandava a cozinha de um pequeno restaurante de bairro.",CRIMINOSO:"Você abria fechaduras para uma quadrilha de ladrões.",CULTISTA_ARREPENDIDO:"Você abandonou uma seita e tentou reconstruir a vida longe dela.",DESGARRADO:"Você mudava de cidade com uma mochila e aceitava trabalhos temporários.",ENGENHEIRO:"Você projetava máquinas e passava as tardes entre ferramentas e plantas.",EXECUTIVO:"Você negociava contratos e resolvia problemas de uma grande empresa.",INVESTIGADOR:"Você procurava pessoas desaparecidas num pequeno escritório de detetive.",LUTADOR:"Você dava aulas de luta numa academia e competia nos fins de semana.",MAGNATA:"Você administrava os negócios da família e frequentava eventos exclusivos.",MERCENARIO:"Você aceitava trabalhos perigosos para quem pudesse pagar.",MILITAR:"Você servia numa unidade militar e participava dos treinamentos de campo.",OPERARIO:"Você consertava equipamentos durante o turno de uma fábrica.",POLICIAL:"Você atendia ocorrências e fazia patrulhas nas ruas do seu bairro.",RELIGIOSO:"Você acolhia os moradores de uma pequena comunidade religiosa.",SERVIDOR_PUBLICO:"Você atendia o público e organizava documentos numa repartição.",TEORICO_CONSPIRACAO:"Você reunia recortes de jornal sobre casos que ninguém conseguia explicar.",TI:"Você mantinha os computadores de uma empresa funcionando.",TRABALHADOR_RURAL:"Você cuidava da plantação e dos animais numa propriedade do interior.",TRAMBIQUEIRO:"Você vivia de pequenos golpes, sempre inventando uma nova história.",UNIVERSITARIO:"Você dividia os dias entre aulas, estágio e trabalhos da faculdade.",VITIMA:"Você tentava retomar a rotina depois de sobreviver a um acontecimento terrível.",AMIGO_ANIMAIS:"Você resgatava animais de rua e ajudava a encontrar novos lares para eles.",ASTRONAUTA:"Você passou anos treinando para integrar uma missão espacial.",CHEF_OUTRO_LADO:"Você começou a investigar uma receita estranha encontrada no caderno da família.",COLEGIAL:"Você estudava de manhã e passava as tardes com os amigos da escola.",COSPLAYER:"Você costurava fantasias e participava de encontros de fãs.",DIPLOMATA:"Você representava uma instituição em reuniões e negociações delicadas.",EXPLORADOR:"Você participava de expedições para conhecer regiões pouco visitadas.",EXPERIMENTO:"Você escapou de um laboratório e tentou descobrir o que fizeram com você.",FANATICO_CRIATURAS:"Você mantinha um caderno cheio de relatos sobre criaturas misteriosas.",FOTOGRAFO:"Você fotografava festas e eventos para pagar o aluguel.",INVENTOR_PARANORMAL:"Você montava aparelhos para tentar registrar fenômenos inexplicáveis.",JOVEM_MISTICO:"Você lia cartas para os amigos e colecionava histórias sobre o oculto.",LEGISTA_NOTURNO:"Você examinava corpos no turno da noite de um instituto médico-legal.",MATEIRO:"Você guiava viajantes pelas trilhas e matas da região onde cresceu.",MERGULHADOR:"Você trabalhava inspecionando embarcações debaixo d’água.",MOTORISTA:"Você atravessava estradas fazendo entregas entre cidades.",NERD_ENTUSIASTA:"Você organizava encontros para conversar sobre seu assunto favorito.",PSICOLOGO:"Você atendia pessoas num consultório e ouvia suas histórias.",REPORTER_INVESTIGATIVO:"Você seguia denúncias anônimas para escrever reportagens sobre gente poderosa.",ACALENTADOR:"Você acolhia vizinhos que precisavam conversar depois de um dia difícil.",ALFAIATE:"Você ajustava roupas e costurava peças sob medida numa pequena oficina.",APOSTADOR:"Você frequentava mesas de cartas e apostava parte do que ganhava.",ATIRADOR_EXIMIO:"Você treinava tiro esportivo e participava de competições locais.",BOMBADO:"Você passava boa parte do tempo na academia, seguindo uma rotina de treino.",BOTICARIO:"Você preparava remédios e misturas numa pequena botica.",COLECIONADOR:"Você visitava feiras de antiguidades em busca de objetos incomuns.",CRIANCA_AMALDICOADA:"Você cresceu ouvindo a família contar histórias sobre coisas estranhas ao seu redor.",DESOCUPADO:"Você fazia bicos quando precisava e passava o tempo explorando seus interesses.",HERDEIRO:"Você recebeu uma herança de um parente que quase não conhecia.",INVENTOR:"Você desmontava aparelhos velhos para construir suas próprias invenções.",LINHA_FRENTE:"Você trabalhava protegendo pessoas em lugares onde havia perigo.",MOCHILEIRO_ORIGEM:"Você viajava de carona, conhecendo pessoas e dormindo onde conseguia.",PLAYER:"Você jogava com os amigos e participava de pequenos torneios.",PROFETA:"Você anotava sonhos estranhos num caderno que levava a todo lugar.",REVOLUCIONARIO:"Você organizava protestos para mudar uma situação injusta na sua comunidade.",VETERINARIO:"Você atendia animais numa clínica e ajudava um abrigo nos fins de semana.",BODYBUILDER:"Você se preparava para subir ao palco de uma competição de fisiculturismo.",BLASTER:"Você trabalhava com demolições e acompanhava a preparação de explosivos.",PERSONAL_TRAINER:"Você montava treinos e acompanhava os alunos de uma academia.",EXORCIZADO:"Você tentou retomar a rotina depois de passar por um exorcismo.",SENSITIVO_REBELDE:"Você escondia suas percepções estranhas de uma família que não acreditava."});function Sc(i){return LS[i.code]??""}const Ms=Object.freeze([{id:"investigar",label:"Investigar",prompt:"Quero descobrir o que está escondido.",skills:["INVESTIGACAO","PERCEPCAO","CIENCIAS","ATUALIDADES"]},{id:"cuidar",label:"Cuidar",prompt:"Quero cuidar de pessoas ou animais.",skills:["MEDICINA","ADESTRAMENTO","INTUICAO"]},{id:"criar",label:"Criar e consertar",prompt:"Quero criar, consertar ou entender máquinas.",skills:["TECNOLOGIA","PROFISSAO","ARTES"]},{id:"convencer",label:"Convencer",prompt:"Quero lidar com pessoas e influenciar decisões.",skills:["DIPLOMACIA","ENGANACAO","INTIMIDACAO"]},{id:"sobreviver",label:"Sobreviver",prompt:"Quero explorar e me virar em lugares difíceis.",skills:["SOBREVIVENCIA","FORTITUDE","PILOTAGEM"]},{id:"agir",label:"Agir sob pressão",prompt:"Quero uma história ligada à ação e ao esforço físico.",skills:["LUTA","PONTARIA","ATLETISMO","REFLEXOS","INICIATIVA"]},{id:"paranormal",label:"Paranormal",prompt:"Quero um passado próximo do inexplicável.",skills:["OCULTISMO","RELIGIAO"]},{id:"discricao",label:"Agir com discrição",prompt:"Quero alguém que saiba agir sem chamar atenção.",skills:["CRIME","FURTIVIDADE"]}].map(i=>Object.freeze({...i,skills:Object.freeze(i.skills)}))),DS={ACADEMICO:"Uma vida entre estudos, perguntas e conhecimento. Nem toda resposta estava nos livros.",AGENTE_SAUDE:"Cuidar de pessoas fazia parte da sua rotina, muito antes do inexplicável.",ARTISTA:"Você encontrava na arte uma forma de dizer o que palavras comuns não alcançavam.",ATLETA:"Treino, disciplina e movimento marcaram sua vida.",CHEF:"Sua história passava pela cozinha, pelos sabores e pelas pessoas ao redor da mesa.",CRIMINOSO:"Você conheceu caminhos que as pessoas preferem não mencionar.",CULTISTA_ARREPENDIDO:"Seu passado se aproximou de uma crença que você decidiu abandonar.",DESGARRADO:"Você aprendeu a seguir em frente mesmo sem um lugar ao qual pertencer.",ENGENHEIRO:"Entender como as coisas funcionam sempre foi parte da sua maneira de ver o mundo.",EXECUTIVO:"Decisões, negociações e responsabilidades preenchiam seus dias.",INVESTIGADOR:"Você aprendeu a procurar pistas onde outras pessoas só viam detalhes.",LUTADOR:"Seu corpo, seu treino e sua determinação contam parte da sua história.",MAGNATA:"Dinheiro, influência e os círculos que os acompanham fizeram parte da sua vida.",MERCENARIO:"Você já esteve em situações perigosas em troca de pagamento.",MILITAR:"Disciplina e treinamento militar deixaram marcas no seu passado.",OPERARIO:"Seu conhecimento nasceu do trabalho e da prática cotidiana.",POLICIAL:"Sua rotina envolvia ocorrências, investigação e a vida nas ruas.",RELIGIOSO:"A fé foi uma presença importante na sua trajetória.",SERVIDOR_PUBLICO:"Você conheceu o trabalho diário de atender pessoas e fazer instituições funcionarem.",TEORICO_CONSPIRACAO:"Você suspeitava que havia algo por trás das versões oficiais.",TI:"Computadores, sistemas e informação faziam parte do seu cotidiano.",TRABALHADOR_RURAL:"Sua vida estava ligada à terra, aos animais e aos ritmos do campo.",TRAMBIQUEIRO:"Você aprendeu a sair de situações difíceis com conversa e esperteza.",UNIVERSITARIO:"Estudos, descobertas e uma vida ainda em construção compunham sua rotina.",VITIMA:"Algo que você viveu deixou marcas. Sua história continua para além delas.",AMIGO_ANIMAIS:"Sua relação com os animais sempre teve um lugar especial na sua vida.",ASTRONAUTA:"Você construiu uma trajetória ligada ao espaço e aos seus desafios.",CHEF_OUTRO_LADO:"A cozinha e o inexplicável se encontram na ideia desse passado.",COLEGIAL:"Sua história começou entre aulas, amizades e descobertas da vida escolar.",COSPLAYER:"Criar e interpretar outras figuras era uma forma de expressão para você.",DIPLOMATA:"Sua experiência passava por diálogo, negociações e relações entre pessoas.",EXPLORADOR:"Lugares desconhecidos e a vontade de descobrir marcaram sua trajetória.",EXPERIMENTO:"Uma experiência incomum faz parte da história que você quer contar.",FANATICO_CRIATURAS:"O interesse por criaturas e pelo desconhecido ocupava seus pensamentos.",FOTOGRAFO:"Você aprendeu a perceber o mundo por meio de enquadramentos e imagens.",INVENTOR_PARANORMAL:"Criar coisas e se aproximar do inexplicável se cruzam no seu passado.",JOVEM_MISTICO:"Crenças e sinais incomuns acompanharam suas primeiras descobertas.",LEGISTA_NOTURNO:"Seu trabalho passava por perguntas que os mortos deixavam para os vivos.",MATEIRO:"Você se acostumou a observar caminhos, rastros e a vida fora das cidades.",MERGULHADOR:"Seu passado está ligado às profundezas e à experiência de mergulhar.",MOTORISTA:"Estradas, trajetos e o tempo ao volante fizeram parte da sua rotina.",NERD_ENTUSIASTA:"Seus interesses renderam horas de estudo, curiosidade e dedicação.",PSICOLOGO:"Ouvir pessoas e buscar compreender suas experiências marcou sua vida.",REPORTER_INVESTIGATIVO:"Você buscava histórias, fontes e os fatos por trás das aparências.",ACALENTADOR:"Acolher pessoas e estar presente para elas era parte da sua história.",ALFAIATE:"Seu trabalho transformava tecido, medidas e ideias em vestimentas.",APOSTADOR:"Jogos, apostas e decisões arriscadas atravessaram seu passado.",ATIRADOR_EXIMIO:"Precisão e treinamento de tiro fazem parte da história que você quer contar.",BOMBADO:"A dedicação ao treino físico deixou marcas na sua rotina.",BOTICARIO:"Preparos, ingredientes e cuidados faziam parte do seu conhecimento.",COLECIONADOR:"Você reunia objetos e histórias que tinham um significado particular.",CRIANCA_AMALDICOADA:"Um passado de infância atravessado pelo inexplicável compõe essa ideia de história.",DESOCUPADO:"Sua trajetória não cabe facilmente em uma profissão ou rotina definida.",HERDEIRO:"O que veio antes de você deixou uma herança na sua história.",INVENTOR:"Você procurava soluções e gostava de transformar ideias em coisas.",LINHA_FRENTE:"Estar perto do perigo faz parte da história que você quer contar.",MOCHILEIRO_ORIGEM:"Viagens, encontros e caminhos abertos marcaram sua vida.",PLAYER:"Jogos e suas descobertas fazem parte dos seus interesses.",PROFETA:"Sua história se aproxima da fé e de sinais difíceis de explicar.",REVOLUCIONARIO:"Mudar a realidade ao seu redor era uma motivação importante para você.",VETERINARIO:"Cuidar da saúde dos animais fazia parte da sua vida.",BODYBUILDER:"Construir o próprio corpo era um projeto feito de rotina e dedicação.",BLASTER:"Seu interesse por explosivos faz parte da ideia desse passado.",PERSONAL_TRAINER:"Você ajudava outras pessoas a desenvolver o corpo por meio do treino.",EXORCIZADO:"Um exorcismo atravessa a história que você quer contar.",SENSITIVO_REBELDE:"Percepções incomuns e uma postura de questionamento atravessam essa ideia de passado."},NS={AGENTE_SAUDE:"médico médica enfermeiro enfermeira hospital",TI:"computador informática hacker programador programação",RELIGIOSO:"padre pastor freira igreja",OPERARIO:"fábrica construção trabalhador",INVESTIGADOR:"detetive pistas mistério",TRABALHADOR_RURAL:"fazenda campo agricultor",ACALENTADOR:"acolhimento apoio",VETERINARIO:"bicho pet animal",BOTICARIO:"remédio farmácia",PERSONAL_TRAINER:"academia exercício"};function mh(i){return String(i??"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLocaleLowerCase("pt-BR").replace(/[^a-z0-9]+/g," ").trim()}function Qa(i){return Ff.find(e=>e.code===i)?.label??i}function Bf(i){return DS[i.code]??"Escolha esta origem para explorar uma possibilidade para o seu passado."}function OS(i){return Ms.filter(e=>i.fixedSkills.some(t=>e.skills.includes(t)))}function gh({query:i="",interest:e="",source:t="",skill:n=""}={}){const r=mh(i).split(" ").filter(Boolean);return Mi.filter(s=>{const a=mh([s.label,s.powerName,s.source,Bf(s),Sc(s),NS[s.code]??"",...s.fixedSkills.map(Qa)].join(" "));return(!t||s.source===t)&&(!n||s.fixedSkills.includes(n))&&(!e||OS(s).some(o=>o.id===e))&&r.every(o=>a.includes(o))}).sort((s,a)=>s.label.localeCompare(a.label,"pt-BR"))}const pe=i=>`<path d="${i}"/>`,Xe=(i,e,t)=>`<circle cx="${i}" cy="${e}" r="${t}"/>`,vh=(i,e,t,n)=>`<ellipse cx="${i}" cy="${e}" rx="${t}" ry="${n}"/>`,_h=pe("M7 12q9-5 17 1 8-6 17-1v25q-9-4-17 1-8-5-17-1ZM24 13v25M11 18l8 1m-8 5 8 1m10-6 8-1m-8 7 8-1"),US=pe("M21 17h6v7h7v6h-7v7h-6v-7h-7v-6h7Z"),FS=Xe(16,16,3)+Xe(24,12,3)+Xe(32,16,3)+pe("M24 21c-5 0-7 6-10 9-4 6 1 10 6 7 3-2 5-2 8 0 5 3 10-1 6-7-3-3-5-9-10-9Z"),BS=pe("M24 34 12 22c-9-10 7-18 12-8 5-10 21-2 12 8Z"),xh=pe("M18 32v-4c-10-8-5-22 6-22s16 14 6 22v4ZM18 36h12m-10 5h8M24 4V1M9 12l-4-3m34 3 4-3"),kS=pe("M7 15q17 6 34 0v8c0 13-17 19-17 19S7 36 7 23ZM13 24q4-5 8 0m6 0q4-5 8 0M19 32q5 4 10 0"),yh=pe("M14 15v-4q0-4 4-4h12q4 0 4 4v4M7 16h34v25H7ZM18 7v8m12-8v8"),zS=Xe(24,24,17)+pe("m29 14-2 13-13 7 7-13ZM24 4v5m0 30v5M4 24h5m30 0h5"),bl=pe("M24 5q-8 6-17 6v12c0 11 17 20 17 20s17-9 17-20V11q-9 0-17-6Z"),bh=pe("M12 26c-13-3-8-20 4-15 2-11 17-11 19 0 12-4 16 12 2 15v13H12ZM12 33h25"),Sh=pe("M13 18q-1-10 11-10t11 10l3 22H10ZM18 9V5h12v4M14 25h20v11H14Zm4-7h12m-20 5-5 4v12h5m28-16 5 4v12h-5"),Mh=pe("M4 24q20-22 40 0-20 22-40 0Z")+Xe(24,24,7)+Xe(24,24,2),VS=Object.freeze({ACADEMICO:_h+pe("M31 9V4h6v9l-3-2Z"),AGENTE_SAUDE:yh+US,ARTISTA:pe("M24 6C3 6 1 34 15 39c8 3 6-6 12-7 8-2 13 7 17-4C49 15 36 6 24 6Z")+Xe(14,19,2)+Xe(20,13,2)+Xe(29,13,2)+Xe(36,19,2)+pe("m14 42 15-22 4 3-15 21Z"),ATLETA:pe("M6 31c5-1 8-10 11-20l8 3-1 9 9 4 9 3v9H6ZM7 35h34M21 22l5 4m-9-1 5 4m7-3 4 4"),CHEF:bh+pe("M18 30v-5m7 5v-5m6 5v-5"),CRIMINOSO:pe("M5 17q19-9 38 0l-3 13q-8 4-16-2-8 6-16 2ZM10 21q5-4 10 0-4 8-10 0Zm18 0q5-4 10 0-4 8-10 0ZM20 36h8m-5-4v8"),CULTISTA_ARREPENDIDO:Xe(24,24,17)+pe("m24 9 9 27-23-17h28L15 36ZM7 41 41 7M18 5l3 6m17 29-4-5"),DESGARRADO:pe("M8 39h32M24 36V18m0 7L12 13m12 8 9-15M5 12l7-2 4 6m14-9 7-2 2 8M8 42l4-6m22 6-4-6")+Xe(24,12,4),ENGENHEIRO:pe("M9 38 29 18c-5-10 4-17 13-13l-8 7 3 6 8-7c4 9-5 17-13 12L14 43Z")+Xe(11,38,2)+pe("M6 9h13M12 3v13m-6 8 6-6"),EXECUTIVO:yh+pe("M7 25q17 8 34 0M20 25h8v7h-8ZM30 10l6-5 5 4"),INVESTIGADOR:Xe(20,19,12)+pe("m29 28 14 14-4 4-14-14M13 16q4-5 10-4")+Xe(18,22,1),LUTADOR:pe("M15 38 8 27q-3-6 2-8l4 5V11q1-5 5-2v13-15q3-4 6 0v15-13q3-4 6 0v15-9q3-3 6 0v13l-7 10v6H15ZM15 34l20-4M16 39h14m-12 3h12"),MAGNATA:pe("m24 5 12 10-12 12-12-12ZM12 15h24M24 5l-5 10 5 12 5-12ZM12 27c-9 20 33 20 24 0M9 34h30"),MERCENARIO:pe("M14 7h19l6 6v24l-6 6H14V7Zm5 0v-4m8 0v4M19 16h12m-12 6h12m-12 6h7M8 35l32-28m-6 0 6 0v6"),MILITAR:pe("m24 5 7 13 14 2-10 10 2 14-13-7-13 7 2-14L3 20l14-2ZM15 25l9-6 9 6m-18 6 9-6 9 6"),OPERARIO:pe("m7 8 10-3 9 9-5 5-9-9-5 3ZM17 17l24 24-5 5-24-24M38 5c-9-3-15 5-11 12L7 37l4 4 21-20c8 3 16-6 12-13l-7 7-4-4Z"),POLICIAL:bl+pe("m24 13 3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1Z"),RELIGIOSO:pe("M18 23h12v19H18Zm6-3c-10-6 5-12 0-19 11 8 7 15 0 19ZM12 43h24M11 14l-6-2m32 2 6-2M14 6l-3-4m23 4 3-4"),SERVIDOR_PUBLICO:pe("m5 16 19-11 19 11ZM8 19h32M10 19v19m9-19v19m10-19v19m9-19v19M6 39h36v5H6Z")+Xe(24,11,1),TEORICO_CONSPIRACAO:pe("M6 7h36v34H6ZM11 13l7 5 13-4 6 13-16 8-10-10 7-7m3 17 10-21M11 25l26 2")+Xe(18,18,3)+Xe(31,14,2)+Xe(21,35,2),TI:pe("M8 7h32v26H8ZM4 39h40l-3 4H7ZM14 15l6 5-6 5m10 0h9M18 37h12"),TRABALHADOR_RURAL:pe("M24 43V18M24 28C7 32 4 20 4 20s17-3 20 8Zm0-10C39 21 43 9 43 9S27 6 24 18ZM8 43h32M11 5l-5 7 9 3"),TRAMBIQUEIRO:pe("m5 13 22-7 11 30-22 7ZM19 9l15-3 8 31-5 1M11 19l4-1m7 18 4-1")+pe("m20 18-4 9 9-3Z"),UNIVERSITARIO:pe("m3 17 21-11 21 11-21 11ZM12 22v13q12 9 24 0V22M43 19v19m-3 0h6M18 41h12"),VITIMA:bl+pe("m25 8-8 12 12 7-9 15M17 22l5-5m-1 12 6-6m-8 12 7-5"),AMIGO_ANIMAIS:FS+pe("M7 7c-5-7 7-9 8-3 1-6 13-4 8 3l-8 8Z"),ASTRONAUTA:pe("M9 28V21c0-22 30-22 30 0v7M8 27h32v14H8ZM13 20q11-8 22 0v11H13ZM16 41v4h16v-4M17 15l8-3")+Xe(13,36,1)+Xe(35,36,1),CHEF_OUTRO_LADO:bh+pe("m24 17 2 5 5 1-4 3 1 5-4-3-4 3 1-5-4-3 5-1ZM8 30c-10-2-7 13-1 10m34-10c9-2 7 13 0 10"),COLEGIAL:Sh+pe("m19 28 4 4 7-6M20 17h8"),COSPLAYER:kS+pe("m8 5 2 5 5 2-5 2-2 5-2-5-5-2 5-2ZM37 5v7m-4-3h8"),DIPLOMATA:pe("M4 22 12 12l9 5 7-3 16 10-9 14-14-3-7-7-5 1ZM18 18l-6 8 6 5 8-9 12 10m-20 3 7-9m-1 11 7-8M4 22l6 5m28-10 5 5"),EXPLORADOR:zS+pe("m16 35 8-5 9 5M21 10h6"),EXPERIMENTO:pe("M18 4h12m-10 0v14L8 38q-2 6 4 6h24q6 0 4-6L28 18V4M14 30h20M20 14l8 5m-12 5 15 4")+Xe(21,35,2)+Xe(29,38,1),FANATICO_CRIATURAS:_h+pe("M16 12 11 3l11 8m9 1 6-9-1 10M17 25l4 3m7 0 4-3"),FOTOGRAFO:pe("M5 15h10l4-7h12l4 7h8v26H5ZM8 20h6m22 0h3")+Xe(25,28,9)+Xe(25,28,5),INVENTOR_PARANORMAL:xh+pe("m24 12 3 7 7 1-6 4 2 7-6-4-6 4 2-7-6-4 7-1Z"),JOVEM_MISTICO:pe("m9 22 7-11 7 11-7 21ZM9 22h14M16 11v32m10-18 6-7 6 7-6 16ZM26 25h12M33 4c-11 3-8 15 2 15-6-5-6-10-2-15Z"),LEGISTA_NOTURNO:pe("M12 23C2 0 46 0 36 23l-5 5v11H17V28ZM17 34h14m-10-6v11m6-11v11M20 18h-6v6h6Zm8 0h6v6h-6ZM22 27l2-5 2 5M7 42h34"),MATEIRO:pe("M11 32C5 12 25 7 39 6 39 27 30 38 11 32ZM10 39 33 13M17 31v-9m7 3 9-2m-10-4v-7M5 43h8m13-3 6-4m7 6h5"),MERGULHADOR:pe("M4 20h40v14H31l-7-5-7 5H4ZM8 24h10v6H8Zm22 0h10v6H30ZM41 18V6h-7v9m10-9v22M17 40q7 5 14 0")+Xe(10,11,2),MOTORISTA:Xe(24,24,19)+Xe(24,24,14)+Xe(24,24,4)+pe("M6 19l15 4m6 0 15-4M24 28v14M11 16q13-7 26 0"),NERD_ENTUSIASTA:pe("M4 18h17v11H6Zm23 0h17l-2 11H27ZM21 22h6M4 18l3-6m37 6-3-6M12 38l12-5 12 5-12 7Z")+Xe(24,39,1),PSICOLOGO:pe("M17 42v-9c-10-7-9-24 3-27 16-5 23 9 19 17l5 6h-7v8H27v5M19 14c-7-5-12 4-6 8m6-8c8-8 16 2 9 7m-8-7v13m-5-7c-5 5 2 11 5 7m0-6c8-5 14 5 6 8"),REPORTER_INVESTIGATIVO:pe("M7 8h24v34H7ZM12 14h13m-13 6h10m-10 6h13m-13 6h8M37 6c-8 0-8 13 0 13s8-13 0-13ZM37 19v15m-7-17v5q7 9 14 0v-5m-12 17h10"),ACALENTADOR:BS+pe("M4 31l8 7 12 5 12-5 8-7M5 31l5-6 10 9m23-3-5-6-10 9"),ALFAIATE:Xe(12,34,6)+Xe(34,34,6)+pe("m16 30 19-25 2 4-14 20L13 5l-2 4 20 21M23 25l-3 5")+Xe(23,25,1),APOSTADOR:pe("m7 14 22-7 11 28-22 7ZM8 14l14 8 18-1M22 22l-4 20m4-20 7-15")+Xe(15,21,1)+Xe(22,34,1)+Xe(32,28,1)+Xe(34,33,1),ATIRADOR_EXIMIO:Xe(24,24,14)+Xe(24,24,7)+pe("M24 2v15m0 14v15M2 24h15m14 0h15M9 5l5 5m20 28 5 5"),BOMBADO:pe("M8 36c3-6 8-6 13-5l-3-8-8-3 2-8 9-5 7 5-2 6-6-1 9 13c10-5 17 2 13 9-8 8-28 6-34-3ZM19 12l7 2m3 16-7 3M10 40l3-6"),BOTICARIO:pe("M8 26h32q-1 15-16 15T8 26ZM16 41h16v4H16ZM25 25l9-19 6 3-9 16M10 17C6 6 16 5 21 4c2 9-2 16-11 13Zm1-1 6-6"),COLECIONADOR:pe("M5 7h38v36H5ZM5 27h38M11 11h8v12h-8ZM26 10h6v4l4 3v6H22v-6l4-3ZM12 32h8v8h-8Zm16 0h9v8h-9Z"),CRIANCA_AMALDICOADA:Xe(13,11,5)+Xe(35,11,5)+vh(24,20,13,12)+vh(24,37,11,8)+pe("M18 18l5 5m0-5-5 5M29 19h3M21 27h6M9 33l7 4m16 0 7-4M24 32v11"),DESOCUPADO:pe("M11 23V12q13-8 26 0v11M6 24q5-6 10 0v10h16V24q5-6 10 0v18H6ZM12 42v3m24-3v3M17 18h14M2 10h5m-3-5 3 2"),HERDEIRO:pe("m9 9 8 7 7-13 7 13 8-7-4 17H13ZM15 21h18M24 30v15m0-5h8m-8 5h5")+Xe(24,31,5),INVENTOR:xh+pe("M20 17h8v9h-8ZM24 13v4m0 9v5m-8-10h4m8 0h5"),LINHA_FRENTE:bl+pe("M9 20h30M8 28h32M17 13v7m14-7v7M24 20v8m-8 0v8m16-8v8"),MOCHILEIRO_ORIGEM:Sh+pe("m16 33 7-11 9 11ZM7 8l-3-4m35 4 5-4"),PLAYER:pe("M12 14h24c8 1 13 25 6 26-5 1-8-8-13-8H19c-5 0-8 9-13 8-7-1-2-25 6-26ZM16 18v12m-6-6h12M24 14V7h8")+Xe(33,21,2)+Xe(38,27,2),PROFETA:Mh+pe("M24 2v5m-13 0 3 5m23-5-3 5M24 41v5m-13-5 3-5m23 5-3-5"),REVOLUCIONARIO:pe("M10 45V4m0 2c10-8 19 10 30 2v20c-11 8-20-10-30-2M18 13l5 5 9-5M5 45h10"),VETERINARIO:Xe(24,29,6)+pe("M24 35v3c0 10 18 10 18-3V19M7 5v11c0 14 19 14 19 0V5M4 5h7m12 0h7")+Xe(41,15,4)+pe("M22 29h4m-2-2v4"),BODYBUILDER:pe("M17 24h14M7 13h5v22H7ZM12 9h6v30h-6ZM30 9h6v30h-6Zm6 4h5v22h-5M5 24H2m39 0h5M15 43l9 3 9-3M20 3h8"),BLASTER:pe("M8 16h10v26H8Zm11 0h10v26H19Zm11 0h10v26H30ZM8 25h32m-32 9h32M24 16V9q0-8 10-6m0 0 3 5m-3-5 5-1m-5 1-2-3"),PERSONAL_TRAINER:Xe(24,26,16)+pe("M19 4h10v6H19ZM24 14v12l8 5M9 10l4 4m22 0 4-4M8 42l-4 3m36-3 4 3"),EXORCIZADO:pe("M16 8C-1 18 7 42 23 42m9-3C48 29 40 8 28 7M22 4l-3 9 7-2-4 9M20 26h8v14h-8ZM24 23c-6-5 4-8 0-13 8 7 5 10 0 13Z"),SENSITIVO_REBELDE:Mh+pe("m27 2-9 16 10-2-8 13 9-2-7 18M7 8l5 4m24 24 5 4")});function Oa(i){const e=VS[i];if(!e)throw new Error("Missing origin pictogram: "+i);return`<svg class="origin-icon" data-origin-icon="${i}" viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${e}</svg>`}const sn=Object.freeze([{code:"COMBATENTE",label:"Combatente",atlas:0,theme:"Confronto e proteção",summary:"Treinamento para enfrentar ameaças de forma direta.",strengths:["Mais Pontos de Vida na base.","Treinamento voltado a armas e confronto."],limits:["Menos escolhas livres de perícias na base.","Menos Esforço e Sanidade na base."],example:"Você era segurança e passou a treinar para enfrentar as ameaças que antes tentava conter.",base:{pv:20,pe:2,san:12,freeSkills:1}},{code:"ESPECIALISTA",label:"Especialista",atlas:1,theme:"Perícias e soluções",summary:"Versatilidade para investigar e resolver problemas com técnica.",strengths:["Mais perícias livres na base.","Versatilidade em tarefas especializadas."],limits:["Base de Vida abaixo do Combatente.","Base de Esforço abaixo do Ocultista."],example:"Você era técnico de manutenção e usava seu conhecimento para investigar casos estranhos.",base:{pv:16,pe:3,san:16,freeSkills:7}},{code:"OCULTISTA",label:"Ocultista",atlas:2,theme:"Rituais e paranormal",summary:"Estudo e uso do paranormal por meio de rituais.",strengths:["Mais Esforço e Sanidade na base.","Acesso a rituais pela classe."],limits:["Menor base de Pontos de Vida.","Rituais exigem gerenciar custos e condições."],example:"Você era pesquisador e começou a estudar rituais ao encontrar registros do Outro Lado.",base:{pv:12,pe:4,san:20,freeSkills:3}}].map(i=>Object.freeze({...i,base:Object.freeze(i.base),strengths:Object.freeze(i.strengths),limits:Object.freeze(i.limits)})));function tu(i){return sn.find(e=>e.code===i)??null}function Eh(i){return(i%sn.length+sn.length)%sn.length}function Th(i,e,t){const n=(i*120-e)*Math.PI/180,r=(Math.cos(n)+1)/2;return{x:Math.sin(n)*t,y:-30*(1-r),scale:.62+.38*r,z:Math.round(r*100)}}function HS(i,e){const t=tu(e);return!t||!i?.origin?.code||typeof i.name!="string"||!i.name.trim()?null:{...i,step:"class",classCode:t.code}}function Mc(i,e){let t=null,n=-1/0;const r=c=>{c.isPrimary&&(c.pointerType==="touch"||c.pointerType==="pen")&&!i.disabled&&(t={id:c.pointerId,x:c.clientX,y:c.clientY})},s=c=>{t&&c.pointerId===t.id&&Math.hypot(c.clientX-t.x,c.clientY-t.y)>10&&(t=null)},a=()=>{t=null},o=c=>{const d=t;t=null,!(!d||c.pointerId!==d.id||i.disabled||Math.hypot(c.clientX-d.x,c.clientY-d.y)>10)&&i.contains(document.elementFromPoint(c.clientX,c.clientY))&&(n=performance.now(),e(c))},l=c=>{if(c.detail>0&&c.pointerType!=="mouse"&&performance.now()-n<700){c.preventDefault();return}e(c)};return i.addEventListener("pointerdown",r),i.addEventListener("pointermove",s),i.addEventListener("pointerup",o),i.addEventListener("pointercancel",a),i.addEventListener("click",l),()=>{i.removeEventListener("pointerdown",r),i.removeEventListener("pointermove",s),i.removeEventListener("pointerup",o),i.removeEventListener("pointercancel",a),i.removeEventListener("click",l)}}const GS=["combatente","especialista","ocultista"].map(i=>`/assets/workshop/${i}-v20.png`);let Sl=null;function kf(){return Sl||(Sl=Promise.all(GS.map(i=>{const e=new Image;return e.src=i,e.decode()})).then(()=>!0).catch(()=>!1)),Sl}const Ah=i=>({transform:`translate(-50%,-50%) translate(${i.x}px,${i.y}px) scale(${i.scale})`,zIndex:i.z});function WS(i,{name:e,originLabel:t,classCode:n=null,reducedMotion:r=!1,onConfirm:s=()=>!1,onBack:a=()=>{},onContinue:o=null}){const l={index:Math.max(0,sn.findIndex(T=>T.code===n)),rotation:0,busy:!1,confirmed:tu(n)?.code??null};l.rotation=l.index*120;let c=!1,d=[],u=[],h=null,p=0;i.innerHTML=`<div class="paper-chapter"><span>03 / CLASSE</span></div><h1 id="classPaperTitle" tabindex="-1">Escolha sua classe.</h1><p class="paper-intro">Gire ou use as setas. Confirme a classe que você quer.</p>
  <p class="class-context"><strong class="class-arauto"></strong><span aria-hidden="true"> · </span><span class="class-origin"></span></p>
  <div class="class-layout"><section class="class-picker" aria-label="Roleta de classes" aria-roledescription="carrossel"><div class="class-orbit" tabindex="0" aria-label="Use as setas esquerda e direita para explorar as classes"><div class="roulette-ink-ring" aria-hidden="true"></div><svg class="roulette-inscription" viewBox="0 0 400 400" aria-hidden="true"><defs><path id="classInscriptionPath" d="M200 30a170 170 0 1 1-.1 0"/></defs><text textLength="1000" lengthAdjust="spacing"><textPath href="#classInscriptionPath">Acorrentado pela realidade   Acorrentado pela realidade   Acorrentado pela realidade</textPath></text></svg>${sn.map(T=>`<button type="button" class="roulette-option" data-class-index="${T.atlas}" aria-label="Ver classe ${T.label}" aria-pressed="false"><span class="class-art-layer" aria-hidden="true"><span class="class-silhouette class-silhouette-${T.atlas}"></span></span><span class="roulette-label">${T.label}</span></button>`).join("")}<p class="class-art-loading" role="status">Preparando as silhuetas…</p></div>
   <div class="class-rotation-controls"><button type="button" class="class-previous ink-link" aria-label="Classe anterior">←</button><button type="button" class="class-spin ink-primary">Girar roleta <span aria-hidden="true">↻</span></button><button type="button" class="class-next ink-link" aria-label="Próxima classe">→</button></div>
   <nav class="class-pages" aria-label="Escolher classe em destaque">${sn.map(T=>`<button type="button" data-class-page="${T.atlas}" aria-pressed="false">${T.label}</button>`).join("")}</nav><p class="class-position" aria-live="off"></p>
  </section><section class="class-reading" aria-labelledby="className"><span class="class-theme"></span><h2 id="className"></h2><p class="class-summary"></p><div class="class-tradeoffs"><section><h3>Pontos fortes</h3><ul class="class-strengths"></ul></section><section><h3>Limitações</h3><ul class="class-limits"></ul></section></div><section class="origin-example class-example" aria-label="Exemplo de personagem"><span>Por exemplo…</span><p></p></section>
   <details class="class-comparison"><summary>Comparar as três classes</summary><p>Valores-base da classe. Atributos, origem e outras escolhas alteram o total.</p><div class="class-table-scroll"><table><caption>Bases de recursos e escolhas livres de perícias</caption><thead><tr><th scope="col">Base</th>${sn.map(T=>`<th scope="col">${T.label}</th>`).join("")}</tr></thead><tbody>${[["PV","pv"],["PE","pe"],["SAN","san"],["Perícias livres","freeSkills"]].map(([T,N])=>`<tr><th scope="row">${T}</th>${sn.map(B=>`<td>${B.base[N]}${N==="freeSkills"?" + INT":""}</td>`).join("")}</tr>`).join("")}</tbody></table></div><dl class="class-resource-key"><div><dt>PV</dt><dd>Pontos de Vida</dd></div><div><dt>PE</dt><dd>Pontos de Esforço</dd></div><div><dt>SAN</dt><dd>Sanidade</dd></div></dl><small>Perícias livres não incluem os treinamentos fixos de classe e origem.</small></details>
   <button type="button" class="confirm-class ink-primary">Escolher esta classe <span aria-hidden="true">→</span></button><p class="class-status" role="status" aria-live="polite"></p><button type="button" class="continue-creation ink-primary" hidden>Continuar para atributos <span aria-hidden="true">→</span></button>
  </section></div><footer class="paper-footer class-footer"><button type="button" class="back-to-origins ink-link">← Rever origem</button><span class="paper-page">ÓRION / 03</span></footer>`;const g=T=>i.querySelector(T),v=g(".class-orbit"),m=[...i.querySelectorAll("[data-class-index]")],f=[...i.querySelectorAll("[data-class-page]")],b=[],_=(T,N)=>b.push(Mc(T,N));g(".class-arauto").textContent=e,g(".class-origin").textContent=t;function x(){return Math.min(210,v.clientWidth*.36)}function R(T){m.forEach((N,B)=>Object.assign(N.style,Ah(Th(B,T,x()))))}function M(T=!1){const N=sn[l.index];g(".class-theme").textContent=N.theme,g("#className").textContent=N.label,g(".class-summary").textContent=N.summary;for(const[k,V]of[[".class-strengths",N.strengths],[".class-limits",N.limits]])g(k).replaceChildren(...V.map(O=>{const F=document.createElement("li");return F.textContent=O,F}));g(".class-example p").textContent=N.example,g(".class-position").textContent=`${l.index+1} / 3 · ${N.label}`,m.forEach((k,V)=>{k.setAttribute("aria-pressed",String(V===l.index)),k.classList.toggle("is-front",V===l.index)}),f.forEach((k,V)=>{k.setAttribute("aria-pressed",String(V===l.index)),k.disabled=l.busy});for(const k of[".class-previous",".class-next",".class-spin"])g(k).disabled=l.busy;const B=g(".confirm-class");if(B.disabled=l.busy||l.confirmed===N.code,B.firstChild.textContent=l.confirmed===N.code?"✓ Classe escolhida ":"Escolher esta classe ",i.setAttribute("aria-busy",String(l.busy)),g(".continue-creation").hidden=!o||l.confirmed!==N.code,g(".continue-creation").disabled=l.busy,T&&!r){for(const k of u)k.cancel();u=["#className",".class-summary",".class-tradeoffs",".class-example"].map((k,V)=>g(k).animate([{opacity:0,transform:"translateY(9px)"},{opacity:1,transform:"translateY(0)"}],{duration:280,delay:V*35,easing:"cubic-bezier(.2,.7,.2,1)"}))}}async function A(T,N=!1){if(c||l.busy||!T)return;const B=l.rotation,k=B+T*120;if(l.busy=!0,M(),g(".class-status").textContent=N?"Girando a roleta…":"Mudando a classe em destaque…",!r){const V=N?72:18,D=x();d=m.map((O,F)=>O.animate(Array.from({length:V+1},(z,j)=>{const te=j/V,L=1-(1-te)**3;return{offset:te,...Ah(Th(F,B+(k-B)*L,D))}}),{duration:N?1550:460,easing:"linear",fill:"forwards"})),await Promise.all(d.map(O=>O.finished.catch(()=>{})))}if(!c){l.rotation=k,l.index=Eh(Math.round(k/120)),R(k);for(const V of d)V.cancel();d=[],l.busy=!1,M(!0),g(".class-status").textContent=`${sn[l.index].label} em destaque. Confirme se quiser escolher.`}}_(g(".class-previous"),()=>A(-1)),_(g(".class-next"),()=>A(1)),_(g(".class-spin"),()=>A(6+Math.floor(Math.random()*3),!0));for(const T of[...m,...f])_(T,N=>{if(N.type==="click"&&N.detail>0&&N.pointerType!=="mouse"&&performance.now()<p)return;const B=Number(T.dataset.classIndex??T.dataset.classPage),k=Eh(B-l.index);A(k===2?-1:k)});v.addEventListener("keydown",T=>{(T.key==="ArrowLeft"||T.key==="ArrowRight")&&(T.preventDefault(),A(T.key==="ArrowLeft"?-1:1))}),v.addEventListener("pointerdown",T=>{T.isPrimary&&(T.pointerType==="touch"||T.pointerType==="pen")&&(h={x:T.clientX,y:T.clientY})}),v.addEventListener("pointerup",T=>{if(!h)return;const N=T.clientX-h.x,B=T.clientY-h.y;h=null,Math.abs(N)>45&&Math.abs(N)>Math.abs(B)*1.3&&(p=performance.now()+400,A(N<0?1:-1))}),v.addEventListener("pointercancel",()=>{h=null}),_(g(".confirm-class"),()=>{if(l.busy||l.confirmed===sn[l.index].code)return;const T=sn[l.index];s(T.code)?(l.confirmed=T.code,M(),r||m[l.index].animate([{transform:m[l.index].style.transform,opacity:.7},{opacity:1}],{duration:380,easing:"ease-out"}),g(".class-status").textContent=`${T.label} é a classe de ${e}. Você pode revisar sua escolha.`):g(".class-status").textContent="Não foi possível guardar esta classe. Tente novamente."}),_(g(".back-to-origins"),a),_(g(".continue-creation"),()=>{l.confirmed===sn[l.index].code&&o?.()});const w=T=>{if(r||T.pointerType!=="mouse")return;const N=v.getBoundingClientRect();v.style.setProperty("--class-look-x",`${((T.clientX-N.x)/N.width-.5)*5}px`),v.style.setProperty("--class-look-y",`${((T.clientY-N.y)/N.height-.5)*3}px`)},S=()=>{v.style.setProperty("--class-look-x","0px"),v.style.setProperty("--class-look-y","0px")};v.addEventListener("pointermove",w),v.addEventListener("pointerleave",S);const y=new ResizeObserver(()=>{l.busy||R(l.rotation)});return y.observe(v),i.dataset.classMotion=r?"reduced":"full",M(!0),R(l.rotation),kf().then(T=>{c||(i.dataset.classArt=T?"ready":"error",g(".class-art-loading").textContent=T?"":"As silhuetas não carregaram. As descrições continuam disponíveis.",g(".class-art-loading").hidden=T)}),{get state(){return{...l}},dispose(){c=!0,y.disconnect();for(const T of b)T();for(const T of[...d,...u])T.cancel();i.replaceChildren()}}}const XS="/assets/workshop/walnut-v15.png",En=i=>String(i??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),qS=i=>i.fixedSkills.map(Qa).join(" · "),YS={investigar:"INVESTIGADOR",cuidar:"AGENTE_SAUDE",criar:"INVENTOR",convencer:"DIPLOMATA",sobreviver:"EXPLORADOR",agir:"LUTADOR",paranormal:"JOVEM_MISTICO",discricao:"CRIMINOSO"};let Er=null,Ml=null;function zf(){if(!Ml){const i=new Image;i.src=XS,Ml=i.decode().catch(()=>{})}return Ml}function jS(i,{onReturn:e=()=>{},onChoose:t=()=>{},reducedMotion:n=!1,resume:r=!1}={}){if(Er)return Er;const s=document.activeElement,a=document.createElement("section"),o={query:"",interest:"",source:"",skill:"",selected:null,compared:[],confirmed:null};let l=tu(i.classCode)?.code??null,c=null,d=null;a.className="paper-workshop",a.setAttribute("aria-label","Ficha de criação: origem"),a.dataset.phase="preparing",a.innerHTML=`<div class="workshop-mist" aria-hidden="true"></div><svg class="workshop-binding" viewBox="0 0 400 400" aria-hidden="true"><defs><path id="workshopBindingPath" d="M200 35a165 165 0 1 1-.1 0"/></defs><text><textPath href="#workshopBindingPath">Acorrentado pela realidade   Acorrentado pela realidade</textPath></text></svg><p class="paper-preparing" role="status">Materializando sua história…</p>
  <div class="workshop-planks" aria-hidden="true">${Array.from({length:6},(L,$)=>`<div class="workshop-plank" style="--plank:${$};--grain:${$*19}%"></div>`).join("")}</div>
  <div class="paper-scroll"><div class="paper-landing"><article class="physical-sheet" aria-labelledby="paperTitle" aria-busy="true">
   <div class="paper-content" inert>
    <header class="paper-header"><div class="paper-imprint"><span>ÓRION</span><small>Ficha do arauto · prévia</small></div><button class="paper-return ink-link" type="button">← Voltar à identidade</button></header>
    <section class="origin-chapter-content">
    <div class="paper-chapter"><span>02 / ORIGEM</span></div>
    <h1 id="paperTitle" tabindex="-1">Toda história deixa marcas.</h1>
    <p class="paper-intro">Escolha o passado do seu arauto.</p>
    <div class="paper-identity"><div><span>Nome do arauto</span><strong class="paper-name"></strong></div><div><span>Origem</span><strong class="paper-chosen-name">Ainda por escrever</strong></div></div>
    <nav class="discovery-modes" aria-label="Como explorar as origens"><button type="button" data-mode="explore" aria-pressed="true">Explorar origens</button><button type="button" data-mode="guide" aria-pressed="false">Me ajude a escolher</button></nav>
    <section class="origin-guide" aria-label="Ajuda para escolher uma origem" hidden><h2>Que passado você imagina?</h2><p>Comece por uma ideia.</p><div>${Ms.map(L=>`<button type="button" data-guide="${L.id}" aria-label="${L.prompt}" aria-pressed="false">${Oa(YS[L.id])}<strong>${L.label}</strong><span class="guide-check" aria-hidden="true">✓</span></button>`).join("")}</div></section>
    <section class="origin-tools" aria-label="Buscar e filtrar origens">
     <div class="paper-search"><label for="originSearch">Encontre uma história</label><div><span aria-hidden="true">⌕</span><input id="originSearch" type="search" placeholder="Nome, profissão ou perícia…" autocomplete="off" aria-controls="originResults"><button class="clear-search ink-link" type="button" aria-label="Limpar busca" hidden>×</button></div></div>
     <div class="interest-filters" role="group" aria-label="Filtrar por interesse"><button type="button" data-interest="" aria-pressed="true">Todas</button>${Ms.map(L=>`<button type="button" data-interest="${L.id}" aria-pressed="false">${L.label}</button>`).join("")}</div>
     <details class="advanced-origins"><summary>Filtrar por livro e perícia</summary><div><label>Livro de origem<select id="originSource"><option value="">Todos os livros</option>${[...new Set(Mi.map(L=>L.source))].map(L=>`<option>${L}</option>`).join("")}</select></label><label>Perícia associada<select id="originSkill"><option value="">Todas as perícias</option>${Ff.map(L=>`<option value="${L.code}">${L.label}</option>`).join("")}</select></label></div></details>
    </section>
    <section class="origin-filter-feedback" id="originFilters" aria-label="Filtros aplicados" hidden><span class="filter-seal" aria-hidden="true">✓</span><div><small>Filtro aplicado</small><strong class="filter-applied-label"></strong><p class="filter-result-count"></p></div><div class="filter-feedback-actions"><button type="button" class="change-interest ink-link">Trocar interesse</button><button type="button" class="reset-filters ink-link">Limpar filtros</button></div></section>
    <div class="origin-library"><section class="origin-index" aria-labelledby="originCount"><div class="index-heading"><h2 id="originCount" tabindex="-1"></h2></div><ol id="originResults"></ol><p class="origin-empty" hidden>Nenhuma origem com esses filtros. Tente outra palavra ou limpe os filtros.</p></section>
     <section class="origin-detail" id="originDetail" aria-labelledby="originDetailTitle"><div class="detail-placeholder"><span class="ink-star" aria-hidden="true">✧</span><h2 id="originDetailTitle">Seu passado começa aqui.</h2><small>Abra uma origem para ver um exemplo.</small></div></section></div>
    <footer class="paper-footer"><div><button class="open-comparison ink-link" type="button" disabled>Comparar origens (0/2)</button><p class="paper-status" role="status" aria-live="polite">Abra uma origem para começar.</p><button type="button" class="origin-next ink-primary" hidden>Continuar para classe <span aria-hidden="true">→</span></button><small class="origin-next-hint" hidden>Confirme a origem aberta para continuar.</small></div><span class="paper-page">ÓRION / 02</span></footer>
    </section><section class="class-chapter" aria-label="Escolha da classe" hidden></section><section class="creation-journey" aria-label="Continuar criação do arauto" hidden></section>
   </div>
  </article></div></div>
  <dialog class="origin-comparison" aria-labelledby="compareTitle"><header><div><small>Duas possibilidades para sua história</small><h2 id="compareTitle">Lado a lado</h2></div><button type="button" class="close-comparison ink-link" aria-label="Fechar comparação">×</button></header><div class="comparison-content"></div></dialog>`,document.body.append(a),document.documentElement.dataset.paperTransition="1",a.querySelector(".paper-name").textContent=i.name;const u=L=>a.querySelector(L),h=u(".paper-status"),p=u("#originResults"),g=u("#originDetail"),v=u(".paper-content"),m=u(".physical-sheet"),f=u("dialog"),b=g.innerHTML;let _=!1,x=0;const R=IS(a,{reducedMotion:n});function M(L){i={...L},t(L)}function A(L){h.textContent=L}function w(){const L=u(".origin-next"),$=!!(o.selected&&o.selected!==o.confirmed);L.hidden=!o.confirmed,L.disabled=$,u(".origin-next-hint").hidden=!o.confirmed||!$,L.firstChild.textContent=l?"Rever classe ":"Continuar para classe "}function S(){d?.save(),d?.dispose(),d=null,c?.dispose(),c=null,u(".class-chapter").hidden=!0,u(".creation-journey").hidden=!0,u(".origin-chapter-content").hidden=!1,a.dataset.chapter="origin",a.setAttribute("aria-label","Ficha de criação: origem"),m.setAttribute("aria-labelledby","paperTitle"),u(".paper-return").textContent="← Voltar à identidade",w(),u(".paper-scroll").scrollTop=x}function y(){if(!(_||R.busy))return R.turn(S,{backward:!0,focus:()=>u(".origin-next")})}function T(){d?.save(),d?.dispose(),d=null,c?.dispose();const L=Mi.find($=>$.code===o.confirmed);u(".origin-chapter-content").hidden=!0,u(".creation-journey").hidden=!0,u(".class-chapter").hidden=!1,a.dataset.chapter="class",a.setAttribute("aria-label","Ficha de criação: classe"),m.setAttribute("aria-labelledby","classPaperTitle"),u(".paper-return").textContent="← Voltar às origens",c=WS(u(".class-chapter"),{name:i.name,originLabel:L.label,classCode:l,reducedMotion:n,onBack:y,onContinue:()=>k(),onConfirm($){const Z=HS({...i,origin:{code:L.code,label:L.label,source:L.source}},$);if(!Z)return!1;try{return sessionStorage.setItem(Ka,JSON.stringify(Z)),l=$,M(Z),a.dispatchEvent(new CustomEvent("orion:class-chosen",{detail:Z,bubbles:!0})),w(),!0}catch{return!1}}}),u(".paper-scroll").scrollTop=0}function N(){if(!(_||R.busy||!o.confirmed||u(".origin-next").disabled))return a.dataset.chapter==="origin"&&(x=u(".paper-scroll").scrollTop),R.turn(T,{backward:a.dataset.chapter==="journey",focus:()=>u("#classPaperTitle")})}async function B(){const{mountCreationJourney:L}=await hp(async()=>{const{mountCreationJourney:$}=await import("./creation-journey-DTCdLQ_H.js");return{mountCreationJourney:$}},__vite__mapDeps([0,1,2,3,4]));_||(c?.dispose(),c=null,d?.dispose(),u(".class-chapter").hidden=!0,u(".origin-chapter-content").hidden=!0,u(".creation-journey").hidden=!1,a.dataset.chapter="journey",a.setAttribute("aria-label","Ficha de criação: decisões do arauto"),m.setAttribute("aria-labelledby","journeyTitle"),u(".paper-return").textContent="← Rever classe",d=L(u(".creation-journey"),{draft:i,onSave:M,onBack:N,onOrigin:y,onTurn:($,Z)=>R.turn($,Z),scroll:()=>u(".paper-scroll").scrollTop=0}),u(".paper-scroll").scrollTop=0)}async function k(){if(!(_||R.busy||!l))try{await R.turn(B,{focus:()=>u("#journeyTitle")})}catch{const L=u(".class-status");L&&(L.textContent="Não foi possível abrir a próxima etapa. Suas escolhas foram preservadas; tente novamente.")}}function V(){const L=u(".open-comparison");L.textContent=`Comparar origens (${o.compared.length}/2)`,L.disabled=o.compared.length!==2}function D(){for(const L of p.querySelectorAll("[data-origin]"))L.setAttribute("aria-pressed",String(L.dataset.origin===o.selected)),L.querySelector(".origin-row-arrow").textContent=L.dataset.origin===o.selected?"✓":"→"}function O(){const L=gh(o);u("#originCount").textContent=`${L.length} ${L.length===1?"origem":"origens"}`,p.innerHTML=L.map(Z=>`<li><button type="button" data-origin="${Z.code}" aria-pressed="${Z.code===o.selected}" aria-controls="originDetail"><span class="origin-row-symbol">${Oa(Z.code)}</span><strong>${En(Z.label)}</strong><span class="origin-row-arrow" aria-hidden="true">${Z.code===o.selected?"✓":"→"}</span></button></li>`).join(""),u(".origin-empty").hidden=L.length>0,u(".reset-filters").hidden=!(o.query||o.interest||o.source||o.skill),u(".clear-search").hidden=!o.query;for(const Z of a.querySelectorAll("[data-interest]"))Z.setAttribute("aria-pressed",String(Z.dataset.interest===o.interest));for(const Z of a.querySelectorAll("[data-guide]"))Z.setAttribute("aria-pressed",String(Z.dataset.guide===o.interest));const $=[Ms.find(Z=>Z.id===o.interest)?.label,o.query?`Busca: ${o.query}`:"",o.source,o.skill?Qa(o.skill):""].filter(Boolean);u("#originFilters").hidden=!$.length,u(".filter-applied-label").textContent=$.join(" · "),u(".filter-result-count").textContent=`${L.length} ${L.length===1?"origem para explorar":"origens para explorar"}`,u(".change-interest").hidden=!o.interest,A(`${L.length} ${L.length===1?"origem encontrada":"origens encontradas"}.${o.selected?" A origem aberta continua disponível para revisão.":""}`)}function F(){w();const L=Mi.find($=>$.code===o.selected);if(!L){g.innerHTML=b;return}g.innerHTML=`<div class="detail-overline"><button class="back-to-index ink-link" type="button">↑ Voltar à lista</button></div><div class="origin-heading"><div class="origin-portrait">${Oa(L.code)}</div><h2 id="originDetailTitle" tabindex="-1">${En(L.label)}</h2></div><section class="origin-example" aria-label="Exemplo de passado"><span>Por exemplo…</span><p>${En(Sc(L))}</p></section><dl class="origin-facts"><div><dt>Perícias</dt><dd><ul class="origin-skill-chips">${L.fixedSkills.map($=>`<li>${En(Qa($))}</li>`).join("")}${L.variableSkillCount?`<li>+${L.variableSkillCount} à escolha</li>`:""}</ul></dd></div><div><dt>Habilidade</dt><dd>${En(L.powerName)}</dd></div></dl>${L.professionRequired?'<p class="origin-choice-note">Exige uma especialidade de Profissão.</p>':""}<details class="origin-more"><summary>Ver contexto e fonte</summary><p class="origin-story">${En(Bf(L))}</p><p class="origin-book">${En(L.source)}</p><small>O exemplo é só uma inspiração para sua história.</small></details><div class="origin-detail-actions"><button type="button" class="choose-origin ink-primary" ${o.confirmed===L.code?"disabled":""}>${o.confirmed===L.code?"✓ Origem escolhida":"Escolher esta origem"}<span aria-hidden="true">→</span></button><button type="button" class="compare-origin ink-link" aria-pressed="${o.compared.includes(L.code)}">${o.compared.includes(L.code)?"− Retirar da comparação":"+ Comparar esta origem"}</button></div>`,u(".choose-origin").addEventListener("click",()=>{const $={...i,step:"origin",origin:{code:L.code,label:L.label,source:L.source},...l?{classCode:l}:{}};try{sessionStorage.setItem(Ka,JSON.stringify($)),o.confirmed=L.code,u(".paper-chosen-name").textContent=L.label,F(),kf(),A(`${L.label} é a origem de ${i.name}. Continue para escolher a classe.`),M($),a.dispatchEvent(new CustomEvent("orion:origin-chosen",{detail:$,bubbles:!0}))}catch{A("Não foi possível guardar esta escolha. Você pode continuar explorando e tentar novamente.")}}),u(".compare-origin").addEventListener("click",()=>{if(o.compared.includes(L.code))o.compared=o.compared.filter($=>$!==L.code);else if(o.compared.length<2)o.compared.push(L.code);else{A("Há duas origens na comparação. Retire uma delas para adicionar outra.");return}V(),F(),u(".compare-origin").focus({preventScroll:!0}),A(o.compared.length===2?"Duas origens separadas. Abra a comparação no fim da folha.":`${o.compared.length} origem na comparação.`)}),u(".back-to-index").addEventListener("click",()=>{p.querySelector(`[data-origin="${L.code}"]`)?.focus()})}p.addEventListener("click",L=>{const $=L.target.closest("[data-origin]");$&&(o.selected=$.dataset.origin,D(),F(),A(`${Mi.find(Z=>Z.code===o.selected).label} aberta. Confira os detalhes antes de escolher.`),matchMedia("(max-width: 760px)").matches&&(u("#originDetailTitle").focus({preventScroll:!0}),g.scrollIntoView({behavior:n?"instant":"smooth",block:"start"})))}),u("#originSearch").addEventListener("input",L=>{o.query=L.target.value,O()}),u(".clear-search").addEventListener("click",()=>{o.query="",u("#originSearch").value="",O(),u("#originSearch").focus()});function z(L){o.interest=L,O()}function j(L){for(const $ of a.querySelectorAll("[data-mode]"))$.setAttribute("aria-pressed",String($.dataset.mode==="guide"===L));u(".origin-guide").hidden=!L,u(".origin-tools").hidden=L,u(".origin-library").hidden=L,u("#originFilters").hidden=L||!(o.query||o.interest||o.source||o.skill)}function te(){(u("#originFilters").hidden?u(".origin-library"):u("#originFilters")).scrollIntoView({behavior:n?"instant":"smooth",block:"start"}),u("#originCount").focus({preventScroll:!0})}for(const L of a.querySelectorAll("[data-interest]"))L.addEventListener("click",()=>z(L.dataset.interest));for(const L of a.querySelectorAll("[data-guide]"))L.addEventListener("click",()=>{Object.assign(o,{query:"",source:"",skill:"",selected:null}),u("#originSearch").value="",u("#originSource").value="",u("#originSkill").value="",z(L.dataset.guide),F(),j(!1),te(),A(`${Ms.find($=>$.id===o.interest).label}: filtro aplicado. ${gh(o).length} origens para explorar.`)});for(const L of a.querySelectorAll("[data-mode]"))L.addEventListener("click",()=>j(L.dataset.mode==="guide"));return u(".change-interest").addEventListener("click",()=>{j(!0),u(".origin-guide").scrollIntoView({behavior:n?"instant":"smooth",block:"start"}),a.querySelector(`[data-guide="${o.interest}"]`)?.focus({preventScroll:!0})}),u("#originSource").addEventListener("change",L=>{o.source=L.target.value,O()}),u("#originSkill").addEventListener("change",L=>{o.skill=L.target.value,O()}),u(".reset-filters").addEventListener("click",()=>{Object.assign(o,{query:"",interest:"",source:"",skill:""}),u("#originSearch").value="",u("#originSource").value="",u("#originSkill").value="",O(),te()}),u(".open-comparison").addEventListener("click",()=>{u(".comparison-content").innerHTML=o.compared.map(L=>{const $=Mi.find(Z=>Z.code===L);return`<section><div class="comparison-origin-heading">${Oa($.code)}<h3>${En($.label)}</h3></div><p class="comparison-background">${En(Sc($))}</p><dl><dt>Perícias</dt><dd>${En(qS($))}</dd><dt>Habilidade</dt><dd>${En($.powerName)}</dd><dt>Livro</dt><dd>${En($.source)}</dd></dl><button type="button" class="ink-link" data-remove-compare="${$.code}">Retirar da comparação</button></section>`}).join(""),f.showModal()}),u(".comparison-content").addEventListener("click",L=>{const $=L.target.closest("[data-remove-compare]");$&&(o.compared=o.compared.filter(Z=>Z!==$.dataset.removeCompare),V(),F(),f.close(),A("Origem retirada da comparação."))}),u(".close-comparison").addEventListener("click",()=>f.close()),Mc(u(".origin-next"),N),Mc(u(".paper-return"),async()=>{if(!(_||R.busy)){if(a.dataset.chapter==="class"){y();return}if(a.dataset.chapter==="journey"){N();return}if(_=!0,R.dispose(),c?.dispose(),d?.save(),d?.dispose(),a.inert=!0,delete document.documentElement.dataset.paperActive,document.documentElement.dataset.paperTransition="1",!n){const L=[u(".paper-landing").animate([{opacity:1,transform:"none"},{opacity:0,transform:"translateY(-70px) rotateX(6deg)"}],{duration:360,fill:"forwards"}),u(".workshop-planks").animate([{opacity:1},{opacity:0}],{duration:360,delay:120,fill:"forwards"})];await Promise.all(L.map($=>$.finished.catch(()=>{})))}a.remove(),delete document.documentElement.dataset.paperReady,delete document.documentElement.dataset.paperTransition,Er=null,e(),s?.focus({preventScroll:!0})}}),i.origin&&Mi.some(L=>L.code===i.origin.code)&&(o.selected=o.confirmed=i.origin.code,u(".paper-chosen-name").textContent=Mi.find(L=>L.code===o.selected).label,F()),O(),w(),a.dataset.chapter="origin",Er=(async()=>{await zf(),!_&&(u(".paper-preparing").textContent="",r&&i.character&&l&&await B(),await PS(a,{reducedMotion:n}),!_&&(a.dataset.phase="ready",v.inert=!1,m.setAttribute("aria-busy","false"),document.documentElement.dataset.paperReady="1",delete document.documentElement.dataset.paperTransition,(a.dataset.chapter==="journey"?u("#journeyTitle"):u("#paperTitle")).focus({preventScroll:!0})))})().catch(L=>{throw a.remove(),Er=null,delete document.documentElement.dataset.paperActive,delete document.documentElement.dataset.paperReady,delete document.documentElement.dataset.paperTransition,R.dispose(),L}),Er}function $S(i,{hands:e,reducedMotion:t=!1,scene:n,camera:r,environment:s}){let a=fS(),o=null,l={x:0,y:0},c=!1,d=null,u=null,h=null;const p=document.createElement("section");p.className="herald-creation",p.setAttribute("aria-label","O nascimento do Marcado"),p.innerHTML=`
 <a class="creation-back" href="index.html?stars=0" aria-label="Voltar ao observatório">←</a>
 <span class="creation-label">O despertar</span>
 <div class="creation-stage">
  <section class="birth-stage" aria-label="O despertar">
   <h1 class="blood-prologue">Tudo começa pelo sangue.</h1>
   <div class="sealed-being"><button class="baby-target" type="button" data-creation-point aria-label="Contemplar a silhueta etérea" aria-controls="markBeing" aria-expanded="false"><span class="sr-only">Acorrentado pela realidade: uma silhueta cercada por sigilos de conhecimento</span><span class="interaction-cue" aria-hidden="true">Despertar</span></button></div>
   <div class="mark-slot"><button class="mark-being" id="markBeing" aria-label="Tornar Marcado" type="button" hidden disabled><span class="mark-sigil" aria-hidden="true">✧</span><span class="mark-title">Tornar Marcado</span><span class="mark-hint">Romper o vínculo</span></button></div>
  </section>
  <form id="identityForm" class="identity-form" hidden>
   <header class="identity-title" hidden><h1>O início de uma história.</h1><p>Escolha uma representação para seu arauto.</p></header>
   <fieldset class="child-choices"><legend class="sr-only">Escolha a silhueta ou não defina gênero</legend>${["menina","menino"].map(D=>`<button type="button" class="child-choice" data-gender="${D}" data-creation-point aria-label="Escolher ${D}" aria-pressed="false"><i class="soul-anchor" aria-hidden="true"></i><span>${D==="menina"?"Menina":"Menino"}<small>Selecionar</small></span></button>`).join("")}</fieldset>
   <div class="identity-controls">
    <div class="identity-fields"><label for="herald-name" class="name-label">Nome do arauto</label><input id="herald-name" name="name" type="text" placeholder="Nomeie seu arauto" maxlength="60" required autocomplete="off" aria-describedby="creationStatus"><label class="undefined-choice"><input type="checkbox" id="undefinedGender">Não definir gênero</label></div>
    <div class="identity-action" hidden><button class="creation-next" type="submit" aria-label="Continuar com esta identidade" hidden disabled><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14m-6-6 6 6-6 6"/></svg></button><span aria-hidden="true">Continuar</span></div>
   </div>
  </form>
 </div>
 <p id="creationStatus" class="creation-status" role="status" aria-live="polite"></p>`,i.append(p);const g=op(location.href);g.searchParams.set("stars","0"),p.querySelector(".creation-back").href=g.href;const v=p.querySelector(".baby-target"),m=p.querySelector("#markBeing"),f=p.querySelector(".sealed-being"),b=p.querySelector("form"),_=p.querySelector("#herald-name"),x=p.querySelector("#undefinedGender"),R=p.querySelector(".creation-next"),M=p.querySelector("#creationStatus"),A=CS({scene:n,camera:r,panel:p,reducedMotion:t,environment:s});v.disabled=!0,A.ready.then(()=>{i.dataset.creationArt="ready",v.disabled=!1,m.disabled=!1,M.textContent=""}).catch(()=>{i.dataset.creationArt="error",M.textContent="Não foi possível carregar a cena. Recarregue a página."}),new URLSearchParams(location.search).has("debug")&&(window.__orionCreationDebug=A);function w(){p.dataset.phase=a.phase,i.dataset.creationPhase=a.phase,p.querySelector(".creation-label").textContent=a.phase==="identity"?"Identidade":"O despertar",p.querySelector(".identity-title").hidden=a.phase!=="identity",p.querySelector(".birth-stage").hidden=a.phase==="identity",p.querySelector(".identity-action").hidden=a.gender===null,p.querySelector(".blood-prologue").setAttribute("aria-hidden",String(a.phase==="identity"));for(const D of p.querySelectorAll("[data-gender]"))D.setAttribute("aria-pressed",String(D.dataset.gender===a.gender)),D.querySelector("small").textContent=D.dataset.gender===a.gender?"✓ Selecionado":"Selecionar";x.checked=a.gender==="nao-definir",R.hidden=a.gender===null,R.disabled=!bc(a)||a.continued,A.invalidateLayout()}function S(){o=performance.now(),e.setStarHovered?.(!0)}function y(D){if(A.update(D),e.setStarDirection?.(l.x,l.y),o!==null){const O=Ef((D-o)/1e3,t);e.setStarSelection?.(O.progress<1?O:null),O.progress>=1&&(o=null)}}function T(D){l={x:(D.clientX/innerWidth-.5)*2,y:(.5-D.clientY/innerHeight)*2},e.setStarHovered?.(!!D.target.closest("[data-creation-point]")),A.point(l),A.hover(D.target.closest(".baby-target")?"baby":D.target.closest("[data-gender]")?.dataset.gender??null)}p.addEventListener("focusin",D=>{e.setStarHovered?.(D.target.matches(":focus-visible")&&!!D.target.closest("[data-creation-point]")),A.hover(D.target===v?"baby":D.target.dataset.gender??null)}),p.addEventListener("focusout",()=>{e.setStarHovered?.(!1),A.hover(null)}),p.addEventListener("pointerleave",()=>A.hover(null)),v.addEventListener("click",()=>{a.phase==="sealed"&&(a=Mr(a,{type:"reveal"}),S(),w(),v.setAttribute("aria-expanded","true"),m.hidden=!1,M.textContent="Acorrentado pela realidade.",m.focus({preventScroll:!0}))}),m.addEventListener("click",async()=>{a.phase==="revealed"&&(zf(),a=Mr(a,{type:"mark"}),w(),o=null,e.setStarSelection?.(null),e.setStarHovered?.(!1),m.disabled=!0,v.inert=!0,b.append(M),b.hidden=!1,b.inert=!0,M.textContent="Os sigilos se desfazem. A alma desperta.",await A.release(),a=Mr(a,{type:"released"}),w(),f.hidden=!0,m.hidden=!0,b.hidden=!1,b.inert=!1,M.textContent="Dê um nome ao seu arauto e escolha como deseja representá-lo.",p.querySelector(".child-choice").focus({preventScroll:!0}))});function N(D){a=Mr(a,{type:"gender",value:D}),A.select(D),(D==="menina"||D==="menino")&&S(),w(),M.textContent=a.name.trim()?"Sua identidade começa a tomar forma.":"Digite um nome para continuar."}for(const D of p.querySelectorAll("[data-gender]"))D.addEventListener("click",()=>N(D.dataset.gender));x.addEventListener("change",()=>N(x.checked?"nao-definir":null)),_.addEventListener("input",()=>{a=Mr(a,{type:"name",value:_.value}),w(),M.textContent=a.gender===null?"Escolha uma silhueta ou não defina gênero.":a.name.trim()?"Sua identidade está pronta para continuar.":"Digite um nome para continuar."}),b.addEventListener("submit",D=>{if(D.preventDefault(),!bc(a)||a.continued){a.name.trim()||(_.setCustomValidity("Dê um nome ao seu arauto."),_.reportValidity(),_.setCustomValidity(""));return}a=Mr(a,{type:"continue"}),w();const O={...h,version:1,name:a.name,gender:a.gender,step:"identity",...d?{origin:d}:{},...u?{classCode:u}:{}};try{sessionStorage.setItem(Ka,JSON.stringify(O))}catch{c=!0}M.textContent=c?"Seu navegador não permitiu guardar o rascunho. Você ainda pode explorar as origens.":"Preparando sua ficha…",i.dispatchEvent(new CustomEvent("orion:creation-continue",{detail:O,bubbles:!0})),B(O)});function B(D,O=!1){return i.inert=!0,jS(D,{reducedMotion:t,resume:O,onChoose(F){d=F.origin,u=F.classCode??null,F.character&&(h={character:F.character,creationStep:F.creationStep,creationVisited:F.creationVisited})},onReturn(){i.inert=!1,a={...a,continued:!1},w(),M.textContent="Revise sua identidade e continue quando quiser."}}).catch(()=>{i.inert=!1,delete document.documentElement.dataset.paperActive,a={...a,continued:!1},w(),M.textContent="Não foi possível abrir a ficha. Tente continuar novamente."})}let k=null,V="session";try{k=$a(sessionStorage,Ka),k||(k=$a(localStorage),V="local")}catch{}if(k)if(new URLSearchParams(location.search).has("resume"))a={phase:"identity",name:k.name,gender:k.gender,continued:!0},d=k.origin,u=k.classCode,h={character:k.character,creationStep:k.creationStep,creationVisited:k.creationVisited},_.value=k.name,b.hidden=!1,f.hidden=!0,m.hidden=!0,b.append(M),w(),A.select(k.gender),A.ready.then(()=>A.release({immediate:!0})).then(()=>B(k,!0)).catch(()=>{M.textContent="Não foi possível retomar a criação. O rascunho guardado não foi apagado.",i.inert=!1});else{const D=document.createElement("a");D.className="creation-resume ink-link",D.href="criacao.html?stars=0&resume="+V,D.textContent="Retomar criação anterior →",p.append(D)}return w(),{ready:A.ready,point:T,update:y,finishFrame(){if(e.state.mode==="mesh")return;const D=new Set;e.root?.traverse(O=>{O.isMesh&&O.material&&!D.has(O.material)&&(D.add(O.material),O.material.opacity*=.56)})},get state(){return{...a}}}}function KS({root:i,isLocked:e,onDismiss:t,onSwipe:n}){const r={dragging:!1,gestures:0};let s=null,a=!1;const o=g=>{const v=g.closest("button,a,input,summary,#heraldCard,.debug");return v&&!v.matches(".herald-target")};function l(g){if(g.pointerType!=="touch"){a=!1;return}if(!e()){if(s){u();return}a=!1,!(!g.isPrimary||o(g.target))&&(s={id:g.pointerId,x:g.clientX,y:g.clientY,star:!!g.target.closest(".herald-target")})}}function c(g){if(!s||g.pointerId!==s.id||e())return;const v=g.clientX-s.x,m=g.clientY-s.y;!r.dragging&&Math.hypot(v,m)<10||r.dragging||(r.dragging=!0,r.gestures++,t(),i.setPointerCapture(g.pointerId))}function d(g){if(!s||g.pointerId!==s.id)return;c(g);const v=g.clientX-s.x,m=g.clientY-s.y,f=Math.max(48,Math.min(80,i.clientWidth*.14));r.dragging&&Math.abs(v)>=f&&Math.abs(v)>Math.abs(m)*1.25&&n(v<0?1:-1),a=r.dragging,!r.dragging&&!s.star&&t();const b=s.id;s=null,r.dragging=!1,i.hasPointerCapture(b)&&i.releasePointerCapture(b)}function u(){if(!s)return;const g=s.id;s=null,r.dragging=!1,a=!0,i.hasPointerCapture(g)&&i.releasePointerCapture(g)}function h(g){g.target===i&&!i.hasPointerCapture(g.pointerId)&&u()}function p(g){!a||g.detail===0||(a=!1,g.preventDefault(),g.stopImmediatePropagation())}return i.addEventListener("pointerdown",l),i.addEventListener("pointermove",c),i.addEventListener("pointerup",d),i.addEventListener("pointercancel",u),i.addEventListener("lostpointercapture",h),i.addEventListener("click",p,!0),window.addEventListener("blur",u),{state:r,cancel:u,dispose(){u(),i.removeEventListener("pointerdown",l),i.removeEventListener("pointermove",c),i.removeEventListener("pointerup",d),i.removeEventListener("pointercancel",u),i.removeEventListener("lostpointercapture",h),i.removeEventListener("click",p,!0),window.removeEventListener("blur",u)}}}function Vf(i,e,t=0,n=0){const r=2*Math.tan(52*Math.PI/360)*496,s=r*e,a=e>1,o=a?.5-.22*n:.5,l=a?.34+.12*n:.36-.13*n;return Array.from({length:i},(c,d)=>({x:(d-t)*s*1.12+(o-.5)*s+t*8,y:(.5-l)*r,z:-470,scale:Math.min(1,Math.max(.65,e/.95))}))}function ZS({root:i,heralds:e,reducedMotion:t,isLocked:n,onChange:r}){const s=document.getElementById("starBrowser"),a=document.getElementById("browseName"),o=document.getElementById("browseCount"),l=document.getElementById("starPages"),c=document.getElementById("previousStar"),d=document.getElementById("nextStar"),u=document.getElementById("swipeHint"),h={index:0,position:0,summary:0,settled:!0,changes:0},p=e.map((f,b)=>{const _=document.createElement("button");return _.type="button",_.className="star-page",_.setAttribute("aria-label",`Mostrar ${f.data.name}, ${b+1} de ${e.length}`),_.addEventListener("click",()=>v(b)),l.appendChild(_),_});s.hidden=!1,s.dataset.single=String(e.length===1);function g(){a.textContent=e[h.index].data.name,o.textContent=`${h.index+1} / ${e.length}`,c.disabled=h.index===0,d.disabled=h.index===e.length-1,p.forEach((f,b)=>f.setAttribute("aria-current",String(b===h.index))),u.textContent="Deslize para mudar de estrela"}function v(f){if(n())return!1;const b=Math.max(0,Math.min(e.length-1,f));return b===h.index?!1:(h.index=b,h.changes++,h.settled=t,t&&(h.position=b),i.dataset.browseMoving=String(!h.settled),r(e[b]),g(),!0)}function m(f,b){const _=t?1:1-Math.exp(-Math.max(0,f)*12);h.position+=(h.index-h.position)*_,h.summary+=(Number(b)-h.summary)*_,h.settled=Math.abs(h.index-h.position)<.002,h.settled&&(h.position=h.index);const x=String(!h.settled);i.dataset.browseMoving!==x&&(i.dataset.browseMoving=x);const R=!!b||n();s.inert!==R&&(s.inert=R);for(const[M,A]of e.entries()){const w=M!==h.index,S=w||!h.settled||n();A.target.hidden!==w&&(A.target.hidden=w),A.target.tabIndex!==(w?-1:0)&&(A.target.tabIndex=w?-1:0),A.target.disabled!==S&&(A.target.disabled=S)}}return c.addEventListener("click",()=>v(h.index-1)),d.addEventListener("click",()=>v(h.index+1)),i.addEventListener("keydown",f=>{!["ArrowLeft","ArrowRight"].includes(f.key)||f.target.closest("#heraldCard,input,.debug")||(f.preventDefault(),v(h.index+(f.key==="ArrowRight"?1:-1)))}),g(),m(0,!1),{state:h,choose:v,step:f=>v(h.index+f),update:m}}function JS(i,e,t,n){return Math.min(Math.max(.5,e||1),i.dpr,Math.sqrt(i.maxPixels/Math.max(1,t*n)))}function QS({interval:i=2400,minSamples:e=12}={}){let t=null,n=0,r=0,s=0;const a={averageMs:null,samples:0,updatedAt:null,windowMs:0};function o(c=null){t=c,n=0,r=0,s=0,a.averageMs=null,a.samples=0,a.updatedAt=null,a.windowMs=0}function l(c,d){if(!Number.isFinite(d)||d<=0||d>1e3)return o(c),!1;if(t===null&&(t=c),n+=d,r++,c-t<i||r<e)return!1;const u=n/r;a.averageMs=u,a.samples=r,a.updatedAt=c,a.windowMs=c-t,t=c,n=0,r=0,s=u>24?s+1:0;const h=u>38||s>=2;return h&&(s=0),h}return{state:a,record:l,reset:o}}function eM({creationPage:i=!1}={}){const e=document.getElementById("sceneLoading");if(!e||i)return{play:async()=>{}};const t=document.createElement("div");t.className="entrance-map",t.setAttribute("aria-hidden","true"),t.innerHTML='<svg viewBox="0 0 280 180"><path class="entrance-orbit" d="M140 24C222 24 257 135 140 157C23 135 58 24 140 24Z"/><path class="entrance-route" d="m58 115 43-62 42 51 58-70 26 84-84-14-34 49-51-38"/><g><circle cx="58" cy="115" r="2"/><circle cx="101" cy="53" r="3"/><circle cx="143" cy="104" r="4"/><circle cx="201" cy="34" r="2"/><circle cx="227" cy="118" r="3"/><circle cx="109" cy="153" r="2"/></g></svg>',e.prepend(t);const n=document.createElement("button");return n.type="button",n.className="entrance-skip",n.textContent="Pular introdução",n.hidden=!0,e.append(n),{async play({reducedMotion:r=!1}={}){let s=!1;try{s=sessionStorage.getItem("orion-entrance-v24")==="seen"}catch{}if(r||s)return;e.dataset.entrance="reveal",e.querySelector("p").textContent="Uma luz. Uma história.",n.hidden=!1;const a=e.animate([{opacity:1},{opacity:1,offset:.25},{opacity:0}],{duration:1450,easing:"cubic-bezier(.22,.65,.3,1)",fill:"forwards"}),l=document.querySelector("#world").animate([{opacity:.3,transform:"scale(1.035)"},{opacity:1,transform:"scale(1)"}],{duration:1450,easing:"cubic-bezier(.2,.7,.2,1)"}),c=()=>{a.finish(),l.finish()};n.addEventListener("click",c,{once:!0}),await a.finished.catch(()=>{}),n.removeEventListener("click",c),a.cancel(),l.cancel(),n.hidden=!0,e.dataset.entrance="done";try{sessionStorage.setItem("orion-entrance-v24","seen")}catch{}}}}const Hf="orion-render-quality-v1",Gf=[["auto","Automático"],["eco","Mais fluidez"],["high","Mais detalhe"]];function tM(){try{const i=localStorage.getItem(Hf);return Gf.some(([e])=>e===i)?i:null}catch{return null}}function nM(i,{value:e="auto",onChange:t,diagnostic:n,graphics:r={}}){const s=document.createElement("button");s.type="button",s.className="quality-toggle",s.textContent="◐ Fluidez",s.setAttribute("aria-label","Ajustar qualidade visual"),s.setAttribute("aria-haspopup","dialog");const a=document.createElement("dialog");a.className="quality-dialog",a.setAttribute("aria-labelledby","qualityTitle"),a.innerHTML=`<button class="quality-close" type="button" aria-label="Fechar ajustes de qualidade">×</button><h2 id="qualityTitle">Qualidade visual</h2><p>Escolha o equilíbrio entre detalhe e movimento.</p><fieldset><legend>Preferência de imagem</legend>${Gf.map(([f,b])=>`<label><input type="radio" name="renderQuality" value="${f}"><span>${b}</span></label>`).join("")}</fieldset><p class="quality-feedback" role="status"></p><details><summary>Diagnóstico deste navegador</summary><pre></pre><button type="button" class="quality-copy">Copiar diagnóstico</button><p class="quality-copy-feedback" role="status"></p></details>`,i.append(s,a);const o=fp(i,a,r);new MutationObserver(()=>{s.disabled=i.classList.contains("jumping")||i.classList.contains("selecting"),s.disabled&&a.open&&a.close()}).observe(i,{attributes:!0,attributeFilter:["class"]});const c=[...a.querySelectorAll('input[name="renderQuality"]')],d=a.querySelector(".quality-feedback"),u=a.querySelector("details"),h=a.querySelector("pre");let p=null;function g(){c.forEach(f=>f.checked=f.value===e),h.textContent=n()}function v(){p!==null&&clearInterval(p),p=null}function m(){v(),!(!a.open||!u.open)&&(g(),p=setInterval(()=>{const f=document.getSelection();document.hidden||f&&!f.isCollapsed&&h.contains(f.anchorNode)||g()},1e3))}s.addEventListener("click",()=>{g(),a.showModal(),m(),(c.find(f=>f.checked)||c[0]).focus()}),a.querySelector(".quality-close").addEventListener("click",()=>a.close()),a.addEventListener("close",()=>{v(),s.focus()}),u.addEventListener("toggle",m);for(const f of c)f.addEventListener("change",()=>{e=f.value,t(e);let b=!1;try{localStorage.setItem(Hf,e),b=!0}catch{}d.textContent=b?"Ajuste aplicado e salvo neste navegador.":"Ajuste aplicado nesta aba.",g()});return a.querySelector(".quality-copy").addEventListener("click",async()=>{const f=n();a.querySelector("pre").textContent=f;try{await navigator.clipboard.writeText(f),a.querySelector(".quality-copy-feedback").textContent="Diagnóstico copiado."}catch{a.querySelector(".quality-copy-feedback").textContent="Selecione e copie os dados acima."}}),{button:s,dialog:a,observeSample:o.observeSample,openGraphicsHelp:o.open}}const tn=document.getElementById("observatory"),Pt=document.body.dataset.page==="creation",iM=eM({creationPage:Pt});let $r=null;const rM=document.getElementById("world");let Ji=document.getElementById("heraldTarget");const Wt=document.getElementById("heraldCard"),Li=document.getElementById("hint"),El=document.getElementById("notice"),Ec=document.getElementById("loading"),Kr=document.getElementById("arrivalFlash"),Zr=document.getElementById("debug"),Tc=document.getElementById("depth"),Wf=document.getElementById("depthValue"),at=matchMedia("(prefers-reduced-motion: reduce)").matches,xt=matchMedia("(pointer: coarse)").matches;tn.dataset.input=xt?"touch":"pointer";const Xf=xt?"Toque na estrela para conhecer":"Concentre seu olhar sobre uma estrela";Li.textContent=Xf;let vn=Number(new URLSearchParams(location.search).get("depth")||1);Number.isFinite(vn)||(vn=1);vn=_e.clamp(vn,.5,2.5);Tc.value=String(vn);Wf.textContent=vn.toFixed(1).replace(".",",")+"×";const _n=new URLSearchParams(location.search),dn=_n.has("debug"),sM=_n.get("depthMotion")!=="off",aM=_n.get("foreground")!=="off",ai=_n.get("hands"),Ei=["on","fps","vr","rig","3d","2d"].includes(ai)||["overlay","mesh"].includes(ai)||ai!=="off",Ai=ai==="2d"?"2d":ai==="3d"?"3d":ai==="rig"?"rig":ai==="vr"?"vr":ai==="fps"?"fps":ai==="overlay"?"overlay":"mesh",wh=document.getElementById("fpsHandsCredit");wh&&(wh.hidden=!Ei||Ai!=="fps");Zr.hidden=!dn;const qf=xt||navigator.deviceMemory!==void 0&&navigator.deviceMemory<=4||navigator.hardwareConcurrency!==void 0&&navigator.hardwareConcurrency<=4,wi=_n.get("quality")||tM();let wr=["eco","eco-plus","lite","low","balanced","high"].includes(wi);const eo=["no-bloom","no-gas"].includes(_n.get("effects"))?_n.get("effects"):"normal",oM=wi==="eco"?"eco":wi==="eco-plus"?"eco-plus":wi==="lite"||wi==="low"?"lite":wi==="high"?"high":wi==="balanced"?"balanced":qf?"lite":"balanced",Rh=["eco","eco-plus","lite","balanced","high"];let Pn=oM,nu=0;const lM={eco:{dpr:.53,maxPixels:5e5,bloomScale:.2,gas:[],fpsCap:60},"eco-plus":{dpr:.6,maxPixels:67e4,bloomScale:.22,gas:[],fpsCap:60},lite:{dpr:.75,maxPixels:95e4,bloomScale:.24,gas:[2],fpsCap:60},balanced:{dpr:1,maxPixels:22e5,bloomScale:.34,gas:[0,2],fpsCap:60},high:{dpr:1.25,maxPixels:32e5,bloomScale:.42,gas:[0,1,2,3,4],fpsCap:60}};function Ys(){return lM[Pn]}function Yf(){return JS(Ys(),window.devicePixelRatio,innerWidth,innerHeight)}const cM={get mode(){return Pn},get pixelRatio(){return St.getPixelRatio()},get maxPixels(){return Ys().maxPixels},get visibleGas(){return Cn.layers.filter(i=>i.visible).length},get adaptations(){return nu},get drawCalls(){return St.info.render.calls},get textures(){return St.info.memory.textures}};dn&&(window.__orionPerformance=cM);let Ch=0;function uM(i){El.textContent=i,El.hidden=!1,clearTimeout(Ch),Ch=setTimeout(()=>{El.hidden=!0},5500)}document.getElementById("leave").addEventListener("click",()=>uM("Protótipo visual: não há conta conectada para sair."));Tc.addEventListener("input",()=>{vn=Number(Tc.value),Wf.textContent=vn.toFixed(1).replace(".",",")+"×"});window.addEventListener("keydown",i=>{i.key.toLowerCase()==="d"&&!["INPUT","TEXTAREA"].includes(document.activeElement.tagName)&&(Zr.hidden=!Zr.hidden)});let St;try{St=new my({antialias:Pn==="high",alpha:!0,powerPreference:"high-performance"})}catch(i){throw Ec.textContent="WebGL indisponível neste navegador. Tente no Chrome com aceleração de hardware ativada.",i}St.setPixelRatio(Yf());St.setSize(innerWidth,innerHeight);St.outputColorSpace=_t;St.toneMapping=kh;St.toneMappingExposure=1.24;St.info.autoReset=!1;rM.appendChild(St.domElement);const Nn=new af,ut=new Kt(52,innerWidth/innerHeight,.2,900),js=new Rt,mo=new Rt,go=new Rt,vo=new Rt;Nn.add(js);js.add(mo);mo.add(go);go.add(vo);vo.add(ut);js.position.set(0,0,26);ut.position.set(0,0,0);const vt=Ai==="mesh"?hS(ut,{enabled:Ei,reducedMotion:at,animation:["mesh","rig","perspective"].includes(_n.get("handsMotion"))?_n.get("handsMotion"):"perspective",touchLayout:xt}):Ai==="overlay"?tS(tn,{enabled:Ei,reducedMotion:at}):Ai==="2d"?Xy(ut,{enabled:Ei,reducedMotion:at}):Ai==="3d"?Ky(ut,{enabled:Ei,reducedMotion:at}):Ai==="rig"?Nb(ut,{enabled:Ei,reducedMotion:at}):Ai==="vr"?Hb(ut,{enabled:Ei,reducedMotion:at}):eS(ut,{enabled:Ei,reducedMotion:at});vt.state.mode=Ai;dn&&(window.__orionHandsDebug=vt);const Qi=[],dM=new ns;function jf(i){const e=dM.load(i,void 0,void 0,t=>console.warn("[nebula]",i,t));return e.colorSpace=_t,e.anisotropy=1,e.minFilter=Gt,e.magFilter=Dt,e.generateMipmaps=!0,e}function rs(i,e,t,n,r,s,a,o=2048/768,l={}){const c=new Ut({map:jf(i),transparent:!0,opacity:t,depthTest:!1,depthWrite:!1,toneMapped:!1,side:Et,forceSinglePass:!0,blending:l.additive?Qt:Ii}),d=new ht(new yn(1,1),c);return d.position.set(n,r,e),d.renderOrder=a,d.userData.factor=s,d.userData.aspect=o,d.userData.layerName=l.name||i.split("/").pop(),Nn.add(d),Qi.push(d),d}const hM=rs("/assets/00-starfield-base.jpg",-700,1,0,0,1.58,-1,2,{name:"00 · Fundo espacial"});hM.visible=!1;const $f=rs("/assets/01-nebula-far.webp",-360,.11,0,-5,1.53,1,3072/1152,{name:"01 · Nebulosa distante"});$f.visible=!1;const Di=rs(Pt?Uf():"/assets/nebula-eso-photographic.jpg",-540,1,0,-3,1.31,2,Pt?16/9:5e3/1850,{name:Pt?"Interior da nebulosa":"02 · Via Láctea fotográfica · ESO"});Di.material.color.setRGB(.43,.46,.53);Pt&&Di.material.color.setRGB(.55,.56,.68);const to=Iy(Di,ut),fM=rs("/assets/03-mid-clouds.webp",-155,.031,-2,-4,1.42,3,3072/1152,{name:"03 · Detalhe da nebulosa",additive:!0}),pM=rs("/assets/04-front-fog.png",-92,.027,9,-10,1.56,4,2560/960,{name:"04 · Névoa frontal",additive:!0}),Kf=rs("/assets/05-star-dust.png",-58,.062,0,0,1.62,5,3072/1152,{name:"05 · Poeira estelar",additive:!0});Kf.visible=!1;const iu=[{mesh:$f,base:.11,amp:.045,rate:.43,phase:.5},{mesh:fM,base:.031,amp:.052,rate:.59,phase:1.8},{mesh:pM,base:.027,amp:.048,rate:.49,phase:3.1},{mesh:Kf,base:.062,amp:.03,rate:.69,phase:2.6}],Rr={gas:1,star:1,beacon:0},Cn=xy(Nn,{reducedMotion:at||xt});Qi.push(...Cn.layers);if(Pt)for(const i of iu)i.mesh.visible=!1;const Ih={reducedMotion:at||xt&&!Pt,parallaxEnabled:sM&&(!Pt||!xt),foregroundEnabled:aM},Zt=Pt?AS(Nn,Di,Ih):ky(Nn,Di,Ih);Qi.push(...Zt.layers);function ru(){const i=new Set(Pt||eo==="no-gas"?[]:Ys().gas);Cn.layers.forEach((e,t)=>{e.visible=i.has(t)}),Zt.applyQuality(Pn)}ru();if(dn){const i=document.createElement("fieldset");i.className="layer-inspector";const e=document.createElement("legend");e.textContent="Camadas da nebulosa",i.appendChild(e);for(const r of Qi){const s=document.createElement("label");s.className="layer-switch";const a=document.createElement("input");a.type="checkbox",a.checked=r.visible,a.addEventListener("change",()=>{r.visible=a.checked});const o=document.createElement("span");o.textContent=r.userData.layerName,s.append(a,o),i.appendChild(s)}Zr.appendChild(i);const t=document.createElement("fieldset");t.className="layer-inspector",t.innerHTML="<legend>Nebulosa Viva</legend>";const n=(r,s,a,o,l,c)=>{const d=document.createElement("label");d.className="atmosphere-slider";const u=document.createElement("span");u.textContent=r;const h=document.createElement("output");h.textContent=Number(s).toFixed(2);const p=document.createElement("input");p.type="range",p.min=String(a),p.max=String(o),p.step=String(l),p.value=String(s),p.setAttribute("aria-label",r),p.addEventListener("input",()=>{const g=Number(p.value);h.textContent=g.toFixed(2),c(g)}),d.append(u,h,p),t.appendChild(d)};n("Densidade do gás",Cn.state.density,0,1.5,.05,Cn.setDensity),n("Fluxo orgânico",Cn.state.flow,0,1,.05,Cn.setFlow),n("Paralaxe da nebulosa",Zt.state.parallaxStrength,.45,1.6,.05,Zt.setParallaxStrength),window.__orionBloomSliderFactory=n,Zr.appendChild(t)}const su=[],_o=new Rt;Nn.add(_o);function xo(i,e,t,n,r,s,a,o={}){const l=new Float32Array(i*3),c=new Float32Array(i),d=new Float32Array(i),u=new Float32Array(i),h=new Float32Array(i),p=new Float32Array(i),g=new Float32Array(i*3),v=a.map(R=>new Ie(R)),m=Math.tan(_e.degToRad(52/2)),f=innerWidth/innerHeight,b=43/496;for(let R=0;R<i;R++){const M=R*3;let A,w,S,y,T,N=0;do{A=(Math.random()-.5)*n,w=(Math.random()-.5)*r,S=e+Math.random()*(t-e);const V=26-S;y=A/V/(m*f),T=(w/V-b)/m,N++}while((y/.51)**2+(T/.42)**2<1&&N<150);l[M]=A,l[M+1]=w,l[M+2]=S,c[R]=s[0]+Math.random()*(s[1]-s[0]),d[R]=Math.random()*6.283;const B=o.group?{low:.46,high:1.05,min:.04,max:.11}:t<-255?{low:.2,high:.66,min:.035,max:.095}:t<-95?{low:.32,high:.91,min:.05,max:.14}:{low:.55,high:1.23,min:.07,max:.17};u[R]=B.low+Math.random()*(B.high-B.low),h[R]=B.min+Math.random()*(B.max-B.min),p[R]=Math.random()*6.283;const k=v[Math.floor(Math.random()*v.length)];g[M]=k.r,g[M+1]=k.g,g[M+2]=k.b}const _=new Lt;_.setAttribute("position",new ct(l,3)),_.setAttribute("aSize",new ct(c,1)),_.setAttribute("aPhase",new ct(d,1)),_.setAttribute("aTwinkleRate",new ct(u,1)),_.setAttribute("aTwinkleAmp",new ct(h,1)),_.setAttribute("aTwinkleSecondary",new ct(p,1)),_.setAttribute("aColor",new ct(g,3));const x=new wt({transparent:!0,depthWrite:!1,blending:Qt,uniforms:{uTime:{value:0},uDpr:{value:Math.min(devicePixelRatio||1,2)},uOpacity:{value:1}},vertexShader:`
      attribute float aSize;attribute float aPhase;attribute float aTwinkleRate;attribute float aTwinkleAmp;attribute float aTwinkleSecondary;attribute vec3 aColor;
      uniform float uTime;uniform float uDpr;uniform float uOpacity;
      varying vec3 vColor;varying float vOpacity;
      void main(){
        vec4 mv=modelViewMatrix*vec4(position,1.0);
        gl_Position=projectionMatrix*mv;
        gl_PointSize=clamp(aSize*96.0/max(5.0,-mv.z)*uDpr,0.6,3.7);
        vColor=aColor;
        // Estrelas não cintilam em sincronismo. Cada ponto tem frequência,
        // amplitude e segunda fase independente (sem gasto extra de draw calls).
        float low=sin(uTime*aTwinkleRate+aPhase);
        float irregular=sin(uTime*(aTwinkleRate*1.753+.12)+aTwinkleSecondary);
        vOpacity=clamp(.61+low*aTwinkleAmp*.40+irregular*aTwinkleAmp*.18,.32,.78)*uOpacity;
      }`,fragmentShader:`
      varying vec3 vColor;varying float vOpacity;
      void main(){
        float r=length(gl_PointCoord-vec2(.5));
        float alpha=(1.0-smoothstep(.1,.48,r))*vOpacity;
        gl_FragColor=vec4(vColor,alpha);
      }`});x.userData.baseOpacity=o.opacity??1,su.push(x),(o.group||_o).add(new Xc(_,x))}xo(110,-540,-270,1100,570,[1.3,3.2],["#c1cce1","#8791c8","#d5c9c4"],{opacity:.38});xo(28,-255,-105,510,290,[.8,2],["#c9d0ed","#a99cc9","#d5c8a9"],{opacity:.34});xo(8,-95,-15,250,140,[.6,1.15],["#bfc6dd","#a5a8ce","#d2c8bc"],{opacity:.28});const yo=new Rt;Nn.add(yo);xo(0,-56,-6,128,72,[.65,1],["#d6dfff","#d3baff","#f7eacf"],{group:yo,opacity:0});dn&&(window.__orionDepthDebug={rigRoot:js,rigYaw:mo,rigPitch:go,rigRoll:vo,camera:ut,foregroundParticles:yo,layers:Qi,nebulaMotion:Zt.state});const bo=new U(0,43,-470),no=bo.clone();let un=new Rt;un.position.copy(bo);Nn.add(un);function mM(){const i=document.createElement("canvas");i.width=i.height=512;const e=i.getContext("2d"),t=e.createRadialGradient(256,256,5,256,256,245);t.addColorStop(0,"rgba(255,255,255,1)"),t.addColorStop(.03,"rgba(255,252,233,1)"),t.addColorStop(.08,"rgba(255,222,158,.87)"),t.addColorStop(.18,"rgba(249,209,133,.34)"),t.addColorStop(.42,"rgba(225,190,122,.105)"),t.addColorStop(1,"rgba(215,185,140,0)"),e.fillStyle=t,e.fillRect(0,0,512,512);const n=[[0,1.4,190],[1.4,0,192],[-.7,.7,96],[.7,.7,96]];e.save(),e.translate(256,256);for(const[s,a,o]of n){const l=Math.hypot(s,a),c=s/l,d=a/l;for(const u of[-1,1]){const h=e.createLinearGradient(0,0,c*o*u,d*o*u);h.addColorStop(0,"rgba(255,250,237,.7)"),h.addColorStop(1,"rgba(255,250,237,0)"),e.strokeStyle=h,e.lineWidth=s===0||a===0?1.6:.7,e.beginPath(),e.moveTo(0,0),e.lineTo(c*o*u,d*o*u),e.stroke()}}e.restore();const r=new uo(i);return r.colorSpace=_t,r}const gM=mM();function So(i,e){const t=new Vs({map:gM,transparent:!0,opacity:e,blending:Qt,depthWrite:!1,depthTest:!1,toneMapped:!1}),n=new lo(t);return n.scale.set(i,i,1),n.renderOrder=12,un.add(n),n}let er=new lo(new Vs({map:jf("/assets/06-star-glow.png"),transparent:!0,opacity:.16,blending:Qt,depthTest:!1,depthWrite:!1,toneMapped:!1}));er.scale.set(60,60,1);er.renderOrder=10;un.add(er);let Mo=So(47,.25),Eo=So(22,.8),To=So(7,1),$s=new ht(new ho(7.25,7.28,144),new Ut({color:15257490,transparent:!0,opacity:.015,side:Et,depthWrite:!1,depthTest:!1}));$s.renderOrder=14;un.add($s);let tr=So(178,0);tr.renderOrder=11;tr.layers.enable(1);let Ks=Tf(un,{reducedMotion:at}),Ni=new lo(new Vs({color:16777215,transparent:!0,opacity:0,depthTest:!1,depthWrite:!1}));Ni.scale.setScalar(56);Ni.layers.set(2);Ni.renderOrder=0;un.add(Ni);const io=new Lg;io.layers.set(2);const Ph=new Ce;er.layers.enable(1);Mo.layers.enable(1);Eo.layers.enable(1);To.layers.enable(1);const Zf=lp(_n),Oi=Zf.length===0,vM={id:"new-herald",name:"Sua primeira estrela",subtitle:"Um novo começo",creation:!0,stats:{level:"—",origin:"—",trail:"—",rank:"—",em:"—",ec:"—"}},_M=Oi||Pt?[vM]:Zf;tn.dataset.empty=String(Oi);Oi&&(Li.textContent="Uma nova história espera por você");const Lh={group:un,glows:{halo:er,soft:Mo,main:Eo,core:To},orbit:$s,beacon:tr,spikes:Ks,pick:Ni,target:Ji},It=_M.map((i,e)=>{let t=Lh;if(e){const n=new Rt;Nn.add(n);const r=o=>{const l=o.clone();return l.material=o.material.clone(),n.add(l),l},s=Object.fromEntries(Object.entries(Lh.glows).map(([o,l])=>[o,r(l)])),a=Ji.cloneNode(!1);a.id=`heraldTarget-${i.id}`,Ji.parentNode.insertBefore(a,Wt),t={group:n,glows:s,orbit:r($s),beacon:r(tr),pick:r(Ni),target:a,spikes:Tf(n,{reducedMotion:at,sharedTexture:Ks.primary.material.map})}}return t.pick.userData.heraldIndex=e,t.target.setAttribute("aria-label",i.creation?"Criar meu primeiro arauto":`Selecionar ${i.name}${i.demo?", estrela de demonstração":", arauto ativo, nível 9"}`),{data:i,...t,basePosition:new U,screen:{x:NaN,y:NaN},focus:0}});let ln=It[0],Ln=null;document.getElementById("heraldCount").textContent=Oi?"Sua primeira história":It.length===1?"1 arauto ativo":`${It.length} estrelas · prévia`;const au=up(Kr);function xM(){const i=ln.data;document.getElementById("heraldName").textContent=i.name,document.getElementById("heraldSubtitle").textContent=i.subtitle,document.getElementById("heraldStatus").textContent=i.demo?"Demonstração":"Arauto ativo",Wt.setAttribute("aria-label",`Resumo de ${i.name}`),document.getElementById("dismissHerald").setAttribute("aria-label",`Fechar resumo de ${i.name}`);for(const e of Wt.querySelectorAll("[data-herald-stat]"))e.textContent=i.stats[e.dataset.heraldStat];ou=Wt.offsetHeight}function Nr(i){if(i===ln)return!0;if(bt||Ht.state.active||Ln)return!1;ln=i,Ji=i.target,un=i.group,{halo:er,soft:Mo,main:Eo,core:To}=i.glows,$s=i.orbit,tr=i.beacon,Ks=i.spikes,Ni=i.pick,bo.copy(i.group.position),no.copy(i.basePosition),Ht=i.selection,xM();for(const e of It)e.target.setAttribute("aria-expanded",String(Dn&&e===i));return Dn&&(Li.textContent=`${i.data.name} · ${xt?"Escolha":"Clique para"} atravessar o véu`),!0}const Or=Ry(St,Nn,ut,{initial:xt?.1:.18,reducedMotion:at});dn&&(window.__orionBloomSliderFactory("Bloom seletivo",Or.state.intensity,0,1.5,.05,Or.setIntensity),window.__orionAtmosphereDebug={atmosphere:Cn,selectiveBloom:Or},window.__orionRespirationDebug={state:Rr,veils:iu,nebula:Di,get beaconGlow(){return tr},get heraldGroup(){return un}},window.__orionCinematicDebug={get spikes(){return Ks},starsGroup:_o,foregroundParticles:yo},delete window.__orionBloomSliderFactory);let on={x:0,y:0},gn={x:0,y:0},Dn=!1,bt=!1,Jf=0,Tr=0,Ac=!1,ou=Wt.offsetHeight;const Tn={cx:NaN,cy:NaN,focusAt:0,focusX:NaN,focusY:NaN},Ur={pointerEvents:0,raycasts:0,focusWrites:0};dn&&(window.__orionInteractionMetrics={get pointerEvents(){return Ur.pointerEvents},get raycasts(){return Ur.raycasts},get focusWrites(){return Ur.focusWrites}});const yM={get x(){return gn.x},get y(){return gn.y},get targetX(){return on.x},get targetY(){return on.y},get volumeLayers(){return Zt.layers.length}};dn&&(window.__orionMotionDebug=yM);let ws=performance.now();const Tl=new U;function bM(){for(const a of It){Tl.copy(a.group.position).project(ut);const o=(Tl.x*.5+.5)*innerWidth,l=(-Tl.y*.5+.5)*innerHeight;!Number.isFinite(o)||!Number.isFinite(l)||(!Number.isFinite(a.screen.x)||Math.abs(o-a.screen.x)>.45||Math.abs(l-a.screen.y)>.45)&&(a.target.style.left=o.toFixed(1)+"px",a.target.style.top=l.toFixed(1)+"px",a.screen.x=o,a.screen.y=l)}const{x:i,y:e}=ln.screen;vt.setStarDirection?.((i/innerWidth-.5)*2,(.5-e/innerHeight)*2),bt&&(Kr.style.setProperty("--arrival-x",(i/innerWidth*100).toFixed(2)+"%"),Kr.style.setProperty("--arrival-y",(e/innerHeight*100).toFixed(2)+"%"));const t=performance.now();if(t-Tn.focusAt>90&&(!Number.isFinite(Tn.focusX)||Math.abs(i-Tn.focusX)>2||Math.abs(e-Tn.focusY)>2)&&(tn.style.setProperty("--nox-focus-x",(i/innerWidth*100).toFixed(1)+"%"),tn.style.setProperty("--nox-focus-y",(e/innerHeight*100).toFixed(1)+"%"),Tn.focusAt=t,Tn.focusX=i,Tn.focusY=e,Ur.focusWrites++),xt)return;const n=265,r=_e.clamp(i+170+n<innerWidth-15?i+119:i-150-n,12,innerWidth-n-12),s=_e.clamp(e-93,110,Math.max(112,innerHeight-ou-18));(!Number.isFinite(Tn.cx)||Math.abs(r-Tn.cx)>.5||Math.abs(s-Tn.cy)>.5)&&(Wt.style.left=r.toFixed(1)+"px",Wt.style.top=s.toFixed(1)+"px",Tn.cx=r,Tn.cy=s)}function Ri(i){if(!Pt){if(Oi){if(bt||Ht.state.active)return;vt.setStarHovered?.(i),Li.textContent="Clique na estrela para começar sua história";return}if(!(bt||Ht.state.active)){Dn=i,tn.dataset.summary=String(i),Wt.classList.toggle("visible",i),Wt.setAttribute("aria-hidden",String(!i)),Wt.inert=!i;for(const e of It)e.target.setAttribute("aria-expanded",String(i&&e===ln));vt.setStarHovered?.(i),Li.textContent=i?`${ln.data.name} · ${xt?"Escolha":"Clique para"} atravessar o véu`:Xf}}}function Zs(i=!1){bt||Ht.state.active||(i&&(Ac=!0,Ji.focus({preventScroll:!0}),Ac=!1),Ri(!1))}document.getElementById("dismissHerald").addEventListener("click",()=>Zs(!0));document.getElementById("confirmHerald").addEventListener("click",()=>{Dn&&ro()});window.addEventListener("keydown",i=>{i.key==="Escape"&&Dn&&(i.preventDefault(),Zs(!0))});const ci=xt?ZS({root:tn,heralds:It,reducedMotion:at,isLocked:()=>bt||!!Ln,onChange:i=>{Zs(),Nr(i),Li.textContent=`${i.data.name} · Toque na estrela para conhecer`}}):null,lu=xt?KS({root:tn,isLocked:()=>bt||!!Ln,onDismiss:()=>Zs(),onSwipe:i=>ci.step(i)}):null;dn&&(window.__orionMobileDebug=ci);dn&&(window.__orionTouchDebug=lu);for(const i of It){const e=i.target;e.addEventListener("mouseenter",()=>{!xt&&Nr(i)&&Ri(!0)}),e.addEventListener("mouseleave",()=>{xt||Ri(!1)}),e.addEventListener("focus",()=>{!Ac&&(!xt||e.matches(":focus-visible"))&&Nr(i)&&Ri(!0)}),e.addEventListener("blur",()=>{xt||Ri(!1)}),e.addEventListener("click",t=>{if(!(bt||Ht.state.active||!Nr(i))){if(Oi){ro(i);return}if(xt){if(!ci.state.settled)return;Ri(!0);return}if(t.detail===0&&!Dn){Ri(!0);return}ro(i)}})}function Qf(i,e){if(bt||Pt)return null;const t=Math.max(120,innerHeight*.15),n=It.filter(s=>Math.abs(i-s.screen.x)<=t&&Math.abs(e-s.screen.y)<=t);if(!n.length)return null;Ur.raycasts++,Ph.set(i/innerWidth*2-1,1-e/innerHeight*2),ut.updateWorldMatrix(!0,!1);for(const s of n)s.group.updateWorldMatrix(!0,!0);io.setFromCamera(Ph,ut);const r=io.intersectObjects(n.map(s=>s.pick),!1)[0];return r?It[r.object.userData.heraldIndex]:null}window.addEventListener("pointermove",i=>{if($r){!xt&&i.pointerType!=="touch"&&(on.x=(i.clientX/innerWidth-.5)*2,on.y=(.5-i.clientY/innerHeight)*2),$r.point(i);return}if(xt||i.pointerType==="touch"||bt||Ht.state.active)return;Ur.pointerEvents++,on.x=(i.clientX/innerWidth-.5)*2,on.y=(.5-i.clientY/innerHeight)*2;const e=Qf(i.clientX,i.clientY),t=It.find(r=>document.activeElement===r.target&&r.target.matches(":focus-visible"));(e||t)&&Nr(e||t);const n=!!(e||t);document.body.classList.toggle("star-aimed",!!e),vt.setStarHovered?.(n),Dn!==n&&Ri(n)},{passive:!0});const cu=()=>{Zs(),document.body.classList.remove("star-aimed"),vt.setStarHovered?.(!1)};document.documentElement.addEventListener("pointerleave",i=>{i.pointerType!=="touch"&&cu()});window.addEventListener("blur",cu);window.addEventListener("pointerdown",i=>{if(i.pointerType==="touch"||bt||Ht.state.active||i.button!==0||i.target.closest("a,button,input,.debug"))return;const e=Qf(i.clientX,i.clientY);e&&(i.preventDefault(),ro(e))});const Bs=Ly({scene:Nn,camera:ut,star:un,glows:{halo:er,soft:Mo,main:Eo,core:To},layers:Qi,gasLayers:Cn.layers,selectiveBloom:Or,flash:Kr,sky:to,reducedMotion:at,onArrive:()=>{try{sessionStorage.setItem("orion-last-trip-v09",JSON.stringify({heraldId:Ln.data.id,passedGasLayers:Cn.layers.filter(i=>ut.position.z<i.position.z).length,endZ:ut.position.z,starZ:un.position.z}))}catch{}au.navigate(Fh(location.href,Ln.data))}});for(const i of It)i.selection=Uy(i.group,{camera:ut,hands:vt,reducedMotion:at,onDepart:Dh,onConfirm:Dh});let Ht=ln.selection;dn&&(window.__orionStarDebug={journey:Bs,get selection(){return Ht},get heraldGroup(){return un},get heraldPickSprite(){return Ni},raycaster:io,heralds:It,get selectedHeraldId(){return Ln?.data.id},transition:au.state,sky:to});function ro(i=ln){if(!(bt||!Nr(i)||!Ht.begin())){if(Ln=i,xt&&(tn.dataset.confirming="true",document.getElementById("starBrowser").inert=!0),i.data.creation)for(const e of Object.values(Ja)){if(document.querySelector(`link[data-creation-preload="${e}"]`))continue;const t=document.createElement("link");t.rel="prefetch",t.as="image",t.href=e,t.dataset.creationPreload=e,document.head.append(t)}au.prepare(Fh(location.href,i.data)),Jf=performance.now(),lu?.cancel(),Dn=!1,Wt.classList.remove("visible"),Wt.setAttribute("aria-hidden","true"),Wt.inert=!0,Ji.setAttribute("aria-expanded","false"),document.body.classList.remove("star-aimed"),Li.textContent=`${i.data.name} selecionada · Atravessando o véu…`}}function Dh(){if(!bt&&(Bs.setDestination(Ln.group,Ln.glows),!!Bs.begin())){for(const i of It)i.beacon.visible=!1,i!==Ln&&i.group.traverse(e=>{e.material&&(e.userData.departureOpacity=e.material.opacity)});bt=!0,vt.setStarHovered?.(!1),vt.beginTravel(),Dn=!1,Wt.classList.remove("visible"),Wt.setAttribute("aria-hidden","true"),Wt.inert=!0,Ji.setAttribute("aria-expanded","false"),tn.classList.add("jumping"),document.body.classList.remove("star-aimed"),Li.textContent="Atravessando o véu…"}}const Ki=QS();function Ao(){if(ou=Wt.offsetHeight,ut.aspect=innerWidth/innerHeight,ut.updateProjectionMatrix(),!bt&&!Ln){const i=xt?Vf(It.length,ut.aspect,ci.state.position,ci.state.summary):dp(It.length,ut.aspect);It.forEach((e,t)=>{const n=Oi?{x:0,y:0,z:-470,scale:1}:i[t];e.group.position.set(n.x,n.y,n.z),e.group.scale.setScalar(n.scale),e.basePosition.copy(e.group.position)}),bo.copy(ln.group.position),no.copy(ln.basePosition)}vt.resize(),St.setPixelRatio(Yf()),St.setSize(innerWidth,innerHeight),Or.resize(innerWidth,innerHeight,Ys().bloomScale);for(const i of Qi){if(i.userData.volumeFragment||i===Di&&to.state.active)continue;const e=26-i.position.z,t=2*Math.tan(_e.degToRad(52/2))*e*i.userData.factor;i.scale.set(t*i.userData.aspect,t,1)}to.state.active||Zt.resize();for(const i of su)i.uniforms.uDpr.value=St.getPixelRatio();Ki.reset(performance.now())}window.addEventListener("resize",Ao);Ao();window.addEventListener("pageshow",i=>{i.persisted&&bt&&location.reload()});const so=dn?Gy(Zr,()=>({quality:Pn,effects:eo,bloomRest:Pn!=="eco"&&eo!=="no-bloom",canvasPixels:St.domElement.width*St.domElement.height,dpr:Number(St.getPixelRatio().toFixed(2)),gasLayers:Cn.layers.filter(i=>i.visible).length,volumeLayers:Zt.layers.filter(i=>i.visible).length,foregroundNear:Zt.layers.some(i=>i.visible&&i.userData.volumeFragment&&i.position.z>-100),handsVisible:vt.state.visible,handsSurfaces:vt.state.drawSurfaces,handsMode:vt.state.mode,handsTriangles:vt.state.triangles||0,handsTextures:vt.state.textureCount,handsReady:vt.state.loaded??vt.state.enabled,handsJoints:vt.state.joints||0,handsFingerJoints:vt.state.fingerJoints||0,handsLoadError:vt.state.loadError||null,depthMotion:Zt.state.parallaxEnabled,parallaxStrength:Zt.state.parallaxStrength,drawCalls:St.info.render.calls,textures:St.info.memory.textures,mouseDeltaPx:Number(Math.hypot((gn.x-on.x)*innerWidth*.5,(gn.y-on.y)*innerHeight*.5).toFixed(1)),adaptations:nu,viewport:innerWidth+"×"+innerHeight})):null;dn&&(window.__orionDiagnostic=so);let Ar=0;function SM(i,e){if(bt||document.hidden||document.documentElement.dataset.paperTransition==="1"||document.documentElement.dataset.presentationReady!=="1"){Ki.reset(i);return}const t=Ki.record(i,e);MM.observeSample(Ki.state,i),t&&!wr&&Pn!=="eco"&&(Pn=Rh[Math.max(0,Rh.indexOf(Pn)-1)],nu++,ru(),Ao())}document.addEventListener("visibilitychange",()=>{document.hidden&&(lu?.cancel(),cu()),document.hidden||(ws=performance.now(),Ki.reset(ws),so?.reset())});const wc=St.getContext(),Nh=wc.getExtension("WEBGL_debug_renderer_info"),Oh=String(wc.getParameter(Nh?Nh.UNMASKED_RENDERER_WEBGL:wc.RENDERER)||""),MM=nM(tn,{graphics:{renderer:Oh,brave:!!navigator.brave||Oh==="Brave",creationPage:Pt},value:wr?wi:"auto",onChange(i){wr=i!=="auto",Pn=wr?i:qf?"lite":"balanced",wr?_n.set("quality",i):_n.delete("quality"),history.replaceState(history.state,"",location.pathname+"?"+_n.toString()+location.hash),Ki.reset(performance.now()),ru(),Ao()},diagnostic(){const i=St.getContext(),e=i.getExtension("WEBGL_debug_renderer_info"),t=e?i.getParameter(e.UNMASKED_RENDERER_WEBGL):i.getParameter(i.RENDERER),n=Ki.state;return["Órion · diagnóstico local","Diagnóstico: V24",navigator.userAgent,"Cena: "+(Pt?"criação / "+(tn.dataset.creationPhase||"carregando"):"observatório"),"Renderizador: "+t,...String(t).trim().toLowerCase()==="brave"?["GPU física: não identificada pelo nome genérico fornecido pelo navegador."]:[],"Modo: "+(wr?"manual":"automático")+" / "+Pn,"Canvas: "+St.domElement.width+" × "+St.domElement.height,"FPS da aba (última janela concluída): "+(n.averageMs?Math.round(1e3/n.averageMs):"coletando nova amostra"),"Amostra: "+(n.updatedAt===null?"aguardando uma janela completa neste perfil":n.samples+" quadros / "+(n.windowMs/1e3).toFixed(1)+" s; concluída há "+(Math.max(0,performance.now()-n.updatedAt)/1e3).toFixed(1)+" s"),"MSAA na inicialização: "+(i.getContextAttributes().antialias?"sim":"não"),"Nenhum dado é enviado."].join(`
`)}});let Uh=0;function ep(i){if(requestAnimationFrame(ep),Pt&&document.documentElement.dataset.paperActive==="1"){ws=i,Ar=i;return}if(document.hidden)return;const e=Ys();if(!bt&&e.fpsCap<60&&Ar&&i-Ar<1e3/e.fpsCap-1)return;const t=Ar?i-Ar:16.67;Ar=i,so?.record(i,t),SM(i,t);const n=Math.max(0,(i-ws)/1e3),r=Math.min(n,.05);ws=i;const s=i*.001;if(Ht.update(Math.min(n,Math.max(0,(i-Jf)/1e3))),bt)tr.visible=!1,Bs.update(i,r);else{if(xt&&!Ln){ci.update(n,Dn);const f=Vf(It.length,ut.aspect,ci.state.position,ci.state.summary);It.forEach((b,_)=>{const x=Oi?{x:0,y:0,z:-470,scale:1}:f[_];b.group.position.set(x.x,x.y,x.z),b.group.scale.setScalar(x.scale),b.basePosition.copy(b.group.position)}),no.copy(ln.basePosition)}else xt||un.position.copy(no);_o.position.z=0;const a=at?1:1-Math.exp(-Math.max(.001,r)*(Pt?4:18)),o=Pt?.35:1;gn.x=_e.lerp(gn.x,on.x,a),gn.y=_e.lerp(gn.y,on.y,a);const l=at?0:Math.sin(s*.29)*.23;js.position.set(xt?ci.state.position*8:gn.x*6.8*vn*o,gn.y*4.35*vn*o+l,26+(at?0:Math.sin(s*.21)*.25)),mo.rotation.y=-gn.x*.068*vn*o,go.rotation.x=gn.y*.052*vn*o,vo.rotation.z=at||xt?0:-gn.x*.011*vn*o+Math.sin(s*.27)*.0015;const c=Dn||Ht.state.active,d=c?1:0;Tr=at?0:_e.lerp(Tr,d,1-Math.exp(-r*12)),Math.abs(Tr-d)<5e-4&&(Tr=d),ut.position.z=-.9*Tr;const u=52-Tr;Math.abs(ut.fov-u)>.001&&(ut.fov=u,ut.updateProjectionMatrix());const h=at?0:Math.sin(s*.42+.6),p=at?0:Math.sin(s*.24+1.5);Rr.gas=1+.019*h+.011*p;for(const f of iu){const b=at?0:.68*Math.sin(s*f.rate+f.phase)+.32*Math.sin(s*f.rate*.57+f.phase*1.73);f.mesh.material.opacity=f.base*(1+f.amp*b+(Rr.gas-1)*.5)}const g=at?0:Math.sin(s*.77+.4),v=at?0:.65*Math.sin(s*2.16+1.1)+.35*Math.sin(s*3.24+2.4),m=at?0:Math.pow(Math.max(0,Math.cos(s*.7392-1.35)),10);Rr.beacon=m,Rr.star=1+.028*g+.013*v;for(const f of It){const{halo:b,soft:_,main:x,core:R}=f.glows,{beacon:M,orbit:A}=f;f.focus=at?0:_e.lerp(f.focus,f===ln&&c?1:0,1-Math.exp(-r*12));const w=1+.22*f.focus;if(b.scale.setScalar(156*(Rr.star+.055*m)*w),_.scale.setScalar(118*(1+.034*g+.045*m)*w),x.scale.setScalar(66*(1+.048*g+.022*v+.075*m)*w),R.scale.setScalar(18*(1+.026*v)*(1+.18*f.focus)),b.material.opacity=.075+.045*f.focus+.012*g+.028*m,_.material.opacity=.13+.085*f.focus+.012*g+.024*m,x.material.opacity=.48+.19*f.focus+.015*v+.04*m,R.material.opacity=.94,M.scale.setScalar(154+42*m),M.material.opacity=.046*m*(1+.55*f.focus),A.material.opacity=0,f===ln&&Ht.state.active){const S=Ht.state.light,y=Ht.state.charge,T=Ht.state.burst;x.material.opacity+=.3*S,_.material.opacity+=.22*y+.18*T,b.material.opacity+=.12*T,x.scale.multiplyScalar(1+.12*y+.22*T),R.scale.multiplyScalar(1+.12*y+.45*T),b.scale.multiplyScalar(1+.1*y+.12*T)}}Zt.update(s,on.x,on.y,r),Kr.style.opacity="0",Kr.style.setProperty("--veil-opacity","0")}$r?.update(i),vt.update(s,r,on.x,on.y),$r?.finishFrame();for(const a of su)a.uniforms.uTime.value=at?0:s,a.uniforms.uOpacity.value=a.userData.baseOpacity*(bt?1.24:1);Ks.update(s,Dn||Ht.state.active,bt);for(const a of It)if(a!==ln&&(a.spikes.update(s,!1,bt),bt)){const o=Bs.companionOpacity;a.group.traverse(l=>{l.material&&(l.material.opacity=l.userData.departureOpacity*o)})}ut.updateWorldMatrix(!0,!1),bM(),Cn.update(s),Uh++,St.info.reset(),Or.render(bt||Uh%2===1,bt||Pn!=="eco"&&eo!=="no-bloom"),so?.refresh(i)}if(Pt){tn.classList.add("creation-scene");for(const i of It)i.group.visible=!1,i.target.hidden=!0,i.target.inert=!0;$r=$S(tn,{hands:vt,reducedMotion:at,scene:Nn,camera:ut,environment:Zt}),dn&&(window.__orionCreationEnvironment={state:Zt.state,layers:Zt.layers,photo:Di})}if(!Pt)try{if($a(sessionStorage,"orion-herald-creation-v1")||$a(localStorage)){const e=document.createElement("a");e.className="resume-creation-link",e.href="criacao.html?stars=0&resume=1",e.textContent="Retomar criação →",tn.querySelector(".bottom-ui").append(e)}}catch{}requestAnimationFrame(ep);document.documentElement.dataset.sceneReady="1";const EM=new Promise((i,e)=>{const t=new Image;t.onload=i,t.onerror=()=>e(new Error("Não foi possível carregar o fundo.")),t.src=Pt?Uf():"/assets/nebula-eso-photographic.jpg"});Promise.all([EM,vt.ready,$r?.ready]).then(async()=>{if(vt.state.loadError)throw new Error(vt.state.loadError);await new Promise(i=>requestAnimationFrame(()=>requestAnimationFrame(i))),await iM.play({reducedMotion:at}),document.documentElement.dataset.presentationReady="1",Ec.classList.add("done"),Pt&&await cp()}).catch(i=>{document.documentElement.dataset.sceneError=i.message,document.getElementById("loadErrorText").textContent=i.message,document.getElementById("loadIssue").hidden=!1,Ec.hidden=!0});const wM=Object.freeze(Object.defineProperty({__proto__:null},Symbol.toStringTag,{value:"Module"}));export{Ka as C,xl as L,Mi as O,Ff as S,tu as c,wM as m};

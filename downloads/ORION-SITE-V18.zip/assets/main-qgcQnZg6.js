import{o as ep,g as tp,a as Lh,r as np,c as ip,b as sp}from"./page-transition-B8Pdkv8g.js";/**
 * @license
 * Copyright 2010-2025 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const Ac="180",rp=0,pu=1,ap=2,Dh=1,op=2,ri=3,fi=0,an=1,Mt=2,ui=0,Ci=1,gn=2,mu=3,gu=4,lp=5,ji=100,cp=101,up=102,dp=103,hp=104,fp=200,pp=201,mp=202,gp=203,Ml=204,El=205,vp=206,_p=207,xp=208,yp=209,Sp=210,bp=211,Mp=212,Ep=213,Tp=214,Tl=0,Al=1,wl=2,Os=3,Rl=4,Cl=5,Il=6,Pl=7,wc=0,Ap=1,wp=2,Ii=0,Rp=1,Cp=2,Ip=3,Nh=4,Pp=5,Lp=6,Dp=7,vu="attached",Np="detached",Oh=300,Us=301,Fs=302,Ll=303,Dl=304,ro=306,Bs=1e3,Ri=1001,Ga=1002,Jt=1003,Uh=1004,xr=1005,Lt=1006,Na=1007,Gt=1008,qn=1009,Fh=1010,Bh=1011,Ar=1012,Rc=1013,Ki=1014,Fn=1015,di=1016,Cc=1017,Ic=1018,wr=1020,kh=35902,zh=35899,Vh=1021,Hh=1022,An=1023,Rr=1026,Cr=1027,Pc=1028,Lc=1029,Gh=1030,Dc=1031,Nc=1033,Oa=33776,Ua=33777,Fa=33778,Ba=33779,Nl=35840,Ol=35841,Ul=35842,Fl=35843,Bl=36196,kl=37492,zl=37496,Vl=37808,Hl=37809,Gl=37810,Wl=37811,Xl=37812,ql=37813,Yl=37814,jl=37815,$l=37816,Kl=37817,Zl=37818,Jl=37819,Ql=37820,ec=37821,tc=36492,nc=36494,ic=36495,sc=36283,rc=36284,ac=36285,oc=36286,Ir=2300,Pr=2301,wo=2302,_u=2400,xu=2401,yu=2402,Op=2500,Up=0,Wh=1,lc=2,Fp=3200,Bp=3201,Oc=0,kp=1,oi="",_t="srgb",Qt="srgb-linear",Wa="linear",ft="srgb",ns=7680,Su=519,zp=512,Vp=513,Hp=514,Xh=515,Gp=516,Wp=517,Xp=518,qp=519,cc=35044,qh=35048,bu="300 es",Wn=2e3,Xa=2001;class $s{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});const n=this._listeners;n[e]===void 0&&(n[e]=[]),n[e].indexOf(t)===-1&&n[e].push(t)}hasEventListener(e,t){const n=this._listeners;return n===void 0?!1:n[e]!==void 0&&n[e].indexOf(t)!==-1}removeEventListener(e,t){const n=this._listeners;if(n===void 0)return;const s=n[e];if(s!==void 0){const r=s.indexOf(t);r!==-1&&s.splice(r,1)}}dispatchEvent(e){const t=this._listeners;if(t===void 0)return;const n=t[e.type];if(n!==void 0){e.target=this;const s=n.slice(0);for(let r=0,a=s.length;r<a;r++)s[r].call(this,e);e.target=null}}}const Xt=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];let Mu=1234567;const br=Math.PI/180,ks=180/Math.PI;function Bn(){const i=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(Xt[i&255]+Xt[i>>8&255]+Xt[i>>16&255]+Xt[i>>24&255]+"-"+Xt[e&255]+Xt[e>>8&255]+"-"+Xt[e>>16&15|64]+Xt[e>>24&255]+"-"+Xt[t&63|128]+Xt[t>>8&255]+"-"+Xt[t>>16&255]+Xt[t>>24&255]+Xt[n&255]+Xt[n>>8&255]+Xt[n>>16&255]+Xt[n>>24&255]).toLowerCase()}function Je(i,e,t){return Math.max(e,Math.min(t,i))}function Uc(i,e){return(i%e+e)%e}function Yp(i,e,t,n,s){return n+(i-e)*(s-n)/(t-e)}function jp(i,e,t){return i!==e?(t-i)/(e-i):0}function Mr(i,e,t){return(1-t)*i+t*e}function $p(i,e,t,n){return Mr(i,e,1-Math.exp(-t*n))}function Kp(i,e=1){return e-Math.abs(Uc(i,e*2)-e)}function Zp(i,e,t){return i<=e?0:i>=t?1:(i=(i-e)/(t-e),i*i*(3-2*i))}function Jp(i,e,t){return i<=e?0:i>=t?1:(i=(i-e)/(t-e),i*i*i*(i*(i*6-15)+10))}function Qp(i,e){return i+Math.floor(Math.random()*(e-i+1))}function em(i,e){return i+Math.random()*(e-i)}function tm(i){return i*(.5-Math.random())}function nm(i){i!==void 0&&(Mu=i);let e=Mu+=1831565813;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}function im(i){return i*br}function sm(i){return i*ks}function rm(i){return(i&i-1)===0&&i!==0}function am(i){return Math.pow(2,Math.ceil(Math.log(i)/Math.LN2))}function om(i){return Math.pow(2,Math.floor(Math.log(i)/Math.LN2))}function lm(i,e,t,n,s){const r=Math.cos,a=Math.sin,o=r(t/2),c=a(t/2),l=r((e+n)/2),u=a((e+n)/2),d=r((e-n)/2),h=a((e-n)/2),p=r((n-e)/2),g=a((n-e)/2);switch(s){case"XYX":i.set(o*u,c*d,c*h,o*l);break;case"YZY":i.set(c*h,o*u,c*d,o*l);break;case"ZXZ":i.set(c*d,c*h,o*u,o*l);break;case"XZX":i.set(o*u,c*g,c*p,o*l);break;case"YXY":i.set(c*p,o*u,c*g,o*l);break;case"ZYZ":i.set(c*g,c*p,o*u,o*l);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+s)}}function Un(i,e){switch(e.constructor){case Float32Array:return i;case Uint32Array:return i/4294967295;case Uint16Array:return i/65535;case Uint8Array:return i/255;case Int32Array:return Math.max(i/2147483647,-1);case Int16Array:return Math.max(i/32767,-1);case Int8Array:return Math.max(i/127,-1);default:throw new Error("Invalid component type.")}}function ot(i,e){switch(e.constructor){case Float32Array:return i;case Uint32Array:return Math.round(i*4294967295);case Uint16Array:return Math.round(i*65535);case Uint8Array:return Math.round(i*255);case Int32Array:return Math.round(i*2147483647);case Int16Array:return Math.round(i*32767);case Int8Array:return Math.round(i*127);default:throw new Error("Invalid component type.")}}const _e={DEG2RAD:br,RAD2DEG:ks,generateUUID:Bn,clamp:Je,euclideanModulo:Uc,mapLinear:Yp,inverseLerp:jp,lerp:Mr,damp:$p,pingpong:Kp,smoothstep:Zp,smootherstep:Jp,randInt:Qp,randFloat:em,randFloatSpread:tm,seededRandom:nm,degToRad:im,radToDeg:sm,isPowerOfTwo:rm,ceilPowerOfTwo:am,floorPowerOfTwo:om,setQuaternionFromProperEuler:lm,normalize:ot,denormalize:Un};class Ie{constructor(e=0,t=0){Ie.prototype.isVector2=!0,this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const t=this.x,n=this.y,s=e.elements;return this.x=s[0]*t+s[3]*n+s[6],this.y=s[1]*t+s[4]*n+s[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Je(this.x,e.x,t.x),this.y=Je(this.y,e.y,t.y),this}clampScalar(e,t){return this.x=Je(this.x,e,t),this.y=Je(this.y,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Je(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(Je(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){const n=Math.cos(t),s=Math.sin(t),r=this.x-e.x,a=this.y-e.y;return this.x=r*n-a*s+e.x,this.y=r*s+a*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class dt{constructor(e=0,t=0,n=0,s=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=s}static slerpFlat(e,t,n,s,r,a,o){let c=n[s+0],l=n[s+1],u=n[s+2],d=n[s+3];const h=r[a+0],p=r[a+1],g=r[a+2],v=r[a+3];if(o===0){e[t+0]=c,e[t+1]=l,e[t+2]=u,e[t+3]=d;return}if(o===1){e[t+0]=h,e[t+1]=p,e[t+2]=g,e[t+3]=v;return}if(d!==v||c!==h||l!==p||u!==g){let m=1-o;const f=c*h+l*p+u*g+d*v,_=f>=0?1:-1,x=1-f*f;if(x>Number.EPSILON){const A=Math.sqrt(x),E=Math.atan2(A,f*_);m=Math.sin(m*E)/A,o=Math.sin(o*E)/A}const y=o*_;if(c=c*m+h*y,l=l*m+p*y,u=u*m+g*y,d=d*m+v*y,m===1-o){const A=1/Math.sqrt(c*c+l*l+u*u+d*d);c*=A,l*=A,u*=A,d*=A}}e[t]=c,e[t+1]=l,e[t+2]=u,e[t+3]=d}static multiplyQuaternionsFlat(e,t,n,s,r,a){const o=n[s],c=n[s+1],l=n[s+2],u=n[s+3],d=r[a],h=r[a+1],p=r[a+2],g=r[a+3];return e[t]=o*g+u*d+c*p-l*h,e[t+1]=c*g+u*h+l*d-o*p,e[t+2]=l*g+u*p+o*h-c*d,e[t+3]=u*g-o*d-c*h-l*p,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,s){return this._x=e,this._y=t,this._z=n,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){const n=e._x,s=e._y,r=e._z,a=e._order,o=Math.cos,c=Math.sin,l=o(n/2),u=o(s/2),d=o(r/2),h=c(n/2),p=c(s/2),g=c(r/2);switch(a){case"XYZ":this._x=h*u*d+l*p*g,this._y=l*p*d-h*u*g,this._z=l*u*g+h*p*d,this._w=l*u*d-h*p*g;break;case"YXZ":this._x=h*u*d+l*p*g,this._y=l*p*d-h*u*g,this._z=l*u*g-h*p*d,this._w=l*u*d+h*p*g;break;case"ZXY":this._x=h*u*d-l*p*g,this._y=l*p*d+h*u*g,this._z=l*u*g+h*p*d,this._w=l*u*d-h*p*g;break;case"ZYX":this._x=h*u*d-l*p*g,this._y=l*p*d+h*u*g,this._z=l*u*g-h*p*d,this._w=l*u*d+h*p*g;break;case"YZX":this._x=h*u*d+l*p*g,this._y=l*p*d+h*u*g,this._z=l*u*g-h*p*d,this._w=l*u*d-h*p*g;break;case"XZY":this._x=h*u*d-l*p*g,this._y=l*p*d-h*u*g,this._z=l*u*g+h*p*d,this._w=l*u*d+h*p*g;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+a)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){const n=t/2,s=Math.sin(n);return this._x=e.x*s,this._y=e.y*s,this._z=e.z*s,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){const t=e.elements,n=t[0],s=t[4],r=t[8],a=t[1],o=t[5],c=t[9],l=t[2],u=t[6],d=t[10],h=n+o+d;if(h>0){const p=.5/Math.sqrt(h+1);this._w=.25/p,this._x=(u-c)*p,this._y=(r-l)*p,this._z=(a-s)*p}else if(n>o&&n>d){const p=2*Math.sqrt(1+n-o-d);this._w=(u-c)/p,this._x=.25*p,this._y=(s+a)/p,this._z=(r+l)/p}else if(o>d){const p=2*Math.sqrt(1+o-n-d);this._w=(r-l)/p,this._x=(s+a)/p,this._y=.25*p,this._z=(c+u)/p}else{const p=2*Math.sqrt(1+d-n-o);this._w=(a-s)/p,this._x=(r+l)/p,this._y=(c+u)/p,this._z=.25*p}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;return n<1e-8?(n=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=n):(this._x=0,this._y=-e.z,this._z=e.y,this._w=n)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(Je(this.dot(e),-1,1)))}rotateTowards(e,t){const n=this.angleTo(e);if(n===0)return this;const s=Math.min(1,t/n);return this.slerp(e,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){const n=e._x,s=e._y,r=e._z,a=e._w,o=t._x,c=t._y,l=t._z,u=t._w;return this._x=n*u+a*o+s*l-r*c,this._y=s*u+a*c+r*o-n*l,this._z=r*u+a*l+n*c-s*o,this._w=a*u-n*o-s*c-r*l,this._onChangeCallback(),this}slerp(e,t){if(t===0)return this;if(t===1)return this.copy(e);const n=this._x,s=this._y,r=this._z,a=this._w;let o=a*e._w+n*e._x+s*e._y+r*e._z;if(o<0?(this._w=-e._w,this._x=-e._x,this._y=-e._y,this._z=-e._z,o=-o):this.copy(e),o>=1)return this._w=a,this._x=n,this._y=s,this._z=r,this;const c=1-o*o;if(c<=Number.EPSILON){const p=1-t;return this._w=p*a+t*this._w,this._x=p*n+t*this._x,this._y=p*s+t*this._y,this._z=p*r+t*this._z,this.normalize(),this}const l=Math.sqrt(c),u=Math.atan2(l,o),d=Math.sin((1-t)*u)/l,h=Math.sin(t*u)/l;return this._w=a*d+this._w*h,this._x=n*d+this._x*h,this._y=s*d+this._y*h,this._z=r*d+this._z*h,this._onChangeCallback(),this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){const e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),n=Math.random(),s=Math.sqrt(1-n),r=Math.sqrt(n);return this.set(s*Math.sin(e),s*Math.cos(e),r*Math.sin(t),r*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class N{constructor(e=0,t=0,n=0){N.prototype.isVector3=!0,this.x=e,this.y=t,this.z=n}set(e,t,n){return n===void 0&&(n=this.z),this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(Eu.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(Eu.setFromAxisAngle(e,t))}applyMatrix3(e){const t=this.x,n=this.y,s=this.z,r=e.elements;return this.x=r[0]*t+r[3]*n+r[6]*s,this.y=r[1]*t+r[4]*n+r[7]*s,this.z=r[2]*t+r[5]*n+r[8]*s,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const t=this.x,n=this.y,s=this.z,r=e.elements,a=1/(r[3]*t+r[7]*n+r[11]*s+r[15]);return this.x=(r[0]*t+r[4]*n+r[8]*s+r[12])*a,this.y=(r[1]*t+r[5]*n+r[9]*s+r[13])*a,this.z=(r[2]*t+r[6]*n+r[10]*s+r[14])*a,this}applyQuaternion(e){const t=this.x,n=this.y,s=this.z,r=e.x,a=e.y,o=e.z,c=e.w,l=2*(a*s-o*n),u=2*(o*t-r*s),d=2*(r*n-a*t);return this.x=t+c*l+a*d-o*u,this.y=n+c*u+o*l-r*d,this.z=s+c*d+r*u-a*l,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const t=this.x,n=this.y,s=this.z,r=e.elements;return this.x=r[0]*t+r[4]*n+r[8]*s,this.y=r[1]*t+r[5]*n+r[9]*s,this.z=r[2]*t+r[6]*n+r[10]*s,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Je(this.x,e.x,t.x),this.y=Je(this.y,e.y,t.y),this.z=Je(this.z,e.z,t.z),this}clampScalar(e,t){return this.x=Je(this.x,e,t),this.y=Je(this.y,e,t),this.z=Je(this.z,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Je(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){const n=e.x,s=e.y,r=e.z,a=t.x,o=t.y,c=t.z;return this.x=s*c-r*o,this.y=r*a-n*c,this.z=n*o-s*a,this}projectOnVector(e){const t=e.lengthSq();if(t===0)return this.set(0,0,0);const n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return Ro.copy(this).projectOnVector(e),this.sub(Ro)}reflect(e){return this.sub(Ro.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(Je(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y,s=this.z-e.z;return t*t+n*n+s*s}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,n){const s=Math.sin(t)*e;return this.x=s*Math.sin(n),this.y=Math.cos(t)*e,this.z=s*Math.cos(n),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){const t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),s=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=s,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,t=Math.random()*2-1,n=Math.sqrt(1-t*t);return this.x=n*Math.cos(e),this.y=t,this.z=n*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const Ro=new N,Eu=new dt;class $e{constructor(e,t,n,s,r,a,o,c,l){$e.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,n,s,r,a,o,c,l)}set(e,t,n,s,r,a,o,c,l){const u=this.elements;return u[0]=e,u[1]=s,u[2]=o,u[3]=t,u[4]=r,u[5]=c,u[6]=n,u[7]=a,u[8]=l,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,s=t.elements,r=this.elements,a=n[0],o=n[3],c=n[6],l=n[1],u=n[4],d=n[7],h=n[2],p=n[5],g=n[8],v=s[0],m=s[3],f=s[6],_=s[1],x=s[4],y=s[7],A=s[2],E=s[5],M=s[8];return r[0]=a*v+o*_+c*A,r[3]=a*m+o*x+c*E,r[6]=a*f+o*y+c*M,r[1]=l*v+u*_+d*A,r[4]=l*m+u*x+d*E,r[7]=l*f+u*y+d*M,r[2]=h*v+p*_+g*A,r[5]=h*m+p*x+g*E,r[8]=h*f+p*y+g*M,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[1],s=e[2],r=e[3],a=e[4],o=e[5],c=e[6],l=e[7],u=e[8];return t*a*u-t*o*l-n*r*u+n*o*c+s*r*l-s*a*c}invert(){const e=this.elements,t=e[0],n=e[1],s=e[2],r=e[3],a=e[4],o=e[5],c=e[6],l=e[7],u=e[8],d=u*a-o*l,h=o*c-u*r,p=l*r-a*c,g=t*d+n*h+s*p;if(g===0)return this.set(0,0,0,0,0,0,0,0,0);const v=1/g;return e[0]=d*v,e[1]=(s*l-u*n)*v,e[2]=(o*n-s*a)*v,e[3]=h*v,e[4]=(u*t-s*c)*v,e[5]=(s*r-o*t)*v,e[6]=p*v,e[7]=(n*c-l*t)*v,e[8]=(a*t-n*r)*v,this}transpose(){let e;const t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,s,r,a,o){const c=Math.cos(r),l=Math.sin(r);return this.set(n*c,n*l,-n*(c*a+l*o)+a+e,-s*l,s*c,-s*(-l*a+c*o)+o+t,0,0,1),this}scale(e,t){return this.premultiply(Co.makeScale(e,t)),this}rotate(e){return this.premultiply(Co.makeRotation(-e)),this}translate(e,t){return this.premultiply(Co.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){const t=this.elements,n=e.elements;for(let s=0;s<9;s++)if(t[s]!==n[s])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new this.constructor().fromArray(this.elements)}}const Co=new $e;function Yh(i){for(let e=i.length-1;e>=0;--e)if(i[e]>=65535)return!0;return!1}function Lr(i){return document.createElementNS("http://www.w3.org/1999/xhtml",i)}function cm(){const i=Lr("canvas");return i.style.display="block",i}const Tu={};function Dr(i){i in Tu||(Tu[i]=!0,console.warn(i))}function um(i,e,t){return new Promise(function(n,s){function r(){switch(i.clientWaitSync(e,i.SYNC_FLUSH_COMMANDS_BIT,0)){case i.WAIT_FAILED:s();break;case i.TIMEOUT_EXPIRED:setTimeout(r,t);break;default:n()}}setTimeout(r,t)})}const Au=new $e().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),wu=new $e().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function dm(){const i={enabled:!0,workingColorSpace:Qt,spaces:{},convert:function(s,r,a){return this.enabled===!1||r===a||!r||!a||(this.spaces[r].transfer===ft&&(s.r=hi(s.r),s.g=hi(s.g),s.b=hi(s.b)),this.spaces[r].primaries!==this.spaces[a].primaries&&(s.applyMatrix3(this.spaces[r].toXYZ),s.applyMatrix3(this.spaces[a].fromXYZ)),this.spaces[a].transfer===ft&&(s.r=Cs(s.r),s.g=Cs(s.g),s.b=Cs(s.b))),s},workingToColorSpace:function(s,r){return this.convert(s,this.workingColorSpace,r)},colorSpaceToWorking:function(s,r){return this.convert(s,r,this.workingColorSpace)},getPrimaries:function(s){return this.spaces[s].primaries},getTransfer:function(s){return s===oi?Wa:this.spaces[s].transfer},getToneMappingMode:function(s){return this.spaces[s].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(s,r=this.workingColorSpace){return s.fromArray(this.spaces[r].luminanceCoefficients)},define:function(s){Object.assign(this.spaces,s)},_getMatrix:function(s,r,a){return s.copy(this.spaces[r].toXYZ).multiply(this.spaces[a].fromXYZ)},_getDrawingBufferColorSpace:function(s){return this.spaces[s].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(s=this.workingColorSpace){return this.spaces[s].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(s,r){return Dr("THREE.ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),i.workingToColorSpace(s,r)},toWorkingColorSpace:function(s,r){return Dr("THREE.ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),i.colorSpaceToWorking(s,r)}},e=[.64,.33,.3,.6,.15,.06],t=[.2126,.7152,.0722],n=[.3127,.329];return i.define({[Qt]:{primaries:e,whitePoint:n,transfer:Wa,toXYZ:Au,fromXYZ:wu,luminanceCoefficients:t,workingColorSpaceConfig:{unpackColorSpace:_t},outputColorSpaceConfig:{drawingBufferColorSpace:_t}},[_t]:{primaries:e,whitePoint:n,transfer:ft,toXYZ:Au,fromXYZ:wu,luminanceCoefficients:t,outputColorSpaceConfig:{drawingBufferColorSpace:_t}}}),i}const tt=dm();function hi(i){return i<.04045?i*.0773993808:Math.pow(i*.9478672986+.0521327014,2.4)}function Cs(i){return i<.0031308?i*12.92:1.055*Math.pow(i,.41666)-.055}let is;class hm{static getDataURL(e,t="image/png"){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let n;if(e instanceof HTMLCanvasElement)n=e;else{is===void 0&&(is=Lr("canvas")),is.width=e.width,is.height=e.height;const s=is.getContext("2d");e instanceof ImageData?s.putImageData(e,0,0):s.drawImage(e,0,0,e.width,e.height),n=is}return n.toDataURL(t)}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const t=Lr("canvas");t.width=e.width,t.height=e.height;const n=t.getContext("2d");n.drawImage(e,0,0,e.width,e.height);const s=n.getImageData(0,0,e.width,e.height),r=s.data;for(let a=0;a<r.length;a++)r[a]=hi(r[a]/255)*255;return n.putImageData(s,0,0),t}else if(e.data){const t=e.data.slice(0);for(let n=0;n<t.length;n++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[n]=Math.floor(hi(t[n]/255)*255):t[n]=hi(t[n]);return{data:t,width:e.width,height:e.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let fm=0;class Fc{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:fm++}),this.uuid=Bn(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){const t=this.data;return typeof HTMLVideoElement<"u"&&t instanceof HTMLVideoElement?e.set(t.videoWidth,t.videoHeight,0):t instanceof VideoFrame?e.set(t.displayHeight,t.displayWidth,0):t!==null?e.set(t.width,t.height,t.depth||0):e.set(0,0,0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const n={uuid:this.uuid,url:""},s=this.data;if(s!==null){let r;if(Array.isArray(s)){r=[];for(let a=0,o=s.length;a<o;a++)s[a].isDataTexture?r.push(Io(s[a].image)):r.push(Io(s[a]))}else r=Io(s);n.url=r}return t||(e.images[this.uuid]=n),n}}function Io(i){return typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&i instanceof ImageBitmap?hm.getDataURL(i):i.data?{data:Array.from(i.data),width:i.width,height:i.height,type:i.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}let pm=0;const Po=new N;class Ft extends $s{constructor(e=Ft.DEFAULT_IMAGE,t=Ft.DEFAULT_MAPPING,n=Ri,s=Ri,r=Lt,a=Gt,o=An,c=qn,l=Ft.DEFAULT_ANISOTROPY,u=oi){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:pm++}),this.uuid=Bn(),this.name="",this.source=new Fc(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=n,this.wrapT=s,this.magFilter=r,this.minFilter=a,this.anisotropy=l,this.format=o,this.internalFormat=null,this.type=c,this.offset=new Ie(0,0),this.repeat=new Ie(1,1),this.center=new Ie(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new $e,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=u,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0}get width(){return this.source.getSize(Po).x}get height(){return this.source.getSize(Po).y}get depth(){return this.source.getSize(Po).z}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(const t in e){const n=e[t];if(n===void 0){console.warn(`THREE.Texture.setValues(): parameter '${t}' has value of undefined.`);continue}const s=this[t];if(s===void 0){console.warn(`THREE.Texture.setValues(): property '${t}' does not exist.`);continue}s&&n&&s.isVector2&&n.isVector2||s&&n&&s.isVector3&&n.isVector3||s&&n&&s.isMatrix3&&n.isMatrix3?s.copy(n):this[t]=n}}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const n={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),t||(e.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==Oh)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Bs:e.x=e.x-Math.floor(e.x);break;case Ri:e.x=e.x<0?0:1;break;case Ga:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case Bs:e.y=e.y-Math.floor(e.y);break;case Ri:e.y=e.y<0?0:1;break;case Ga:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}Ft.DEFAULT_IMAGE=null;Ft.DEFAULT_MAPPING=Oh;Ft.DEFAULT_ANISOTROPY=1;class st{constructor(e=0,t=0,n=0,s=1){st.prototype.isVector4=!0,this.x=e,this.y=t,this.z=n,this.w=s}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,s){return this.x=e,this.y=t,this.z=n,this.w=s,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const t=this.x,n=this.y,s=this.z,r=this.w,a=e.elements;return this.x=a[0]*t+a[4]*n+a[8]*s+a[12]*r,this.y=a[1]*t+a[5]*n+a[9]*s+a[13]*r,this.z=a[2]*t+a[6]*n+a[10]*s+a[14]*r,this.w=a[3]*t+a[7]*n+a[11]*s+a[15]*r,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,n,s,r;const c=e.elements,l=c[0],u=c[4],d=c[8],h=c[1],p=c[5],g=c[9],v=c[2],m=c[6],f=c[10];if(Math.abs(u-h)<.01&&Math.abs(d-v)<.01&&Math.abs(g-m)<.01){if(Math.abs(u+h)<.1&&Math.abs(d+v)<.1&&Math.abs(g+m)<.1&&Math.abs(l+p+f-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;const x=(l+1)/2,y=(p+1)/2,A=(f+1)/2,E=(u+h)/4,M=(d+v)/4,C=(g+m)/4;return x>y&&x>A?x<.01?(n=0,s=.707106781,r=.707106781):(n=Math.sqrt(x),s=E/n,r=M/n):y>A?y<.01?(n=.707106781,s=0,r=.707106781):(s=Math.sqrt(y),n=E/s,r=C/s):A<.01?(n=.707106781,s=.707106781,r=0):(r=Math.sqrt(A),n=M/r,s=C/r),this.set(n,s,r,t),this}let _=Math.sqrt((m-g)*(m-g)+(d-v)*(d-v)+(h-u)*(h-u));return Math.abs(_)<.001&&(_=1),this.x=(m-g)/_,this.y=(d-v)/_,this.z=(h-u)/_,this.w=Math.acos((l+p+f-1)/2),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Je(this.x,e.x,t.x),this.y=Je(this.y,e.y,t.y),this.z=Je(this.z,e.z,t.z),this.w=Je(this.w,e.w,t.w),this}clampScalar(e,t){return this.x=Je(this.x,e,t),this.y=Je(this.y,e,t),this.z=Je(this.z,e,t),this.w=Je(this.w,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Je(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class mm extends $s{constructor(e=1,t=1,n={}){super(),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Lt,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1},n),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=n.depth,this.scissor=new st(0,0,e,t),this.scissorTest=!1,this.viewport=new st(0,0,e,t);const s={width:e,height:t,depth:n.depth},r=new Ft(s);this.textures=[];const a=n.count;for(let o=0;o<a;o++)this.textures[o]=r.clone(),this.textures[o].isRenderTargetTexture=!0,this.textures[o].renderTarget=this;this._setTextureOptions(n),this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=n.depthTexture,this.samples=n.samples,this.multiview=n.multiview}_setTextureOptions(e={}){const t={minFilter:Lt,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(t.mapping=e.mapping),e.wrapS!==void 0&&(t.wrapS=e.wrapS),e.wrapT!==void 0&&(t.wrapT=e.wrapT),e.wrapR!==void 0&&(t.wrapR=e.wrapR),e.magFilter!==void 0&&(t.magFilter=e.magFilter),e.minFilter!==void 0&&(t.minFilter=e.minFilter),e.format!==void 0&&(t.format=e.format),e.type!==void 0&&(t.type=e.type),e.anisotropy!==void 0&&(t.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(t.colorSpace=e.colorSpace),e.flipY!==void 0&&(t.flipY=e.flipY),e.generateMipmaps!==void 0&&(t.generateMipmaps=e.generateMipmaps),e.internalFormat!==void 0&&(t.internalFormat=e.internalFormat);for(let n=0;n<this.textures.length;n++)this.textures[n].setValues(t)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),e!==null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,t,n=1){if(this.width!==e||this.height!==t||this.depth!==n){this.width=e,this.height=t,this.depth=n;for(let s=0,r=this.textures.length;s<r;s++)this.textures[s].image.width=e,this.textures[s].image.height=t,this.textures[s].image.depth=n,this.textures[s].isArrayTexture=this.textures[s].image.depth>1;this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let t=0,n=e.textures.length;t<n;t++){this.textures[t]=e.textures[t].clone(),this.textures[t].isRenderTargetTexture=!0,this.textures[t].renderTarget=this;const s=Object.assign({},e.textures[t].image);this.textures[t].source=new Fc(s)}return this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class kn extends mm{constructor(e=1,t=1,n={}){super(e,t,n),this.isWebGLRenderTarget=!0}}class jh extends Ft{constructor(e=null,t=1,n=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:n,depth:s},this.magFilter=Jt,this.minFilter=Jt,this.wrapR=Ri,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class gm extends Ft{constructor(e=null,t=1,n=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:n,depth:s},this.magFilter=Jt,this.minFilter=Jt,this.wrapR=Ri,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class jn{constructor(e=new N(1/0,1/0,1/0),t=new N(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t+=3)this.expandByPoint(Dn.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,n=e.count;t<n;t++)this.expandByPoint(Dn.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const n=Dn.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);const n=e.geometry;if(n!==void 0){const r=n.getAttribute("position");if(t===!0&&r!==void 0&&e.isInstancedMesh!==!0)for(let a=0,o=r.count;a<o;a++)e.isMesh===!0?e.getVertexPosition(a,Dn):Dn.fromBufferAttribute(r,a),Dn.applyMatrix4(e.matrixWorld),this.expandByPoint(Dn);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),Jr.copy(e.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),Jr.copy(n.boundingBox)),Jr.applyMatrix4(e.matrixWorld),this.union(Jr)}const s=e.children;for(let r=0,a=s.length;r<a;r++)this.expandByObject(s[r],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,Dn),Dn.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,n;return e.normal.x>0?(t=e.normal.x*this.min.x,n=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,n=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,n+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,n+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,n+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,n+=e.normal.z*this.min.z),t<=-e.constant&&n>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(ir),Qr.subVectors(this.max,ir),ss.subVectors(e.a,ir),rs.subVectors(e.b,ir),as.subVectors(e.c,ir),pi.subVectors(rs,ss),mi.subVectors(as,rs),Fi.subVectors(ss,as);let t=[0,-pi.z,pi.y,0,-mi.z,mi.y,0,-Fi.z,Fi.y,pi.z,0,-pi.x,mi.z,0,-mi.x,Fi.z,0,-Fi.x,-pi.y,pi.x,0,-mi.y,mi.x,0,-Fi.y,Fi.x,0];return!Lo(t,ss,rs,as,Qr)||(t=[1,0,0,0,1,0,0,0,1],!Lo(t,ss,rs,as,Qr))?!1:(ea.crossVectors(pi,mi),t=[ea.x,ea.y,ea.z],Lo(t,ss,rs,as,Qr))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Dn).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(Dn).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(Jn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),Jn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),Jn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),Jn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),Jn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),Jn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),Jn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),Jn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(Jn),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}}const Jn=[new N,new N,new N,new N,new N,new N,new N,new N],Dn=new N,Jr=new jn,ss=new N,rs=new N,as=new N,pi=new N,mi=new N,Fi=new N,ir=new N,Qr=new N,ea=new N,Bi=new N;function Lo(i,e,t,n,s){for(let r=0,a=i.length-3;r<=a;r+=3){Bi.fromArray(i,r);const o=s.x*Math.abs(Bi.x)+s.y*Math.abs(Bi.y)+s.z*Math.abs(Bi.z),c=e.dot(Bi),l=t.dot(Bi),u=n.dot(Bi);if(Math.max(-Math.max(c,l,u),Math.min(c,l,u))>o)return!1}return!0}const vm=new jn,sr=new N,Do=new N;class $n{constructor(e=new N,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){const n=this.center;t!==void 0?n.copy(t):vm.setFromPoints(e).getCenter(n);let s=0;for(let r=0,a=e.length;r<a;r++)s=Math.max(s,n.distanceToSquared(e[r]));return this.radius=Math.sqrt(s),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){const n=this.center.distanceToSquared(e);return t.copy(e),n>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;sr.subVectors(e,this.center);const t=sr.lengthSq();if(t>this.radius*this.radius){const n=Math.sqrt(t),s=(n-this.radius)*.5;this.center.addScaledVector(sr,s/n),this.radius+=s}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Do.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(sr.copy(e.center).add(Do)),this.expandByPoint(sr.copy(e.center).sub(Do))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}}const Qn=new N,No=new N,ta=new N,gi=new N,Oo=new N,na=new N,Uo=new N;class Fr{constructor(e=new N,t=new N(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,Qn)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);const n=t.dot(this.direction);return n<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const t=Qn.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(Qn.copy(this.origin).addScaledVector(this.direction,t),Qn.distanceToSquared(e))}distanceSqToSegment(e,t,n,s){No.copy(e).add(t).multiplyScalar(.5),ta.copy(t).sub(e).normalize(),gi.copy(this.origin).sub(No);const r=e.distanceTo(t)*.5,a=-this.direction.dot(ta),o=gi.dot(this.direction),c=-gi.dot(ta),l=gi.lengthSq(),u=Math.abs(1-a*a);let d,h,p,g;if(u>0)if(d=a*c-o,h=a*o-c,g=r*u,d>=0)if(h>=-g)if(h<=g){const v=1/u;d*=v,h*=v,p=d*(d+a*h+2*o)+h*(a*d+h+2*c)+l}else h=r,d=Math.max(0,-(a*h+o)),p=-d*d+h*(h+2*c)+l;else h=-r,d=Math.max(0,-(a*h+o)),p=-d*d+h*(h+2*c)+l;else h<=-g?(d=Math.max(0,-(-a*r+o)),h=d>0?-r:Math.min(Math.max(-r,-c),r),p=-d*d+h*(h+2*c)+l):h<=g?(d=0,h=Math.min(Math.max(-r,-c),r),p=h*(h+2*c)+l):(d=Math.max(0,-(a*r+o)),h=d>0?r:Math.min(Math.max(-r,-c),r),p=-d*d+h*(h+2*c)+l);else h=a>0?-r:r,d=Math.max(0,-(a*h+o)),p=-d*d+h*(h+2*c)+l;return n&&n.copy(this.origin).addScaledVector(this.direction,d),s&&s.copy(No).addScaledVector(ta,h),p}intersectSphere(e,t){Qn.subVectors(e.center,this.origin);const n=Qn.dot(this.direction),s=Qn.dot(Qn)-n*n,r=e.radius*e.radius;if(s>r)return null;const a=Math.sqrt(r-s),o=n-a,c=n+a;return c<0?null:o<0?this.at(c,t):this.at(o,t)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;const n=-(this.origin.dot(e.normal)+e.constant)/t;return n>=0?n:null}intersectPlane(e,t){const n=this.distanceToPlane(e);return n===null?null:this.at(n,t)}intersectsPlane(e){const t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let n,s,r,a,o,c;const l=1/this.direction.x,u=1/this.direction.y,d=1/this.direction.z,h=this.origin;return l>=0?(n=(e.min.x-h.x)*l,s=(e.max.x-h.x)*l):(n=(e.max.x-h.x)*l,s=(e.min.x-h.x)*l),u>=0?(r=(e.min.y-h.y)*u,a=(e.max.y-h.y)*u):(r=(e.max.y-h.y)*u,a=(e.min.y-h.y)*u),n>a||r>s||((r>n||isNaN(n))&&(n=r),(a<s||isNaN(s))&&(s=a),d>=0?(o=(e.min.z-h.z)*d,c=(e.max.z-h.z)*d):(o=(e.max.z-h.z)*d,c=(e.min.z-h.z)*d),n>c||o>s)||((o>n||n!==n)&&(n=o),(c<s||s!==s)&&(s=c),s<0)?null:this.at(n>=0?n:s,t)}intersectsBox(e){return this.intersectBox(e,Qn)!==null}intersectTriangle(e,t,n,s,r){Oo.subVectors(t,e),na.subVectors(n,e),Uo.crossVectors(Oo,na);let a=this.direction.dot(Uo),o;if(a>0){if(s)return null;o=1}else if(a<0)o=-1,a=-a;else return null;gi.subVectors(this.origin,e);const c=o*this.direction.dot(na.crossVectors(gi,na));if(c<0)return null;const l=o*this.direction.dot(Oo.cross(gi));if(l<0||c+l>a)return null;const u=-o*gi.dot(Uo);return u<0?null:this.at(u/a,r)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class Ye{constructor(e,t,n,s,r,a,o,c,l,u,d,h,p,g,v,m){Ye.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,n,s,r,a,o,c,l,u,d,h,p,g,v,m)}set(e,t,n,s,r,a,o,c,l,u,d,h,p,g,v,m){const f=this.elements;return f[0]=e,f[4]=t,f[8]=n,f[12]=s,f[1]=r,f[5]=a,f[9]=o,f[13]=c,f[2]=l,f[6]=u,f[10]=d,f[14]=h,f[3]=p,f[7]=g,f[11]=v,f[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new Ye().fromArray(this.elements)}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){const t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){const t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){return e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){const t=this.elements,n=e.elements,s=1/os.setFromMatrixColumn(e,0).length(),r=1/os.setFromMatrixColumn(e,1).length(),a=1/os.setFromMatrixColumn(e,2).length();return t[0]=n[0]*s,t[1]=n[1]*s,t[2]=n[2]*s,t[3]=0,t[4]=n[4]*r,t[5]=n[5]*r,t[6]=n[6]*r,t[7]=0,t[8]=n[8]*a,t[9]=n[9]*a,t[10]=n[10]*a,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){const t=this.elements,n=e.x,s=e.y,r=e.z,a=Math.cos(n),o=Math.sin(n),c=Math.cos(s),l=Math.sin(s),u=Math.cos(r),d=Math.sin(r);if(e.order==="XYZ"){const h=a*u,p=a*d,g=o*u,v=o*d;t[0]=c*u,t[4]=-c*d,t[8]=l,t[1]=p+g*l,t[5]=h-v*l,t[9]=-o*c,t[2]=v-h*l,t[6]=g+p*l,t[10]=a*c}else if(e.order==="YXZ"){const h=c*u,p=c*d,g=l*u,v=l*d;t[0]=h+v*o,t[4]=g*o-p,t[8]=a*l,t[1]=a*d,t[5]=a*u,t[9]=-o,t[2]=p*o-g,t[6]=v+h*o,t[10]=a*c}else if(e.order==="ZXY"){const h=c*u,p=c*d,g=l*u,v=l*d;t[0]=h-v*o,t[4]=-a*d,t[8]=g+p*o,t[1]=p+g*o,t[5]=a*u,t[9]=v-h*o,t[2]=-a*l,t[6]=o,t[10]=a*c}else if(e.order==="ZYX"){const h=a*u,p=a*d,g=o*u,v=o*d;t[0]=c*u,t[4]=g*l-p,t[8]=h*l+v,t[1]=c*d,t[5]=v*l+h,t[9]=p*l-g,t[2]=-l,t[6]=o*c,t[10]=a*c}else if(e.order==="YZX"){const h=a*c,p=a*l,g=o*c,v=o*l;t[0]=c*u,t[4]=v-h*d,t[8]=g*d+p,t[1]=d,t[5]=a*u,t[9]=-o*u,t[2]=-l*u,t[6]=p*d+g,t[10]=h-v*d}else if(e.order==="XZY"){const h=a*c,p=a*l,g=o*c,v=o*l;t[0]=c*u,t[4]=-d,t[8]=l*u,t[1]=h*d+v,t[5]=a*u,t[9]=p*d-g,t[2]=g*d-p,t[6]=o*u,t[10]=v*d+h}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(_m,e,xm)}lookAt(e,t,n){const s=this.elements;return dn.subVectors(e,t),dn.lengthSq()===0&&(dn.z=1),dn.normalize(),vi.crossVectors(n,dn),vi.lengthSq()===0&&(Math.abs(n.z)===1?dn.x+=1e-4:dn.z+=1e-4,dn.normalize(),vi.crossVectors(n,dn)),vi.normalize(),ia.crossVectors(dn,vi),s[0]=vi.x,s[4]=ia.x,s[8]=dn.x,s[1]=vi.y,s[5]=ia.y,s[9]=dn.y,s[2]=vi.z,s[6]=ia.z,s[10]=dn.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,s=t.elements,r=this.elements,a=n[0],o=n[4],c=n[8],l=n[12],u=n[1],d=n[5],h=n[9],p=n[13],g=n[2],v=n[6],m=n[10],f=n[14],_=n[3],x=n[7],y=n[11],A=n[15],E=s[0],M=s[4],C=s[8],b=s[12],S=s[1],I=s[5],D=s[9],w=s[13],U=s[2],O=s[6],F=s[10],V=s[14],k=s[3],z=s[7],B=s[11],j=s[15];return r[0]=a*E+o*S+c*U+l*k,r[4]=a*M+o*I+c*O+l*z,r[8]=a*C+o*D+c*F+l*B,r[12]=a*b+o*w+c*V+l*j,r[1]=u*E+d*S+h*U+p*k,r[5]=u*M+d*I+h*O+p*z,r[9]=u*C+d*D+h*F+p*B,r[13]=u*b+d*w+h*V+p*j,r[2]=g*E+v*S+m*U+f*k,r[6]=g*M+v*I+m*O+f*z,r[10]=g*C+v*D+m*F+f*B,r[14]=g*b+v*w+m*V+f*j,r[3]=_*E+x*S+y*U+A*k,r[7]=_*M+x*I+y*O+A*z,r[11]=_*C+x*D+y*F+A*B,r[15]=_*b+x*w+y*V+A*j,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[4],s=e[8],r=e[12],a=e[1],o=e[5],c=e[9],l=e[13],u=e[2],d=e[6],h=e[10],p=e[14],g=e[3],v=e[7],m=e[11],f=e[15];return g*(+r*c*d-s*l*d-r*o*h+n*l*h+s*o*p-n*c*p)+v*(+t*c*p-t*l*h+r*a*h-s*a*p+s*l*u-r*c*u)+m*(+t*l*d-t*o*p-r*a*d+n*a*p+r*o*u-n*l*u)+f*(-s*o*u-t*c*d+t*o*h+s*a*d-n*a*h+n*c*u)}transpose(){const e=this.elements;let t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){const s=this.elements;return e.isVector3?(s[12]=e.x,s[13]=e.y,s[14]=e.z):(s[12]=e,s[13]=t,s[14]=n),this}invert(){const e=this.elements,t=e[0],n=e[1],s=e[2],r=e[3],a=e[4],o=e[5],c=e[6],l=e[7],u=e[8],d=e[9],h=e[10],p=e[11],g=e[12],v=e[13],m=e[14],f=e[15],_=d*m*l-v*h*l+v*c*p-o*m*p-d*c*f+o*h*f,x=g*h*l-u*m*l-g*c*p+a*m*p+u*c*f-a*h*f,y=u*v*l-g*d*l+g*o*p-a*v*p-u*o*f+a*d*f,A=g*d*c-u*v*c-g*o*h+a*v*h+u*o*m-a*d*m,E=t*_+n*x+s*y+r*A;if(E===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const M=1/E;return e[0]=_*M,e[1]=(v*h*r-d*m*r-v*s*p+n*m*p+d*s*f-n*h*f)*M,e[2]=(o*m*r-v*c*r+v*s*l-n*m*l-o*s*f+n*c*f)*M,e[3]=(d*c*r-o*h*r-d*s*l+n*h*l+o*s*p-n*c*p)*M,e[4]=x*M,e[5]=(u*m*r-g*h*r+g*s*p-t*m*p-u*s*f+t*h*f)*M,e[6]=(g*c*r-a*m*r-g*s*l+t*m*l+a*s*f-t*c*f)*M,e[7]=(a*h*r-u*c*r+u*s*l-t*h*l-a*s*p+t*c*p)*M,e[8]=y*M,e[9]=(g*d*r-u*v*r-g*n*p+t*v*p+u*n*f-t*d*f)*M,e[10]=(a*v*r-g*o*r+g*n*l-t*v*l-a*n*f+t*o*f)*M,e[11]=(u*o*r-a*d*r-u*n*l+t*d*l+a*n*p-t*o*p)*M,e[12]=A*M,e[13]=(u*v*s-g*d*s+g*n*h-t*v*h-u*n*m+t*d*m)*M,e[14]=(g*o*s-a*v*s-g*n*c+t*v*c+a*n*m-t*o*m)*M,e[15]=(a*d*s-u*o*s+u*n*c-t*d*c-a*n*h+t*o*h)*M,this}scale(e){const t=this.elements,n=e.x,s=e.y,r=e.z;return t[0]*=n,t[4]*=s,t[8]*=r,t[1]*=n,t[5]*=s,t[9]*=r,t[2]*=n,t[6]*=s,t[10]*=r,t[3]*=n,t[7]*=s,t[11]*=r,this}getMaxScaleOnAxis(){const e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],s=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,s))}makeTranslation(e,t,n){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1),this}makeRotationX(e){const t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){const n=Math.cos(t),s=Math.sin(t),r=1-n,a=e.x,o=e.y,c=e.z,l=r*a,u=r*o;return this.set(l*a+n,l*o-s*c,l*c+s*o,0,l*o+s*c,u*o+n,u*c-s*a,0,l*c-s*o,u*c+s*a,r*c*c+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,s,r,a){return this.set(1,n,r,0,e,1,a,0,t,s,1,0,0,0,0,1),this}compose(e,t,n){const s=this.elements,r=t._x,a=t._y,o=t._z,c=t._w,l=r+r,u=a+a,d=o+o,h=r*l,p=r*u,g=r*d,v=a*u,m=a*d,f=o*d,_=c*l,x=c*u,y=c*d,A=n.x,E=n.y,M=n.z;return s[0]=(1-(v+f))*A,s[1]=(p+y)*A,s[2]=(g-x)*A,s[3]=0,s[4]=(p-y)*E,s[5]=(1-(h+f))*E,s[6]=(m+_)*E,s[7]=0,s[8]=(g+x)*M,s[9]=(m-_)*M,s[10]=(1-(h+v))*M,s[11]=0,s[12]=e.x,s[13]=e.y,s[14]=e.z,s[15]=1,this}decompose(e,t,n){const s=this.elements;let r=os.set(s[0],s[1],s[2]).length();const a=os.set(s[4],s[5],s[6]).length(),o=os.set(s[8],s[9],s[10]).length();this.determinant()<0&&(r=-r),e.x=s[12],e.y=s[13],e.z=s[14],Nn.copy(this);const l=1/r,u=1/a,d=1/o;return Nn.elements[0]*=l,Nn.elements[1]*=l,Nn.elements[2]*=l,Nn.elements[4]*=u,Nn.elements[5]*=u,Nn.elements[6]*=u,Nn.elements[8]*=d,Nn.elements[9]*=d,Nn.elements[10]*=d,t.setFromRotationMatrix(Nn),n.x=r,n.y=a,n.z=o,this}makePerspective(e,t,n,s,r,a,o=Wn,c=!1){const l=this.elements,u=2*r/(t-e),d=2*r/(n-s),h=(t+e)/(t-e),p=(n+s)/(n-s);let g,v;if(c)g=r/(a-r),v=a*r/(a-r);else if(o===Wn)g=-(a+r)/(a-r),v=-2*a*r/(a-r);else if(o===Xa)g=-a/(a-r),v=-a*r/(a-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return l[0]=u,l[4]=0,l[8]=h,l[12]=0,l[1]=0,l[5]=d,l[9]=p,l[13]=0,l[2]=0,l[6]=0,l[10]=g,l[14]=v,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(e,t,n,s,r,a,o=Wn,c=!1){const l=this.elements,u=2/(t-e),d=2/(n-s),h=-(t+e)/(t-e),p=-(n+s)/(n-s);let g,v;if(c)g=1/(a-r),v=a/(a-r);else if(o===Wn)g=-2/(a-r),v=-(a+r)/(a-r);else if(o===Xa)g=-1/(a-r),v=-r/(a-r);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return l[0]=u,l[4]=0,l[8]=0,l[12]=h,l[1]=0,l[5]=d,l[9]=0,l[13]=p,l[2]=0,l[6]=0,l[10]=g,l[14]=v,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(e){const t=this.elements,n=e.elements;for(let s=0;s<16;s++)if(t[s]!==n[s])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}}const os=new N,Nn=new Ye,_m=new N(0,0,0),xm=new N(1,1,1),vi=new N,ia=new N,dn=new N,Ru=new Ye,Cu=new dt;class vn{constructor(e=0,t=0,n=0,s=vn.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=n,this._order=s}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,s=this._order){return this._x=e,this._y=t,this._z=n,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){const s=e.elements,r=s[0],a=s[4],o=s[8],c=s[1],l=s[5],u=s[9],d=s[2],h=s[6],p=s[10];switch(t){case"XYZ":this._y=Math.asin(Je(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-u,p),this._z=Math.atan2(-a,r)):(this._x=Math.atan2(h,l),this._z=0);break;case"YXZ":this._x=Math.asin(-Je(u,-1,1)),Math.abs(u)<.9999999?(this._y=Math.atan2(o,p),this._z=Math.atan2(c,l)):(this._y=Math.atan2(-d,r),this._z=0);break;case"ZXY":this._x=Math.asin(Je(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(-d,p),this._z=Math.atan2(-a,l)):(this._y=0,this._z=Math.atan2(c,r));break;case"ZYX":this._y=Math.asin(-Je(d,-1,1)),Math.abs(d)<.9999999?(this._x=Math.atan2(h,p),this._z=Math.atan2(c,r)):(this._x=0,this._z=Math.atan2(-a,l));break;case"YZX":this._z=Math.asin(Je(c,-1,1)),Math.abs(c)<.9999999?(this._x=Math.atan2(-u,l),this._y=Math.atan2(-d,r)):(this._x=0,this._y=Math.atan2(o,p));break;case"XZY":this._z=Math.asin(-Je(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(h,l),this._y=Math.atan2(o,r)):(this._x=Math.atan2(-u,p),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,n===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,n){return Ru.makeRotationFromQuaternion(e),this.setFromRotationMatrix(Ru,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return Cu.setFromEuler(this),this.setFromQuaternion(Cu,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}vn.DEFAULT_ORDER="XYZ";class Bc{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let ym=0;const Iu=new N,ls=new dt,ei=new Ye,sa=new N,rr=new N,Sm=new N,bm=new dt,Pu=new N(1,0,0),Lu=new N(0,1,0),Du=new N(0,0,1),Nu={type:"added"},Mm={type:"removed"},cs={type:"childadded",child:null},Fo={type:"childremoved",child:null};class bt extends $s{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:ym++}),this.uuid=Bn(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=bt.DEFAULT_UP.clone();const e=new N,t=new vn,n=new dt,s=new N(1,1,1);function r(){n.setFromEuler(t,!1)}function a(){t.setFromQuaternion(n,void 0,!1)}t._onChange(r),n._onChange(a),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new Ye},normalMatrix:{value:new $e}}),this.matrix=new Ye,this.matrixWorld=new Ye,this.matrixAutoUpdate=bt.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=bt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Bc,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return ls.setFromAxisAngle(e,t),this.quaternion.multiply(ls),this}rotateOnWorldAxis(e,t){return ls.setFromAxisAngle(e,t),this.quaternion.premultiply(ls),this}rotateX(e){return this.rotateOnAxis(Pu,e)}rotateY(e){return this.rotateOnAxis(Lu,e)}rotateZ(e){return this.rotateOnAxis(Du,e)}translateOnAxis(e,t){return Iu.copy(e).applyQuaternion(this.quaternion),this.position.add(Iu.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(Pu,e)}translateY(e){return this.translateOnAxis(Lu,e)}translateZ(e){return this.translateOnAxis(Du,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(ei.copy(this.matrixWorld).invert())}lookAt(e,t,n){e.isVector3?sa.copy(e):sa.set(e,t,n);const s=this.parent;this.updateWorldMatrix(!0,!1),rr.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?ei.lookAt(rr,sa,this.up):ei.lookAt(sa,rr,this.up),this.quaternion.setFromRotationMatrix(ei),s&&(ei.extractRotation(s.matrixWorld),ls.setFromRotationMatrix(ei),this.quaternion.premultiply(ls.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(Nu),cs.child=e,this.dispatchEvent(cs),cs.child=null):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}const t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(Mm),Fo.child=e,this.dispatchEvent(Fo),Fo.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),ei.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),ei.multiply(e.parent.matrixWorld)),e.applyMatrix4(ei),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(Nu),cs.child=e,this.dispatchEvent(cs),cs.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let n=0,s=this.children.length;n<s;n++){const a=this.children[n].getObjectByProperty(e,t);if(a!==void 0)return a}}getObjectsByProperty(e,t,n=[]){this[e]===t&&n.push(this);const s=this.children;for(let r=0,a=s.length;r<a;r++)s[r].getObjectsByProperty(e,t,n);return n}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(rr,e,Sm),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(rr,bm,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);const t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].traverseVisible(e)}traverseAncestors(e){const t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].updateMatrixWorld(e)}updateWorldMatrix(e,t){const n=this.parent;if(e===!0&&n!==null&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),t===!0){const s=this.children;for(let r=0,a=s.length;r<a;r++)s[r].updateWorldMatrix(!1,!0)}}toJSON(e){const t=e===void 0||typeof e=="string",n={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const s={};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.castShadow===!0&&(s.castShadow=!0),this.receiveShadow===!0&&(s.receiveShadow=!0),this.visible===!1&&(s.visible=!1),this.frustumCulled===!1&&(s.frustumCulled=!1),this.renderOrder!==0&&(s.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(s.matrixAutoUpdate=!1),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.geometryInfo=this._geometryInfo.map(o=>({...o,boundingBox:o.boundingBox?o.boundingBox.toJSON():void 0,boundingSphere:o.boundingSphere?o.boundingSphere.toJSON():void 0})),s.instanceInfo=this._instanceInfo.map(o=>({...o})),s.availableInstanceIds=this._availableInstanceIds.slice(),s.availableGeometryIds=this._availableGeometryIds.slice(),s.nextIndexStart=this._nextIndexStart,s.nextVertexStart=this._nextVertexStart,s.geometryCount=this._geometryCount,s.maxInstanceCount=this._maxInstanceCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.matricesTexture=this._matricesTexture.toJSON(e),s.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(s.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(s.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(s.boundingBox=this.boundingBox.toJSON()));function r(o,c){return o[c.uuid]===void 0&&(o[c.uuid]=c.toJSON(e)),c.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=r(e.geometries,this.geometry);const o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){const c=o.shapes;if(Array.isArray(c))for(let l=0,u=c.length;l<u;l++){const d=c[l];r(e.shapes,d)}else r(e.shapes,c)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(e.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const o=[];for(let c=0,l=this.material.length;c<l;c++)o.push(r(e.materials,this.material[c]));s.material=o}else s.material=r(e.materials,this.material);if(this.children.length>0){s.children=[];for(let o=0;o<this.children.length;o++)s.children.push(this.children[o].toJSON(e).object)}if(this.animations.length>0){s.animations=[];for(let o=0;o<this.animations.length;o++){const c=this.animations[o];s.animations.push(r(e.animations,c))}}if(t){const o=a(e.geometries),c=a(e.materials),l=a(e.textures),u=a(e.images),d=a(e.shapes),h=a(e.skeletons),p=a(e.animations),g=a(e.nodes);o.length>0&&(n.geometries=o),c.length>0&&(n.materials=c),l.length>0&&(n.textures=l),u.length>0&&(n.images=u),d.length>0&&(n.shapes=d),h.length>0&&(n.skeletons=h),p.length>0&&(n.animations=p),g.length>0&&(n.nodes=g)}return n.object=s,n;function a(o){const c=[];for(const l in o){const u=o[l];delete u.metadata,c.push(u)}return c}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let n=0;n<e.children.length;n++){const s=e.children[n];this.add(s.clone())}return this}}bt.DEFAULT_UP=new N(0,1,0);bt.DEFAULT_MATRIX_AUTO_UPDATE=!0;bt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const On=new N,ti=new N,Bo=new N,ni=new N,us=new N,ds=new N,Ou=new N,ko=new N,zo=new N,Vo=new N,Ho=new st,Go=new st,Wo=new st;class Tn{constructor(e=new N,t=new N,n=new N){this.a=e,this.b=t,this.c=n}static getNormal(e,t,n,s){s.subVectors(n,t),On.subVectors(e,t),s.cross(On);const r=s.lengthSq();return r>0?s.multiplyScalar(1/Math.sqrt(r)):s.set(0,0,0)}static getBarycoord(e,t,n,s,r){On.subVectors(s,t),ti.subVectors(n,t),Bo.subVectors(e,t);const a=On.dot(On),o=On.dot(ti),c=On.dot(Bo),l=ti.dot(ti),u=ti.dot(Bo),d=a*l-o*o;if(d===0)return r.set(0,0,0),null;const h=1/d,p=(l*c-o*u)*h,g=(a*u-o*c)*h;return r.set(1-p-g,g,p)}static containsPoint(e,t,n,s){return this.getBarycoord(e,t,n,s,ni)===null?!1:ni.x>=0&&ni.y>=0&&ni.x+ni.y<=1}static getInterpolation(e,t,n,s,r,a,o,c){return this.getBarycoord(e,t,n,s,ni)===null?(c.x=0,c.y=0,"z"in c&&(c.z=0),"w"in c&&(c.w=0),null):(c.setScalar(0),c.addScaledVector(r,ni.x),c.addScaledVector(a,ni.y),c.addScaledVector(o,ni.z),c)}static getInterpolatedAttribute(e,t,n,s,r,a){return Ho.setScalar(0),Go.setScalar(0),Wo.setScalar(0),Ho.fromBufferAttribute(e,t),Go.fromBufferAttribute(e,n),Wo.fromBufferAttribute(e,s),a.setScalar(0),a.addScaledVector(Ho,r.x),a.addScaledVector(Go,r.y),a.addScaledVector(Wo,r.z),a}static isFrontFacing(e,t,n,s){return On.subVectors(n,t),ti.subVectors(e,t),On.cross(ti).dot(s)<0}set(e,t,n){return this.a.copy(e),this.b.copy(t),this.c.copy(n),this}setFromPointsAndIndices(e,t,n,s){return this.a.copy(e[t]),this.b.copy(e[n]),this.c.copy(e[s]),this}setFromAttributeAndIndices(e,t,n,s){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,n),this.c.fromBufferAttribute(e,s),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return On.subVectors(this.c,this.b),ti.subVectors(this.a,this.b),On.cross(ti).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return Tn.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return Tn.getBarycoord(e,this.a,this.b,this.c,t)}getInterpolation(e,t,n,s,r){return Tn.getInterpolation(e,this.a,this.b,this.c,t,n,s,r)}containsPoint(e){return Tn.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return Tn.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){const n=this.a,s=this.b,r=this.c;let a,o;us.subVectors(s,n),ds.subVectors(r,n),ko.subVectors(e,n);const c=us.dot(ko),l=ds.dot(ko);if(c<=0&&l<=0)return t.copy(n);zo.subVectors(e,s);const u=us.dot(zo),d=ds.dot(zo);if(u>=0&&d<=u)return t.copy(s);const h=c*d-u*l;if(h<=0&&c>=0&&u<=0)return a=c/(c-u),t.copy(n).addScaledVector(us,a);Vo.subVectors(e,r);const p=us.dot(Vo),g=ds.dot(Vo);if(g>=0&&p<=g)return t.copy(r);const v=p*l-c*g;if(v<=0&&l>=0&&g<=0)return o=l/(l-g),t.copy(n).addScaledVector(ds,o);const m=u*g-p*d;if(m<=0&&d-u>=0&&p-g>=0)return Ou.subVectors(r,s),o=(d-u)/(d-u+(p-g)),t.copy(s).addScaledVector(Ou,o);const f=1/(m+v+h);return a=v*f,o=h*f,t.copy(n).addScaledVector(us,a).addScaledVector(ds,o)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}const $h={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},_i={h:0,s:0,l:0},ra={h:0,s:0,l:0};function Xo(i,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?i+(e-i)*6*t:t<1/2?e:t<2/3?i+(e-i)*6*(2/3-t):i}class Re{constructor(e,t,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,n)}set(e,t,n){if(t===void 0&&n===void 0){const s=e;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(e,t,n);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=_t){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,tt.colorSpaceToWorking(this,t),this}setRGB(e,t,n,s=tt.workingColorSpace){return this.r=e,this.g=t,this.b=n,tt.colorSpaceToWorking(this,s),this}setHSL(e,t,n,s=tt.workingColorSpace){if(e=Uc(e,1),t=Je(t,0,1),n=Je(n,0,1),t===0)this.r=this.g=this.b=n;else{const r=n<=.5?n*(1+t):n+t-n*t,a=2*n-r;this.r=Xo(a,r,e+1/3),this.g=Xo(a,r,e),this.b=Xo(a,r,e-1/3)}return tt.colorSpaceToWorking(this,s),this}setStyle(e,t=_t){function n(r){r!==void 0&&parseFloat(r)<1&&console.warn("THREE.Color: Alpha component of "+e+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(e)){let r;const a=s[1],o=s[2];switch(a){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,t);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,t);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,t);break;default:console.warn("THREE.Color: Unknown color model "+e)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(e)){const r=s[1],a=r.length;if(a===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,t);if(a===6)return this.setHex(parseInt(r,16),t);console.warn("THREE.Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=_t){const n=$h[e.toLowerCase()];return n!==void 0?this.setHex(n,t):console.warn("THREE.Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=hi(e.r),this.g=hi(e.g),this.b=hi(e.b),this}copyLinearToSRGB(e){return this.r=Cs(e.r),this.g=Cs(e.g),this.b=Cs(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=_t){return tt.workingToColorSpace(qt.copy(this),e),Math.round(Je(qt.r*255,0,255))*65536+Math.round(Je(qt.g*255,0,255))*256+Math.round(Je(qt.b*255,0,255))}getHexString(e=_t){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=tt.workingColorSpace){tt.workingToColorSpace(qt.copy(this),t);const n=qt.r,s=qt.g,r=qt.b,a=Math.max(n,s,r),o=Math.min(n,s,r);let c,l;const u=(o+a)/2;if(o===a)c=0,l=0;else{const d=a-o;switch(l=u<=.5?d/(a+o):d/(2-a-o),a){case n:c=(s-r)/d+(s<r?6:0);break;case s:c=(r-n)/d+2;break;case r:c=(n-s)/d+4;break}c/=6}return e.h=c,e.s=l,e.l=u,e}getRGB(e,t=tt.workingColorSpace){return tt.workingToColorSpace(qt.copy(this),t),e.r=qt.r,e.g=qt.g,e.b=qt.b,e}getStyle(e=_t){tt.workingToColorSpace(qt.copy(this),e);const t=qt.r,n=qt.g,s=qt.b;return e!==_t?`color(${e} ${t.toFixed(3)} ${n.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(n*255)},${Math.round(s*255)})`}offsetHSL(e,t,n){return this.getHSL(_i),this.setHSL(_i.h+e,_i.s+t,_i.l+n)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,n){return this.r=e.r+(t.r-e.r)*n,this.g=e.g+(t.g-e.g)*n,this.b=e.b+(t.b-e.b)*n,this}lerpHSL(e,t){this.getHSL(_i),e.getHSL(ra);const n=Mr(_i.h,ra.h,t),s=Mr(_i.s,ra.s,t),r=Mr(_i.l,ra.l,t);return this.setHSL(n,s,r),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const t=this.r,n=this.g,s=this.b,r=e.elements;return this.r=r[0]*t+r[3]*n+r[6]*s,this.g=r[1]*t+r[4]*n+r[7]*s,this.b=r[2]*t+r[5]*n+r[8]*s,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const qt=new Re;Re.NAMES=$h;let Em=0;class Rn extends $s{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Em++}),this.uuid=Bn(),this.name="",this.type="Material",this.blending=Ci,this.side=fi,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Ml,this.blendDst=El,this.blendEquation=ji,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Re(0,0,0),this.blendAlpha=0,this.depthFunc=Os,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Su,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=ns,this.stencilZFail=ns,this.stencilZPass=ns,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const t in e){const n=e[t];if(n===void 0){console.warn(`THREE.Material: parameter '${t}' has value of undefined.`);continue}const s=this[t];if(s===void 0){console.warn(`THREE.Material: '${t}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(n):s&&s.isVector3&&n&&n.isVector3?s.copy(n):this[t]=n}}toJSON(e){const t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});const n={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(n.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(n.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(e).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(e).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(e).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(e).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(e).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==Ci&&(n.blending=this.blending),this.side!==fi&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==Ml&&(n.blendSrc=this.blendSrc),this.blendDst!==El&&(n.blendDst=this.blendDst),this.blendEquation!==ji&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==Os&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Su&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==ns&&(n.stencilFail=this.stencilFail),this.stencilZFail!==ns&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==ns&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function s(r){const a=[];for(const o in r){const c=r[o];delete c.metadata,a.push(c)}return a}if(t){const r=s(e.textures),a=s(e.images);r.length>0&&(n.textures=r),a.length>0&&(n.images=a)}return n}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const t=e.clippingPlanes;let n=null;if(t!==null){const s=t.length;n=new Array(s);for(let r=0;r!==s;++r)n[r]=t[r].clone()}return this.clippingPlanes=n,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}class Ut extends Rn{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Re(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new vn,this.combine=wc,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const Dt=new N,aa=new Ie;let Tm=0;class ct{constructor(e,t,n=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:Tm++}),this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=n,this.usage=cc,this.updateRanges=[],this.gpuType=Fn,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,n){e*=this.itemSize,n*=t.itemSize;for(let s=0,r=this.itemSize;s<r;s++)this.array[e+s]=t.array[n+s];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,n=this.count;t<n;t++)aa.fromBufferAttribute(this,t),aa.applyMatrix3(e),this.setXY(t,aa.x,aa.y);else if(this.itemSize===3)for(let t=0,n=this.count;t<n;t++)Dt.fromBufferAttribute(this,t),Dt.applyMatrix3(e),this.setXYZ(t,Dt.x,Dt.y,Dt.z);return this}applyMatrix4(e){for(let t=0,n=this.count;t<n;t++)Dt.fromBufferAttribute(this,t),Dt.applyMatrix4(e),this.setXYZ(t,Dt.x,Dt.y,Dt.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)Dt.fromBufferAttribute(this,t),Dt.applyNormalMatrix(e),this.setXYZ(t,Dt.x,Dt.y,Dt.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)Dt.fromBufferAttribute(this,t),Dt.transformDirection(e),this.setXYZ(t,Dt.x,Dt.y,Dt.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let n=this.array[e*this.itemSize+t];return this.normalized&&(n=Un(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=ot(n,this.array)),this.array[e*this.itemSize+t]=n,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=Un(t,this.array)),t}setX(e,t){return this.normalized&&(t=ot(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=Un(t,this.array)),t}setY(e,t){return this.normalized&&(t=ot(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=Un(t,this.array)),t}setZ(e,t){return this.normalized&&(t=ot(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=Un(t,this.array)),t}setW(e,t){return this.normalized&&(t=ot(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,n){return e*=this.itemSize,this.normalized&&(t=ot(t,this.array),n=ot(n,this.array)),this.array[e+0]=t,this.array[e+1]=n,this}setXYZ(e,t,n,s){return e*=this.itemSize,this.normalized&&(t=ot(t,this.array),n=ot(n,this.array),s=ot(s,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=s,this}setXYZW(e,t,n,s,r){return e*=this.itemSize,this.normalized&&(t=ot(t,this.array),n=ot(n,this.array),s=ot(s,this.array),r=ot(r,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=s,this.array[e+3]=r,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==cc&&(e.usage=this.usage),e}}class ao extends ct{constructor(e,t,n){super(new Uint16Array(e),t,n)}}class Kh extends ct{constructor(e,t,n){super(new Uint32Array(e),t,n)}}class nt extends ct{constructor(e,t,n){super(new Float32Array(e),t,n)}}let Am=0;const Sn=new Ye,qo=new bt,hs=new N,hn=new jn,ar=new jn,zt=new N;class It extends $s{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:Am++}),this.uuid=Bn(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(Yh(e)?Kh:ao)(e,1):this.index=e,this}setIndirect(e){return this.indirect=e,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,n=0){this.groups.push({start:e,count:t,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){const t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);const n=this.attributes.normal;if(n!==void 0){const r=new $e().getNormalMatrix(e);n.applyNormalMatrix(r),n.needsUpdate=!0}const s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(e),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return Sn.makeRotationFromQuaternion(e),this.applyMatrix4(Sn),this}rotateX(e){return Sn.makeRotationX(e),this.applyMatrix4(Sn),this}rotateY(e){return Sn.makeRotationY(e),this.applyMatrix4(Sn),this}rotateZ(e){return Sn.makeRotationZ(e),this.applyMatrix4(Sn),this}translate(e,t,n){return Sn.makeTranslation(e,t,n),this.applyMatrix4(Sn),this}scale(e,t,n){return Sn.makeScale(e,t,n),this.applyMatrix4(Sn),this}lookAt(e){return qo.lookAt(e),qo.updateMatrix(),this.applyMatrix4(qo.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(hs).negate(),this.translate(hs.x,hs.y,hs.z),this}setFromPoints(e){const t=this.getAttribute("position");if(t===void 0){const n=[];for(let s=0,r=e.length;s<r;s++){const a=e[s];n.push(a.x,a.y,a.z||0)}this.setAttribute("position",new nt(n,3))}else{const n=Math.min(e.length,t.count);for(let s=0;s<n;s++){const r=e[s];t.setXYZ(s,r.x,r.y,r.z||0)}e.length>t.count&&console.warn("THREE.BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new jn);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new N(-1/0,-1/0,-1/0),new N(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let n=0,s=t.length;n<s;n++){const r=t[n];hn.setFromBufferAttribute(r),this.morphTargetsRelative?(zt.addVectors(this.boundingBox.min,hn.min),this.boundingBox.expandByPoint(zt),zt.addVectors(this.boundingBox.max,hn.max),this.boundingBox.expandByPoint(zt)):(this.boundingBox.expandByPoint(hn.min),this.boundingBox.expandByPoint(hn.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new $n);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new N,1/0);return}if(e){const n=this.boundingSphere.center;if(hn.setFromBufferAttribute(e),t)for(let r=0,a=t.length;r<a;r++){const o=t[r];ar.setFromBufferAttribute(o),this.morphTargetsRelative?(zt.addVectors(hn.min,ar.min),hn.expandByPoint(zt),zt.addVectors(hn.max,ar.max),hn.expandByPoint(zt)):(hn.expandByPoint(ar.min),hn.expandByPoint(ar.max))}hn.getCenter(n);let s=0;for(let r=0,a=e.count;r<a;r++)zt.fromBufferAttribute(e,r),s=Math.max(s,n.distanceToSquared(zt));if(t)for(let r=0,a=t.length;r<a;r++){const o=t[r],c=this.morphTargetsRelative;for(let l=0,u=o.count;l<u;l++)zt.fromBufferAttribute(o,l),c&&(hs.fromBufferAttribute(e,l),zt.add(hs)),s=Math.max(s,n.distanceToSquared(zt))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const n=t.position,s=t.normal,r=t.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new ct(new Float32Array(4*n.count),4));const a=this.getAttribute("tangent"),o=[],c=[];for(let C=0;C<n.count;C++)o[C]=new N,c[C]=new N;const l=new N,u=new N,d=new N,h=new Ie,p=new Ie,g=new Ie,v=new N,m=new N;function f(C,b,S){l.fromBufferAttribute(n,C),u.fromBufferAttribute(n,b),d.fromBufferAttribute(n,S),h.fromBufferAttribute(r,C),p.fromBufferAttribute(r,b),g.fromBufferAttribute(r,S),u.sub(l),d.sub(l),p.sub(h),g.sub(h);const I=1/(p.x*g.y-g.x*p.y);isFinite(I)&&(v.copy(u).multiplyScalar(g.y).addScaledVector(d,-p.y).multiplyScalar(I),m.copy(d).multiplyScalar(p.x).addScaledVector(u,-g.x).multiplyScalar(I),o[C].add(v),o[b].add(v),o[S].add(v),c[C].add(m),c[b].add(m),c[S].add(m))}let _=this.groups;_.length===0&&(_=[{start:0,count:e.count}]);for(let C=0,b=_.length;C<b;++C){const S=_[C],I=S.start,D=S.count;for(let w=I,U=I+D;w<U;w+=3)f(e.getX(w+0),e.getX(w+1),e.getX(w+2))}const x=new N,y=new N,A=new N,E=new N;function M(C){A.fromBufferAttribute(s,C),E.copy(A);const b=o[C];x.copy(b),x.sub(A.multiplyScalar(A.dot(b))).normalize(),y.crossVectors(E,b);const I=y.dot(c[C])<0?-1:1;a.setXYZW(C,x.x,x.y,x.z,I)}for(let C=0,b=_.length;C<b;++C){const S=_[C],I=S.start,D=S.count;for(let w=I,U=I+D;w<U;w+=3)M(e.getX(w+0)),M(e.getX(w+1)),M(e.getX(w+2))}}computeVertexNormals(){const e=this.index,t=this.getAttribute("position");if(t!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new ct(new Float32Array(t.count*3),3),this.setAttribute("normal",n);else for(let h=0,p=n.count;h<p;h++)n.setXYZ(h,0,0,0);const s=new N,r=new N,a=new N,o=new N,c=new N,l=new N,u=new N,d=new N;if(e)for(let h=0,p=e.count;h<p;h+=3){const g=e.getX(h+0),v=e.getX(h+1),m=e.getX(h+2);s.fromBufferAttribute(t,g),r.fromBufferAttribute(t,v),a.fromBufferAttribute(t,m),u.subVectors(a,r),d.subVectors(s,r),u.cross(d),o.fromBufferAttribute(n,g),c.fromBufferAttribute(n,v),l.fromBufferAttribute(n,m),o.add(u),c.add(u),l.add(u),n.setXYZ(g,o.x,o.y,o.z),n.setXYZ(v,c.x,c.y,c.z),n.setXYZ(m,l.x,l.y,l.z)}else for(let h=0,p=t.count;h<p;h+=3)s.fromBufferAttribute(t,h+0),r.fromBufferAttribute(t,h+1),a.fromBufferAttribute(t,h+2),u.subVectors(a,r),d.subVectors(s,r),u.cross(d),n.setXYZ(h+0,u.x,u.y,u.z),n.setXYZ(h+1,u.x,u.y,u.z),n.setXYZ(h+2,u.x,u.y,u.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let t=0,n=e.count;t<n;t++)zt.fromBufferAttribute(e,t),zt.normalize(),e.setXYZ(t,zt.x,zt.y,zt.z)}toNonIndexed(){function e(o,c){const l=o.array,u=o.itemSize,d=o.normalized,h=new l.constructor(c.length*u);let p=0,g=0;for(let v=0,m=c.length;v<m;v++){o.isInterleavedBufferAttribute?p=c[v]*o.data.stride+o.offset:p=c[v]*u;for(let f=0;f<u;f++)h[g++]=l[p++]}return new ct(h,u,d)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const t=new It,n=this.index.array,s=this.attributes;for(const o in s){const c=s[o],l=e(c,n);t.setAttribute(o,l)}const r=this.morphAttributes;for(const o in r){const c=[],l=r[o];for(let u=0,d=l.length;u<d;u++){const h=l[u],p=e(h,n);c.push(p)}t.morphAttributes[o]=c}t.morphTargetsRelative=this.morphTargetsRelative;const a=this.groups;for(let o=0,c=a.length;o<c;o++){const l=a[o];t.addGroup(l.start,l.count,l.materialIndex)}return t}toJSON(){const e={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){const c=this.parameters;for(const l in c)c[l]!==void 0&&(e[l]=c[l]);return e}e.data={attributes:{}};const t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});const n=this.attributes;for(const c in n){const l=n[c];e.data.attributes[c]=l.toJSON(e.data)}const s={};let r=!1;for(const c in this.morphAttributes){const l=this.morphAttributes[c],u=[];for(let d=0,h=l.length;d<h;d++){const p=l[d];u.push(p.toJSON(e.data))}u.length>0&&(s[c]=u,r=!0)}r&&(e.data.morphAttributes=s,e.data.morphTargetsRelative=this.morphTargetsRelative);const a=this.groups;a.length>0&&(e.data.groups=JSON.parse(JSON.stringify(a)));const o=this.boundingSphere;return o!==null&&(e.data.boundingSphere=o.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const t={};this.name=e.name;const n=e.index;n!==null&&this.setIndex(n.clone());const s=e.attributes;for(const l in s){const u=s[l];this.setAttribute(l,u.clone(t))}const r=e.morphAttributes;for(const l in r){const u=[],d=r[l];for(let h=0,p=d.length;h<p;h++)u.push(d[h].clone(t));this.morphAttributes[l]=u}this.morphTargetsRelative=e.morphTargetsRelative;const a=e.groups;for(let l=0,u=a.length;l<u;l++){const d=a[l];this.addGroup(d.start,d.count,d.materialIndex)}const o=e.boundingBox;o!==null&&(this.boundingBox=o.clone());const c=e.boundingSphere;return c!==null&&(this.boundingSphere=c.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const Uu=new Ye,ki=new Fr,oa=new $n,Fu=new N,la=new N,ca=new N,ua=new N,Yo=new N,da=new N,Bu=new N,ha=new N;class pt extends bt{constructor(e=new It,t=new Ut){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=s.length;r<a;r++){const o=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}getVertexPosition(e,t){const n=this.geometry,s=n.attributes.position,r=n.morphAttributes.position,a=n.morphTargetsRelative;t.fromBufferAttribute(s,e);const o=this.morphTargetInfluences;if(r&&o){da.set(0,0,0);for(let c=0,l=r.length;c<l;c++){const u=o[c],d=r[c];u!==0&&(Yo.fromBufferAttribute(d,e),a?da.addScaledVector(Yo,u):da.addScaledVector(Yo.sub(t),u))}t.add(da)}return t}raycast(e,t){const n=this.geometry,s=this.material,r=this.matrixWorld;s!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),oa.copy(n.boundingSphere),oa.applyMatrix4(r),ki.copy(e.ray).recast(e.near),!(oa.containsPoint(ki.origin)===!1&&(ki.intersectSphere(oa,Fu)===null||ki.origin.distanceToSquared(Fu)>(e.far-e.near)**2))&&(Uu.copy(r).invert(),ki.copy(e.ray).applyMatrix4(Uu),!(n.boundingBox!==null&&ki.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(e,t,ki)))}_computeIntersections(e,t,n){let s;const r=this.geometry,a=this.material,o=r.index,c=r.attributes.position,l=r.attributes.uv,u=r.attributes.uv1,d=r.attributes.normal,h=r.groups,p=r.drawRange;if(o!==null)if(Array.isArray(a))for(let g=0,v=h.length;g<v;g++){const m=h[g],f=a[m.materialIndex],_=Math.max(m.start,p.start),x=Math.min(o.count,Math.min(m.start+m.count,p.start+p.count));for(let y=_,A=x;y<A;y+=3){const E=o.getX(y),M=o.getX(y+1),C=o.getX(y+2);s=fa(this,f,e,n,l,u,d,E,M,C),s&&(s.faceIndex=Math.floor(y/3),s.face.materialIndex=m.materialIndex,t.push(s))}}else{const g=Math.max(0,p.start),v=Math.min(o.count,p.start+p.count);for(let m=g,f=v;m<f;m+=3){const _=o.getX(m),x=o.getX(m+1),y=o.getX(m+2);s=fa(this,a,e,n,l,u,d,_,x,y),s&&(s.faceIndex=Math.floor(m/3),t.push(s))}}else if(c!==void 0)if(Array.isArray(a))for(let g=0,v=h.length;g<v;g++){const m=h[g],f=a[m.materialIndex],_=Math.max(m.start,p.start),x=Math.min(c.count,Math.min(m.start+m.count,p.start+p.count));for(let y=_,A=x;y<A;y+=3){const E=y,M=y+1,C=y+2;s=fa(this,f,e,n,l,u,d,E,M,C),s&&(s.faceIndex=Math.floor(y/3),s.face.materialIndex=m.materialIndex,t.push(s))}}else{const g=Math.max(0,p.start),v=Math.min(c.count,p.start+p.count);for(let m=g,f=v;m<f;m+=3){const _=m,x=m+1,y=m+2;s=fa(this,a,e,n,l,u,d,_,x,y),s&&(s.faceIndex=Math.floor(m/3),t.push(s))}}}}function wm(i,e,t,n,s,r,a,o){let c;if(e.side===an?c=n.intersectTriangle(a,r,s,!0,o):c=n.intersectTriangle(s,r,a,e.side===fi,o),c===null)return null;ha.copy(o),ha.applyMatrix4(i.matrixWorld);const l=t.ray.origin.distanceTo(ha);return l<t.near||l>t.far?null:{distance:l,point:ha.clone(),object:i}}function fa(i,e,t,n,s,r,a,o,c,l){i.getVertexPosition(o,la),i.getVertexPosition(c,ca),i.getVertexPosition(l,ua);const u=wm(i,e,t,n,la,ca,ua,Bu);if(u){const d=new N;Tn.getBarycoord(Bu,la,ca,ua,d),s&&(u.uv=Tn.getInterpolatedAttribute(s,o,c,l,d,new Ie)),r&&(u.uv1=Tn.getInterpolatedAttribute(r,o,c,l,d,new Ie)),a&&(u.normal=Tn.getInterpolatedAttribute(a,o,c,l,d,new N),u.normal.dot(n.direction)>0&&u.normal.multiplyScalar(-1));const h={a:o,b:c,c:l,normal:new N,materialIndex:0};Tn.getNormal(la,ca,ua,h.normal),u.face=h,u.barycoord=d}return u}class Br extends It{constructor(e=1,t=1,n=1,s=1,r=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:n,widthSegments:s,heightSegments:r,depthSegments:a};const o=this;s=Math.floor(s),r=Math.floor(r),a=Math.floor(a);const c=[],l=[],u=[],d=[];let h=0,p=0;g("z","y","x",-1,-1,n,t,e,a,r,0),g("z","y","x",1,-1,n,t,-e,a,r,1),g("x","z","y",1,1,e,n,t,s,a,2),g("x","z","y",1,-1,e,n,-t,s,a,3),g("x","y","z",1,-1,e,t,n,s,r,4),g("x","y","z",-1,-1,e,t,-n,s,r,5),this.setIndex(c),this.setAttribute("position",new nt(l,3)),this.setAttribute("normal",new nt(u,3)),this.setAttribute("uv",new nt(d,2));function g(v,m,f,_,x,y,A,E,M,C,b){const S=y/M,I=A/C,D=y/2,w=A/2,U=E/2,O=M+1,F=C+1;let V=0,k=0;const z=new N;for(let B=0;B<F;B++){const j=B*I-w;for(let ne=0;ne<O;ne++){const Q=ne*S-D;z[v]=Q*_,z[m]=j*x,z[f]=U,l.push(z.x,z.y,z.z),z[v]=0,z[m]=0,z[f]=E>0?1:-1,u.push(z.x,z.y,z.z),d.push(ne/M),d.push(1-B/C),V+=1}}for(let B=0;B<C;B++)for(let j=0;j<M;j++){const ne=h+j+O*B,Q=h+j+O*(B+1),re=h+(j+1)+O*(B+1),ce=h+(j+1)+O*B;c.push(ne,Q,ce),c.push(Q,re,ce),k+=6}o.addGroup(p,k,b),p+=k,h+=V}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Br(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}function zs(i){const e={};for(const t in i){e[t]={};for(const n in i[t]){const s=i[t][n];s&&(s.isColor||s.isMatrix3||s.isMatrix4||s.isVector2||s.isVector3||s.isVector4||s.isTexture||s.isQuaternion)?s.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][n]=null):e[t][n]=s.clone():Array.isArray(s)?e[t][n]=s.slice():e[t][n]=s}}return e}function $t(i){const e={};for(let t=0;t<i.length;t++){const n=zs(i[t]);for(const s in n)e[s]=n[s]}return e}function Rm(i){const e=[];for(let t=0;t<i.length;t++)e.push(i[t].clone());return e}function Zh(i){const e=i.getRenderTarget();return e===null?i.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:tt.workingColorSpace}const qa={clone:zs,merge:$t};var Cm=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,Im=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class Rt extends Rn{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=Cm,this.fragmentShader=Im,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=zs(e.uniforms),this.uniformsGroups=Rm(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this}toJSON(e){const t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(const s in this.uniforms){const a=this.uniforms[s].value;a&&a.isTexture?t.uniforms[s]={type:"t",value:a.toJSON(e).uuid}:a&&a.isColor?t.uniforms[s]={type:"c",value:a.getHex()}:a&&a.isVector2?t.uniforms[s]={type:"v2",value:a.toArray()}:a&&a.isVector3?t.uniforms[s]={type:"v3",value:a.toArray()}:a&&a.isVector4?t.uniforms[s]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?t.uniforms[s]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?t.uniforms[s]={type:"m4",value:a.toArray()}:t.uniforms[s]={value:a}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;const n={};for(const s in this.extensions)this.extensions[s]===!0&&(n[s]=!0);return Object.keys(n).length>0&&(t.extensions=n),t}}class Jh extends bt{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Ye,this.projectionMatrix=new Ye,this.projectionMatrixInverse=new Ye,this.coordinateSystem=Wn,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,t){super.updateWorldMatrix(e,t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}}const xi=new N,ku=new Ie,zu=new Ie;class Kt extends Jh{constructor(e=50,t=1,n=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=n,this.far=s,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const t=.5*this.getFilmHeight()/e;this.fov=ks*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(br*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return ks*2*Math.atan(Math.tan(br*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,n){xi.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(xi.x,xi.y).multiplyScalar(-e/xi.z),xi.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(xi.x,xi.y).multiplyScalar(-e/xi.z)}getViewSize(e,t){return this.getViewBounds(e,ku,zu),t.subVectors(zu,ku)}setViewOffset(e,t,n,s,r,a){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let t=e*Math.tan(br*.5*this.fov)/this.zoom,n=2*t,s=this.aspect*n,r=-.5*s;const a=this.view;if(this.view!==null&&this.view.enabled){const c=a.fullWidth,l=a.fullHeight;r+=a.offsetX*s/c,t-=a.offsetY*n/l,s*=a.width/c,n*=a.height/l}const o=this.filmOffset;o!==0&&(r+=e*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+s,t,t-n,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}}const fs=-90,ps=1;class Pm extends bt{constructor(e,t,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;const s=new Kt(fs,ps,e,t);s.layers=this.layers,this.add(s);const r=new Kt(fs,ps,e,t);r.layers=this.layers,this.add(r);const a=new Kt(fs,ps,e,t);a.layers=this.layers,this.add(a);const o=new Kt(fs,ps,e,t);o.layers=this.layers,this.add(o);const c=new Kt(fs,ps,e,t);c.layers=this.layers,this.add(c);const l=new Kt(fs,ps,e,t);l.layers=this.layers,this.add(l)}updateCoordinateSystem(){const e=this.coordinateSystem,t=this.children.concat(),[n,s,r,a,o,c]=t;for(const l of t)this.remove(l);if(e===Wn)n.up.set(0,1,0),n.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),c.up.set(0,1,0),c.lookAt(0,0,-1);else if(e===Xa)n.up.set(0,-1,0),n.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),c.up.set(0,-1,0),c.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const l of t)this.add(l),l.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();const{renderTarget:n,activeMipmapLevel:s}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[r,a,o,c,l,u]=this.children,d=e.getRenderTarget(),h=e.getActiveCubeFace(),p=e.getActiveMipmapLevel(),g=e.xr.enabled;e.xr.enabled=!1;const v=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,e.setRenderTarget(n,0,s),e.render(t,r),e.setRenderTarget(n,1,s),e.render(t,a),e.setRenderTarget(n,2,s),e.render(t,o),e.setRenderTarget(n,3,s),e.render(t,c),e.setRenderTarget(n,4,s),e.render(t,l),n.texture.generateMipmaps=v,e.setRenderTarget(n,5,s),e.render(t,u),e.setRenderTarget(d,h,p),e.xr.enabled=g,n.texture.needsPMREMUpdate=!0}}class Qh extends Ft{constructor(e=[],t=Us,n,s,r,a,o,c,l,u){super(e,t,n,s,r,a,o,c,l,u),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class Lm extends kn{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;const n={width:e,height:e,depth:1},s=[n,n,n,n,n,n];this.texture=new Qh(s),this._setTextureOptions(t),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;const n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new Br(5,5,5),r=new Rt({name:"CubemapFromEquirect",uniforms:zs(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:an,blending:ui});r.uniforms.tEquirect.value=t;const a=new pt(s,r),o=t.minFilter;return t.minFilter===Gt&&(t.minFilter=Lt),new Pm(1,10,this).update(e,a),t.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(e,t=!0,n=!0,s=!0){const r=e.getRenderTarget();for(let a=0;a<6;a++)e.setRenderTarget(this,a),e.clear(t,n,s);e.setRenderTarget(r)}}class At extends bt{constructor(){super(),this.isGroup=!0,this.type="Group"}}const Dm={type:"move"};class jo{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new At,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new At,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new N,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new N),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new At,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new N,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new N),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const t=this._hand;if(t)for(const n of e.hand.values())this._getHandJoint(t,n)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,n){let s=null,r=null,a=null;const o=this._targetRay,c=this._grip,l=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(l&&e.hand){a=!0;for(const v of e.hand.values()){const m=t.getJointPose(v,n),f=this._getHandJoint(l,v);m!==null&&(f.matrix.fromArray(m.transform.matrix),f.matrix.decompose(f.position,f.rotation,f.scale),f.matrixWorldNeedsUpdate=!0,f.jointRadius=m.radius),f.visible=m!==null}const u=l.joints["index-finger-tip"],d=l.joints["thumb-tip"],h=u.position.distanceTo(d.position),p=.02,g=.005;l.inputState.pinching&&h>p+g?(l.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!l.inputState.pinching&&h<=p-g&&(l.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else c!==null&&e.gripSpace&&(r=t.getPose(e.gripSpace,n),r!==null&&(c.matrix.fromArray(r.transform.matrix),c.matrix.decompose(c.position,c.rotation,c.scale),c.matrixWorldNeedsUpdate=!0,r.linearVelocity?(c.hasLinearVelocity=!0,c.linearVelocity.copy(r.linearVelocity)):c.hasLinearVelocity=!1,r.angularVelocity?(c.hasAngularVelocity=!0,c.angularVelocity.copy(r.angularVelocity)):c.hasAngularVelocity=!1));o!==null&&(s=t.getPose(e.targetRaySpace,n),s===null&&r!==null&&(s=r),s!==null&&(o.matrix.fromArray(s.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,s.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(s.linearVelocity)):o.hasLinearVelocity=!1,s.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(s.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(Dm)))}return o!==null&&(o.visible=s!==null),c!==null&&(c.visible=r!==null),l!==null&&(l.visible=a!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){const n=new At;n.matrixAutoUpdate=!1,n.visible=!1,e.joints[t.jointName]=n,e.add(n)}return e.joints[t.jointName]}}class ef extends bt{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new vn,this.environmentIntensity=1,this.environmentRotation=new vn,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(t.object.environmentIntensity=this.environmentIntensity),t.object.environmentRotation=this.environmentRotation.toArray(),t}}class tf{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e!==void 0?e.length/t:0,this.usage=cc,this.updateRanges=[],this.version=0,this.uuid=Bn()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,n){e*=this.stride,n*=t.stride;for(let s=0,r=this.stride;s<r;s++)this.array[e+s]=t.array[n+s];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Bn()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);const t=new this.array.constructor(e.arrayBuffers[this.array.buffer._uuid]),n=new this.constructor(t,this.stride);return n.setUsage(this.usage),n}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){return e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Bn()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}}const jt=new N;class Nr{constructor(e,t,n,s=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=e,this.itemSize=t,this.offset=n,this.normalized=s}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let t=0,n=this.data.count;t<n;t++)jt.fromBufferAttribute(this,t),jt.applyMatrix4(e),this.setXYZ(t,jt.x,jt.y,jt.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)jt.fromBufferAttribute(this,t),jt.applyNormalMatrix(e),this.setXYZ(t,jt.x,jt.y,jt.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)jt.fromBufferAttribute(this,t),jt.transformDirection(e),this.setXYZ(t,jt.x,jt.y,jt.z);return this}getComponent(e,t){let n=this.array[e*this.data.stride+this.offset+t];return this.normalized&&(n=Un(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=ot(n,this.array)),this.data.array[e*this.data.stride+this.offset+t]=n,this}setX(e,t){return this.normalized&&(t=ot(t,this.array)),this.data.array[e*this.data.stride+this.offset]=t,this}setY(e,t){return this.normalized&&(t=ot(t,this.array)),this.data.array[e*this.data.stride+this.offset+1]=t,this}setZ(e,t){return this.normalized&&(t=ot(t,this.array)),this.data.array[e*this.data.stride+this.offset+2]=t,this}setW(e,t){return this.normalized&&(t=ot(t,this.array)),this.data.array[e*this.data.stride+this.offset+3]=t,this}getX(e){let t=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(t=Un(t,this.array)),t}getY(e){let t=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(t=Un(t,this.array)),t}getZ(e){let t=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(t=Un(t,this.array)),t}getW(e){let t=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(t=Un(t,this.array)),t}setXY(e,t,n){return e=e*this.data.stride+this.offset,this.normalized&&(t=ot(t,this.array),n=ot(n,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this}setXYZ(e,t,n,s){return e=e*this.data.stride+this.offset,this.normalized&&(t=ot(t,this.array),n=ot(n,this.array),s=ot(s,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=s,this}setXYZW(e,t,n,s,r){return e=e*this.data.stride+this.offset,this.normalized&&(t=ot(t,this.array),n=ot(n,this.array),s=ot(s,this.array),r=ot(r,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=s,this.data.array[e+3]=r,this}clone(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let n=0;n<this.count;n++){const s=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)t.push(this.data.array[s+r])}return new ct(new this.array.constructor(t),this.itemSize,this.normalized)}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.clone(e)),new Nr(e.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let n=0;n<this.count;n++){const s=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)t.push(this.data.array[s+r])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:t,normalized:this.normalized}}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}}class kr extends Rn{constructor(e){super(),this.isSpriteMaterial=!0,this.type="SpriteMaterial",this.color=new Re(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.rotation=e.rotation,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}let ms;const or=new N,gs=new N,vs=new N,_s=new Ie,lr=new Ie,nf=new Ye,pa=new N,cr=new N,ma=new N,Vu=new Ie,$o=new Ie,Hu=new Ie;class oo extends bt{constructor(e=new kr){if(super(),this.isSprite=!0,this.type="Sprite",ms===void 0){ms=new It;const t=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),n=new tf(t,5);ms.setIndex([0,1,2,0,2,3]),ms.setAttribute("position",new Nr(n,3,0,!1)),ms.setAttribute("uv",new Nr(n,2,3,!1))}this.geometry=ms,this.material=e,this.center=new Ie(.5,.5),this.count=1}raycast(e,t){e.camera===null&&console.error('THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),gs.setFromMatrixScale(this.matrixWorld),nf.copy(e.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(e.camera.matrixWorldInverse,this.matrixWorld),vs.setFromMatrixPosition(this.modelViewMatrix),e.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&gs.multiplyScalar(-vs.z);const n=this.material.rotation;let s,r;n!==0&&(r=Math.cos(n),s=Math.sin(n));const a=this.center;ga(pa.set(-.5,-.5,0),vs,a,gs,s,r),ga(cr.set(.5,-.5,0),vs,a,gs,s,r),ga(ma.set(.5,.5,0),vs,a,gs,s,r),Vu.set(0,0),$o.set(1,0),Hu.set(1,1);let o=e.ray.intersectTriangle(pa,cr,ma,!1,or);if(o===null&&(ga(cr.set(-.5,.5,0),vs,a,gs,s,r),$o.set(0,1),o=e.ray.intersectTriangle(pa,ma,cr,!1,or),o===null))return;const c=e.ray.origin.distanceTo(or);c<e.near||c>e.far||t.push({distance:c,point:or.clone(),uv:Tn.getInterpolation(or,pa,cr,ma,Vu,$o,Hu,new Ie),face:null,object:this})}copy(e,t){return super.copy(e,t),e.center!==void 0&&this.center.copy(e.center),this.material=e.material,this}}function ga(i,e,t,n,s,r){_s.subVectors(i,t).addScalar(.5).multiply(n),s!==void 0?(lr.x=r*_s.x-s*_s.y,lr.y=s*_s.x+r*_s.y):lr.copy(_s),i.copy(e),i.x+=lr.x,i.y+=lr.y,i.applyMatrix4(nf)}const Gu=new N,Wu=new st,Xu=new st,Nm=new N,qu=new Ye,va=new N,Ko=new $n,Yu=new Ye,Zo=new Fr;class kc extends pt{constructor(e,t){super(e,t),this.isSkinnedMesh=!0,this.type="SkinnedMesh",this.bindMode=vu,this.bindMatrix=new Ye,this.bindMatrixInverse=new Ye,this.boundingBox=null,this.boundingSphere=null}computeBoundingBox(){const e=this.geometry;this.boundingBox===null&&(this.boundingBox=new jn),this.boundingBox.makeEmpty();const t=e.getAttribute("position");for(let n=0;n<t.count;n++)this.getVertexPosition(n,va),this.boundingBox.expandByPoint(va)}computeBoundingSphere(){const e=this.geometry;this.boundingSphere===null&&(this.boundingSphere=new $n),this.boundingSphere.makeEmpty();const t=e.getAttribute("position");for(let n=0;n<t.count;n++)this.getVertexPosition(n,va),this.boundingSphere.expandByPoint(va)}copy(e,t){return super.copy(e,t),this.bindMode=e.bindMode,this.bindMatrix.copy(e.bindMatrix),this.bindMatrixInverse.copy(e.bindMatrixInverse),this.skeleton=e.skeleton,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}raycast(e,t){const n=this.material,s=this.matrixWorld;n!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),Ko.copy(this.boundingSphere),Ko.applyMatrix4(s),e.ray.intersectsSphere(Ko)!==!1&&(Yu.copy(s).invert(),Zo.copy(e.ray).applyMatrix4(Yu),!(this.boundingBox!==null&&Zo.intersectsBox(this.boundingBox)===!1)&&this._computeIntersections(e,t,Zo)))}getVertexPosition(e,t){return super.getVertexPosition(e,t),this.applyBoneTransform(e,t),t}bind(e,t){this.skeleton=e,t===void 0&&(this.updateMatrixWorld(!0),this.skeleton.calculateInverses(),t=this.matrixWorld),this.bindMatrix.copy(t),this.bindMatrixInverse.copy(t).invert()}pose(){this.skeleton.pose()}normalizeSkinWeights(){const e=new st,t=this.geometry.attributes.skinWeight;for(let n=0,s=t.count;n<s;n++){e.fromBufferAttribute(t,n);const r=1/e.manhattanLength();r!==1/0?e.multiplyScalar(r):e.set(1,0,0,0),t.setXYZW(n,e.x,e.y,e.z,e.w)}}updateMatrixWorld(e){super.updateMatrixWorld(e),this.bindMode===vu?this.bindMatrixInverse.copy(this.matrixWorld).invert():this.bindMode===Np?this.bindMatrixInverse.copy(this.bindMatrix).invert():console.warn("THREE.SkinnedMesh: Unrecognized bindMode: "+this.bindMode)}applyBoneTransform(e,t){const n=this.skeleton,s=this.geometry;Wu.fromBufferAttribute(s.attributes.skinIndex,e),Xu.fromBufferAttribute(s.attributes.skinWeight,e),Gu.copy(t).applyMatrix4(this.bindMatrix),t.set(0,0,0);for(let r=0;r<4;r++){const a=Xu.getComponent(r);if(a!==0){const o=Wu.getComponent(r);qu.multiplyMatrices(n.bones[o].matrixWorld,n.boneInverses[o]),t.addScaledVector(Nm.copy(Gu).applyMatrix4(qu),a)}}return t.applyMatrix4(this.bindMatrixInverse)}}class lo extends bt{constructor(){super(),this.isBone=!0,this.type="Bone"}}class sf extends Ft{constructor(e=null,t=1,n=1,s,r,a,o,c,l=Jt,u=Jt,d,h){super(null,a,o,c,l,u,s,r,d,h),this.isDataTexture=!0,this.image={data:e,width:t,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const ju=new Ye,Om=new Ye;class zr{constructor(e=[],t=[]){this.uuid=Bn(),this.bones=e.slice(0),this.boneInverses=t,this.boneMatrices=null,this.boneTexture=null,this.init()}init(){const e=this.bones,t=this.boneInverses;if(this.boneMatrices=new Float32Array(e.length*16),t.length===0)this.calculateInverses();else if(e.length!==t.length){console.warn("THREE.Skeleton: Number of inverse bone matrices does not match amount of bones."),this.boneInverses=[];for(let n=0,s=this.bones.length;n<s;n++)this.boneInverses.push(new Ye)}}calculateInverses(){this.boneInverses.length=0;for(let e=0,t=this.bones.length;e<t;e++){const n=new Ye;this.bones[e]&&n.copy(this.bones[e].matrixWorld).invert(),this.boneInverses.push(n)}}pose(){for(let e=0,t=this.bones.length;e<t;e++){const n=this.bones[e];n&&n.matrixWorld.copy(this.boneInverses[e]).invert()}for(let e=0,t=this.bones.length;e<t;e++){const n=this.bones[e];n&&(n.parent&&n.parent.isBone?(n.matrix.copy(n.parent.matrixWorld).invert(),n.matrix.multiply(n.matrixWorld)):n.matrix.copy(n.matrixWorld),n.matrix.decompose(n.position,n.quaternion,n.scale))}}update(){const e=this.bones,t=this.boneInverses,n=this.boneMatrices,s=this.boneTexture;for(let r=0,a=e.length;r<a;r++){const o=e[r]?e[r].matrixWorld:Om;ju.multiplyMatrices(o,t[r]),ju.toArray(n,r*16)}s!==null&&(s.needsUpdate=!0)}clone(){return new zr(this.bones,this.boneInverses)}computeBoneTexture(){let e=Math.sqrt(this.bones.length*4);e=Math.ceil(e/4)*4,e=Math.max(e,4);const t=new Float32Array(e*e*4);t.set(this.boneMatrices);const n=new sf(t,e,e,An,Fn);return n.needsUpdate=!0,this.boneMatrices=t,this.boneTexture=n,this}getBoneByName(e){for(let t=0,n=this.bones.length;t<n;t++){const s=this.bones[t];if(s.name===e)return s}}dispose(){this.boneTexture!==null&&(this.boneTexture.dispose(),this.boneTexture=null)}fromJSON(e,t){this.uuid=e.uuid;for(let n=0,s=e.bones.length;n<s;n++){const r=e.bones[n];let a=t[r];a===void 0&&(console.warn("THREE.Skeleton: No bone found with UUID:",r),a=new lo),this.bones.push(a),this.boneInverses.push(new Ye().fromArray(e.boneInverses[n]))}return this.init(),this}toJSON(){const e={metadata:{version:4.7,type:"Skeleton",generator:"Skeleton.toJSON"},bones:[],boneInverses:[]};e.uuid=this.uuid;const t=this.bones,n=this.boneInverses;for(let s=0,r=t.length;s<r;s++){const a=t[s];e.bones.push(a.uuid);const o=n[s];e.boneInverses.push(o.toArray())}return e}}class Ya extends ct{constructor(e,t,n,s=1){super(e,t,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=s}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){const e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}}const xs=new Ye,$u=new Ye,_a=[],Ku=new jn,Um=new Ye,ur=new pt,dr=new $n;class Fm extends pt{constructor(e,t,n){super(e,t),this.isInstancedMesh=!0,this.instanceMatrix=new Ya(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let s=0;s<n;s++)this.setMatrixAt(s,Um)}computeBoundingBox(){const e=this.geometry,t=this.count;this.boundingBox===null&&(this.boundingBox=new jn),e.boundingBox===null&&e.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,xs),Ku.copy(e.boundingBox).applyMatrix4(xs),this.boundingBox.union(Ku)}computeBoundingSphere(){const e=this.geometry,t=this.count;this.boundingSphere===null&&(this.boundingSphere=new $n),e.boundingSphere===null&&e.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,xs),dr.copy(e.boundingSphere).applyMatrix4(xs),this.boundingSphere.union(dr)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),e.morphTexture!==null&&(this.morphTexture=e.morphTexture.clone()),e.instanceColor!==null&&(this.instanceColor=e.instanceColor.clone()),this.count=e.count,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}getColorAt(e,t){t.fromArray(this.instanceColor.array,e*3)}getMatrixAt(e,t){t.fromArray(this.instanceMatrix.array,e*16)}getMorphAt(e,t){const n=t.morphTargetInfluences,s=this.morphTexture.source.data.data,r=n.length+1,a=e*r+1;for(let o=0;o<n.length;o++)n[o]=s[a+o]}raycast(e,t){const n=this.matrixWorld,s=this.count;if(ur.geometry=this.geometry,ur.material=this.material,ur.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),dr.copy(this.boundingSphere),dr.applyMatrix4(n),e.ray.intersectsSphere(dr)!==!1))for(let r=0;r<s;r++){this.getMatrixAt(r,xs),$u.multiplyMatrices(n,xs),ur.matrixWorld=$u,ur.raycast(e,_a);for(let a=0,o=_a.length;a<o;a++){const c=_a[a];c.instanceId=r,c.object=this,t.push(c)}_a.length=0}}setColorAt(e,t){this.instanceColor===null&&(this.instanceColor=new Ya(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),t.toArray(this.instanceColor.array,e*3)}setMatrixAt(e,t){t.toArray(this.instanceMatrix.array,e*16)}setMorphAt(e,t){const n=t.morphTargetInfluences,s=n.length+1;this.morphTexture===null&&(this.morphTexture=new sf(new Float32Array(s*this.count),s,this.count,Pc,Fn));const r=this.morphTexture.source.data.data;let a=0;for(let l=0;l<n.length;l++)a+=n[l];const o=this.geometry.morphTargetsRelative?1:1-a,c=s*e;r[c]=o,r.set(n,c+1)}updateMorphTargets(){}dispose(){this.dispatchEvent({type:"dispose"}),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null)}}const Jo=new N,Bm=new N,km=new $e;class Xi{constructor(e=new N(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,n,s){return this.normal.set(e,t,n),this.constant=s,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,n){const s=Jo.subVectors(n,t).cross(Bm.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(s,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t){const n=e.delta(Jo),s=this.normal.dot(n);if(s===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;const r=-(e.start.dot(this.normal)+this.constant)/s;return r<0||r>1?null:t.copy(e.start).addScaledVector(n,r)}intersectsLine(e){const t=this.distanceToPoint(e.start),n=this.distanceToPoint(e.end);return t<0&&n>0||n<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){const n=t||km.getNormalMatrix(e),s=this.coplanarPoint(Jo).applyMatrix4(e),r=this.normal.applyMatrix3(n).normalize();return this.constant=-s.dot(r),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const zi=new $n,zm=new Ie(.5,.5),xa=new N;class zc{constructor(e=new Xi,t=new Xi,n=new Xi,s=new Xi,r=new Xi,a=new Xi){this.planes=[e,t,n,s,r,a]}set(e,t,n,s,r,a){const o=this.planes;return o[0].copy(e),o[1].copy(t),o[2].copy(n),o[3].copy(s),o[4].copy(r),o[5].copy(a),this}copy(e){const t=this.planes;for(let n=0;n<6;n++)t[n].copy(e.planes[n]);return this}setFromProjectionMatrix(e,t=Wn,n=!1){const s=this.planes,r=e.elements,a=r[0],o=r[1],c=r[2],l=r[3],u=r[4],d=r[5],h=r[6],p=r[7],g=r[8],v=r[9],m=r[10],f=r[11],_=r[12],x=r[13],y=r[14],A=r[15];if(s[0].setComponents(l-a,p-u,f-g,A-_).normalize(),s[1].setComponents(l+a,p+u,f+g,A+_).normalize(),s[2].setComponents(l+o,p+d,f+v,A+x).normalize(),s[3].setComponents(l-o,p-d,f-v,A-x).normalize(),n)s[4].setComponents(c,h,m,y).normalize(),s[5].setComponents(l-c,p-h,f-m,A-y).normalize();else if(s[4].setComponents(l-c,p-h,f-m,A-y).normalize(),t===Wn)s[5].setComponents(l+c,p+h,f+m,A+y).normalize();else if(t===Xa)s[5].setComponents(c,h,m,y).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),zi.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),zi.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(zi)}intersectsSprite(e){zi.center.set(0,0,0);const t=zm.distanceTo(e.center);return zi.radius=.7071067811865476+t,zi.applyMatrix4(e.matrixWorld),this.intersectsSphere(zi)}intersectsSphere(e){const t=this.planes,n=e.center,s=-e.radius;for(let r=0;r<6;r++)if(t[r].distanceToPoint(n)<s)return!1;return!0}intersectsBox(e){const t=this.planes;for(let n=0;n<6;n++){const s=t[n];if(xa.x=s.normal.x>0?e.max.x:e.min.x,xa.y=s.normal.y>0?e.max.y:e.min.y,xa.z=s.normal.z>0?e.max.z:e.min.z,s.distanceToPoint(xa)<0)return!1}return!0}containsPoint(e){const t=this.planes;for(let n=0;n<6;n++)if(t[n].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class Vc extends Rn{constructor(e){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new Re(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}}const ja=new N,$a=new N,Zu=new Ye,hr=new Fr,ya=new $n,Qo=new N,Ju=new N;class Hc extends bt{constructor(e=new It,t=new Vc){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,n=[0];for(let s=1,r=t.count;s<r;s++)ja.fromBufferAttribute(t,s-1),$a.fromBufferAttribute(t,s),n[s]=n[s-1],n[s]+=ja.distanceTo($a);e.setAttribute("lineDistance",new nt(n,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(e,t){const n=this.geometry,s=this.matrixWorld,r=e.params.Line.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),ya.copy(n.boundingSphere),ya.applyMatrix4(s),ya.radius+=r,e.ray.intersectsSphere(ya)===!1)return;Zu.copy(s).invert(),hr.copy(e.ray).applyMatrix4(Zu);const o=r/((this.scale.x+this.scale.y+this.scale.z)/3),c=o*o,l=this.isLineSegments?2:1,u=n.index,h=n.attributes.position;if(u!==null){const p=Math.max(0,a.start),g=Math.min(u.count,a.start+a.count);for(let v=p,m=g-1;v<m;v+=l){const f=u.getX(v),_=u.getX(v+1),x=Sa(this,e,hr,c,f,_,v);x&&t.push(x)}if(this.isLineLoop){const v=u.getX(g-1),m=u.getX(p),f=Sa(this,e,hr,c,v,m,g-1);f&&t.push(f)}}else{const p=Math.max(0,a.start),g=Math.min(h.count,a.start+a.count);for(let v=p,m=g-1;v<m;v+=l){const f=Sa(this,e,hr,c,v,v+1,v);f&&t.push(f)}if(this.isLineLoop){const v=Sa(this,e,hr,c,g-1,p,g-1);v&&t.push(v)}}}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=s.length;r<a;r++){const o=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}}function Sa(i,e,t,n,s,r,a){const o=i.geometry.attributes.position;if(ja.fromBufferAttribute(o,s),$a.fromBufferAttribute(o,r),t.distanceSqToSegment(ja,$a,Qo,Ju)>n)return;Qo.applyMatrix4(i.matrixWorld);const l=e.ray.origin.distanceTo(Qo);if(!(l<e.near||l>e.far))return{distance:l,point:Ju.clone().applyMatrix4(i.matrixWorld),index:a,face:null,faceIndex:null,barycoord:null,object:i}}const Qu=new N,ed=new N;class rf extends Hc{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,n=[];for(let s=0,r=t.count;s<r;s+=2)Qu.fromBufferAttribute(t,s),ed.fromBufferAttribute(t,s+1),n[s]=s===0?0:n[s-1],n[s+1]=n[s]+Qu.distanceTo(ed);e.setAttribute("lineDistance",new nt(n,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class Vm extends Hc{constructor(e,t){super(e,t),this.isLineLoop=!0,this.type="LineLoop"}}class af extends Rn{constructor(e){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new Re(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}const td=new Ye,uc=new Fr,ba=new $n,Ma=new N;class Gc extends bt{constructor(e=new It,t=new af){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}raycast(e,t){const n=this.geometry,s=this.matrixWorld,r=e.params.Points.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),ba.copy(n.boundingSphere),ba.applyMatrix4(s),ba.radius+=r,e.ray.intersectsSphere(ba)===!1)return;td.copy(s).invert(),uc.copy(e.ray).applyMatrix4(td);const o=r/((this.scale.x+this.scale.y+this.scale.z)/3),c=o*o,l=n.index,d=n.attributes.position;if(l!==null){const h=Math.max(0,a.start),p=Math.min(l.count,a.start+a.count);for(let g=h,v=p;g<v;g++){const m=l.getX(g);Ma.fromBufferAttribute(d,m),nd(Ma,m,c,s,e,t,this)}}else{const h=Math.max(0,a.start),p=Math.min(d.count,a.start+a.count);for(let g=h,v=p;g<v;g++)Ma.fromBufferAttribute(d,g),nd(Ma,g,c,s,e,t,this)}}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=s.length;r<a;r++){const o=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}}function nd(i,e,t,n,s,r,a){const o=uc.distanceSqToPoint(i);if(o<t){const c=new N;uc.closestPointToPoint(i,c),c.applyMatrix4(n);const l=s.ray.origin.distanceTo(c);if(l<s.near||l>s.far)return;r.push({distance:l,distanceToRay:Math.sqrt(o),point:c,index:e,face:null,faceIndex:null,barycoord:null,object:a})}}class co extends Ft{constructor(e,t,n,s,r,a,o,c,l){super(e,t,n,s,r,a,o,c,l),this.isCanvasTexture=!0,this.needsUpdate=!0}}class of extends Ft{constructor(e,t,n=Ki,s,r,a,o=Jt,c=Jt,l,u=Rr,d=1){if(u!==Rr&&u!==Cr)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const h={width:e,height:t,depth:d};super(h,s,r,a,o,c,u,n,l),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new Fc(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){const t=super.toJSON(e);return this.compareFunction!==null&&(t.compareFunction=this.compareFunction),t}}class lf extends Ft{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}}class Wc extends It{constructor(e=1,t=1,n=1,s=32,r=1,a=!1,o=0,c=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:t,height:n,radialSegments:s,heightSegments:r,openEnded:a,thetaStart:o,thetaLength:c};const l=this;s=Math.floor(s),r=Math.floor(r);const u=[],d=[],h=[],p=[];let g=0;const v=[],m=n/2;let f=0;_(),a===!1&&(e>0&&x(!0),t>0&&x(!1)),this.setIndex(u),this.setAttribute("position",new nt(d,3)),this.setAttribute("normal",new nt(h,3)),this.setAttribute("uv",new nt(p,2));function _(){const y=new N,A=new N;let E=0;const M=(t-e)/n;for(let C=0;C<=r;C++){const b=[],S=C/r,I=S*(t-e)+e;for(let D=0;D<=s;D++){const w=D/s,U=w*c+o,O=Math.sin(U),F=Math.cos(U);A.x=I*O,A.y=-S*n+m,A.z=I*F,d.push(A.x,A.y,A.z),y.set(O,M,F).normalize(),h.push(y.x,y.y,y.z),p.push(w,1-S),b.push(g++)}v.push(b)}for(let C=0;C<s;C++)for(let b=0;b<r;b++){const S=v[b][C],I=v[b+1][C],D=v[b+1][C+1],w=v[b][C+1];(e>0||b!==0)&&(u.push(S,I,w),E+=3),(t>0||b!==r-1)&&(u.push(I,D,w),E+=3)}l.addGroup(f,E,0),f+=E}function x(y){const A=g,E=new Ie,M=new N;let C=0;const b=y===!0?e:t,S=y===!0?1:-1;for(let D=1;D<=s;D++)d.push(0,m*S,0),h.push(0,S,0),p.push(.5,.5),g++;const I=g;for(let D=0;D<=s;D++){const U=D/s*c+o,O=Math.cos(U),F=Math.sin(U);M.x=b*F,M.y=m*S,M.z=b*O,d.push(M.x,M.y,M.z),h.push(0,S,0),E.x=O*.5+.5,E.y=F*.5*S+.5,p.push(E.x,E.y),g++}for(let D=0;D<s;D++){const w=A+D,U=I+D;y===!0?u.push(U,U+1,w):u.push(U+1,U,w),C+=3}l.addGroup(f,C,y===!0?1:2),f+=C}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Wc(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class _n extends It{constructor(e=1,t=1,n=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:n,heightSegments:s};const r=e/2,a=t/2,o=Math.floor(n),c=Math.floor(s),l=o+1,u=c+1,d=e/o,h=t/c,p=[],g=[],v=[],m=[];for(let f=0;f<u;f++){const _=f*h-a;for(let x=0;x<l;x++){const y=x*d-r;g.push(y,-_,0),v.push(0,0,1),m.push(x/o),m.push(1-f/c)}}for(let f=0;f<c;f++)for(let _=0;_<o;_++){const x=_+l*f,y=_+l*(f+1),A=_+1+l*(f+1),E=_+1+l*f;p.push(x,y,E),p.push(y,A,E)}this.setIndex(p),this.setAttribute("position",new nt(g,3)),this.setAttribute("normal",new nt(v,3)),this.setAttribute("uv",new nt(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new _n(e.width,e.height,e.widthSegments,e.heightSegments)}}class uo extends It{constructor(e=.5,t=1,n=32,s=1,r=0,a=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:e,outerRadius:t,thetaSegments:n,phiSegments:s,thetaStart:r,thetaLength:a},n=Math.max(3,n),s=Math.max(1,s);const o=[],c=[],l=[],u=[];let d=e;const h=(t-e)/s,p=new N,g=new Ie;for(let v=0;v<=s;v++){for(let m=0;m<=n;m++){const f=r+m/n*a;p.x=d*Math.cos(f),p.y=d*Math.sin(f),c.push(p.x,p.y,p.z),l.push(0,0,1),g.x=(p.x/t+1)/2,g.y=(p.y/t+1)/2,u.push(g.x,g.y)}d+=h}for(let v=0;v<s;v++){const m=v*(n+1);for(let f=0;f<n;f++){const _=f+m,x=_,y=_+n+1,A=_+n+2,E=_+1;o.push(x,y,E),o.push(y,A,E)}}this.setIndex(o),this.setAttribute("position",new nt(c,3)),this.setAttribute("normal",new nt(l,3)),this.setAttribute("uv",new nt(u,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new uo(e.innerRadius,e.outerRadius,e.thetaSegments,e.phiSegments,e.thetaStart,e.thetaLength)}}class Xc extends It{constructor(e=1,t=32,n=16,s=0,r=Math.PI*2,a=0,o=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:t,heightSegments:n,phiStart:s,phiLength:r,thetaStart:a,thetaLength:o},t=Math.max(3,Math.floor(t)),n=Math.max(2,Math.floor(n));const c=Math.min(a+o,Math.PI);let l=0;const u=[],d=new N,h=new N,p=[],g=[],v=[],m=[];for(let f=0;f<=n;f++){const _=[],x=f/n;let y=0;f===0&&a===0?y=.5/t:f===n&&c===Math.PI&&(y=-.5/t);for(let A=0;A<=t;A++){const E=A/t;d.x=-e*Math.cos(s+E*r)*Math.sin(a+x*o),d.y=e*Math.cos(a+x*o),d.z=e*Math.sin(s+E*r)*Math.sin(a+x*o),g.push(d.x,d.y,d.z),h.copy(d).normalize(),v.push(h.x,h.y,h.z),m.push(E+y,1-x),_.push(l++)}u.push(_)}for(let f=0;f<n;f++)for(let _=0;_<t;_++){const x=u[f][_+1],y=u[f][_],A=u[f+1][_],E=u[f+1][_+1];(f!==0||a>0)&&p.push(x,y,E),(f!==n-1||c<Math.PI)&&p.push(y,A,E)}this.setIndex(p),this.setAttribute("position",new nt(g,3)),this.setAttribute("normal",new nt(v,3)),this.setAttribute("uv",new nt(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Xc(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}}class qc extends Rn{constructor(e){super(),this.isMeshStandardMaterial=!0,this.type="MeshStandardMaterial",this.defines={STANDARD:""},this.color=new Re(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Re(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Oc,this.normalScale=new Ie(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new vn,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class Kn extends qc{constructor(e){super(),this.isMeshPhysicalMaterial=!0,this.defines={STANDARD:"",PHYSICAL:""},this.type="MeshPhysicalMaterial",this.anisotropyRotation=0,this.anisotropyMap=null,this.clearcoatMap=null,this.clearcoatRoughness=0,this.clearcoatRoughnessMap=null,this.clearcoatNormalScale=new Ie(1,1),this.clearcoatNormalMap=null,this.ior=1.5,Object.defineProperty(this,"reflectivity",{get:function(){return Je(2.5*(this.ior-1)/(this.ior+1),0,1)},set:function(t){this.ior=(1+.4*t)/(1-.4*t)}}),this.iridescenceMap=null,this.iridescenceIOR=1.3,this.iridescenceThicknessRange=[100,400],this.iridescenceThicknessMap=null,this.sheenColor=new Re(0),this.sheenColorMap=null,this.sheenRoughness=1,this.sheenRoughnessMap=null,this.transmissionMap=null,this.thickness=0,this.thicknessMap=null,this.attenuationDistance=1/0,this.attenuationColor=new Re(1,1,1),this.specularIntensity=1,this.specularIntensityMap=null,this.specularColor=new Re(1,1,1),this.specularColorMap=null,this._anisotropy=0,this._clearcoat=0,this._dispersion=0,this._iridescence=0,this._sheen=0,this._transmission=0,this.setValues(e)}get anisotropy(){return this._anisotropy}set anisotropy(e){this._anisotropy>0!=e>0&&this.version++,this._anisotropy=e}get clearcoat(){return this._clearcoat}set clearcoat(e){this._clearcoat>0!=e>0&&this.version++,this._clearcoat=e}get iridescence(){return this._iridescence}set iridescence(e){this._iridescence>0!=e>0&&this.version++,this._iridescence=e}get dispersion(){return this._dispersion}set dispersion(e){this._dispersion>0!=e>0&&this.version++,this._dispersion=e}get sheen(){return this._sheen}set sheen(e){this._sheen>0!=e>0&&this.version++,this._sheen=e}get transmission(){return this._transmission}set transmission(e){this._transmission>0!=e>0&&this.version++,this._transmission=e}copy(e){return super.copy(e),this.defines={STANDARD:"",PHYSICAL:""},this.anisotropy=e.anisotropy,this.anisotropyRotation=e.anisotropyRotation,this.anisotropyMap=e.anisotropyMap,this.clearcoat=e.clearcoat,this.clearcoatMap=e.clearcoatMap,this.clearcoatRoughness=e.clearcoatRoughness,this.clearcoatRoughnessMap=e.clearcoatRoughnessMap,this.clearcoatNormalMap=e.clearcoatNormalMap,this.clearcoatNormalScale.copy(e.clearcoatNormalScale),this.dispersion=e.dispersion,this.ior=e.ior,this.iridescence=e.iridescence,this.iridescenceMap=e.iridescenceMap,this.iridescenceIOR=e.iridescenceIOR,this.iridescenceThicknessRange=[...e.iridescenceThicknessRange],this.iridescenceThicknessMap=e.iridescenceThicknessMap,this.sheen=e.sheen,this.sheenColor.copy(e.sheenColor),this.sheenColorMap=e.sheenColorMap,this.sheenRoughness=e.sheenRoughness,this.sheenRoughnessMap=e.sheenRoughnessMap,this.transmission=e.transmission,this.transmissionMap=e.transmissionMap,this.thickness=e.thickness,this.thicknessMap=e.thicknessMap,this.attenuationDistance=e.attenuationDistance,this.attenuationColor.copy(e.attenuationColor),this.specularIntensity=e.specularIntensity,this.specularIntensityMap=e.specularIntensityMap,this.specularColor.copy(e.specularColor),this.specularColorMap=e.specularColorMap,this}}class Hm extends Rn{constructor(e){super(),this.isMeshLambertMaterial=!0,this.type="MeshLambertMaterial",this.color=new Re(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Re(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Oc,this.normalScale=new Ie(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new vn,this.combine=wc,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class Gm extends Rn{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=Fp,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class Wm extends Rn{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}function Ea(i,e){return!i||i.constructor===e?i:typeof e.BYTES_PER_ELEMENT=="number"?new e(i):Array.prototype.slice.call(i)}function Xm(i){return ArrayBuffer.isView(i)&&!(i instanceof DataView)}function qm(i){function e(s,r){return i[s]-i[r]}const t=i.length,n=new Array(t);for(let s=0;s!==t;++s)n[s]=s;return n.sort(e),n}function id(i,e,t){const n=i.length,s=new i.constructor(n);for(let r=0,a=0;a!==n;++r){const o=t[r]*e;for(let c=0;c!==e;++c)s[a++]=i[o+c]}return s}function cf(i,e,t,n){let s=1,r=i[0];for(;r!==void 0&&r[n]===void 0;)r=i[s++];if(r===void 0)return;let a=r[n];if(a!==void 0)if(Array.isArray(a))do a=r[n],a!==void 0&&(e.push(r.time),t.push(...a)),r=i[s++];while(r!==void 0);else if(a.toArray!==void 0)do a=r[n],a!==void 0&&(e.push(r.time),a.toArray(t,t.length)),r=i[s++];while(r!==void 0);else do a=r[n],a!==void 0&&(e.push(r.time),t.push(a)),r=i[s++];while(r!==void 0)}class Vr{constructor(e,t,n,s){this.parameterPositions=e,this._cachedIndex=0,this.resultBuffer=s!==void 0?s:new t.constructor(n),this.sampleValues=t,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(e){const t=this.parameterPositions;let n=this._cachedIndex,s=t[n],r=t[n-1];n:{e:{let a;t:{i:if(!(e<s)){for(let o=n+2;;){if(s===void 0){if(e<r)break i;return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===o)break;if(r=s,s=t[++n],e<s)break e}a=t.length;break t}if(!(e>=r)){const o=t[1];e<o&&(n=2,r=o);for(let c=n-2;;){if(r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===c)break;if(s=r,r=t[--n-1],e>=r)break e}a=n,n=0;break t}break n}for(;n<a;){const o=n+a>>>1;e<t[o]?a=o:n=o+1}if(s=t[n],r=t[n-1],r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(s===void 0)return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,r,s)}return this.interpolate_(n,r,e,s)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(e){const t=this.resultBuffer,n=this.sampleValues,s=this.valueSize,r=e*s;for(let a=0;a!==s;++a)t[a]=n[r+a];return t}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}}class Ym extends Vr{constructor(e,t,n,s){super(e,t,n,s),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:_u,endingEnd:_u}}intervalChanged_(e,t,n){const s=this.parameterPositions;let r=e-2,a=e+1,o=s[r],c=s[a];if(o===void 0)switch(this.getSettings_().endingStart){case xu:r=e,o=2*t-n;break;case yu:r=s.length-2,o=t+s[r]-s[r+1];break;default:r=e,o=n}if(c===void 0)switch(this.getSettings_().endingEnd){case xu:a=e,c=2*n-t;break;case yu:a=1,c=n+s[1]-s[0];break;default:a=e-1,c=t}const l=(n-t)*.5,u=this.valueSize;this._weightPrev=l/(t-o),this._weightNext=l/(c-n),this._offsetPrev=r*u,this._offsetNext=a*u}interpolate_(e,t,n,s){const r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,c=e*o,l=c-o,u=this._offsetPrev,d=this._offsetNext,h=this._weightPrev,p=this._weightNext,g=(n-t)/(s-t),v=g*g,m=v*g,f=-h*m+2*h*v-h*g,_=(1+h)*m+(-1.5-2*h)*v+(-.5+h)*g+1,x=(-1-p)*m+(1.5+p)*v+.5*g,y=p*m-p*v;for(let A=0;A!==o;++A)r[A]=f*a[u+A]+_*a[l+A]+x*a[c+A]+y*a[d+A];return r}}class jm extends Vr{constructor(e,t,n,s){super(e,t,n,s)}interpolate_(e,t,n,s){const r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,c=e*o,l=c-o,u=(n-t)/(s-t),d=1-u;for(let h=0;h!==o;++h)r[h]=a[l+h]*d+a[c+h]*u;return r}}class $m extends Vr{constructor(e,t,n,s){super(e,t,n,s)}interpolate_(e){return this.copySampleValue_(e-1)}}class zn{constructor(e,t,n,s){if(e===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(t===void 0||t.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+e);this.name=e,this.times=Ea(t,this.TimeBufferType),this.values=Ea(n,this.ValueBufferType),this.setInterpolation(s||this.DefaultInterpolation)}static toJSON(e){const t=e.constructor;let n;if(t.toJSON!==this.toJSON)n=t.toJSON(e);else{n={name:e.name,times:Ea(e.times,Array),values:Ea(e.values,Array)};const s=e.getInterpolation();s!==e.DefaultInterpolation&&(n.interpolation=s)}return n.type=e.ValueTypeName,n}InterpolantFactoryMethodDiscrete(e){return new $m(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodLinear(e){return new jm(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodSmooth(e){return new Ym(this.times,this.values,this.getValueSize(),e)}setInterpolation(e){let t;switch(e){case Ir:t=this.InterpolantFactoryMethodDiscrete;break;case Pr:t=this.InterpolantFactoryMethodLinear;break;case wo:t=this.InterpolantFactoryMethodSmooth;break}if(t===void 0){const n="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(e!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(n);return console.warn("THREE.KeyframeTrack:",n),this}return this.createInterpolant=t,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return Ir;case this.InterpolantFactoryMethodLinear:return Pr;case this.InterpolantFactoryMethodSmooth:return wo}}getValueSize(){return this.values.length/this.times.length}shift(e){if(e!==0){const t=this.times;for(let n=0,s=t.length;n!==s;++n)t[n]+=e}return this}scale(e){if(e!==1){const t=this.times;for(let n=0,s=t.length;n!==s;++n)t[n]*=e}return this}trim(e,t){const n=this.times,s=n.length;let r=0,a=s-1;for(;r!==s&&n[r]<e;)++r;for(;a!==-1&&n[a]>t;)--a;if(++a,r!==0||a!==s){r>=a&&(a=Math.max(a,1),r=a-1);const o=this.getValueSize();this.times=n.slice(r,a),this.values=this.values.slice(r*o,a*o)}return this}validate(){let e=!0;const t=this.getValueSize();t-Math.floor(t)!==0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),e=!1);const n=this.times,s=this.values,r=n.length;r===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),e=!1);let a=null;for(let o=0;o!==r;o++){const c=n[o];if(typeof c=="number"&&isNaN(c)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,o,c),e=!1;break}if(a!==null&&a>c){console.error("THREE.KeyframeTrack: Out of order keys.",this,o,c,a),e=!1;break}a=c}if(s!==void 0&&Xm(s))for(let o=0,c=s.length;o!==c;++o){const l=s[o];if(isNaN(l)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,o,l),e=!1;break}}return e}optimize(){const e=this.times.slice(),t=this.values.slice(),n=this.getValueSize(),s=this.getInterpolation()===wo,r=e.length-1;let a=1;for(let o=1;o<r;++o){let c=!1;const l=e[o],u=e[o+1];if(l!==u&&(o!==1||l!==e[0]))if(s)c=!0;else{const d=o*n,h=d-n,p=d+n;for(let g=0;g!==n;++g){const v=t[d+g];if(v!==t[h+g]||v!==t[p+g]){c=!0;break}}}if(c){if(o!==a){e[a]=e[o];const d=o*n,h=a*n;for(let p=0;p!==n;++p)t[h+p]=t[d+p]}++a}}if(r>0){e[a]=e[r];for(let o=r*n,c=a*n,l=0;l!==n;++l)t[c+l]=t[o+l];++a}return a!==e.length?(this.times=e.slice(0,a),this.values=t.slice(0,a*n)):(this.times=e,this.values=t),this}clone(){const e=this.times.slice(),t=this.values.slice(),n=this.constructor,s=new n(this.name,e,t);return s.createInterpolant=this.createInterpolant,s}}zn.prototype.ValueTypeName="";zn.prototype.TimeBufferType=Float32Array;zn.prototype.ValueBufferType=Float32Array;zn.prototype.DefaultInterpolation=Pr;class Ks extends zn{constructor(e,t,n){super(e,t,n)}}Ks.prototype.ValueTypeName="bool";Ks.prototype.ValueBufferType=Array;Ks.prototype.DefaultInterpolation=Ir;Ks.prototype.InterpolantFactoryMethodLinear=void 0;Ks.prototype.InterpolantFactoryMethodSmooth=void 0;class uf extends zn{constructor(e,t,n,s){super(e,t,n,s)}}uf.prototype.ValueTypeName="color";class Vs extends zn{constructor(e,t,n,s){super(e,t,n,s)}}Vs.prototype.ValueTypeName="number";class Km extends Vr{constructor(e,t,n,s){super(e,t,n,s)}interpolate_(e,t,n,s){const r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,c=(n-t)/(s-t);let l=e*o;for(let u=l+o;l!==u;l+=4)dt.slerpFlat(r,0,a,l-o,a,l,c);return r}}class Hs extends zn{constructor(e,t,n,s){super(e,t,n,s)}InterpolantFactoryMethodLinear(e){return new Km(this.times,this.values,this.getValueSize(),e)}}Hs.prototype.ValueTypeName="quaternion";Hs.prototype.InterpolantFactoryMethodSmooth=void 0;class Zs extends zn{constructor(e,t,n){super(e,t,n)}}Zs.prototype.ValueTypeName="string";Zs.prototype.ValueBufferType=Array;Zs.prototype.DefaultInterpolation=Ir;Zs.prototype.InterpolantFactoryMethodLinear=void 0;Zs.prototype.InterpolantFactoryMethodSmooth=void 0;class Gs extends zn{constructor(e,t,n,s){super(e,t,n,s)}}Gs.prototype.ValueTypeName="vector";class Zm{constructor(e="",t=-1,n=[],s=Op){this.name=e,this.tracks=n,this.duration=t,this.blendMode=s,this.uuid=Bn(),this.userData={},this.duration<0&&this.resetDuration()}static parse(e){const t=[],n=e.tracks,s=1/(e.fps||1);for(let a=0,o=n.length;a!==o;++a)t.push(Qm(n[a]).scale(s));const r=new this(e.name,e.duration,t,e.blendMode);return r.uuid=e.uuid,r.userData=JSON.parse(e.userData||"{}"),r}static toJSON(e){const t=[],n=e.tracks,s={name:e.name,duration:e.duration,tracks:t,uuid:e.uuid,blendMode:e.blendMode,userData:JSON.stringify(e.userData)};for(let r=0,a=n.length;r!==a;++r)t.push(zn.toJSON(n[r]));return s}static CreateFromMorphTargetSequence(e,t,n,s){const r=t.length,a=[];for(let o=0;o<r;o++){let c=[],l=[];c.push((o+r-1)%r,o,(o+1)%r),l.push(0,1,0);const u=qm(c);c=id(c,1,u),l=id(l,1,u),!s&&c[0]===0&&(c.push(r),l.push(l[0])),a.push(new Vs(".morphTargetInfluences["+t[o].name+"]",c,l).scale(1/n))}return new this(e,-1,a)}static findByName(e,t){let n=e;if(!Array.isArray(e)){const s=e;n=s.geometry&&s.geometry.animations||s.animations}for(let s=0;s<n.length;s++)if(n[s].name===t)return n[s];return null}static CreateClipsFromMorphTargetSequences(e,t,n){const s={},r=/^([\w-]*?)([\d]+)$/;for(let o=0,c=e.length;o<c;o++){const l=e[o],u=l.name.match(r);if(u&&u.length>1){const d=u[1];let h=s[d];h||(s[d]=h=[]),h.push(l)}}const a=[];for(const o in s)a.push(this.CreateFromMorphTargetSequence(o,s[o],t,n));return a}static parseAnimation(e,t){if(console.warn("THREE.AnimationClip: parseAnimation() is deprecated and will be removed with r185"),!e)return console.error("THREE.AnimationClip: No animation in JSONLoader data."),null;const n=function(d,h,p,g,v){if(p.length!==0){const m=[],f=[];cf(p,m,f,g),m.length!==0&&v.push(new d(h,m,f))}},s=[],r=e.name||"default",a=e.fps||30,o=e.blendMode;let c=e.length||-1;const l=e.hierarchy||[];for(let d=0;d<l.length;d++){const h=l[d].keys;if(!(!h||h.length===0))if(h[0].morphTargets){const p={};let g;for(g=0;g<h.length;g++)if(h[g].morphTargets)for(let v=0;v<h[g].morphTargets.length;v++)p[h[g].morphTargets[v]]=-1;for(const v in p){const m=[],f=[];for(let _=0;_!==h[g].morphTargets.length;++_){const x=h[g];m.push(x.time),f.push(x.morphTarget===v?1:0)}s.push(new Vs(".morphTargetInfluence["+v+"]",m,f))}c=p.length*a}else{const p=".bones["+t[d].name+"]";n(Gs,p+".position",h,"pos",s),n(Hs,p+".quaternion",h,"rot",s),n(Gs,p+".scale",h,"scl",s)}}return s.length===0?null:new this(r,c,s,o)}resetDuration(){const e=this.tracks;let t=0;for(let n=0,s=e.length;n!==s;++n){const r=this.tracks[n];t=Math.max(t,r.times[r.times.length-1])}return this.duration=t,this}trim(){for(let e=0;e<this.tracks.length;e++)this.tracks[e].trim(0,this.duration);return this}validate(){let e=!0;for(let t=0;t<this.tracks.length;t++)e=e&&this.tracks[t].validate();return e}optimize(){for(let e=0;e<this.tracks.length;e++)this.tracks[e].optimize();return this}clone(){const e=[];for(let n=0;n<this.tracks.length;n++)e.push(this.tracks[n].clone());const t=new this.constructor(this.name,this.duration,e,this.blendMode);return t.userData=JSON.parse(JSON.stringify(this.userData)),t}toJSON(){return this.constructor.toJSON(this)}}function Jm(i){switch(i.toLowerCase()){case"scalar":case"double":case"float":case"number":case"integer":return Vs;case"vector":case"vector2":case"vector3":case"vector4":return Gs;case"color":return uf;case"quaternion":return Hs;case"bool":case"boolean":return Ks;case"string":return Zs}throw new Error("THREE.KeyframeTrack: Unsupported typeName: "+i)}function Qm(i){if(i.type===void 0)throw new Error("THREE.KeyframeTrack: track type undefined, can not parse");const e=Jm(i.type);if(i.times===void 0){const t=[],n=[];cf(i.keys,t,n,"value"),i.times=t,i.values=n}return e.parse!==void 0?e.parse(i):new e(i.name,i.times,i.values,i.interpolation)}const li={enabled:!1,files:{},add:function(i,e){this.enabled!==!1&&(this.files[i]=e)},get:function(i){if(this.enabled!==!1)return this.files[i]},remove:function(i){delete this.files[i]},clear:function(){this.files={}}};class eg{constructor(e,t,n){const s=this;let r=!1,a=0,o=0,c;const l=[];this.onStart=void 0,this.onLoad=e,this.onProgress=t,this.onError=n,this.abortController=new AbortController,this.itemStart=function(u){o++,r===!1&&s.onStart!==void 0&&s.onStart(u,a,o),r=!0},this.itemEnd=function(u){a++,s.onProgress!==void 0&&s.onProgress(u,a,o),a===o&&(r=!1,s.onLoad!==void 0&&s.onLoad())},this.itemError=function(u){s.onError!==void 0&&s.onError(u)},this.resolveURL=function(u){return c?c(u):u},this.setURLModifier=function(u){return c=u,this},this.addHandler=function(u,d){return l.push(u,d),this},this.removeHandler=function(u){const d=l.indexOf(u);return d!==-1&&l.splice(d,2),this},this.getHandler=function(u){for(let d=0,h=l.length;d<h;d+=2){const p=l[d],g=l[d+1];if(p.global&&(p.lastIndex=0),p.test(u))return g}return null},this.abort=function(){return this.abortController.abort(),this.abortController=new AbortController,this}}}const tg=new eg;class Js{constructor(e){this.manager=e!==void 0?e:tg,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(e,t){const n=this;return new Promise(function(s,r){n.load(e,s,t,r)})}parse(){}setCrossOrigin(e){return this.crossOrigin=e,this}setWithCredentials(e){return this.withCredentials=e,this}setPath(e){return this.path=e,this}setResourcePath(e){return this.resourcePath=e,this}setRequestHeader(e){return this.requestHeader=e,this}abort(){return this}}Js.DEFAULT_MATERIAL_NAME="__DEFAULT";const ii={};class ng extends Error{constructor(e,t){super(e),this.response=t}}class df extends Js{constructor(e){super(e),this.mimeType="",this.responseType="",this._abortController=new AbortController}load(e,t,n,s){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);const r=li.get(`file:${e}`);if(r!==void 0)return this.manager.itemStart(e),setTimeout(()=>{t&&t(r),this.manager.itemEnd(e)},0),r;if(ii[e]!==void 0){ii[e].push({onLoad:t,onProgress:n,onError:s});return}ii[e]=[],ii[e].push({onLoad:t,onProgress:n,onError:s});const a=new Request(e,{headers:new Headers(this.requestHeader),credentials:this.withCredentials?"include":"same-origin",signal:typeof AbortSignal.any=="function"?AbortSignal.any([this._abortController.signal,this.manager.abortController.signal]):this._abortController.signal}),o=this.mimeType,c=this.responseType;fetch(a).then(l=>{if(l.status===200||l.status===0){if(l.status===0&&console.warn("THREE.FileLoader: HTTP Status 0 received."),typeof ReadableStream>"u"||l.body===void 0||l.body.getReader===void 0)return l;const u=ii[e],d=l.body.getReader(),h=l.headers.get("X-File-Size")||l.headers.get("Content-Length"),p=h?parseInt(h):0,g=p!==0;let v=0;const m=new ReadableStream({start(f){_();function _(){d.read().then(({done:x,value:y})=>{if(x)f.close();else{v+=y.byteLength;const A=new ProgressEvent("progress",{lengthComputable:g,loaded:v,total:p});for(let E=0,M=u.length;E<M;E++){const C=u[E];C.onProgress&&C.onProgress(A)}f.enqueue(y),_()}},x=>{f.error(x)})}}});return new Response(m)}else throw new ng(`fetch for "${l.url}" responded with ${l.status}: ${l.statusText}`,l)}).then(l=>{switch(c){case"arraybuffer":return l.arrayBuffer();case"blob":return l.blob();case"document":return l.text().then(u=>new DOMParser().parseFromString(u,o));case"json":return l.json();default:if(o==="")return l.text();{const d=/charset="?([^;"\s]*)"?/i.exec(o),h=d&&d[1]?d[1].toLowerCase():void 0,p=new TextDecoder(h);return l.arrayBuffer().then(g=>p.decode(g))}}}).then(l=>{li.add(`file:${e}`,l);const u=ii[e];delete ii[e];for(let d=0,h=u.length;d<h;d++){const p=u[d];p.onLoad&&p.onLoad(l)}}).catch(l=>{const u=ii[e];if(u===void 0)throw this.manager.itemError(e),l;delete ii[e];for(let d=0,h=u.length;d<h;d++){const p=u[d];p.onError&&p.onError(l)}this.manager.itemError(e)}).finally(()=>{this.manager.itemEnd(e)}),this.manager.itemStart(e)}setResponseType(e){return this.responseType=e,this}setMimeType(e){return this.mimeType=e,this}abort(){return this._abortController.abort(),this._abortController=new AbortController,this}}const ys=new WeakMap;class ig extends Js{constructor(e){super(e)}load(e,t,n,s){this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);const r=this,a=li.get(`image:${e}`);if(a!==void 0){if(a.complete===!0)r.manager.itemStart(e),setTimeout(function(){t&&t(a),r.manager.itemEnd(e)},0);else{let d=ys.get(a);d===void 0&&(d=[],ys.set(a,d)),d.push({onLoad:t,onError:s})}return a}const o=Lr("img");function c(){u(),t&&t(this);const d=ys.get(this)||[];for(let h=0;h<d.length;h++){const p=d[h];p.onLoad&&p.onLoad(this)}ys.delete(this),r.manager.itemEnd(e)}function l(d){u(),s&&s(d),li.remove(`image:${e}`);const h=ys.get(this)||[];for(let p=0;p<h.length;p++){const g=h[p];g.onError&&g.onError(d)}ys.delete(this),r.manager.itemError(e),r.manager.itemEnd(e)}function u(){o.removeEventListener("load",c,!1),o.removeEventListener("error",l,!1)}return o.addEventListener("load",c,!1),o.addEventListener("error",l,!1),e.slice(0,5)!=="data:"&&this.crossOrigin!==void 0&&(o.crossOrigin=this.crossOrigin),li.add(`image:${e}`,o),r.manager.itemStart(e),o.src=e,o}}class Qs extends Js{constructor(e){super(e)}load(e,t,n,s){const r=new Ft,a=new ig(this.manager);return a.setCrossOrigin(this.crossOrigin),a.setPath(this.path),a.load(e,function(o){r.image=o,r.needsUpdate=!0,t!==void 0&&t(r)},n,s),r}}class ho extends bt{constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new Re(e),this.intensity=t}dispose(){}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){const t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,this.groundColor!==void 0&&(t.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(t.object.distance=this.distance),this.angle!==void 0&&(t.object.angle=this.angle),this.decay!==void 0&&(t.object.decay=this.decay),this.penumbra!==void 0&&(t.object.penumbra=this.penumbra),this.shadow!==void 0&&(t.object.shadow=this.shadow.toJSON()),this.target!==void 0&&(t.object.target=this.target.uuid),t}}class sg extends ho{constructor(e,t,n){super(e,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(bt.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Re(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}}const el=new Ye,sd=new N,rd=new N;class Yc{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new Ie(512,512),this.mapType=qn,this.map=null,this.mapPass=null,this.matrix=new Ye,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new zc,this._frameExtents=new Ie(1,1),this._viewportCount=1,this._viewports=[new st(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){const t=this.camera,n=this.matrix;sd.setFromMatrixPosition(e.matrixWorld),t.position.copy(sd),rd.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(rd),t.updateMatrixWorld(),el.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),this._frustum.setFromProjectionMatrix(el,t.coordinateSystem,t.reversedDepth),t.reversedDepth?n.set(.5,0,0,.5,0,.5,0,.5,0,0,1,0,0,0,0,1):n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(el)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.autoUpdate=e.autoUpdate,this.needsUpdate=e.needsUpdate,this.normalBias=e.normalBias,this.blurSamples=e.blurSamples,this.mapSize.copy(e.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){const e={};return this.intensity!==1&&(e.intensity=this.intensity),this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}}class rg extends Yc{constructor(){super(new Kt(50,1,.5,500)),this.isSpotLightShadow=!0,this.focus=1,this.aspect=1}updateMatrices(e){const t=this.camera,n=ks*2*e.angle*this.focus,s=this.mapSize.width/this.mapSize.height*this.aspect,r=e.distance||t.far;(n!==t.fov||s!==t.aspect||r!==t.far)&&(t.fov=n,t.aspect=s,t.far=r,t.updateProjectionMatrix()),super.updateMatrices(e)}copy(e){return super.copy(e),this.focus=e.focus,this}}class ag extends ho{constructor(e,t,n=0,s=Math.PI/3,r=0,a=2){super(e,t),this.isSpotLight=!0,this.type="SpotLight",this.position.copy(bt.DEFAULT_UP),this.updateMatrix(),this.target=new bt,this.distance=n,this.angle=s,this.penumbra=r,this.decay=a,this.map=null,this.shadow=new rg}get power(){return this.intensity*Math.PI}set power(e){this.intensity=e/Math.PI}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.angle=e.angle,this.penumbra=e.penumbra,this.decay=e.decay,this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}}const ad=new Ye,fr=new N,tl=new N;class og extends Yc{constructor(){super(new Kt(90,1,.5,500)),this.isPointLightShadow=!0,this._frameExtents=new Ie(4,2),this._viewportCount=6,this._viewports=[new st(2,1,1,1),new st(0,1,1,1),new st(3,1,1,1),new st(1,1,1,1),new st(3,0,1,1),new st(1,0,1,1)],this._cubeDirections=[new N(1,0,0),new N(-1,0,0),new N(0,0,1),new N(0,0,-1),new N(0,1,0),new N(0,-1,0)],this._cubeUps=[new N(0,1,0),new N(0,1,0),new N(0,1,0),new N(0,1,0),new N(0,0,1),new N(0,0,-1)]}updateMatrices(e,t=0){const n=this.camera,s=this.matrix,r=e.distance||n.far;r!==n.far&&(n.far=r,n.updateProjectionMatrix()),fr.setFromMatrixPosition(e.matrixWorld),n.position.copy(fr),tl.copy(n.position),tl.add(this._cubeDirections[t]),n.up.copy(this._cubeUps[t]),n.lookAt(tl),n.updateMatrixWorld(),s.makeTranslation(-fr.x,-fr.y,-fr.z),ad.multiplyMatrices(n.projectionMatrix,n.matrixWorldInverse),this._frustum.setFromProjectionMatrix(ad,n.coordinateSystem,n.reversedDepth)}}class lg extends ho{constructor(e,t,n=0,s=2){super(e,t),this.isPointLight=!0,this.type="PointLight",this.distance=n,this.decay=s,this.shadow=new og}get power(){return this.intensity*4*Math.PI}set power(e){this.intensity=e/(4*Math.PI)}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.decay=e.decay,this.shadow=e.shadow.clone(),this}}class Hr extends Jh{constructor(e=-1,t=1,n=1,s=-1,r=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=n,this.bottom=s,this.near=r,this.far=a,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,n,s,r,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,s=(this.top+this.bottom)/2;let r=n-e,a=n+e,o=s+t,c=s-t;if(this.view!==null&&this.view.enabled){const l=(this.right-this.left)/this.view.fullWidth/this.zoom,u=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=l*this.view.offsetX,a=r+l*this.view.width,o-=u*this.view.offsetY,c=o-u*this.view.height}this.projectionMatrix.makeOrthographic(r,a,o,c,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}}class cg extends Yc{constructor(){super(new Hr(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class hf extends ho{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(bt.DEFAULT_UP),this.updateMatrix(),this.target=new bt,this.shadow=new cg}dispose(){this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}}class Er{static extractUrlBase(e){const t=e.lastIndexOf("/");return t===-1?"./":e.slice(0,t+1)}static resolveURL(e,t){return typeof e!="string"||e===""?"":(/^https?:\/\//i.test(t)&&/^\//.test(e)&&(t=t.replace(/(^https?:\/\/[^\/]+).*/i,"$1")),/^(https?:)?\/\//i.test(e)||/^data:.*,.*$/i.test(e)||/^blob:.*$/i.test(e)?e:t+e)}}class ug extends It{constructor(){super(),this.isInstancedBufferGeometry=!0,this.type="InstancedBufferGeometry",this.instanceCount=1/0}copy(e){return super.copy(e),this.instanceCount=e.instanceCount,this}toJSON(){const e=super.toJSON();return e.instanceCount=this.instanceCount,e.isInstancedBufferGeometry=!0,e}}const nl=new WeakMap;class dg extends Js{constructor(e){super(e),this.isImageBitmapLoader=!0,typeof createImageBitmap>"u"&&console.warn("THREE.ImageBitmapLoader: createImageBitmap() not supported."),typeof fetch>"u"&&console.warn("THREE.ImageBitmapLoader: fetch() not supported."),this.options={premultiplyAlpha:"none"},this._abortController=new AbortController}setOptions(e){return this.options=e,this}load(e,t,n,s){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);const r=this,a=li.get(`image-bitmap:${e}`);if(a!==void 0){if(r.manager.itemStart(e),a.then){a.then(l=>{if(nl.has(a)===!0)s&&s(nl.get(a)),r.manager.itemError(e),r.manager.itemEnd(e);else return t&&t(l),r.manager.itemEnd(e),l});return}return setTimeout(function(){t&&t(a),r.manager.itemEnd(e)},0),a}const o={};o.credentials=this.crossOrigin==="anonymous"?"same-origin":"include",o.headers=this.requestHeader,o.signal=typeof AbortSignal.any=="function"?AbortSignal.any([this._abortController.signal,this.manager.abortController.signal]):this._abortController.signal;const c=fetch(e,o).then(function(l){return l.blob()}).then(function(l){return createImageBitmap(l,Object.assign(r.options,{colorSpaceConversion:"none"}))}).then(function(l){return li.add(`image-bitmap:${e}`,l),t&&t(l),r.manager.itemEnd(e),l}).catch(function(l){s&&s(l),nl.set(c,l),li.remove(`image-bitmap:${e}`),r.manager.itemError(e),r.manager.itemEnd(e)});li.add(`image-bitmap:${e}`,c),r.manager.itemStart(e)}abort(){return this._abortController.abort(),this._abortController=new AbortController,this}}class hg extends Kt{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e}}class fg{constructor(e=!0){this.autoStart=e,this.startTime=0,this.oldTime=0,this.elapsedTime=0,this.running=!1}start(){this.startTime=performance.now(),this.oldTime=this.startTime,this.elapsedTime=0,this.running=!0}stop(){this.getElapsedTime(),this.running=!1,this.autoStart=!1}getElapsedTime(){return this.getDelta(),this.elapsedTime}getDelta(){let e=0;if(this.autoStart&&!this.running)return this.start(),0;if(this.running){const t=performance.now();e=(t-this.oldTime)/1e3,this.oldTime=t,this.elapsedTime+=e}return e}}const jc="\\[\\]\\.:\\/",pg=new RegExp("["+jc+"]","g"),$c="[^"+jc+"]",mg="[^"+jc.replace("\\.","")+"]",gg=/((?:WC+[\/:])*)/.source.replace("WC",$c),vg=/(WCOD+)?/.source.replace("WCOD",mg),_g=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",$c),xg=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",$c),yg=new RegExp("^"+gg+vg+_g+xg+"$"),Sg=["material","materials","bones","map"];class bg{constructor(e,t,n){const s=n||lt.parseTrackName(t);this._targetGroup=e,this._bindings=e.subscribe_(t,s)}getValue(e,t){this.bind();const n=this._targetGroup.nCachedObjects_,s=this._bindings[n];s!==void 0&&s.getValue(e,t)}setValue(e,t){const n=this._bindings;for(let s=this._targetGroup.nCachedObjects_,r=n.length;s!==r;++s)n[s].setValue(e,t)}bind(){const e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].bind()}unbind(){const e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].unbind()}}class lt{constructor(e,t,n){this.path=t,this.parsedPath=n||lt.parseTrackName(t),this.node=lt.findNode(e,this.parsedPath.nodeName),this.rootNode=e,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(e,t,n){return e&&e.isAnimationObjectGroup?new lt.Composite(e,t,n):new lt(e,t,n)}static sanitizeNodeName(e){return e.replace(/\s/g,"_").replace(pg,"")}static parseTrackName(e){const t=yg.exec(e);if(t===null)throw new Error("PropertyBinding: Cannot parse trackName: "+e);const n={nodeName:t[2],objectName:t[3],objectIndex:t[4],propertyName:t[5],propertyIndex:t[6]},s=n.nodeName&&n.nodeName.lastIndexOf(".");if(s!==void 0&&s!==-1){const r=n.nodeName.substring(s+1);Sg.indexOf(r)!==-1&&(n.nodeName=n.nodeName.substring(0,s),n.objectName=r)}if(n.propertyName===null||n.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+e);return n}static findNode(e,t){if(t===void 0||t===""||t==="."||t===-1||t===e.name||t===e.uuid)return e;if(e.skeleton){const n=e.skeleton.getBoneByName(t);if(n!==void 0)return n}if(e.children){const n=function(r){for(let a=0;a<r.length;a++){const o=r[a];if(o.name===t||o.uuid===t)return o;const c=n(o.children);if(c)return c}return null},s=n(e.children);if(s)return s}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(e,t){e[t]=this.targetObject[this.propertyName]}_getValue_array(e,t){const n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)e[t++]=n[s]}_getValue_arrayElement(e,t){e[t]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(e,t){this.resolvedProperty.toArray(e,t)}_setValue_direct(e,t){this.targetObject[this.propertyName]=e[t]}_setValue_direct_setNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(e,t){const n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=e[t++]}_setValue_array_setNeedsUpdate(e,t){const n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=e[t++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(e,t){const n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=e[t++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(e,t){this.resolvedProperty[this.propertyIndex]=e[t]}_setValue_arrayElement_setNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(e,t){this.resolvedProperty.fromArray(e,t)}_setValue_fromArray_setNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(e,t){this.bind(),this.getValue(e,t)}_setValue_unbound(e,t){this.bind(),this.setValue(e,t)}bind(){let e=this.node;const t=this.parsedPath,n=t.objectName,s=t.propertyName;let r=t.propertyIndex;if(e||(e=lt.findNode(this.rootNode,t.nodeName),this.node=e),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!e){console.warn("THREE.PropertyBinding: No target node found for track: "+this.path+".");return}if(n){let l=t.objectIndex;switch(n){case"materials":if(!e.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!e.material.materials){console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}e=e.material.materials;break;case"bones":if(!e.skeleton){console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}e=e.skeleton.bones;for(let u=0;u<e.length;u++)if(e[u].name===l){l=u;break}break;case"map":if("map"in e){e=e.map;break}if(!e.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!e.material.map){console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}e=e.material.map;break;default:if(e[n]===void 0){console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);return}e=e[n]}if(l!==void 0){if(e[l]===void 0){console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,e);return}e=e[l]}}const a=e[s];if(a===void 0){const l=t.nodeName;console.error("THREE.PropertyBinding: Trying to update property for track: "+l+"."+s+" but it wasn't found.",e);return}let o=this.Versioning.None;this.targetObject=e,e.isMaterial===!0?o=this.Versioning.NeedsUpdate:e.isObject3D===!0&&(o=this.Versioning.MatrixWorldNeedsUpdate);let c=this.BindingType.Direct;if(r!==void 0){if(s==="morphTargetInfluences"){if(!e.geometry){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!e.geometry.morphAttributes){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}e.morphTargetDictionary[r]!==void 0&&(r=e.morphTargetDictionary[r])}c=this.BindingType.ArrayElement,this.resolvedProperty=a,this.propertyIndex=r}else a.fromArray!==void 0&&a.toArray!==void 0?(c=this.BindingType.HasFromToArray,this.resolvedProperty=a):Array.isArray(a)?(c=this.BindingType.EntireArray,this.resolvedProperty=a):this.propertyName=s;this.getValue=this.GetterByBindingType[c],this.setValue=this.SetterByBindingTypeAndVersioning[c][o]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}}lt.Composite=bg;lt.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};lt.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};lt.prototype.GetterByBindingType=[lt.prototype._getValue_direct,lt.prototype._getValue_array,lt.prototype._getValue_arrayElement,lt.prototype._getValue_toArray];lt.prototype.SetterByBindingTypeAndVersioning=[[lt.prototype._setValue_direct,lt.prototype._setValue_direct_setNeedsUpdate,lt.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[lt.prototype._setValue_array,lt.prototype._setValue_array_setNeedsUpdate,lt.prototype._setValue_array_setMatrixWorldNeedsUpdate],[lt.prototype._setValue_arrayElement,lt.prototype._setValue_arrayElement_setNeedsUpdate,lt.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[lt.prototype._setValue_fromArray,lt.prototype._setValue_fromArray_setNeedsUpdate,lt.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];const od=new Ye;class Mg{constructor(e,t,n=0,s=1/0){this.ray=new Fr(e,t),this.near=n,this.far=s,this.camera=null,this.layers=new Bc,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,(t.near+t.far)/(t.near-t.far)).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):console.error("THREE.Raycaster: Unsupported camera type: "+t.type)}setFromXRController(e){return od.identity().extractRotation(e.matrixWorld),this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(od),this}intersectObject(e,t=!0,n=[]){return dc(e,this,n,t),n.sort(ld),n}intersectObjects(e,t=!0,n=[]){for(let s=0,r=e.length;s<r;s++)dc(e[s],this,n,t);return n.sort(ld),n}}function ld(i,e){return i.distance-e.distance}function dc(i,e,t,n){let s=!0;if(i.layers.test(e.layers)&&i.raycast(e,t)===!1&&(s=!1),s===!0&&n===!0){const r=i.children;for(let a=0,o=r.length;a<o;a++)dc(r[a],e,t,!0)}}function cd(i,e,t,n){const s=Eg(n);switch(t){case Vh:return i*e;case Pc:return i*e/s.components*s.byteLength;case Lc:return i*e/s.components*s.byteLength;case Gh:return i*e*2/s.components*s.byteLength;case Dc:return i*e*2/s.components*s.byteLength;case Hh:return i*e*3/s.components*s.byteLength;case An:return i*e*4/s.components*s.byteLength;case Nc:return i*e*4/s.components*s.byteLength;case Oa:case Ua:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case Fa:case Ba:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case Ol:case Fl:return Math.max(i,16)*Math.max(e,8)/4;case Nl:case Ul:return Math.max(i,8)*Math.max(e,8)/2;case Bl:case kl:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case zl:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case Vl:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case Hl:return Math.floor((i+4)/5)*Math.floor((e+3)/4)*16;case Gl:return Math.floor((i+4)/5)*Math.floor((e+4)/5)*16;case Wl:return Math.floor((i+5)/6)*Math.floor((e+4)/5)*16;case Xl:return Math.floor((i+5)/6)*Math.floor((e+5)/6)*16;case ql:return Math.floor((i+7)/8)*Math.floor((e+4)/5)*16;case Yl:return Math.floor((i+7)/8)*Math.floor((e+5)/6)*16;case jl:return Math.floor((i+7)/8)*Math.floor((e+7)/8)*16;case $l:return Math.floor((i+9)/10)*Math.floor((e+4)/5)*16;case Kl:return Math.floor((i+9)/10)*Math.floor((e+5)/6)*16;case Zl:return Math.floor((i+9)/10)*Math.floor((e+7)/8)*16;case Jl:return Math.floor((i+9)/10)*Math.floor((e+9)/10)*16;case Ql:return Math.floor((i+11)/12)*Math.floor((e+9)/10)*16;case ec:return Math.floor((i+11)/12)*Math.floor((e+11)/12)*16;case tc:case nc:case ic:return Math.ceil(i/4)*Math.ceil(e/4)*16;case sc:case rc:return Math.ceil(i/4)*Math.ceil(e/4)*8;case ac:case oc:return Math.ceil(i/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${t} format.`)}function Eg(i){switch(i){case qn:case Fh:return{byteLength:1,components:1};case Ar:case Bh:case di:return{byteLength:2,components:1};case Cc:case Ic:return{byteLength:2,components:4};case Ki:case Rc:case Fn:return{byteLength:4,components:1};case kh:case zh:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${i}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Ac}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Ac);/**
 * @license
 * Copyright 2010-2025 Three.js Authors
 * SPDX-License-Identifier: MIT
 */function ff(){let i=null,e=!1,t=null,n=null;function s(r,a){t(r,a),n=i.requestAnimationFrame(s)}return{start:function(){e!==!0&&t!==null&&(n=i.requestAnimationFrame(s),e=!0)},stop:function(){i.cancelAnimationFrame(n),e=!1},setAnimationLoop:function(r){t=r},setContext:function(r){i=r}}}function Tg(i){const e=new WeakMap;function t(o,c){const l=o.array,u=o.usage,d=l.byteLength,h=i.createBuffer();i.bindBuffer(c,h),i.bufferData(c,l,u),o.onUploadCallback();let p;if(l instanceof Float32Array)p=i.FLOAT;else if(typeof Float16Array<"u"&&l instanceof Float16Array)p=i.HALF_FLOAT;else if(l instanceof Uint16Array)o.isFloat16BufferAttribute?p=i.HALF_FLOAT:p=i.UNSIGNED_SHORT;else if(l instanceof Int16Array)p=i.SHORT;else if(l instanceof Uint32Array)p=i.UNSIGNED_INT;else if(l instanceof Int32Array)p=i.INT;else if(l instanceof Int8Array)p=i.BYTE;else if(l instanceof Uint8Array)p=i.UNSIGNED_BYTE;else if(l instanceof Uint8ClampedArray)p=i.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+l);return{buffer:h,type:p,bytesPerElement:l.BYTES_PER_ELEMENT,version:o.version,size:d}}function n(o,c,l){const u=c.array,d=c.updateRanges;if(i.bindBuffer(l,o),d.length===0)i.bufferSubData(l,0,u);else{d.sort((p,g)=>p.start-g.start);let h=0;for(let p=1;p<d.length;p++){const g=d[h],v=d[p];v.start<=g.start+g.count+1?g.count=Math.max(g.count,v.start+v.count-g.start):(++h,d[h]=v)}d.length=h+1;for(let p=0,g=d.length;p<g;p++){const v=d[p];i.bufferSubData(l,v.start*u.BYTES_PER_ELEMENT,u,v.start,v.count)}c.clearUpdateRanges()}c.onUploadCallback()}function s(o){return o.isInterleavedBufferAttribute&&(o=o.data),e.get(o)}function r(o){o.isInterleavedBufferAttribute&&(o=o.data);const c=e.get(o);c&&(i.deleteBuffer(c.buffer),e.delete(o))}function a(o,c){if(o.isInterleavedBufferAttribute&&(o=o.data),o.isGLBufferAttribute){const u=e.get(o);(!u||u.version<o.version)&&e.set(o,{buffer:o.buffer,type:o.type,bytesPerElement:o.elementSize,version:o.version});return}const l=e.get(o);if(l===void 0)e.set(o,t(o,c));else if(l.version<o.version){if(l.size!==o.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(l.buffer,o,c),l.version=o.version}}return{get:s,remove:r,update:a}}var Ag=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,wg=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,Rg=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,Cg=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Ig=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,Pg=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,Lg=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,Dg=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,Ng=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,Og=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,Ug=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Fg=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Bg=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,kg=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,zg=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Vg=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,Hg=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Gg=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Wg=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Xg=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,qg=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,Yg=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,jg=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,$g=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Kg=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,Zg=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,Jg=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Qg=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,e0=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,t0=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,n0="gl_FragColor = linearToOutputTexel( gl_FragColor );",i0=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,s0=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,r0=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,a0=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,o0=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,l0=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,c0=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,u0=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,d0=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,h0=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,f0=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,p0=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,m0=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,g0=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,v0=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,_0=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,x0=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,y0=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,S0=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,b0=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,M0=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,E0=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,T0=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,A0=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,w0=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,R0=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,C0=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,I0=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,P0=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,L0=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,D0=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,N0=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,O0=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,U0=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,F0=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,B0=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,k0=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,z0=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,V0=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,H0=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,G0=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,W0=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,X0=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,q0=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Y0=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,j0=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,$0=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,K0=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,Z0=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,J0=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,Q0=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,ev=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,tv=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,nv=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,iv=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,sv=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,rv=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,av=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,ov=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		float depth = unpackRGBAToDepth( texture2D( depths, uv ) );
		#ifdef USE_REVERSED_DEPTH_BUFFER
			return step( depth, compare );
		#else
			return step( compare, depth );
		#endif
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow( sampler2D shadow, vec2 uv, float compare ) {
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		#ifdef USE_REVERSED_DEPTH_BUFFER
			float hard_shadow = step( distribution.x, compare );
		#else
			float hard_shadow = step( compare, distribution.x );
		#endif
		if ( hard_shadow != 1.0 ) {
			float distance = compare - distribution.x;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,lv=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,cv=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,uv=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,dv=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,hv=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,fv=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,pv=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,mv=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,gv=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,vv=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,_v=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,xv=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,yv=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,Sv=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,bv=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Mv=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,Ev=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const Tv=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,Av=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,wv=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Rv=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Cv=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Iv=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Pv=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,Lv=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,Dv=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Nv=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,Ov=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,Uv=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Fv=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Bv=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,kv=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,zv=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Vv=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Hv=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Gv=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Wv=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Xv=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,qv=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Yv=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,jv=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,$v=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Kv=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Zv=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Jv=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Qv=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,e_=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,t_=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,n_=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,i_=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,s_=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Ze={alphahash_fragment:Ag,alphahash_pars_fragment:wg,alphamap_fragment:Rg,alphamap_pars_fragment:Cg,alphatest_fragment:Ig,alphatest_pars_fragment:Pg,aomap_fragment:Lg,aomap_pars_fragment:Dg,batching_pars_vertex:Ng,batching_vertex:Og,begin_vertex:Ug,beginnormal_vertex:Fg,bsdfs:Bg,iridescence_fragment:kg,bumpmap_pars_fragment:zg,clipping_planes_fragment:Vg,clipping_planes_pars_fragment:Hg,clipping_planes_pars_vertex:Gg,clipping_planes_vertex:Wg,color_fragment:Xg,color_pars_fragment:qg,color_pars_vertex:Yg,color_vertex:jg,common:$g,cube_uv_reflection_fragment:Kg,defaultnormal_vertex:Zg,displacementmap_pars_vertex:Jg,displacementmap_vertex:Qg,emissivemap_fragment:e0,emissivemap_pars_fragment:t0,colorspace_fragment:n0,colorspace_pars_fragment:i0,envmap_fragment:s0,envmap_common_pars_fragment:r0,envmap_pars_fragment:a0,envmap_pars_vertex:o0,envmap_physical_pars_fragment:_0,envmap_vertex:l0,fog_vertex:c0,fog_pars_vertex:u0,fog_fragment:d0,fog_pars_fragment:h0,gradientmap_pars_fragment:f0,lightmap_pars_fragment:p0,lights_lambert_fragment:m0,lights_lambert_pars_fragment:g0,lights_pars_begin:v0,lights_toon_fragment:x0,lights_toon_pars_fragment:y0,lights_phong_fragment:S0,lights_phong_pars_fragment:b0,lights_physical_fragment:M0,lights_physical_pars_fragment:E0,lights_fragment_begin:T0,lights_fragment_maps:A0,lights_fragment_end:w0,logdepthbuf_fragment:R0,logdepthbuf_pars_fragment:C0,logdepthbuf_pars_vertex:I0,logdepthbuf_vertex:P0,map_fragment:L0,map_pars_fragment:D0,map_particle_fragment:N0,map_particle_pars_fragment:O0,metalnessmap_fragment:U0,metalnessmap_pars_fragment:F0,morphinstance_vertex:B0,morphcolor_vertex:k0,morphnormal_vertex:z0,morphtarget_pars_vertex:V0,morphtarget_vertex:H0,normal_fragment_begin:G0,normal_fragment_maps:W0,normal_pars_fragment:X0,normal_pars_vertex:q0,normal_vertex:Y0,normalmap_pars_fragment:j0,clearcoat_normal_fragment_begin:$0,clearcoat_normal_fragment_maps:K0,clearcoat_pars_fragment:Z0,iridescence_pars_fragment:J0,opaque_fragment:Q0,packing:ev,premultiplied_alpha_fragment:tv,project_vertex:nv,dithering_fragment:iv,dithering_pars_fragment:sv,roughnessmap_fragment:rv,roughnessmap_pars_fragment:av,shadowmap_pars_fragment:ov,shadowmap_pars_vertex:lv,shadowmap_vertex:cv,shadowmask_pars_fragment:uv,skinbase_vertex:dv,skinning_pars_vertex:hv,skinning_vertex:fv,skinnormal_vertex:pv,specularmap_fragment:mv,specularmap_pars_fragment:gv,tonemapping_fragment:vv,tonemapping_pars_fragment:_v,transmission_fragment:xv,transmission_pars_fragment:yv,uv_pars_fragment:Sv,uv_pars_vertex:bv,uv_vertex:Mv,worldpos_vertex:Ev,background_vert:Tv,background_frag:Av,backgroundCube_vert:wv,backgroundCube_frag:Rv,cube_vert:Cv,cube_frag:Iv,depth_vert:Pv,depth_frag:Lv,distanceRGBA_vert:Dv,distanceRGBA_frag:Nv,equirect_vert:Ov,equirect_frag:Uv,linedashed_vert:Fv,linedashed_frag:Bv,meshbasic_vert:kv,meshbasic_frag:zv,meshlambert_vert:Vv,meshlambert_frag:Hv,meshmatcap_vert:Gv,meshmatcap_frag:Wv,meshnormal_vert:Xv,meshnormal_frag:qv,meshphong_vert:Yv,meshphong_frag:jv,meshphysical_vert:$v,meshphysical_frag:Kv,meshtoon_vert:Zv,meshtoon_frag:Jv,points_vert:Qv,points_frag:e_,shadow_vert:t_,shadow_frag:n_,sprite_vert:i_,sprite_frag:s_},Se={common:{diffuse:{value:new Re(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new $e},alphaMap:{value:null},alphaMapTransform:{value:new $e},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new $e}},envmap:{envMap:{value:null},envMapRotation:{value:new $e},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new $e}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new $e}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new $e},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new $e},normalScale:{value:new Ie(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new $e},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new $e}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new $e}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new $e}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Re(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new Re(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new $e},alphaTest:{value:0},uvTransform:{value:new $e}},sprite:{diffuse:{value:new Re(16777215)},opacity:{value:1},center:{value:new Ie(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new $e},alphaMap:{value:null},alphaMapTransform:{value:new $e},alphaTest:{value:0}}},Gn={basic:{uniforms:$t([Se.common,Se.specularmap,Se.envmap,Se.aomap,Se.lightmap,Se.fog]),vertexShader:Ze.meshbasic_vert,fragmentShader:Ze.meshbasic_frag},lambert:{uniforms:$t([Se.common,Se.specularmap,Se.envmap,Se.aomap,Se.lightmap,Se.emissivemap,Se.bumpmap,Se.normalmap,Se.displacementmap,Se.fog,Se.lights,{emissive:{value:new Re(0)}}]),vertexShader:Ze.meshlambert_vert,fragmentShader:Ze.meshlambert_frag},phong:{uniforms:$t([Se.common,Se.specularmap,Se.envmap,Se.aomap,Se.lightmap,Se.emissivemap,Se.bumpmap,Se.normalmap,Se.displacementmap,Se.fog,Se.lights,{emissive:{value:new Re(0)},specular:{value:new Re(1118481)},shininess:{value:30}}]),vertexShader:Ze.meshphong_vert,fragmentShader:Ze.meshphong_frag},standard:{uniforms:$t([Se.common,Se.envmap,Se.aomap,Se.lightmap,Se.emissivemap,Se.bumpmap,Se.normalmap,Se.displacementmap,Se.roughnessmap,Se.metalnessmap,Se.fog,Se.lights,{emissive:{value:new Re(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Ze.meshphysical_vert,fragmentShader:Ze.meshphysical_frag},toon:{uniforms:$t([Se.common,Se.aomap,Se.lightmap,Se.emissivemap,Se.bumpmap,Se.normalmap,Se.displacementmap,Se.gradientmap,Se.fog,Se.lights,{emissive:{value:new Re(0)}}]),vertexShader:Ze.meshtoon_vert,fragmentShader:Ze.meshtoon_frag},matcap:{uniforms:$t([Se.common,Se.bumpmap,Se.normalmap,Se.displacementmap,Se.fog,{matcap:{value:null}}]),vertexShader:Ze.meshmatcap_vert,fragmentShader:Ze.meshmatcap_frag},points:{uniforms:$t([Se.points,Se.fog]),vertexShader:Ze.points_vert,fragmentShader:Ze.points_frag},dashed:{uniforms:$t([Se.common,Se.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Ze.linedashed_vert,fragmentShader:Ze.linedashed_frag},depth:{uniforms:$t([Se.common,Se.displacementmap]),vertexShader:Ze.depth_vert,fragmentShader:Ze.depth_frag},normal:{uniforms:$t([Se.common,Se.bumpmap,Se.normalmap,Se.displacementmap,{opacity:{value:1}}]),vertexShader:Ze.meshnormal_vert,fragmentShader:Ze.meshnormal_frag},sprite:{uniforms:$t([Se.sprite,Se.fog]),vertexShader:Ze.sprite_vert,fragmentShader:Ze.sprite_frag},background:{uniforms:{uvTransform:{value:new $e},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Ze.background_vert,fragmentShader:Ze.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new $e}},vertexShader:Ze.backgroundCube_vert,fragmentShader:Ze.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Ze.cube_vert,fragmentShader:Ze.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Ze.equirect_vert,fragmentShader:Ze.equirect_frag},distanceRGBA:{uniforms:$t([Se.common,Se.displacementmap,{referencePosition:{value:new N},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Ze.distanceRGBA_vert,fragmentShader:Ze.distanceRGBA_frag},shadow:{uniforms:$t([Se.lights,Se.fog,{color:{value:new Re(0)},opacity:{value:1}}]),vertexShader:Ze.shadow_vert,fragmentShader:Ze.shadow_frag}};Gn.physical={uniforms:$t([Gn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new $e},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new $e},clearcoatNormalScale:{value:new Ie(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new $e},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new $e},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new $e},sheen:{value:0},sheenColor:{value:new Re(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new $e},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new $e},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new $e},transmissionSamplerSize:{value:new Ie},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new $e},attenuationDistance:{value:0},attenuationColor:{value:new Re(0)},specularColor:{value:new Re(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new $e},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new $e},anisotropyVector:{value:new Ie},anisotropyMap:{value:null},anisotropyMapTransform:{value:new $e}}]),vertexShader:Ze.meshphysical_vert,fragmentShader:Ze.meshphysical_frag};const Ta={r:0,b:0,g:0},Vi=new vn,r_=new Ye;function a_(i,e,t,n,s,r,a){const o=new Re(0);let c=r===!0?0:1,l,u,d=null,h=0,p=null;function g(x){let y=x.isScene===!0?x.background:null;return y&&y.isTexture&&(y=(x.backgroundBlurriness>0?t:e).get(y)),y}function v(x){let y=!1;const A=g(x);A===null?f(o,c):A&&A.isColor&&(f(A,1),y=!0);const E=i.xr.getEnvironmentBlendMode();E==="additive"?n.buffers.color.setClear(0,0,0,1,a):E==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,a),(i.autoClear||y)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil))}function m(x,y){const A=g(y);A&&(A.isCubeTexture||A.mapping===ro)?(u===void 0&&(u=new pt(new Br(1,1,1),new Rt({name:"BackgroundCubeMaterial",uniforms:zs(Gn.backgroundCube.uniforms),vertexShader:Gn.backgroundCube.vertexShader,fragmentShader:Gn.backgroundCube.fragmentShader,side:an,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),u.geometry.deleteAttribute("normal"),u.geometry.deleteAttribute("uv"),u.onBeforeRender=function(E,M,C){this.matrixWorld.copyPosition(C.matrixWorld)},Object.defineProperty(u.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),s.update(u)),Vi.copy(y.backgroundRotation),Vi.x*=-1,Vi.y*=-1,Vi.z*=-1,A.isCubeTexture&&A.isRenderTargetTexture===!1&&(Vi.y*=-1,Vi.z*=-1),u.material.uniforms.envMap.value=A,u.material.uniforms.flipEnvMap.value=A.isCubeTexture&&A.isRenderTargetTexture===!1?-1:1,u.material.uniforms.backgroundBlurriness.value=y.backgroundBlurriness,u.material.uniforms.backgroundIntensity.value=y.backgroundIntensity,u.material.uniforms.backgroundRotation.value.setFromMatrix4(r_.makeRotationFromEuler(Vi)),u.material.toneMapped=tt.getTransfer(A.colorSpace)!==ft,(d!==A||h!==A.version||p!==i.toneMapping)&&(u.material.needsUpdate=!0,d=A,h=A.version,p=i.toneMapping),u.layers.enableAll(),x.unshift(u,u.geometry,u.material,0,0,null)):A&&A.isTexture&&(l===void 0&&(l=new pt(new _n(2,2),new Rt({name:"BackgroundMaterial",uniforms:zs(Gn.background.uniforms),vertexShader:Gn.background.vertexShader,fragmentShader:Gn.background.fragmentShader,side:fi,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),s.update(l)),l.material.uniforms.t2D.value=A,l.material.uniforms.backgroundIntensity.value=y.backgroundIntensity,l.material.toneMapped=tt.getTransfer(A.colorSpace)!==ft,A.matrixAutoUpdate===!0&&A.updateMatrix(),l.material.uniforms.uvTransform.value.copy(A.matrix),(d!==A||h!==A.version||p!==i.toneMapping)&&(l.material.needsUpdate=!0,d=A,h=A.version,p=i.toneMapping),l.layers.enableAll(),x.unshift(l,l.geometry,l.material,0,0,null))}function f(x,y){x.getRGB(Ta,Zh(i)),n.buffers.color.setClear(Ta.r,Ta.g,Ta.b,y,a)}function _(){u!==void 0&&(u.geometry.dispose(),u.material.dispose(),u=void 0),l!==void 0&&(l.geometry.dispose(),l.material.dispose(),l=void 0)}return{getClearColor:function(){return o},setClearColor:function(x,y=1){o.set(x),c=y,f(o,c)},getClearAlpha:function(){return c},setClearAlpha:function(x){c=x,f(o,c)},render:v,addToRenderList:m,dispose:_}}function o_(i,e){const t=i.getParameter(i.MAX_VERTEX_ATTRIBS),n={},s=h(null);let r=s,a=!1;function o(S,I,D,w,U){let O=!1;const F=d(w,D,I);r!==F&&(r=F,l(r.object)),O=p(S,w,D,U),O&&g(S,w,D,U),U!==null&&e.update(U,i.ELEMENT_ARRAY_BUFFER),(O||a)&&(a=!1,y(S,I,D,w),U!==null&&i.bindBuffer(i.ELEMENT_ARRAY_BUFFER,e.get(U).buffer))}function c(){return i.createVertexArray()}function l(S){return i.bindVertexArray(S)}function u(S){return i.deleteVertexArray(S)}function d(S,I,D){const w=D.wireframe===!0;let U=n[S.id];U===void 0&&(U={},n[S.id]=U);let O=U[I.id];O===void 0&&(O={},U[I.id]=O);let F=O[w];return F===void 0&&(F=h(c()),O[w]=F),F}function h(S){const I=[],D=[],w=[];for(let U=0;U<t;U++)I[U]=0,D[U]=0,w[U]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:I,enabledAttributes:D,attributeDivisors:w,object:S,attributes:{},index:null}}function p(S,I,D,w){const U=r.attributes,O=I.attributes;let F=0;const V=D.getAttributes();for(const k in V)if(V[k].location>=0){const B=U[k];let j=O[k];if(j===void 0&&(k==="instanceMatrix"&&S.instanceMatrix&&(j=S.instanceMatrix),k==="instanceColor"&&S.instanceColor&&(j=S.instanceColor)),B===void 0||B.attribute!==j||j&&B.data!==j.data)return!0;F++}return r.attributesNum!==F||r.index!==w}function g(S,I,D,w){const U={},O=I.attributes;let F=0;const V=D.getAttributes();for(const k in V)if(V[k].location>=0){let B=O[k];B===void 0&&(k==="instanceMatrix"&&S.instanceMatrix&&(B=S.instanceMatrix),k==="instanceColor"&&S.instanceColor&&(B=S.instanceColor));const j={};j.attribute=B,B&&B.data&&(j.data=B.data),U[k]=j,F++}r.attributes=U,r.attributesNum=F,r.index=w}function v(){const S=r.newAttributes;for(let I=0,D=S.length;I<D;I++)S[I]=0}function m(S){f(S,0)}function f(S,I){const D=r.newAttributes,w=r.enabledAttributes,U=r.attributeDivisors;D[S]=1,w[S]===0&&(i.enableVertexAttribArray(S),w[S]=1),U[S]!==I&&(i.vertexAttribDivisor(S,I),U[S]=I)}function _(){const S=r.newAttributes,I=r.enabledAttributes;for(let D=0,w=I.length;D<w;D++)I[D]!==S[D]&&(i.disableVertexAttribArray(D),I[D]=0)}function x(S,I,D,w,U,O,F){F===!0?i.vertexAttribIPointer(S,I,D,U,O):i.vertexAttribPointer(S,I,D,w,U,O)}function y(S,I,D,w){v();const U=w.attributes,O=D.getAttributes(),F=I.defaultAttributeValues;for(const V in O){const k=O[V];if(k.location>=0){let z=U[V];if(z===void 0&&(V==="instanceMatrix"&&S.instanceMatrix&&(z=S.instanceMatrix),V==="instanceColor"&&S.instanceColor&&(z=S.instanceColor)),z!==void 0){const B=z.normalized,j=z.itemSize,ne=e.get(z);if(ne===void 0)continue;const Q=ne.buffer,re=ne.type,ce=ne.bytesPerElement,G=re===i.INT||re===i.UNSIGNED_INT||z.gpuType===Rc;if(z.isInterleavedBufferAttribute){const Y=z.data,ie=Y.stride,ye=z.offset;if(Y.isInstancedInterleavedBuffer){for(let se=0;se<k.locationSize;se++)f(k.location+se,Y.meshPerAttribute);S.isInstancedMesh!==!0&&w._maxInstanceCount===void 0&&(w._maxInstanceCount=Y.meshPerAttribute*Y.count)}else for(let se=0;se<k.locationSize;se++)m(k.location+se);i.bindBuffer(i.ARRAY_BUFFER,Q);for(let se=0;se<k.locationSize;se++)x(k.location+se,j/k.locationSize,re,B,ie*ce,(ye+j/k.locationSize*se)*ce,G)}else{if(z.isInstancedBufferAttribute){for(let Y=0;Y<k.locationSize;Y++)f(k.location+Y,z.meshPerAttribute);S.isInstancedMesh!==!0&&w._maxInstanceCount===void 0&&(w._maxInstanceCount=z.meshPerAttribute*z.count)}else for(let Y=0;Y<k.locationSize;Y++)m(k.location+Y);i.bindBuffer(i.ARRAY_BUFFER,Q);for(let Y=0;Y<k.locationSize;Y++)x(k.location+Y,j/k.locationSize,re,B,j*ce,j/k.locationSize*Y*ce,G)}}else if(F!==void 0){const B=F[V];if(B!==void 0)switch(B.length){case 2:i.vertexAttrib2fv(k.location,B);break;case 3:i.vertexAttrib3fv(k.location,B);break;case 4:i.vertexAttrib4fv(k.location,B);break;default:i.vertexAttrib1fv(k.location,B)}}}}_()}function A(){C();for(const S in n){const I=n[S];for(const D in I){const w=I[D];for(const U in w)u(w[U].object),delete w[U];delete I[D]}delete n[S]}}function E(S){if(n[S.id]===void 0)return;const I=n[S.id];for(const D in I){const w=I[D];for(const U in w)u(w[U].object),delete w[U];delete I[D]}delete n[S.id]}function M(S){for(const I in n){const D=n[I];if(D[S.id]===void 0)continue;const w=D[S.id];for(const U in w)u(w[U].object),delete w[U];delete D[S.id]}}function C(){b(),a=!0,r!==s&&(r=s,l(r.object))}function b(){s.geometry=null,s.program=null,s.wireframe=!1}return{setup:o,reset:C,resetDefaultState:b,dispose:A,releaseStatesOfGeometry:E,releaseStatesOfProgram:M,initAttributes:v,enableAttribute:m,disableUnusedAttributes:_}}function l_(i,e,t){let n;function s(l){n=l}function r(l,u){i.drawArrays(n,l,u),t.update(u,n,1)}function a(l,u,d){d!==0&&(i.drawArraysInstanced(n,l,u,d),t.update(u,n,d))}function o(l,u,d){if(d===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,l,0,u,0,d);let p=0;for(let g=0;g<d;g++)p+=u[g];t.update(p,n,1)}function c(l,u,d,h){if(d===0)return;const p=e.get("WEBGL_multi_draw");if(p===null)for(let g=0;g<l.length;g++)a(l[g],u[g],h[g]);else{p.multiDrawArraysInstancedWEBGL(n,l,0,u,0,h,0,d);let g=0;for(let v=0;v<d;v++)g+=u[v]*h[v];t.update(g,n,1)}}this.setMode=s,this.render=r,this.renderInstances=a,this.renderMultiDraw=o,this.renderMultiDrawInstances=c}function c_(i,e,t,n){let s;function r(){if(s!==void 0)return s;if(e.has("EXT_texture_filter_anisotropic")===!0){const M=e.get("EXT_texture_filter_anisotropic");s=i.getParameter(M.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else s=0;return s}function a(M){return!(M!==An&&n.convert(M)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_FORMAT))}function o(M){const C=M===di&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(M!==qn&&n.convert(M)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_TYPE)&&M!==Fn&&!C)}function c(M){if(M==="highp"){if(i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.HIGH_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.HIGH_FLOAT).precision>0)return"highp";M="mediump"}return M==="mediump"&&i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.MEDIUM_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let l=t.precision!==void 0?t.precision:"highp";const u=c(l);u!==l&&(console.warn("THREE.WebGLRenderer:",l,"not supported, using",u,"instead."),l=u);const d=t.logarithmicDepthBuffer===!0,h=t.reversedDepthBuffer===!0&&e.has("EXT_clip_control"),p=i.getParameter(i.MAX_TEXTURE_IMAGE_UNITS),g=i.getParameter(i.MAX_VERTEX_TEXTURE_IMAGE_UNITS),v=i.getParameter(i.MAX_TEXTURE_SIZE),m=i.getParameter(i.MAX_CUBE_MAP_TEXTURE_SIZE),f=i.getParameter(i.MAX_VERTEX_ATTRIBS),_=i.getParameter(i.MAX_VERTEX_UNIFORM_VECTORS),x=i.getParameter(i.MAX_VARYING_VECTORS),y=i.getParameter(i.MAX_FRAGMENT_UNIFORM_VECTORS),A=g>0,E=i.getParameter(i.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:r,getMaxPrecision:c,textureFormatReadable:a,textureTypeReadable:o,precision:l,logarithmicDepthBuffer:d,reversedDepthBuffer:h,maxTextures:p,maxVertexTextures:g,maxTextureSize:v,maxCubemapSize:m,maxAttributes:f,maxVertexUniforms:_,maxVaryings:x,maxFragmentUniforms:y,vertexTextures:A,maxSamples:E}}function u_(i){const e=this;let t=null,n=0,s=!1,r=!1;const a=new Xi,o=new $e,c={value:null,needsUpdate:!1};this.uniform=c,this.numPlanes=0,this.numIntersection=0,this.init=function(d,h){const p=d.length!==0||h||n!==0||s;return s=h,n=d.length,p},this.beginShadows=function(){r=!0,u(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(d,h){t=u(d,h,0)},this.setState=function(d,h,p){const g=d.clippingPlanes,v=d.clipIntersection,m=d.clipShadows,f=i.get(d);if(!s||g===null||g.length===0||r&&!m)r?u(null):l();else{const _=r?0:n,x=_*4;let y=f.clippingState||null;c.value=y,y=u(g,h,x,p);for(let A=0;A!==x;++A)y[A]=t[A];f.clippingState=y,this.numIntersection=v?this.numPlanes:0,this.numPlanes+=_}};function l(){c.value!==t&&(c.value=t,c.needsUpdate=n>0),e.numPlanes=n,e.numIntersection=0}function u(d,h,p,g){const v=d!==null?d.length:0;let m=null;if(v!==0){if(m=c.value,g!==!0||m===null){const f=p+v*4,_=h.matrixWorldInverse;o.getNormalMatrix(_),(m===null||m.length<f)&&(m=new Float32Array(f));for(let x=0,y=p;x!==v;++x,y+=4)a.copy(d[x]).applyMatrix4(_,o),a.normal.toArray(m,y),m[y+3]=a.constant}c.value=m,c.needsUpdate=!0}return e.numPlanes=v,e.numIntersection=0,m}}function d_(i){let e=new WeakMap;function t(a,o){return o===Ll?a.mapping=Us:o===Dl&&(a.mapping=Fs),a}function n(a){if(a&&a.isTexture){const o=a.mapping;if(o===Ll||o===Dl)if(e.has(a)){const c=e.get(a).texture;return t(c,a.mapping)}else{const c=a.image;if(c&&c.height>0){const l=new Lm(c.height);return l.fromEquirectangularTexture(i,a),e.set(a,l),a.addEventListener("dispose",s),t(l.texture,a.mapping)}else return null}}return a}function s(a){const o=a.target;o.removeEventListener("dispose",s);const c=e.get(o);c!==void 0&&(e.delete(o),c.dispose())}function r(){e=new WeakMap}return{get:n,dispose:r}}const ws=4,ud=[.125,.215,.35,.446,.526,.582],$i=20,il=new Hr,dd=new Re;let sl=null,rl=0,al=0,ol=!1;const qi=(1+Math.sqrt(5))/2,Ss=1/qi,hd=[new N(-qi,Ss,0),new N(qi,Ss,0),new N(-Ss,0,qi),new N(Ss,0,qi),new N(0,qi,-Ss),new N(0,qi,Ss),new N(-1,1,-1),new N(1,1,-1),new N(-1,1,1),new N(1,1,1)],h_=new N;class fd{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(e,t=0,n=.1,s=100,r={}){const{size:a=256,position:o=h_}=r;sl=this._renderer.getRenderTarget(),rl=this._renderer.getActiveCubeFace(),al=this._renderer.getActiveMipmapLevel(),ol=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(a);const c=this._allocateTargets();return c.depthBuffer=!0,this._sceneToCubeUV(e,n,s,c,o),t>0&&this._blur(c,0,0,t),this._applyPMREM(c),this._cleanup(c),c}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=gd(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=md(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodPlanes.length;e++)this._lodPlanes[e].dispose()}_cleanup(e){this._renderer.setRenderTarget(sl,rl,al),this._renderer.xr.enabled=ol,e.scissorTest=!1,Aa(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===Us||e.mapping===Fs?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),sl=this._renderer.getRenderTarget(),rl=this._renderer.getActiveCubeFace(),al=this._renderer.getActiveMipmapLevel(),ol=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const n=t||this._allocateTargets();return this._textureToCubeUV(e,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,n={magFilter:Lt,minFilter:Lt,generateMipmaps:!1,type:di,format:An,colorSpace:Qt,depthBuffer:!1},s=pd(e,t,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=pd(e,t,n);const{_lodMax:r}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=f_(r)),this._blurMaterial=p_(r,e,t)}return s}_compileMaterial(e){const t=new pt(this._lodPlanes[0],e);this._renderer.compile(t,il)}_sceneToCubeUV(e,t,n,s,r){const c=new Kt(90,1,t,n),l=[1,-1,1,1,1,1],u=[1,1,1,-1,-1,-1],d=this._renderer,h=d.autoClear,p=d.toneMapping;d.getClearColor(dd),d.toneMapping=Ii,d.autoClear=!1,d.state.buffers.depth.getReversed()&&(d.setRenderTarget(s),d.clearDepth(),d.setRenderTarget(null));const v=new Ut({name:"PMREM.Background",side:an,depthWrite:!1,depthTest:!1}),m=new pt(new Br,v);let f=!1;const _=e.background;_?_.isColor&&(v.color.copy(_),e.background=null,f=!0):(v.color.copy(dd),f=!0);for(let x=0;x<6;x++){const y=x%3;y===0?(c.up.set(0,l[x],0),c.position.set(r.x,r.y,r.z),c.lookAt(r.x+u[x],r.y,r.z)):y===1?(c.up.set(0,0,l[x]),c.position.set(r.x,r.y,r.z),c.lookAt(r.x,r.y+u[x],r.z)):(c.up.set(0,l[x],0),c.position.set(r.x,r.y,r.z),c.lookAt(r.x,r.y,r.z+u[x]));const A=this._cubeSize;Aa(s,y*A,x>2?A:0,A,A),d.setRenderTarget(s),f&&d.render(m,c),d.render(e,c)}m.geometry.dispose(),m.material.dispose(),d.toneMapping=p,d.autoClear=h,e.background=_}_textureToCubeUV(e,t){const n=this._renderer,s=e.mapping===Us||e.mapping===Fs;s?(this._cubemapMaterial===null&&(this._cubemapMaterial=gd()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=md());const r=s?this._cubemapMaterial:this._equirectMaterial,a=new pt(this._lodPlanes[0],r),o=r.uniforms;o.envMap.value=e;const c=this._cubeSize;Aa(t,0,0,3*c,2*c),n.setRenderTarget(t),n.render(a,il)}_applyPMREM(e){const t=this._renderer,n=t.autoClear;t.autoClear=!1;const s=this._lodPlanes.length;for(let r=1;r<s;r++){const a=Math.sqrt(this._sigmas[r]*this._sigmas[r]-this._sigmas[r-1]*this._sigmas[r-1]),o=hd[(s-r-1)%hd.length];this._blur(e,r-1,r,a,o)}t.autoClear=n}_blur(e,t,n,s,r){const a=this._pingPongRenderTarget;this._halfBlur(e,a,t,n,s,"latitudinal",r),this._halfBlur(a,e,n,n,s,"longitudinal",r)}_halfBlur(e,t,n,s,r,a,o){const c=this._renderer,l=this._blurMaterial;a!=="latitudinal"&&a!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");const u=3,d=new pt(this._lodPlanes[s],l),h=l.uniforms,p=this._sizeLods[n]-1,g=isFinite(r)?Math.PI/(2*p):2*Math.PI/(2*$i-1),v=r/g,m=isFinite(r)?1+Math.floor(u*v):$i;m>$i&&console.warn(`sigmaRadians, ${r}, is too large and will clip, as it requested ${m} samples when the maximum is set to ${$i}`);const f=[];let _=0;for(let M=0;M<$i;++M){const C=M/v,b=Math.exp(-C*C/2);f.push(b),M===0?_+=b:M<m&&(_+=2*b)}for(let M=0;M<f.length;M++)f[M]=f[M]/_;h.envMap.value=e.texture,h.samples.value=m,h.weights.value=f,h.latitudinal.value=a==="latitudinal",o&&(h.poleAxis.value=o);const{_lodMax:x}=this;h.dTheta.value=g,h.mipInt.value=x-n;const y=this._sizeLods[s],A=3*y*(s>x-ws?s-x+ws:0),E=4*(this._cubeSize-y);Aa(t,A,E,3*y,2*y),c.setRenderTarget(t),c.render(d,il)}}function f_(i){const e=[],t=[],n=[];let s=i;const r=i-ws+1+ud.length;for(let a=0;a<r;a++){const o=Math.pow(2,s);t.push(o);let c=1/o;a>i-ws?c=ud[a-i+ws-1]:a===0&&(c=0),n.push(c);const l=1/(o-2),u=-l,d=1+l,h=[u,u,d,u,d,d,u,u,d,d,u,d],p=6,g=6,v=3,m=2,f=1,_=new Float32Array(v*g*p),x=new Float32Array(m*g*p),y=new Float32Array(f*g*p);for(let E=0;E<p;E++){const M=E%3*2/3-1,C=E>2?0:-1,b=[M,C,0,M+2/3,C,0,M+2/3,C+1,0,M,C,0,M+2/3,C+1,0,M,C+1,0];_.set(b,v*g*E),x.set(h,m*g*E);const S=[E,E,E,E,E,E];y.set(S,f*g*E)}const A=new It;A.setAttribute("position",new ct(_,v)),A.setAttribute("uv",new ct(x,m)),A.setAttribute("faceIndex",new ct(y,f)),e.push(A),s>ws&&s--}return{lodPlanes:e,sizeLods:t,sigmas:n}}function pd(i,e,t){const n=new kn(i,e,t);return n.texture.mapping=ro,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function Aa(i,e,t,n,s){i.viewport.set(e,t,n,s),i.scissor.set(e,t,n,s)}function p_(i,e,t){const n=new Float32Array($i),s=new N(0,1,0);return new Rt({name:"SphericalGaussianBlur",defines:{n:$i,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${i}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:s}},vertexShader:Kc(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:ui,depthTest:!1,depthWrite:!1})}function md(){return new Rt({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Kc(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:ui,depthTest:!1,depthWrite:!1})}function gd(){return new Rt({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Kc(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:ui,depthTest:!1,depthWrite:!1})}function Kc(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function m_(i){let e=new WeakMap,t=null;function n(o){if(o&&o.isTexture){const c=o.mapping,l=c===Ll||c===Dl,u=c===Us||c===Fs;if(l||u){let d=e.get(o);const h=d!==void 0?d.texture.pmremVersion:0;if(o.isRenderTargetTexture&&o.pmremVersion!==h)return t===null&&(t=new fd(i)),d=l?t.fromEquirectangular(o,d):t.fromCubemap(o,d),d.texture.pmremVersion=o.pmremVersion,e.set(o,d),d.texture;if(d!==void 0)return d.texture;{const p=o.image;return l&&p&&p.height>0||u&&p&&s(p)?(t===null&&(t=new fd(i)),d=l?t.fromEquirectangular(o):t.fromCubemap(o),d.texture.pmremVersion=o.pmremVersion,e.set(o,d),o.addEventListener("dispose",r),d.texture):null}}}return o}function s(o){let c=0;const l=6;for(let u=0;u<l;u++)o[u]!==void 0&&c++;return c===l}function r(o){const c=o.target;c.removeEventListener("dispose",r);const l=e.get(c);l!==void 0&&(e.delete(c),l.dispose())}function a(){e=new WeakMap,t!==null&&(t.dispose(),t=null)}return{get:n,dispose:a}}function g_(i){const e={};function t(n){if(e[n]!==void 0)return e[n];let s;switch(n){case"WEBGL_depth_texture":s=i.getExtension("WEBGL_depth_texture")||i.getExtension("MOZ_WEBGL_depth_texture")||i.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":s=i.getExtension("EXT_texture_filter_anisotropic")||i.getExtension("MOZ_EXT_texture_filter_anisotropic")||i.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":s=i.getExtension("WEBGL_compressed_texture_s3tc")||i.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":s=i.getExtension("WEBGL_compressed_texture_pvrtc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:s=i.getExtension(n)}return e[n]=s,s}return{has:function(n){return t(n)!==null},init:function(){t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance"),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture"),t("WEBGL_render_shared_exponent")},get:function(n){const s=t(n);return s===null&&Dr("THREE.WebGLRenderer: "+n+" extension not supported."),s}}}function v_(i,e,t,n){const s={},r=new WeakMap;function a(d){const h=d.target;h.index!==null&&e.remove(h.index);for(const g in h.attributes)e.remove(h.attributes[g]);h.removeEventListener("dispose",a),delete s[h.id];const p=r.get(h);p&&(e.remove(p),r.delete(h)),n.releaseStatesOfGeometry(h),h.isInstancedBufferGeometry===!0&&delete h._maxInstanceCount,t.memory.geometries--}function o(d,h){return s[h.id]===!0||(h.addEventListener("dispose",a),s[h.id]=!0,t.memory.geometries++),h}function c(d){const h=d.attributes;for(const p in h)e.update(h[p],i.ARRAY_BUFFER)}function l(d){const h=[],p=d.index,g=d.attributes.position;let v=0;if(p!==null){const _=p.array;v=p.version;for(let x=0,y=_.length;x<y;x+=3){const A=_[x+0],E=_[x+1],M=_[x+2];h.push(A,E,E,M,M,A)}}else if(g!==void 0){const _=g.array;v=g.version;for(let x=0,y=_.length/3-1;x<y;x+=3){const A=x+0,E=x+1,M=x+2;h.push(A,E,E,M,M,A)}}else return;const m=new(Yh(h)?Kh:ao)(h,1);m.version=v;const f=r.get(d);f&&e.remove(f),r.set(d,m)}function u(d){const h=r.get(d);if(h){const p=d.index;p!==null&&h.version<p.version&&l(d)}else l(d);return r.get(d)}return{get:o,update:c,getWireframeAttribute:u}}function __(i,e,t){let n;function s(h){n=h}let r,a;function o(h){r=h.type,a=h.bytesPerElement}function c(h,p){i.drawElements(n,p,r,h*a),t.update(p,n,1)}function l(h,p,g){g!==0&&(i.drawElementsInstanced(n,p,r,h*a,g),t.update(p,n,g))}function u(h,p,g){if(g===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,p,0,r,h,0,g);let m=0;for(let f=0;f<g;f++)m+=p[f];t.update(m,n,1)}function d(h,p,g,v){if(g===0)return;const m=e.get("WEBGL_multi_draw");if(m===null)for(let f=0;f<h.length;f++)l(h[f]/a,p[f],v[f]);else{m.multiDrawElementsInstancedWEBGL(n,p,0,r,h,0,v,0,g);let f=0;for(let _=0;_<g;_++)f+=p[_]*v[_];t.update(f,n,1)}}this.setMode=s,this.setIndex=o,this.render=c,this.renderInstances=l,this.renderMultiDraw=u,this.renderMultiDrawInstances=d}function x_(i){const e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function n(r,a,o){switch(t.calls++,a){case i.TRIANGLES:t.triangles+=o*(r/3);break;case i.LINES:t.lines+=o*(r/2);break;case i.LINE_STRIP:t.lines+=o*(r-1);break;case i.LINE_LOOP:t.lines+=o*r;break;case i.POINTS:t.points+=o*r;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",a);break}}function s(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:s,update:n}}function y_(i,e,t){const n=new WeakMap,s=new st;function r(a,o,c){const l=a.morphTargetInfluences,u=o.morphAttributes.position||o.morphAttributes.normal||o.morphAttributes.color,d=u!==void 0?u.length:0;let h=n.get(o);if(h===void 0||h.count!==d){let b=function(){M.dispose(),n.delete(o),o.removeEventListener("dispose",b)};h!==void 0&&h.texture.dispose();const p=o.morphAttributes.position!==void 0,g=o.morphAttributes.normal!==void 0,v=o.morphAttributes.color!==void 0,m=o.morphAttributes.position||[],f=o.morphAttributes.normal||[],_=o.morphAttributes.color||[];let x=0;p===!0&&(x=1),g===!0&&(x=2),v===!0&&(x=3);let y=o.attributes.position.count*x,A=1;y>e.maxTextureSize&&(A=Math.ceil(y/e.maxTextureSize),y=e.maxTextureSize);const E=new Float32Array(y*A*4*d),M=new jh(E,y,A,d);M.type=Fn,M.needsUpdate=!0;const C=x*4;for(let S=0;S<d;S++){const I=m[S],D=f[S],w=_[S],U=y*A*4*S;for(let O=0;O<I.count;O++){const F=O*C;p===!0&&(s.fromBufferAttribute(I,O),E[U+F+0]=s.x,E[U+F+1]=s.y,E[U+F+2]=s.z,E[U+F+3]=0),g===!0&&(s.fromBufferAttribute(D,O),E[U+F+4]=s.x,E[U+F+5]=s.y,E[U+F+6]=s.z,E[U+F+7]=0),v===!0&&(s.fromBufferAttribute(w,O),E[U+F+8]=s.x,E[U+F+9]=s.y,E[U+F+10]=s.z,E[U+F+11]=w.itemSize===4?s.w:1)}}h={count:d,texture:M,size:new Ie(y,A)},n.set(o,h),o.addEventListener("dispose",b)}if(a.isInstancedMesh===!0&&a.morphTexture!==null)c.getUniforms().setValue(i,"morphTexture",a.morphTexture,t);else{let p=0;for(let v=0;v<l.length;v++)p+=l[v];const g=o.morphTargetsRelative?1:1-p;c.getUniforms().setValue(i,"morphTargetBaseInfluence",g),c.getUniforms().setValue(i,"morphTargetInfluences",l)}c.getUniforms().setValue(i,"morphTargetsTexture",h.texture,t),c.getUniforms().setValue(i,"morphTargetsTextureSize",h.size)}return{update:r}}function S_(i,e,t,n){let s=new WeakMap;function r(c){const l=n.render.frame,u=c.geometry,d=e.get(c,u);if(s.get(d)!==l&&(e.update(d),s.set(d,l)),c.isInstancedMesh&&(c.hasEventListener("dispose",o)===!1&&c.addEventListener("dispose",o),s.get(c)!==l&&(t.update(c.instanceMatrix,i.ARRAY_BUFFER),c.instanceColor!==null&&t.update(c.instanceColor,i.ARRAY_BUFFER),s.set(c,l))),c.isSkinnedMesh){const h=c.skeleton;s.get(h)!==l&&(h.update(),s.set(h,l))}return d}function a(){s=new WeakMap}function o(c){const l=c.target;l.removeEventListener("dispose",o),t.remove(l.instanceMatrix),l.instanceColor!==null&&t.remove(l.instanceColor)}return{update:r,dispose:a}}const pf=new Ft,vd=new of(1,1),mf=new jh,gf=new gm,vf=new Qh,_d=[],xd=[],yd=new Float32Array(16),Sd=new Float32Array(9),bd=new Float32Array(4);function er(i,e,t){const n=i[0];if(n<=0||n>0)return i;const s=e*t;let r=_d[s];if(r===void 0&&(r=new Float32Array(s),_d[s]=r),e!==0){n.toArray(r,0);for(let a=1,o=0;a!==e;++a)o+=t,i[a].toArray(r,o)}return r}function Bt(i,e){if(i.length!==e.length)return!1;for(let t=0,n=i.length;t<n;t++)if(i[t]!==e[t])return!1;return!0}function kt(i,e){for(let t=0,n=e.length;t<n;t++)i[t]=e[t]}function fo(i,e){let t=xd[e];t===void 0&&(t=new Int32Array(e),xd[e]=t);for(let n=0;n!==e;++n)t[n]=i.allocateTextureUnit();return t}function b_(i,e){const t=this.cache;t[0]!==e&&(i.uniform1f(this.addr,e),t[0]=e)}function M_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Bt(t,e))return;i.uniform2fv(this.addr,e),kt(t,e)}}function E_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(i.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(Bt(t,e))return;i.uniform3fv(this.addr,e),kt(t,e)}}function T_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Bt(t,e))return;i.uniform4fv(this.addr,e),kt(t,e)}}function A_(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Bt(t,e))return;i.uniformMatrix2fv(this.addr,!1,e),kt(t,e)}else{if(Bt(t,n))return;bd.set(n),i.uniformMatrix2fv(this.addr,!1,bd),kt(t,n)}}function w_(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Bt(t,e))return;i.uniformMatrix3fv(this.addr,!1,e),kt(t,e)}else{if(Bt(t,n))return;Sd.set(n),i.uniformMatrix3fv(this.addr,!1,Sd),kt(t,n)}}function R_(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(Bt(t,e))return;i.uniformMatrix4fv(this.addr,!1,e),kt(t,e)}else{if(Bt(t,n))return;yd.set(n),i.uniformMatrix4fv(this.addr,!1,yd),kt(t,n)}}function C_(i,e){const t=this.cache;t[0]!==e&&(i.uniform1i(this.addr,e),t[0]=e)}function I_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Bt(t,e))return;i.uniform2iv(this.addr,e),kt(t,e)}}function P_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Bt(t,e))return;i.uniform3iv(this.addr,e),kt(t,e)}}function L_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Bt(t,e))return;i.uniform4iv(this.addr,e),kt(t,e)}}function D_(i,e){const t=this.cache;t[0]!==e&&(i.uniform1ui(this.addr,e),t[0]=e)}function N_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Bt(t,e))return;i.uniform2uiv(this.addr,e),kt(t,e)}}function O_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Bt(t,e))return;i.uniform3uiv(this.addr,e),kt(t,e)}}function U_(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Bt(t,e))return;i.uniform4uiv(this.addr,e),kt(t,e)}}function F_(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s);let r;this.type===i.SAMPLER_2D_SHADOW?(vd.compareFunction=Xh,r=vd):r=pf,t.setTexture2D(e||r,s)}function B_(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTexture3D(e||gf,s)}function k_(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTextureCube(e||vf,s)}function z_(i,e,t){const n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTexture2DArray(e||mf,s)}function V_(i){switch(i){case 5126:return b_;case 35664:return M_;case 35665:return E_;case 35666:return T_;case 35674:return A_;case 35675:return w_;case 35676:return R_;case 5124:case 35670:return C_;case 35667:case 35671:return I_;case 35668:case 35672:return P_;case 35669:case 35673:return L_;case 5125:return D_;case 36294:return N_;case 36295:return O_;case 36296:return U_;case 35678:case 36198:case 36298:case 36306:case 35682:return F_;case 35679:case 36299:case 36307:return B_;case 35680:case 36300:case 36308:case 36293:return k_;case 36289:case 36303:case 36311:case 36292:return z_}}function H_(i,e){i.uniform1fv(this.addr,e)}function G_(i,e){const t=er(e,this.size,2);i.uniform2fv(this.addr,t)}function W_(i,e){const t=er(e,this.size,3);i.uniform3fv(this.addr,t)}function X_(i,e){const t=er(e,this.size,4);i.uniform4fv(this.addr,t)}function q_(i,e){const t=er(e,this.size,4);i.uniformMatrix2fv(this.addr,!1,t)}function Y_(i,e){const t=er(e,this.size,9);i.uniformMatrix3fv(this.addr,!1,t)}function j_(i,e){const t=er(e,this.size,16);i.uniformMatrix4fv(this.addr,!1,t)}function $_(i,e){i.uniform1iv(this.addr,e)}function K_(i,e){i.uniform2iv(this.addr,e)}function Z_(i,e){i.uniform3iv(this.addr,e)}function J_(i,e){i.uniform4iv(this.addr,e)}function Q_(i,e){i.uniform1uiv(this.addr,e)}function ex(i,e){i.uniform2uiv(this.addr,e)}function tx(i,e){i.uniform3uiv(this.addr,e)}function nx(i,e){i.uniform4uiv(this.addr,e)}function ix(i,e,t){const n=this.cache,s=e.length,r=fo(t,s);Bt(n,r)||(i.uniform1iv(this.addr,r),kt(n,r));for(let a=0;a!==s;++a)t.setTexture2D(e[a]||pf,r[a])}function sx(i,e,t){const n=this.cache,s=e.length,r=fo(t,s);Bt(n,r)||(i.uniform1iv(this.addr,r),kt(n,r));for(let a=0;a!==s;++a)t.setTexture3D(e[a]||gf,r[a])}function rx(i,e,t){const n=this.cache,s=e.length,r=fo(t,s);Bt(n,r)||(i.uniform1iv(this.addr,r),kt(n,r));for(let a=0;a!==s;++a)t.setTextureCube(e[a]||vf,r[a])}function ax(i,e,t){const n=this.cache,s=e.length,r=fo(t,s);Bt(n,r)||(i.uniform1iv(this.addr,r),kt(n,r));for(let a=0;a!==s;++a)t.setTexture2DArray(e[a]||mf,r[a])}function ox(i){switch(i){case 5126:return H_;case 35664:return G_;case 35665:return W_;case 35666:return X_;case 35674:return q_;case 35675:return Y_;case 35676:return j_;case 5124:case 35670:return $_;case 35667:case 35671:return K_;case 35668:case 35672:return Z_;case 35669:case 35673:return J_;case 5125:return Q_;case 36294:return ex;case 36295:return tx;case 36296:return nx;case 35678:case 36198:case 36298:case 36306:case 35682:return ix;case 35679:case 36299:case 36307:return sx;case 35680:case 36300:case 36308:case 36293:return rx;case 36289:case 36303:case 36311:case 36292:return ax}}class lx{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.setValue=V_(t.type)}}class cx{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=ox(t.type)}}class ux{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,n){const s=this.seq;for(let r=0,a=s.length;r!==a;++r){const o=s[r];o.setValue(e,t[o.id],n)}}}const ll=/(\w+)(\])?(\[|\.)?/g;function Md(i,e){i.seq.push(e),i.map[e.id]=e}function dx(i,e,t){const n=i.name,s=n.length;for(ll.lastIndex=0;;){const r=ll.exec(n),a=ll.lastIndex;let o=r[1];const c=r[2]==="]",l=r[3];if(c&&(o=o|0),l===void 0||l==="["&&a+2===s){Md(t,l===void 0?new lx(o,i,e):new cx(o,i,e));break}else{let d=t.map[o];d===void 0&&(d=new ux(o),Md(t,d)),t=d}}}class ka{constructor(e,t){this.seq=[],this.map={};const n=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let s=0;s<n;++s){const r=e.getActiveUniform(t,s),a=e.getUniformLocation(t,r.name);dx(r,a,this)}}setValue(e,t,n,s){const r=this.map[t];r!==void 0&&r.setValue(e,n,s)}setOptional(e,t,n){const s=t[n];s!==void 0&&this.setValue(e,n,s)}static upload(e,t,n,s){for(let r=0,a=t.length;r!==a;++r){const o=t[r],c=n[o.id];c.needsUpdate!==!1&&o.setValue(e,c.value,s)}}static seqWithValue(e,t){const n=[];for(let s=0,r=e.length;s!==r;++s){const a=e[s];a.id in t&&n.push(a)}return n}}function Ed(i,e,t){const n=i.createShader(e);return i.shaderSource(n,t),i.compileShader(n),n}const hx=37297;let fx=0;function px(i,e){const t=i.split(`
`),n=[],s=Math.max(e-6,0),r=Math.min(e+6,t.length);for(let a=s;a<r;a++){const o=a+1;n.push(`${o===e?">":" "} ${o}: ${t[a]}`)}return n.join(`
`)}const Td=new $e;function mx(i){tt._getMatrix(Td,tt.workingColorSpace,i);const e=`mat3( ${Td.elements.map(t=>t.toFixed(4))} )`;switch(tt.getTransfer(i)){case Wa:return[e,"LinearTransferOETF"];case ft:return[e,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space: ",i),[e,"LinearTransferOETF"]}}function Ad(i,e,t){const n=i.getShaderParameter(e,i.COMPILE_STATUS),r=(i.getShaderInfoLog(e)||"").trim();if(n&&r==="")return"";const a=/ERROR: 0:(\d+)/.exec(r);if(a){const o=parseInt(a[1]);return t.toUpperCase()+`

`+r+`

`+px(i.getShaderSource(e),o)}else return r}function gx(i,e){const t=mx(e);return[`vec4 ${i}( vec4 value ) {`,`	return ${t[1]}( vec4( value.rgb * ${t[0]}, value.a ) );`,"}"].join(`
`)}function vx(i,e){let t;switch(e){case Rp:t="Linear";break;case Cp:t="Reinhard";break;case Ip:t="Cineon";break;case Nh:t="ACESFilmic";break;case Lp:t="AgX";break;case Dp:t="Neutral";break;case Pp:t="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",e),t="Linear"}return"vec3 "+i+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}const wa=new N;function _x(){tt.getLuminanceCoefficients(wa);const i=wa.x.toFixed(4),e=wa.y.toFixed(4),t=wa.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${i}, ${e}, ${t} );`,"	return dot( weights, rgb );","}"].join(`
`)}function xx(i){return[i.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",i.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(yr).join(`
`)}function yx(i){const e=[];for(const t in i){const n=i[t];n!==!1&&e.push("#define "+t+" "+n)}return e.join(`
`)}function Sx(i,e){const t={},n=i.getProgramParameter(e,i.ACTIVE_ATTRIBUTES);for(let s=0;s<n;s++){const r=i.getActiveAttrib(e,s),a=r.name;let o=1;r.type===i.FLOAT_MAT2&&(o=2),r.type===i.FLOAT_MAT3&&(o=3),r.type===i.FLOAT_MAT4&&(o=4),t[a]={type:r.type,location:i.getAttribLocation(e,a),locationSize:o}}return t}function yr(i){return i!==""}function wd(i,e){const t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return i.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function Rd(i,e){return i.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const bx=/^[ \t]*#include +<([\w\d./]+)>/gm;function hc(i){return i.replace(bx,Ex)}const Mx=new Map;function Ex(i,e){let t=Ze[e];if(t===void 0){const n=Mx.get(e);if(n!==void 0)t=Ze[n],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,n);else throw new Error("Can not resolve #include <"+e+">")}return hc(t)}const Tx=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Cd(i){return i.replace(Tx,Ax)}function Ax(i,e,t,n){let s="";for(let r=parseInt(e);r<parseInt(t);r++)s+=n.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return s}function Id(i){let e=`precision ${i.precision} float;
	precision ${i.precision} int;
	precision ${i.precision} sampler2D;
	precision ${i.precision} samplerCube;
	precision ${i.precision} sampler3D;
	precision ${i.precision} sampler2DArray;
	precision ${i.precision} sampler2DShadow;
	precision ${i.precision} samplerCubeShadow;
	precision ${i.precision} sampler2DArrayShadow;
	precision ${i.precision} isampler2D;
	precision ${i.precision} isampler3D;
	precision ${i.precision} isamplerCube;
	precision ${i.precision} isampler2DArray;
	precision ${i.precision} usampler2D;
	precision ${i.precision} usampler3D;
	precision ${i.precision} usamplerCube;
	precision ${i.precision} usampler2DArray;
	`;return i.precision==="highp"?e+=`
#define HIGH_PRECISION`:i.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:i.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}function wx(i){let e="SHADOWMAP_TYPE_BASIC";return i.shadowMapType===Dh?e="SHADOWMAP_TYPE_PCF":i.shadowMapType===op?e="SHADOWMAP_TYPE_PCF_SOFT":i.shadowMapType===ri&&(e="SHADOWMAP_TYPE_VSM"),e}function Rx(i){let e="ENVMAP_TYPE_CUBE";if(i.envMap)switch(i.envMapMode){case Us:case Fs:e="ENVMAP_TYPE_CUBE";break;case ro:e="ENVMAP_TYPE_CUBE_UV";break}return e}function Cx(i){let e="ENVMAP_MODE_REFLECTION";if(i.envMap)switch(i.envMapMode){case Fs:e="ENVMAP_MODE_REFRACTION";break}return e}function Ix(i){let e="ENVMAP_BLENDING_NONE";if(i.envMap)switch(i.combine){case wc:e="ENVMAP_BLENDING_MULTIPLY";break;case Ap:e="ENVMAP_BLENDING_MIX";break;case wp:e="ENVMAP_BLENDING_ADD";break}return e}function Px(i){const e=i.envMapCubeUVHeight;if(e===null)return null;const t=Math.log2(e)-2,n=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,t),112)),texelHeight:n,maxMip:t}}function Lx(i,e,t,n){const s=i.getContext(),r=t.defines;let a=t.vertexShader,o=t.fragmentShader;const c=wx(t),l=Rx(t),u=Cx(t),d=Ix(t),h=Px(t),p=xx(t),g=yx(r),v=s.createProgram();let m,f,_=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(m=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g].filter(yr).join(`
`),m.length>0&&(m+=`
`),f=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g].filter(yr).join(`
`),f.length>0&&(f+=`
`)):(m=[Id(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.batchingColor?"#define USE_BATCHING_COLOR":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.instancingMorph?"#define USE_INSTANCING_MORPH":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+u:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+c:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(yr).join(`
`),f=[Id(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+l:"",t.envMap?"#define "+u:"",t.envMap?"#define "+d:"",h?"#define CUBEUV_TEXEL_WIDTH "+h.texelWidth:"",h?"#define CUBEUV_TEXEL_HEIGHT "+h.texelHeight:"",h?"#define CUBEUV_MAX_MIP "+h.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.dispersion?"#define USE_DISPERSION":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor||t.batchingColor?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+c:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==Ii?"#define TONE_MAPPING":"",t.toneMapping!==Ii?Ze.tonemapping_pars_fragment:"",t.toneMapping!==Ii?vx("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",Ze.colorspace_pars_fragment,gx("linearToOutputTexel",t.outputColorSpace),_x(),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(yr).join(`
`)),a=hc(a),a=wd(a,t),a=Rd(a,t),o=hc(o),o=wd(o,t),o=Rd(o,t),a=Cd(a),o=Cd(o),t.isRawShaderMaterial!==!0&&(_=`#version 300 es
`,m=[p,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+m,f=["#define varying in",t.glslVersion===bu?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===bu?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+f);const x=_+m+a,y=_+f+o,A=Ed(s,s.VERTEX_SHADER,x),E=Ed(s,s.FRAGMENT_SHADER,y);s.attachShader(v,A),s.attachShader(v,E),t.index0AttributeName!==void 0?s.bindAttribLocation(v,0,t.index0AttributeName):t.morphTargets===!0&&s.bindAttribLocation(v,0,"position"),s.linkProgram(v);function M(I){if(i.debug.checkShaderErrors){const D=s.getProgramInfoLog(v)||"",w=s.getShaderInfoLog(A)||"",U=s.getShaderInfoLog(E)||"",O=D.trim(),F=w.trim(),V=U.trim();let k=!0,z=!0;if(s.getProgramParameter(v,s.LINK_STATUS)===!1)if(k=!1,typeof i.debug.onShaderError=="function")i.debug.onShaderError(s,v,A,E);else{const B=Ad(s,A,"vertex"),j=Ad(s,E,"fragment");console.error("THREE.WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(v,s.VALIDATE_STATUS)+`

Material Name: `+I.name+`
Material Type: `+I.type+`

Program Info Log: `+O+`
`+B+`
`+j)}else O!==""?console.warn("THREE.WebGLProgram: Program Info Log:",O):(F===""||V==="")&&(z=!1);z&&(I.diagnostics={runnable:k,programLog:O,vertexShader:{log:F,prefix:m},fragmentShader:{log:V,prefix:f}})}s.deleteShader(A),s.deleteShader(E),C=new ka(s,v),b=Sx(s,v)}let C;this.getUniforms=function(){return C===void 0&&M(this),C};let b;this.getAttributes=function(){return b===void 0&&M(this),b};let S=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return S===!1&&(S=s.getProgramParameter(v,hx)),S},this.destroy=function(){n.releaseStatesOfProgram(this),s.deleteProgram(v),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=fx++,this.cacheKey=e,this.usedTimes=1,this.program=v,this.vertexShader=A,this.fragmentShader=E,this}let Dx=0;class Nx{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){const t=e.vertexShader,n=e.fragmentShader,s=this._getShaderStage(t),r=this._getShaderStage(n),a=this._getShaderCacheForMaterial(e);return a.has(s)===!1&&(a.add(s),s.usedTimes++),a.has(r)===!1&&(a.add(r),r.usedTimes++),this}remove(e){const t=this.materialCache.get(e);for(const n of t)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const t=this.materialCache;let n=t.get(e);return n===void 0&&(n=new Set,t.set(e,n)),n}_getShaderStage(e){const t=this.shaderCache;let n=t.get(e);return n===void 0&&(n=new Ox(e),t.set(e,n)),n}}class Ox{constructor(e){this.id=Dx++,this.code=e,this.usedTimes=0}}function Ux(i,e,t,n,s,r,a){const o=new Bc,c=new Nx,l=new Set,u=[],d=s.logarithmicDepthBuffer,h=s.vertexTextures;let p=s.precision;const g={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function v(b){return l.add(b),b===0?"uv":`uv${b}`}function m(b,S,I,D,w){const U=D.fog,O=w.geometry,F=b.isMeshStandardMaterial?D.environment:null,V=(b.isMeshStandardMaterial?t:e).get(b.envMap||F),k=V&&V.mapping===ro?V.image.height:null,z=g[b.type];b.precision!==null&&(p=s.getMaxPrecision(b.precision),p!==b.precision&&console.warn("THREE.WebGLProgram.getParameters:",b.precision,"not supported, using",p,"instead."));const B=O.morphAttributes.position||O.morphAttributes.normal||O.morphAttributes.color,j=B!==void 0?B.length:0;let ne=0;O.morphAttributes.position!==void 0&&(ne=1),O.morphAttributes.normal!==void 0&&(ne=2),O.morphAttributes.color!==void 0&&(ne=3);let Q,re,ce,G;if(z){const rt=Gn[z];Q=rt.vertexShader,re=rt.fragmentShader}else Q=b.vertexShader,re=b.fragmentShader,c.update(b),ce=c.getVertexShaderID(b),G=c.getFragmentShaderID(b);const Y=i.getRenderTarget(),ie=i.state.buffers.depth.getReversed(),ye=w.isInstancedMesh===!0,se=w.isBatchedMesh===!0,Le=!!b.map,be=!!b.matcap,L=!!V,Ue=!!b.aoMap,me=!!b.lightMap,ae=!!b.bumpMap,le=!!b.normalMap,Ne=!!b.displacementMap,pe=!!b.emissiveMap,Ae=!!b.metalnessMap,He=!!b.roughnessMap,ke=b.anisotropy>0,P=b.clearcoat>0,T=b.dispersion>0,q=b.iridescence>0,J=b.sheen>0,te=b.transmission>0,$=ke&&!!b.anisotropyMap,xe=P&&!!b.clearcoatMap,oe=P&&!!b.clearcoatNormalMap,Oe=P&&!!b.clearcoatRoughnessMap,Fe=q&&!!b.iridescenceMap,he=q&&!!b.iridescenceThicknessMap,Te=J&&!!b.sheenColorMap,We=J&&!!b.sheenRoughnessMap,Be=!!b.specularMap,Me=!!b.specularColorMap,Ke=!!b.specularIntensityMap,H=te&&!!b.transmissionMap,fe=te&&!!b.thicknessMap,ve=!!b.gradientMap,Ce=!!b.alphaMap,ue=b.alphaTest>0,ee=!!b.alphaHash,De=!!b.extensions;let je=Ii;b.toneMapped&&(Y===null||Y.isXRRenderTarget===!0)&&(je=i.toneMapping);const gt={shaderID:z,shaderType:b.type,shaderName:b.name,vertexShader:Q,fragmentShader:re,defines:b.defines,customVertexShaderID:ce,customFragmentShaderID:G,isRawShaderMaterial:b.isRawShaderMaterial===!0,glslVersion:b.glslVersion,precision:p,batching:se,batchingColor:se&&w._colorsTexture!==null,instancing:ye,instancingColor:ye&&w.instanceColor!==null,instancingMorph:ye&&w.morphTexture!==null,supportsVertexTextures:h,outputColorSpace:Y===null?i.outputColorSpace:Y.isXRRenderTarget===!0?Y.texture.colorSpace:Qt,alphaToCoverage:!!b.alphaToCoverage,map:Le,matcap:be,envMap:L,envMapMode:L&&V.mapping,envMapCubeUVHeight:k,aoMap:Ue,lightMap:me,bumpMap:ae,normalMap:le,displacementMap:h&&Ne,emissiveMap:pe,normalMapObjectSpace:le&&b.normalMapType===kp,normalMapTangentSpace:le&&b.normalMapType===Oc,metalnessMap:Ae,roughnessMap:He,anisotropy:ke,anisotropyMap:$,clearcoat:P,clearcoatMap:xe,clearcoatNormalMap:oe,clearcoatRoughnessMap:Oe,dispersion:T,iridescence:q,iridescenceMap:Fe,iridescenceThicknessMap:he,sheen:J,sheenColorMap:Te,sheenRoughnessMap:We,specularMap:Be,specularColorMap:Me,specularIntensityMap:Ke,transmission:te,transmissionMap:H,thicknessMap:fe,gradientMap:ve,opaque:b.transparent===!1&&b.blending===Ci&&b.alphaToCoverage===!1,alphaMap:Ce,alphaTest:ue,alphaHash:ee,combine:b.combine,mapUv:Le&&v(b.map.channel),aoMapUv:Ue&&v(b.aoMap.channel),lightMapUv:me&&v(b.lightMap.channel),bumpMapUv:ae&&v(b.bumpMap.channel),normalMapUv:le&&v(b.normalMap.channel),displacementMapUv:Ne&&v(b.displacementMap.channel),emissiveMapUv:pe&&v(b.emissiveMap.channel),metalnessMapUv:Ae&&v(b.metalnessMap.channel),roughnessMapUv:He&&v(b.roughnessMap.channel),anisotropyMapUv:$&&v(b.anisotropyMap.channel),clearcoatMapUv:xe&&v(b.clearcoatMap.channel),clearcoatNormalMapUv:oe&&v(b.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Oe&&v(b.clearcoatRoughnessMap.channel),iridescenceMapUv:Fe&&v(b.iridescenceMap.channel),iridescenceThicknessMapUv:he&&v(b.iridescenceThicknessMap.channel),sheenColorMapUv:Te&&v(b.sheenColorMap.channel),sheenRoughnessMapUv:We&&v(b.sheenRoughnessMap.channel),specularMapUv:Be&&v(b.specularMap.channel),specularColorMapUv:Me&&v(b.specularColorMap.channel),specularIntensityMapUv:Ke&&v(b.specularIntensityMap.channel),transmissionMapUv:H&&v(b.transmissionMap.channel),thicknessMapUv:fe&&v(b.thicknessMap.channel),alphaMapUv:Ce&&v(b.alphaMap.channel),vertexTangents:!!O.attributes.tangent&&(le||ke),vertexColors:b.vertexColors,vertexAlphas:b.vertexColors===!0&&!!O.attributes.color&&O.attributes.color.itemSize===4,pointsUvs:w.isPoints===!0&&!!O.attributes.uv&&(Le||Ce),fog:!!U,useFog:b.fog===!0,fogExp2:!!U&&U.isFogExp2,flatShading:b.flatShading===!0&&b.wireframe===!1,sizeAttenuation:b.sizeAttenuation===!0,logarithmicDepthBuffer:d,reversedDepthBuffer:ie,skinning:w.isSkinnedMesh===!0,morphTargets:O.morphAttributes.position!==void 0,morphNormals:O.morphAttributes.normal!==void 0,morphColors:O.morphAttributes.color!==void 0,morphTargetsCount:j,morphTextureStride:ne,numDirLights:S.directional.length,numPointLights:S.point.length,numSpotLights:S.spot.length,numSpotLightMaps:S.spotLightMap.length,numRectAreaLights:S.rectArea.length,numHemiLights:S.hemi.length,numDirLightShadows:S.directionalShadowMap.length,numPointLightShadows:S.pointShadowMap.length,numSpotLightShadows:S.spotShadowMap.length,numSpotLightShadowsWithMaps:S.numSpotLightShadowsWithMaps,numLightProbes:S.numLightProbes,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:b.dithering,shadowMapEnabled:i.shadowMap.enabled&&I.length>0,shadowMapType:i.shadowMap.type,toneMapping:je,decodeVideoTexture:Le&&b.map.isVideoTexture===!0&&tt.getTransfer(b.map.colorSpace)===ft,decodeVideoTextureEmissive:pe&&b.emissiveMap.isVideoTexture===!0&&tt.getTransfer(b.emissiveMap.colorSpace)===ft,premultipliedAlpha:b.premultipliedAlpha,doubleSided:b.side===Mt,flipSided:b.side===an,useDepthPacking:b.depthPacking>=0,depthPacking:b.depthPacking||0,index0AttributeName:b.index0AttributeName,extensionClipCullDistance:De&&b.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(De&&b.extensions.multiDraw===!0||se)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:b.customProgramCacheKey()};return gt.vertexUv1s=l.has(1),gt.vertexUv2s=l.has(2),gt.vertexUv3s=l.has(3),l.clear(),gt}function f(b){const S=[];if(b.shaderID?S.push(b.shaderID):(S.push(b.customVertexShaderID),S.push(b.customFragmentShaderID)),b.defines!==void 0)for(const I in b.defines)S.push(I),S.push(b.defines[I]);return b.isRawShaderMaterial===!1&&(_(S,b),x(S,b),S.push(i.outputColorSpace)),S.push(b.customProgramCacheKey),S.join()}function _(b,S){b.push(S.precision),b.push(S.outputColorSpace),b.push(S.envMapMode),b.push(S.envMapCubeUVHeight),b.push(S.mapUv),b.push(S.alphaMapUv),b.push(S.lightMapUv),b.push(S.aoMapUv),b.push(S.bumpMapUv),b.push(S.normalMapUv),b.push(S.displacementMapUv),b.push(S.emissiveMapUv),b.push(S.metalnessMapUv),b.push(S.roughnessMapUv),b.push(S.anisotropyMapUv),b.push(S.clearcoatMapUv),b.push(S.clearcoatNormalMapUv),b.push(S.clearcoatRoughnessMapUv),b.push(S.iridescenceMapUv),b.push(S.iridescenceThicknessMapUv),b.push(S.sheenColorMapUv),b.push(S.sheenRoughnessMapUv),b.push(S.specularMapUv),b.push(S.specularColorMapUv),b.push(S.specularIntensityMapUv),b.push(S.transmissionMapUv),b.push(S.thicknessMapUv),b.push(S.combine),b.push(S.fogExp2),b.push(S.sizeAttenuation),b.push(S.morphTargetsCount),b.push(S.morphAttributeCount),b.push(S.numDirLights),b.push(S.numPointLights),b.push(S.numSpotLights),b.push(S.numSpotLightMaps),b.push(S.numHemiLights),b.push(S.numRectAreaLights),b.push(S.numDirLightShadows),b.push(S.numPointLightShadows),b.push(S.numSpotLightShadows),b.push(S.numSpotLightShadowsWithMaps),b.push(S.numLightProbes),b.push(S.shadowMapType),b.push(S.toneMapping),b.push(S.numClippingPlanes),b.push(S.numClipIntersection),b.push(S.depthPacking)}function x(b,S){o.disableAll(),S.supportsVertexTextures&&o.enable(0),S.instancing&&o.enable(1),S.instancingColor&&o.enable(2),S.instancingMorph&&o.enable(3),S.matcap&&o.enable(4),S.envMap&&o.enable(5),S.normalMapObjectSpace&&o.enable(6),S.normalMapTangentSpace&&o.enable(7),S.clearcoat&&o.enable(8),S.iridescence&&o.enable(9),S.alphaTest&&o.enable(10),S.vertexColors&&o.enable(11),S.vertexAlphas&&o.enable(12),S.vertexUv1s&&o.enable(13),S.vertexUv2s&&o.enable(14),S.vertexUv3s&&o.enable(15),S.vertexTangents&&o.enable(16),S.anisotropy&&o.enable(17),S.alphaHash&&o.enable(18),S.batching&&o.enable(19),S.dispersion&&o.enable(20),S.batchingColor&&o.enable(21),S.gradientMap&&o.enable(22),b.push(o.mask),o.disableAll(),S.fog&&o.enable(0),S.useFog&&o.enable(1),S.flatShading&&o.enable(2),S.logarithmicDepthBuffer&&o.enable(3),S.reversedDepthBuffer&&o.enable(4),S.skinning&&o.enable(5),S.morphTargets&&o.enable(6),S.morphNormals&&o.enable(7),S.morphColors&&o.enable(8),S.premultipliedAlpha&&o.enable(9),S.shadowMapEnabled&&o.enable(10),S.doubleSided&&o.enable(11),S.flipSided&&o.enable(12),S.useDepthPacking&&o.enable(13),S.dithering&&o.enable(14),S.transmission&&o.enable(15),S.sheen&&o.enable(16),S.opaque&&o.enable(17),S.pointsUvs&&o.enable(18),S.decodeVideoTexture&&o.enable(19),S.decodeVideoTextureEmissive&&o.enable(20),S.alphaToCoverage&&o.enable(21),b.push(o.mask)}function y(b){const S=g[b.type];let I;if(S){const D=Gn[S];I=qa.clone(D.uniforms)}else I=b.uniforms;return I}function A(b,S){let I;for(let D=0,w=u.length;D<w;D++){const U=u[D];if(U.cacheKey===S){I=U,++I.usedTimes;break}}return I===void 0&&(I=new Lx(i,S,b,r),u.push(I)),I}function E(b){if(--b.usedTimes===0){const S=u.indexOf(b);u[S]=u[u.length-1],u.pop(),b.destroy()}}function M(b){c.remove(b)}function C(){c.dispose()}return{getParameters:m,getProgramCacheKey:f,getUniforms:y,acquireProgram:A,releaseProgram:E,releaseShaderCache:M,programs:u,dispose:C}}function Fx(){let i=new WeakMap;function e(a){return i.has(a)}function t(a){let o=i.get(a);return o===void 0&&(o={},i.set(a,o)),o}function n(a){i.delete(a)}function s(a,o,c){i.get(a)[o]=c}function r(){i=new WeakMap}return{has:e,get:t,remove:n,update:s,dispose:r}}function Bx(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.material.id!==e.material.id?i.material.id-e.material.id:i.z!==e.z?i.z-e.z:i.id-e.id}function Pd(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.z!==e.z?e.z-i.z:i.id-e.id}function Ld(){const i=[];let e=0;const t=[],n=[],s=[];function r(){e=0,t.length=0,n.length=0,s.length=0}function a(d,h,p,g,v,m){let f=i[e];return f===void 0?(f={id:d.id,object:d,geometry:h,material:p,groupOrder:g,renderOrder:d.renderOrder,z:v,group:m},i[e]=f):(f.id=d.id,f.object=d,f.geometry=h,f.material=p,f.groupOrder=g,f.renderOrder=d.renderOrder,f.z=v,f.group=m),e++,f}function o(d,h,p,g,v,m){const f=a(d,h,p,g,v,m);p.transmission>0?n.push(f):p.transparent===!0?s.push(f):t.push(f)}function c(d,h,p,g,v,m){const f=a(d,h,p,g,v,m);p.transmission>0?n.unshift(f):p.transparent===!0?s.unshift(f):t.unshift(f)}function l(d,h){t.length>1&&t.sort(d||Bx),n.length>1&&n.sort(h||Pd),s.length>1&&s.sort(h||Pd)}function u(){for(let d=e,h=i.length;d<h;d++){const p=i[d];if(p.id===null)break;p.id=null,p.object=null,p.geometry=null,p.material=null,p.group=null}}return{opaque:t,transmissive:n,transparent:s,init:r,push:o,unshift:c,finish:u,sort:l}}function kx(){let i=new WeakMap;function e(n,s){const r=i.get(n);let a;return r===void 0?(a=new Ld,i.set(n,[a])):s>=r.length?(a=new Ld,r.push(a)):a=r[s],a}function t(){i=new WeakMap}return{get:e,dispose:t}}function zx(){const i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"DirectionalLight":t={direction:new N,color:new Re};break;case"SpotLight":t={position:new N,direction:new N,color:new Re,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new N,color:new Re,distance:0,decay:0};break;case"HemisphereLight":t={direction:new N,skyColor:new Re,groundColor:new Re};break;case"RectAreaLight":t={color:new Re,position:new N,halfWidth:new N,halfHeight:new N};break}return i[e.id]=t,t}}}function Vx(){const i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"DirectionalLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ie};break;case"SpotLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ie};break;case"PointLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ie,shadowCameraNear:1,shadowCameraFar:1e3};break}return i[e.id]=t,t}}}let Hx=0;function Gx(i,e){return(e.castShadow?2:0)-(i.castShadow?2:0)+(e.map?1:0)-(i.map?1:0)}function Wx(i){const e=new zx,t=Vx(),n={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let l=0;l<9;l++)n.probe.push(new N);const s=new N,r=new Ye,a=new Ye;function o(l){let u=0,d=0,h=0;for(let b=0;b<9;b++)n.probe[b].set(0,0,0);let p=0,g=0,v=0,m=0,f=0,_=0,x=0,y=0,A=0,E=0,M=0;l.sort(Gx);for(let b=0,S=l.length;b<S;b++){const I=l[b],D=I.color,w=I.intensity,U=I.distance,O=I.shadow&&I.shadow.map?I.shadow.map.texture:null;if(I.isAmbientLight)u+=D.r*w,d+=D.g*w,h+=D.b*w;else if(I.isLightProbe){for(let F=0;F<9;F++)n.probe[F].addScaledVector(I.sh.coefficients[F],w);M++}else if(I.isDirectionalLight){const F=e.get(I);if(F.color.copy(I.color).multiplyScalar(I.intensity),I.castShadow){const V=I.shadow,k=t.get(I);k.shadowIntensity=V.intensity,k.shadowBias=V.bias,k.shadowNormalBias=V.normalBias,k.shadowRadius=V.radius,k.shadowMapSize=V.mapSize,n.directionalShadow[p]=k,n.directionalShadowMap[p]=O,n.directionalShadowMatrix[p]=I.shadow.matrix,_++}n.directional[p]=F,p++}else if(I.isSpotLight){const F=e.get(I);F.position.setFromMatrixPosition(I.matrixWorld),F.color.copy(D).multiplyScalar(w),F.distance=U,F.coneCos=Math.cos(I.angle),F.penumbraCos=Math.cos(I.angle*(1-I.penumbra)),F.decay=I.decay,n.spot[v]=F;const V=I.shadow;if(I.map&&(n.spotLightMap[A]=I.map,A++,V.updateMatrices(I),I.castShadow&&E++),n.spotLightMatrix[v]=V.matrix,I.castShadow){const k=t.get(I);k.shadowIntensity=V.intensity,k.shadowBias=V.bias,k.shadowNormalBias=V.normalBias,k.shadowRadius=V.radius,k.shadowMapSize=V.mapSize,n.spotShadow[v]=k,n.spotShadowMap[v]=O,y++}v++}else if(I.isRectAreaLight){const F=e.get(I);F.color.copy(D).multiplyScalar(w),F.halfWidth.set(I.width*.5,0,0),F.halfHeight.set(0,I.height*.5,0),n.rectArea[m]=F,m++}else if(I.isPointLight){const F=e.get(I);if(F.color.copy(I.color).multiplyScalar(I.intensity),F.distance=I.distance,F.decay=I.decay,I.castShadow){const V=I.shadow,k=t.get(I);k.shadowIntensity=V.intensity,k.shadowBias=V.bias,k.shadowNormalBias=V.normalBias,k.shadowRadius=V.radius,k.shadowMapSize=V.mapSize,k.shadowCameraNear=V.camera.near,k.shadowCameraFar=V.camera.far,n.pointShadow[g]=k,n.pointShadowMap[g]=O,n.pointShadowMatrix[g]=I.shadow.matrix,x++}n.point[g]=F,g++}else if(I.isHemisphereLight){const F=e.get(I);F.skyColor.copy(I.color).multiplyScalar(w),F.groundColor.copy(I.groundColor).multiplyScalar(w),n.hemi[f]=F,f++}}m>0&&(i.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=Se.LTC_FLOAT_1,n.rectAreaLTC2=Se.LTC_FLOAT_2):(n.rectAreaLTC1=Se.LTC_HALF_1,n.rectAreaLTC2=Se.LTC_HALF_2)),n.ambient[0]=u,n.ambient[1]=d,n.ambient[2]=h;const C=n.hash;(C.directionalLength!==p||C.pointLength!==g||C.spotLength!==v||C.rectAreaLength!==m||C.hemiLength!==f||C.numDirectionalShadows!==_||C.numPointShadows!==x||C.numSpotShadows!==y||C.numSpotMaps!==A||C.numLightProbes!==M)&&(n.directional.length=p,n.spot.length=v,n.rectArea.length=m,n.point.length=g,n.hemi.length=f,n.directionalShadow.length=_,n.directionalShadowMap.length=_,n.pointShadow.length=x,n.pointShadowMap.length=x,n.spotShadow.length=y,n.spotShadowMap.length=y,n.directionalShadowMatrix.length=_,n.pointShadowMatrix.length=x,n.spotLightMatrix.length=y+A-E,n.spotLightMap.length=A,n.numSpotLightShadowsWithMaps=E,n.numLightProbes=M,C.directionalLength=p,C.pointLength=g,C.spotLength=v,C.rectAreaLength=m,C.hemiLength=f,C.numDirectionalShadows=_,C.numPointShadows=x,C.numSpotShadows=y,C.numSpotMaps=A,C.numLightProbes=M,n.version=Hx++)}function c(l,u){let d=0,h=0,p=0,g=0,v=0;const m=u.matrixWorldInverse;for(let f=0,_=l.length;f<_;f++){const x=l[f];if(x.isDirectionalLight){const y=n.directional[d];y.direction.setFromMatrixPosition(x.matrixWorld),s.setFromMatrixPosition(x.target.matrixWorld),y.direction.sub(s),y.direction.transformDirection(m),d++}else if(x.isSpotLight){const y=n.spot[p];y.position.setFromMatrixPosition(x.matrixWorld),y.position.applyMatrix4(m),y.direction.setFromMatrixPosition(x.matrixWorld),s.setFromMatrixPosition(x.target.matrixWorld),y.direction.sub(s),y.direction.transformDirection(m),p++}else if(x.isRectAreaLight){const y=n.rectArea[g];y.position.setFromMatrixPosition(x.matrixWorld),y.position.applyMatrix4(m),a.identity(),r.copy(x.matrixWorld),r.premultiply(m),a.extractRotation(r),y.halfWidth.set(x.width*.5,0,0),y.halfHeight.set(0,x.height*.5,0),y.halfWidth.applyMatrix4(a),y.halfHeight.applyMatrix4(a),g++}else if(x.isPointLight){const y=n.point[h];y.position.setFromMatrixPosition(x.matrixWorld),y.position.applyMatrix4(m),h++}else if(x.isHemisphereLight){const y=n.hemi[v];y.direction.setFromMatrixPosition(x.matrixWorld),y.direction.transformDirection(m),v++}}}return{setup:o,setupView:c,state:n}}function Dd(i){const e=new Wx(i),t=[],n=[];function s(u){l.camera=u,t.length=0,n.length=0}function r(u){t.push(u)}function a(u){n.push(u)}function o(){e.setup(t)}function c(u){e.setupView(t,u)}const l={lightsArray:t,shadowsArray:n,camera:null,lights:e,transmissionRenderTarget:{}};return{init:s,state:l,setupLights:o,setupLightsView:c,pushLight:r,pushShadow:a}}function Xx(i){let e=new WeakMap;function t(s,r=0){const a=e.get(s);let o;return a===void 0?(o=new Dd(i),e.set(s,[o])):r>=a.length?(o=new Dd(i),a.push(o)):o=a[r],o}function n(){e=new WeakMap}return{get:t,dispose:n}}const qx=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,Yx=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function jx(i,e,t){let n=new zc;const s=new Ie,r=new Ie,a=new st,o=new Gm({depthPacking:Bp}),c=new Wm,l={},u=t.maxTextureSize,d={[fi]:an,[an]:fi,[Mt]:Mt},h=new Rt({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Ie},radius:{value:4}},vertexShader:qx,fragmentShader:Yx}),p=h.clone();p.defines.HORIZONTAL_PASS=1;const g=new It;g.setAttribute("position",new ct(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const v=new pt(g,h),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Dh;let f=this.type;this.render=function(E,M,C){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||E.length===0)return;const b=i.getRenderTarget(),S=i.getActiveCubeFace(),I=i.getActiveMipmapLevel(),D=i.state;D.setBlending(ui),D.buffers.depth.getReversed()===!0?D.buffers.color.setClear(0,0,0,0):D.buffers.color.setClear(1,1,1,1),D.buffers.depth.setTest(!0),D.setScissorTest(!1);const w=f!==ri&&this.type===ri,U=f===ri&&this.type!==ri;for(let O=0,F=E.length;O<F;O++){const V=E[O],k=V.shadow;if(k===void 0){console.warn("THREE.WebGLShadowMap:",V,"has no shadow.");continue}if(k.autoUpdate===!1&&k.needsUpdate===!1)continue;s.copy(k.mapSize);const z=k.getFrameExtents();if(s.multiply(z),r.copy(k.mapSize),(s.x>u||s.y>u)&&(s.x>u&&(r.x=Math.floor(u/z.x),s.x=r.x*z.x,k.mapSize.x=r.x),s.y>u&&(r.y=Math.floor(u/z.y),s.y=r.y*z.y,k.mapSize.y=r.y)),k.map===null||w===!0||U===!0){const j=this.type!==ri?{minFilter:Jt,magFilter:Jt}:{};k.map!==null&&k.map.dispose(),k.map=new kn(s.x,s.y,j),k.map.texture.name=V.name+".shadowMap",k.camera.updateProjectionMatrix()}i.setRenderTarget(k.map),i.clear();const B=k.getViewportCount();for(let j=0;j<B;j++){const ne=k.getViewport(j);a.set(r.x*ne.x,r.y*ne.y,r.x*ne.z,r.y*ne.w),D.viewport(a),k.updateMatrices(V,j),n=k.getFrustum(),y(M,C,k.camera,V,this.type)}k.isPointLightShadow!==!0&&this.type===ri&&_(k,C),k.needsUpdate=!1}f=this.type,m.needsUpdate=!1,i.setRenderTarget(b,S,I)};function _(E,M){const C=e.update(v);h.defines.VSM_SAMPLES!==E.blurSamples&&(h.defines.VSM_SAMPLES=E.blurSamples,p.defines.VSM_SAMPLES=E.blurSamples,h.needsUpdate=!0,p.needsUpdate=!0),E.mapPass===null&&(E.mapPass=new kn(s.x,s.y)),h.uniforms.shadow_pass.value=E.map.texture,h.uniforms.resolution.value=E.mapSize,h.uniforms.radius.value=E.radius,i.setRenderTarget(E.mapPass),i.clear(),i.renderBufferDirect(M,null,C,h,v,null),p.uniforms.shadow_pass.value=E.mapPass.texture,p.uniforms.resolution.value=E.mapSize,p.uniforms.radius.value=E.radius,i.setRenderTarget(E.map),i.clear(),i.renderBufferDirect(M,null,C,p,v,null)}function x(E,M,C,b){let S=null;const I=C.isPointLight===!0?E.customDistanceMaterial:E.customDepthMaterial;if(I!==void 0)S=I;else if(S=C.isPointLight===!0?c:o,i.localClippingEnabled&&M.clipShadows===!0&&Array.isArray(M.clippingPlanes)&&M.clippingPlanes.length!==0||M.displacementMap&&M.displacementScale!==0||M.alphaMap&&M.alphaTest>0||M.map&&M.alphaTest>0||M.alphaToCoverage===!0){const D=S.uuid,w=M.uuid;let U=l[D];U===void 0&&(U={},l[D]=U);let O=U[w];O===void 0&&(O=S.clone(),U[w]=O,M.addEventListener("dispose",A)),S=O}if(S.visible=M.visible,S.wireframe=M.wireframe,b===ri?S.side=M.shadowSide!==null?M.shadowSide:M.side:S.side=M.shadowSide!==null?M.shadowSide:d[M.side],S.alphaMap=M.alphaMap,S.alphaTest=M.alphaToCoverage===!0?.5:M.alphaTest,S.map=M.map,S.clipShadows=M.clipShadows,S.clippingPlanes=M.clippingPlanes,S.clipIntersection=M.clipIntersection,S.displacementMap=M.displacementMap,S.displacementScale=M.displacementScale,S.displacementBias=M.displacementBias,S.wireframeLinewidth=M.wireframeLinewidth,S.linewidth=M.linewidth,C.isPointLight===!0&&S.isMeshDistanceMaterial===!0){const D=i.properties.get(S);D.light=C}return S}function y(E,M,C,b,S){if(E.visible===!1)return;if(E.layers.test(M.layers)&&(E.isMesh||E.isLine||E.isPoints)&&(E.castShadow||E.receiveShadow&&S===ri)&&(!E.frustumCulled||n.intersectsObject(E))){E.modelViewMatrix.multiplyMatrices(C.matrixWorldInverse,E.matrixWorld);const w=e.update(E),U=E.material;if(Array.isArray(U)){const O=w.groups;for(let F=0,V=O.length;F<V;F++){const k=O[F],z=U[k.materialIndex];if(z&&z.visible){const B=x(E,z,b,S);E.onBeforeShadow(i,E,M,C,w,B,k),i.renderBufferDirect(C,null,w,B,E,k),E.onAfterShadow(i,E,M,C,w,B,k)}}}else if(U.visible){const O=x(E,U,b,S);E.onBeforeShadow(i,E,M,C,w,O,null),i.renderBufferDirect(C,null,w,O,E,null),E.onAfterShadow(i,E,M,C,w,O,null)}}const D=E.children;for(let w=0,U=D.length;w<U;w++)y(D[w],M,C,b,S)}function A(E){E.target.removeEventListener("dispose",A);for(const C in l){const b=l[C],S=E.target.uuid;S in b&&(b[S].dispose(),delete b[S])}}}const $x={[Tl]:Al,[wl]:Il,[Rl]:Pl,[Os]:Cl,[Al]:Tl,[Il]:wl,[Pl]:Rl,[Cl]:Os};function Kx(i,e){function t(){let H=!1;const fe=new st;let ve=null;const Ce=new st(0,0,0,0);return{setMask:function(ue){ve!==ue&&!H&&(i.colorMask(ue,ue,ue,ue),ve=ue)},setLocked:function(ue){H=ue},setClear:function(ue,ee,De,je,gt){gt===!0&&(ue*=je,ee*=je,De*=je),fe.set(ue,ee,De,je),Ce.equals(fe)===!1&&(i.clearColor(ue,ee,De,je),Ce.copy(fe))},reset:function(){H=!1,ve=null,Ce.set(-1,0,0,0)}}}function n(){let H=!1,fe=!1,ve=null,Ce=null,ue=null;return{setReversed:function(ee){if(fe!==ee){const De=e.get("EXT_clip_control");ee?De.clipControlEXT(De.LOWER_LEFT_EXT,De.ZERO_TO_ONE_EXT):De.clipControlEXT(De.LOWER_LEFT_EXT,De.NEGATIVE_ONE_TO_ONE_EXT),fe=ee;const je=ue;ue=null,this.setClear(je)}},getReversed:function(){return fe},setTest:function(ee){ee?Y(i.DEPTH_TEST):ie(i.DEPTH_TEST)},setMask:function(ee){ve!==ee&&!H&&(i.depthMask(ee),ve=ee)},setFunc:function(ee){if(fe&&(ee=$x[ee]),Ce!==ee){switch(ee){case Tl:i.depthFunc(i.NEVER);break;case Al:i.depthFunc(i.ALWAYS);break;case wl:i.depthFunc(i.LESS);break;case Os:i.depthFunc(i.LEQUAL);break;case Rl:i.depthFunc(i.EQUAL);break;case Cl:i.depthFunc(i.GEQUAL);break;case Il:i.depthFunc(i.GREATER);break;case Pl:i.depthFunc(i.NOTEQUAL);break;default:i.depthFunc(i.LEQUAL)}Ce=ee}},setLocked:function(ee){H=ee},setClear:function(ee){ue!==ee&&(fe&&(ee=1-ee),i.clearDepth(ee),ue=ee)},reset:function(){H=!1,ve=null,Ce=null,ue=null,fe=!1}}}function s(){let H=!1,fe=null,ve=null,Ce=null,ue=null,ee=null,De=null,je=null,gt=null;return{setTest:function(rt){H||(rt?Y(i.STENCIL_TEST):ie(i.STENCIL_TEST))},setMask:function(rt){fe!==rt&&!H&&(i.stencilMask(rt),fe=rt)},setFunc:function(rt,Zn,Vn){(ve!==rt||Ce!==Zn||ue!==Vn)&&(i.stencilFunc(rt,Zn,Vn),ve=rt,Ce=Zn,ue=Vn)},setOp:function(rt,Zn,Vn){(ee!==rt||De!==Zn||je!==Vn)&&(i.stencilOp(rt,Zn,Vn),ee=rt,De=Zn,je=Vn)},setLocked:function(rt){H=rt},setClear:function(rt){gt!==rt&&(i.clearStencil(rt),gt=rt)},reset:function(){H=!1,fe=null,ve=null,Ce=null,ue=null,ee=null,De=null,je=null,gt=null}}}const r=new t,a=new n,o=new s,c=new WeakMap,l=new WeakMap;let u={},d={},h=new WeakMap,p=[],g=null,v=!1,m=null,f=null,_=null,x=null,y=null,A=null,E=null,M=new Re(0,0,0),C=0,b=!1,S=null,I=null,D=null,w=null,U=null;const O=i.getParameter(i.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let F=!1,V=0;const k=i.getParameter(i.VERSION);k.indexOf("WebGL")!==-1?(V=parseFloat(/^WebGL (\d)/.exec(k)[1]),F=V>=1):k.indexOf("OpenGL ES")!==-1&&(V=parseFloat(/^OpenGL ES (\d)/.exec(k)[1]),F=V>=2);let z=null,B={};const j=i.getParameter(i.SCISSOR_BOX),ne=i.getParameter(i.VIEWPORT),Q=new st().fromArray(j),re=new st().fromArray(ne);function ce(H,fe,ve,Ce){const ue=new Uint8Array(4),ee=i.createTexture();i.bindTexture(H,ee),i.texParameteri(H,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(H,i.TEXTURE_MAG_FILTER,i.NEAREST);for(let De=0;De<ve;De++)H===i.TEXTURE_3D||H===i.TEXTURE_2D_ARRAY?i.texImage3D(fe,0,i.RGBA,1,1,Ce,0,i.RGBA,i.UNSIGNED_BYTE,ue):i.texImage2D(fe+De,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,ue);return ee}const G={};G[i.TEXTURE_2D]=ce(i.TEXTURE_2D,i.TEXTURE_2D,1),G[i.TEXTURE_CUBE_MAP]=ce(i.TEXTURE_CUBE_MAP,i.TEXTURE_CUBE_MAP_POSITIVE_X,6),G[i.TEXTURE_2D_ARRAY]=ce(i.TEXTURE_2D_ARRAY,i.TEXTURE_2D_ARRAY,1,1),G[i.TEXTURE_3D]=ce(i.TEXTURE_3D,i.TEXTURE_3D,1,1),r.setClear(0,0,0,1),a.setClear(1),o.setClear(0),Y(i.DEPTH_TEST),a.setFunc(Os),ae(!1),le(pu),Y(i.CULL_FACE),Ue(ui);function Y(H){u[H]!==!0&&(i.enable(H),u[H]=!0)}function ie(H){u[H]!==!1&&(i.disable(H),u[H]=!1)}function ye(H,fe){return d[H]!==fe?(i.bindFramebuffer(H,fe),d[H]=fe,H===i.DRAW_FRAMEBUFFER&&(d[i.FRAMEBUFFER]=fe),H===i.FRAMEBUFFER&&(d[i.DRAW_FRAMEBUFFER]=fe),!0):!1}function se(H,fe){let ve=p,Ce=!1;if(H){ve=h.get(fe),ve===void 0&&(ve=[],h.set(fe,ve));const ue=H.textures;if(ve.length!==ue.length||ve[0]!==i.COLOR_ATTACHMENT0){for(let ee=0,De=ue.length;ee<De;ee++)ve[ee]=i.COLOR_ATTACHMENT0+ee;ve.length=ue.length,Ce=!0}}else ve[0]!==i.BACK&&(ve[0]=i.BACK,Ce=!0);Ce&&i.drawBuffers(ve)}function Le(H){return g!==H?(i.useProgram(H),g=H,!0):!1}const be={[ji]:i.FUNC_ADD,[cp]:i.FUNC_SUBTRACT,[up]:i.FUNC_REVERSE_SUBTRACT};be[dp]=i.MIN,be[hp]=i.MAX;const L={[fp]:i.ZERO,[pp]:i.ONE,[mp]:i.SRC_COLOR,[Ml]:i.SRC_ALPHA,[Sp]:i.SRC_ALPHA_SATURATE,[xp]:i.DST_COLOR,[vp]:i.DST_ALPHA,[gp]:i.ONE_MINUS_SRC_COLOR,[El]:i.ONE_MINUS_SRC_ALPHA,[yp]:i.ONE_MINUS_DST_COLOR,[_p]:i.ONE_MINUS_DST_ALPHA,[bp]:i.CONSTANT_COLOR,[Mp]:i.ONE_MINUS_CONSTANT_COLOR,[Ep]:i.CONSTANT_ALPHA,[Tp]:i.ONE_MINUS_CONSTANT_ALPHA};function Ue(H,fe,ve,Ce,ue,ee,De,je,gt,rt){if(H===ui){v===!0&&(ie(i.BLEND),v=!1);return}if(v===!1&&(Y(i.BLEND),v=!0),H!==lp){if(H!==m||rt!==b){if((f!==ji||y!==ji)&&(i.blendEquation(i.FUNC_ADD),f=ji,y=ji),rt)switch(H){case Ci:i.blendFuncSeparate(i.ONE,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case gn:i.blendFunc(i.ONE,i.ONE);break;case mu:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case gu:i.blendFuncSeparate(i.DST_COLOR,i.ONE_MINUS_SRC_ALPHA,i.ZERO,i.ONE);break;default:console.error("THREE.WebGLState: Invalid blending: ",H);break}else switch(H){case Ci:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case gn:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE,i.ONE,i.ONE);break;case mu:console.error("THREE.WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case gu:console.error("THREE.WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:console.error("THREE.WebGLState: Invalid blending: ",H);break}_=null,x=null,A=null,E=null,M.set(0,0,0),C=0,m=H,b=rt}return}ue=ue||fe,ee=ee||ve,De=De||Ce,(fe!==f||ue!==y)&&(i.blendEquationSeparate(be[fe],be[ue]),f=fe,y=ue),(ve!==_||Ce!==x||ee!==A||De!==E)&&(i.blendFuncSeparate(L[ve],L[Ce],L[ee],L[De]),_=ve,x=Ce,A=ee,E=De),(je.equals(M)===!1||gt!==C)&&(i.blendColor(je.r,je.g,je.b,gt),M.copy(je),C=gt),m=H,b=!1}function me(H,fe){H.side===Mt?ie(i.CULL_FACE):Y(i.CULL_FACE);let ve=H.side===an;fe&&(ve=!ve),ae(ve),H.blending===Ci&&H.transparent===!1?Ue(ui):Ue(H.blending,H.blendEquation,H.blendSrc,H.blendDst,H.blendEquationAlpha,H.blendSrcAlpha,H.blendDstAlpha,H.blendColor,H.blendAlpha,H.premultipliedAlpha),a.setFunc(H.depthFunc),a.setTest(H.depthTest),a.setMask(H.depthWrite),r.setMask(H.colorWrite);const Ce=H.stencilWrite;o.setTest(Ce),Ce&&(o.setMask(H.stencilWriteMask),o.setFunc(H.stencilFunc,H.stencilRef,H.stencilFuncMask),o.setOp(H.stencilFail,H.stencilZFail,H.stencilZPass)),pe(H.polygonOffset,H.polygonOffsetFactor,H.polygonOffsetUnits),H.alphaToCoverage===!0?Y(i.SAMPLE_ALPHA_TO_COVERAGE):ie(i.SAMPLE_ALPHA_TO_COVERAGE)}function ae(H){S!==H&&(H?i.frontFace(i.CW):i.frontFace(i.CCW),S=H)}function le(H){H!==rp?(Y(i.CULL_FACE),H!==I&&(H===pu?i.cullFace(i.BACK):H===ap?i.cullFace(i.FRONT):i.cullFace(i.FRONT_AND_BACK))):ie(i.CULL_FACE),I=H}function Ne(H){H!==D&&(F&&i.lineWidth(H),D=H)}function pe(H,fe,ve){H?(Y(i.POLYGON_OFFSET_FILL),(w!==fe||U!==ve)&&(i.polygonOffset(fe,ve),w=fe,U=ve)):ie(i.POLYGON_OFFSET_FILL)}function Ae(H){H?Y(i.SCISSOR_TEST):ie(i.SCISSOR_TEST)}function He(H){H===void 0&&(H=i.TEXTURE0+O-1),z!==H&&(i.activeTexture(H),z=H)}function ke(H,fe,ve){ve===void 0&&(z===null?ve=i.TEXTURE0+O-1:ve=z);let Ce=B[ve];Ce===void 0&&(Ce={type:void 0,texture:void 0},B[ve]=Ce),(Ce.type!==H||Ce.texture!==fe)&&(z!==ve&&(i.activeTexture(ve),z=ve),i.bindTexture(H,fe||G[H]),Ce.type=H,Ce.texture=fe)}function P(){const H=B[z];H!==void 0&&H.type!==void 0&&(i.bindTexture(H.type,null),H.type=void 0,H.texture=void 0)}function T(){try{i.compressedTexImage2D(...arguments)}catch(H){console.error("THREE.WebGLState:",H)}}function q(){try{i.compressedTexImage3D(...arguments)}catch(H){console.error("THREE.WebGLState:",H)}}function J(){try{i.texSubImage2D(...arguments)}catch(H){console.error("THREE.WebGLState:",H)}}function te(){try{i.texSubImage3D(...arguments)}catch(H){console.error("THREE.WebGLState:",H)}}function $(){try{i.compressedTexSubImage2D(...arguments)}catch(H){console.error("THREE.WebGLState:",H)}}function xe(){try{i.compressedTexSubImage3D(...arguments)}catch(H){console.error("THREE.WebGLState:",H)}}function oe(){try{i.texStorage2D(...arguments)}catch(H){console.error("THREE.WebGLState:",H)}}function Oe(){try{i.texStorage3D(...arguments)}catch(H){console.error("THREE.WebGLState:",H)}}function Fe(){try{i.texImage2D(...arguments)}catch(H){console.error("THREE.WebGLState:",H)}}function he(){try{i.texImage3D(...arguments)}catch(H){console.error("THREE.WebGLState:",H)}}function Te(H){Q.equals(H)===!1&&(i.scissor(H.x,H.y,H.z,H.w),Q.copy(H))}function We(H){re.equals(H)===!1&&(i.viewport(H.x,H.y,H.z,H.w),re.copy(H))}function Be(H,fe){let ve=l.get(fe);ve===void 0&&(ve=new WeakMap,l.set(fe,ve));let Ce=ve.get(H);Ce===void 0&&(Ce=i.getUniformBlockIndex(fe,H.name),ve.set(H,Ce))}function Me(H,fe){const Ce=l.get(fe).get(H);c.get(fe)!==Ce&&(i.uniformBlockBinding(fe,Ce,H.__bindingPointIndex),c.set(fe,Ce))}function Ke(){i.disable(i.BLEND),i.disable(i.CULL_FACE),i.disable(i.DEPTH_TEST),i.disable(i.POLYGON_OFFSET_FILL),i.disable(i.SCISSOR_TEST),i.disable(i.STENCIL_TEST),i.disable(i.SAMPLE_ALPHA_TO_COVERAGE),i.blendEquation(i.FUNC_ADD),i.blendFunc(i.ONE,i.ZERO),i.blendFuncSeparate(i.ONE,i.ZERO,i.ONE,i.ZERO),i.blendColor(0,0,0,0),i.colorMask(!0,!0,!0,!0),i.clearColor(0,0,0,0),i.depthMask(!0),i.depthFunc(i.LESS),a.setReversed(!1),i.clearDepth(1),i.stencilMask(4294967295),i.stencilFunc(i.ALWAYS,0,4294967295),i.stencilOp(i.KEEP,i.KEEP,i.KEEP),i.clearStencil(0),i.cullFace(i.BACK),i.frontFace(i.CCW),i.polygonOffset(0,0),i.activeTexture(i.TEXTURE0),i.bindFramebuffer(i.FRAMEBUFFER,null),i.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),i.bindFramebuffer(i.READ_FRAMEBUFFER,null),i.useProgram(null),i.lineWidth(1),i.scissor(0,0,i.canvas.width,i.canvas.height),i.viewport(0,0,i.canvas.width,i.canvas.height),u={},z=null,B={},d={},h=new WeakMap,p=[],g=null,v=!1,m=null,f=null,_=null,x=null,y=null,A=null,E=null,M=new Re(0,0,0),C=0,b=!1,S=null,I=null,D=null,w=null,U=null,Q.set(0,0,i.canvas.width,i.canvas.height),re.set(0,0,i.canvas.width,i.canvas.height),r.reset(),a.reset(),o.reset()}return{buffers:{color:r,depth:a,stencil:o},enable:Y,disable:ie,bindFramebuffer:ye,drawBuffers:se,useProgram:Le,setBlending:Ue,setMaterial:me,setFlipSided:ae,setCullFace:le,setLineWidth:Ne,setPolygonOffset:pe,setScissorTest:Ae,activeTexture:He,bindTexture:ke,unbindTexture:P,compressedTexImage2D:T,compressedTexImage3D:q,texImage2D:Fe,texImage3D:he,updateUBOMapping:Be,uniformBlockBinding:Me,texStorage2D:oe,texStorage3D:Oe,texSubImage2D:J,texSubImage3D:te,compressedTexSubImage2D:$,compressedTexSubImage3D:xe,scissor:Te,viewport:We,reset:Ke}}function Zx(i,e,t,n,s,r,a){const o=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,c=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),l=new Ie,u=new WeakMap;let d;const h=new WeakMap;let p=!1;try{p=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function g(P,T){return p?new OffscreenCanvas(P,T):Lr("canvas")}function v(P,T,q){let J=1;const te=ke(P);if((te.width>q||te.height>q)&&(J=q/Math.max(te.width,te.height)),J<1)if(typeof HTMLImageElement<"u"&&P instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&P instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&P instanceof ImageBitmap||typeof VideoFrame<"u"&&P instanceof VideoFrame){const $=Math.floor(J*te.width),xe=Math.floor(J*te.height);d===void 0&&(d=g($,xe));const oe=T?g($,xe):d;return oe.width=$,oe.height=xe,oe.getContext("2d").drawImage(P,0,0,$,xe),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+te.width+"x"+te.height+") to ("+$+"x"+xe+")."),oe}else return"data"in P&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+te.width+"x"+te.height+")."),P;return P}function m(P){return P.generateMipmaps}function f(P){i.generateMipmap(P)}function _(P){return P.isWebGLCubeRenderTarget?i.TEXTURE_CUBE_MAP:P.isWebGL3DRenderTarget?i.TEXTURE_3D:P.isWebGLArrayRenderTarget||P.isCompressedArrayTexture?i.TEXTURE_2D_ARRAY:i.TEXTURE_2D}function x(P,T,q,J,te=!1){if(P!==null){if(i[P]!==void 0)return i[P];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+P+"'")}let $=T;if(T===i.RED&&(q===i.FLOAT&&($=i.R32F),q===i.HALF_FLOAT&&($=i.R16F),q===i.UNSIGNED_BYTE&&($=i.R8)),T===i.RED_INTEGER&&(q===i.UNSIGNED_BYTE&&($=i.R8UI),q===i.UNSIGNED_SHORT&&($=i.R16UI),q===i.UNSIGNED_INT&&($=i.R32UI),q===i.BYTE&&($=i.R8I),q===i.SHORT&&($=i.R16I),q===i.INT&&($=i.R32I)),T===i.RG&&(q===i.FLOAT&&($=i.RG32F),q===i.HALF_FLOAT&&($=i.RG16F),q===i.UNSIGNED_BYTE&&($=i.RG8)),T===i.RG_INTEGER&&(q===i.UNSIGNED_BYTE&&($=i.RG8UI),q===i.UNSIGNED_SHORT&&($=i.RG16UI),q===i.UNSIGNED_INT&&($=i.RG32UI),q===i.BYTE&&($=i.RG8I),q===i.SHORT&&($=i.RG16I),q===i.INT&&($=i.RG32I)),T===i.RGB_INTEGER&&(q===i.UNSIGNED_BYTE&&($=i.RGB8UI),q===i.UNSIGNED_SHORT&&($=i.RGB16UI),q===i.UNSIGNED_INT&&($=i.RGB32UI),q===i.BYTE&&($=i.RGB8I),q===i.SHORT&&($=i.RGB16I),q===i.INT&&($=i.RGB32I)),T===i.RGBA_INTEGER&&(q===i.UNSIGNED_BYTE&&($=i.RGBA8UI),q===i.UNSIGNED_SHORT&&($=i.RGBA16UI),q===i.UNSIGNED_INT&&($=i.RGBA32UI),q===i.BYTE&&($=i.RGBA8I),q===i.SHORT&&($=i.RGBA16I),q===i.INT&&($=i.RGBA32I)),T===i.RGB&&(q===i.UNSIGNED_INT_5_9_9_9_REV&&($=i.RGB9_E5),q===i.UNSIGNED_INT_10F_11F_11F_REV&&($=i.R11F_G11F_B10F)),T===i.RGBA){const xe=te?Wa:tt.getTransfer(J);q===i.FLOAT&&($=i.RGBA32F),q===i.HALF_FLOAT&&($=i.RGBA16F),q===i.UNSIGNED_BYTE&&($=xe===ft?i.SRGB8_ALPHA8:i.RGBA8),q===i.UNSIGNED_SHORT_4_4_4_4&&($=i.RGBA4),q===i.UNSIGNED_SHORT_5_5_5_1&&($=i.RGB5_A1)}return($===i.R16F||$===i.R32F||$===i.RG16F||$===i.RG32F||$===i.RGBA16F||$===i.RGBA32F)&&e.get("EXT_color_buffer_float"),$}function y(P,T){let q;return P?T===null||T===Ki||T===wr?q=i.DEPTH24_STENCIL8:T===Fn?q=i.DEPTH32F_STENCIL8:T===Ar&&(q=i.DEPTH24_STENCIL8,console.warn("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):T===null||T===Ki||T===wr?q=i.DEPTH_COMPONENT24:T===Fn?q=i.DEPTH_COMPONENT32F:T===Ar&&(q=i.DEPTH_COMPONENT16),q}function A(P,T){return m(P)===!0||P.isFramebufferTexture&&P.minFilter!==Jt&&P.minFilter!==Lt?Math.log2(Math.max(T.width,T.height))+1:P.mipmaps!==void 0&&P.mipmaps.length>0?P.mipmaps.length:P.isCompressedTexture&&Array.isArray(P.image)?T.mipmaps.length:1}function E(P){const T=P.target;T.removeEventListener("dispose",E),C(T),T.isVideoTexture&&u.delete(T)}function M(P){const T=P.target;T.removeEventListener("dispose",M),S(T)}function C(P){const T=n.get(P);if(T.__webglInit===void 0)return;const q=P.source,J=h.get(q);if(J){const te=J[T.__cacheKey];te.usedTimes--,te.usedTimes===0&&b(P),Object.keys(J).length===0&&h.delete(q)}n.remove(P)}function b(P){const T=n.get(P);i.deleteTexture(T.__webglTexture);const q=P.source,J=h.get(q);delete J[T.__cacheKey],a.memory.textures--}function S(P){const T=n.get(P);if(P.depthTexture&&(P.depthTexture.dispose(),n.remove(P.depthTexture)),P.isWebGLCubeRenderTarget)for(let J=0;J<6;J++){if(Array.isArray(T.__webglFramebuffer[J]))for(let te=0;te<T.__webglFramebuffer[J].length;te++)i.deleteFramebuffer(T.__webglFramebuffer[J][te]);else i.deleteFramebuffer(T.__webglFramebuffer[J]);T.__webglDepthbuffer&&i.deleteRenderbuffer(T.__webglDepthbuffer[J])}else{if(Array.isArray(T.__webglFramebuffer))for(let J=0;J<T.__webglFramebuffer.length;J++)i.deleteFramebuffer(T.__webglFramebuffer[J]);else i.deleteFramebuffer(T.__webglFramebuffer);if(T.__webglDepthbuffer&&i.deleteRenderbuffer(T.__webglDepthbuffer),T.__webglMultisampledFramebuffer&&i.deleteFramebuffer(T.__webglMultisampledFramebuffer),T.__webglColorRenderbuffer)for(let J=0;J<T.__webglColorRenderbuffer.length;J++)T.__webglColorRenderbuffer[J]&&i.deleteRenderbuffer(T.__webglColorRenderbuffer[J]);T.__webglDepthRenderbuffer&&i.deleteRenderbuffer(T.__webglDepthRenderbuffer)}const q=P.textures;for(let J=0,te=q.length;J<te;J++){const $=n.get(q[J]);$.__webglTexture&&(i.deleteTexture($.__webglTexture),a.memory.textures--),n.remove(q[J])}n.remove(P)}let I=0;function D(){I=0}function w(){const P=I;return P>=s.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+P+" texture units while this GPU supports only "+s.maxTextures),I+=1,P}function U(P){const T=[];return T.push(P.wrapS),T.push(P.wrapT),T.push(P.wrapR||0),T.push(P.magFilter),T.push(P.minFilter),T.push(P.anisotropy),T.push(P.internalFormat),T.push(P.format),T.push(P.type),T.push(P.generateMipmaps),T.push(P.premultiplyAlpha),T.push(P.flipY),T.push(P.unpackAlignment),T.push(P.colorSpace),T.join()}function O(P,T){const q=n.get(P);if(P.isVideoTexture&&Ae(P),P.isRenderTargetTexture===!1&&P.isExternalTexture!==!0&&P.version>0&&q.__version!==P.version){const J=P.image;if(J===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(J.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{G(q,P,T);return}}else P.isExternalTexture&&(q.__webglTexture=P.sourceTexture?P.sourceTexture:null);t.bindTexture(i.TEXTURE_2D,q.__webglTexture,i.TEXTURE0+T)}function F(P,T){const q=n.get(P);if(P.isRenderTargetTexture===!1&&P.version>0&&q.__version!==P.version){G(q,P,T);return}t.bindTexture(i.TEXTURE_2D_ARRAY,q.__webglTexture,i.TEXTURE0+T)}function V(P,T){const q=n.get(P);if(P.isRenderTargetTexture===!1&&P.version>0&&q.__version!==P.version){G(q,P,T);return}t.bindTexture(i.TEXTURE_3D,q.__webglTexture,i.TEXTURE0+T)}function k(P,T){const q=n.get(P);if(P.version>0&&q.__version!==P.version){Y(q,P,T);return}t.bindTexture(i.TEXTURE_CUBE_MAP,q.__webglTexture,i.TEXTURE0+T)}const z={[Bs]:i.REPEAT,[Ri]:i.CLAMP_TO_EDGE,[Ga]:i.MIRRORED_REPEAT},B={[Jt]:i.NEAREST,[Uh]:i.NEAREST_MIPMAP_NEAREST,[xr]:i.NEAREST_MIPMAP_LINEAR,[Lt]:i.LINEAR,[Na]:i.LINEAR_MIPMAP_NEAREST,[Gt]:i.LINEAR_MIPMAP_LINEAR},j={[zp]:i.NEVER,[qp]:i.ALWAYS,[Vp]:i.LESS,[Xh]:i.LEQUAL,[Hp]:i.EQUAL,[Xp]:i.GEQUAL,[Gp]:i.GREATER,[Wp]:i.NOTEQUAL};function ne(P,T){if(T.type===Fn&&e.has("OES_texture_float_linear")===!1&&(T.magFilter===Lt||T.magFilter===Na||T.magFilter===xr||T.magFilter===Gt||T.minFilter===Lt||T.minFilter===Na||T.minFilter===xr||T.minFilter===Gt)&&console.warn("THREE.WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),i.texParameteri(P,i.TEXTURE_WRAP_S,z[T.wrapS]),i.texParameteri(P,i.TEXTURE_WRAP_T,z[T.wrapT]),(P===i.TEXTURE_3D||P===i.TEXTURE_2D_ARRAY)&&i.texParameteri(P,i.TEXTURE_WRAP_R,z[T.wrapR]),i.texParameteri(P,i.TEXTURE_MAG_FILTER,B[T.magFilter]),i.texParameteri(P,i.TEXTURE_MIN_FILTER,B[T.minFilter]),T.compareFunction&&(i.texParameteri(P,i.TEXTURE_COMPARE_MODE,i.COMPARE_REF_TO_TEXTURE),i.texParameteri(P,i.TEXTURE_COMPARE_FUNC,j[T.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(T.magFilter===Jt||T.minFilter!==xr&&T.minFilter!==Gt||T.type===Fn&&e.has("OES_texture_float_linear")===!1)return;if(T.anisotropy>1||n.get(T).__currentAnisotropy){const q=e.get("EXT_texture_filter_anisotropic");i.texParameterf(P,q.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(T.anisotropy,s.getMaxAnisotropy())),n.get(T).__currentAnisotropy=T.anisotropy}}}function Q(P,T){let q=!1;P.__webglInit===void 0&&(P.__webglInit=!0,T.addEventListener("dispose",E));const J=T.source;let te=h.get(J);te===void 0&&(te={},h.set(J,te));const $=U(T);if($!==P.__cacheKey){te[$]===void 0&&(te[$]={texture:i.createTexture(),usedTimes:0},a.memory.textures++,q=!0),te[$].usedTimes++;const xe=te[P.__cacheKey];xe!==void 0&&(te[P.__cacheKey].usedTimes--,xe.usedTimes===0&&b(T)),P.__cacheKey=$,P.__webglTexture=te[$].texture}return q}function re(P,T,q){return Math.floor(Math.floor(P/q)/T)}function ce(P,T,q,J){const $=P.updateRanges;if($.length===0)t.texSubImage2D(i.TEXTURE_2D,0,0,0,T.width,T.height,q,J,T.data);else{$.sort((he,Te)=>he.start-Te.start);let xe=0;for(let he=1;he<$.length;he++){const Te=$[xe],We=$[he],Be=Te.start+Te.count,Me=re(We.start,T.width,4),Ke=re(Te.start,T.width,4);We.start<=Be+1&&Me===Ke&&re(We.start+We.count-1,T.width,4)===Me?Te.count=Math.max(Te.count,We.start+We.count-Te.start):(++xe,$[xe]=We)}$.length=xe+1;const oe=i.getParameter(i.UNPACK_ROW_LENGTH),Oe=i.getParameter(i.UNPACK_SKIP_PIXELS),Fe=i.getParameter(i.UNPACK_SKIP_ROWS);i.pixelStorei(i.UNPACK_ROW_LENGTH,T.width);for(let he=0,Te=$.length;he<Te;he++){const We=$[he],Be=Math.floor(We.start/4),Me=Math.ceil(We.count/4),Ke=Be%T.width,H=Math.floor(Be/T.width),fe=Me,ve=1;i.pixelStorei(i.UNPACK_SKIP_PIXELS,Ke),i.pixelStorei(i.UNPACK_SKIP_ROWS,H),t.texSubImage2D(i.TEXTURE_2D,0,Ke,H,fe,ve,q,J,T.data)}P.clearUpdateRanges(),i.pixelStorei(i.UNPACK_ROW_LENGTH,oe),i.pixelStorei(i.UNPACK_SKIP_PIXELS,Oe),i.pixelStorei(i.UNPACK_SKIP_ROWS,Fe)}}function G(P,T,q){let J=i.TEXTURE_2D;(T.isDataArrayTexture||T.isCompressedArrayTexture)&&(J=i.TEXTURE_2D_ARRAY),T.isData3DTexture&&(J=i.TEXTURE_3D);const te=Q(P,T),$=T.source;t.bindTexture(J,P.__webglTexture,i.TEXTURE0+q);const xe=n.get($);if($.version!==xe.__version||te===!0){t.activeTexture(i.TEXTURE0+q);const oe=tt.getPrimaries(tt.workingColorSpace),Oe=T.colorSpace===oi?null:tt.getPrimaries(T.colorSpace),Fe=T.colorSpace===oi||oe===Oe?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,T.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,T.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,T.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,Fe);let he=v(T.image,!1,s.maxTextureSize);he=He(T,he);const Te=r.convert(T.format,T.colorSpace),We=r.convert(T.type);let Be=x(T.internalFormat,Te,We,T.colorSpace,T.isVideoTexture);ne(J,T);let Me;const Ke=T.mipmaps,H=T.isVideoTexture!==!0,fe=xe.__version===void 0||te===!0,ve=$.dataReady,Ce=A(T,he);if(T.isDepthTexture)Be=y(T.format===Cr,T.type),fe&&(H?t.texStorage2D(i.TEXTURE_2D,1,Be,he.width,he.height):t.texImage2D(i.TEXTURE_2D,0,Be,he.width,he.height,0,Te,We,null));else if(T.isDataTexture)if(Ke.length>0){H&&fe&&t.texStorage2D(i.TEXTURE_2D,Ce,Be,Ke[0].width,Ke[0].height);for(let ue=0,ee=Ke.length;ue<ee;ue++)Me=Ke[ue],H?ve&&t.texSubImage2D(i.TEXTURE_2D,ue,0,0,Me.width,Me.height,Te,We,Me.data):t.texImage2D(i.TEXTURE_2D,ue,Be,Me.width,Me.height,0,Te,We,Me.data);T.generateMipmaps=!1}else H?(fe&&t.texStorage2D(i.TEXTURE_2D,Ce,Be,he.width,he.height),ve&&ce(T,he,Te,We)):t.texImage2D(i.TEXTURE_2D,0,Be,he.width,he.height,0,Te,We,he.data);else if(T.isCompressedTexture)if(T.isCompressedArrayTexture){H&&fe&&t.texStorage3D(i.TEXTURE_2D_ARRAY,Ce,Be,Ke[0].width,Ke[0].height,he.depth);for(let ue=0,ee=Ke.length;ue<ee;ue++)if(Me=Ke[ue],T.format!==An)if(Te!==null)if(H){if(ve)if(T.layerUpdates.size>0){const De=cd(Me.width,Me.height,T.format,T.type);for(const je of T.layerUpdates){const gt=Me.data.subarray(je*De/Me.data.BYTES_PER_ELEMENT,(je+1)*De/Me.data.BYTES_PER_ELEMENT);t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,ue,0,0,je,Me.width,Me.height,1,Te,gt)}T.clearLayerUpdates()}else t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,ue,0,0,0,Me.width,Me.height,he.depth,Te,Me.data)}else t.compressedTexImage3D(i.TEXTURE_2D_ARRAY,ue,Be,Me.width,Me.height,he.depth,0,Me.data,0,0);else console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else H?ve&&t.texSubImage3D(i.TEXTURE_2D_ARRAY,ue,0,0,0,Me.width,Me.height,he.depth,Te,We,Me.data):t.texImage3D(i.TEXTURE_2D_ARRAY,ue,Be,Me.width,Me.height,he.depth,0,Te,We,Me.data)}else{H&&fe&&t.texStorage2D(i.TEXTURE_2D,Ce,Be,Ke[0].width,Ke[0].height);for(let ue=0,ee=Ke.length;ue<ee;ue++)Me=Ke[ue],T.format!==An?Te!==null?H?ve&&t.compressedTexSubImage2D(i.TEXTURE_2D,ue,0,0,Me.width,Me.height,Te,Me.data):t.compressedTexImage2D(i.TEXTURE_2D,ue,Be,Me.width,Me.height,0,Me.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):H?ve&&t.texSubImage2D(i.TEXTURE_2D,ue,0,0,Me.width,Me.height,Te,We,Me.data):t.texImage2D(i.TEXTURE_2D,ue,Be,Me.width,Me.height,0,Te,We,Me.data)}else if(T.isDataArrayTexture)if(H){if(fe&&t.texStorage3D(i.TEXTURE_2D_ARRAY,Ce,Be,he.width,he.height,he.depth),ve)if(T.layerUpdates.size>0){const ue=cd(he.width,he.height,T.format,T.type);for(const ee of T.layerUpdates){const De=he.data.subarray(ee*ue/he.data.BYTES_PER_ELEMENT,(ee+1)*ue/he.data.BYTES_PER_ELEMENT);t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,ee,he.width,he.height,1,Te,We,De)}T.clearLayerUpdates()}else t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,0,he.width,he.height,he.depth,Te,We,he.data)}else t.texImage3D(i.TEXTURE_2D_ARRAY,0,Be,he.width,he.height,he.depth,0,Te,We,he.data);else if(T.isData3DTexture)H?(fe&&t.texStorage3D(i.TEXTURE_3D,Ce,Be,he.width,he.height,he.depth),ve&&t.texSubImage3D(i.TEXTURE_3D,0,0,0,0,he.width,he.height,he.depth,Te,We,he.data)):t.texImage3D(i.TEXTURE_3D,0,Be,he.width,he.height,he.depth,0,Te,We,he.data);else if(T.isFramebufferTexture){if(fe)if(H)t.texStorage2D(i.TEXTURE_2D,Ce,Be,he.width,he.height);else{let ue=he.width,ee=he.height;for(let De=0;De<Ce;De++)t.texImage2D(i.TEXTURE_2D,De,Be,ue,ee,0,Te,We,null),ue>>=1,ee>>=1}}else if(Ke.length>0){if(H&&fe){const ue=ke(Ke[0]);t.texStorage2D(i.TEXTURE_2D,Ce,Be,ue.width,ue.height)}for(let ue=0,ee=Ke.length;ue<ee;ue++)Me=Ke[ue],H?ve&&t.texSubImage2D(i.TEXTURE_2D,ue,0,0,Te,We,Me):t.texImage2D(i.TEXTURE_2D,ue,Be,Te,We,Me);T.generateMipmaps=!1}else if(H){if(fe){const ue=ke(he);t.texStorage2D(i.TEXTURE_2D,Ce,Be,ue.width,ue.height)}ve&&t.texSubImage2D(i.TEXTURE_2D,0,0,0,Te,We,he)}else t.texImage2D(i.TEXTURE_2D,0,Be,Te,We,he);m(T)&&f(J),xe.__version=$.version,T.onUpdate&&T.onUpdate(T)}P.__version=T.version}function Y(P,T,q){if(T.image.length!==6)return;const J=Q(P,T),te=T.source;t.bindTexture(i.TEXTURE_CUBE_MAP,P.__webglTexture,i.TEXTURE0+q);const $=n.get(te);if(te.version!==$.__version||J===!0){t.activeTexture(i.TEXTURE0+q);const xe=tt.getPrimaries(tt.workingColorSpace),oe=T.colorSpace===oi?null:tt.getPrimaries(T.colorSpace),Oe=T.colorSpace===oi||xe===oe?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,T.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,T.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,T.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,Oe);const Fe=T.isCompressedTexture||T.image[0].isCompressedTexture,he=T.image[0]&&T.image[0].isDataTexture,Te=[];for(let ee=0;ee<6;ee++)!Fe&&!he?Te[ee]=v(T.image[ee],!0,s.maxCubemapSize):Te[ee]=he?T.image[ee].image:T.image[ee],Te[ee]=He(T,Te[ee]);const We=Te[0],Be=r.convert(T.format,T.colorSpace),Me=r.convert(T.type),Ke=x(T.internalFormat,Be,Me,T.colorSpace),H=T.isVideoTexture!==!0,fe=$.__version===void 0||J===!0,ve=te.dataReady;let Ce=A(T,We);ne(i.TEXTURE_CUBE_MAP,T);let ue;if(Fe){H&&fe&&t.texStorage2D(i.TEXTURE_CUBE_MAP,Ce,Ke,We.width,We.height);for(let ee=0;ee<6;ee++){ue=Te[ee].mipmaps;for(let De=0;De<ue.length;De++){const je=ue[De];T.format!==An?Be!==null?H?ve&&t.compressedTexSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ee,De,0,0,je.width,je.height,Be,je.data):t.compressedTexImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ee,De,Ke,je.width,je.height,0,je.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):H?ve&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ee,De,0,0,je.width,je.height,Be,Me,je.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ee,De,Ke,je.width,je.height,0,Be,Me,je.data)}}}else{if(ue=T.mipmaps,H&&fe){ue.length>0&&Ce++;const ee=ke(Te[0]);t.texStorage2D(i.TEXTURE_CUBE_MAP,Ce,Ke,ee.width,ee.height)}for(let ee=0;ee<6;ee++)if(he){H?ve&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ee,0,0,0,Te[ee].width,Te[ee].height,Be,Me,Te[ee].data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ee,0,Ke,Te[ee].width,Te[ee].height,0,Be,Me,Te[ee].data);for(let De=0;De<ue.length;De++){const gt=ue[De].image[ee].image;H?ve&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ee,De+1,0,0,gt.width,gt.height,Be,Me,gt.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ee,De+1,Ke,gt.width,gt.height,0,Be,Me,gt.data)}}else{H?ve&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ee,0,0,0,Be,Me,Te[ee]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ee,0,Ke,Be,Me,Te[ee]);for(let De=0;De<ue.length;De++){const je=ue[De];H?ve&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ee,De+1,0,0,Be,Me,je.image[ee]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ee,De+1,Ke,Be,Me,je.image[ee])}}}m(T)&&f(i.TEXTURE_CUBE_MAP),$.__version=te.version,T.onUpdate&&T.onUpdate(T)}P.__version=T.version}function ie(P,T,q,J,te,$){const xe=r.convert(q.format,q.colorSpace),oe=r.convert(q.type),Oe=x(q.internalFormat,xe,oe,q.colorSpace),Fe=n.get(T),he=n.get(q);if(he.__renderTarget=T,!Fe.__hasExternalTextures){const Te=Math.max(1,T.width>>$),We=Math.max(1,T.height>>$);te===i.TEXTURE_3D||te===i.TEXTURE_2D_ARRAY?t.texImage3D(te,$,Oe,Te,We,T.depth,0,xe,oe,null):t.texImage2D(te,$,Oe,Te,We,0,xe,oe,null)}t.bindFramebuffer(i.FRAMEBUFFER,P),pe(T)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,J,te,he.__webglTexture,0,Ne(T)):(te===i.TEXTURE_2D||te>=i.TEXTURE_CUBE_MAP_POSITIVE_X&&te<=i.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&i.framebufferTexture2D(i.FRAMEBUFFER,J,te,he.__webglTexture,$),t.bindFramebuffer(i.FRAMEBUFFER,null)}function ye(P,T,q){if(i.bindRenderbuffer(i.RENDERBUFFER,P),T.depthBuffer){const J=T.depthTexture,te=J&&J.isDepthTexture?J.type:null,$=y(T.stencilBuffer,te),xe=T.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,oe=Ne(T);pe(T)?o.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,oe,$,T.width,T.height):q?i.renderbufferStorageMultisample(i.RENDERBUFFER,oe,$,T.width,T.height):i.renderbufferStorage(i.RENDERBUFFER,$,T.width,T.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,xe,i.RENDERBUFFER,P)}else{const J=T.textures;for(let te=0;te<J.length;te++){const $=J[te],xe=r.convert($.format,$.colorSpace),oe=r.convert($.type),Oe=x($.internalFormat,xe,oe,$.colorSpace),Fe=Ne(T);q&&pe(T)===!1?i.renderbufferStorageMultisample(i.RENDERBUFFER,Fe,Oe,T.width,T.height):pe(T)?o.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,Fe,Oe,T.width,T.height):i.renderbufferStorage(i.RENDERBUFFER,Oe,T.width,T.height)}}i.bindRenderbuffer(i.RENDERBUFFER,null)}function se(P,T){if(T&&T.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(t.bindFramebuffer(i.FRAMEBUFFER,P),!(T.depthTexture&&T.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const J=n.get(T.depthTexture);J.__renderTarget=T,(!J.__webglTexture||T.depthTexture.image.width!==T.width||T.depthTexture.image.height!==T.height)&&(T.depthTexture.image.width=T.width,T.depthTexture.image.height=T.height,T.depthTexture.needsUpdate=!0),O(T.depthTexture,0);const te=J.__webglTexture,$=Ne(T);if(T.depthTexture.format===Rr)pe(T)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,te,0,$):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,te,0);else if(T.depthTexture.format===Cr)pe(T)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,te,0,$):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,te,0);else throw new Error("Unknown depthTexture format")}function Le(P){const T=n.get(P),q=P.isWebGLCubeRenderTarget===!0;if(T.__boundDepthTexture!==P.depthTexture){const J=P.depthTexture;if(T.__depthDisposeCallback&&T.__depthDisposeCallback(),J){const te=()=>{delete T.__boundDepthTexture,delete T.__depthDisposeCallback,J.removeEventListener("dispose",te)};J.addEventListener("dispose",te),T.__depthDisposeCallback=te}T.__boundDepthTexture=J}if(P.depthTexture&&!T.__autoAllocateDepthBuffer){if(q)throw new Error("target.depthTexture not supported in Cube render targets");const J=P.texture.mipmaps;J&&J.length>0?se(T.__webglFramebuffer[0],P):se(T.__webglFramebuffer,P)}else if(q){T.__webglDepthbuffer=[];for(let J=0;J<6;J++)if(t.bindFramebuffer(i.FRAMEBUFFER,T.__webglFramebuffer[J]),T.__webglDepthbuffer[J]===void 0)T.__webglDepthbuffer[J]=i.createRenderbuffer(),ye(T.__webglDepthbuffer[J],P,!1);else{const te=P.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,$=T.__webglDepthbuffer[J];i.bindRenderbuffer(i.RENDERBUFFER,$),i.framebufferRenderbuffer(i.FRAMEBUFFER,te,i.RENDERBUFFER,$)}}else{const J=P.texture.mipmaps;if(J&&J.length>0?t.bindFramebuffer(i.FRAMEBUFFER,T.__webglFramebuffer[0]):t.bindFramebuffer(i.FRAMEBUFFER,T.__webglFramebuffer),T.__webglDepthbuffer===void 0)T.__webglDepthbuffer=i.createRenderbuffer(),ye(T.__webglDepthbuffer,P,!1);else{const te=P.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,$=T.__webglDepthbuffer;i.bindRenderbuffer(i.RENDERBUFFER,$),i.framebufferRenderbuffer(i.FRAMEBUFFER,te,i.RENDERBUFFER,$)}}t.bindFramebuffer(i.FRAMEBUFFER,null)}function be(P,T,q){const J=n.get(P);T!==void 0&&ie(J.__webglFramebuffer,P,P.texture,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,0),q!==void 0&&Le(P)}function L(P){const T=P.texture,q=n.get(P),J=n.get(T);P.addEventListener("dispose",M);const te=P.textures,$=P.isWebGLCubeRenderTarget===!0,xe=te.length>1;if(xe||(J.__webglTexture===void 0&&(J.__webglTexture=i.createTexture()),J.__version=T.version,a.memory.textures++),$){q.__webglFramebuffer=[];for(let oe=0;oe<6;oe++)if(T.mipmaps&&T.mipmaps.length>0){q.__webglFramebuffer[oe]=[];for(let Oe=0;Oe<T.mipmaps.length;Oe++)q.__webglFramebuffer[oe][Oe]=i.createFramebuffer()}else q.__webglFramebuffer[oe]=i.createFramebuffer()}else{if(T.mipmaps&&T.mipmaps.length>0){q.__webglFramebuffer=[];for(let oe=0;oe<T.mipmaps.length;oe++)q.__webglFramebuffer[oe]=i.createFramebuffer()}else q.__webglFramebuffer=i.createFramebuffer();if(xe)for(let oe=0,Oe=te.length;oe<Oe;oe++){const Fe=n.get(te[oe]);Fe.__webglTexture===void 0&&(Fe.__webglTexture=i.createTexture(),a.memory.textures++)}if(P.samples>0&&pe(P)===!1){q.__webglMultisampledFramebuffer=i.createFramebuffer(),q.__webglColorRenderbuffer=[],t.bindFramebuffer(i.FRAMEBUFFER,q.__webglMultisampledFramebuffer);for(let oe=0;oe<te.length;oe++){const Oe=te[oe];q.__webglColorRenderbuffer[oe]=i.createRenderbuffer(),i.bindRenderbuffer(i.RENDERBUFFER,q.__webglColorRenderbuffer[oe]);const Fe=r.convert(Oe.format,Oe.colorSpace),he=r.convert(Oe.type),Te=x(Oe.internalFormat,Fe,he,Oe.colorSpace,P.isXRRenderTarget===!0),We=Ne(P);i.renderbufferStorageMultisample(i.RENDERBUFFER,We,Te,P.width,P.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+oe,i.RENDERBUFFER,q.__webglColorRenderbuffer[oe])}i.bindRenderbuffer(i.RENDERBUFFER,null),P.depthBuffer&&(q.__webglDepthRenderbuffer=i.createRenderbuffer(),ye(q.__webglDepthRenderbuffer,P,!0)),t.bindFramebuffer(i.FRAMEBUFFER,null)}}if($){t.bindTexture(i.TEXTURE_CUBE_MAP,J.__webglTexture),ne(i.TEXTURE_CUBE_MAP,T);for(let oe=0;oe<6;oe++)if(T.mipmaps&&T.mipmaps.length>0)for(let Oe=0;Oe<T.mipmaps.length;Oe++)ie(q.__webglFramebuffer[oe][Oe],P,T,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+oe,Oe);else ie(q.__webglFramebuffer[oe],P,T,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+oe,0);m(T)&&f(i.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(xe){for(let oe=0,Oe=te.length;oe<Oe;oe++){const Fe=te[oe],he=n.get(Fe);let Te=i.TEXTURE_2D;(P.isWebGL3DRenderTarget||P.isWebGLArrayRenderTarget)&&(Te=P.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),t.bindTexture(Te,he.__webglTexture),ne(Te,Fe),ie(q.__webglFramebuffer,P,Fe,i.COLOR_ATTACHMENT0+oe,Te,0),m(Fe)&&f(Te)}t.unbindTexture()}else{let oe=i.TEXTURE_2D;if((P.isWebGL3DRenderTarget||P.isWebGLArrayRenderTarget)&&(oe=P.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),t.bindTexture(oe,J.__webglTexture),ne(oe,T),T.mipmaps&&T.mipmaps.length>0)for(let Oe=0;Oe<T.mipmaps.length;Oe++)ie(q.__webglFramebuffer[Oe],P,T,i.COLOR_ATTACHMENT0,oe,Oe);else ie(q.__webglFramebuffer,P,T,i.COLOR_ATTACHMENT0,oe,0);m(T)&&f(oe),t.unbindTexture()}P.depthBuffer&&Le(P)}function Ue(P){const T=P.textures;for(let q=0,J=T.length;q<J;q++){const te=T[q];if(m(te)){const $=_(P),xe=n.get(te).__webglTexture;t.bindTexture($,xe),f($),t.unbindTexture()}}}const me=[],ae=[];function le(P){if(P.samples>0){if(pe(P)===!1){const T=P.textures,q=P.width,J=P.height;let te=i.COLOR_BUFFER_BIT;const $=P.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,xe=n.get(P),oe=T.length>1;if(oe)for(let Fe=0;Fe<T.length;Fe++)t.bindFramebuffer(i.FRAMEBUFFER,xe.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Fe,i.RENDERBUFFER,null),t.bindFramebuffer(i.FRAMEBUFFER,xe.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Fe,i.TEXTURE_2D,null,0);t.bindFramebuffer(i.READ_FRAMEBUFFER,xe.__webglMultisampledFramebuffer);const Oe=P.texture.mipmaps;Oe&&Oe.length>0?t.bindFramebuffer(i.DRAW_FRAMEBUFFER,xe.__webglFramebuffer[0]):t.bindFramebuffer(i.DRAW_FRAMEBUFFER,xe.__webglFramebuffer);for(let Fe=0;Fe<T.length;Fe++){if(P.resolveDepthBuffer&&(P.depthBuffer&&(te|=i.DEPTH_BUFFER_BIT),P.stencilBuffer&&P.resolveStencilBuffer&&(te|=i.STENCIL_BUFFER_BIT)),oe){i.framebufferRenderbuffer(i.READ_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.RENDERBUFFER,xe.__webglColorRenderbuffer[Fe]);const he=n.get(T[Fe]).__webglTexture;i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,he,0)}i.blitFramebuffer(0,0,q,J,0,0,q,J,te,i.NEAREST),c===!0&&(me.length=0,ae.length=0,me.push(i.COLOR_ATTACHMENT0+Fe),P.depthBuffer&&P.resolveDepthBuffer===!1&&(me.push($),ae.push($),i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,ae)),i.invalidateFramebuffer(i.READ_FRAMEBUFFER,me))}if(t.bindFramebuffer(i.READ_FRAMEBUFFER,null),t.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),oe)for(let Fe=0;Fe<T.length;Fe++){t.bindFramebuffer(i.FRAMEBUFFER,xe.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Fe,i.RENDERBUFFER,xe.__webglColorRenderbuffer[Fe]);const he=n.get(T[Fe]).__webglTexture;t.bindFramebuffer(i.FRAMEBUFFER,xe.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Fe,i.TEXTURE_2D,he,0)}t.bindFramebuffer(i.DRAW_FRAMEBUFFER,xe.__webglMultisampledFramebuffer)}else if(P.depthBuffer&&P.resolveDepthBuffer===!1&&c){const T=P.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,[T])}}}function Ne(P){return Math.min(s.maxSamples,P.samples)}function pe(P){const T=n.get(P);return P.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&T.__useRenderToTexture!==!1}function Ae(P){const T=a.render.frame;u.get(P)!==T&&(u.set(P,T),P.update())}function He(P,T){const q=P.colorSpace,J=P.format,te=P.type;return P.isCompressedTexture===!0||P.isVideoTexture===!0||q!==Qt&&q!==oi&&(tt.getTransfer(q)===ft?(J!==An||te!==qn)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",q)),T}function ke(P){return typeof HTMLImageElement<"u"&&P instanceof HTMLImageElement?(l.width=P.naturalWidth||P.width,l.height=P.naturalHeight||P.height):typeof VideoFrame<"u"&&P instanceof VideoFrame?(l.width=P.displayWidth,l.height=P.displayHeight):(l.width=P.width,l.height=P.height),l}this.allocateTextureUnit=w,this.resetTextureUnits=D,this.setTexture2D=O,this.setTexture2DArray=F,this.setTexture3D=V,this.setTextureCube=k,this.rebindTextures=be,this.setupRenderTarget=L,this.updateRenderTargetMipmap=Ue,this.updateMultisampleRenderTarget=le,this.setupDepthRenderbuffer=Le,this.setupFrameBufferTexture=ie,this.useMultisampledRTT=pe}function Jx(i,e){function t(n,s=oi){let r;const a=tt.getTransfer(s);if(n===qn)return i.UNSIGNED_BYTE;if(n===Cc)return i.UNSIGNED_SHORT_4_4_4_4;if(n===Ic)return i.UNSIGNED_SHORT_5_5_5_1;if(n===kh)return i.UNSIGNED_INT_5_9_9_9_REV;if(n===zh)return i.UNSIGNED_INT_10F_11F_11F_REV;if(n===Fh)return i.BYTE;if(n===Bh)return i.SHORT;if(n===Ar)return i.UNSIGNED_SHORT;if(n===Rc)return i.INT;if(n===Ki)return i.UNSIGNED_INT;if(n===Fn)return i.FLOAT;if(n===di)return i.HALF_FLOAT;if(n===Vh)return i.ALPHA;if(n===Hh)return i.RGB;if(n===An)return i.RGBA;if(n===Rr)return i.DEPTH_COMPONENT;if(n===Cr)return i.DEPTH_STENCIL;if(n===Pc)return i.RED;if(n===Lc)return i.RED_INTEGER;if(n===Gh)return i.RG;if(n===Dc)return i.RG_INTEGER;if(n===Nc)return i.RGBA_INTEGER;if(n===Oa||n===Ua||n===Fa||n===Ba)if(a===ft)if(r=e.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(n===Oa)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===Ua)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===Fa)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===Ba)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=e.get("WEBGL_compressed_texture_s3tc"),r!==null){if(n===Oa)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===Ua)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===Fa)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===Ba)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===Nl||n===Ol||n===Ul||n===Fl)if(r=e.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(n===Nl)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===Ol)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===Ul)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===Fl)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===Bl||n===kl||n===zl)if(r=e.get("WEBGL_compressed_texture_etc"),r!==null){if(n===Bl||n===kl)return a===ft?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(n===zl)return a===ft?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(n===Vl||n===Hl||n===Gl||n===Wl||n===Xl||n===ql||n===Yl||n===jl||n===$l||n===Kl||n===Zl||n===Jl||n===Ql||n===ec)if(r=e.get("WEBGL_compressed_texture_astc"),r!==null){if(n===Vl)return a===ft?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===Hl)return a===ft?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===Gl)return a===ft?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===Wl)return a===ft?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===Xl)return a===ft?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===ql)return a===ft?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===Yl)return a===ft?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===jl)return a===ft?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===$l)return a===ft?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===Kl)return a===ft?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===Zl)return a===ft?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===Jl)return a===ft?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===Ql)return a===ft?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===ec)return a===ft?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===tc||n===nc||n===ic)if(r=e.get("EXT_texture_compression_bptc"),r!==null){if(n===tc)return a===ft?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===nc)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===ic)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===sc||n===rc||n===ac||n===oc)if(r=e.get("EXT_texture_compression_rgtc"),r!==null){if(n===sc)return r.COMPRESSED_RED_RGTC1_EXT;if(n===rc)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===ac)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===oc)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===wr?i.UNSIGNED_INT_24_8:i[n]!==void 0?i[n]:null}return{convert:t}}const Qx=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,ey=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class ty{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t){if(this.texture===null){const n=new lf(e.texture);(e.depthNear!==t.depthNear||e.depthFar!==t.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=n}}getMesh(e){if(this.texture!==null&&this.mesh===null){const t=e.cameras[0].viewport,n=new Rt({vertexShader:Qx,fragmentShader:ey,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new pt(new _n(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class ny extends $s{constructor(e,t){super();const n=this;let s=null,r=1,a=null,o="local-floor",c=1,l=null,u=null,d=null,h=null,p=null,g=null;const v=typeof XRWebGLBinding<"u",m=new ty,f={},_=t.getContextAttributes();let x=null,y=null;const A=[],E=[],M=new Ie;let C=null;const b=new Kt;b.viewport=new st;const S=new Kt;S.viewport=new st;const I=[b,S],D=new hg;let w=null,U=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(G){let Y=A[G];return Y===void 0&&(Y=new jo,A[G]=Y),Y.getTargetRaySpace()},this.getControllerGrip=function(G){let Y=A[G];return Y===void 0&&(Y=new jo,A[G]=Y),Y.getGripSpace()},this.getHand=function(G){let Y=A[G];return Y===void 0&&(Y=new jo,A[G]=Y),Y.getHandSpace()};function O(G){const Y=E.indexOf(G.inputSource);if(Y===-1)return;const ie=A[Y];ie!==void 0&&(ie.update(G.inputSource,G.frame,l||a),ie.dispatchEvent({type:G.type,data:G.inputSource}))}function F(){s.removeEventListener("select",O),s.removeEventListener("selectstart",O),s.removeEventListener("selectend",O),s.removeEventListener("squeeze",O),s.removeEventListener("squeezestart",O),s.removeEventListener("squeezeend",O),s.removeEventListener("end",F),s.removeEventListener("inputsourceschange",V);for(let G=0;G<A.length;G++){const Y=E[G];Y!==null&&(E[G]=null,A[G].disconnect(Y))}w=null,U=null,m.reset();for(const G in f)delete f[G];e.setRenderTarget(x),p=null,h=null,d=null,s=null,y=null,ce.stop(),n.isPresenting=!1,e.setPixelRatio(C),e.setSize(M.width,M.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(G){r=G,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(G){o=G,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return l||a},this.setReferenceSpace=function(G){l=G},this.getBaseLayer=function(){return h!==null?h:p},this.getBinding=function(){return d===null&&v&&(d=new XRWebGLBinding(s,t)),d},this.getFrame=function(){return g},this.getSession=function(){return s},this.setSession=async function(G){if(s=G,s!==null){if(x=e.getRenderTarget(),s.addEventListener("select",O),s.addEventListener("selectstart",O),s.addEventListener("selectend",O),s.addEventListener("squeeze",O),s.addEventListener("squeezestart",O),s.addEventListener("squeezeend",O),s.addEventListener("end",F),s.addEventListener("inputsourceschange",V),_.xrCompatible!==!0&&await t.makeXRCompatible(),C=e.getPixelRatio(),e.getSize(M),v&&"createProjectionLayer"in XRWebGLBinding.prototype){let ie=null,ye=null,se=null;_.depth&&(se=_.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,ie=_.stencil?Cr:Rr,ye=_.stencil?wr:Ki);const Le={colorFormat:t.RGBA8,depthFormat:se,scaleFactor:r};d=this.getBinding(),h=d.createProjectionLayer(Le),s.updateRenderState({layers:[h]}),e.setPixelRatio(1),e.setSize(h.textureWidth,h.textureHeight,!1),y=new kn(h.textureWidth,h.textureHeight,{format:An,type:qn,depthTexture:new of(h.textureWidth,h.textureHeight,ye,void 0,void 0,void 0,void 0,void 0,void 0,ie),stencilBuffer:_.stencil,colorSpace:e.outputColorSpace,samples:_.antialias?4:0,resolveDepthBuffer:h.ignoreDepthValues===!1,resolveStencilBuffer:h.ignoreDepthValues===!1})}else{const ie={antialias:_.antialias,alpha:!0,depth:_.depth,stencil:_.stencil,framebufferScaleFactor:r};p=new XRWebGLLayer(s,t,ie),s.updateRenderState({baseLayer:p}),e.setPixelRatio(1),e.setSize(p.framebufferWidth,p.framebufferHeight,!1),y=new kn(p.framebufferWidth,p.framebufferHeight,{format:An,type:qn,colorSpace:e.outputColorSpace,stencilBuffer:_.stencil,resolveDepthBuffer:p.ignoreDepthValues===!1,resolveStencilBuffer:p.ignoreDepthValues===!1})}y.isXRRenderTarget=!0,this.setFoveation(c),l=null,a=await s.requestReferenceSpace(o),ce.setContext(s),ce.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode},this.getDepthTexture=function(){return m.getDepthTexture()};function V(G){for(let Y=0;Y<G.removed.length;Y++){const ie=G.removed[Y],ye=E.indexOf(ie);ye>=0&&(E[ye]=null,A[ye].disconnect(ie))}for(let Y=0;Y<G.added.length;Y++){const ie=G.added[Y];let ye=E.indexOf(ie);if(ye===-1){for(let Le=0;Le<A.length;Le++)if(Le>=E.length){E.push(ie),ye=Le;break}else if(E[Le]===null){E[Le]=ie,ye=Le;break}if(ye===-1)break}const se=A[ye];se&&se.connect(ie)}}const k=new N,z=new N;function B(G,Y,ie){k.setFromMatrixPosition(Y.matrixWorld),z.setFromMatrixPosition(ie.matrixWorld);const ye=k.distanceTo(z),se=Y.projectionMatrix.elements,Le=ie.projectionMatrix.elements,be=se[14]/(se[10]-1),L=se[14]/(se[10]+1),Ue=(se[9]+1)/se[5],me=(se[9]-1)/se[5],ae=(se[8]-1)/se[0],le=(Le[8]+1)/Le[0],Ne=be*ae,pe=be*le,Ae=ye/(-ae+le),He=Ae*-ae;if(Y.matrixWorld.decompose(G.position,G.quaternion,G.scale),G.translateX(He),G.translateZ(Ae),G.matrixWorld.compose(G.position,G.quaternion,G.scale),G.matrixWorldInverse.copy(G.matrixWorld).invert(),se[10]===-1)G.projectionMatrix.copy(Y.projectionMatrix),G.projectionMatrixInverse.copy(Y.projectionMatrixInverse);else{const ke=be+Ae,P=L+Ae,T=Ne-He,q=pe+(ye-He),J=Ue*L/P*ke,te=me*L/P*ke;G.projectionMatrix.makePerspective(T,q,J,te,ke,P),G.projectionMatrixInverse.copy(G.projectionMatrix).invert()}}function j(G,Y){Y===null?G.matrixWorld.copy(G.matrix):G.matrixWorld.multiplyMatrices(Y.matrixWorld,G.matrix),G.matrixWorldInverse.copy(G.matrixWorld).invert()}this.updateCamera=function(G){if(s===null)return;let Y=G.near,ie=G.far;m.texture!==null&&(m.depthNear>0&&(Y=m.depthNear),m.depthFar>0&&(ie=m.depthFar)),D.near=S.near=b.near=Y,D.far=S.far=b.far=ie,(w!==D.near||U!==D.far)&&(s.updateRenderState({depthNear:D.near,depthFar:D.far}),w=D.near,U=D.far),D.layers.mask=G.layers.mask|6,b.layers.mask=D.layers.mask&3,S.layers.mask=D.layers.mask&5;const ye=G.parent,se=D.cameras;j(D,ye);for(let Le=0;Le<se.length;Le++)j(se[Le],ye);se.length===2?B(D,b,S):D.projectionMatrix.copy(b.projectionMatrix),ne(G,D,ye)};function ne(G,Y,ie){ie===null?G.matrix.copy(Y.matrixWorld):(G.matrix.copy(ie.matrixWorld),G.matrix.invert(),G.matrix.multiply(Y.matrixWorld)),G.matrix.decompose(G.position,G.quaternion,G.scale),G.updateMatrixWorld(!0),G.projectionMatrix.copy(Y.projectionMatrix),G.projectionMatrixInverse.copy(Y.projectionMatrixInverse),G.isPerspectiveCamera&&(G.fov=ks*2*Math.atan(1/G.projectionMatrix.elements[5]),G.zoom=1)}this.getCamera=function(){return D},this.getFoveation=function(){if(!(h===null&&p===null))return c},this.setFoveation=function(G){c=G,h!==null&&(h.fixedFoveation=G),p!==null&&p.fixedFoveation!==void 0&&(p.fixedFoveation=G)},this.hasDepthSensing=function(){return m.texture!==null},this.getDepthSensingMesh=function(){return m.getMesh(D)},this.getCameraTexture=function(G){return f[G]};let Q=null;function re(G,Y){if(u=Y.getViewerPose(l||a),g=Y,u!==null){const ie=u.views;p!==null&&(e.setRenderTargetFramebuffer(y,p.framebuffer),e.setRenderTarget(y));let ye=!1;ie.length!==D.cameras.length&&(D.cameras.length=0,ye=!0);for(let L=0;L<ie.length;L++){const Ue=ie[L];let me=null;if(p!==null)me=p.getViewport(Ue);else{const le=d.getViewSubImage(h,Ue);me=le.viewport,L===0&&(e.setRenderTargetTextures(y,le.colorTexture,le.depthStencilTexture),e.setRenderTarget(y))}let ae=I[L];ae===void 0&&(ae=new Kt,ae.layers.enable(L),ae.viewport=new st,I[L]=ae),ae.matrix.fromArray(Ue.transform.matrix),ae.matrix.decompose(ae.position,ae.quaternion,ae.scale),ae.projectionMatrix.fromArray(Ue.projectionMatrix),ae.projectionMatrixInverse.copy(ae.projectionMatrix).invert(),ae.viewport.set(me.x,me.y,me.width,me.height),L===0&&(D.matrix.copy(ae.matrix),D.matrix.decompose(D.position,D.quaternion,D.scale)),ye===!0&&D.cameras.push(ae)}const se=s.enabledFeatures;if(se&&se.includes("depth-sensing")&&s.depthUsage=="gpu-optimized"&&v){d=n.getBinding();const L=d.getDepthInformation(ie[0]);L&&L.isValid&&L.texture&&m.init(L,s.renderState)}if(se&&se.includes("camera-access")&&v){e.state.unbindTexture(),d=n.getBinding();for(let L=0;L<ie.length;L++){const Ue=ie[L].camera;if(Ue){let me=f[Ue];me||(me=new lf,f[Ue]=me);const ae=d.getCameraImage(Ue);me.sourceTexture=ae}}}}for(let ie=0;ie<A.length;ie++){const ye=E[ie],se=A[ie];ye!==null&&se!==void 0&&se.update(ye,Y,l||a)}Q&&Q(G,Y),Y.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:Y}),g=null}const ce=new ff;ce.setAnimationLoop(re),this.setAnimationLoop=function(G){Q=G},this.dispose=function(){}}}const Hi=new vn,iy=new Ye;function sy(i,e){function t(m,f){m.matrixAutoUpdate===!0&&m.updateMatrix(),f.value.copy(m.matrix)}function n(m,f){f.color.getRGB(m.fogColor.value,Zh(i)),f.isFog?(m.fogNear.value=f.near,m.fogFar.value=f.far):f.isFogExp2&&(m.fogDensity.value=f.density)}function s(m,f,_,x,y){f.isMeshBasicMaterial||f.isMeshLambertMaterial?r(m,f):f.isMeshToonMaterial?(r(m,f),d(m,f)):f.isMeshPhongMaterial?(r(m,f),u(m,f)):f.isMeshStandardMaterial?(r(m,f),h(m,f),f.isMeshPhysicalMaterial&&p(m,f,y)):f.isMeshMatcapMaterial?(r(m,f),g(m,f)):f.isMeshDepthMaterial?r(m,f):f.isMeshDistanceMaterial?(r(m,f),v(m,f)):f.isMeshNormalMaterial?r(m,f):f.isLineBasicMaterial?(a(m,f),f.isLineDashedMaterial&&o(m,f)):f.isPointsMaterial?c(m,f,_,x):f.isSpriteMaterial?l(m,f):f.isShadowMaterial?(m.color.value.copy(f.color),m.opacity.value=f.opacity):f.isShaderMaterial&&(f.uniformsNeedUpdate=!1)}function r(m,f){m.opacity.value=f.opacity,f.color&&m.diffuse.value.copy(f.color),f.emissive&&m.emissive.value.copy(f.emissive).multiplyScalar(f.emissiveIntensity),f.map&&(m.map.value=f.map,t(f.map,m.mapTransform)),f.alphaMap&&(m.alphaMap.value=f.alphaMap,t(f.alphaMap,m.alphaMapTransform)),f.bumpMap&&(m.bumpMap.value=f.bumpMap,t(f.bumpMap,m.bumpMapTransform),m.bumpScale.value=f.bumpScale,f.side===an&&(m.bumpScale.value*=-1)),f.normalMap&&(m.normalMap.value=f.normalMap,t(f.normalMap,m.normalMapTransform),m.normalScale.value.copy(f.normalScale),f.side===an&&m.normalScale.value.negate()),f.displacementMap&&(m.displacementMap.value=f.displacementMap,t(f.displacementMap,m.displacementMapTransform),m.displacementScale.value=f.displacementScale,m.displacementBias.value=f.displacementBias),f.emissiveMap&&(m.emissiveMap.value=f.emissiveMap,t(f.emissiveMap,m.emissiveMapTransform)),f.specularMap&&(m.specularMap.value=f.specularMap,t(f.specularMap,m.specularMapTransform)),f.alphaTest>0&&(m.alphaTest.value=f.alphaTest);const _=e.get(f),x=_.envMap,y=_.envMapRotation;x&&(m.envMap.value=x,Hi.copy(y),Hi.x*=-1,Hi.y*=-1,Hi.z*=-1,x.isCubeTexture&&x.isRenderTargetTexture===!1&&(Hi.y*=-1,Hi.z*=-1),m.envMapRotation.value.setFromMatrix4(iy.makeRotationFromEuler(Hi)),m.flipEnvMap.value=x.isCubeTexture&&x.isRenderTargetTexture===!1?-1:1,m.reflectivity.value=f.reflectivity,m.ior.value=f.ior,m.refractionRatio.value=f.refractionRatio),f.lightMap&&(m.lightMap.value=f.lightMap,m.lightMapIntensity.value=f.lightMapIntensity,t(f.lightMap,m.lightMapTransform)),f.aoMap&&(m.aoMap.value=f.aoMap,m.aoMapIntensity.value=f.aoMapIntensity,t(f.aoMap,m.aoMapTransform))}function a(m,f){m.diffuse.value.copy(f.color),m.opacity.value=f.opacity,f.map&&(m.map.value=f.map,t(f.map,m.mapTransform))}function o(m,f){m.dashSize.value=f.dashSize,m.totalSize.value=f.dashSize+f.gapSize,m.scale.value=f.scale}function c(m,f,_,x){m.diffuse.value.copy(f.color),m.opacity.value=f.opacity,m.size.value=f.size*_,m.scale.value=x*.5,f.map&&(m.map.value=f.map,t(f.map,m.uvTransform)),f.alphaMap&&(m.alphaMap.value=f.alphaMap,t(f.alphaMap,m.alphaMapTransform)),f.alphaTest>0&&(m.alphaTest.value=f.alphaTest)}function l(m,f){m.diffuse.value.copy(f.color),m.opacity.value=f.opacity,m.rotation.value=f.rotation,f.map&&(m.map.value=f.map,t(f.map,m.mapTransform)),f.alphaMap&&(m.alphaMap.value=f.alphaMap,t(f.alphaMap,m.alphaMapTransform)),f.alphaTest>0&&(m.alphaTest.value=f.alphaTest)}function u(m,f){m.specular.value.copy(f.specular),m.shininess.value=Math.max(f.shininess,1e-4)}function d(m,f){f.gradientMap&&(m.gradientMap.value=f.gradientMap)}function h(m,f){m.metalness.value=f.metalness,f.metalnessMap&&(m.metalnessMap.value=f.metalnessMap,t(f.metalnessMap,m.metalnessMapTransform)),m.roughness.value=f.roughness,f.roughnessMap&&(m.roughnessMap.value=f.roughnessMap,t(f.roughnessMap,m.roughnessMapTransform)),f.envMap&&(m.envMapIntensity.value=f.envMapIntensity)}function p(m,f,_){m.ior.value=f.ior,f.sheen>0&&(m.sheenColor.value.copy(f.sheenColor).multiplyScalar(f.sheen),m.sheenRoughness.value=f.sheenRoughness,f.sheenColorMap&&(m.sheenColorMap.value=f.sheenColorMap,t(f.sheenColorMap,m.sheenColorMapTransform)),f.sheenRoughnessMap&&(m.sheenRoughnessMap.value=f.sheenRoughnessMap,t(f.sheenRoughnessMap,m.sheenRoughnessMapTransform))),f.clearcoat>0&&(m.clearcoat.value=f.clearcoat,m.clearcoatRoughness.value=f.clearcoatRoughness,f.clearcoatMap&&(m.clearcoatMap.value=f.clearcoatMap,t(f.clearcoatMap,m.clearcoatMapTransform)),f.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=f.clearcoatRoughnessMap,t(f.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),f.clearcoatNormalMap&&(m.clearcoatNormalMap.value=f.clearcoatNormalMap,t(f.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(f.clearcoatNormalScale),f.side===an&&m.clearcoatNormalScale.value.negate())),f.dispersion>0&&(m.dispersion.value=f.dispersion),f.iridescence>0&&(m.iridescence.value=f.iridescence,m.iridescenceIOR.value=f.iridescenceIOR,m.iridescenceThicknessMinimum.value=f.iridescenceThicknessRange[0],m.iridescenceThicknessMaximum.value=f.iridescenceThicknessRange[1],f.iridescenceMap&&(m.iridescenceMap.value=f.iridescenceMap,t(f.iridescenceMap,m.iridescenceMapTransform)),f.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=f.iridescenceThicknessMap,t(f.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),f.transmission>0&&(m.transmission.value=f.transmission,m.transmissionSamplerMap.value=_.texture,m.transmissionSamplerSize.value.set(_.width,_.height),f.transmissionMap&&(m.transmissionMap.value=f.transmissionMap,t(f.transmissionMap,m.transmissionMapTransform)),m.thickness.value=f.thickness,f.thicknessMap&&(m.thicknessMap.value=f.thicknessMap,t(f.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=f.attenuationDistance,m.attenuationColor.value.copy(f.attenuationColor)),f.anisotropy>0&&(m.anisotropyVector.value.set(f.anisotropy*Math.cos(f.anisotropyRotation),f.anisotropy*Math.sin(f.anisotropyRotation)),f.anisotropyMap&&(m.anisotropyMap.value=f.anisotropyMap,t(f.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=f.specularIntensity,m.specularColor.value.copy(f.specularColor),f.specularColorMap&&(m.specularColorMap.value=f.specularColorMap,t(f.specularColorMap,m.specularColorMapTransform)),f.specularIntensityMap&&(m.specularIntensityMap.value=f.specularIntensityMap,t(f.specularIntensityMap,m.specularIntensityMapTransform))}function g(m,f){f.matcap&&(m.matcap.value=f.matcap)}function v(m,f){const _=e.get(f).light;m.referencePosition.value.setFromMatrixPosition(_.matrixWorld),m.nearDistance.value=_.shadow.camera.near,m.farDistance.value=_.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:s}}function ry(i,e,t,n){let s={},r={},a=[];const o=i.getParameter(i.MAX_UNIFORM_BUFFER_BINDINGS);function c(_,x){const y=x.program;n.uniformBlockBinding(_,y)}function l(_,x){let y=s[_.id];y===void 0&&(g(_),y=u(_),s[_.id]=y,_.addEventListener("dispose",m));const A=x.program;n.updateUBOMapping(_,A);const E=e.render.frame;r[_.id]!==E&&(h(_),r[_.id]=E)}function u(_){const x=d();_.__bindingPointIndex=x;const y=i.createBuffer(),A=_.__size,E=_.usage;return i.bindBuffer(i.UNIFORM_BUFFER,y),i.bufferData(i.UNIFORM_BUFFER,A,E),i.bindBuffer(i.UNIFORM_BUFFER,null),i.bindBufferBase(i.UNIFORM_BUFFER,x,y),y}function d(){for(let _=0;_<o;_++)if(a.indexOf(_)===-1)return a.push(_),_;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function h(_){const x=s[_.id],y=_.uniforms,A=_.__cache;i.bindBuffer(i.UNIFORM_BUFFER,x);for(let E=0,M=y.length;E<M;E++){const C=Array.isArray(y[E])?y[E]:[y[E]];for(let b=0,S=C.length;b<S;b++){const I=C[b];if(p(I,E,b,A)===!0){const D=I.__offset,w=Array.isArray(I.value)?I.value:[I.value];let U=0;for(let O=0;O<w.length;O++){const F=w[O],V=v(F);typeof F=="number"||typeof F=="boolean"?(I.__data[0]=F,i.bufferSubData(i.UNIFORM_BUFFER,D+U,I.__data)):F.isMatrix3?(I.__data[0]=F.elements[0],I.__data[1]=F.elements[1],I.__data[2]=F.elements[2],I.__data[3]=0,I.__data[4]=F.elements[3],I.__data[5]=F.elements[4],I.__data[6]=F.elements[5],I.__data[7]=0,I.__data[8]=F.elements[6],I.__data[9]=F.elements[7],I.__data[10]=F.elements[8],I.__data[11]=0):(F.toArray(I.__data,U),U+=V.storage/Float32Array.BYTES_PER_ELEMENT)}i.bufferSubData(i.UNIFORM_BUFFER,D,I.__data)}}}i.bindBuffer(i.UNIFORM_BUFFER,null)}function p(_,x,y,A){const E=_.value,M=x+"_"+y;if(A[M]===void 0)return typeof E=="number"||typeof E=="boolean"?A[M]=E:A[M]=E.clone(),!0;{const C=A[M];if(typeof E=="number"||typeof E=="boolean"){if(C!==E)return A[M]=E,!0}else if(C.equals(E)===!1)return C.copy(E),!0}return!1}function g(_){const x=_.uniforms;let y=0;const A=16;for(let M=0,C=x.length;M<C;M++){const b=Array.isArray(x[M])?x[M]:[x[M]];for(let S=0,I=b.length;S<I;S++){const D=b[S],w=Array.isArray(D.value)?D.value:[D.value];for(let U=0,O=w.length;U<O;U++){const F=w[U],V=v(F),k=y%A,z=k%V.boundary,B=k+z;y+=z,B!==0&&A-B<V.storage&&(y+=A-B),D.__data=new Float32Array(V.storage/Float32Array.BYTES_PER_ELEMENT),D.__offset=y,y+=V.storage}}}const E=y%A;return E>0&&(y+=A-E),_.__size=y,_.__cache={},this}function v(_){const x={boundary:0,storage:0};return typeof _=="number"||typeof _=="boolean"?(x.boundary=4,x.storage=4):_.isVector2?(x.boundary=8,x.storage=8):_.isVector3||_.isColor?(x.boundary=16,x.storage=12):_.isVector4?(x.boundary=16,x.storage=16):_.isMatrix3?(x.boundary=48,x.storage=48):_.isMatrix4?(x.boundary=64,x.storage=64):_.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",_),x}function m(_){const x=_.target;x.removeEventListener("dispose",m);const y=a.indexOf(x.__bindingPointIndex);a.splice(y,1),i.deleteBuffer(s[x.id]),delete s[x.id],delete r[x.id]}function f(){for(const _ in s)i.deleteBuffer(s[_]);a=[],s={},r={}}return{bind:c,update:l,dispose:f}}class ay{constructor(e={}){const{canvas:t=cm(),context:n=null,depth:s=!0,stencil:r=!1,alpha:a=!1,antialias:o=!1,premultipliedAlpha:c=!0,preserveDrawingBuffer:l=!1,powerPreference:u="default",failIfMajorPerformanceCaveat:d=!1,reversedDepthBuffer:h=!1}=e;this.isWebGLRenderer=!0;let p;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");p=n.getContextAttributes().alpha}else p=a;const g=new Uint32Array(4),v=new Int32Array(4);let m=null,f=null;const _=[],x=[];this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=Ii,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const y=this;let A=!1;this._outputColorSpace=_t;let E=0,M=0,C=null,b=-1,S=null;const I=new st,D=new st;let w=null;const U=new Re(0);let O=0,F=t.width,V=t.height,k=1,z=null,B=null;const j=new st(0,0,F,V),ne=new st(0,0,F,V);let Q=!1;const re=new zc;let ce=!1,G=!1;const Y=new Ye,ie=new N,ye=new st,se={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let Le=!1;function be(){return C===null?k:1}let L=n;function Ue(R,W){return t.getContext(R,W)}try{const R={alpha:!0,depth:s,stencil:r,antialias:o,premultipliedAlpha:c,preserveDrawingBuffer:l,powerPreference:u,failIfMajorPerformanceCaveat:d};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${Ac}`),t.addEventListener("webglcontextlost",ve,!1),t.addEventListener("webglcontextrestored",Ce,!1),t.addEventListener("webglcontextcreationerror",ue,!1),L===null){const W="webgl2";if(L=Ue(W,R),L===null)throw Ue(W)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(R){throw console.error("THREE.WebGLRenderer: "+R.message),R}let me,ae,le,Ne,pe,Ae,He,ke,P,T,q,J,te,$,xe,oe,Oe,Fe,he,Te,We,Be,Me,Ke;function H(){me=new g_(L),me.init(),Be=new Jx(L,me),ae=new c_(L,me,e,Be),le=new Kx(L,me),ae.reversedDepthBuffer&&h&&le.buffers.depth.setReversed(!0),Ne=new x_(L),pe=new Fx,Ae=new Zx(L,me,le,pe,ae,Be,Ne),He=new d_(y),ke=new m_(y),P=new Tg(L),Me=new o_(L,P),T=new v_(L,P,Ne,Me),q=new S_(L,T,P,Ne),he=new y_(L,ae,Ae),oe=new u_(pe),J=new Ux(y,He,ke,me,ae,Me,oe),te=new sy(y,pe),$=new kx,xe=new Xx(me),Fe=new a_(y,He,ke,le,q,p,c),Oe=new jx(y,q,ae),Ke=new ry(L,Ne,ae,le),Te=new l_(L,me,Ne),We=new __(L,me,Ne),Ne.programs=J.programs,y.capabilities=ae,y.extensions=me,y.properties=pe,y.renderLists=$,y.shadowMap=Oe,y.state=le,y.info=Ne}H();const fe=new ny(y,L);this.xr=fe,this.getContext=function(){return L},this.getContextAttributes=function(){return L.getContextAttributes()},this.forceContextLoss=function(){const R=me.get("WEBGL_lose_context");R&&R.loseContext()},this.forceContextRestore=function(){const R=me.get("WEBGL_lose_context");R&&R.restoreContext()},this.getPixelRatio=function(){return k},this.setPixelRatio=function(R){R!==void 0&&(k=R,this.setSize(F,V,!1))},this.getSize=function(R){return R.set(F,V)},this.setSize=function(R,W,K=!0){if(fe.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}F=R,V=W,t.width=Math.floor(R*k),t.height=Math.floor(W*k),K===!0&&(t.style.width=R+"px",t.style.height=W+"px"),this.setViewport(0,0,R,W)},this.getDrawingBufferSize=function(R){return R.set(F*k,V*k).floor()},this.setDrawingBufferSize=function(R,W,K){F=R,V=W,k=K,t.width=Math.floor(R*K),t.height=Math.floor(W*K),this.setViewport(0,0,R,W)},this.getCurrentViewport=function(R){return R.copy(I)},this.getViewport=function(R){return R.copy(j)},this.setViewport=function(R,W,K,Z){R.isVector4?j.set(R.x,R.y,R.z,R.w):j.set(R,W,K,Z),le.viewport(I.copy(j).multiplyScalar(k).round())},this.getScissor=function(R){return R.copy(ne)},this.setScissor=function(R,W,K,Z){R.isVector4?ne.set(R.x,R.y,R.z,R.w):ne.set(R,W,K,Z),le.scissor(D.copy(ne).multiplyScalar(k).round())},this.getScissorTest=function(){return Q},this.setScissorTest=function(R){le.setScissorTest(Q=R)},this.setOpaqueSort=function(R){z=R},this.setTransparentSort=function(R){B=R},this.getClearColor=function(R){return R.copy(Fe.getClearColor())},this.setClearColor=function(){Fe.setClearColor(...arguments)},this.getClearAlpha=function(){return Fe.getClearAlpha()},this.setClearAlpha=function(){Fe.setClearAlpha(...arguments)},this.clear=function(R=!0,W=!0,K=!0){let Z=0;if(R){let X=!1;if(C!==null){const de=C.texture.format;X=de===Nc||de===Dc||de===Lc}if(X){const de=C.texture.type,Ee=de===qn||de===Ki||de===Ar||de===wr||de===Cc||de===Ic,Pe=Fe.getClearColor(),we=Fe.getClearAlpha(),Ge=Pe.r,Xe=Pe.g,ze=Pe.b;Ee?(g[0]=Ge,g[1]=Xe,g[2]=ze,g[3]=we,L.clearBufferuiv(L.COLOR,0,g)):(v[0]=Ge,v[1]=Xe,v[2]=ze,v[3]=we,L.clearBufferiv(L.COLOR,0,v))}else Z|=L.COLOR_BUFFER_BIT}W&&(Z|=L.DEPTH_BUFFER_BIT),K&&(Z|=L.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),L.clear(Z)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){t.removeEventListener("webglcontextlost",ve,!1),t.removeEventListener("webglcontextrestored",Ce,!1),t.removeEventListener("webglcontextcreationerror",ue,!1),Fe.dispose(),$.dispose(),xe.dispose(),pe.dispose(),He.dispose(),ke.dispose(),q.dispose(),Me.dispose(),Ke.dispose(),J.dispose(),fe.dispose(),fe.removeEventListener("sessionstart",Vn),fe.removeEventListener("sessionend",lu),Oi.stop()};function ve(R){R.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),A=!0}function Ce(){console.log("THREE.WebGLRenderer: Context Restored."),A=!1;const R=Ne.autoReset,W=Oe.enabled,K=Oe.autoUpdate,Z=Oe.needsUpdate,X=Oe.type;H(),Ne.autoReset=R,Oe.enabled=W,Oe.autoUpdate=K,Oe.needsUpdate=Z,Oe.type=X}function ue(R){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",R.statusMessage)}function ee(R){const W=R.target;W.removeEventListener("dispose",ee),De(W)}function De(R){je(R),pe.remove(R)}function je(R){const W=pe.get(R).programs;W!==void 0&&(W.forEach(function(K){J.releaseProgram(K)}),R.isShaderMaterial&&J.releaseShaderCache(R))}this.renderBufferDirect=function(R,W,K,Z,X,de){W===null&&(W=se);const Ee=X.isMesh&&X.matrixWorld.determinant()<0,Pe=jf(R,W,K,Z,X);le.setMaterial(Z,Ee);let we=K.index,Ge=1;if(Z.wireframe===!0){if(we=T.getWireframeAttribute(K),we===void 0)return;Ge=2}const Xe=K.drawRange,ze=K.attributes.position;let et=Xe.start*Ge,ht=(Xe.start+Xe.count)*Ge;de!==null&&(et=Math.max(et,de.start*Ge),ht=Math.min(ht,(de.start+de.count)*Ge)),we!==null?(et=Math.max(et,0),ht=Math.min(ht,we.count)):ze!=null&&(et=Math.max(et,0),ht=Math.min(ht,ze.count));const wt=ht-et;if(wt<0||wt===1/0)return;Me.setup(X,Z,Pe,K,we);let yt,mt=Te;if(we!==null&&(yt=P.get(we),mt=We,mt.setIndex(yt)),X.isMesh)Z.wireframe===!0?(le.setLineWidth(Z.wireframeLinewidth*be()),mt.setMode(L.LINES)):mt.setMode(L.TRIANGLES);else if(X.isLine){let Ve=Z.linewidth;Ve===void 0&&(Ve=1),le.setLineWidth(Ve*be()),X.isLineSegments?mt.setMode(L.LINES):X.isLineLoop?mt.setMode(L.LINE_LOOP):mt.setMode(L.LINE_STRIP)}else X.isPoints?mt.setMode(L.POINTS):X.isSprite&&mt.setMode(L.TRIANGLES);if(X.isBatchedMesh)if(X._multiDrawInstances!==null)Dr("THREE.WebGLRenderer: renderMultiDrawInstances has been deprecated and will be removed in r184. Append to renderMultiDraw arguments and use indirection."),mt.renderMultiDrawInstances(X._multiDrawStarts,X._multiDrawCounts,X._multiDrawCount,X._multiDrawInstances);else if(me.get("WEBGL_multi_draw"))mt.renderMultiDraw(X._multiDrawStarts,X._multiDrawCounts,X._multiDrawCount);else{const Ve=X._multiDrawStarts,Et=X._multiDrawCounts,it=X._multiDrawCount,cn=we?P.get(we).bytesPerElement:1,ts=pe.get(Z).currentProgram.getUniforms();for(let un=0;un<it;un++)ts.setValue(L,"_gl_DrawID",un),mt.render(Ve[un]/cn,Et[un])}else if(X.isInstancedMesh)mt.renderInstances(et,wt,X.count);else if(K.isInstancedBufferGeometry){const Ve=K._maxInstanceCount!==void 0?K._maxInstanceCount:1/0,Et=Math.min(K.instanceCount,Ve);mt.renderInstances(et,wt,Et)}else mt.render(et,wt)};function gt(R,W,K){R.transparent===!0&&R.side===Mt&&R.forceSinglePass===!1?(R.side=an,R.needsUpdate=!0,Zr(R,W,K),R.side=fi,R.needsUpdate=!0,Zr(R,W,K),R.side=Mt):Zr(R,W,K)}this.compile=function(R,W,K=null){K===null&&(K=R),f=xe.get(K),f.init(W),x.push(f),K.traverseVisible(function(X){X.isLight&&X.layers.test(W.layers)&&(f.pushLight(X),X.castShadow&&f.pushShadow(X))}),R!==K&&R.traverseVisible(function(X){X.isLight&&X.layers.test(W.layers)&&(f.pushLight(X),X.castShadow&&f.pushShadow(X))}),f.setupLights();const Z=new Set;return R.traverse(function(X){if(!(X.isMesh||X.isPoints||X.isLine||X.isSprite))return;const de=X.material;if(de)if(Array.isArray(de))for(let Ee=0;Ee<de.length;Ee++){const Pe=de[Ee];gt(Pe,K,X),Z.add(Pe)}else gt(de,K,X),Z.add(de)}),f=x.pop(),Z},this.compileAsync=function(R,W,K=null){const Z=this.compile(R,W,K);return new Promise(X=>{function de(){if(Z.forEach(function(Ee){pe.get(Ee).currentProgram.isReady()&&Z.delete(Ee)}),Z.size===0){X(R);return}setTimeout(de,10)}me.get("KHR_parallel_shader_compile")!==null?de():setTimeout(de,10)})};let rt=null;function Zn(R){rt&&rt(R)}function Vn(){Oi.stop()}function lu(){Oi.start()}const Oi=new ff;Oi.setAnimationLoop(Zn),typeof self<"u"&&Oi.setContext(self),this.setAnimationLoop=function(R){rt=R,fe.setAnimationLoop(R),R===null?Oi.stop():Oi.start()},fe.addEventListener("sessionstart",Vn),fe.addEventListener("sessionend",lu),this.render=function(R,W){if(W!==void 0&&W.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(A===!0)return;if(R.matrixWorldAutoUpdate===!0&&R.updateMatrixWorld(),W.parent===null&&W.matrixWorldAutoUpdate===!0&&W.updateMatrixWorld(),fe.enabled===!0&&fe.isPresenting===!0&&(fe.cameraAutoUpdate===!0&&fe.updateCamera(W),W=fe.getCamera()),R.isScene===!0&&R.onBeforeRender(y,R,W,C),f=xe.get(R,x.length),f.init(W),x.push(f),Y.multiplyMatrices(W.projectionMatrix,W.matrixWorldInverse),re.setFromProjectionMatrix(Y,Wn,W.reversedDepth),G=this.localClippingEnabled,ce=oe.init(this.clippingPlanes,G),m=$.get(R,_.length),m.init(),_.push(m),fe.enabled===!0&&fe.isPresenting===!0){const de=y.xr.getDepthSensingMesh();de!==null&&To(de,W,-1/0,y.sortObjects)}To(R,W,0,y.sortObjects),m.finish(),y.sortObjects===!0&&m.sort(z,B),Le=fe.enabled===!1||fe.isPresenting===!1||fe.hasDepthSensing()===!1,Le&&Fe.addToRenderList(m,R),this.info.render.frame++,ce===!0&&oe.beginShadows();const K=f.state.shadowsArray;Oe.render(K,R,W),ce===!0&&oe.endShadows(),this.info.autoReset===!0&&this.info.reset();const Z=m.opaque,X=m.transmissive;if(f.setupLights(),W.isArrayCamera){const de=W.cameras;if(X.length>0)for(let Ee=0,Pe=de.length;Ee<Pe;Ee++){const we=de[Ee];uu(Z,X,R,we)}Le&&Fe.render(R);for(let Ee=0,Pe=de.length;Ee<Pe;Ee++){const we=de[Ee];cu(m,R,we,we.viewport)}}else X.length>0&&uu(Z,X,R,W),Le&&Fe.render(R),cu(m,R,W);C!==null&&M===0&&(Ae.updateMultisampleRenderTarget(C),Ae.updateRenderTargetMipmap(C)),R.isScene===!0&&R.onAfterRender(y,R,W),Me.resetDefaultState(),b=-1,S=null,x.pop(),x.length>0?(f=x[x.length-1],ce===!0&&oe.setGlobalState(y.clippingPlanes,f.state.camera)):f=null,_.pop(),_.length>0?m=_[_.length-1]:m=null};function To(R,W,K,Z){if(R.visible===!1)return;if(R.layers.test(W.layers)){if(R.isGroup)K=R.renderOrder;else if(R.isLOD)R.autoUpdate===!0&&R.update(W);else if(R.isLight)f.pushLight(R),R.castShadow&&f.pushShadow(R);else if(R.isSprite){if(!R.frustumCulled||re.intersectsSprite(R)){Z&&ye.setFromMatrixPosition(R.matrixWorld).applyMatrix4(Y);const Ee=q.update(R),Pe=R.material;Pe.visible&&m.push(R,Ee,Pe,K,ye.z,null)}}else if((R.isMesh||R.isLine||R.isPoints)&&(!R.frustumCulled||re.intersectsObject(R))){const Ee=q.update(R),Pe=R.material;if(Z&&(R.boundingSphere!==void 0?(R.boundingSphere===null&&R.computeBoundingSphere(),ye.copy(R.boundingSphere.center)):(Ee.boundingSphere===null&&Ee.computeBoundingSphere(),ye.copy(Ee.boundingSphere.center)),ye.applyMatrix4(R.matrixWorld).applyMatrix4(Y)),Array.isArray(Pe)){const we=Ee.groups;for(let Ge=0,Xe=we.length;Ge<Xe;Ge++){const ze=we[Ge],et=Pe[ze.materialIndex];et&&et.visible&&m.push(R,Ee,et,K,ye.z,ze)}}else Pe.visible&&m.push(R,Ee,Pe,K,ye.z,null)}}const de=R.children;for(let Ee=0,Pe=de.length;Ee<Pe;Ee++)To(de[Ee],W,K,Z)}function cu(R,W,K,Z){const X=R.opaque,de=R.transmissive,Ee=R.transparent;f.setupLightsView(K),ce===!0&&oe.setGlobalState(y.clippingPlanes,K),Z&&le.viewport(I.copy(Z)),X.length>0&&Kr(X,W,K),de.length>0&&Kr(de,W,K),Ee.length>0&&Kr(Ee,W,K),le.buffers.depth.setTest(!0),le.buffers.depth.setMask(!0),le.buffers.color.setMask(!0),le.setPolygonOffset(!1)}function uu(R,W,K,Z){if((K.isScene===!0?K.overrideMaterial:null)!==null)return;f.state.transmissionRenderTarget[Z.id]===void 0&&(f.state.transmissionRenderTarget[Z.id]=new kn(1,1,{generateMipmaps:!0,type:me.has("EXT_color_buffer_half_float")||me.has("EXT_color_buffer_float")?di:qn,minFilter:Gt,samples:4,stencilBuffer:r,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:tt.workingColorSpace}));const de=f.state.transmissionRenderTarget[Z.id],Ee=Z.viewport||I;de.setSize(Ee.z*y.transmissionResolutionScale,Ee.w*y.transmissionResolutionScale);const Pe=y.getRenderTarget(),we=y.getActiveCubeFace(),Ge=y.getActiveMipmapLevel();y.setRenderTarget(de),y.getClearColor(U),O=y.getClearAlpha(),O<1&&y.setClearColor(16777215,.5),y.clear(),Le&&Fe.render(K);const Xe=y.toneMapping;y.toneMapping=Ii;const ze=Z.viewport;if(Z.viewport!==void 0&&(Z.viewport=void 0),f.setupLightsView(Z),ce===!0&&oe.setGlobalState(y.clippingPlanes,Z),Kr(R,K,Z),Ae.updateMultisampleRenderTarget(de),Ae.updateRenderTargetMipmap(de),me.has("WEBGL_multisampled_render_to_texture")===!1){let et=!1;for(let ht=0,wt=W.length;ht<wt;ht++){const yt=W[ht],mt=yt.object,Ve=yt.geometry,Et=yt.material,it=yt.group;if(Et.side===Mt&&mt.layers.test(Z.layers)){const cn=Et.side;Et.side=an,Et.needsUpdate=!0,du(mt,K,Z,Ve,Et,it),Et.side=cn,Et.needsUpdate=!0,et=!0}}et===!0&&(Ae.updateMultisampleRenderTarget(de),Ae.updateRenderTargetMipmap(de))}y.setRenderTarget(Pe,we,Ge),y.setClearColor(U,O),ze!==void 0&&(Z.viewport=ze),y.toneMapping=Xe}function Kr(R,W,K){const Z=W.isScene===!0?W.overrideMaterial:null;for(let X=0,de=R.length;X<de;X++){const Ee=R[X],Pe=Ee.object,we=Ee.geometry,Ge=Ee.group;let Xe=Ee.material;Xe.allowOverride===!0&&Z!==null&&(Xe=Z),Pe.layers.test(K.layers)&&du(Pe,W,K,we,Xe,Ge)}}function du(R,W,K,Z,X,de){R.onBeforeRender(y,W,K,Z,X,de),R.modelViewMatrix.multiplyMatrices(K.matrixWorldInverse,R.matrixWorld),R.normalMatrix.getNormalMatrix(R.modelViewMatrix),X.onBeforeRender(y,W,K,Z,R,de),X.transparent===!0&&X.side===Mt&&X.forceSinglePass===!1?(X.side=an,X.needsUpdate=!0,y.renderBufferDirect(K,W,Z,X,R,de),X.side=fi,X.needsUpdate=!0,y.renderBufferDirect(K,W,Z,X,R,de),X.side=Mt):y.renderBufferDirect(K,W,Z,X,R,de),R.onAfterRender(y,W,K,Z,X,de)}function Zr(R,W,K){W.isScene!==!0&&(W=se);const Z=pe.get(R),X=f.state.lights,de=f.state.shadowsArray,Ee=X.state.version,Pe=J.getParameters(R,X.state,de,W,K),we=J.getProgramCacheKey(Pe);let Ge=Z.programs;Z.environment=R.isMeshStandardMaterial?W.environment:null,Z.fog=W.fog,Z.envMap=(R.isMeshStandardMaterial?ke:He).get(R.envMap||Z.environment),Z.envMapRotation=Z.environment!==null&&R.envMap===null?W.environmentRotation:R.envMapRotation,Ge===void 0&&(R.addEventListener("dispose",ee),Ge=new Map,Z.programs=Ge);let Xe=Ge.get(we);if(Xe!==void 0){if(Z.currentProgram===Xe&&Z.lightsStateVersion===Ee)return fu(R,Pe),Xe}else Pe.uniforms=J.getUniforms(R),R.onBeforeCompile(Pe,y),Xe=J.acquireProgram(Pe,we),Ge.set(we,Xe),Z.uniforms=Pe.uniforms;const ze=Z.uniforms;return(!R.isShaderMaterial&&!R.isRawShaderMaterial||R.clipping===!0)&&(ze.clippingPlanes=oe.uniform),fu(R,Pe),Z.needsLights=Kf(R),Z.lightsStateVersion=Ee,Z.needsLights&&(ze.ambientLightColor.value=X.state.ambient,ze.lightProbe.value=X.state.probe,ze.directionalLights.value=X.state.directional,ze.directionalLightShadows.value=X.state.directionalShadow,ze.spotLights.value=X.state.spot,ze.spotLightShadows.value=X.state.spotShadow,ze.rectAreaLights.value=X.state.rectArea,ze.ltc_1.value=X.state.rectAreaLTC1,ze.ltc_2.value=X.state.rectAreaLTC2,ze.pointLights.value=X.state.point,ze.pointLightShadows.value=X.state.pointShadow,ze.hemisphereLights.value=X.state.hemi,ze.directionalShadowMap.value=X.state.directionalShadowMap,ze.directionalShadowMatrix.value=X.state.directionalShadowMatrix,ze.spotShadowMap.value=X.state.spotShadowMap,ze.spotLightMatrix.value=X.state.spotLightMatrix,ze.spotLightMap.value=X.state.spotLightMap,ze.pointShadowMap.value=X.state.pointShadowMap,ze.pointShadowMatrix.value=X.state.pointShadowMatrix),Z.currentProgram=Xe,Z.uniformsList=null,Xe}function hu(R){if(R.uniformsList===null){const W=R.currentProgram.getUniforms();R.uniformsList=ka.seqWithValue(W.seq,R.uniforms)}return R.uniformsList}function fu(R,W){const K=pe.get(R);K.outputColorSpace=W.outputColorSpace,K.batching=W.batching,K.batchingColor=W.batchingColor,K.instancing=W.instancing,K.instancingColor=W.instancingColor,K.instancingMorph=W.instancingMorph,K.skinning=W.skinning,K.morphTargets=W.morphTargets,K.morphNormals=W.morphNormals,K.morphColors=W.morphColors,K.morphTargetsCount=W.morphTargetsCount,K.numClippingPlanes=W.numClippingPlanes,K.numIntersection=W.numClipIntersection,K.vertexAlphas=W.vertexAlphas,K.vertexTangents=W.vertexTangents,K.toneMapping=W.toneMapping}function jf(R,W,K,Z,X){W.isScene!==!0&&(W=se),Ae.resetTextureUnits();const de=W.fog,Ee=Z.isMeshStandardMaterial?W.environment:null,Pe=C===null?y.outputColorSpace:C.isXRRenderTarget===!0?C.texture.colorSpace:Qt,we=(Z.isMeshStandardMaterial?ke:He).get(Z.envMap||Ee),Ge=Z.vertexColors===!0&&!!K.attributes.color&&K.attributes.color.itemSize===4,Xe=!!K.attributes.tangent&&(!!Z.normalMap||Z.anisotropy>0),ze=!!K.morphAttributes.position,et=!!K.morphAttributes.normal,ht=!!K.morphAttributes.color;let wt=Ii;Z.toneMapped&&(C===null||C.isXRRenderTarget===!0)&&(wt=y.toneMapping);const yt=K.morphAttributes.position||K.morphAttributes.normal||K.morphAttributes.color,mt=yt!==void 0?yt.length:0,Ve=pe.get(Z),Et=f.state.lights;if(ce===!0&&(G===!0||R!==S)){const Yt=R===S&&Z.id===b;oe.setState(Z,R,Yt)}let it=!1;Z.version===Ve.__version?(Ve.needsLights&&Ve.lightsStateVersion!==Et.state.version||Ve.outputColorSpace!==Pe||X.isBatchedMesh&&Ve.batching===!1||!X.isBatchedMesh&&Ve.batching===!0||X.isBatchedMesh&&Ve.batchingColor===!0&&X.colorTexture===null||X.isBatchedMesh&&Ve.batchingColor===!1&&X.colorTexture!==null||X.isInstancedMesh&&Ve.instancing===!1||!X.isInstancedMesh&&Ve.instancing===!0||X.isSkinnedMesh&&Ve.skinning===!1||!X.isSkinnedMesh&&Ve.skinning===!0||X.isInstancedMesh&&Ve.instancingColor===!0&&X.instanceColor===null||X.isInstancedMesh&&Ve.instancingColor===!1&&X.instanceColor!==null||X.isInstancedMesh&&Ve.instancingMorph===!0&&X.morphTexture===null||X.isInstancedMesh&&Ve.instancingMorph===!1&&X.morphTexture!==null||Ve.envMap!==we||Z.fog===!0&&Ve.fog!==de||Ve.numClippingPlanes!==void 0&&(Ve.numClippingPlanes!==oe.numPlanes||Ve.numIntersection!==oe.numIntersection)||Ve.vertexAlphas!==Ge||Ve.vertexTangents!==Xe||Ve.morphTargets!==ze||Ve.morphNormals!==et||Ve.morphColors!==ht||Ve.toneMapping!==wt||Ve.morphTargetsCount!==mt)&&(it=!0):(it=!0,Ve.__version=Z.version);let cn=Ve.currentProgram;it===!0&&(cn=Zr(Z,W,X));let ts=!1,un=!1,nr=!1;const Tt=cn.getUniforms(),xn=Ve.uniforms;if(le.useProgram(cn.program)&&(ts=!0,un=!0,nr=!0),Z.id!==b&&(b=Z.id,un=!0),ts||S!==R){le.buffers.depth.getReversed()&&R.reversedDepth!==!0&&(R._reversedDepth=!0,R.updateProjectionMatrix()),Tt.setValue(L,"projectionMatrix",R.projectionMatrix),Tt.setValue(L,"viewMatrix",R.matrixWorldInverse);const en=Tt.map.cameraPosition;en!==void 0&&en.setValue(L,ie.setFromMatrixPosition(R.matrixWorld)),ae.logarithmicDepthBuffer&&Tt.setValue(L,"logDepthBufFC",2/(Math.log(R.far+1)/Math.LN2)),(Z.isMeshPhongMaterial||Z.isMeshToonMaterial||Z.isMeshLambertMaterial||Z.isMeshBasicMaterial||Z.isMeshStandardMaterial||Z.isShaderMaterial)&&Tt.setValue(L,"isOrthographic",R.isOrthographicCamera===!0),S!==R&&(S=R,un=!0,nr=!0)}if(X.isSkinnedMesh){Tt.setOptional(L,X,"bindMatrix"),Tt.setOptional(L,X,"bindMatrixInverse");const Yt=X.skeleton;Yt&&(Yt.boneTexture===null&&Yt.computeBoneTexture(),Tt.setValue(L,"boneTexture",Yt.boneTexture,Ae))}X.isBatchedMesh&&(Tt.setOptional(L,X,"batchingTexture"),Tt.setValue(L,"batchingTexture",X._matricesTexture,Ae),Tt.setOptional(L,X,"batchingIdTexture"),Tt.setValue(L,"batchingIdTexture",X._indirectTexture,Ae),Tt.setOptional(L,X,"batchingColorTexture"),X._colorsTexture!==null&&Tt.setValue(L,"batchingColorTexture",X._colorsTexture,Ae));const yn=K.morphAttributes;if((yn.position!==void 0||yn.normal!==void 0||yn.color!==void 0)&&he.update(X,K,cn),(un||Ve.receiveShadow!==X.receiveShadow)&&(Ve.receiveShadow=X.receiveShadow,Tt.setValue(L,"receiveShadow",X.receiveShadow)),Z.isMeshGouraudMaterial&&Z.envMap!==null&&(xn.envMap.value=we,xn.flipEnvMap.value=we.isCubeTexture&&we.isRenderTargetTexture===!1?-1:1),Z.isMeshStandardMaterial&&Z.envMap===null&&W.environment!==null&&(xn.envMapIntensity.value=W.environmentIntensity),un&&(Tt.setValue(L,"toneMappingExposure",y.toneMappingExposure),Ve.needsLights&&$f(xn,nr),de&&Z.fog===!0&&te.refreshFogUniforms(xn,de),te.refreshMaterialUniforms(xn,Z,k,V,f.state.transmissionRenderTarget[R.id]),ka.upload(L,hu(Ve),xn,Ae)),Z.isShaderMaterial&&Z.uniformsNeedUpdate===!0&&(ka.upload(L,hu(Ve),xn,Ae),Z.uniformsNeedUpdate=!1),Z.isSpriteMaterial&&Tt.setValue(L,"center",X.center),Tt.setValue(L,"modelViewMatrix",X.modelViewMatrix),Tt.setValue(L,"normalMatrix",X.normalMatrix),Tt.setValue(L,"modelMatrix",X.matrixWorld),Z.isShaderMaterial||Z.isRawShaderMaterial){const Yt=Z.uniformsGroups;for(let en=0,Ao=Yt.length;en<Ao;en++){const Ui=Yt[en];Ke.update(Ui,cn),Ke.bind(Ui,cn)}}return cn}function $f(R,W){R.ambientLightColor.needsUpdate=W,R.lightProbe.needsUpdate=W,R.directionalLights.needsUpdate=W,R.directionalLightShadows.needsUpdate=W,R.pointLights.needsUpdate=W,R.pointLightShadows.needsUpdate=W,R.spotLights.needsUpdate=W,R.spotLightShadows.needsUpdate=W,R.rectAreaLights.needsUpdate=W,R.hemisphereLights.needsUpdate=W}function Kf(R){return R.isMeshLambertMaterial||R.isMeshToonMaterial||R.isMeshPhongMaterial||R.isMeshStandardMaterial||R.isShadowMaterial||R.isShaderMaterial&&R.lights===!0}this.getActiveCubeFace=function(){return E},this.getActiveMipmapLevel=function(){return M},this.getRenderTarget=function(){return C},this.setRenderTargetTextures=function(R,W,K){const Z=pe.get(R);Z.__autoAllocateDepthBuffer=R.resolveDepthBuffer===!1,Z.__autoAllocateDepthBuffer===!1&&(Z.__useRenderToTexture=!1),pe.get(R.texture).__webglTexture=W,pe.get(R.depthTexture).__webglTexture=Z.__autoAllocateDepthBuffer?void 0:K,Z.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(R,W){const K=pe.get(R);K.__webglFramebuffer=W,K.__useDefaultFramebuffer=W===void 0};const Zf=L.createFramebuffer();this.setRenderTarget=function(R,W=0,K=0){C=R,E=W,M=K;let Z=!0,X=null,de=!1,Ee=!1;if(R){const we=pe.get(R);if(we.__useDefaultFramebuffer!==void 0)le.bindFramebuffer(L.FRAMEBUFFER,null),Z=!1;else if(we.__webglFramebuffer===void 0)Ae.setupRenderTarget(R);else if(we.__hasExternalTextures)Ae.rebindTextures(R,pe.get(R.texture).__webglTexture,pe.get(R.depthTexture).__webglTexture);else if(R.depthBuffer){const ze=R.depthTexture;if(we.__boundDepthTexture!==ze){if(ze!==null&&pe.has(ze)&&(R.width!==ze.image.width||R.height!==ze.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");Ae.setupDepthRenderbuffer(R)}}const Ge=R.texture;(Ge.isData3DTexture||Ge.isDataArrayTexture||Ge.isCompressedArrayTexture)&&(Ee=!0);const Xe=pe.get(R).__webglFramebuffer;R.isWebGLCubeRenderTarget?(Array.isArray(Xe[W])?X=Xe[W][K]:X=Xe[W],de=!0):R.samples>0&&Ae.useMultisampledRTT(R)===!1?X=pe.get(R).__webglMultisampledFramebuffer:Array.isArray(Xe)?X=Xe[K]:X=Xe,I.copy(R.viewport),D.copy(R.scissor),w=R.scissorTest}else I.copy(j).multiplyScalar(k).floor(),D.copy(ne).multiplyScalar(k).floor(),w=Q;if(K!==0&&(X=Zf),le.bindFramebuffer(L.FRAMEBUFFER,X)&&Z&&le.drawBuffers(R,X),le.viewport(I),le.scissor(D),le.setScissorTest(w),de){const we=pe.get(R.texture);L.framebufferTexture2D(L.FRAMEBUFFER,L.COLOR_ATTACHMENT0,L.TEXTURE_CUBE_MAP_POSITIVE_X+W,we.__webglTexture,K)}else if(Ee){const we=W;for(let Ge=0;Ge<R.textures.length;Ge++){const Xe=pe.get(R.textures[Ge]);L.framebufferTextureLayer(L.FRAMEBUFFER,L.COLOR_ATTACHMENT0+Ge,Xe.__webglTexture,K,we)}}else if(R!==null&&K!==0){const we=pe.get(R.texture);L.framebufferTexture2D(L.FRAMEBUFFER,L.COLOR_ATTACHMENT0,L.TEXTURE_2D,we.__webglTexture,K)}b=-1},this.readRenderTargetPixels=function(R,W,K,Z,X,de,Ee,Pe=0){if(!(R&&R.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let we=pe.get(R).__webglFramebuffer;if(R.isWebGLCubeRenderTarget&&Ee!==void 0&&(we=we[Ee]),we){le.bindFramebuffer(L.FRAMEBUFFER,we);try{const Ge=R.textures[Pe],Xe=Ge.format,ze=Ge.type;if(!ae.textureFormatReadable(Xe)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!ae.textureTypeReadable(ze)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}W>=0&&W<=R.width-Z&&K>=0&&K<=R.height-X&&(R.textures.length>1&&L.readBuffer(L.COLOR_ATTACHMENT0+Pe),L.readPixels(W,K,Z,X,Be.convert(Xe),Be.convert(ze),de))}finally{const Ge=C!==null?pe.get(C).__webglFramebuffer:null;le.bindFramebuffer(L.FRAMEBUFFER,Ge)}}},this.readRenderTargetPixelsAsync=async function(R,W,K,Z,X,de,Ee,Pe=0){if(!(R&&R.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let we=pe.get(R).__webglFramebuffer;if(R.isWebGLCubeRenderTarget&&Ee!==void 0&&(we=we[Ee]),we)if(W>=0&&W<=R.width-Z&&K>=0&&K<=R.height-X){le.bindFramebuffer(L.FRAMEBUFFER,we);const Ge=R.textures[Pe],Xe=Ge.format,ze=Ge.type;if(!ae.textureFormatReadable(Xe))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!ae.textureTypeReadable(ze))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const et=L.createBuffer();L.bindBuffer(L.PIXEL_PACK_BUFFER,et),L.bufferData(L.PIXEL_PACK_BUFFER,de.byteLength,L.STREAM_READ),R.textures.length>1&&L.readBuffer(L.COLOR_ATTACHMENT0+Pe),L.readPixels(W,K,Z,X,Be.convert(Xe),Be.convert(ze),0);const ht=C!==null?pe.get(C).__webglFramebuffer:null;le.bindFramebuffer(L.FRAMEBUFFER,ht);const wt=L.fenceSync(L.SYNC_GPU_COMMANDS_COMPLETE,0);return L.flush(),await um(L,wt,4),L.bindBuffer(L.PIXEL_PACK_BUFFER,et),L.getBufferSubData(L.PIXEL_PACK_BUFFER,0,de),L.deleteBuffer(et),L.deleteSync(wt),de}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(R,W=null,K=0){const Z=Math.pow(2,-K),X=Math.floor(R.image.width*Z),de=Math.floor(R.image.height*Z),Ee=W!==null?W.x:0,Pe=W!==null?W.y:0;Ae.setTexture2D(R,0),L.copyTexSubImage2D(L.TEXTURE_2D,K,0,0,Ee,Pe,X,de),le.unbindTexture()};const Jf=L.createFramebuffer(),Qf=L.createFramebuffer();this.copyTextureToTexture=function(R,W,K=null,Z=null,X=0,de=null){de===null&&(X!==0?(Dr("WebGLRenderer: copyTextureToTexture function signature has changed to support src and dst mipmap levels."),de=X,X=0):de=0);let Ee,Pe,we,Ge,Xe,ze,et,ht,wt;const yt=R.isCompressedTexture?R.mipmaps[de]:R.image;if(K!==null)Ee=K.max.x-K.min.x,Pe=K.max.y-K.min.y,we=K.isBox3?K.max.z-K.min.z:1,Ge=K.min.x,Xe=K.min.y,ze=K.isBox3?K.min.z:0;else{const yn=Math.pow(2,-X);Ee=Math.floor(yt.width*yn),Pe=Math.floor(yt.height*yn),R.isDataArrayTexture?we=yt.depth:R.isData3DTexture?we=Math.floor(yt.depth*yn):we=1,Ge=0,Xe=0,ze=0}Z!==null?(et=Z.x,ht=Z.y,wt=Z.z):(et=0,ht=0,wt=0);const mt=Be.convert(W.format),Ve=Be.convert(W.type);let Et;W.isData3DTexture?(Ae.setTexture3D(W,0),Et=L.TEXTURE_3D):W.isDataArrayTexture||W.isCompressedArrayTexture?(Ae.setTexture2DArray(W,0),Et=L.TEXTURE_2D_ARRAY):(Ae.setTexture2D(W,0),Et=L.TEXTURE_2D),L.pixelStorei(L.UNPACK_FLIP_Y_WEBGL,W.flipY),L.pixelStorei(L.UNPACK_PREMULTIPLY_ALPHA_WEBGL,W.premultiplyAlpha),L.pixelStorei(L.UNPACK_ALIGNMENT,W.unpackAlignment);const it=L.getParameter(L.UNPACK_ROW_LENGTH),cn=L.getParameter(L.UNPACK_IMAGE_HEIGHT),ts=L.getParameter(L.UNPACK_SKIP_PIXELS),un=L.getParameter(L.UNPACK_SKIP_ROWS),nr=L.getParameter(L.UNPACK_SKIP_IMAGES);L.pixelStorei(L.UNPACK_ROW_LENGTH,yt.width),L.pixelStorei(L.UNPACK_IMAGE_HEIGHT,yt.height),L.pixelStorei(L.UNPACK_SKIP_PIXELS,Ge),L.pixelStorei(L.UNPACK_SKIP_ROWS,Xe),L.pixelStorei(L.UNPACK_SKIP_IMAGES,ze);const Tt=R.isDataArrayTexture||R.isData3DTexture,xn=W.isDataArrayTexture||W.isData3DTexture;if(R.isDepthTexture){const yn=pe.get(R),Yt=pe.get(W),en=pe.get(yn.__renderTarget),Ao=pe.get(Yt.__renderTarget);le.bindFramebuffer(L.READ_FRAMEBUFFER,en.__webglFramebuffer),le.bindFramebuffer(L.DRAW_FRAMEBUFFER,Ao.__webglFramebuffer);for(let Ui=0;Ui<we;Ui++)Tt&&(L.framebufferTextureLayer(L.READ_FRAMEBUFFER,L.COLOR_ATTACHMENT0,pe.get(R).__webglTexture,X,ze+Ui),L.framebufferTextureLayer(L.DRAW_FRAMEBUFFER,L.COLOR_ATTACHMENT0,pe.get(W).__webglTexture,de,wt+Ui)),L.blitFramebuffer(Ge,Xe,Ee,Pe,et,ht,Ee,Pe,L.DEPTH_BUFFER_BIT,L.NEAREST);le.bindFramebuffer(L.READ_FRAMEBUFFER,null),le.bindFramebuffer(L.DRAW_FRAMEBUFFER,null)}else if(X!==0||R.isRenderTargetTexture||pe.has(R)){const yn=pe.get(R),Yt=pe.get(W);le.bindFramebuffer(L.READ_FRAMEBUFFER,Jf),le.bindFramebuffer(L.DRAW_FRAMEBUFFER,Qf);for(let en=0;en<we;en++)Tt?L.framebufferTextureLayer(L.READ_FRAMEBUFFER,L.COLOR_ATTACHMENT0,yn.__webglTexture,X,ze+en):L.framebufferTexture2D(L.READ_FRAMEBUFFER,L.COLOR_ATTACHMENT0,L.TEXTURE_2D,yn.__webglTexture,X),xn?L.framebufferTextureLayer(L.DRAW_FRAMEBUFFER,L.COLOR_ATTACHMENT0,Yt.__webglTexture,de,wt+en):L.framebufferTexture2D(L.DRAW_FRAMEBUFFER,L.COLOR_ATTACHMENT0,L.TEXTURE_2D,Yt.__webglTexture,de),X!==0?L.blitFramebuffer(Ge,Xe,Ee,Pe,et,ht,Ee,Pe,L.COLOR_BUFFER_BIT,L.NEAREST):xn?L.copyTexSubImage3D(Et,de,et,ht,wt+en,Ge,Xe,Ee,Pe):L.copyTexSubImage2D(Et,de,et,ht,Ge,Xe,Ee,Pe);le.bindFramebuffer(L.READ_FRAMEBUFFER,null),le.bindFramebuffer(L.DRAW_FRAMEBUFFER,null)}else xn?R.isDataTexture||R.isData3DTexture?L.texSubImage3D(Et,de,et,ht,wt,Ee,Pe,we,mt,Ve,yt.data):W.isCompressedArrayTexture?L.compressedTexSubImage3D(Et,de,et,ht,wt,Ee,Pe,we,mt,yt.data):L.texSubImage3D(Et,de,et,ht,wt,Ee,Pe,we,mt,Ve,yt):R.isDataTexture?L.texSubImage2D(L.TEXTURE_2D,de,et,ht,Ee,Pe,mt,Ve,yt.data):R.isCompressedTexture?L.compressedTexSubImage2D(L.TEXTURE_2D,de,et,ht,yt.width,yt.height,mt,yt.data):L.texSubImage2D(L.TEXTURE_2D,de,et,ht,Ee,Pe,mt,Ve,yt);L.pixelStorei(L.UNPACK_ROW_LENGTH,it),L.pixelStorei(L.UNPACK_IMAGE_HEIGHT,cn),L.pixelStorei(L.UNPACK_SKIP_PIXELS,ts),L.pixelStorei(L.UNPACK_SKIP_ROWS,un),L.pixelStorei(L.UNPACK_SKIP_IMAGES,nr),de===0&&W.generateMipmaps&&L.generateMipmap(Et),le.unbindTexture()},this.initRenderTarget=function(R){pe.get(R).__webglFramebuffer===void 0&&Ae.setupRenderTarget(R)},this.initTexture=function(R){R.isCubeTexture?Ae.setTextureCube(R,0):R.isData3DTexture?Ae.setTexture3D(R,0):R.isDataArrayTexture||R.isCompressedArrayTexture?Ae.setTexture2DArray(R,0):Ae.setTexture2D(R,0),le.unbindTexture()},this.resetState=function(){E=0,M=0,C=null,le.reset(),Me.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return Wn}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const t=this.getContext();t.drawingBufferColorSpace=tt._getDrawingBufferColorSpace(e),t.unpackColorSpace=tt._getUnpackColorSpace()}}const oy=`
  varying vec2 vUv;
  void main() {
    vUv = uv;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`,ly=`
  precision highp float;
  varying vec2 vUv;
  uniform float uTime;
  uniform float uFlow;
  uniform float uDensity;
  uniform float uStrength;
  uniform float uSeed;
  uniform float uBreath;
  uniform vec3 uCool;
  uniform vec3 uWarm;

  float hash21(vec2 p) {
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
  }
  float noise2(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(
      mix(hash21(i), hash21(i + vec2(1.0, 0.0)), u.x),
      mix(hash21(i + vec2(0.0, 1.0)), hash21(i + vec2(1.0, 1.0)), u.x),
      u.y
    );
  }
  float fbm(vec2 p) {
    float v = 0.0;
    float a = .5;
    for (int i = 0; i < 3; ++i) {
      v += a * noise2(p);
      p = p * 2.03 + vec2(3.73, 4.17);
      a *= .5;
    }
    return v;
  }
  void main() {
    vec2 uv = vUv;
    float motion = uTime * uFlow;
    vec2 drift = vec2(motion * .012, -motion * .006);
    // So a nuvem e deformada. A imagem principal da ESO nunca usa este shader.
    float domain = fbm(uv * 2.9 + drift + vec2(uSeed, uSeed * .34));
    vec2 advected = uv * vec2(4.6, 3.7) + vec2(domain * .62, -domain * .37);
    advected += drift;
    float body = fbm(advected + uSeed * .13);
    float wisps = fbm(advected * 2.8 + vec2(.0, motion * .014));
    float horizontal = uv.y - (.51 + .08 * sin(uv.x * 5.4 + uSeed));
    float band = exp(-horizontal * horizontal * 10.5);
    float edges = smoothstep(.01, .22, uv.x) * smoothstep(.01, .22, 1.0-uv.x)
      * smoothstep(.02, .18, uv.y) * smoothstep(.02, .18, 1.0-uv.y);
    float volume = smoothstep(.45, .68, body);
    float threads = smoothstep(.57, .78, wisps) * smoothstep(.35, .76, body);
    float alpha = (volume * .68 + threads * .32) * band * edges
      * uDensity * uStrength * uBreath;
    vec3 color = mix(uCool, uWarm, clamp(body * .85 + threads * .24, 0.0, 1.0));
    color *= (.68 + .56 * threads) * (1.0 + (uBreath-1.0)*.35);
    gl_FragColor = vec4(color, clamp(alpha, 0.0, .16));
    #include <colorspace_fragment>
  }
`,cy=[{name:"07 · Gás profundo",z:-225,x:-20,y:6,aspect:2.72,factor:1.55,order:2.6,opacity:.44,seed:1.7,cool:"#314778",warm:"#7853a8"},{name:"08 · Filamentos violetas",z:-195,x:12,y:-6,aspect:2.72,factor:1.54,order:3.3,opacity:.57,seed:8.3,cool:"#403d80",warm:"#ac70c5"},{name:"09 · Nuvens intermediárias",z:-169,x:-9,y:1,aspect:2.66,factor:1.5,order:3.7,opacity:.51,seed:13.6,cool:"#345a91",warm:"#8d59a8"},{name:"10 · Reflexos no gás",z:-112,x:5,y:-4,aspect:2.55,factor:1.56,order:4.6,opacity:.35,seed:23.8,cool:"#406aa3",warm:"#b47aab"},{name:"11 · Véu próximo",z:-73,x:13,y:-10,aspect:2.52,factor:1.65,order:5.3,opacity:.28,seed:31.2,cool:"#343d77",warm:"#6b578e"}];function uy(i,{reducedMotion:e=!1}={}){const t={density:.46,flow:.27,bloom:.18},n=[];for(const o of cy){const c=new Rt({vertexShader:oy,fragmentShader:ly,transparent:!0,depthTest:!1,depthWrite:!1,blending:gn,side:Mt,toneMapped:!1,uniforms:{uTime:{value:0},uFlow:{value:e?0:t.flow},uDensity:{value:t.density},uStrength:{value:o.opacity},uSeed:{value:o.seed},uBreath:{value:1},uCool:{value:new Re(o.cool)},uWarm:{value:new Re(o.warm)}}}),l=new pt(new _n(1,1),c);l.position.set(o.x,o.y,o.z),l.renderOrder=o.order,l.userData.aspect=o.aspect,l.userData.factor=o.factor,l.userData.layerName=o.name,l.userData.breathRate=.38+o.seed%5*.045,l.userData.breathPhase=o.seed*.83,i.add(l),n.push(l)}function s(o){for(const c of n){c.material.uniforms.uTime.value=e?0:o,c.material.uniforms.uFlow.value=e?0:t.flow,c.material.uniforms.uDensity.value=t.density;const l=c.userData.breathRate,u=c.userData.breathPhase;c.material.uniforms.uBreath.value=e?1:1+.036*Math.sin(o*l+u)+.016*Math.sin(o*(l*.61)+u*1.71)}}function r(o){t.density=_e.clamp(o,0,1.5)}function a(o){t.flow=_e.clamp(o,0,1)}return{layers:n,state:t,update:s,setDensity:r,setFlow:a}}const za={name:"CopyShader",uniforms:{tDiffuse:{value:null},opacity:{value:1}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform float opacity;

		uniform sampler2D tDiffuse;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );
			gl_FragColor = opacity * texel;


		}`};class Gr{constructor(){this.isPass=!0,this.enabled=!0,this.needsSwap=!0,this.clear=!1,this.renderToScreen=!1}setSize(){}render(){console.error("THREE.Pass: .render() must be implemented in derived pass.")}dispose(){}}const dy=new Hr(-1,1,1,-1,0,1);class hy extends It{constructor(){super(),this.setAttribute("position",new nt([-1,3,0,-1,-1,0,3,-1,0],3)),this.setAttribute("uv",new nt([0,2,0,0,2,0],2))}}const fy=new hy;class _f{constructor(e){this._mesh=new pt(fy,e)}dispose(){this._mesh.geometry.dispose()}render(e){e.render(this._mesh,dy)}get material(){return this._mesh.material}set material(e){this._mesh.material=e}}class py extends Gr{constructor(e,t="tDiffuse"){super(),this.textureID=t,this.uniforms=null,this.material=null,e instanceof Rt?(this.uniforms=e.uniforms,this.material=e):e&&(this.uniforms=qa.clone(e.uniforms),this.material=new Rt({name:e.name!==void 0?e.name:"unspecified",defines:Object.assign({},e.defines),uniforms:this.uniforms,vertexShader:e.vertexShader,fragmentShader:e.fragmentShader})),this._fsQuad=new _f(this.material)}render(e,t,n){this.uniforms[this.textureID]&&(this.uniforms[this.textureID].value=n.texture),this._fsQuad.material=this.material,this.renderToScreen?(e.setRenderTarget(null),this._fsQuad.render(e)):(e.setRenderTarget(t),this.clear&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),this._fsQuad.render(e))}dispose(){this.material.dispose(),this._fsQuad.dispose()}}class Nd extends Gr{constructor(e,t){super(),this.scene=e,this.camera=t,this.clear=!0,this.needsSwap=!1,this.inverse=!1}render(e,t,n){const s=e.getContext(),r=e.state;r.buffers.color.setMask(!1),r.buffers.depth.setMask(!1),r.buffers.color.setLocked(!0),r.buffers.depth.setLocked(!0);let a,o;this.inverse?(a=0,o=1):(a=1,o=0),r.buffers.stencil.setTest(!0),r.buffers.stencil.setOp(s.REPLACE,s.REPLACE,s.REPLACE),r.buffers.stencil.setFunc(s.ALWAYS,a,4294967295),r.buffers.stencil.setClear(o),r.buffers.stencil.setLocked(!0),e.setRenderTarget(n),this.clear&&e.clear(),e.render(this.scene,this.camera),e.setRenderTarget(t),this.clear&&e.clear(),e.render(this.scene,this.camera),r.buffers.color.setLocked(!1),r.buffers.depth.setLocked(!1),r.buffers.color.setMask(!0),r.buffers.depth.setMask(!0),r.buffers.stencil.setLocked(!1),r.buffers.stencil.setFunc(s.EQUAL,1,4294967295),r.buffers.stencil.setOp(s.KEEP,s.KEEP,s.KEEP),r.buffers.stencil.setLocked(!0)}}class my extends Gr{constructor(){super(),this.needsSwap=!1}render(e){e.state.buffers.stencil.setLocked(!1),e.state.buffers.stencil.setTest(!1)}}class gy{constructor(e,t){if(this.renderer=e,this._pixelRatio=e.getPixelRatio(),t===void 0){const n=e.getSize(new Ie);this._width=n.width,this._height=n.height,t=new kn(this._width*this._pixelRatio,this._height*this._pixelRatio,{type:di}),t.texture.name="EffectComposer.rt1"}else this._width=t.width,this._height=t.height;this.renderTarget1=t,this.renderTarget2=t.clone(),this.renderTarget2.texture.name="EffectComposer.rt2",this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2,this.renderToScreen=!0,this.passes=[],this.copyPass=new py(za),this.copyPass.material.blending=ui,this.clock=new fg}swapBuffers(){const e=this.readBuffer;this.readBuffer=this.writeBuffer,this.writeBuffer=e}addPass(e){this.passes.push(e),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}insertPass(e,t){this.passes.splice(t,0,e),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}removePass(e){const t=this.passes.indexOf(e);t!==-1&&this.passes.splice(t,1)}isLastEnabledPass(e){for(let t=e+1;t<this.passes.length;t++)if(this.passes[t].enabled)return!1;return!0}render(e){e===void 0&&(e=this.clock.getDelta());const t=this.renderer.getRenderTarget();let n=!1;for(let s=0,r=this.passes.length;s<r;s++){const a=this.passes[s];if(a.enabled!==!1){if(a.renderToScreen=this.renderToScreen&&this.isLastEnabledPass(s),a.render(this.renderer,this.writeBuffer,this.readBuffer,e,n),a.needsSwap){if(n){const o=this.renderer.getContext(),c=this.renderer.state.buffers.stencil;c.setFunc(o.NOTEQUAL,1,4294967295),this.copyPass.render(this.renderer,this.writeBuffer,this.readBuffer,e),c.setFunc(o.EQUAL,1,4294967295)}this.swapBuffers()}Nd!==void 0&&(a instanceof Nd?n=!0:a instanceof my&&(n=!1))}}this.renderer.setRenderTarget(t)}reset(e){if(e===void 0){const t=this.renderer.getSize(new Ie);this._pixelRatio=this.renderer.getPixelRatio(),this._width=t.width,this._height=t.height,e=this.renderTarget1.clone(),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.renderTarget1=e,this.renderTarget2=e.clone(),this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2}setSize(e,t){this._width=e,this._height=t;const n=this._width*this._pixelRatio,s=this._height*this._pixelRatio;this.renderTarget1.setSize(n,s),this.renderTarget2.setSize(n,s);for(let r=0;r<this.passes.length;r++)this.passes[r].setSize(n,s)}setPixelRatio(e){this._pixelRatio=e,this.setSize(this._width,this._height)}dispose(){this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.copyPass.dispose()}}class vy extends Gr{constructor(e,t,n=null,s=null,r=null){super(),this.scene=e,this.camera=t,this.overrideMaterial=n,this.clearColor=s,this.clearAlpha=r,this.clear=!0,this.clearDepth=!1,this.needsSwap=!1,this._oldClearColor=new Re}render(e,t,n){const s=e.autoClear;e.autoClear=!1;let r,a;this.overrideMaterial!==null&&(a=this.scene.overrideMaterial,this.scene.overrideMaterial=this.overrideMaterial),this.clearColor!==null&&(e.getClearColor(this._oldClearColor),e.setClearColor(this.clearColor,e.getClearAlpha())),this.clearAlpha!==null&&(r=e.getClearAlpha(),e.setClearAlpha(this.clearAlpha)),this.clearDepth==!0&&e.clearDepth(),e.setRenderTarget(this.renderToScreen?null:n),this.clear===!0&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),e.render(this.scene,this.camera),this.clearColor!==null&&e.setClearColor(this._oldClearColor),this.clearAlpha!==null&&e.setClearAlpha(r),this.overrideMaterial!==null&&(this.scene.overrideMaterial=a),e.autoClear=s}}const _y={uniforms:{tDiffuse:{value:null},luminosityThreshold:{value:1},smoothWidth:{value:1},defaultColor:{value:new Re(0)},defaultOpacity:{value:0}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;

			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform sampler2D tDiffuse;
		uniform vec3 defaultColor;
		uniform float defaultOpacity;
		uniform float luminosityThreshold;
		uniform float smoothWidth;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );

			float v = luminance( texel.xyz );

			vec4 outputColor = vec4( defaultColor.rgb, defaultOpacity );

			float alpha = smoothstep( luminosityThreshold, luminosityThreshold + smoothWidth, v );

			gl_FragColor = mix( outputColor, texel, alpha );

		}`};class Ws extends Gr{constructor(e,t=1,n,s){super(),this.strength=t,this.radius=n,this.threshold=s,this.resolution=e!==void 0?new Ie(e.x,e.y):new Ie(256,256),this.clearColor=new Re(0,0,0),this.needsSwap=!1,this.renderTargetsHorizontal=[],this.renderTargetsVertical=[],this.nMips=5;let r=Math.round(this.resolution.x/2),a=Math.round(this.resolution.y/2);this.renderTargetBright=new kn(r,a,{type:di}),this.renderTargetBright.texture.name="UnrealBloomPass.bright",this.renderTargetBright.texture.generateMipmaps=!1;for(let u=0;u<this.nMips;u++){const d=new kn(r,a,{type:di});d.texture.name="UnrealBloomPass.h"+u,d.texture.generateMipmaps=!1,this.renderTargetsHorizontal.push(d);const h=new kn(r,a,{type:di});h.texture.name="UnrealBloomPass.v"+u,h.texture.generateMipmaps=!1,this.renderTargetsVertical.push(h),r=Math.round(r/2),a=Math.round(a/2)}const o=_y;this.highPassUniforms=qa.clone(o.uniforms),this.highPassUniforms.luminosityThreshold.value=s,this.highPassUniforms.smoothWidth.value=.01,this.materialHighPassFilter=new Rt({uniforms:this.highPassUniforms,vertexShader:o.vertexShader,fragmentShader:o.fragmentShader}),this.separableBlurMaterials=[];const c=[3,5,7,9,11];r=Math.round(this.resolution.x/2),a=Math.round(this.resolution.y/2);for(let u=0;u<this.nMips;u++)this.separableBlurMaterials.push(this._getSeparableBlurMaterial(c[u])),this.separableBlurMaterials[u].uniforms.invSize.value=new Ie(1/r,1/a),r=Math.round(r/2),a=Math.round(a/2);this.compositeMaterial=this._getCompositeMaterial(this.nMips),this.compositeMaterial.uniforms.blurTexture1.value=this.renderTargetsVertical[0].texture,this.compositeMaterial.uniforms.blurTexture2.value=this.renderTargetsVertical[1].texture,this.compositeMaterial.uniforms.blurTexture3.value=this.renderTargetsVertical[2].texture,this.compositeMaterial.uniforms.blurTexture4.value=this.renderTargetsVertical[3].texture,this.compositeMaterial.uniforms.blurTexture5.value=this.renderTargetsVertical[4].texture,this.compositeMaterial.uniforms.bloomStrength.value=t,this.compositeMaterial.uniforms.bloomRadius.value=.1;const l=[1,.8,.6,.4,.2];this.compositeMaterial.uniforms.bloomFactors.value=l,this.bloomTintColors=[new N(1,1,1),new N(1,1,1),new N(1,1,1),new N(1,1,1),new N(1,1,1)],this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors,this.copyUniforms=qa.clone(za.uniforms),this.blendMaterial=new Rt({uniforms:this.copyUniforms,vertexShader:za.vertexShader,fragmentShader:za.fragmentShader,blending:gn,depthTest:!1,depthWrite:!1,transparent:!0}),this._oldClearColor=new Re,this._oldClearAlpha=1,this._basic=new Ut,this._fsQuad=new _f(null)}dispose(){for(let e=0;e<this.renderTargetsHorizontal.length;e++)this.renderTargetsHorizontal[e].dispose();for(let e=0;e<this.renderTargetsVertical.length;e++)this.renderTargetsVertical[e].dispose();this.renderTargetBright.dispose();for(let e=0;e<this.separableBlurMaterials.length;e++)this.separableBlurMaterials[e].dispose();this.compositeMaterial.dispose(),this.blendMaterial.dispose(),this._basic.dispose(),this._fsQuad.dispose()}setSize(e,t){let n=Math.round(e/2),s=Math.round(t/2);this.renderTargetBright.setSize(n,s);for(let r=0;r<this.nMips;r++)this.renderTargetsHorizontal[r].setSize(n,s),this.renderTargetsVertical[r].setSize(n,s),this.separableBlurMaterials[r].uniforms.invSize.value=new Ie(1/n,1/s),n=Math.round(n/2),s=Math.round(s/2)}render(e,t,n,s,r){e.getClearColor(this._oldClearColor),this._oldClearAlpha=e.getClearAlpha();const a=e.autoClear;e.autoClear=!1,e.setClearColor(this.clearColor,0),r&&e.state.buffers.stencil.setTest(!1),this.renderToScreen&&(this._fsQuad.material=this._basic,this._basic.map=n.texture,e.setRenderTarget(null),e.clear(),this._fsQuad.render(e)),this.highPassUniforms.tDiffuse.value=n.texture,this.highPassUniforms.luminosityThreshold.value=this.threshold,this._fsQuad.material=this.materialHighPassFilter,e.setRenderTarget(this.renderTargetBright),e.clear(),this._fsQuad.render(e);let o=this.renderTargetBright;for(let c=0;c<this.nMips;c++)this._fsQuad.material=this.separableBlurMaterials[c],this.separableBlurMaterials[c].uniforms.colorTexture.value=o.texture,this.separableBlurMaterials[c].uniforms.direction.value=Ws.BlurDirectionX,e.setRenderTarget(this.renderTargetsHorizontal[c]),e.clear(),this._fsQuad.render(e),this.separableBlurMaterials[c].uniforms.colorTexture.value=this.renderTargetsHorizontal[c].texture,this.separableBlurMaterials[c].uniforms.direction.value=Ws.BlurDirectionY,e.setRenderTarget(this.renderTargetsVertical[c]),e.clear(),this._fsQuad.render(e),o=this.renderTargetsVertical[c];this._fsQuad.material=this.compositeMaterial,this.compositeMaterial.uniforms.bloomStrength.value=this.strength,this.compositeMaterial.uniforms.bloomRadius.value=this.radius,this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors,e.setRenderTarget(this.renderTargetsHorizontal[0]),e.clear(),this._fsQuad.render(e),this._fsQuad.material=this.blendMaterial,this.copyUniforms.tDiffuse.value=this.renderTargetsHorizontal[0].texture,r&&e.state.buffers.stencil.setTest(!0),this.renderToScreen?(e.setRenderTarget(null),this._fsQuad.render(e)):(e.setRenderTarget(n),this._fsQuad.render(e)),e.setClearColor(this._oldClearColor,this._oldClearAlpha),e.autoClear=a}_getSeparableBlurMaterial(e){const t=[];for(let n=0;n<e;n++)t.push(.39894*Math.exp(-.5*n*n/(e*e))/e);return new Rt({defines:{KERNEL_RADIUS:e},uniforms:{colorTexture:{value:null},invSize:{value:new Ie(.5,.5)},direction:{value:new Ie(.5,.5)},gaussianCoefficients:{value:t}},vertexShader:`varying vec2 vUv;
				void main() {
					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
				}`,fragmentShader:`#include <common>
				varying vec2 vUv;
				uniform sampler2D colorTexture;
				uniform vec2 invSize;
				uniform vec2 direction;
				uniform float gaussianCoefficients[KERNEL_RADIUS];

				void main() {
					float weightSum = gaussianCoefficients[0];
					vec3 diffuseSum = texture2D( colorTexture, vUv ).rgb * weightSum;
					for( int i = 1; i < KERNEL_RADIUS; i ++ ) {
						float x = float(i);
						float w = gaussianCoefficients[i];
						vec2 uvOffset = direction * invSize * x;
						vec3 sample1 = texture2D( colorTexture, vUv + uvOffset ).rgb;
						vec3 sample2 = texture2D( colorTexture, vUv - uvOffset ).rgb;
						diffuseSum += (sample1 + sample2) * w;
						weightSum += 2.0 * w;
					}
					gl_FragColor = vec4(diffuseSum/weightSum, 1.0);
				}`})}_getCompositeMaterial(e){return new Rt({defines:{NUM_MIPS:e},uniforms:{blurTexture1:{value:null},blurTexture2:{value:null},blurTexture3:{value:null},blurTexture4:{value:null},blurTexture5:{value:null},bloomStrength:{value:1},bloomFactors:{value:null},bloomTintColors:{value:null},bloomRadius:{value:0}},vertexShader:`varying vec2 vUv;
				void main() {
					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
				}`,fragmentShader:`varying vec2 vUv;
				uniform sampler2D blurTexture1;
				uniform sampler2D blurTexture2;
				uniform sampler2D blurTexture3;
				uniform sampler2D blurTexture4;
				uniform sampler2D blurTexture5;
				uniform float bloomStrength;
				uniform float bloomRadius;
				uniform float bloomFactors[NUM_MIPS];
				uniform vec3 bloomTintColors[NUM_MIPS];

				float lerpBloomFactor(const in float factor) {
					float mirrorFactor = 1.2 - factor;
					return mix(factor, mirrorFactor, bloomRadius);
				}

				void main() {
					gl_FragColor = bloomStrength * ( lerpBloomFactor(bloomFactors[0]) * vec4(bloomTintColors[0], 1.0) * texture2D(blurTexture1, vUv) +
						lerpBloomFactor(bloomFactors[1]) * vec4(bloomTintColors[1], 1.0) * texture2D(blurTexture2, vUv) +
						lerpBloomFactor(bloomFactors[2]) * vec4(bloomTintColors[2], 1.0) * texture2D(blurTexture3, vUv) +
						lerpBloomFactor(bloomFactors[3]) * vec4(bloomTintColors[3], 1.0) * texture2D(blurTexture4, vUv) +
						lerpBloomFactor(bloomFactors[4]) * vec4(bloomTintColors[4], 1.0) * texture2D(blurTexture5, vUv) );
				}`})}}Ws.BlurDirectionX=new Ie(1,0);Ws.BlurDirectionY=new Ie(0,1);function xy(i,e,t,{initial:n=.48,reducedMotion:s=!1}={}){const r={intensity:s?.23:n},a=new gy(i);a.renderToScreen=!1,a.setPixelRatio(1);const o=new Ws(new Ie(512,288),.72,.3,.72);a.addPass(new vy(e,t)),a.addPass(o);const c=new ef,l=new Hr(-1,1,1,-1,0,1),u=new Rt({depthTest:!1,depthWrite:!1,transparent:!0,blending:gn,toneMapped:!1,uniforms:{uTexture:{value:null},uOpacity:{value:r.intensity}},vertexShader:"varying vec2 vUv;void main(){vUv=uv;gl_Position=vec4(position.xy,0.0,1.0);}",fragmentShader:`uniform sampler2D uTexture; uniform float uOpacity;varying vec2 vUv;
      void main(){vec3 c=texture2D(uTexture,vUv).rgb;gl_FragColor=vec4(c*uOpacity,1.0);}`});c.add(new pt(new _n(2,2),u));function d(g,v,m=.34){const f=_e.clamp(m,.2,.5);a.setSize(Math.max(64,Math.floor(g*f)),Math.max(64,Math.floor(v*f)))}function h(g=!0,v=!0){if(!v){t.layers.set(0),i.setRenderTarget(null),i.render(e,t);return}g&&(t.layers.set(1),a.render(),t.layers.set(0),u.uniforms.uTexture.value=a.readBuffer.texture),i.setRenderTarget(null),i.render(e,t);const m=i.autoClear;i.autoClear=!1,i.render(c,l),i.autoClear=m}function p(g){r.intensity=_e.clamp(g,0,1.5),u.uniforms.uOpacity.value=r.intensity}return{state:r,render:h,resize:d,setIntensity:p}}const yy=1.32;function Sy(i,e){const t={uSkyActive:{value:0},uSkyBasis:{value:new $e},uSkyEye:{value:new Ie},uSkyCenter:{value:new Ie},uSkySize:{value:new Ie},uSkyDistance:{value:1},uSkyTanHalf:{value:1},uSkyAspect:{value:e.aspect},uSkyPan:{value:new Ie},uSkyZoom:{value:1}},n={active:!1,projection:"angular-sky",panX:0,panY:0,approach:0,zoom:1,newTextures:0,newSurfaces:0},s=new dt,r=new dt,a=new dt,o=new N,c=new N,l=new N,u=new N,d=new Ye,h=new vn(0,0,0,"YXZ");i.material.onBeforeCompile=v=>{Object.assign(v.uniforms,t),v.vertexShader=v.vertexShader.replace("#include <common>",`#include <common>
      varying vec2 vSkyScreen;`).replace("#include <project_vertex>",`#include <project_vertex>
      vSkyScreen=gl_Position.xy/gl_Position.w;`),v.fragmentShader=v.fragmentShader.replace("#include <common>",`#include <common>
      varying vec2 vSkyScreen;
      uniform float uSkyActive,uSkyDistance,uSkyTanHalf,uSkyAspect,uSkyZoom;
      uniform mat3 uSkyBasis;
      uniform vec2 uSkyEye,uSkyCenter,uSkySize,uSkyPan;`).replace("#include <map_fragment>",`
      if(uSkyActive>.5){
        // A projeção de partida fica fixa. O giro acrescenta o mesmo
        // deslocamento angular a todos os pixels, sem cisalhar a fotografia.
        // Zoom uniforme no espaço da tela, centrado na direção de chegada.
        // A mesma escala nos dois eixos conserva o formato durante o giro.
        vec2 screen=vSkyScreen/uSkyZoom;
        vec3 ray=uSkyBasis*vec3(screen.x*uSkyTanHalf*uSkyAspect,screen.y*uSkyTanHalf,-1.);
        vec2 uv=(uSkyEye+ray.xy*uSkyDistance/max(.00001,-ray.z)-uSkyCenter)/uSkySize+.5+uSkyPan;
        vec4 sky=texture2D(map,clamp(uv,vec2(0.),vec2(1.)));
        // Fora da região fotografada há céu escuro, sem repetir/esticar bordas.
        vec2 edge=smoothstep(vec2(0.),vec2(.035),uv)*(1.-smoothstep(vec2(.965),vec2(1.),uv));
        sky.rgb=mix(vec3(.0006,.0004,.0012),sky.rgb,edge.x*edge.y);
        diffuseColor*=sky;
      }else{
        #include <map_fragment>
      }`)},i.material.customProgramCacheKey=()=>"orion-angular-sky-v2",i.material.needsUpdate=!0;function p(){return n.active?!1:(e.updateWorldMatrix(!0,!1),i.updateWorldMatrix(!0,!1),e.getWorldPosition(o),e.getWorldQuaternion(s),r.copy(s).invert(),i.getWorldPosition(c),i.getWorldScale(l),t.uSkyBasis.value.setFromMatrix4(d.makeRotationFromQuaternion(s)),t.uSkyEye.value.set(o.x,o.y),t.uSkyCenter.value.set(c.x,c.y),t.uSkySize.value.set(l.x,l.y),t.uSkyDistance.value=o.z-c.z,t.uSkyTanHalf.value=Math.tan(_e.degToRad(e.fov/2)),e.add(i),i.quaternion.identity(),t.uSkyActive.value=1,n.active=!0,g(0),!0)}function g(v=n.approach){if(!n.active)return;n.approach=_e.clamp(Number.isFinite(v)?v:0,0,1),n.zoom=1+(yy-1)*n.approach,t.uSkyZoom.value=n.zoom,e.getWorldQuaternion(a),a.premultiply(r),h.setFromQuaternion(a,"YXZ"),u.set(-h.y,h.x,0).applyQuaternion(s);const m=t.uSkyDistance.value;t.uSkyPan.value.set(u.x*m/l.x,u.y*m/l.y),n.panX=t.uSkyPan.value.x,n.panY=t.uSkyPan.value.y,t.uSkyAspect.value=e.aspect;const f=Math.max(e.near*2,Math.min(100,e.far*.5)),_=2*f*Math.tan(_e.degToRad(e.fov/2));i.position.set(0,0,-f),i.scale.set(_*e.aspect*1.0001,_*1.0001,1),i.quaternion.identity()}return{begin:p,update:g,state:n,uniforms:t,photo:i}}const Rs=i=>Math.min(1,Math.max(0,i)),pr=(i,e,t)=>{const n=Rs((i-e)/(t-e));return n*n*n*(n*(n*6-15)+10)},by=2550,mr=(i,e,t)=>{const n=Rs((i-e)/(t-e));return n*n*(3-2*n)};function My({scene:i,camera:e,star:t,glows:n,layers:s,gasLayers:r,selectiveBloom:a,flash:o,reducedMotion:c,onArrive:l,sky:u=null}){const d=[{object:n.halo,scale:156,opacity:.22},{object:n.soft,scale:118,opacity:.3},{object:n.main,scale:66,opacity:.8},{object:n.core,scale:18,opacity:1}];let h=52,p=t.position.z;const g=new N(t.position.x,t.position.y,p+53),v=c?850:by,m=c?80:700,f=c?0:160,_=c?.7:.77,x=new N,y=new dt,A=new dt,E=new Ye,M=new N(0,1,0),C=a.state.intensity;let b=!1,S=!1,I=0,D=0,w=1;const U=r.map(be=>[be,be.material.uniforms.uStrength.value,1]),O=s.filter(be=>be.material?.opacity!==void 0).map(be=>[be,be.material.opacity,1]),F=[...new Set([...r,...s.filter(be=>be!==u?.photo&&be.material?.opacity!==void 0)])].map(be=>({layer:be,quaternion:new dt})),V=new N,k=new N,z=be=>k.copy(be.position).sub(e.position).dot(V),B=be=>mr(z(be),6,55),j=c?0:540,ne=new Float32Array(j*6),Q=new Float32Array(j*6),re=[],ce=[new Re("#c8d5ff"),new Re("#9f8dd8"),new Re("#fce1b4")];for(let be=0;be<j;be++){const L=Math.random()*Math.PI*2,Ue=6+Math.sqrt(Math.random())*100,me=Math.cos(L)*Ue,ae=Math.sin(L)*Ue*.65,le=-14-Math.random()*200,Ne=3+Math.random()*18,pe=.65+Math.random()*.8;re.push({x:me,y:ae,z:le,len:Ne,speed:pe});const Ae=ce[be%ce.length],He=be*6;for(let ke=0;ke<2;ke++)Q[He+ke*3]=Ae.r,Q[He+ke*3+1]=Ae.g,Q[He+ke*3+2]=Ae.b}const G=new It;G.setAttribute("position",new ct(ne,3).setUsage(qh)),G.setAttribute("color",new ct(Q,3));const Y=new Vc({vertexColors:!0,transparent:!0,opacity:0,depthTest:!1,depthWrite:!1,blending:gn}),ie=new rf(G,Y);ie.frustumCulled=!1,ie.renderOrder=18,ie.visible=!1,e.add(ie);function ye(be,L){if(b||S)return!1;t=be,n=L,p=t.position.z,g.set(t.position.x,t.position.y,p+53);for(const[Ue,me]of["halo","soft","main","core"].entries())d[Ue].object=n[me];return!0}function se(be=performance.now()){if(b||S)return!1;e.updateWorldMatrix(!0,!1),i.attach(e),e.updateWorldMatrix(!0,!1),x.copy(e.position),y.copy(e.quaternion),h=e.fov,u?.begin(),w=1,V.set(0,0,-1).applyQuaternion(e.quaternion);for(const L of F)L.quaternion.copy(L.layer.quaternion);for(const L of U)L[1]=L[0].material.uniforms.uStrength.value,L[2]=B(L[0]);for(const L of O)L[1]=L[0].material.opacity,L[2]=B(L[0]);g.copy(x).lerp(t.position,(x.z-(p+53))/(x.z-p));for(const L of d)L.startScale=L.object.scale.x,L.startOpacity=L.object.material.opacity;return E.lookAt(x,t.position,M),A.setFromRotationMatrix(E),I=be,b=!0,D=0,ie.visible=!c,!0}function Le(be,L){if(!b)return 0;const Ue=be-I,me=Rs(Ue/v);D=me;const ae=Rs((Ue-m)/(v-m));w=c?0:1-pr(Ue,0,f);const le=pr(ae,0,1),Ne=_e.lerp(x.x,g.x,le),pe=_e.lerp(x.y,g.y,le);e.position.set(Ne,pe,_e.lerp(x.z,g.z,le)),e.quaternion.slerpQuaternions(y,A,pr(Ue,f,m));const Ae=pr(Ue,0,m);e.fov=_e.lerp(h,52,Ae)+(c?0:4*Math.sin(Math.PI*ae)**2),e.updateProjectionMatrix(),u?.update(c?0:le),V.set(0,0,-1).applyQuaternion(e.quaternion);const He=c?1:1+1.4*pr(ae,0,.35);for(const{layer:$,quaternion:xe}of F)$.quaternion.slerpQuaternions(xe,e.quaternion,Ae);for(const[$,xe,oe]of U)$.material.uniforms.uStrength.value=xe*He*Rs(B($)/Math.max(1e-6,oe));for(const[$,xe,oe]of O)$===u?.photo||$.position.z<p-25||($.material.opacity=Math.min(1,xe*He*Rs(B($)/Math.max(1e-6,oe))));const ke=mr(me,_,.995),P=Math.max(35,e.position.distanceTo(t.position)),T=Math.max(1,x.distanceTo(t.position)),q=P/T,J=1+ke*ke*22;for(const $ of d)$.object.scale.setScalar(_e.lerp($.startScale,$.scale*q*J,Ae));for(const[$,xe]of[.2+.47*ke,.3+.47*ke,.85+.22*ke,1].entries())d[$].object.material.opacity=_e.lerp(d[$].startOpacity,xe,Ae);a.setIntensity(Math.min(1.5,C+.75*ke));const te=140+1700*Math.pow(ae,1.7);for(let $=0;$<re.length;$++){const xe=re[$];xe.z+=L*te*xe.speed,xe.z>2&&(xe.z=-220-Math.random()*45);const oe=$*6;ne[oe]=xe.x,ne[oe+1]=xe.y,ne[oe+2]=xe.z,ne[oe+3]=xe.x,ne[oe+4]=xe.y,ne[oe+5]=xe.z-Math.min(28,xe.len*(1+2.2*ae))}return G.attributes.position.needsUpdate=!0,Y.opacity=c?0:mr(ae,0,.18)*(.04+.5*mr(ae,0,.55))*(1-ke*.88),o.style.opacity=String(ke),o.style.setProperty("--veil-opacity",String(mr(me,.9,1))),me>=1&&!S&&(S=!0,b=!1,l()),me}return{begin:se,update:Le,setDestination:ye,get active(){return b},get progress(){return D},get companionOpacity(){return w},get streakCount(){return j},get passedLayers(){return r.filter(be=>e.position.z<be.position.z).length}}}const Xs=i=>Math.max(0,Math.min(1,i)),Ot=(i,e,t)=>{const n=Xs((i-e)/(t-e));return Xs(n*n*n*(n*(n*6-15)+10))},Ey=1.12,Ty=.16,Ay=.78;function xf(i,e=!1){const t=Xs(i/(e?Ty:Ey));if(e)return{progress:t,reach:0,press:0,anticipation:0,followThrough:0,lift:0,charge:0,burst:0,light:t<1?.3:0};const n=Ot(t,0,.07)*(1-Ot(t,.1,.24)),s=Ot(t,.08,.4)*(1-Ot(t,.68,1)),r=Ot(t,.05,.28)*(1-Ot(t,.57,.94)),a=Ot(t,.32,.49)*(1-Ot(t,.6,.88)),o=Ot(t,.6,.78)*(1-Ot(t,.86,1)),c=Ot(t,0,.34)*(1-Ot(t,.44,.64)),l=Ot(t,.32,.49)*(1-Ot(t,.6,.98)),u=1-(1-.65*c)*(1-.95*l);return{progress:t,reach:s,press:a,anticipation:n,followThrough:o,lift:r,charge:c,burst:l,light:u}}function Od(i,e,t=Math.PI*2){const n=new uo(i,1,e,4,0,t),s=n.attributes.position,r=new Float32Array(s.count*4);for(let a=0;a<s.count;a++){const o=s.getX(a),c=s.getY(a),l=Math.hypot(o,c),u=Math.sin(Math.PI*Xs((l-i)/(1-i)))**2;let d=Math.atan2(c,o);d<0&&(d+=Math.PI*2);const h=t<Math.PI*2?Math.sin(Math.PI*Xs(d/t))**2:1;r.set([1,1,1,u*h],a*4)}return n.setAttribute("color",new nt(r,4)),n}function wy(i,{camera:e,hands:t,reducedMotion:n=!1,onConfirm:s,onDepart:r}){const a={active:!1,completed:!1,departed:!1,elapsed:0,progress:0,reach:0,press:0,anticipation:0,followThrough:0,lift:0,charge:0,burst:0,light:0,activations:0,surfaces:0,triangles:0},o=new At;o.name="NoxSelectionLight",o.visible=!1,i.add(o);const c=[],l=[],u=[],d=new Set,h=new dt,p=new dt,g=new Re(16113064),v=new Re(12166639);let m=null,f=null,_=!1,x=!1;function y(b,S,I){d.add(b);const D=new Ut({color:S,vertexColors:!0,transparent:!0,opacity:0,side:Mt,depthTest:!1,depthWrite:!1,blending:gn,toneMapped:!1,forceSinglePass:!0}),w=new pt(b,D);return w.renderOrder=15,w.frustumCulled=!1,w.userData.selectionType=I,o.add(w),l.push(w),w}function A(){if(l.length)return;const b=Od(.86,96);for(const S of[g,v])c.push(y(b,S,"wave"));if(!n){const S=Od(.91,80,Math.PI*1.65);for(const V of[v,g])u.push(y(S,V,"ribbon"));const I=[],D=[];for(let V=0;V<12;V++){const k=V*Math.PI/6+.12,z=V%3===0?78:V%2===0?54:35,B=V%3===0?1.9:1.1,j=V%2?v:g;for(const[ne,Q,re]of[[8,0,0],[18,-B,0],[18,0,.85],[18,-B,0],[z,0,0],[18,0,.85],[8,0,0],[18,0,.85],[18,B,0],[18,B,0],[18,0,.85],[z,0,0]])I.push(Math.cos(k)*ne-Math.sin(k)*Q,Math.sin(k)*ne+Math.cos(k)*Q,0),D.push(j.r,j.g,j.b,re)}const w=new It;w.setAttribute("position",new nt(I,3)),w.setAttribute("color",new nt(D,4)),m=y(w,16777215,"corona");const U=new It,O=new Float32Array(648),F=new Float32Array(864);for(let V=0;V<18;V++)for(let k=0;k<12;k++){const z=V%2?v:g,B=k%3===1?.9:0;F.set([z.r,z.g,z.b,B],(V*12+k)*4)}U.setAttribute("position",new ct(O,3).setUsage(qh)),U.setAttribute("color",new nt(F,4)),f=y(U,16777215,"motes")}a.surfaces=l.length,a.triangles=[...l].reduce((S,I)=>S+(I.geometry.index?.count??I.geometry.attributes.position.count)/3,0)}function E(){return _||a.active||a.completed?!1:(A(),a.active=!0,a.activations++,o.visible=!0,t.setStarSelection?.({reach:0,press:0}),M(0),x=n,!0)}function M(b){if(!(!a.active||_)){x&&(x=!1,b=0),a.elapsed+=Math.max(0,n?b:Math.min(b,.1)),Object.assign(a,xf(a.elapsed,n)),t.setStarSelection?.(a),i.getWorldQuaternion(h),e.getWorldQuaternion(p),o.quaternion.copy(h.invert().multiply(p));for(let S=0;S<c.length;S++){const I=S*.28,D=Xs((a.progress-I)/(1-I));c[S].scale.setScalar(n?20:10+(S===0?68:80)*(1-(1-D)**2)),c[S].material.opacity=n?S===0?a.light:0:(S===0?.58:.4)*Ot(D,0,.14)*(1-Ot(D,.42,1))}if(!n){const S=a.progress,I=Ot(S,.46,1);for(let F=0;F<u.length;F++){const V=u[F],k=_e.lerp(38,23,a.charge)+26*I;V.scale.setScalar(k),V.rotation.set(F===0?.85:-.95,F===0?.3:-.35,(F===0?1:-1)*(.35+S*1.8)),V.material.opacity=(F===0?.52:.42)*a.light}m.rotation.z=-.08+S*.18,m.scale.setScalar(.65+.55*I),m.material.opacity=.62*a.burst;const D=f.geometry.attributes.position,w=_e.lerp(64,14,Ot(S,0,.44)),U=14+98*(1-(1-I)**2),O=_e.lerp(w,U,Ot(S,.44,.54));for(let F=0;F<18;F++){const V=F*Math.PI*2/18+.17+S*.85,k=.82+F%5*.09,z=O*k,B=.65+F%3*.17,j=2.2+5*I,ne=Math.cos(V)*z,Q=Math.sin(V)*z;for(const[re,[ce,G]]of[[-j,0],[0,0],[0,-B],[0,-B],[0,0],[j,0],[j,0],[0,0],[0,B],[0,B],[0,0],[-j,0]].entries())D.setXYZ(F*12+re,ne+Math.cos(V)*ce-Math.sin(V)*G,Q+Math.sin(V)*ce+Math.cos(V)*G,0)}D.needsUpdate=!0,f.material.opacity=.72*(1-(1-.75*a.charge)*(1-a.burst))}!n&&r&&!a.departed&&a.progress>=Ay&&(a.departed=!0,r()),a.progress>=1&&(a.active=!1,a.completed=!0,o.visible=!1,t.setStarSelection?.(null),s?.())}}function C(){if(!_){_=!0,a.active=!1,o.visible=!1,t.setStarSelection?.(null);for(const b of d)b.dispose();for(const b of l)b.material.dispose();i.remove(o)}}return{state:a,root:o,rings:c,effects:l,begin:E,update:M,dispose:C}}function Ry(){const i=document.createElement("canvas");i.width=i.height=512;const e=i.getContext("2d");if(!e)throw Error("Canvas 2D indisponível para o flare da estrela");const t=256;e.translate(t,t),e.globalCompositeOperation="lighter";const n=e.createRadialGradient(0,0,2,0,0,90);n.addColorStop(0,"rgba(255,249,226,.30)"),n.addColorStop(.11,"rgba(247,223,185,.18)"),n.addColorStop(.36,"rgba(199,179,223,.043)"),n.addColorStop(1,"rgba(199,179,223,0)"),e.fillStyle=n,e.fillRect(-96,-96,192,192);function s(a,o,c,l){e.save(),e.rotate(a);for(const[u,d]of[[l*3.4,.1],[l,.48],[.55,1]]){const h=e.createLinearGradient(0,0,o,0),p=c*d;h.addColorStop(0,`rgba(255,252,239,${Math.min(1,p)})`),h.addColorStop(.08,`rgba(255,242,211,${p*.75})`),h.addColorStop(.34,`rgba(228,217,246,${p*.32})`),h.addColorStop(.7,`rgba(205,202,255,${p*.12})`),h.addColorStop(1,"rgba(205,202,255,0)"),e.fillStyle=h,e.beginPath(),e.moveTo(0,-u),e.lineTo(o,0),e.lineTo(0,u),e.closePath(),e.fill()}e.restore()}for(let a=0;a<4;a++)s(a*Math.PI/2,231,.48,1.6);for(let a=0;a<4;a++)s(Math.PI/4+a*Math.PI/2,119,.15,.72);const r=new co(i);return r.colorSpace=_t,r.minFilter=Gt,r.magFilter=Lt,r.generateMipmaps=!0,r}function yf(i,{reducedMotion:e=!1,sharedTexture:t=null}={}){const n=t??Ry();function s(h,p,g){const v=new kr({map:n,transparent:!0,opacity:p,depthTest:!1,depthWrite:!1,blending:gn,toneMapped:!1}),m=new oo(v);return m.scale.setScalar(h),m.renderOrder=g,i.add(m),m}const r=s(174,.31,11),a=s(123,.085,11);let o=0,c=0,l=null;function u(h,p,g){const v=l===null?0:Math.max(0,Math.min(.1,h-l));l=h;const m=e?1:1-Math.exp(-v*12);o+=((p?1:0)-o)*m,c+=((g?1:0)-c)*m;const f=e?0:Math.sin(h*.79+.9),_=e?0:Math.sin(h*2.11+.7)*.55+Math.sin(h*3.16+2.3)*.45;r.material.rotation=e?.11:.11+h*.019,a.material.rotation=e?-.3:-.3-h*.012,r.material.opacity=.28-.16*c+.04*f+.032*_+.09*o,a.material.opacity=.075-.03*c+.012*f+.035*o,r.scale.setScalar(174*(1+.018*f+.045*o)),a.scale.setScalar(123*(1+.025*_))}function d(){r.material.dispose(),a.material.dispose(),t||n.dispose()}return{primary:r,secondary:a,update:u,dispose:d}}const Cy=Object.freeze([{id:"01",name:"Massa distante",u:.19,v:.51,w:.23,h:.27,z:-425,opacity:.18,rate:.27,phase:.6,drift:1.5,parallaxX:2.2,parallaxY:.8},{id:"02",name:"Nuvem central",u:.41,v:.52,w:.25,h:.32,z:-342,opacity:.23,rate:.22,phase:1.9,drift:2.1,parallaxX:5.2,parallaxY:2.1},{id:"03",name:"Filamento lateral",u:.61,v:.53,w:.23,h:.3,z:-252,opacity:.19,rate:.3,phase:3,drift:2.9,parallaxX:9,parallaxY:3.1},{id:"04",name:"Véu avançado",u:.8,v:.53,w:.22,h:.26,z:-185,opacity:.14,rate:.36,phase:4.2,drift:3.6,parallaxX:16.5,parallaxY:6.2},{id:"05",name:"Bruma intermediária esquerda",u:.28,v:.43,w:.18,h:.24,z:-130,opacity:.1,rate:.25,phase:5.4,drift:1.2,parallaxX:12,parallaxY:4},{id:"06",name:"Filamento próximo direito",u:.66,v:.61,w:.2,h:.27,z:-42,opacity:.055,rate:.32,phase:6.7,drift:.65,parallaxX:8,parallaxY:3}]);function Iy(i,e,{reducedMotion:t=!1,parallaxEnabled:n=!0,foregroundEnabled:s=!0}={}){const r=new Qs,a=Cy.map((g,v)=>{const m=new Ut({transparent:!0,opacity:g.opacity,depthTest:!1,depthWrite:!1,side:Mt,forceSinglePass:v>=4,blending:Ci,toneMapped:!1}),f=new pt(new _n(1,1),m);return f.position.z=g.z,f.renderOrder=2.11+v*.08,f.visible=!1,f.userData.layerName="Foto ESO em volume · "+g.name,f.userData.volumeFragment=!0,f.userData.spec=g,f.userData.loaded=!1,f.userData.parallaxOffsetX=0,f.userData.parallaxOffsetY=0,f.userData.baseScaleX=1,f.userData.baseScaleY=1,i.add(f),f}),o={active:0,loaded:0,parallaxEnabled:n&&!t,parallaxStrength:1,foregroundEnabled:s};function c(g){const v=Number(g);Number.isFinite(v)&&(o.parallaxStrength=_e.clamp(v,.45,1.6))}function l(g){if(g.userData.loaded)return;g.userData.loaded=!0;const v=g.userData.spec.id,m=r.load("/assets/depth/eso-gas-"+v+".webp",void 0,void 0,f=>{console.warn("[Nebulosa em volume] falha ao carregar recorte",v,f),g.visible=!1});m.colorSpace=_t,m.anisotropy=1,m.minFilter=Gt,m.magFilter=Lt,g.material.map=m,g.material.needsUpdate=!0,o.loaded++}function u(g){const v=g==="eco-plus"?o.foregroundEnabled?[1,2,3,4,5]:[1,3]:["lite","eco"].includes(g)?[1,3]:g==="high"?[0,1,2,3,4,5]:[0,1,2,4,5];a.forEach((m,f)=>{const _=g==="eco-plus"&&o.foregroundEnabled&&f===2,x=m.userData.spec;m.position.z=_?-75:x.z,m.userData.opacityFactor=_?.38:1,m.material.opacity=x.opacity*m.userData.opacityFactor,m.renderOrder=2.11+(425+m.position.z)*8e-4,m.visible=v.includes(f),m.visible&&l(m)}),o.active=v.length}function d(){const g=26-e.position.z;for(const v of a){const m=v.userData.spec,f=(26-v.position.z)/g;v.userData.baseX=e.position.x+(m.u-.5)*e.scale.x*f,v.userData.baseY=e.position.y+(.5-m.v)*e.scale.y*f,v.position.x=v.userData.baseX,v.position.y=v.userData.baseY,v.userData.baseScaleX=e.scale.x*m.w*f*1.008,v.userData.baseScaleY=e.scale.y*m.h*f*1.008,v.scale.set(v.userData.baseScaleX,v.userData.baseScaleY,1)}}function h(g,v=0,m=0,f=1/60){const _=o.parallaxEnabled,x=_?1-Math.exp(-Math.max(0,Math.min(.1,f))*14):1,y=_?_e.clamp(v,-1,1):0,A=_?_e.clamp(m,-1,1):0;for(const E of a){if(!E.visible)continue;const M=E.userData.spec,C=t?0:Math.sin(g*M.rate+M.phase),b=t?0:Math.sin(g*M.rate*.55+M.phase*1.43),S=E.userData;S.parallaxOffsetX+=(-y*M.parallaxX*o.parallaxStrength-S.parallaxOffsetX)*x,S.parallaxOffsetY+=(-A*M.parallaxY*o.parallaxStrength-S.parallaxOffsetY)*x,E.position.x=S.baseX+b*M.drift+S.parallaxOffsetX,E.position.y=S.baseY+C*M.drift*.32+S.parallaxOffsetY;const I=t?0:.003*Math.sin(g*M.rate*.67+M.phase);E.scale.x=S.baseScaleX*(1+I),E.scale.y=S.baseScaleY*(1+I*.6),E.material.opacity=M.opacity*S.opacityFactor*(1+C*.085)}}function p(){for(const g of a)g.material.map?.dispose(),g.material.dispose(),g.geometry.dispose(),i.remove(g)}return{layers:a,state:o,resize:d,update:h,applyQuality:u,dispose:p,setParallaxStrength:c}}const Zc="orion-observatorio-hands-ab-v1";function Py(i){return JSON.stringify({quality:i.quality,effects:i.effects,bloomRest:i.bloomRest,viewport:i.viewport,dpr:i.dpr,canvasPixels:i.canvasPixels,gasLayers:i.gasLayers,volumeLayers:i.volumeLayers,foregroundNear:i.foregroundNear,depthMotion:i.depthMotion,parallaxStrength:i.parallaxStrength})}function Ud(i,e){if(!i||!e)return{ok:!1,reason:"Faltam medições dos dois modos."};if(i.mode!=="off"||e.mode!=="fps")return{ok:!1,reason:"Modos A/B inválidos."};if(i.signature!==e.signature)return{ok:!1,reason:"Configurações ou resolução diferentes. Limpe as medições e repita no mesmo tamanho de janela."};for(const t of[i.fps,i.p95Ms,e.fps,e.p95Ms])if(!Number.isFinite(t))return{ok:!1,reason:"Medições incompletas."};return{ok:!0,fpsDifference:e.fps-i.fps,p95Difference:+(e.p95Ms-i.p95Ms).toFixed(1),drawCallsDifference:(e.drawCalls??0)-(i.drawCalls??0),texturesDifference:(e.textures??0)-(i.textures??0)}}function cl(){try{const i=JSON.parse(sessionStorage.getItem(Zc)||"{}");return i&&typeof i=="object"?i:{}}catch{return{}}}function Ly(i){try{return sessionStorage.setItem(Zc,JSON.stringify(i)),!0}catch{return!1}}function Dy(i,e){const t=document.createElement("section");t.className="perf-ab-inspector",t.setAttribute("aria-label","Benchmark local das mãos FPS");const n=document.createElement("strong");n.textContent="Comparação A/B · mãos FPS";const s=document.createElement("small");s.textContent="Mesmo PC e janela: espere 10 s com a aba visível, registre uma amostra, mude de modo e registre a outra. Repita para confirmar. Não mede VRAM nem FPS efetivamente exibido pela GPU.";const r=document.createElement("output");r.id="orionHandsABResult",r.className="perf-values",r.setAttribute("aria-live","polite");const a=document.createElement("button");a.id="orionHandsABCapture",a.className="perf-copy",a.type="button",a.textContent="Registrar amostra atual";const o=document.createElement("a");o.id="orionHandsABSwitch",o.className="perf-depth-compare";const c=document.createElement("button");c.id="orionHandsABClear",c.className="perf-copy",c.type="button",c.textContent="Limpar comparativo";const l=document.createElement("small");l.id="orionHandsABStatus",l.setAttribute("aria-live","polite");const u=new URLSearchParams(location.search),d=u.get("hands")==="off",h=new URL(location.href);h.searchParams.set("debug","1"),h.searchParams.set("quality","eco-plus"),h.searchParams.set("hands",d?"fps":"off"),h.searchParams.set("fpsStyle","frame"),h.searchParams.delete("fpsTune"),o.href=h.pathname+h.search,o.textContent=d?"Testar com mãos FPS":"Testar sem mãos FPS",t.append(n,s,r,a,o,c,l),i.appendChild(t);function p(){const v=cl(),m=v.off,f=v.fps;if(!m&&!f)return"Comparativo A/B: sem dados registrados.";const _=y=>y?"FPS "+y.fps+" | p95 "+y.p95Ms+" ms | >33 ms "+y.longFrames+"% | draw calls "+y.drawCalls+" | texturas "+y.textures+" | amostras "+y.samples+" | viewport "+y.viewport:"pendente",x=Ud(m,f);return["Observatório · mãos FPS · comparação local A/B","Sem mãos: "+_(m),"David Fischer (natural): "+_(f),x.ok?"Diferença com mãos menos sem mãos: FPS "+(x.fpsDifference>=0?"+":"")+x.fpsDifference+" | p95 "+(x.p95Difference>=0?"+":"")+x.p95Difference+" ms | draw calls "+(x.drawCallsDifference>=0?"+":"")+x.drawCallsDifference+" | texturas "+(x.texturesDifference>=0?"+":"")+x.texturesDifference:"Comparação pendente: "+x.reason,"Amostras do loop da página, não benchmark de GPU. Repetir pares A/B na mesma janela."].join(`
`)}function g(){const v=cl(),m=Ud(v.off,v.fps);m.ok?r.textContent="FPS: sem mãos "+v.off.fps+" → com mãos "+v.fps.fps+" ("+(m.fpsDifference>=0?"+":"")+m.fpsDifference+`)
p95: `+v.off.p95Ms+" → "+v.fps.p95Ms+" ms ("+(m.p95Difference>=0?"+":"")+m.p95Difference+` ms)
Draw calls: `+v.off.drawCalls+" → "+v.fps.drawCalls+" | Texturas: "+v.off.textures+" → "+v.fps.textures:r.textContent="Sem mãos: "+(v.off?"registrado":"pendente")+" · Com mãos FPS: "+(v.fps?"registrado":"pendente")+`
`+(v.off&&v.fps?m.reason:"Aguardando duas amostras comparáveis.")}return a.addEventListener("click",()=>{const v=e(),m=u.get("hands")==="off",f=m?"off":"fps";if(document.hidden){l.textContent="Volte para a aba visível antes de medir.";return}if(v.quality!=="eco-plus"){l.textContent="Selecione Eco+ para comparar com resolução fixa.";return}if(!m&&(v.handsMode!=="fps"||!v.handsVisible||!v.handsReady||v.handsLoadError)){l.textContent="O modelo FPS ainda não está pronto para a medição.";return}if(m&&v.handsVisible){l.textContent="Desligue as mãos antes de medir o modo sem mãos.";return}if(performance.now()<1e4||v.samples<30||!Number.isFinite(v.fps)||!Number.isFinite(v.p95Ms)){l.textContent="Espere pelo menos 10 s de cena carregada e 30 quadros de amostra.";return}const _={mode:f,signature:Py(v),fps:v.fps,p95Ms:v.p95Ms,longFrames:v.longFrames,drawCalls:v.drawCalls,textures:v.textures,samples:v.samples,viewport:v.viewport,quality:v.quality,recordedAt:new Date().toISOString()},x=cl();if(x[f]=_,!Ly(x)){l.textContent="Armazenamento da aba bloqueado. Não foi possível preservar a comparação.";return}l.textContent="Amostra "+(f==="fps"?"com mãos FPS":"sem mãos")+" registrada nesta aba.",g()}),c.addEventListener("click",()=>{try{sessionStorage.removeItem(Zc)}catch{}l.textContent="Comparação limpa.",g()}),g(),{report:p}}function Ny(i,e){const t=document.createElement("fieldset");t.className="layer-inspector perf-inspector";const n=document.createElement("legend");n.textContent="Diagnóstico de fluidez · prévia";const s=document.createElement("output");s.id="orionPerfReadout",s.className="perf-values",s.setAttribute("aria-label","Indicadores de desempenho locais"),s.textContent="Coletando amostras do seu navegador…";const r=document.createElement("small");r.textContent="FPS medido na aba, não pela GPU. Texturas e draw calls não representam RAM/VRAM. Para memória total: Shift+Esc no Chrome.";const a=document.createElement("button");a.type="button",a.className="perf-copy",a.textContent="Copiar diagnóstico";const o=document.createElement("small");o.className="perf-copy-status",o.setAttribute("aria-live","polite"),t.append(n,s,r,a,o);const c=document.createElement("nav");c.className="perf-comparisons",c.setAttribute("aria-label","Comparação de custos de renderização");const l=[{label:"Lite original · 950k px",quality:"lite",effects:null},{label:"Lite sem gás GLSL",quality:"lite",effects:"no-gas"},{label:"Eco+ · 670k px + bloom",quality:"eco-plus",effects:null},{label:"Eco+ sem bloom",quality:"eco-plus",effects:"no-bloom"},{label:"Eco · 500k px",quality:"eco",effects:null}];for(const z of l){const B=new URL(window.location.href);B.searchParams.set("debug","1"),B.searchParams.set("quality",z.quality),B.searchParams.delete("depthMotion"),z.effects?B.searchParams.set("effects",z.effects):B.searchParams.delete("effects");const j=document.createElement("a");j.href=B.pathname+B.search,j.textContent=z.label,z.quality===new URLSearchParams(location.search).get("quality")&&(z.effects||"normal")===(new URLSearchParams(location.search).get("effects")||"normal")&&new URLSearchParams(location.search).get("depthMotion")!=="off"&&j.setAttribute("aria-current","page"),c.appendChild(j)}const u=document.createElement("small");u.textContent="Compare após ~10 s em cada modo e repita as medições. Lite sem gás e Eco+ preservam o bloom: a diferença isola principalmente a resolução; Eco+ sem bloom mostra o custo do bloom na mesma resolução.";const d=document.createElement("a"),h=new URL(window.location.href);h.searchParams.set("debug","1"),h.searchParams.set("quality","eco-plus"),h.searchParams.delete("effects"),new URLSearchParams(location.search).get("depthMotion")==="off"?(h.searchParams.delete("depthMotion"),d.textContent="Ativar profundidade orgânica · Eco+"):(h.searchParams.set("depthMotion","off"),d.textContent="Comparar profundidade original · Eco+"),d.href=h.pathname+h.search,d.className="perf-depth-compare";const p=document.createElement("a"),g=new URL(window.location.href);g.searchParams.set("debug","1"),g.searchParams.set("quality","eco-plus"),g.searchParams.delete("effects"),new URLSearchParams(location.search).get("foreground")==="off"?(g.searchParams.delete("foreground"),p.textContent="Ativar véu próximo · Eco+"):(g.searchParams.set("foreground","off"),p.textContent="Comparar sem véu próximo · Eco+"),p.href=g.pathname+g.search,p.className="perf-depth-compare";const m=document.createElement("a"),f=new URL(window.location.href);f.searchParams.set("debug","1"),f.searchParams.set("quality","eco-plus"),new URLSearchParams(location.search).get("hands")==="off"?(f.searchParams.set("hands","fps"),f.searchParams.set("fpsStyle","frame"),f.searchParams.delete("fpsTune"),m.textContent="Ativar mãos FPS David Fischer · Eco+"):(f.searchParams.set("hands","off"),m.textContent="Comparar sem mãos · Eco+"),m.href=f.pathname+f.search,m.className="perf-depth-compare";const x=document.createElement("nav");x.className="perf-comparisons",x.setAttribute("aria-label","Comparar modelos das mãos");const y=new URLSearchParams(location.search).get("hands")||"fps";for(const{mode:z,label:B}of[{mode:"fps",label:"David Fischer · FPS (CC BY)"},{mode:"vr",label:"Mãos anatômicas VR · MIT"},{mode:"rig",label:"WRAD retrô · 50 ossos"},{mode:"3d",label:"Modelo 3D anterior"},{mode:"2d",label:"Silhueta 2,5D"},{mode:"off",label:"Sem mãos"}]){const j=new URL(window.location.href);j.searchParams.set("quality","eco-plus"),j.searchParams.set("debug","1"),j.searchParams.set("hands",z);const ne=document.createElement("a");ne.href=j.pathname+j.search,ne.textContent=B,(z===y||z==="fps"&&y==="on")&&ne.setAttribute("aria-current","page"),x.appendChild(ne)}t.append(u,c,d,p,x,m),i.appendChild(t);const A=360,E=4e3,M=new Array(A);let C=0,b=0,S=-1/0,I=null;function D(){b=0,C=0,S=-1/0,I=null,s.textContent="Coletando amostras do seu navegador…"}function w(z,B){if(!(!Number.isFinite(z)||!Number.isFinite(B)||B<=0)){if(B>1e3){D();return}M[C]={t:z,dt:B},C=(C+1)%A,b=Math.min(A,b+1)}}function U(z=performance.now()){const B=[];for(let re=0;re<b;re++){const ce=M[(C-b+re+A)%A];z-ce.t<=E&&B.push(ce.dt)}B.sort((re,ce)=>re-ce);const j=B.reduce((re,ce)=>re+ce,0),ne=e(),Q=typeof performance.memory?.usedJSHeapSize=="number"?Math.round(performance.memory.usedJSHeapSize/1048576):null;return{fps:j>0?Math.round(1e3*B.length/j):null,p95Ms:B.length?Math.round(B[Math.min(B.length-1,Math.ceil(B.length*.95)-1)]*10)/10:null,longFrames:B.length?Math.round(100*B.filter(re=>re>33.3).length/B.length):null,samples:B.length,jsHeapMB:Q,...ne}}function O(z){return["FPS médio (~4s): "+(z.fps??"—"),"Quadro p95: "+(z.p95Ms??"—")+" ms","Quadros acima de 33 ms: "+(z.longFrames??"—")+"%","Perfil: "+z.quality+" · DPR: "+z.dpr,"Efeitos: "+z.effects+" · bloom em repouso: "+(z.bloomRest?"sim":"não"),"Pixels do canvas: "+z.canvasPixels,"Camadas: "+z.gasLayers+" gás / "+z.volumeLayers+" recortes","Véu frontal próximo da câmera: "+(z.foregroundNear?"sim":"não"),"Mãos em primeira pessoa: "+(z.handsVisible?"visíveis":"desligadas")+" · modo: "+z.handsMode+" · superfícies: "+z.handsSurfaces+" · texturas de mãos: "+z.handsTextures+" · triângulos por mão: "+z.handsTriangles,"Rig pronto: "+(z.handsReady?"sim":"carregando/indisponível")+" · ossos: "+z.handsJoints+" · juntas de dedos: "+z.handsFingerJoints,...z.handsMode==="fps"&&window.__orionHandsDebug?.state?.framing?["FPS | punhos NDC: "+JSON.stringify(window.__orionHandsDebug.state.framing)]:[],...z.handsLoadError?["Falha no rig: "+z.handsLoadError]:[],"Profundidade orgânica: "+(z.depthMotion?"ativa":"desativada")+" · intensidade: "+z.parallaxStrength,"Draw calls: "+z.drawCalls+" · texturas GPU: "+z.textures,"Diferença interna mouse/câmera: "+z.mouseDeltaPx+" px","Heap JavaScript: "+(z.jsHeapMB==null?"indisponível":z.jsHeapMB+" MB")+" (não é RAM total)"].join(`
`)}function F(){const z=U();return["Projeto Órion · Observatório v0.9.15 (prévia)",new Date().toLocaleString("pt-BR"),O(z),"Amostras: "+z.samples+" · adaptações automáticas: "+z.adaptations,"Janela: "+z.viewport,"Memória total da aba: verificar no Gerenciador de tarefas do Chrome (Shift+Esc).","Os valores são observações locais, não benchmarks de GPU nem medidas de VRAM."].join(`
`)}const V=Dy(t,U);function k(z){z-S<1e3||(S=z,I=U(z),s.textContent=O(I))}return a.addEventListener("click",async()=>{const z=F()+`

`+V.report();try{if(!navigator.clipboard?.writeText)throw new Error("Clipboard indisponível");await navigator.clipboard.writeText(z),o.textContent="Diagnóstico copiado. Pode colar no chat."}catch{o.textContent="Cópia automática indisponível; selecione o texto abaixo.";const B=document.createElement("textarea");B.readOnly=!0,B.className="perf-fallback",B.setAttribute("aria-label","Diagnóstico para cópia manual"),B.value=z,t.querySelector(".perf-fallback")?.remove(),t.appendChild(B),B.focus(),B.select()}}),{record:w,refresh:k,reset:D,snapshot:U,report:F,get latest(){return I}}}function Oy(){const i=document.createElement("canvas");i.width=320,i.height=512;const e=i.getContext("2d");if(!e)throw new Error("Canvas 2D indisponível para as mãos etéreas");const t=new Path2D;t.moveTo(30,520),t.bezierCurveTo(38,460,60,418,89,385),t.bezierCurveTo(108,363,119,352,114,328),t.bezierCurveTo(102,309,99,289,106,279),t.bezierCurveTo(112,269,123,271,132,287),t.bezierCurveTo(137,295,140,315,143,323),t.lineTo(140,264),t.bezierCurveTo(140,247,145,237,155,236),t.bezierCurveTo(167,237,167,249,167,264),t.lineTo(169,304),t.lineTo(169,236),t.bezierCurveTo(169,222,174,213,184,212),t.bezierCurveTo(197,213,199,227,198,243),t.lineTo(199,306),t.lineTo(205,269),t.bezierCurveTo(206,252,214,246,226,250),t.bezierCurveTo(238,256,235,270,232,286),t.lineTo(222,333),t.bezierCurveTo(239,323,251,313,266,316),t.bezierCurveTo(280,319,282,330,273,341),t.bezierCurveTo(261,355,246,365,238,386),t.bezierCurveTo(223,426,226,475,245,520),t.closePath(),e.save(),e.shadowBlur=23,e.shadowColor="rgba(173,96,212,.25)";const n=e.createLinearGradient(74,210,247,502);n.addColorStop(0,"rgba(101,76,149,.96)"),n.addColorStop(.31,"rgba(74,51,115,.98)"),n.addColorStop(.65,"rgba(34,28,69,.99)"),n.addColorStop(1,"rgba(9,15,39,.98)"),e.fillStyle=n,e.fill(t),e.restore(),e.save(),e.clip(t);const s=e.createRadialGradient(194,305,5,178,327,156);s.addColorStop(0,"rgba(209,135,218,.35)"),s.addColorStop(.45,"rgba(136,92,189,.20)"),s.addColorStop(1,"rgba(54,30,99,0)"),e.fillStyle=s,e.fillRect(0,160,320,360),e.lineCap="round",e.lineJoin="round",e.lineWidth=5,e.strokeStyle="rgba(245,203,255,.10)",e.beginPath(),e.moveTo(112,338),e.bezierCurveTo(143,319,170,322,193,339),e.moveTo(123,369),e.bezierCurveTo(162,355,189,358,219,380),e.moveTo(150,266),e.lineTo(151,304),e.moveTo(181,242),e.lineTo(182,298),e.moveTo(217,275),e.lineTo(210,310),e.stroke(),e.strokeStyle="rgba(208,146,244,.28)",e.lineWidth=2,e.beginPath(),e.moveTo(117,308),e.bezierCurveTo(126,349,133,353,144,361),e.moveTo(148,252),e.lineTo(150,289),e.moveTo(177,226),e.lineTo(179,286),e.moveTo(218,263),e.lineTo(211,309),e.moveTo(110,392),e.bezierCurveTo(120,410,121,437,115,452),e.stroke(),e.save(),e.translate(163,409),e.rotate(-.08);const r=e.createLinearGradient(0,-20,0,45);r.addColorStop(0,"rgba(15,16,38,.35)"),r.addColorStop(.22,"rgba(12,16,42,.90)"),r.addColorStop(.7,"rgba(8,12,30,.96)"),r.addColorStop(1,"rgba(26,19,56,.90)"),e.fillStyle=r,e.fillRect(-110,-5,210,63),e.strokeStyle="rgba(186,113,210,.32)",e.lineWidth=3,e.beginPath(),e.moveTo(-107,0),e.lineTo(98,0),e.stroke(),e.restore(),e.strokeStyle="rgba(230,146,233,.13)",e.lineWidth=7,e.shadowBlur=10,e.shadowColor="rgba(177,78,238,.28)",e.beginPath(),e.moveTo(61,418),e.bezierCurveTo(84,392,98,373,103,345),e.moveTo(239,382),e.bezierCurveTo(231,409,224,446,229,470),e.stroke(),e.shadowBlur=0,e.restore(),e.save(),e.strokeStyle="rgba(185,126,212,.38)",e.lineWidth=2.2,e.lineJoin="round",e.stroke(t),e.restore();const a=e.createLinearGradient(0,388,0,512);a.addColorStop(0,"rgba(0,0,0,1)"),a.addColorStop(.77,"rgba(0,0,0,.92)"),a.addColorStop(1,"rgba(0,0,0,.06)"),e.globalCompositeOperation="destination-in",e.fillStyle=a,e.fillRect(0,0,320,512),e.globalCompositeOperation="source-over";const o=new co(i);return o.colorSpace=_t,o.anisotropy=1,o.minFilter=Gt,o.magFilter=Lt,o}function Uy(i,{enabled:e=!0,reducedMotion:t=!1}={}){const n={enabled:!!e,visible:!!e,motionEnabled:!t,leftX:0,rightX:0,swayX:0,swayY:0,textureCount:e?1:0,drawSurfaces:e?2:0};if(!e)return{state:n,meshes:[],update(){},resize(){},beginTravel(){},dispose(){}};const s=Oy(),r=new _n(1,1),a=new Ut({map:s,transparent:!0,opacity:.78,depthTest:!1,depthWrite:!1,toneMapped:!1,side:Mt}),o=new pt(r,a),c=new pt(r,a);o.name="Mão etérea esquerda · pose de primeira pessoa v0.9.11",c.name="Mão etérea direita · pose de primeira pessoa v0.9.11",o.layers.set(0),c.layers.set(0),o.renderOrder=30,c.renderOrder=30,o.frustumCulled=!1,c.frustumCulled=!1,i.add(o,c);const l=[o,c],u={left:{z:-1.1,x:-.7,y:-.72,size:1.1,roll:-.2,pitch:.055,yaw:.025,sway:.86},right:{z:-1,x:.68,y:-.66,size:1.17,roll:.18,pitch:.035,yaw:-.025,sway:1}};let d=0,h=0;function p(_){const x=Math.tan(_e.degToRad(i.fov/2))*Math.abs(_);return{hh:x,hw:x*i.aspect}}function g(){for(const[_,x,y]of[[o,u.left,1],[c,u.right,-1]]){const{hh:A,hw:E}=p(x.z),M=A*x.size;_.scale.set(y*M*(320/512),M,1),_.position.set(E*x.x,A*x.y,x.z),_.rotation.set(x.pitch,x.yaw,x.roll)}n.leftX=o.position.x,n.rightX=c.position.x}g();function v(_,x,y=0,A=0){if(!n.visible)return;const E=_e.clamp(y,-1,1),M=_e.clamp(A,-1,1),C=n.motionEnabled?1-Math.exp(-Math.max(0,Math.min(x,.06))*7.5):1;d+=(E-d)*C,h+=(M-h)*C,n.swayX=n.motionEnabled?d:0,n.swayY=n.motionEnabled?h:0;const b=n.motionEnabled?Math.sin(_*.81)*.006:0;for(const[S,I,D]of[[o,u.left,.9],[c,u.right,1]]){const{hh:w,hw:U}=p(I.z),O=n.swayX*U*.029*I.sway,F=n.swayY*w*.024*I.sway;S.position.set(U*I.x-O,w*I.y-F+b*w*D,I.z),S.rotation.set(I.pitch+(n.motionEnabled?n.swayY*.012:0),I.yaw,I.roll+(n.motionEnabled?n.swayX*.02*I.sway:0))}n.leftX=o.position.x,n.rightX=c.position.x}function m(){n.visible=!1,l.forEach(_=>_.visible=!1)}function f(){i.remove(o,c),r.dispose(),a.dispose(),s.dispose()}return{state:n,meshes:l,update:v,resize:g,beginTravel:m,dispose:f}}function Fy(i,e=!1){const t=i[0].index!==null,n=new Set(Object.keys(i[0].attributes)),s=new Set(Object.keys(i[0].morphAttributes)),r={},a={},o=i[0].morphTargetsRelative,c=new It;let l=0;for(let u=0;u<i.length;++u){const d=i[u];let h=0;if(t!==(d.index!==null))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+u+". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."),null;for(const p in d.attributes){if(!n.has(p))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+u+'. All geometries must have compatible attributes; make sure "'+p+'" attribute exists among all geometries, or in none of them.'),null;r[p]===void 0&&(r[p]=[]),r[p].push(d.attributes[p]),h++}if(h!==n.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+u+". Make sure all geometries have the same number of attributes."),null;if(o!==d.morphTargetsRelative)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+u+". .morphTargetsRelative must be consistent throughout all geometries."),null;for(const p in d.morphAttributes){if(!s.has(p))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+u+".  .morphAttributes must be consistent throughout all geometries."),null;a[p]===void 0&&(a[p]=[]),a[p].push(d.morphAttributes[p])}if(e){let p;if(t)p=d.index.count;else if(d.attributes.position!==void 0)p=d.attributes.position.count;else return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+u+". The geometry must have either an index or a position attribute"),null;c.addGroup(l,p,u),l+=p}}if(t){let u=0;const d=[];for(let h=0;h<i.length;++h){const p=i[h].index;for(let g=0;g<p.count;++g)d.push(p.getX(g)+u);u+=i[h].attributes.position.count}c.setIndex(d)}for(const u in r){const d=Fd(r[u]);if(!d)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+u+" attribute."),null;c.setAttribute(u,d)}for(const u in a){const d=a[u][0].length;if(d===0)break;c.morphAttributes=c.morphAttributes||{},c.morphAttributes[u]=[];for(let h=0;h<d;++h){const p=[];for(let v=0;v<a[u].length;++v)p.push(a[u][v][h]);const g=Fd(p);if(!g)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+u+" morphAttribute."),null;c.morphAttributes[u].push(g)}}return c}function Fd(i){let e,t,n,s=-1,r=0;for(let l=0;l<i.length;++l){const u=i[l];if(e===void 0&&(e=u.array.constructor),e!==u.array.constructor)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."),null;if(t===void 0&&(t=u.itemSize),t!==u.itemSize)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."),null;if(n===void 0&&(n=u.normalized),n!==u.normalized)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."),null;if(s===-1&&(s=u.gpuType),s!==u.gpuType)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."),null;r+=u.count*t}const a=new e(r),o=new ct(a,t,n);let c=0;for(let l=0;l<i.length;++l){const u=i[l];if(u.isInterleavedBufferAttribute){const d=c/t;for(let h=0,p=u.count;h<p;h++)for(let g=0;g<t;g++){const v=u.getComponent(h,g);o.setComponent(h+d,g,v)}}else a.set(u.array,c);c+=u.count*t}return s!==void 0&&(o.gpuType=s),o}function Bd(i,e){if(e===Up)return console.warn("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Geometry already defined as triangles."),i;if(e===lc||e===Wh){let t=i.getIndex();if(t===null){const a=[],o=i.getAttribute("position");if(o!==void 0){for(let c=0;c<o.count;c++)a.push(c);i.setIndex(a),t=i.getIndex()}else return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Undefined position attribute. Processing not possible."),i}const n=t.count-2,s=[];if(e===lc)for(let a=1;a<=n;a++)s.push(t.getX(0)),s.push(t.getX(a)),s.push(t.getX(a+1));else for(let a=0;a<n;a++)a%2===0?(s.push(t.getX(a)),s.push(t.getX(a+1)),s.push(t.getX(a+2))):(s.push(t.getX(a+2)),s.push(t.getX(a+1)),s.push(t.getX(a)));s.length/3!==n&&console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unable to generate correct amount of triangles.");const r=i.clone();return r.setIndex(s),r.clearGroups(),r}else return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unknown draw mode:",e),i}const ul=new Re("#5b3e83"),By=new Re("#171831"),kd=new Re("#ba79ca"),ky=new Re("#101329"),dl=new N(-.48,.64,.64).normalize();function Sf(i,{kind:e="skin",strength:t=1}={}){const n=i.getAttribute("position"),s=i.getAttribute("normal"),r=new Float32Array(n.count*4),a=new Re;for(let o=0;o<n.count;o++){n.getX(o);const c=n.getY(o),l=s.getX(o),u=s.getY(o),d=s.getZ(o),h=Math.max(0,l*dl.x+u*dl.y+d*dl.z),p=Math.max(0,d);if(e==="cuff")a.copy(ky).lerp(ul,Math.min(.22,h*.14));else if(e==="glimmer")a.copy(kd).lerp(ul,.25);else{a.copy(By).lerp(ul,.44+.36*h+.13*p);const v=Math.min(.2,Math.max(0,c-.2)*.42);a.lerp(kd,Math.min(.44,v+h*.1*t))}const g=_e.smoothstep(c,-1.15,-.79);r[o*4]=a.r,r[o*4+1]=a.g,r[o*4+2]=a.b,r[o*4+3]=(e==="glimmer"?.5:1)*g}return i.setAttribute("color",new nt(r,4)),i}function si(i,e,t,n="skin",s=12,r=8){const a=new Xc(1,s,r);a.scale(t[0],t[1],t[2]),a.translate(e[0],e[1],e[2]),i.push(Sf(a,{kind:n}))}function Gi(i,e,t,n,s,r="skin"){const a=new N(...e),o=new N(...t),c=o.clone().sub(a),l=c.length();if(l<.001)return;const u=new Wc(s,n,l,9,1,!1),d=new dt().setFromUnitVectors(new N(0,1,0),c.normalize());u.applyMatrix4(new Ye().compose(a.add(o).multiplyScalar(.5),d,new N(1,1,1))),i.push(Sf(u,{kind:r}))}function zy(){const i=[];Gi(i,[0,-1.12,-.16],[.025,-.4,-.04],.185,.135,"cuff"),si(i,[.023,-.49,-.035],[.153,.13,.124],"cuff"),Gi(i,[.025,-.43,-.04],[.02,-.25,.025],.125,.118),si(i,[0,-.07,.035],[.27,.326,.126]),si(i,[.002,.13,.063],[.225,.144,.115]),si(i,[.178,-.16,.114],[.12,.17,.108]);const e=[{x:-.205,len:.265,lean:-.057,r:.047},{x:-.104,len:.344,lean:-.024,r:.053},{x:.011,len:.393,lean:.011,r:.057},{x:.125,len:.334,lean:.064,r:.051}];for(const a of e){const o=[a.x,.187,.067],c=[a.x+a.lean*.43,.187+a.len*.57,.018],l=[a.x+a.lean,.187+a.len,-.1];Gi(i,o,c,a.r*1.18,a.r*.93),si(i,c,[a.r*.99,a.r*.99,a.r*.94]),Gi(i,c,l,a.r*.94,a.r*.72),si(i,l,[a.r*.8,a.r*.9,a.r*.78]),si(i,[l[0],l[1]+a.r*.18,l[2]+a.r*.48],[a.r*.43,a.r*.25,a.r*.12],"glimmer",8,5)}const t=[.196,-.168,.117],n=[.357,-.043,.157],s=[.385,.102,.073];Gi(i,t,n,.083,.062),si(i,n,[.066,.066,.068]),Gi(i,n,s,.062,.043),si(i,s,[.051,.062,.048]),Gi(i,[.025,-.53,-.034],[.025,-.49,-.034],.159,.159,"glimmer");const r=Fy(i,!1);for(const a of i)a.dispose();if(!r)throw new Error("Não foi possível mesclar a malha das mãos 3D");return r.computeBoundingSphere(),r.userData.fingerCount=5,r.userData.sections=i.length,r.userData.triangles=r.index?.count/3,r}function Vy(i,{enabled:e=!0,reducedMotion:t=!1}={}){const n={mode:"3d",enabled:!!e,visible:!!e,motionEnabled:!t,textureCount:0,drawSurfaces:e?2:0,fingerCount:e?10:0,leftX:0,rightX:0,swayX:0,swayY:0,triangles:0};if(!e)return{state:n,meshes:[],update(){},resize(){},beginTravel(){},dispose(){}};const s=zy();n.triangles=s.userData.triangles;const r=new Ut({color:16777215,vertexColors:!0,transparent:!0,opacity:.92,side:Mt,depthTest:!1,depthWrite:!1,toneMapped:!1}),a=new pt(s,r),o=new pt(s,r);a.name="Mão 3D esquerda · primeira pessoa",o.name="Mão 3D direita · primeira pessoa";for(const f of[a,o])f.layers.set(0),f.renderOrder=30,f.frustumCulled=!1;i.add(a,o);const c=[a,o],l={left:{z:-1.1,x:-.78,y:-.82,size:.65,roll:-.2,pitch:-.13,yaw:-.13,sway:.86},right:{z:-1,x:.76,y:-.8,size:.68,roll:.18,pitch:-.11,yaw:.12,sway:1}};function u(f){const _=Math.tan(_e.degToRad(i.fov*.5))*Math.abs(f);return{hh:_,hw:_*i.aspect}}function d(){for(const[f,_,x]of[[a,l.left,1],[o,l.right,-1]]){const{hh:y,hw:A}=u(_.z),E=y*_.size;f.scale.set(x*E,E,E),f.position.set(A*_.x,y*_.y,_.z),f.rotation.set(_.pitch,_.yaw,_.roll)}n.leftX=a.position.x,n.rightX=o.position.x}let h=0,p=0;d();function g(f,_,x=0,y=0){if(!n.visible)return;const A=n.motionEnabled?1-Math.exp(-Math.max(0,Math.min(_,.06))*7.5):1;h+=(_e.clamp(x,-1,1)-h)*A,p+=(_e.clamp(y,-1,1)-p)*A,n.swayX=n.motionEnabled?h:0,n.swayY=n.motionEnabled?p:0;const E=n.motionEnabled?Math.sin(f*.81)*.006:0;for(const[M,C,b]of[[a,l.left,.9],[o,l.right,1]]){const{hh:S,hw:I}=u(C.z);M.position.set(I*(C.x-n.swayX*.029*C.sway),S*(C.y-n.swayY*.024*C.sway+E*b),C.z),M.rotation.set(C.pitch+(n.motionEnabled?n.swayY*.012:0),C.yaw+(n.motionEnabled?n.swayX*.01:0),C.roll+(n.motionEnabled?n.swayX*.02*C.sway:0))}n.leftX=a.position.x,n.rightX=o.position.x}function v(){n.visible=!1;for(const f of c)f.visible=!1}function m(){i.remove(a,o),s.dispose(),r.dispose()}return{state:n,meshes:c,update:g,resize:d,beginTravel:v,dispose:m}}class Jc extends Js{constructor(e){super(e),this.dracoLoader=null,this.ktx2Loader=null,this.meshoptDecoder=null,this.pluginCallbacks=[],this.register(function(t){return new qy(t)}),this.register(function(t){return new Yy(t)}),this.register(function(t){return new nS(t)}),this.register(function(t){return new iS(t)}),this.register(function(t){return new sS(t)}),this.register(function(t){return new $y(t)}),this.register(function(t){return new Ky(t)}),this.register(function(t){return new Zy(t)}),this.register(function(t){return new Jy(t)}),this.register(function(t){return new Xy(t)}),this.register(function(t){return new Qy(t)}),this.register(function(t){return new jy(t)}),this.register(function(t){return new tS(t)}),this.register(function(t){return new eS(t)}),this.register(function(t){return new Gy(t)}),this.register(function(t){return new rS(t)}),this.register(function(t){return new aS(t)})}load(e,t,n,s){const r=this;let a;if(this.resourcePath!=="")a=this.resourcePath;else if(this.path!==""){const l=Er.extractUrlBase(e);a=Er.resolveURL(l,this.path)}else a=Er.extractUrlBase(e);this.manager.itemStart(e);const o=function(l){s?s(l):console.error(l),r.manager.itemError(e),r.manager.itemEnd(e)},c=new df(this.manager);c.setPath(this.path),c.setResponseType("arraybuffer"),c.setRequestHeader(this.requestHeader),c.setWithCredentials(this.withCredentials),c.load(e,function(l){try{r.parse(l,a,function(u){t(u),r.manager.itemEnd(e)},o)}catch(u){o(u)}},n,o)}setDRACOLoader(e){return this.dracoLoader=e,this}setKTX2Loader(e){return this.ktx2Loader=e,this}setMeshoptDecoder(e){return this.meshoptDecoder=e,this}register(e){return this.pluginCallbacks.indexOf(e)===-1&&this.pluginCallbacks.push(e),this}unregister(e){return this.pluginCallbacks.indexOf(e)!==-1&&this.pluginCallbacks.splice(this.pluginCallbacks.indexOf(e),1),this}parse(e,t,n,s){let r;const a={},o={},c=new TextDecoder;if(typeof e=="string")r=JSON.parse(e);else if(e instanceof ArrayBuffer)if(c.decode(new Uint8Array(e,0,4))===bf){try{a[Qe.KHR_BINARY_GLTF]=new oS(e)}catch(d){s&&s(d);return}r=JSON.parse(a[Qe.KHR_BINARY_GLTF].content)}else r=JSON.parse(c.decode(e));else r=e;if(r.asset===void 0||r.asset.version[0]<2){s&&s(new Error("THREE.GLTFLoader: Unsupported asset. glTF versions >=2.0 are supported."));return}const l=new yS(r,{path:t||this.resourcePath||"",crossOrigin:this.crossOrigin,requestHeader:this.requestHeader,manager:this.manager,ktx2Loader:this.ktx2Loader,meshoptDecoder:this.meshoptDecoder});l.fileLoader.setRequestHeader(this.requestHeader);for(let u=0;u<this.pluginCallbacks.length;u++){const d=this.pluginCallbacks[u](l);d.name||console.error("THREE.GLTFLoader: Invalid plugin found: missing name"),o[d.name]=d,a[d.name]=!0}if(r.extensionsUsed)for(let u=0;u<r.extensionsUsed.length;++u){const d=r.extensionsUsed[u],h=r.extensionsRequired||[];switch(d){case Qe.KHR_MATERIALS_UNLIT:a[d]=new Wy;break;case Qe.KHR_DRACO_MESH_COMPRESSION:a[d]=new lS(r,this.dracoLoader);break;case Qe.KHR_TEXTURE_TRANSFORM:a[d]=new cS;break;case Qe.KHR_MESH_QUANTIZATION:a[d]=new uS;break;default:h.indexOf(d)>=0&&o[d]===void 0&&console.warn('THREE.GLTFLoader: Unknown extension "'+d+'".')}}l.setExtensions(a),l.setPlugins(o),l.parse(n,s)}parseAsync(e,t){const n=this;return new Promise(function(s,r){n.parse(e,t,s,r)})}}function Hy(){let i={};return{get:function(e){return i[e]},add:function(e,t){i[e]=t},remove:function(e){delete i[e]},removeAll:function(){i={}}}}const Qe={KHR_BINARY_GLTF:"KHR_binary_glTF",KHR_DRACO_MESH_COMPRESSION:"KHR_draco_mesh_compression",KHR_LIGHTS_PUNCTUAL:"KHR_lights_punctual",KHR_MATERIALS_CLEARCOAT:"KHR_materials_clearcoat",KHR_MATERIALS_DISPERSION:"KHR_materials_dispersion",KHR_MATERIALS_IOR:"KHR_materials_ior",KHR_MATERIALS_SHEEN:"KHR_materials_sheen",KHR_MATERIALS_SPECULAR:"KHR_materials_specular",KHR_MATERIALS_TRANSMISSION:"KHR_materials_transmission",KHR_MATERIALS_IRIDESCENCE:"KHR_materials_iridescence",KHR_MATERIALS_ANISOTROPY:"KHR_materials_anisotropy",KHR_MATERIALS_UNLIT:"KHR_materials_unlit",KHR_MATERIALS_VOLUME:"KHR_materials_volume",KHR_TEXTURE_BASISU:"KHR_texture_basisu",KHR_TEXTURE_TRANSFORM:"KHR_texture_transform",KHR_MESH_QUANTIZATION:"KHR_mesh_quantization",KHR_MATERIALS_EMISSIVE_STRENGTH:"KHR_materials_emissive_strength",EXT_MATERIALS_BUMP:"EXT_materials_bump",EXT_TEXTURE_WEBP:"EXT_texture_webp",EXT_TEXTURE_AVIF:"EXT_texture_avif",EXT_MESHOPT_COMPRESSION:"EXT_meshopt_compression",EXT_MESH_GPU_INSTANCING:"EXT_mesh_gpu_instancing"};class Gy{constructor(e){this.parser=e,this.name=Qe.KHR_LIGHTS_PUNCTUAL,this.cache={refs:{},uses:{}}}_markDefs(){const e=this.parser,t=this.parser.json.nodes||[];for(let n=0,s=t.length;n<s;n++){const r=t[n];r.extensions&&r.extensions[this.name]&&r.extensions[this.name].light!==void 0&&e._addNodeRef(this.cache,r.extensions[this.name].light)}}_loadLight(e){const t=this.parser,n="light:"+e;let s=t.cache.get(n);if(s)return s;const r=t.json,c=((r.extensions&&r.extensions[this.name]||{}).lights||[])[e];let l;const u=new Re(16777215);c.color!==void 0&&u.setRGB(c.color[0],c.color[1],c.color[2],Qt);const d=c.range!==void 0?c.range:0;switch(c.type){case"directional":l=new hf(u),l.target.position.set(0,0,-1),l.add(l.target);break;case"point":l=new lg(u),l.distance=d;break;case"spot":l=new ag(u),l.distance=d,c.spot=c.spot||{},c.spot.innerConeAngle=c.spot.innerConeAngle!==void 0?c.spot.innerConeAngle:0,c.spot.outerConeAngle=c.spot.outerConeAngle!==void 0?c.spot.outerConeAngle:Math.PI/4,l.angle=c.spot.outerConeAngle,l.penumbra=1-c.spot.innerConeAngle/c.spot.outerConeAngle,l.target.position.set(0,0,-1),l.add(l.target);break;default:throw new Error("THREE.GLTFLoader: Unexpected light type: "+c.type)}return l.position.set(0,0,0),Hn(l,c),c.intensity!==void 0&&(l.intensity=c.intensity),l.name=t.createUniqueName(c.name||"light_"+e),s=Promise.resolve(l),t.cache.add(n,s),s}getDependency(e,t){if(e==="light")return this._loadLight(t)}createNodeAttachment(e){const t=this,n=this.parser,r=n.json.nodes[e],o=(r.extensions&&r.extensions[this.name]||{}).light;return o===void 0?null:this._loadLight(o).then(function(c){return n._getNodeRef(t.cache,o,c)})}}class Wy{constructor(){this.name=Qe.KHR_MATERIALS_UNLIT}getMaterialType(){return Ut}extendParams(e,t,n){const s=[];e.color=new Re(1,1,1),e.opacity=1;const r=t.pbrMetallicRoughness;if(r){if(Array.isArray(r.baseColorFactor)){const a=r.baseColorFactor;e.color.setRGB(a[0],a[1],a[2],Qt),e.opacity=a[3]}r.baseColorTexture!==void 0&&s.push(n.assignTexture(e,"map",r.baseColorTexture,_t))}return Promise.all(s)}}class Xy{constructor(e){this.parser=e,this.name=Qe.KHR_MATERIALS_EMISSIVE_STRENGTH}extendMaterialParams(e,t){const s=this.parser.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();const r=s.extensions[this.name].emissiveStrength;return r!==void 0&&(t.emissiveIntensity=r),Promise.resolve()}}class qy{constructor(e){this.parser=e,this.name=Qe.KHR_MATERIALS_CLEARCOAT}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Kn}extendMaterialParams(e,t){const n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();const r=[],a=s.extensions[this.name];if(a.clearcoatFactor!==void 0&&(t.clearcoat=a.clearcoatFactor),a.clearcoatTexture!==void 0&&r.push(n.assignTexture(t,"clearcoatMap",a.clearcoatTexture)),a.clearcoatRoughnessFactor!==void 0&&(t.clearcoatRoughness=a.clearcoatRoughnessFactor),a.clearcoatRoughnessTexture!==void 0&&r.push(n.assignTexture(t,"clearcoatRoughnessMap",a.clearcoatRoughnessTexture)),a.clearcoatNormalTexture!==void 0&&(r.push(n.assignTexture(t,"clearcoatNormalMap",a.clearcoatNormalTexture)),a.clearcoatNormalTexture.scale!==void 0)){const o=a.clearcoatNormalTexture.scale;t.clearcoatNormalScale=new Ie(o,o)}return Promise.all(r)}}class Yy{constructor(e){this.parser=e,this.name=Qe.KHR_MATERIALS_DISPERSION}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Kn}extendMaterialParams(e,t){const s=this.parser.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();const r=s.extensions[this.name];return t.dispersion=r.dispersion!==void 0?r.dispersion:0,Promise.resolve()}}class jy{constructor(e){this.parser=e,this.name=Qe.KHR_MATERIALS_IRIDESCENCE}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Kn}extendMaterialParams(e,t){const n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();const r=[],a=s.extensions[this.name];return a.iridescenceFactor!==void 0&&(t.iridescence=a.iridescenceFactor),a.iridescenceTexture!==void 0&&r.push(n.assignTexture(t,"iridescenceMap",a.iridescenceTexture)),a.iridescenceIor!==void 0&&(t.iridescenceIOR=a.iridescenceIor),t.iridescenceThicknessRange===void 0&&(t.iridescenceThicknessRange=[100,400]),a.iridescenceThicknessMinimum!==void 0&&(t.iridescenceThicknessRange[0]=a.iridescenceThicknessMinimum),a.iridescenceThicknessMaximum!==void 0&&(t.iridescenceThicknessRange[1]=a.iridescenceThicknessMaximum),a.iridescenceThicknessTexture!==void 0&&r.push(n.assignTexture(t,"iridescenceThicknessMap",a.iridescenceThicknessTexture)),Promise.all(r)}}class $y{constructor(e){this.parser=e,this.name=Qe.KHR_MATERIALS_SHEEN}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Kn}extendMaterialParams(e,t){const n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();const r=[];t.sheenColor=new Re(0,0,0),t.sheenRoughness=0,t.sheen=1;const a=s.extensions[this.name];if(a.sheenColorFactor!==void 0){const o=a.sheenColorFactor;t.sheenColor.setRGB(o[0],o[1],o[2],Qt)}return a.sheenRoughnessFactor!==void 0&&(t.sheenRoughness=a.sheenRoughnessFactor),a.sheenColorTexture!==void 0&&r.push(n.assignTexture(t,"sheenColorMap",a.sheenColorTexture,_t)),a.sheenRoughnessTexture!==void 0&&r.push(n.assignTexture(t,"sheenRoughnessMap",a.sheenRoughnessTexture)),Promise.all(r)}}class Ky{constructor(e){this.parser=e,this.name=Qe.KHR_MATERIALS_TRANSMISSION}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Kn}extendMaterialParams(e,t){const n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();const r=[],a=s.extensions[this.name];return a.transmissionFactor!==void 0&&(t.transmission=a.transmissionFactor),a.transmissionTexture!==void 0&&r.push(n.assignTexture(t,"transmissionMap",a.transmissionTexture)),Promise.all(r)}}class Zy{constructor(e){this.parser=e,this.name=Qe.KHR_MATERIALS_VOLUME}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Kn}extendMaterialParams(e,t){const n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();const r=[],a=s.extensions[this.name];t.thickness=a.thicknessFactor!==void 0?a.thicknessFactor:0,a.thicknessTexture!==void 0&&r.push(n.assignTexture(t,"thicknessMap",a.thicknessTexture)),t.attenuationDistance=a.attenuationDistance||1/0;const o=a.attenuationColor||[1,1,1];return t.attenuationColor=new Re().setRGB(o[0],o[1],o[2],Qt),Promise.all(r)}}class Jy{constructor(e){this.parser=e,this.name=Qe.KHR_MATERIALS_IOR}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Kn}extendMaterialParams(e,t){const s=this.parser.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();const r=s.extensions[this.name];return t.ior=r.ior!==void 0?r.ior:1.5,Promise.resolve()}}class Qy{constructor(e){this.parser=e,this.name=Qe.KHR_MATERIALS_SPECULAR}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Kn}extendMaterialParams(e,t){const n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();const r=[],a=s.extensions[this.name];t.specularIntensity=a.specularFactor!==void 0?a.specularFactor:1,a.specularTexture!==void 0&&r.push(n.assignTexture(t,"specularIntensityMap",a.specularTexture));const o=a.specularColorFactor||[1,1,1];return t.specularColor=new Re().setRGB(o[0],o[1],o[2],Qt),a.specularColorTexture!==void 0&&r.push(n.assignTexture(t,"specularColorMap",a.specularColorTexture,_t)),Promise.all(r)}}class eS{constructor(e){this.parser=e,this.name=Qe.EXT_MATERIALS_BUMP}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Kn}extendMaterialParams(e,t){const n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();const r=[],a=s.extensions[this.name];return t.bumpScale=a.bumpFactor!==void 0?a.bumpFactor:1,a.bumpTexture!==void 0&&r.push(n.assignTexture(t,"bumpMap",a.bumpTexture)),Promise.all(r)}}class tS{constructor(e){this.parser=e,this.name=Qe.KHR_MATERIALS_ANISOTROPY}getMaterialType(e){const n=this.parser.json.materials[e];return!n.extensions||!n.extensions[this.name]?null:Kn}extendMaterialParams(e,t){const n=this.parser,s=n.json.materials[e];if(!s.extensions||!s.extensions[this.name])return Promise.resolve();const r=[],a=s.extensions[this.name];return a.anisotropyStrength!==void 0&&(t.anisotropy=a.anisotropyStrength),a.anisotropyRotation!==void 0&&(t.anisotropyRotation=a.anisotropyRotation),a.anisotropyTexture!==void 0&&r.push(n.assignTexture(t,"anisotropyMap",a.anisotropyTexture)),Promise.all(r)}}class nS{constructor(e){this.parser=e,this.name=Qe.KHR_TEXTURE_BASISU}loadTexture(e){const t=this.parser,n=t.json,s=n.textures[e];if(!s.extensions||!s.extensions[this.name])return null;const r=s.extensions[this.name],a=t.options.ktx2Loader;if(!a){if(n.extensionsRequired&&n.extensionsRequired.indexOf(this.name)>=0)throw new Error("THREE.GLTFLoader: setKTX2Loader must be called before loading KTX2 textures");return null}return t.loadTextureImage(e,r.source,a)}}class iS{constructor(e){this.parser=e,this.name=Qe.EXT_TEXTURE_WEBP}loadTexture(e){const t=this.name,n=this.parser,s=n.json,r=s.textures[e];if(!r.extensions||!r.extensions[t])return null;const a=r.extensions[t],o=s.images[a.source];let c=n.textureLoader;if(o.uri){const l=n.options.manager.getHandler(o.uri);l!==null&&(c=l)}return n.loadTextureImage(e,a.source,c)}}class sS{constructor(e){this.parser=e,this.name=Qe.EXT_TEXTURE_AVIF}loadTexture(e){const t=this.name,n=this.parser,s=n.json,r=s.textures[e];if(!r.extensions||!r.extensions[t])return null;const a=r.extensions[t],o=s.images[a.source];let c=n.textureLoader;if(o.uri){const l=n.options.manager.getHandler(o.uri);l!==null&&(c=l)}return n.loadTextureImage(e,a.source,c)}}class rS{constructor(e){this.name=Qe.EXT_MESHOPT_COMPRESSION,this.parser=e}loadBufferView(e){const t=this.parser.json,n=t.bufferViews[e];if(n.extensions&&n.extensions[this.name]){const s=n.extensions[this.name],r=this.parser.getDependency("buffer",s.buffer),a=this.parser.options.meshoptDecoder;if(!a||!a.supported){if(t.extensionsRequired&&t.extensionsRequired.indexOf(this.name)>=0)throw new Error("THREE.GLTFLoader: setMeshoptDecoder must be called before loading compressed files");return null}return r.then(function(o){const c=s.byteOffset||0,l=s.byteLength||0,u=s.count,d=s.byteStride,h=new Uint8Array(o,c,l);return a.decodeGltfBufferAsync?a.decodeGltfBufferAsync(u,d,h,s.mode,s.filter).then(function(p){return p.buffer}):a.ready.then(function(){const p=new ArrayBuffer(u*d);return a.decodeGltfBuffer(new Uint8Array(p),u,d,h,s.mode,s.filter),p})})}else return null}}class aS{constructor(e){this.name=Qe.EXT_MESH_GPU_INSTANCING,this.parser=e}createNodeMesh(e){const t=this.parser.json,n=t.nodes[e];if(!n.extensions||!n.extensions[this.name]||n.mesh===void 0)return null;const s=t.meshes[n.mesh];for(const l of s.primitives)if(l.mode!==En.TRIANGLES&&l.mode!==En.TRIANGLE_STRIP&&l.mode!==En.TRIANGLE_FAN&&l.mode!==void 0)return null;const a=n.extensions[this.name].attributes,o=[],c={};for(const l in a)o.push(this.parser.getDependency("accessor",a[l]).then(u=>(c[l]=u,c[l])));return o.length<1?null:(o.push(this.parser.createNodeMesh(e)),Promise.all(o).then(l=>{const u=l.pop(),d=u.isGroup?u.children:[u],h=l[0].count,p=[];for(const g of d){const v=new Ye,m=new N,f=new dt,_=new N(1,1,1),x=new Fm(g.geometry,g.material,h);for(let y=0;y<h;y++)c.TRANSLATION&&m.fromBufferAttribute(c.TRANSLATION,y),c.ROTATION&&f.fromBufferAttribute(c.ROTATION,y),c.SCALE&&_.fromBufferAttribute(c.SCALE,y),x.setMatrixAt(y,v.compose(m,f,_));for(const y in c)if(y==="_COLOR_0"){const A=c[y];x.instanceColor=new Ya(A.array,A.itemSize,A.normalized)}else y!=="TRANSLATION"&&y!=="ROTATION"&&y!=="SCALE"&&g.geometry.setAttribute(y,c[y]);bt.prototype.copy.call(x,g),this.parser.assignFinalMaterial(x),p.push(x)}return u.isGroup?(u.clear(),u.add(...p),u):p[0]}))}}const bf="glTF",gr=12,zd={JSON:1313821514,BIN:5130562};class oS{constructor(e){this.name=Qe.KHR_BINARY_GLTF,this.content=null,this.body=null;const t=new DataView(e,0,gr),n=new TextDecoder;if(this.header={magic:n.decode(new Uint8Array(e.slice(0,4))),version:t.getUint32(4,!0),length:t.getUint32(8,!0)},this.header.magic!==bf)throw new Error("THREE.GLTFLoader: Unsupported glTF-Binary header.");if(this.header.version<2)throw new Error("THREE.GLTFLoader: Legacy binary file detected.");const s=this.header.length-gr,r=new DataView(e,gr);let a=0;for(;a<s;){const o=r.getUint32(a,!0);a+=4;const c=r.getUint32(a,!0);if(a+=4,c===zd.JSON){const l=new Uint8Array(e,gr+a,o);this.content=n.decode(l)}else if(c===zd.BIN){const l=gr+a;this.body=e.slice(l,l+o)}a+=o}if(this.content===null)throw new Error("THREE.GLTFLoader: JSON content not found.")}}class lS{constructor(e,t){if(!t)throw new Error("THREE.GLTFLoader: No DRACOLoader instance provided.");this.name=Qe.KHR_DRACO_MESH_COMPRESSION,this.json=e,this.dracoLoader=t,this.dracoLoader.preload()}decodePrimitive(e,t){const n=this.json,s=this.dracoLoader,r=e.extensions[this.name].bufferView,a=e.extensions[this.name].attributes,o={},c={},l={};for(const u in a){const d=fc[u]||u.toLowerCase();o[d]=a[u]}for(const u in e.attributes){const d=fc[u]||u.toLowerCase();if(a[u]!==void 0){const h=n.accessors[e.attributes[u]],p=Is[h.componentType];l[d]=p.name,c[d]=h.normalized===!0}}return t.getDependency("bufferView",r).then(function(u){return new Promise(function(d,h){s.decodeDracoFile(u,function(p){for(const g in p.attributes){const v=p.attributes[g],m=c[g];m!==void 0&&(v.normalized=m)}d(p)},o,l,Qt,h)})})}}class cS{constructor(){this.name=Qe.KHR_TEXTURE_TRANSFORM}extendTexture(e,t){return(t.texCoord===void 0||t.texCoord===e.channel)&&t.offset===void 0&&t.rotation===void 0&&t.scale===void 0||(e=e.clone(),t.texCoord!==void 0&&(e.channel=t.texCoord),t.offset!==void 0&&e.offset.fromArray(t.offset),t.rotation!==void 0&&(e.rotation=t.rotation),t.scale!==void 0&&e.repeat.fromArray(t.scale),e.needsUpdate=!0),e}}class uS{constructor(){this.name=Qe.KHR_MESH_QUANTIZATION}}class Mf extends Vr{constructor(e,t,n,s){super(e,t,n,s)}copySampleValue_(e){const t=this.resultBuffer,n=this.sampleValues,s=this.valueSize,r=e*s*3+s;for(let a=0;a!==s;a++)t[a]=n[r+a];return t}interpolate_(e,t,n,s){const r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,c=o*2,l=o*3,u=s-t,d=(n-t)/u,h=d*d,p=h*d,g=e*l,v=g-l,m=-2*p+3*h,f=p-h,_=1-m,x=f-h+d;for(let y=0;y!==o;y++){const A=a[v+y+o],E=a[v+y+c]*u,M=a[g+y+o],C=a[g+y]*u;r[y]=_*A+x*E+m*M+f*C}return r}}const dS=new dt;class hS extends Mf{interpolate_(e,t,n,s){const r=super.interpolate_(e,t,n,s);return dS.fromArray(r).normalize().toArray(r),r}}const En={POINTS:0,LINES:1,LINE_LOOP:2,LINE_STRIP:3,TRIANGLES:4,TRIANGLE_STRIP:5,TRIANGLE_FAN:6},Is={5120:Int8Array,5121:Uint8Array,5122:Int16Array,5123:Uint16Array,5125:Uint32Array,5126:Float32Array},Vd={9728:Jt,9729:Lt,9984:Uh,9985:Na,9986:xr,9987:Gt},Hd={33071:Ri,33648:Ga,10497:Bs},hl={SCALAR:1,VEC2:2,VEC3:3,VEC4:4,MAT2:4,MAT3:9,MAT4:16},fc={POSITION:"position",NORMAL:"normal",TANGENT:"tangent",TEXCOORD_0:"uv",TEXCOORD_1:"uv1",TEXCOORD_2:"uv2",TEXCOORD_3:"uv3",COLOR_0:"color",WEIGHTS_0:"skinWeight",JOINTS_0:"skinIndex"},yi={scale:"scale",translation:"position",rotation:"quaternion",weights:"morphTargetInfluences"},fS={CUBICSPLINE:void 0,LINEAR:Pr,STEP:Ir},fl={OPAQUE:"OPAQUE",MASK:"MASK",BLEND:"BLEND"};function pS(i){return i.DefaultMaterial===void 0&&(i.DefaultMaterial=new qc({color:16777215,emissive:0,metalness:1,roughness:1,transparent:!1,depthTest:!0,side:fi})),i.DefaultMaterial}function Wi(i,e,t){for(const n in t.extensions)i[n]===void 0&&(e.userData.gltfExtensions=e.userData.gltfExtensions||{},e.userData.gltfExtensions[n]=t.extensions[n])}function Hn(i,e){e.extras!==void 0&&(typeof e.extras=="object"?Object.assign(i.userData,e.extras):console.warn("THREE.GLTFLoader: Ignoring primitive type .extras, "+e.extras))}function mS(i,e,t){let n=!1,s=!1,r=!1;for(let l=0,u=e.length;l<u;l++){const d=e[l];if(d.POSITION!==void 0&&(n=!0),d.NORMAL!==void 0&&(s=!0),d.COLOR_0!==void 0&&(r=!0),n&&s&&r)break}if(!n&&!s&&!r)return Promise.resolve(i);const a=[],o=[],c=[];for(let l=0,u=e.length;l<u;l++){const d=e[l];if(n){const h=d.POSITION!==void 0?t.getDependency("accessor",d.POSITION):i.attributes.position;a.push(h)}if(s){const h=d.NORMAL!==void 0?t.getDependency("accessor",d.NORMAL):i.attributes.normal;o.push(h)}if(r){const h=d.COLOR_0!==void 0?t.getDependency("accessor",d.COLOR_0):i.attributes.color;c.push(h)}}return Promise.all([Promise.all(a),Promise.all(o),Promise.all(c)]).then(function(l){const u=l[0],d=l[1],h=l[2];return n&&(i.morphAttributes.position=u),s&&(i.morphAttributes.normal=d),r&&(i.morphAttributes.color=h),i.morphTargetsRelative=!0,i})}function gS(i,e){if(i.updateMorphTargets(),e.weights!==void 0)for(let t=0,n=e.weights.length;t<n;t++)i.morphTargetInfluences[t]=e.weights[t];if(e.extras&&Array.isArray(e.extras.targetNames)){const t=e.extras.targetNames;if(i.morphTargetInfluences.length===t.length){i.morphTargetDictionary={};for(let n=0,s=t.length;n<s;n++)i.morphTargetDictionary[t[n]]=n}else console.warn("THREE.GLTFLoader: Invalid extras.targetNames length. Ignoring names.")}}function vS(i){let e;const t=i.extensions&&i.extensions[Qe.KHR_DRACO_MESH_COMPRESSION];if(t?e="draco:"+t.bufferView+":"+t.indices+":"+pl(t.attributes):e=i.indices+":"+pl(i.attributes)+":"+i.mode,i.targets!==void 0)for(let n=0,s=i.targets.length;n<s;n++)e+=":"+pl(i.targets[n]);return e}function pl(i){let e="";const t=Object.keys(i).sort();for(let n=0,s=t.length;n<s;n++)e+=t[n]+":"+i[t[n]]+";";return e}function pc(i){switch(i){case Int8Array:return 1/127;case Uint8Array:return 1/255;case Int16Array:return 1/32767;case Uint16Array:return 1/65535;default:throw new Error("THREE.GLTFLoader: Unsupported normalized accessor component type.")}}function _S(i){return i.search(/\.jpe?g($|\?)/i)>0||i.search(/^data\:image\/jpeg/)===0?"image/jpeg":i.search(/\.webp($|\?)/i)>0||i.search(/^data\:image\/webp/)===0?"image/webp":i.search(/\.ktx2($|\?)/i)>0||i.search(/^data\:image\/ktx2/)===0?"image/ktx2":"image/png"}const xS=new Ye;class yS{constructor(e={},t={}){this.json=e,this.extensions={},this.plugins={},this.options=t,this.cache=new Hy,this.associations=new Map,this.primitiveCache={},this.nodeCache={},this.meshCache={refs:{},uses:{}},this.cameraCache={refs:{},uses:{}},this.lightCache={refs:{},uses:{}},this.sourceCache={},this.textureCache={},this.nodeNamesUsed={};let n=!1,s=-1,r=!1,a=-1;if(typeof navigator<"u"){const o=navigator.userAgent;n=/^((?!chrome|android).)*safari/i.test(o)===!0;const c=o.match(/Version\/(\d+)/);s=n&&c?parseInt(c[1],10):-1,r=o.indexOf("Firefox")>-1,a=r?o.match(/Firefox\/([0-9]+)\./)[1]:-1}typeof createImageBitmap>"u"||n&&s<17||r&&a<98?this.textureLoader=new Qs(this.options.manager):this.textureLoader=new dg(this.options.manager),this.textureLoader.setCrossOrigin(this.options.crossOrigin),this.textureLoader.setRequestHeader(this.options.requestHeader),this.fileLoader=new df(this.options.manager),this.fileLoader.setResponseType("arraybuffer"),this.options.crossOrigin==="use-credentials"&&this.fileLoader.setWithCredentials(!0)}setExtensions(e){this.extensions=e}setPlugins(e){this.plugins=e}parse(e,t){const n=this,s=this.json,r=this.extensions;this.cache.removeAll(),this.nodeCache={},this._invokeAll(function(a){return a._markDefs&&a._markDefs()}),Promise.all(this._invokeAll(function(a){return a.beforeRoot&&a.beforeRoot()})).then(function(){return Promise.all([n.getDependencies("scene"),n.getDependencies("animation"),n.getDependencies("camera")])}).then(function(a){const o={scene:a[0][s.scene||0],scenes:a[0],animations:a[1],cameras:a[2],asset:s.asset,parser:n,userData:{}};return Wi(r,o,s),Hn(o,s),Promise.all(n._invokeAll(function(c){return c.afterRoot&&c.afterRoot(o)})).then(function(){for(const c of o.scenes)c.updateMatrixWorld();e(o)})}).catch(t)}_markDefs(){const e=this.json.nodes||[],t=this.json.skins||[],n=this.json.meshes||[];for(let s=0,r=t.length;s<r;s++){const a=t[s].joints;for(let o=0,c=a.length;o<c;o++)e[a[o]].isBone=!0}for(let s=0,r=e.length;s<r;s++){const a=e[s];a.mesh!==void 0&&(this._addNodeRef(this.meshCache,a.mesh),a.skin!==void 0&&(n[a.mesh].isSkinnedMesh=!0)),a.camera!==void 0&&this._addNodeRef(this.cameraCache,a.camera)}}_addNodeRef(e,t){t!==void 0&&(e.refs[t]===void 0&&(e.refs[t]=e.uses[t]=0),e.refs[t]++)}_getNodeRef(e,t,n){if(e.refs[t]<=1)return n;const s=n.clone(),r=(a,o)=>{const c=this.associations.get(a);c!=null&&this.associations.set(o,c);for(const[l,u]of a.children.entries())r(u,o.children[l])};return r(n,s),s.name+="_instance_"+e.uses[t]++,s}_invokeOne(e){const t=Object.values(this.plugins);t.push(this);for(let n=0;n<t.length;n++){const s=e(t[n]);if(s)return s}return null}_invokeAll(e){const t=Object.values(this.plugins);t.unshift(this);const n=[];for(let s=0;s<t.length;s++){const r=e(t[s]);r&&n.push(r)}return n}getDependency(e,t){const n=e+":"+t;let s=this.cache.get(n);if(!s){switch(e){case"scene":s=this.loadScene(t);break;case"node":s=this._invokeOne(function(r){return r.loadNode&&r.loadNode(t)});break;case"mesh":s=this._invokeOne(function(r){return r.loadMesh&&r.loadMesh(t)});break;case"accessor":s=this.loadAccessor(t);break;case"bufferView":s=this._invokeOne(function(r){return r.loadBufferView&&r.loadBufferView(t)});break;case"buffer":s=this.loadBuffer(t);break;case"material":s=this._invokeOne(function(r){return r.loadMaterial&&r.loadMaterial(t)});break;case"texture":s=this._invokeOne(function(r){return r.loadTexture&&r.loadTexture(t)});break;case"skin":s=this.loadSkin(t);break;case"animation":s=this._invokeOne(function(r){return r.loadAnimation&&r.loadAnimation(t)});break;case"camera":s=this.loadCamera(t);break;default:if(s=this._invokeOne(function(r){return r!=this&&r.getDependency&&r.getDependency(e,t)}),!s)throw new Error("Unknown type: "+e);break}this.cache.add(n,s)}return s}getDependencies(e){let t=this.cache.get(e);if(!t){const n=this,s=this.json[e+(e==="mesh"?"es":"s")]||[];t=Promise.all(s.map(function(r,a){return n.getDependency(e,a)})),this.cache.add(e,t)}return t}loadBuffer(e){const t=this.json.buffers[e],n=this.fileLoader;if(t.type&&t.type!=="arraybuffer")throw new Error("THREE.GLTFLoader: "+t.type+" buffer type is not supported.");if(t.uri===void 0&&e===0)return Promise.resolve(this.extensions[Qe.KHR_BINARY_GLTF].body);const s=this.options;return new Promise(function(r,a){n.load(Er.resolveURL(t.uri,s.path),r,void 0,function(){a(new Error('THREE.GLTFLoader: Failed to load buffer "'+t.uri+'".'))})})}loadBufferView(e){const t=this.json.bufferViews[e];return this.getDependency("buffer",t.buffer).then(function(n){const s=t.byteLength||0,r=t.byteOffset||0;return n.slice(r,r+s)})}loadAccessor(e){const t=this,n=this.json,s=this.json.accessors[e];if(s.bufferView===void 0&&s.sparse===void 0){const a=hl[s.type],o=Is[s.componentType],c=s.normalized===!0,l=new o(s.count*a);return Promise.resolve(new ct(l,a,c))}const r=[];return s.bufferView!==void 0?r.push(this.getDependency("bufferView",s.bufferView)):r.push(null),s.sparse!==void 0&&(r.push(this.getDependency("bufferView",s.sparse.indices.bufferView)),r.push(this.getDependency("bufferView",s.sparse.values.bufferView))),Promise.all(r).then(function(a){const o=a[0],c=hl[s.type],l=Is[s.componentType],u=l.BYTES_PER_ELEMENT,d=u*c,h=s.byteOffset||0,p=s.bufferView!==void 0?n.bufferViews[s.bufferView].byteStride:void 0,g=s.normalized===!0;let v,m;if(p&&p!==d){const f=Math.floor(h/p),_="InterleavedBuffer:"+s.bufferView+":"+s.componentType+":"+f+":"+s.count;let x=t.cache.get(_);x||(v=new l(o,f*p,s.count*p/u),x=new tf(v,p/u),t.cache.add(_,x)),m=new Nr(x,c,h%p/u,g)}else o===null?v=new l(s.count*c):v=new l(o,h,s.count*c),m=new ct(v,c,g);if(s.sparse!==void 0){const f=hl.SCALAR,_=Is[s.sparse.indices.componentType],x=s.sparse.indices.byteOffset||0,y=s.sparse.values.byteOffset||0,A=new _(a[1],x,s.sparse.count*f),E=new l(a[2],y,s.sparse.count*c);o!==null&&(m=new ct(m.array.slice(),m.itemSize,m.normalized)),m.normalized=!1;for(let M=0,C=A.length;M<C;M++){const b=A[M];if(m.setX(b,E[M*c]),c>=2&&m.setY(b,E[M*c+1]),c>=3&&m.setZ(b,E[M*c+2]),c>=4&&m.setW(b,E[M*c+3]),c>=5)throw new Error("THREE.GLTFLoader: Unsupported itemSize in sparse BufferAttribute.")}m.normalized=g}return m})}loadTexture(e){const t=this.json,n=this.options,r=t.textures[e].source,a=t.images[r];let o=this.textureLoader;if(a.uri){const c=n.manager.getHandler(a.uri);c!==null&&(o=c)}return this.loadTextureImage(e,r,o)}loadTextureImage(e,t,n){const s=this,r=this.json,a=r.textures[e],o=r.images[t],c=(o.uri||o.bufferView)+":"+a.sampler;if(this.textureCache[c])return this.textureCache[c];const l=this.loadImageSource(t,n).then(function(u){u.flipY=!1,u.name=a.name||o.name||"",u.name===""&&typeof o.uri=="string"&&o.uri.startsWith("data:image/")===!1&&(u.name=o.uri);const h=(r.samplers||{})[a.sampler]||{};return u.magFilter=Vd[h.magFilter]||Lt,u.minFilter=Vd[h.minFilter]||Gt,u.wrapS=Hd[h.wrapS]||Bs,u.wrapT=Hd[h.wrapT]||Bs,u.generateMipmaps=!u.isCompressedTexture&&u.minFilter!==Jt&&u.minFilter!==Lt,s.associations.set(u,{textures:e}),u}).catch(function(){return null});return this.textureCache[c]=l,l}loadImageSource(e,t){const n=this,s=this.json,r=this.options;if(this.sourceCache[e]!==void 0)return this.sourceCache[e].then(d=>d.clone());const a=s.images[e],o=self.URL||self.webkitURL;let c=a.uri||"",l=!1;if(a.bufferView!==void 0)c=n.getDependency("bufferView",a.bufferView).then(function(d){l=!0;const h=new Blob([d],{type:a.mimeType});return c=o.createObjectURL(h),c});else if(a.uri===void 0)throw new Error("THREE.GLTFLoader: Image "+e+" is missing URI and bufferView");const u=Promise.resolve(c).then(function(d){return new Promise(function(h,p){let g=h;t.isImageBitmapLoader===!0&&(g=function(v){const m=new Ft(v);m.needsUpdate=!0,h(m)}),t.load(Er.resolveURL(d,r.path),g,void 0,p)})}).then(function(d){return l===!0&&o.revokeObjectURL(c),Hn(d,a),d.userData.mimeType=a.mimeType||_S(a.uri),d}).catch(function(d){throw console.error("THREE.GLTFLoader: Couldn't load texture",c),d});return this.sourceCache[e]=u,u}assignTexture(e,t,n,s){const r=this;return this.getDependency("texture",n.index).then(function(a){if(!a)return null;if(n.texCoord!==void 0&&n.texCoord>0&&(a=a.clone(),a.channel=n.texCoord),r.extensions[Qe.KHR_TEXTURE_TRANSFORM]){const o=n.extensions!==void 0?n.extensions[Qe.KHR_TEXTURE_TRANSFORM]:void 0;if(o){const c=r.associations.get(a);a=r.extensions[Qe.KHR_TEXTURE_TRANSFORM].extendTexture(a,o),r.associations.set(a,c)}}return s!==void 0&&(a.colorSpace=s),e[t]=a,a})}assignFinalMaterial(e){const t=e.geometry;let n=e.material;const s=t.attributes.tangent===void 0,r=t.attributes.color!==void 0,a=t.attributes.normal===void 0;if(e.isPoints){const o="PointsMaterial:"+n.uuid;let c=this.cache.get(o);c||(c=new af,Rn.prototype.copy.call(c,n),c.color.copy(n.color),c.map=n.map,c.sizeAttenuation=!1,this.cache.add(o,c)),n=c}else if(e.isLine){const o="LineBasicMaterial:"+n.uuid;let c=this.cache.get(o);c||(c=new Vc,Rn.prototype.copy.call(c,n),c.color.copy(n.color),c.map=n.map,this.cache.add(o,c)),n=c}if(s||r||a){let o="ClonedMaterial:"+n.uuid+":";s&&(o+="derivative-tangents:"),r&&(o+="vertex-colors:"),a&&(o+="flat-shading:");let c=this.cache.get(o);c||(c=n.clone(),r&&(c.vertexColors=!0),a&&(c.flatShading=!0),s&&(c.normalScale&&(c.normalScale.y*=-1),c.clearcoatNormalScale&&(c.clearcoatNormalScale.y*=-1)),this.cache.add(o,c),this.associations.set(c,this.associations.get(n))),n=c}e.material=n}getMaterialType(){return qc}loadMaterial(e){const t=this,n=this.json,s=this.extensions,r=n.materials[e];let a;const o={},c=r.extensions||{},l=[];if(c[Qe.KHR_MATERIALS_UNLIT]){const d=s[Qe.KHR_MATERIALS_UNLIT];a=d.getMaterialType(),l.push(d.extendParams(o,r,t))}else{const d=r.pbrMetallicRoughness||{};if(o.color=new Re(1,1,1),o.opacity=1,Array.isArray(d.baseColorFactor)){const h=d.baseColorFactor;o.color.setRGB(h[0],h[1],h[2],Qt),o.opacity=h[3]}d.baseColorTexture!==void 0&&l.push(t.assignTexture(o,"map",d.baseColorTexture,_t)),o.metalness=d.metallicFactor!==void 0?d.metallicFactor:1,o.roughness=d.roughnessFactor!==void 0?d.roughnessFactor:1,d.metallicRoughnessTexture!==void 0&&(l.push(t.assignTexture(o,"metalnessMap",d.metallicRoughnessTexture)),l.push(t.assignTexture(o,"roughnessMap",d.metallicRoughnessTexture))),a=this._invokeOne(function(h){return h.getMaterialType&&h.getMaterialType(e)}),l.push(Promise.all(this._invokeAll(function(h){return h.extendMaterialParams&&h.extendMaterialParams(e,o)})))}r.doubleSided===!0&&(o.side=Mt);const u=r.alphaMode||fl.OPAQUE;if(u===fl.BLEND?(o.transparent=!0,o.depthWrite=!1):(o.transparent=!1,u===fl.MASK&&(o.alphaTest=r.alphaCutoff!==void 0?r.alphaCutoff:.5)),r.normalTexture!==void 0&&a!==Ut&&(l.push(t.assignTexture(o,"normalMap",r.normalTexture)),o.normalScale=new Ie(1,1),r.normalTexture.scale!==void 0)){const d=r.normalTexture.scale;o.normalScale.set(d,d)}if(r.occlusionTexture!==void 0&&a!==Ut&&(l.push(t.assignTexture(o,"aoMap",r.occlusionTexture)),r.occlusionTexture.strength!==void 0&&(o.aoMapIntensity=r.occlusionTexture.strength)),r.emissiveFactor!==void 0&&a!==Ut){const d=r.emissiveFactor;o.emissive=new Re().setRGB(d[0],d[1],d[2],Qt)}return r.emissiveTexture!==void 0&&a!==Ut&&l.push(t.assignTexture(o,"emissiveMap",r.emissiveTexture,_t)),Promise.all(l).then(function(){const d=new a(o);return r.name&&(d.name=r.name),Hn(d,r),t.associations.set(d,{materials:e}),r.extensions&&Wi(s,d,r),d})}createUniqueName(e){const t=lt.sanitizeNodeName(e||"");return t in this.nodeNamesUsed?t+"_"+ ++this.nodeNamesUsed[t]:(this.nodeNamesUsed[t]=0,t)}loadGeometries(e){const t=this,n=this.extensions,s=this.primitiveCache;function r(o){return n[Qe.KHR_DRACO_MESH_COMPRESSION].decodePrimitive(o,t).then(function(c){return Gd(c,o,t)})}const a=[];for(let o=0,c=e.length;o<c;o++){const l=e[o],u=vS(l),d=s[u];if(d)a.push(d.promise);else{let h;l.extensions&&l.extensions[Qe.KHR_DRACO_MESH_COMPRESSION]?h=r(l):h=Gd(new It,l,t),s[u]={primitive:l,promise:h},a.push(h)}}return Promise.all(a)}loadMesh(e){const t=this,n=this.json,s=this.extensions,r=n.meshes[e],a=r.primitives,o=[];for(let c=0,l=a.length;c<l;c++){const u=a[c].material===void 0?pS(this.cache):this.getDependency("material",a[c].material);o.push(u)}return o.push(t.loadGeometries(a)),Promise.all(o).then(function(c){const l=c.slice(0,c.length-1),u=c[c.length-1],d=[];for(let p=0,g=u.length;p<g;p++){const v=u[p],m=a[p];let f;const _=l[p];if(m.mode===En.TRIANGLES||m.mode===En.TRIANGLE_STRIP||m.mode===En.TRIANGLE_FAN||m.mode===void 0)f=r.isSkinnedMesh===!0?new kc(v,_):new pt(v,_),f.isSkinnedMesh===!0&&f.normalizeSkinWeights(),m.mode===En.TRIANGLE_STRIP?f.geometry=Bd(f.geometry,Wh):m.mode===En.TRIANGLE_FAN&&(f.geometry=Bd(f.geometry,lc));else if(m.mode===En.LINES)f=new rf(v,_);else if(m.mode===En.LINE_STRIP)f=new Hc(v,_);else if(m.mode===En.LINE_LOOP)f=new Vm(v,_);else if(m.mode===En.POINTS)f=new Gc(v,_);else throw new Error("THREE.GLTFLoader: Primitive mode unsupported: "+m.mode);Object.keys(f.geometry.morphAttributes).length>0&&gS(f,r),f.name=t.createUniqueName(r.name||"mesh_"+e),Hn(f,r),m.extensions&&Wi(s,f,m),t.assignFinalMaterial(f),d.push(f)}for(let p=0,g=d.length;p<g;p++)t.associations.set(d[p],{meshes:e,primitives:p});if(d.length===1)return r.extensions&&Wi(s,d[0],r),d[0];const h=new At;r.extensions&&Wi(s,h,r),t.associations.set(h,{meshes:e});for(let p=0,g=d.length;p<g;p++)h.add(d[p]);return h})}loadCamera(e){let t;const n=this.json.cameras[e],s=n[n.type];if(!s){console.warn("THREE.GLTFLoader: Missing camera parameters.");return}return n.type==="perspective"?t=new Kt(_e.radToDeg(s.yfov),s.aspectRatio||1,s.znear||1,s.zfar||2e6):n.type==="orthographic"&&(t=new Hr(-s.xmag,s.xmag,s.ymag,-s.ymag,s.znear,s.zfar)),n.name&&(t.name=this.createUniqueName(n.name)),Hn(t,n),Promise.resolve(t)}loadSkin(e){const t=this.json.skins[e],n=[];for(let s=0,r=t.joints.length;s<r;s++)n.push(this._loadNodeShallow(t.joints[s]));return t.inverseBindMatrices!==void 0?n.push(this.getDependency("accessor",t.inverseBindMatrices)):n.push(null),Promise.all(n).then(function(s){const r=s.pop(),a=s,o=[],c=[];for(let l=0,u=a.length;l<u;l++){const d=a[l];if(d){o.push(d);const h=new Ye;r!==null&&h.fromArray(r.array,l*16),c.push(h)}else console.warn('THREE.GLTFLoader: Joint "%s" could not be found.',t.joints[l])}return new zr(o,c)})}loadAnimation(e){const t=this.json,n=this,s=t.animations[e],r=s.name?s.name:"animation_"+e,a=[],o=[],c=[],l=[],u=[];for(let d=0,h=s.channels.length;d<h;d++){const p=s.channels[d],g=s.samplers[p.sampler],v=p.target,m=v.node,f=s.parameters!==void 0?s.parameters[g.input]:g.input,_=s.parameters!==void 0?s.parameters[g.output]:g.output;v.node!==void 0&&(a.push(this.getDependency("node",m)),o.push(this.getDependency("accessor",f)),c.push(this.getDependency("accessor",_)),l.push(g),u.push(v))}return Promise.all([Promise.all(a),Promise.all(o),Promise.all(c),Promise.all(l),Promise.all(u)]).then(function(d){const h=d[0],p=d[1],g=d[2],v=d[3],m=d[4],f=[];for(let x=0,y=h.length;x<y;x++){const A=h[x],E=p[x],M=g[x],C=v[x],b=m[x];if(A===void 0)continue;A.updateMatrix&&A.updateMatrix();const S=n._createAnimationTracks(A,E,M,C,b);if(S)for(let I=0;I<S.length;I++)f.push(S[I])}const _=new Zm(r,void 0,f);return Hn(_,s),_})}createNodeMesh(e){const t=this.json,n=this,s=t.nodes[e];return s.mesh===void 0?null:n.getDependency("mesh",s.mesh).then(function(r){const a=n._getNodeRef(n.meshCache,s.mesh,r);return s.weights!==void 0&&a.traverse(function(o){if(o.isMesh)for(let c=0,l=s.weights.length;c<l;c++)o.morphTargetInfluences[c]=s.weights[c]}),a})}loadNode(e){const t=this.json,n=this,s=t.nodes[e],r=n._loadNodeShallow(e),a=[],o=s.children||[];for(let l=0,u=o.length;l<u;l++)a.push(n.getDependency("node",o[l]));const c=s.skin===void 0?Promise.resolve(null):n.getDependency("skin",s.skin);return Promise.all([r,Promise.all(a),c]).then(function(l){const u=l[0],d=l[1],h=l[2];h!==null&&u.traverse(function(p){p.isSkinnedMesh&&p.bind(h,xS)});for(let p=0,g=d.length;p<g;p++)u.add(d[p]);return u})}_loadNodeShallow(e){const t=this.json,n=this.extensions,s=this;if(this.nodeCache[e]!==void 0)return this.nodeCache[e];const r=t.nodes[e],a=r.name?s.createUniqueName(r.name):"",o=[],c=s._invokeOne(function(l){return l.createNodeMesh&&l.createNodeMesh(e)});return c&&o.push(c),r.camera!==void 0&&o.push(s.getDependency("camera",r.camera).then(function(l){return s._getNodeRef(s.cameraCache,r.camera,l)})),s._invokeAll(function(l){return l.createNodeAttachment&&l.createNodeAttachment(e)}).forEach(function(l){o.push(l)}),this.nodeCache[e]=Promise.all(o).then(function(l){let u;if(r.isBone===!0?u=new lo:l.length>1?u=new At:l.length===1?u=l[0]:u=new bt,u!==l[0])for(let d=0,h=l.length;d<h;d++)u.add(l[d]);if(r.name&&(u.userData.name=r.name,u.name=a),Hn(u,r),r.extensions&&Wi(n,u,r),r.matrix!==void 0){const d=new Ye;d.fromArray(r.matrix),u.applyMatrix4(d)}else r.translation!==void 0&&u.position.fromArray(r.translation),r.rotation!==void 0&&u.quaternion.fromArray(r.rotation),r.scale!==void 0&&u.scale.fromArray(r.scale);if(!s.associations.has(u))s.associations.set(u,{});else if(r.mesh!==void 0&&s.meshCache.refs[r.mesh]>1){const d=s.associations.get(u);s.associations.set(u,{...d})}return s.associations.get(u).nodes=e,u}),this.nodeCache[e]}loadScene(e){const t=this.extensions,n=this.json.scenes[e],s=this,r=new At;n.name&&(r.name=s.createUniqueName(n.name)),Hn(r,n),n.extensions&&Wi(t,r,n);const a=n.nodes||[],o=[];for(let c=0,l=a.length;c<l;c++)o.push(s.getDependency("node",a[c]));return Promise.all(o).then(function(c){for(let u=0,d=c.length;u<d;u++)r.add(c[u]);const l=u=>{const d=new Map;for(const[h,p]of s.associations)(h instanceof Rn||h instanceof Ft)&&d.set(h,p);return u.traverse(h=>{const p=s.associations.get(h);p!=null&&d.set(h,p)}),d};return s.associations=l(r),r})}_createAnimationTracks(e,t,n,s,r){const a=[],o=e.name?e.name:e.uuid,c=[];yi[r.path]===yi.weights?e.traverse(function(h){h.morphTargetInfluences&&c.push(h.name?h.name:h.uuid)}):c.push(o);let l;switch(yi[r.path]){case yi.weights:l=Vs;break;case yi.rotation:l=Hs;break;case yi.translation:case yi.scale:l=Gs;break;default:switch(n.itemSize){case 1:l=Vs;break;case 2:case 3:default:l=Gs;break}break}const u=s.interpolation!==void 0?fS[s.interpolation]:Pr,d=this._getArrayFromAccessor(n);for(let h=0,p=c.length;h<p;h++){const g=new l(c[h]+"."+yi[r.path],t.array,d,u);s.interpolation==="CUBICSPLINE"&&this._createCubicSplineTrackInterpolant(g),a.push(g)}return a}_getArrayFromAccessor(e){let t=e.array;if(e.normalized){const n=pc(t.constructor),s=new Float32Array(t.length);for(let r=0,a=t.length;r<a;r++)s[r]=t[r]*n;t=s}return t}_createCubicSplineTrackInterpolant(e){e.createInterpolant=function(n){const s=this instanceof Hs?hS:Mf;return new s(this.times,this.values,this.getValueSize()/3,n)},e.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline=!0}}function SS(i,e,t){const n=e.attributes,s=new jn;if(n.POSITION!==void 0){const o=t.json.accessors[n.POSITION],c=o.min,l=o.max;if(c!==void 0&&l!==void 0){if(s.set(new N(c[0],c[1],c[2]),new N(l[0],l[1],l[2])),o.normalized){const u=pc(Is[o.componentType]);s.min.multiplyScalar(u),s.max.multiplyScalar(u)}}else{console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.");return}}else return;const r=e.targets;if(r!==void 0){const o=new N,c=new N;for(let l=0,u=r.length;l<u;l++){const d=r[l];if(d.POSITION!==void 0){const h=t.json.accessors[d.POSITION],p=h.min,g=h.max;if(p!==void 0&&g!==void 0){if(c.setX(Math.max(Math.abs(p[0]),Math.abs(g[0]))),c.setY(Math.max(Math.abs(p[1]),Math.abs(g[1]))),c.setZ(Math.max(Math.abs(p[2]),Math.abs(g[2]))),h.normalized){const v=pc(Is[h.componentType]);c.multiplyScalar(v)}o.max(c)}else console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.")}}s.expandByVector(o)}i.boundingBox=s;const a=new $n;s.getCenter(a.center),a.radius=s.min.distanceTo(s.max)/2,i.boundingSphere=a}function Gd(i,e,t){const n=e.attributes,s=[];function r(a,o){return t.getDependency("accessor",a).then(function(c){i.setAttribute(o,c)})}for(const a in n){const o=fc[a]||a.toLowerCase();o in i.attributes||s.push(r(n[a],o))}if(e.indices!==void 0&&!i.index){const a=t.getDependency("accessor",e.indices).then(function(o){i.setIndex(o)});s.push(a)}return tt.workingColorSpace!==Qt&&"COLOR_0"in n&&console.warn(`THREE.GLTFLoader: Converting vertex colors from "srgb-linear" to "${tt.workingColorSpace}" not supported.`),Hn(i,e),SS(i,e,t),Promise.all(s).then(function(){return e.targets!==void 0?mS(i,e.targets,t):i})}const bS="/models/wrad-arms.glb",MS=["finger_index","finger_middle","finger_ring","finger_pinky","finger_thumb"],ES=new N(1,0,0),Wd=new dt,Xd=new N;function TS(i,{enabled:e=!0,reducedMotion:t=!1}={}){const n={mode:"rig",enabled:!!e,visible:!!e,motionEnabled:!t,loaded:!1,loadError:null,joints:0,fingerJoints:0,drawSurfaces:0,textureCount:0,triangles:0,leftX:0,rightX:0,swayX:0,swayY:0};if(!e)return{state:n,meshes:[],ready:Promise.resolve(!1),update(){},resize(){},beginTravel(){},dispose(){}};const s=new At;s.name="Órion · viewmodel rigado de primeira pessoa",i.add(s);const r=[],a=[],o=[],c=[],l={disposed:!1};let u=0,d=0,h=-.4,p=1,g=null,v=null;const m={depth:2.5,wristNdcX:.47,wristNdcY:-.84,pitch:Math.PI};function f(){if(!n.loaded||!v)return;const C=Math.tan(_e.degToRad(i.fov*.5)),b=C*i.aspect,{left:S,right:I}=v,D=Math.abs(I.x-S.x)*.5,w=(I.z+S.z)*.5,U=-w,O=m.wristNdcX*b*m.depth/(D+m.wristNdcX*b*U);p=_e.clamp(O,.06,.45);const F=m.depth-U*p,V=(I.y+S.y)*.5;s.scale.setScalar(p),s.rotation.set(m.pitch,0,0),s.position.set(-(S.x+I.x)*.5*p,m.wristNdcY*C*F+V*p,-2.5),h=s.position.y,n.leftX=-.47*b*F,n.rightX=m.wristNdcX*b*F,n.framing={...m,scale:p,baseY:h,wristDepth:F,halfSpan:D,localWristY:V,localWristZ:w},i.updateMatrixWorld(!0),s.updateMatrixWorld(!0);function k(z){if(!z)return null;const B=z.getWorldPosition(new N).project(i);return{x:B.x,y:B.y,z:B.z}}n.projectedWristLeft=k(g?.get("wristl")),n.projectedWristRight=k(g?.get("wristr")),n.projectedMiddleLeft=k(g?.get("finger_middle3l")),n.projectedMiddleRight=k(g?.get("finger_middle3r")),n.projectedShoulderLeft=k(g?.get("shoulderl")),n.projectedShoulderRight=k(g?.get("shoulderr"))}function _(C){if(l.disposed){C.scene.traverse(O=>{O.isMesh&&(O.geometry?.dispose?.(),O.material?.dispose?.())});return}const b=C.scene;b.updateMatrixWorld(!0);const S=new jn().setFromObject(b),I=new N,D=new N;if(S.getSize(I),S.getCenter(D),!Number.isFinite(I.x)||I.x<.001)throw new Error("Bounding box inválida no WRAD ARMS");n.modelBounds={width:I.x,centerX:D.x,top:S.max.y};const w=new Map;if(b.traverse(O=>{if(O.isBone&&w.set(O.name,O),!O.isMesh)return;const V=(Array.isArray(O.material)?O.material[0]:O.material)?.map||null;V&&!c.includes(V)&&c.push(V);const k=O.geometry,z=k.getAttribute("position"),B=new Float32Array(z.count*4);for(let ne=0;ne<z.count;ne++){const Q=_e.smoothstep(Math.abs(z.getX(ne)),3.65,4.87);B[ne*4]=1,B[ne*4+1]=1,B[ne*4+2]=1,B[ne*4+3]=Q}k.setAttribute("color",new nt(B,4));const j=new Ut({map:V,color:7830173,vertexColors:!0,transparent:!0,opacity:.86,depthTest:!1,depthWrite:!1,toneMapped:!1,side:Mt});o.push(j),O.material=j,O.layers.set(0),O.renderOrder=30,O.frustumCulled=!1,r.push(O),n.triangles+=(k.index?.count||k.attributes.position?.count||0)/3}),!r.some(O=>O.isSkinnedMesh))throw new Error("WRAD ARMS veio sem malha SkinnedMesh");for(const[O,F]of w){if(!/^finger_(index|middle|ring|pinky|thumb)[123][._]?[lr]$/.test(O))continue;const V=/^finger_([a-z]+)([123])[._]?([lr])$/.exec(O),k=Number(V[2]),z=V[3];a.push({name:O,bone:F,base:F.quaternion.clone(),side:z==="l"?1:-1,segment:k,offset:MS.indexOf("finger_"+V[1])*.73})}if(a.length<30)throw new Error("Rig incompleto: "+a.length+" falanges de "+w.size+" ossos");g=w,n.joints=w.size,n.fingerJoints=a.length,n.textureCount=c.length,n.drawSurfaces=r.length,b.name="WRAD ARMS CC0 · 50 ossos",s.add(b),s.updateMatrixWorld(!0);const U=O=>{const F=w.get(O);if(!F)throw new Error("Ausência de landmark do punho: "+O);return s.worldToLocal(F.getWorldPosition(new N))};v={left:U("wristl"),right:U("wristr")},n.loaded=!0,f(),s.visible=n.visible}const x=new Promise(C=>{new Jc().load(bS,b=>{try{_(b),C(!0)}catch(S){n.loadError=String(S.message||S),C(!1)}},void 0,b=>{n.loadError=String(b?.message||b),C(!1)})});function y(C,b,S=0,I=0){if(!n.loaded||!n.visible)return;const D=_e.clamp(S,-1,1),w=_e.clamp(I,-1,1),U=n.motionEnabled?1-Math.exp(-Math.min(Math.max(b,0),.06)*7.5):1;u+=(D-u)*U,d+=(w-d)*U,n.swayX=n.motionEnabled?u:0,n.swayY=n.motionEnabled?d:0;const O=Math.tan(_e.degToRad(i.fov*.5))*1.35,F=O*i.aspect,V=n.motionEnabled?Math.sin(C*.72)*.007:0;s.position.x=-(n.modelBounds?.centerX||0)*p-n.swayX*F*.023,s.position.y=h-n.swayY*O*.02+V*O,s.rotation.set(m.pitch+(n.motionEnabled?n.swayY*.012:0),0,n.motionEnabled?n.swayX*.015:0);const k=C*.91;for(const z of a){const j=(n.motionEnabled?.027*Math.sin(k+z.offset+(z.side>0?.4:1.1))+.012*n.swayY:0)*(z.segment===1?1:z.segment===2?.72:.48)*z.side;Xd.copy(ES),Wd.setFromAxisAngle(Xd,j),z.bone.quaternion.copy(z.base).multiply(Wd)}}function A(){f()}function E(){n.visible=!1,s.visible=!1}function M(){l.disposed=!0,i.remove(s);for(const C of r)C.geometry?.dispose?.();for(const C of o)C.dispose();for(const C of c)C.dispose();s.clear()}return{state:n,meshes:r,rigRoot:s,driven:a,ready:x,update:y,resize:A,beginTravel:E,dispose:M}}const AS=["/models/wonderland-left.glb","/models/wonderland-right.glb"],wS=["left","right"],RS=/(index|middle|ring|pinky|thumb)[_-]finger[_-]phalanx[_-](proximal|intermediate|distal)/i,CS={relaxed:{index:.44,middle:.53,ring:.61,pinky:.69,thumb:.26},open:{index:.37,middle:.47,ring:.56,pinky:.63,thumb:.22}},IS=new URLSearchParams(location.search).get("handPose"),Wr=IS==="open"?"open":"relaxed",PS=CS[Wr],qd=Wr==="relaxed"?2.11:Math.PI-.36,Yd=Wr==="relaxed"?.3:.42,jd=Wr==="relaxed"?.22:.29,LS=new N(1,0,0),$d=new dt;function DS(i,{enabled:e=!0,reducedMotion:t=!1}={}){const n={mode:"vr",enabled:!!e,visible:!!e,loaded:!1,loadError:null,motionEnabled:!t,drawSurfaces:0,textureCount:0,joints:0,fingerJoints:0,triangles:0,swayX:0,swayY:0,leftX:0,rightX:0,pose:Wr};if(!e)return{state:n,meshes:[],ready:Promise.resolve(!1),update(){},resize(){},beginTravel(){},dispose(){}};const s=new At;s.name="Órion · mãos anatômicas (viewmodel independente)",i.add(s);const r=wS.map(M=>{const C=new At;return C.name="Órion · "+M,s.add(C),C}),a=[],o=[],c=[],l=[],u=[];let d=!1,h=0,p=0,g=0;function v(M){return new Promise((C,b)=>{new Jc().load(M,C,void 0,b)})}function m(M,C){const b=M.scene,S=r[C];b.traverse(I=>{if(I.isBone){o.push(I);const V=I.name.match(RS);V&&V[2]!=="metacarpal"&&c.push({bone:I,base:I.quaternion.clone(),side:C===0?-1:1,finger:V[1],segment:V[2]==="proximal"?1:V[2]==="intermediate"?2:3,phase:["index","middle","ring","pinky","thumb"].indexOf(V[1])*.64})}if(!I.isMesh)return;const D=I.geometry.clone(),w=D.getAttribute("position"),U=D.getAttribute("normal"),O=new Float32Array(w.count*4);for(let V=0;V<w.count;V++){const k=_e.clamp(.38+.37*U.getZ(V)+.23*U.getY(V),.24,.95),z=w.getY(V),B=1-_e.smoothstep(z,-.045,.018)*.75,j=1-_e.smoothstep(z,-.17,-.04);O[V*4]=k*(.74+.13*j),O[V*4+1]=k*(.65+.07*j),O[V*4+2]=k*(.95+.04*j),O[V*4+3]=B}D.setAttribute("color",new nt(O,4)),u.push(D);const F=new Ut({color:11708107,vertexColors:!0,transparent:!0,opacity:.97,depthTest:!1,depthWrite:!1,toneMapped:!1,side:Mt});l.push(F),I.geometry=D,I.material=F,I.layers.set(0),I.renderOrder=30,I.frustumCulled=!1,a.push(I),n.triangles+=(D.index?.count||D.attributes.position.count)/3}),S.add(b)}function f(M){const C=Math.tan(_e.degToRad(i.fov*.5))*Math.abs(M);return{h:C,w:C*i.aspect}}function _(){if(!n.loaded)return;const M=1.38,{h:C,w:b}=f(M),S=C*.45/.1774;for(let I=0;I<2;I++){const D=r[I],w=I===0?-1:1;D.scale.setScalar(S),D.rotation.set(qd,w*-Yd,w*jd),D.position.set(w*b*.54,-C*.94,-M)}n.leftX=r[0].position.x,n.rightX=r[1].position.x}const x=Promise.all(AS.map(v)).then(M=>{if(d)return!1;if(M.forEach(m),a.length!==2||o.length<50||c.length<24)throw new Error("GLB anatômico não contém malhas/juntas suficientes");return n.drawSurfaces=a.length,n.joints=o.length,n.fingerJoints=c.length,n.loaded=!0,_(),s.visible=n.visible,!0}).catch(M=>(n.loadError=String(M?.message||M),n.loaded=!1,!1));function y(M,C,b=0,S=0){if(!n.loaded||!n.visible)return;const I=n.motionEnabled?1-Math.exp(-Math.min(.06,Math.max(0,C))*7.5):1;p+=(_e.clamp(b,-1,1)-p)*I,g+=(_e.clamp(S,-1,1)-g)*I,n.swayX=n.motionEnabled?p:0,n.swayY=n.motionEnabled?g:0;const{h:D,w}=f(1.38),U=n.motionEnabled?Math.sin(M*.72)*D*.005:0;for(let O=0;O<2;O++){const F=r[O],V=O===0?-1:1;F.position.x=V*w*.54-n.swayX*w*.016,F.position.y=-D*.94-n.swayY*D*.018+U*(O===0?.9:1),F.rotation.set(qd+(n.motionEnabled?n.swayY*.009:0),V*-Yd,V*jd+(n.motionEnabled?n.swayX*.014:0))}if(M-h>=0)for(const O of c){const F=n.motionEnabled?.018*Math.sin(M*.7+O.phase+O.side*.3):0,V=(PS[O.finger]+F)*(O.segment===1?1:O.segment===2?.78:.48);$d.setFromAxisAngle(LS,V),O.bone.quaternion.copy(O.base).multiply($d)}h=M}function A(){n.visible=!1,s.visible=!1}function E(){d=!0,i.remove(s),u.forEach(M=>M.dispose()),l.forEach(M=>M.dispose()),s.clear()}return{state:n,meshes:a,bones:o,driven:c,groups:r,root:s,ready:x,update:y,resize:_,beginTravel:A,dispose:E}}const NS="/models/david-fischer-fps-hands.glb",OS=/^(?:f_)?(index|middle|ring|pinky)(?:\.|_)?0?([123])(?:\.|_)?([lr])/i,US=/^thumb(?:\.|_)?0?([123])(?:\.|_)?([lr])/i,FS=new N,Kd=new dt,BS=new N(1,0,0),kS=new N(0,0,1),Zd=new dt,Or=new URLSearchParams(window.location.search),zS=Or.get("fpsPose")==="open"?"open":"relaxed",Ra=Or.get("fpsLight")==="basic"?"basic":"lit",Vt=["original","calm","cinematic","natural","frame"].includes(Or.get("fpsStyle"))?Or.get("fpsStyle"):"frame",Ti={original:{wristY:-.84,fadeFrom:.615,fadeTo:.725,wristBend:0,wristRoll:0,opacity:.94,fadeInvert:!1},calm:{wristY:-.88,fadeFrom:.735,fadeTo:.865,wristBend:-.43,wristRoll:-.16,opacity:.96,fadeInvert:!0},cinematic:{wristY:-.84,fadeFrom:.73,fadeTo:.87,wristBend:-.55,wristRoll:-.35,opacity:.98,fadeInvert:!0},natural:{wristY:-.85,fadeFrom:.72,fadeTo:.88,wristBend:0,wristRoll:0,opacity:.96,fadeInvert:!0},frame:{wristY:-.89,fadeFrom:.7,fadeTo:.89,wristBend:0,wristRoll:0,opacity:1,fadeInvert:!0,scaleFactor:1.74}}[Vt],mc=Or.get("fpsTune")||"base",Jd={base:Vt==="frame"?{bend:.36,yaw:.46,roll:-.4}:Vt==="natural"?{bend:1,yaw:.36,roll:-.38}:{bend:Ti.wristBend,yaw:0,roll:Ti.wristRoll},forward:{bend:-1.12,yaw:.26,roll:-.25},reach:{bend:-1.47,yaw:.4,roll:-.18},inward:{bend:-1.04,yaw:.62,roll:-.48},back:{bend:.7,yaw:.3,roll:-.3},rest1:{bend:1,yaw:.36,roll:-.38},rest2:{bend:1.24,yaw:.38,roll:-.4},rest3:{bend:.86,yaw:.48,roll:-.48},frameA:{bend:.76,yaw:.47,roll:-.43},frameB:{bend:.6,yaw:.56,roll:-.5},frameC:{bend:.94,yaw:.39,roll:-.35},frameD:{bend:.36,yaw:.46,roll:-.4}},ml=Jd[mc]||Jd.base,VS=new N(1,0,0),HS=new N(0,1,0),GS=new N(0,0,1),Qd=new dt,eh=new dt,th=new dt;function WS(i){return String(i||"").toLowerCase().replace(/[^a-z0-9]/g,"")}function nh(i,e){const t=Math.tan(_e.degToRad(i.fov*.5))*e;return{h:t,w:t*i.aspect}}function XS(i,{enabled:e=!0,reducedMotion:t=!1}={}){const n={mode:"fps",enabled:!!e,visible:!!e,loaded:!1,motionEnabled:!t,loadError:null,pose:zS,joints:0,fingerJoints:0,triangles:0,textureCount:0,drawSurfaces:0,swayX:0,swayY:0,leftX:0,rightX:0,framing:null,artStyle:Vt,lightMode:Ra,tune:mc,referencePose:Vt==="frame"?"arcane-frame":null};if(!e)return{state:n,meshes:[],driven:[],ready:Promise.resolve(!1),update(){},resize(){},beginTravel(){},dispose(){}};const s=new At;s.name="Órion · mãos FPS de David Fischer, viewmodel local",i.add(s);const r=[];if(Ra==="lit"){const F=new sg(15524607,6772868,1.85),V=new hf(16774399,1.22);V.position.set(-.7,1.6,2.3),V.target.position.set(0,0,-2),i.add(F,V,V.target),r.push(F,V,V.target)}const a=[],o=[],c=[],l=[],u=[],d={wristL:null,wristR:null,tipL:null,tipR:null},h=[];let p=!1,g=new N,v=1,m=0;const f={left:0,right:0},_={left:0,right:0};let x=0,y=0;const A=2.05,E={open:.07,relaxed:.17},M={index:[.055,.045,.025],middle:[.22,.32,.24],ring:[.33,.43,.31],pinky:[.42,.48,.37],thumb:[.035,.045,.015]};function C(F=0){Qd.setFromAxisAngle(VS,ml.bend);for(const V of h)eh.setFromAxisAngle(HS,ml.yaw*V.side),th.setFromAxisAngle(GS,ml.roll*V.side),V.bone.quaternion.copy(V.aimed||V.base),V.aimed||V.bone.quaternion.multiply(Qd).multiply(eh).multiply(th);for(let V=0;V<l.length;V++){const k=l[V],z=n.motionEnabled?Math.sin(F*.7+V*.79)*.012:0,B=Vt==="frame"?M[k.digit][k.segment-1]+z*.35:(E[n.pose]+z)*(k.segment===1?.52:k.segment===2?.71:.36)*(k.digit==="thumb"?.45:1);Kd.setFromAxisAngle(BS,B),k.bone.quaternion.copy(k.base).multiply(Kd),Vt==="frame"&&k.digit==="thumb"&&k.segment===1&&(Zd.setFromAxisAngle(kS,.12*k.side),k.bone.quaternion.multiply(Zd))}}function b(){if(Vt!=="natural"||mc!=="base")return;i.updateMatrixWorld(!0),s.updateMatrixWorld(!0);const F=G=>G.getWorldPosition(new N).project(i),V=F(d.wristL),k=F(d.wristR),z=F(d.tipL),B=F(d.tipR);if(z.x-V.x>.09&&z.x-V.x<.23&&k.x-B.x>.09&&k.x-B.x<.23&&z.y-V.y>.25&&z.y-V.y<.42&&B.y-k.y>.25&&B.y-k.y<.42)return;const j=i.getWorldQuaternion(new dt),ne=new N(0,0,1).applyQuaternion(j),Q=new N(1,0,0).applyQuaternion(j),re=[0,-.34,.34,-.5,.5,-.65,.65,-.8,.8],ce=[0,-.14,.14,-.26,.26,-.38,.38,-.46,.46];for(const G of h){const Y=G.side===-1?d.tipL:d.tipR;if(!Y)continue;const ie=G.bone.parent.getWorldQuaternion(new dt).invert(),ye=ne.clone().applyQuaternion(ie).normalize(),se=Q.clone().applyQuaternion(ie).normalize(),Le=G.bone.quaternion.clone(),be=G.side===-1?.115:-.115,L=G.side===-1?.26:.245;let Ue={score:1/0,pitch:0,roll:0,quaternion:Le.clone()};for(const ae of re){const le=new dt().setFromAxisAngle(se,ae);for(const Ne of ce){const pe=new dt().setFromAxisAngle(ye,Ne);G.bone.quaternion.copy(Le).premultiply(le).premultiply(pe),s.updateMatrixWorld(!0);const Ae=G.bone.getWorldPosition(new N),He=Y.getWorldPosition(new N),ke=Ae.clone().project(i),P=He.clone().project(i),T=i.worldToLocal(He).z-i.worldToLocal(Ae).z,q=P.x-ke.x,J=P.y-ke.y,te=Math.abs(q-be)*1.4+Math.abs(J-L)*.8+Math.abs(T+.38)*.32+Math.abs(ae)*.022+Math.abs(Ne)*.027+(J<.13?.8:0)+(J>.39?.15:0)+(P.x*G.side<0?.35:0);te<Ue.score&&(Ue={score:te,pitch:ae,roll:Ne,quaternion:G.bone.quaternion.clone()})}}G.aimed=Ue.quaternion,G.bone.quaternion.copy(Ue.quaternion);const me=G.side===-1?"left":"right";f[me]=Ue.roll,_[me]=Ue.pitch,s.updateMatrixWorld(!0)}}function S(){if(!n.loaded||!d.wristL||!d.wristR)return;for(const Y of h)Y.aimed=null;C(0),s.position.set(0,0,0),s.scale.setScalar(1),s.rotation.set(0,0,0),s.updateMatrixWorld(!0);const F=Y=>s.worldToLocal(Y.getWorldPosition(new N)),V=F(d.wristL),k=F(d.wristR),z=d.tipL?F(d.tipL):V.clone().add(new N(0,.1,0)),B=d.tipR?F(d.tipR):k.clone().add(new N(0,.1,0));V.clone().add(k).multiplyScalar(.5);const j=[-.35,.18,.45,Math.PI-.35,Math.PI+.18,Math.PI+.45];let ne=null;const{h:Q,w:re}=nh(i,A);for(const Y of j){const ie=new vn(Y,0,0),ye=V.clone().applyEuler(ie),se=k.clone().applyEuler(ie),Le=z.clone().applyEuler(ie),be=B.clone().applyEuler(ie),L=Math.abs(se.x-ye.x);if(L<.005)continue;const Ue=_e.clamp(re*.54/(L*.5),.003,6.5),me=(Le.y-ye.y+(be.y-se.y))*.5*Ue/Q,ae=Math.abs(me-.32)+(me<=.05?3:0)+(me>.72?2:0)+Math.abs(Le.y-ye.y-(be.y-se.y))*Ue/Q*.25;(!ne||ae<ne.score)&&(ne={pitch:Y,score:ae,s:Ue,l:ye,r:se,tl:Le,tr:be,rise:me})}if(!ne)throw new Error("Não foi possível calibrar o rig FPS por punhos");m=ne.pitch,v=ne.s*(Ti.scaleFactor||1);const ce=ne.l.clone().add(ne.r).multiplyScalar(.5);s.rotation.set(m,0,0),s.scale.set(-v,v,v),g.set(ce.x*v,Q*Ti.wristY-ce.y*v,-A-ce.z*v),s.position.copy(g),s.updateMatrixWorld(!0),i.updateMatrixWorld(!0),b(),s.updateMatrixWorld(!0);const G=Y=>{if(!Y)return null;const ie=Y.getWorldPosition(FS.clone()).project(i);return{x:ie.x,y:ie.y,z:ie.z}};n.framing={pitch:m,scale:v,rawRise:ne.rise,aimAngles:{...f},depthAngles:{..._},posedLandmarks:!0,wristLeft:G(d.wristL),wristRight:G(d.wristR),tipLeft:G(d.tipL),tipRight:G(d.tipR)},n.leftX=n.framing.wristLeft?.x||0,n.rightX=n.framing.wristRight?.x||0}const I=new Promise(F=>{new Jc().load(NS,V=>{try{if(p){F(!1);return}const k=V.scene;if(k.updateMatrixWorld(!0),k.traverse(z=>{if(z.isBone&&u.push(z),!z.isSkinnedMesh)return;const B=z.geometry;if(B.getAttribute("position")?.count<1e3){z.visible=!1;return}const j=B.clone(),ne=j.getAttribute("normal"),Q=j.getAttribute("position"),re=new Float32Array(Q.count*4);for(let Y=0;Y<Q.count;Y++){const ie=Q.getY(Y),ye=ne?.getZ(Y)??0,se=ne?.getY(Y)??0,Le=Vt==="frame"?_e.clamp(.51+.13*ye+.1*se,.34,.8):_e.clamp(.66+.2*ye+.12*se,.45,.95),be=_e.smoothstep(ie,Ti.fadeFrom,Ti.fadeTo),L=Ti.fadeInvert?1-be:be;re[Y*4]=Le*(Vt==="frame"?.69:.94),re[Y*4+1]=Le*(Vt==="frame"?.72:.84),re[Y*4+2]=Le*(Vt==="frame"?.97:1.05),re[Y*4+3]=L}j.setAttribute("color",new nt(re,4)),c.push(j);const ce=Ra==="lit"?Hm:Ut,G=new ce({color:Vt==="frame"?8418710:Ra==="lit"?13681889:12235468,vertexColors:!0,transparent:!0,opacity:Ti.opacity,side:Mt,depthTest:!1,depthWrite:!1,toneMapped:!1});G.onBeforeCompile=Y=>{Y.vertexShader=`varying float vOrionFpsClipY;
`+(Vt==="frame"?`varying float vOrionFpsRim;
`:"")+Y.vertexShader,Y.vertexShader=Y.vertexShader.replace("#include <project_vertex>",`#include <project_vertex>
vOrionFpsClipY = gl_Position.y / gl_Position.w;`+(Vt==="frame"?`
vOrionFpsRim = 1.0 - abs(dot(normalize(transformedNormal), normalize(-mvPosition.xyz)));`:"")),Y.fragmentShader=`varying float vOrionFpsClipY;
`+(Vt==="frame"?`varying float vOrionFpsRim;
`:"")+Y.fragmentShader,Y.fragmentShader=Y.fragmentShader.replace("#include <opaque_fragment>",`#include <opaque_fragment>
gl_FragColor.a *= smoothstep(-1.08, -0.74, vOrionFpsClipY);`+(Vt==="frame"?`
float orionRim = pow(clamp(vOrionFpsRim, 0.0, 1.0), 1.25);
gl_FragColor.rgb = gl_FragColor.rgb * 0.13 + vec3(0.82,0.83,1.0) * orionRim * 1.23;`:""))},G.customProgramCacheKey=()=>Vt==="frame"?"orion-fps-arcane-frame-v3":"orion-fps-screen-feather-v1",o.push(G),z.geometry=j,z.material=G,z.frustumCulled=!1,z.renderOrder=35,z.layers.set(0),a.push(z),n.triangles+=(j.index?.count||Q.count)/3}),a.length===0)throw new Error("Modelo de David sem SkinnedMesh principal");for(const z of u){const B=WS(z.name);/^handl/.test(B)&&(d.wristL=z),/^handr/.test(B)&&(d.wristR=z),/^fmiddle03l/.test(B)&&(d.tipL=z),/^fmiddle03r/.test(B)&&(d.tipR=z);const j=String(z.name||""),ne=j.match(OS),Q=j.match(US);!ne&&!Q||l.push({bone:z,base:z.quaternion.clone(),digit:Q?"thumb":ne[1].toLowerCase(),segment:Number(Q?Q[1]:ne[2]),side:(Q?Q[2]:ne[3]).toLowerCase()==="l"?1:-1})}if(!d.wristL||!d.wristR)throw new Error("Mãos importadas sem ossos dos punhos");if(h.push({bone:d.wristL,side:-1,base:d.wristL.quaternion.clone()}),h.push({bone:d.wristR,side:1,base:d.wristR.quaternion.clone()}),l.length<25)throw new Error("Rig importado não fornece falanges suficientes: "+l.length);s.add(k),n.joints=u.length,n.fingerJoints=l.length,n.drawSurfaces=a.length,n.textureCount=0,n.loaded=!0,S(),s.visible=n.visible,F(!0)}catch(k){n.loaded=!1,n.loadError=String(k.message||k),F(!1)}},void 0,V=>{n.loadError=String(V?.message||V),F(!1)})});function D(F,V,k=0,z=0){if(!n.loaded||!n.visible)return;const B=n.motionEnabled?1-Math.exp(-Math.min(Math.max(V,0),.06)*7.5):1;x+=(_e.clamp(k,-1,1)-x)*B,y+=(_e.clamp(z,-1,1)-y)*B,n.swayX=n.motionEnabled?x:0,n.swayY=n.motionEnabled?y:0;const{h:j,w:ne}=nh(i,A),Q=n.motionEnabled?Math.sin(F*.67)*j*.005:0;s.position.set(g.x-n.swayX*ne*.018,g.y-n.swayY*j*.016+Q,g.z),s.rotation.set(m+(n.motionEnabled?n.swayY*.008:0),0,n.motionEnabled?n.swayX*.012:0),C(F)}function w(){S()}function U(){n.visible=!1,s.visible=!1}function O(){p=!0,i.remove(s),r.forEach(F=>i.remove(F)),c.forEach(F=>F.dispose()),o.forEach(F=>F.dispose()),s.clear()}return{state:n,root:s,meshes:a,driven:l,ready:I,update:D,resize:w,beginTravel:U,dispose:O}}const ih="/overlay/orion-hands-frame.webp";function qS(i,{enabled:e=!0,reducedMotion:t=!1}={}){const n={enabled:!!e,visible:!!e,loaded:!1,mode:"overlay",motionEnabled:!t,loadError:null,drawSurfaces:0,triangles:0,textureCount:0,joints:0,fingerJoints:0,swayX:0,swayY:0,elementCount:0};if(!e)return{state:n,meshes:[],ready:Promise.resolve(!1),update(){},resize(){},beginTravel(){},dispose(){}};const s=document.createElement("div");s.id="orionEtherealHands",s.className="orion-ethereal-hands",s.setAttribute("aria-hidden","true");const r=[];for(const v of["left","right"]){const m=document.createElement("div");m.className="orion-ethereal-hand orion-ethereal-hand--"+v,m.dataset.side=v;const f=document.createElement("img");f.src=ih,f.alt="",f.decoding="async",f.loading="eager",f.draggable=!1,m.appendChild(f),s.appendChild(m),r.push(m)}i.appendChild(s),n.elementCount=2;let a=!1,o=0,c=0;const l=new Image;l.decoding="async";const u=new Promise(v=>{l.onload=()=>{if(a)return v(!1);n.loaded=!0,n.textureCount=1,s.classList.add("is-ready"),v(!0)},l.onerror=()=>{if(a)return v(!1);n.loadError="Falha ao carregar mãos etéreas locais",s.remove(),v(!1)},l.src=ih,l.complete&&l.naturalWidth>0&&l.onload()});function d(v,m,f=0,_=0){if(a||!n.visible||!n.loaded)return;const x=Math.min(Math.max(m,0),.06),y=n.motionEnabled?1-Math.exp(-x*6.2):1;o+=(Math.max(-1,Math.min(1,f))-o)*y,c+=(Math.max(-1,Math.min(1,_))-c)*y,n.swayX=n.motionEnabled?o:0,n.swayY=n.motionEnabled?c:0;const A=n.motionEnabled?Math.sin(v*.92)*2:0;for(let E=0;E<r.length;E++){const M=E===0?1:-1,C=n.swayX*(E===0?-5.5:-5.2)+M*.6*Math.sin(v*.37),b=n.swayY*-3.8+(E===0?A:A*.85),S=n.motionEnabled?n.swayX*(E===0?-.23:.23):0,I=n.motionEnabled?C:0,D=n.motionEnabled?b:0;r[E].style.transform="translate3d("+I.toFixed(2)+"px,"+D.toFixed(2)+"px,0) rotate("+S.toFixed(3)+"deg)"}}function h(){n.visible&&(n.visible=!1,s.classList.add("is-leaving"))}function p(){}function g(){a=!0,n.visible=!1,l.onload=null,l.onerror=null,s.remove()}return{state:n,meshes:[],ready:u,update:d,resize:p,beginTravel:h,dispose:g,layer:s}}const YS=32,jS=24,gc=Object.freeze({left:Object.freeze({id:"left-framing",limit:.009,index:{x:.58,y:.73,px:.48,py:.48,rx:.25,ry:.31},thumb:{x:.72,y:.44,px:.55,py:.37,rx:.24,ry:.2},indexAmplitude:.027,thumbAmplitude:.018,phase:.38}),right:Object.freeze({id:"right-pointing",limit:.012,index:{x:.27,y:.79,px:.43,py:.63,rx:.25,ry:.24},thumb:{x:.28,y:.52,px:.45,py:.43,rx:.22,ry:.18},indexAmplitude:.046,thumbAmplitude:.026,phase:1.16})}),Ca=(i,e,t)=>Math.max(e,Math.min(t,i));function sh(i,e,t){const n=(i-t.x)/t.rx,s=(e-t.y)/t.ry;return Math.exp(-2.3*(n*n+s*s))}function rh(i,e,t,n){const s=i-t.px,r=e-t.py,a=Math.sin(n),o=Math.cos(n);return[s*o-r*a-s,s*a+r*o-r]}function $S(i,e,t,n,s,r=0,a=0,o=!1){if(!gc[n])throw new Error("Lado da mão não reconhecido");if(i.length!==e.length||i.length/3*2!==t.length)throw new Error("Geometria de mãos incompatível");if(o)return e.set(i),0;const c=gc[n],l=Ca(r,-1,1),u=Ca(a,-1,1),d=c.indexAmplitude*Math.sin(s*.83+c.phase)+l*.012,h=c.thumbAmplitude*Math.sin(s*.65+c.phase+1.4)-u*.008;let p=0;for(let g=0,v=i.length/3;g<v;g++){const m=g*3,f=g*2,_=t[f],x=t[f+1],y=sh(_,x,c.index),A=sh(_,x,c.thumb),[E,M]=rh(_,x,c.index,d),[C,b]=rh(_,x,c.thumb,h),S=Ca(E*y+C*A,-c.limit,c.limit),I=Ca(M*y+b*A,-c.limit,c.limit);e[m]=i[m]+S,e[m+1]=i[m+1]+I,e[m+2]=i[m+2],p=Math.max(p,Math.abs(S),Math.abs(I))}return p}const Ef=.14,KS=.6,Tf=.5,nn=[100,150,180,220,270,320,370,420,480,530],ZS=[[500,519],[465,534],[450,522],[425,504],[401,485],[390,475],[416,510],[439,550],[477,590],[501,620]],JS=[[335,354],[333,402],[344,416],[358,437],[379,463],[399,484],[416,510],[439,550],[477,590],[501,620]],Af=[0,.25,.5,.75,1].map(i=>ZS.map((e,t)=>e.map((n,s)=>n+(JS[t][s]-n)*i)));function QS(i){const e=i.slice(1).map((t,n)=>(t-i[n])/(nn[n+1]-nn[n]));return i.map((t,n)=>{if(n===0||n===i.length-1||e[n-1]*e[n]<=0)return 0;const s=nn[n]-nn[n-1],r=nn[n+1]-nn[n],a=2*r+s,o=r+2*s;return(a+o)/(a/e[n-1]+o/e[n])})}const vc=Af.map(i=>[0,1].map(e=>QS(i.map(t=>t[e]))));for(const i of vc)for(let e=0;e<2;e++)i[e][nn.indexOf(370)]=vc[4][e][nn.indexOf(370)];function ah(i,e){let t=0;for(;t<nn.length-2&&e>nn[t+1]/1122;)t++;const n=nn[t+1]-nn[t],s=Math.max(0,Math.min(1,(e*1122-nn[t])/n)),r=s*s,a=r*s,o=Af[i],c=vc[i],l=[0,1].map(u=>(2*a-3*r+1)*o[t][u]+(a-2*r+s)*n*c[u][t]+(-2*a+3*r)*o[t+1][u]+(a-r)*n*c[u][t+1]);return[1-l[1]/1402,1-l[0]/1402]}function eb(i,e,t,n){if(t>nn.at(-1)/1122||n<=.54||i===e)return n;const[s,r]=ah(i,t),[a,o]=ah(e,t),c=Math.max(.54,Math.min(s,a)-Math.max(.005,Math.abs(a-s)*.65));return n<=c?n:n<s?c+(a-c)*(n-c)/(s-c):n<r?a+(o-a)*(n-s)/(r-s):n+o-r}function wf(i){const e=Math.max(0,Math.min(1,i)),t=e*4,n=Math.min(3,Math.floor(t)),s=t-n,r=s*s*(3-2*s),a=[0,0,0,0,0];return a[n]=1-r,a[n+1]=r,a}const Ps={left:{wrist:[.23,.17],palm:[.47,.44],index:[.49,.62],indexDistal:[.63,.74],indexTip:[.75,.8],thumb:[.54,.36],thumbDistal:[.73,.37],thumbTip:[.9,.38],middle:[.52,.6],middleTip:[.76,.61],ring:[.5,.54],ringTip:[.7,.49],little:[.47,.49],littleTip:[.64,.44],phase:.4},pointing:{wrist:[.8,.2],palm:[.59,.44],index:[.45,.63],indexDistal:[.32,.74],indexTip:[.17,.8],thumb:[.49,.39],thumbDistal:[.35,.43],thumbTip:[.23,.45],middle:[.48,.59],middleTip:[.24,.5],ring:[.52,.55],ringTip:[.34,.47],little:[.57,.52],littleTip:[.43,.47],phase:1.2},neutral:{wrist:[.8,.2],palm:[.59,.44],index:[.45,.63],indexDistal:[.29,.71],indexTip:[.15,.65],thumb:[.49,.39],thumbDistal:[.35,.43],thumbTip:[.23,.45],middle:[.48,.59],middleTip:[.2,.5],ring:[.52,.55],ringTip:[.29,.46],little:[.57,.52],littleTip:[.38,.46],phase:1.2}};Ps.perspective={...Ps.neutral,indexDistal:[.28,.72],indexTip:[.1,.75]};const vr=[["wrist",null,.014,.7],["palm","wrist",.009,.81],["index","palm",.03,1.03],["indexDistal","index",.039,1.12],["thumb","palm",.024,.85],["thumbDistal","thumb",.03,.93],["middle","palm",.021,.96],["ring","palm",.018,.89],["little","palm",.015,.83]],gl=["wrist","palm","indexTip","thumbTip","middleTip","ringTip","littleTip"];for(const[i,e]of[["reach025",.25],["reach050",.5],["reach075",.75]])Ps[i]=Object.fromEntries(Object.entries(Ps.neutral).map(([t,n])=>[t,Array.isArray(n)?n.map((s,r)=>_e.lerp(s,Ps.pointing[t][r],e)):n]));const Ia=[[150,503,490,314,291],[180,522,461,359,279],[220,518,427,391,300],[270,489,402,420,330],[320,478,389,446,358],[370,495,380,486,381],[420,525,401,525,404],[480,550,455,550,458],[530,565,493,565,496]].map(([i,e,t,n,s])=>[i/1122,1-e/1402,1-t/1402,1-n/1402,1-s/1402]);function tb(i,e,t){if(i>Ia.at(-1)[0])return e;let n=Ia[0],s=n;for(let h=1;h<Ia.length&&(s=Ia[h],!(i<=s[0]));h++)n=s;const r=n===s?0:_e.clamp((i-n[0])/(s[0]-n[0]),0,1),a=n.map((h,p)=>_e.lerp(h,s[p],r)),o=a[t?3:1],c=a[t?4:2],l=a[t?1:3],u=a[t?2:4],d=.54;return e<=d?e:e<o?_e.lerp(d,l,(e-d)/(o-d)):e<c?_e.lerp(l,u,(e-o)/(c-o)):e+u-c}function oh(i,e,t,n,s){const r=n[0]-t[0],a=n[1]-t[1],o=r*r+a*a,c=_e.clamp(((i-t[0])*r+(e-t[1])*a)/o,0,1),l=((i-t[0]-c*r)**2+(e-t[1]-c*a)**2)/(s*s);return Math.exp(-2.5*l)}function lh(i,e,t,{perspective:n=!1}={}){const s=Ps[t];if(!s)throw new Error("Pose de rig de mãos desconhecida");const r=[],a={};for(const[m,f]of vr){const _=new lo,x=s[m];_.name="MMV_"+t+"_"+m;const y=f?s[f]:[.5,.5];_.position.set(x[0]-y[0],x[1]-y[1],0),f&&a[f].add(_),r.push(_),a[m]=_}const o=i.getAttribute("uv"),c=new Uint16Array(o.count*4),l=new Float32Array(o.count*4),u=Object.fromEntries(gl.map(m=>[m,{index:0,distance:1/0}]));for(let m=0;m<o.count;m++){const f=o.getX(m),_=o.getY(m),x=1-_e.smoothstep(_,.18,.46),y=[{index:0,weight:.04+x*4},{index:1,weight:.15+oh(f,_,s.wrist,s.palm,.24)}];for(let E=2;E<vr.length;E++){const[M]=vr[E],C=s[M+"Tip"]||s.indexTip,b=s[M],S=M.endsWith("Distal")?s[M.replace("Distal","")+"Tip"]:s[M+"Distal"]||C,I=M.startsWith("index")?.14:M.startsWith("thumb")?.08:.065;y.push({index:E,weight:oh(f,_,b,S,I)*(1-x)*3})}y.sort((E,M)=>M.weight-E.weight);const A=y.slice(0,4).reduce((E,M)=>E+M.weight,0);for(let E=0;E<4;E++)c[m*4+E]=y[E].index,l[m*4+E]=y[E].weight/A;for(const E of gl){const M=s[E],C=(f-M[0])**2+(_-M[1])**2;C<u[E].distance&&(u[E]={index:m,distance:C})}}if(t!=="left"){const m=i.getAttribute("position"),f=[];if(n)for(let x=0;x<4;x++){const y=new Float32Array(m.array);for(let A=0;A<o.count;A++){const E=o.getX(A),M=o.getY(A);y[A*3+1]+=eb(4,x,E,M)-M}f.push(new nt(y,3))}const _=new Float32Array(m.array);for(let x=0;x<o.count;x++)n?_[x*3+2]=-Ef*_e.smoothstep(o.getY(x),.2,.72)*_e.smoothstep(o.getX(x),0,.15):_[x*3+1]=tb(o.getX(x),o.getY(x),t==="pointing")-.5;f.push(new nt(_,3)),i.morphAttributes.position=f}i.setAttribute("skinIndex",new ao(c,4)),i.setAttribute("skinWeight",new nt(l,4));const d=new kc(i,e);d.add(r[0]),d.bind(new zr(r)),d.frustumCulled=!1;let h=!1;function p(m,f=!1,_=t==="pointing"?1:0,x=0,y=null){if(h)return;const A=n?_e.smoothstep(_,0,1):0;for(let E=0;E<vr.length;E++){const[,,M,C]=vr[E];if(f){r[E].rotation.z=0;continue}const b=Math.sin(m*C+s.phase+E*.43),S=A>0?_e.lerp(b,Math.sin(m*C*.57+s.phase+E*.61),.16*A):b,I=(E>=2?1-.18*A:1)*(y?1-(E>=2?.55:.25)*y.selectionPress:1);r[E].rotation.z=S*M*I}if(t==="left"&&!f){const E=_e.clamp(x,0,1);a.wrist.rotation.z+=.012*E,a.palm.rotation.z-=.006*E,a.index.rotation.z-=.17*E,a.indexDistal.rotation.z-=.13*E,a.middle.rotation.z-=.15*E,a.ring.rotation.z-=.12*E,a.little.rotation.z-=.09*E,a.thumb.rotation.z+=.09*E,a.thumbDistal.rotation.z+=.06*E}if(t!=="left"&&y&&!f){const E=y.selectionPress,M=y.selectionReach;a.wrist.rotation.z+=.008*M-.01*E,a.palm.rotation.z-=.012*E,a.thumb.rotation.z-=.025*E,a.thumbDistal.rotation.z-=.018*E,a.middle.rotation.z+=.02*E,a.ring.rotation.z+=.015*E,a.little.rotation.z+=.01*E}if(t!=="left"){const E=_e.clamp(_,0,1);if(n){const M=wf(E);for(let C=0;C<4;C++)d.morphTargetInfluences[C]=M[C];d.morphTargetInfluences[4]=f?0:E*Tf}else d.morphTargetInfluences[0]=f?0:t==="neutral"?E:1-E}}function g(){d.parent?.updateWorldMatrix(!0,!1),d.updateMatrixWorld(!0);const m=i.getAttribute("position"),f=new N,_=new N;let x=0;for(let A=0;A<m.count;A++)f.fromBufferAttribute(m,A),d.getVertexPosition(A,_),x=Math.max(x,_.distanceTo(f));const y={};for(const A of gl){const E=u[A].index;y[A]=d.getVertexPosition(E,new N).applyMatrix4(d.matrixWorld)}return{pose:t,maxVertexDelta:x,landmarks:y,boneCount:r.length,boneTextureBytes:d.skeleton.boneTexture?.image?.data?.byteLength||0}}function v(){h||(h=!0,d.skeleton.dispose())}return{pose:t,mesh:d,bones:r,update:p,measure:g,dispose:v}}const ch=Object.freeze({baseOpacity:.38,height:.565,edgeInset:-.03,bottom:-.02}),Si=Object.freeze({left:{...ch,edgeInset:-.042,rotation:-.2,file:"/overlay/left-hand-ethereal.webp",swayX:-.006,swayY:-.005,breath:.003,phase:.45,pointer:!1,columns:YS,rows:jS},right:{...ch,rotation:0,file:"/overlay/right-hand-pointing.webp",neutralFile:"/overlay/right-hand-neutral.webp",swayX:-.006,swayY:-.005,breath:.003,phase:1.15,pointer:!0,columns:36,rows:28}}),tn=(i,e,t)=>Math.max(e,Math.min(t,i));function nb(i,{enabled:e=!0,reducedMotion:t=!1,animation:n="mesh",touchLayout:s=!1}={}){const r=n==="perspective",a=n==="rig"||r,o={mode:"mesh",enabled:!!e,visible:!1,loaded:!1,loadError:null,motionEnabled:!t,drawSurfaces:0,triangles:0,textureCount:0,joints:0,fingerJoints:0,swayX:0,swayY:0,maxVertexDelta:0,pose:"feminine-star-hover",handProfiles:Object.keys(gc),rightHover:!1,rightBlend:0,hoverBlend:0,leftFollow:0,animation:r?"perspective":a?"rig":"mesh",rightFrameWeights:[],rightDepth:0,selecting:!1,selectionReach:0,selectionPress:0,selectionAnticipation:0,selectionFollowThrough:0,selectionLift:0,touchLayout:s,targetDirectionX:0,targetDirectionY:.18},c=new At;c.name="OrionFeminineHands2p5D",c.visible=!1,i.add(c);const l=[],u=[],d=[],h=[];a&&Object.defineProperty(o,"maxVertexDelta",{enumerable:!0,get:()=>Math.max(0,...d.map(Q=>Q.measure().maxVertexDelta))});let p=null,g=!1,v=0,m=0;if(!e)return{state:o,root:c,meshes:l,rigs:d,rightFrames:h,ready:Promise.resolve(!1),update(){},resize(){},setStarHovered(){},setStarDirection(){},setStarSelection(){},beginTravel(){},dispose(){i.remove(c)}};let f=!1,_=!1,x=!1,y=0,A=1,E=0,M=0;const C=[],b=new Qs,S=Q=>new Promise((re,ce)=>b.load(Q,re,void 0,ce));let I=!1;function D(){const re=2*Math.tan(_e.degToRad(i.fov*.5))*2.5;return{depth:2.5,height:re,width:re*i.aspect}}function w(Q,re=0,ce=0){const G=D(),Y=Q.config,ie=s&&i.aspect<1,ye=Math.min(G.height*Y.height,G.width*(ie?.27:.3)/Q.aspect),se=ye*Q.aspect;Q.mesh.scale.set(se,ye,1);const Le=(Q.side==="left"?-G.width/2+Y.edgeInset*G.width+se/2:G.width/2-Y.edgeInset*G.width-se/2)+re*G.width,be=ie?.19+(t?0:.19*v):s?.015:Y.bottom,L=-G.height/2+(be+ce)*G.height+ye/2;Q.mesh.position.set(Le,L,-2.5)}function U(){if(!f){for(const Q of u)w(Q);p&&l[1]&&(p.scale.copy(l[1].scale),p.position.copy(l[1].position))}}const O=r?[Si.left.file,"/overlay/right-hand-pointing-smooth.webp"]:[Si.left.file,Si.right.file,Si.right.neutralFile],F=Promise.all(O.map(S)).then(Q=>{if(f)return Q.forEach(re=>re.dispose()),!1;for(const re of Q)re.colorSpace=_t,re.magFilter=Lt,re.minFilter=Gt,C.push(re);for(let re=0;re<2;re++){const ce=re===0?"left":"right",G=Q[re],Y=r&&ce==="right"?{...Si[ce],columns:72,rows:72}:Si[ce],ie=new _n(1,1,Y.columns,Y.rows),ye=ie.getAttribute("position"),se=ie.getAttribute("uv");if(r&&ce==="right")for(let pe=0;pe<se.count;pe++){const Ae=se.getY(pe),He=10/72,ke=66/72,P=Ae<=He?Ae/He*.38:Ae<=ke?.38+(Ae-He)/(ke-He)*.47:.85+(Ae-ke)/(1-ke)*.15;se.setY(pe,P),ye.setY(pe,P-.5)}const Le=new Float32Array(ye.array),be=new Float32Array(se.array);{const pe=new Float32Array(se.count*4),Ae=He=>(He=tn(He,0,1),He*He*(3-2*He));for(let He=0;He<se.count;He++){const ke=be[He*2],P=be[He*2+1],T=Ae((ke-.68)/.26),q=1-Ae((P-.16)/.22),J=He*4;pe[J]=1,pe[J+1]=1,pe[J+2]=1,pe[J+3]=ce==="left"?Ae((P-.09)/.21):1-T*q}ie.setAttribute("color",new nt(pe,4))}const L=new Ut({map:G,transparent:!0,opacity:Y.baseOpacity,side:Mt,depthTest:!1,depthWrite:!1,toneMapped:!1,vertexColors:!0}),Ue=a?lh(ie,L,ce==="left"?"left":r?"perspective":"pointing",{perspective:r&&ce==="right"}):null;Ue&&d.push(Ue);const me=Ue?Ue.mesh:new pt(ie,L);me.name=ce==="left"?"OrionFeminineLeftFraming":"OrionFeminineRightPointing",me.renderOrder=300+re,me.frustumCulled=!1,l.push(me),c.add(me);const ae=G.image?.naturalWidth||G.image?.width||1122,le=G.image?.naturalHeight||G.image?.height||1402,Ne={side:ce,config:Y,mesh:me,rest:Le,uvLocal:be,aspect:r&&ce==="right"?1122/1402:ae/le};u.push(Ne),w(Ne)}if(r)h.push(l[1]);else{const re=a?l[1].geometry.clone():l[1].geometry,ce=new Ut({map:C[2],transparent:!0,opacity:Si.right.baseOpacity,side:Mt,depthTest:!1,depthWrite:!1,toneMapped:!1,vertexColors:!0}),G=a?lh(re,ce,"neutral",{perspective:r}):null;G&&d.push(G),p=G?G.mesh:new pt(re,ce),p.name="OrionFeminineRightNeutral",p.renderOrder=301,p.frustumCulled=!1,c.add(p),p.scale.copy(l[1].scale),p.position.copy(l[1].position)}return o.loaded=!0,o.visible=!0,o.textureCount=C.length,o.joints=d.reduce((re,ce)=>re+ce.bones.length,0),o.fingerJoints=d.reduce((re,ce)=>re+ce.bones.length-2,0),c.visible=!0,I=!0,V(0,0),!0}).catch(Q=>(o.loadError="Falha ao carregar os assets das mãos",o.loaded=!1,o.visible=!1,c.visible=!1,C.forEach(re=>re.dispose()),console.warn("[Observatório] Assets das mãos indisponíveis",Q),!1));function V(Q,re,ce=0,G=0){if(!I||f)return;const Y=tn(re,0,.06),ie=1-Math.exp(-Y*5.7);if(E+=(tn(ce,-1,1)-E)*ie,M+=(tn(G,-1,1)-M)*ie,o.swayX=t?0:E,o.swayY=t?0:M,_){y+=Y;const ae=tn(y/.38,0,1);A=1-ae*ae*ae*(ae*(ae*6-15)+10)}const ye=(g||o.selecting)&&(!_||x)?1:0;if(t)v=ye,m=0;else if(a){const le=v-ye,Ne=Math.exp(-6.5*Y),pe=(m+6.5*le)*Y;v=ye+(le+pe)*Ne,m=(m-6.5*pe)*Ne}else v+=(ye-v)*(1-Math.exp(-Y*9.5));v=tn(v,0,1),o.hoverBlend=v,o.leftFollow=t?0:v;const se=r?KS:1,Le=r?.1:.16,be=tn(v*se-(t?0:Le*o.selectionPress+.015*o.selectionAnticipation),0,se);o.rightBlend=be;const L=s?0:A;if(L<.001){c.visible=!1,o.visible=!1,o.drawSurfaces=0,o.triangles=0;return}c.visible=!0,o.visible=!0;let Ue=0;for(const ae of d)ae.update(Q,t,be,ae.pose==="left"?o.leftFollow:0,o.selecting&&ae.pose!=="left"?o:null);const me=a&&!t?_e.smoothstep(be,.25,.75):be;for(const ae of u){const le=ae.config,{mesh:Ne,rest:pe,uvLocal:Ae}=ae,He=Ne.geometry.getAttribute("position");a||(Ue=Math.max(Ue,$S(pe,He.array,Ae,ae.side,Q,o.swayX,o.swayY,t)),He.needsUpdate=!t);const ke=t?0:o.swayX*le.swayX,P=t?0:o.swayY*le.swayY+Math.sin(Q*.94+le.phase)*le.breath;if(w(ae,ke,P),Ne.rotation.set(0,0,le.rotation+(t?0:Math.sin(Q*.72+le.phase)*(le.pointer?.01:.006))),ae.side==="right"&&r&&!t&&(Ne.rotation.z+=(-o.targetDirectionX*.018+(o.targetDirectionY-.18)*.012)*v,Ne.rotation.y+=o.targetDirectionX*.012*v),_&&!t&&(Ne.position.y-=D().height*.018*(1-A)),ae.side==="left"&&o.leftFollow>0){const T=D();Ne.position.x+=T.width*.0025*o.leftFollow,Ne.position.y+=T.height*.0035*o.leftFollow,a||(Ne.rotation.z+=.008*o.leftFollow)}if(ae.side==="right"&&o.selecting&&!t){const T=D(),q=o.selectionReach,J=o.selectionAnticipation,te=o.selectionFollowThrough;Ne.position.x+=T.width*(-.0055*q+.001*J),Ne.position.y+=T.height*(.007*q+.005*o.selectionLift-.002*J+.001*te),Ne.position.z+=.052*q-.01*J,Ne.rotation.x+=.035*q-.018*o.selectionPress,Ne.rotation.y+=-.045*q+.012*te,Ne.rotation.z+=.02*q-.028*o.selectionPress+.01*J+.007*te}Ne.material.opacity=le.baseOpacity*L*(ae.side==="right"&&!r?me:1)}if(p&&l[1]&&(p.position.copy(l[1].position),p.scale.copy(l[1].scale),p.rotation.copy(l[1].rotation),p.material.opacity=Si.right.baseOpacity*L*(1-me)),l[1].visible=r||me>.003,p&&(p.visible=me<.997),r){const ae=wf(be);o.rightFrameWeights=ae,o.rightDepth=t?0:be*Ef*Tf}o.drawSurfaces=r?2:1+Number(l[1].visible)+Number(p.visible),o.triangles=l[0].geometry.index.count/3+(o.drawSurfaces-1)*l[1].geometry.index.count/3,a||(o.maxVertexDelta=Ue)}function k(Q){g=!!Q&&!_,o.rightHover=g}function z(Q,re){o.targetDirectionX=tn(Q,-1,1),o.targetDirectionY=tn(re,-1,1)}function B(Q){o.selecting=!!Q&&(!_||x)&&!f,o.selectionReach=o.selecting&&!t?tn(Q.reach,0,1):0,o.selectionPress=o.selecting&&!t?tn(Q.press,0,1):0,o.selectionAnticipation=o.selecting&&!t?tn(Q.anticipation??0,0,1):0,o.selectionLift=o.selecting&&!t?tn(Q.lift??0,0,1):0,o.selectionFollowThrough=o.selecting&&!t?tn(Q.followThrough??0,0,1):0}function j(){_||(x=o.selecting&&!t,_=!0,x||B(null),k(!1))}function ne(){if(!f){f=!0,c.visible=!1;for(const Q of l)Q.geometry.dispose(),Q.material.dispose(),c.remove(Q);p&&(a&&p.geometry.dispose(),p.material.dispose(),c.remove(p));for(const Q of d)Q.dispose();for(const Q of C)Q.dispose();i.remove(c),l.length=0,u.length=0,d.length=0,h.length=0,o.visible=!1,o.loaded=!1}}return{state:o,root:c,meshes:l,rigs:d,rightFrames:h,ready:F,update:V,resize:U,setStarHovered:k,setStarDirection:z,setStarSelection:B,beginTravel:j,dispose:ne}}const _c="orion-herald-creation-v1",Rf=Object.freeze(["menino","menina","nao-definir"]);function ib(){return{phase:"sealed",name:"",gender:null,continued:!1}}function bs(i,e){return e.type==="reveal"&&i.phase==="sealed"?{...i,phase:"revealed"}:e.type==="mark"&&i.phase==="revealed"?{...i,phase:"breaking"}:e.type==="released"&&i.phase==="breaking"?{...i,phase:"identity"}:i.phase!=="identity"?i:e.type==="name"?{...i,name:String(e.value).slice(0,60),continued:!1}:e.type==="gender"&&(Rf.includes(e.value)||e.value===null)?{...i,gender:e.value,continued:!1}:e.type==="continue"&&xc(i)&&!i.continued?{...i,name:i.name.trim(),continued:!0}:i}function xc(i){return i.phase==="identity"&&Rf.includes(i.gender)&&i.name.trim().length>0&&i.name.trim().length<=60}const sb={fetal:{root:[.48,.46],spine:[.38,.49],neck:[.47,.69],head:[.48,.78],armL:[.48,.59],elbowL:[.6,.52],handL:[.61,.61],armR:[.48,.57],elbowR:[.58,.51],handR:[.58,.6],hipL:[.43,.37],kneeL:[.66,.44],footL:[.6,.28],hipR:[.42,.36],kneeR:[.6,.41],footR:[.54,.27]},menina:{root:[.5,.49],spine:[.5,.63],neck:[.52,.78],head:[.53,.88],armL:[.33,.73],elbowL:[.23,.62],handL:[.12,.56],armR:[.65,.73],elbowR:[.76,.63],handR:[.84,.68],hipL:[.4,.45],kneeL:[.38,.29],footL:[.36,.1],hipR:[.61,.45],kneeR:[.66,.3],footR:[.65,.1]},menino:{root:[.5,.49],spine:[.5,.63],neck:[.49,.78],head:[.48,.88],armL:[.31,.73],elbowL:[.22,.63],handL:[.12,.65],armR:[.68,.73],elbowR:[.79,.61],handR:[.88,.52],hipL:[.4,.45],kneeL:[.37,.28],footL:[.35,.1],hipR:[.6,.45],kneeR:[.64,.3],footR:[.66,.1]}},vl={root:null,spine:"root",neck:"spine",head:"neck",armL:"spine",elbowL:"armL",handL:"elbowL",armR:"spine",elbowR:"armR",handR:"elbowR",hipL:"root",kneeL:"hipL",footL:"kneeL",hipR:"root",kneeR:"hipR",footR:"kneeR"};function rb(i,e,t,n){const s=n[0]-t[0],r=n[1]-t[1],a=_e.clamp(((i-t[0])*s+(e-t[1])*r)/(s*s+r*r||1),0,1);return Math.hypot(i-t[0]-a*s,e-t[1]-a*r)}function ab(i,e){const t=sb[e];if(!t)throw new Error("Unknown silhouette rig");const n=Object.keys(vl),s=[],r={},a=new _n(1,1,48,64);for(const p of n){const g=new lo,v=vl[p],m=t[p],f=v?t[v]:[.5,.5];g.name="Soul_"+e+"_"+p,g.position.set(m[0]-f[0],m[1]-f[1],0),v&&r[v].add(g),r[p]=g,s.push(g)}const o=a.getAttribute("uv"),c=[],l=[];for(let p=0;p<o.count;p++){const g=o.getX(p),v=o.getY(p),m=n.map((_,x)=>{const y=vl[_],A=t[_],E=y?t[y]:A,M=rb(g,v,A,E);return{index:x,weight:Math.exp(-Math.pow(M/.075,2)*2)+1e-15}}).sort((_,x)=>x.weight-_.weight).slice(0,4),f=m.reduce((_,x)=>_+x.weight,0);for(const _ of m)c.push(_.index),l.push(_.weight/f)}a.setAttribute("skinIndex",new ao(c,4)),a.setAttribute("skinWeight",new nt(l,4));const u=new kc(a,i);u.add(s[0]),u.bind(new zr(s)),u.frustumCulled=!1;const d=e==="menina"?.6:e==="menino"?2.7:1.3;function h(p,g=!1,v=0){for(const _ of s)_.rotation.set(0,0,0);if(g)return;const m=Math.sin(p*.7+d),f=Math.sin(p*.42+d);r.spine.rotation.z=m*.007,r.neck.rotation.z=f*.012,r.head.rotation.z=-f*.006-v*.018,r.armL.rotation.z=Math.sin(p*.53+d)*.012,r.armR.rotation.z=Math.sin(p*.49+d+1)*.012,r.elbowL.rotation.z=m*.008,r.elbowR.rotation.z=-m*.009,r.hipL.rotation.z=f*.006,r.hipR.rotation.z=-f*.005,r.kneeL.rotation.z=m*.008,r.kneeR.rotation.z=-m*.007}return{mesh:u,bones:s,geometry:a,update:h,dispose(){u.skeleton.dispose(),a.dispose()}}}const ob=`
#include <common>
#include <skinning_pars_vertex>
varying vec2 vUv;varying float vEdge,vSeed,vLife;
void main(){vUv=uv;vEdge=1.;vSeed=0.;vLife=1.;
#include <skinbase_vertex>
#include <begin_vertex>
#include <skinning_vertex>
gl_Position=projectionMatrix*modelViewMatrix*vec4(transformed,1.);
}`,Cf="Acorrentado pela realidade",uh="/fonts/SigilosDeConhecimento.ttf",Pa="OrionKnowledge",Ka=[{tilt:.52,slope:.95,radius:.46,speed:.115},{tilt:-.46,slope:1.12,radius:.44,speed:-.087},{tilt:.12,slope:.42,radius:.47,speed:.065},{tilt:1.05,slope:.92,radius:.45,speed:-.055},{tilt:-1.08,slope:.86,radius:.43,speed:.095}];function lb(){const i=Cf+"   ";return Ka.flatMap((e,t)=>Array.from(i.repeat(2)).map((n,s)=>({char:n,ring:t,slot:s,slots:i.length*2}))).filter(e=>e.char!==" ")}function cb(i){const e=new ug,t=new _n(1,1);e.index=t.index.clone(),e.attributes.position=t.attributes.position.clone(),e.attributes.uv=t.attributes.uv.clone(),t.dispose();const n=[...new Set(i.map(c=>c.char))],s=[],r=[],a=[],o=[];i.forEach((c,l)=>{s.push(c.slot/c.slots*Math.PI*2),r.push(c.ring),a.push(n.indexOf(c.char)),o.push(l*.6180339%1)});for(const[c,l]of[["aAngle",s],["aRing",r],["aCell",a],["aSeed",o]])e.setAttribute(c,new Ya(new Float32Array(l),1));return e.instanceCount=i.length,{geometry:e,chars:n}}function ub({reducedMotion:i=!1}={}){const e=new At;e.name="AcorrentadoPelaRealidade";const t=lb(),{geometry:n,chars:s}=cb(t),r={uMap:{value:null},uTime:{value:0},uRelease:{value:0},uCharge:{value:0},uOpacity:{value:0}},o=`attribute float aAngle,aRing,aCell,aSeed;uniform float uTime,uRelease;varying vec2 vUv;varying float vDepth,vSeed,vCell;
 vec4 orbitConfig(float ring){${Ka.map((f,_)=>`${_?"else ":""}if(ring<${(_+.5).toFixed(1)})return vec4(${f.tilt},${f.slope},${f.radius},${f.speed});`).join("")}return vec4(0.,1.,.46,.1);}
 vec3 orbit(float angle,float ring){vec4 o=orbitConfig(ring);vec3 p=vec3(cos(angle)*o.z,sin(angle)*o.z*cos(o.y),sin(angle)*o.z*sin(o.y));return vec3(p.x*cos(o.x)-p.y*sin(o.x),p.x*sin(o.x)+p.y*cos(o.x),p.z);}
 void main(){float speed=orbitConfig(aRing).w;float angle=aAngle+uTime*speed+aRing*.7;
 vec3 center=orbit(angle,aRing);vec3 tangent=orbit(angle+.002,aRing)-center;float rotation=atan(tangent.y,tangent.x);
 float release=smoothstep(.02+aSeed*.12,.9,uRelease);float spread=release*release*(.35+aSeed*.5);
 center+=normalize(center)*spread;center.y-=release*release*.12;
 rotation+=release*(aSeed-.5)*2.;mat2 turn=mat2(cos(rotation),sin(rotation),-sin(rotation),cos(rotation));
 float compression=max(.28,length(tangent.xy)/max(.00001,length(tangent)));
 vec2 local=turn*(position.xy*vec2(.039*compression,.039));vec3 p=center+vec3(local,0.);
 vDepth=center.z;vUv=uv;vSeed=aSeed;vCell=aCell;
 gl_Position=projectionMatrix*modelViewMatrix*vec4(p,1.);}`,c=`uniform sampler2D uMap;uniform float uFront,uOpacity,uRelease,uCharge,uTime;varying vec2 vUv;varying float vDepth,vSeed,vCell;
 void main(){vec2 cell=vec2(mod(vCell,8.),floor(vCell/8.));vec2 at=vec2((cell.x+vUv.x)/8.,1.-(cell.y+1.-vUv.y)/4.);float glyph=texture2D(uMap,at).a;
 float side=smoothstep(-.013,.013,vDepth);float mask=mix(1.-side,side,uFront);float fade=1.-smoothstep(.35+vSeed*.2,1.,uRelease);
 float alpha=glyph*mask*uOpacity*fade;if(alpha<.006)discard;
 float breathe=.94+.06*sin(uTime*.8+vSeed*6.);vec3 gold=mix(vec3(.72,.39,.07),vec3(1.60,1.08,.30),uFront*.65+.15)*breathe*(1.+uCharge*.9);
 gl_FragColor=vec4(gold,alpha);
 #include <colorspace_fragment>
 }`,l=[],u=[!1,!0].map(f=>{const _=new Rt({transparent:!0,depthTest:!1,depthWrite:!1,toneMapped:!1,side:Mt,forceSinglePass:!0,uniforms:{...r,uFront:{value:f?1:0}},vertexShader:o,fragmentShader:c});l.push(_);const x=new pt(n,_);return x.frustumCulled=!1,x.renderOrder=f?14:8,x.layers.enable(1),e.add(x),x});let d,h,p=!1;const g={phrase:Cf,fontFamily:Pa,fontURL:uh,loaded:!1,glyphs:t.length,rings:Ka.length,time:0,release:0,reducedMotion:i},v=(async()=>{if(h=new FontFace(Pa,`url("${uh}")`),await h.load(),p)return!1;document.fonts.add(h);const f=document.createElement("canvas");f.width=2048,f.height=1024;const _=f.getContext("2d");_.fillStyle="#fff",_.textAlign="center",_.textBaseline="alphabetic",_.font=`192px "${Pa}"`;const x=s.map(A=>_.measureText(A)),y=192*Math.min(208/Math.max(...x.map(A=>A.width)),208/Math.max(...x.map(A=>A.actualBoundingBoxAscent+A.actualBoundingBoxDescent)));return _.font=`${y}px "${Pa}"`,s.forEach((A,E)=>{const M=_.measureText(A),C=E%8*256+128,b=Math.floor(E/8)*256+128+(M.actualBoundingBoxAscent-M.actualBoundingBoxDescent)/2;_.fillText(A,C,b)}),d=new co(f),d.colorSpace=oi,d.minFilter=Gt,d.magFilter=Lt,r.uMap.value=d,g.loaded=!0,!0})();function m(f,_,x,y=0){const A=i?0:y;r.uTime.value=A,r.uRelease.value=i?0:f,r.uCharge.value=_,r.uOpacity.value=x*(i?1-f:1),e.visible=g.loaded&&x>.001&&f<1,g.time=A,g.release=f}return{root:e,front:u[1],back:u[0],count:t.length,state:g,ready:v,update:m,dispose(){p=!0,e.remove(...u),n.dispose(),l.forEach(f=>f.dispose()),d?.dispose(),h&&document.fonts.delete(h)}}}const db=2.8,hb=i=>Math.max(0,Math.min(1,i)),bi=(i,e,t)=>{const n=hb((t-i)/(e-i));return n*n*(3-2*n)};function fb(i,e=!1){const t=Math.max(0,i);if(e){const n=bi(0,.18,t);return{charge:0,fracture:n,baby:1-n,children:n,separation:1,particles:0,complete:t>=.18}}return{charge:bi(0,.25,t)*(1-bi(.5,.9,t)),fracture:bi(.22,1.95,t),baby:1-bi(.85,1.9,t),children:bi(1.15,2.65,t),separation:bi(1.15,2.8,t),particles:bi(.6,.9,t),complete:t>=db}}const pb=[{file:"/assets/creation/gray-far-v9.png",kind:"gray-far",z:-280,opacity:.3},{file:"/assets/creation/gray-near-v9.png",kind:"gray-near",z:-180,opacity:.21},{file:"/assets/creation/red-left-v14.png",kind:"red-left",z:-110,opacity:.64},{file:"/assets/creation/red-right-v14.png",kind:"red-right",z:-65,opacity:.59}],dh=.3,mb=.75;function gb(i){return dh+(1-dh)*i}function vb(i){return .5-.5*Math.cos(i*2*Math.PI/4.8)}function _b(i,e,{reducedMotion:t=!1,parallaxEnabled:n=!0}={}){const s=e.material,r=s.map;s.dispose(),e.material=new Rt({depthTest:!1,depthWrite:!1,uniforms:{},vertexShader:"void main(){gl_Position=vec4(position.xy*2.,.999,1.);}",fragmentShader:"void main(){gl_FragColor=vec4(0.,0.,0.,1.);}"}),e.material.map=r;const a={active:4,loaded:0,components:5,transition:0,parallaxEnabled:n&&!t,parallaxStrength:1,foregroundEnabled:!0,pulse:[0,0],reducedMotion:t},o=new Qs,c=[],l="varying vec2 vUv;void main(){vUv=uv;gl_Position=vec4(position.xy*2.,.998,1.);}",u=`uniform sampler2D map;uniform vec2 pan;uniform float aspect,plateAspect,time,transition,opacity,red,anchorSide,beat,motion,saturation,brightness,driftPhase;varying vec2 vUv;
 void main(){vec2 cover=vec2(min(1.,aspect/plateAspect),min(1.,plateAspect/aspect));vec2 at=.5+(vUv-.5)*cover*.96;
 float portrait=1.-smoothstep(.75,1.2,aspect);at.x+=red*.23*portrait*(anchorSide<.5?-1.:1.);
 vec2 anchor=vec2(anchorSide<.5?.20:.80,anchorSide<.5?.25:.78);float live=beat*red*(1.-transition)*motion;
 at=anchor+(at-anchor)/(1.+live*.02);at+=pan;
 at+=vec2(sin(time*.09+driftPhase),cos(time*.07+driftPhase))*.0018*motion*transition*(1.-red);
 vec4 cloud=texture2D(map,clamp(at,vec2(.001),vec2(.999)));float grey=dot(cloud.rgb,vec3(.2126,.7152,.0722));
 vec3 color=mix(vec3(grey),cloud.rgb,mix(1.,saturation,red));
 color=mix(color,grey*vec3(.82,.80,.95),transition);
 float layerOpacity=mix(opacity,red>.5?0.:opacity*1.65,transition);
 float alpha=cloud.a*layerOpacity;gl_FragColor=vec4(color,alpha);
 #include <colorspace_fragment>
 gl_FragColor.rgb*=mix(1.,brightness,red);
 }`,d=Promise.all(pb.map(async(p,g)=>{const v=await o.loadAsync(p.file);v.colorSpace=_t,v.minFilter=Gt,v.magFilter=Lt;const m=new Rt({transparent:!0,depthTest:!1,depthWrite:!1,toneMapped:!1,uniforms:{map:{value:v},pan:{value:new Ie},aspect:{value:innerWidth/innerHeight},plateAspect:{value:v.image.width/v.image.height},time:{value:0},transition:{value:0},opacity:{value:p.opacity},red:{value:g>1?1:0},anchorSide:{value:g===3?1:0},motion:{value:t?0:1},beat:{value:1},saturation:{value:1},brightness:{value:mb},driftPhase:{value:g*1.9}},vertexShader:l,fragmentShader:u}),f=new pt(new _n(1,1),m);return f.position.z=p.z,f.frustumCulled=!1,f.renderOrder=3+g*.1,f.userData={kind:p.kind,volumeFragment:!0,baseX:0,baseY:0,parallaxOffsetX:0,parallaxOffsetY:0},c[g]=f,i.add(f),a.loaded++,!0}));function h(p,g,v,m){const f=1-Math.exp(-Math.min(.1,Math.max(0,m))*2.4),_=t||a.transition===1?1:vb(p);a.pulse=[_,_],a.active=a.transition===1?2:4,c.forEach((x,y)=>{if(!x)return;const A=x.userData,E=x.material.uniforms;A.parallaxOffsetX+=((a.parallaxEnabled?-g*(.7+y*.25)*a.parallaxStrength:0)-A.parallaxOffsetX)*f,A.parallaxOffsetY+=((a.parallaxEnabled?-v*(.4+y*.18)*a.parallaxStrength:0)-A.parallaxOffsetY)*f,x.visible=y<2||a.transition<1,E.pan.value.set(A.parallaxOffsetX*.004,A.parallaxOffsetY*.004),E.aspect.value=innerWidth/innerHeight,E.time.value=t?0:p,E.transition.value=a.transition,E.beat.value=y<2?1:_e.lerp(_,1,a.transition),E.saturation.value=y<2?1:gb(E.beat.value)})}return{ready:d,layers:c,state:a,resize(){},update:h,applyQuality(){a.active=a.transition===1?2:4},setTransition(p){a.transition=p},setParallaxStrength(p){a.parallaxStrength=_e.clamp(p,.45,1.6)}}}const Za={nebula:"/assets/creation/gray-far-v9.png",nebulaPortrait:"/assets/creation/gray-far-v9.png",baby:"/assets/creation/unborn-v5.png",children:"/assets/creation/souls-v9.png"};function If(i=innerWidth/innerHeight){return i<.85?Za.nebulaPortrait:Za.nebula}const La=(i,e,t)=>_e.smoothstep(t,i,e),xb=`
 uniform sampler2D uMap;uniform vec4 uUV;uniform float uOpacity,uReveal,uTime,uCharge,uSelected,uFlip,uHover;
 varying vec2 vUv;varying float vEdge,vSeed,vLife;
 float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(fract(sin(dot(i,vec2(127.1,311.7)))*43758.5453),fract(sin(dot(i+vec2(1.,0.),vec2(127.1,311.7)))*43758.5453),f.x),mix(fract(sin(dot(i+vec2(0.,1.),vec2(127.1,311.7)))*43758.5453),fract(sin(dot(i+1.,vec2(127.1,311.7)))*43758.5453),f.x),f.y);}
 void main(){
  vec2 at=uUV.xy+vec2(mix(vUv.x,1.-vUv.x,uFlip),vUv.y)*uUV.zw;
  vec4 texel=texture2D(uMap,at);
  float n=noise(vUv*10.)*.65+noise(vUv*23.)*.35;
  float mask=smoothstep(n-.13,n+.13,uReveal*1.35-.12);
  // Solid alpha core: only the antialiased contour may blend.
  float coverage=smoothstep(.12,.65,texel.a);
  vec2 stepUV=uUV.zw*.006;
  float nearAlpha=max(max(texture2D(uMap,at+vec2(stepUV.x,0.)).a,texture2D(uMap,at-vec2(stepUV.x,0.)).a),max(texture2D(uMap,at+vec2(0.,stepUV.y)).a,texture2D(uMap,at-vec2(0.,stepUV.y)).a));
  float rim=max(0.,smoothstep(.12,.65,nearAlpha)-coverage);
  float emphasis=.38+uHover*.45+uSelected*.35;
  float alpha=max(coverage,rim*emphasis)*uOpacity*mask*vLife;
  alpha*=smoothstep(0.,.025,vUv.x)*(1.-smoothstep(.975,1.,vUv.x))*smoothstep(0.,.025,vUv.y)*(1.-smoothstep(.975,1.,vUv.y));
  if(alpha<.006)discard;
  vec3 color=mix(vec3(0.),vec3(.8,.53,.20),rim*emphasis)+vec3(.9,.87,.96)*uCharge*.9;
  color*=1.+uCharge*.24;
  gl_FragColor=vec4(color,alpha);
  #include <colorspace_fragment>
 }`;function yb(i,{opacity:e=1,uv:t=[0,0,1,1],motion:n=1,flip:s=!1}={}){return new Rt({transparent:!0,depthTest:!1,depthWrite:!1,side:Mt,forceSinglePass:!0,toneMapped:!1,uniforms:{uMap:{value:i},uUV:{value:new st(...t)},uOpacity:{value:e},uMotion:{value:n},uTime:{value:0},uCharge:{value:0},uReveal:{value:1},uSelected:{value:0},uHover:{value:0},uFlip:{value:s?1:0}},vertexShader:ob,fragmentShader:xb})}function Sb({scene:i,camera:e,panel:t,reducedMotion:n=!1,environment:s}){const r=new Qs,a={},o={},c={},l=new At;l.name="CreationCinematicLayers",i.add(l);const u={rigMode:"image-skinned-2.5D",joints:48,fieldLayers:0,bindingType:"knowledge-sigils",bindingLayers:Ka.length,ready:!1,phase:"sealed",releaseProgress:0,selected:null,surfaces:0,fragments:0,particleCount:64,gestureFromMark:!1};let d=null,h=null,p=null,g={x:0,y:0},v=0,m=null;const f={},_=new N,x=new N,y=new dt;function A(B,j,ne){return x.set(B/innerWidth*2-1,1-j/innerHeight*2,.5).unproject(e).sub(_).normalize(),_.clone().addScaledVector(x,(ne-_.z)/x.z)}function E(B,j,ne,Q,re=0,ce=0){const G=B.material.uniforms.uMap.value.image;if(!G||!j.width||!j.height)return;const Y=G.width*Q[2]/(G.height*Q[3]),ie=Math.min(j.height,j.width/Y),ye=ie*Y,se=A(j.x+j.width/2,j.y+j.height/2+ce,ne),Le=A(j.x+j.width/2-ye/2,j.y+j.height/2,ne),be=A(j.x+j.width/2+ye/2,j.y+j.height/2,ne);n||(se.x+=g.x*(B.userData.parallax??.12),se.y+=g.y*.07),B.position.copy(se),B.scale.set(Le.distanceTo(be),Le.distanceTo(be)/Y,Le.distanceTo(be)),B.quaternion.copy(y),B.material.uniforms.uTime.value=n?0:re}const M={baby:[.1494140625,.17578125,.69140625,.6966145833],menina:[.145833333,.072265625,.266927083,.8515625],menino:[.588541667,.072265625,.279947917,.8515625]},C=ub({reducedMotion:n});l.add(C.root),u.links=0,u.glyphs=C.count;const b=Promise.all([C.ready,...["baby","children"].map(async B=>{const j=await r.loadAsync(Za[B]);j.colorSpace=_t,j.minFilter=Gt,j.magFilter=Lt,a[B]=j})]).then(()=>{for(const B of["baby","menina","menino"]){const j=yb(a[B==="baby"?"baby":"children"],{uv:M[B],motion:n?0:1,flip:!1}),ne=ab(j,B==="baby"?"fetal":B);c[B]=ne;const Q=ne.mesh;Q.userData.parallax=.1,Q.frustumCulled=!1,Q.layers.enable(1),Q.renderOrder=11,Q.visible=B==="baby",l.add(Q),o[B]=Q}return s?.ready}).then(()=>(d=performance.now(),u.ready=!0,u.surfaces=5,!0)),S=64,I=new Float32Array(S*3),D=new Float32Array(S*3),w=new Float32Array(S);for(let B=0;B<S;B++){const j=B*2.3999632,ne=.28+B%7/35;I[B*3]=Math.cos(j)*ne,I[B*3+1]=Math.sin(j)*ne,D[B*3]=Math.cos(j)*(1.1+B%5*.2),D[B*3+1]=Math.sin(j)*.9,D[B*3+2]=(B%3-1)*.3,w[B]=B*.6180339%1}const U=new It;U.setAttribute("position",new ct(I,3)),U.setAttribute("aVelocity",new ct(D,3)),U.setAttribute("aSeed",new ct(w,1));const O=new Rt({transparent:!0,depthTest:!1,depthWrite:!1,blending:gn,toneMapped:!1,uniforms:{uTime:{value:0},uElapsed:{value:0},uActive:{value:0},uExtent:{value:new Ie(1,1)},uDpr:{value:Math.min(devicePixelRatio,1.5)}},vertexShader:"attribute vec3 aVelocity;attribute float aSeed;uniform float uTime,uElapsed,uActive,uDpr;uniform vec2 uExtent;varying float alpha;void main(){float t=max(0.,uElapsed-.6);float flight=min(t,4.);float drag=1.-exp(-flight*.9);vec3 p=position+aVelocity*drag;p.y-=.025*flight*flight;p.xy+=vec2(sin(uTime*.2+aSeed*10.),cos(uTime*.17+aSeed*8.))*.012*step(4.,t);vec4 mv=modelViewMatrix*vec4(p.xy*uExtent,p.z,1.);gl_Position=projectionMatrix*mv;gl_PointSize=(1.5+aSeed*2.8)*uDpr;alpha=uActive*smoothstep(0.,.2,t)*(.38+.22*sin(uTime*.7+aSeed*10.))*mix(1.,step(.75,aSeed)*.22,smoothstep(4.,8.,t));}",fragmentShader:"varying float alpha;void main(){float r=length(gl_PointCoord-.5);float a=(1.-smoothstep(.02,.5,r))*alpha;gl_FragColor=vec4(1.,.84,.5,a);}"}),F=new Gc(U,O);F.layers.enable(1),F.renderOrder=15,F.frustumCulled=!1,F.visible=!n,l.add(F);function V(){for(const[B,j]of[["baby",".baby-target"],["orbit",".sealed-being"],["menina",'[data-gender="menina"] .soul-anchor'],["menino",'[data-gender="menino"] .soul-anchor']])f[B]=t.querySelector(j).getBoundingClientRect()}function k(B){if(!u.ready)return;for(const[me,ae]of Object.entries(o)){const le=ae.material.uniforms.uHover;le.value=_e.lerp(le.value,m===me?1:0,n?1:.15)}const j=B*.001;e.updateWorldMatrix(!0,!1),e.getWorldPosition(_),e.getWorldQuaternion(y),B-v>80&&(V(),v=B);const ne=n?1:La(.5,2.1,(B-d)/1e3);u.introProgress=ne,u.phase==="sealed"&&(t.querySelector(".baby-target").disabled=ne<1);const Q=h===null?0:(B-h)/1e3,re=fb(Q,n),ce=h!==null,G=ce?n?Math.min(1,Q/.18):La(.5,1.65,Q):0;s?.setTransition(G),u.environmentTransition=G;const Y=ce&&!n?La(.12,.52,Q)*(1-La(.62,1.3,Q)):0;t.style.setProperty("--birth-flash",String(Y)),t.style.setProperty("--birth-transition",String(G)),ce&&(u.releaseProgress=Math.min(1,Q/(n?.18:2.8)));const ie=o.baby,ye=n?0:Math.sin(j*.6)*4;E(ie,f.baby,-42,M.baby,j,ye),c.baby.update(j,n,0),ie.material.uniforms.uCharge.value=ce?re.charge:0,ie.material.uniforms.uReveal.value=ce?re.baby:1,ie.material.uniforms.uOpacity.value=ne,ie.visible=!(ce&&re.complete);const se=f.orbit,Le=Math.min(se.width,se.height),be=A(se.x+se.width/2,se.y+se.height/2+ye,-44),L=A(se.x+se.width/2-Le/2,se.y+se.height/2,-44),Ue=A(se.x+se.width/2+Le/2,se.y+se.height/2,-44);C.root.position.copy(be),C.root.quaternion.copy(y),C.root.scale.setScalar(L.distanceTo(Ue)),C.update(ce?re.fracture:0,ce?re.charge:0,ne,j),u.bindingFracture=ce?re.fracture:0;for(const me of["menina","menino"]){const ae=o[me];if(ae.visible=ce,!ce)continue;const le=f[me],Ne=f.baby,pe=re.separation,Ae=n?0:Math.sin(pe*Math.PI)*28,He={width:le.width,height:le.height,x:_e.lerp(Ne.x+Ne.width/2-le.width/2,le.x,pe),y:_e.lerp(Ne.y+Ne.height/2-le.height/2,le.y,pe)-Ae};E(ae,He,-39,M[me],j,n?0:Math.sin(j*.55+(me==="menina"?0:2))*4);const ke=ae.material.uniforms;c[me].update(j,n,ke.uSelected.value),ke.uReveal.value=re.children,ke.uSelected.value=_e.lerp(ke.uSelected.value,u.selected===me?1:0,n?1:.12)}if(ce&&!n){F.visible=!0;const me=C.root.position;F.position.copy(me),F.quaternion.copy(y),O.uniforms.uTime.value=j,O.uniforms.uElapsed.value=Q,O.uniforms.uActive.value=re.particles,O.uniforms.uExtent.value.set(C.root.scale.x,C.root.scale.y)}if(ce&&re.complete&&p){u.phase="identity";const me=p;p=null,me()}}function z(){return h!==null?Promise.resolve(!1):(u.phase="breaking",h=performance.now(),new Promise(B=>{p=B}))}return{ready:b,state:u,update:k,release:z,get meshes(){return o},rigs:c,bindings:C,hover(B){m=B},select(B){u.selected=B},point(B){g=B},dispose(){i.remove(l),C.dispose();for(const B of Object.values(c))B.dispose();U.dispose(),O.dispose();for(const B of Object.values(o))B.material.dispose();for(const B of Object.values(a))B.dispose()}}}const Mi=Object.freeze([{code:"ACADEMICO",label:"Acadêmico",source:"Livro Base",fixedSkills:["CIENCIAS","INVESTIGACAO"],variableSkillCount:0,professionRequired:!1,powerName:"Saber é Poder"},{code:"AGENTE_SAUDE",label:"Agente de Saúde",source:"Livro Base",fixedSkills:["INTUICAO","MEDICINA"],variableSkillCount:0,professionRequired:!1,powerName:"Técnica Medicinal"},{code:"ARTISTA",label:"Artista",source:"Livro Base",fixedSkills:["ARTES","ENGANACAO"],variableSkillCount:0,professionRequired:!1,powerName:"Magnum Opus"},{code:"ATLETA",label:"Atleta",source:"Livro Base",fixedSkills:["ACROBACIA","ATLETISMO"],variableSkillCount:0,professionRequired:!1,powerName:"110%"},{code:"CHEF",label:"Chef",source:"Livro Base",fixedSkills:["FORTITUDE","PROFISSAO"],variableSkillCount:0,professionRequired:!0,powerName:"Prato do Dia"},{code:"CRIMINOSO",label:"Criminoso",source:"Livro Base",fixedSkills:["CRIME","FURTIVIDADE"],variableSkillCount:0,professionRequired:!1,powerName:"Artifício"},{code:"CULTISTA_ARREPENDIDO",label:"Cultista Arrependido",source:"Livro Base",fixedSkills:["OCULTISMO","RELIGIAO"],variableSkillCount:0,professionRequired:!1,powerName:"Traços do Outro Lado"},{code:"DESGARRADO",label:"Desgarrado",source:"Livro Base",fixedSkills:["FORTITUDE","SOBREVIVENCIA"],variableSkillCount:0,professionRequired:!1,powerName:"Calejado"},{code:"ENGENHEIRO",label:"Engenheiro",source:"Livro Base",fixedSkills:["PROFISSAO","TECNOLOGIA"],variableSkillCount:0,professionRequired:!0,powerName:"Ferramenta Favorita"},{code:"EXECUTIVO",label:"Executivo",source:"Livro Base",fixedSkills:["DIPLOMACIA","PROFISSAO"],variableSkillCount:0,professionRequired:!0,powerName:"Processo Otimizado"},{code:"INVESTIGADOR",label:"Investigador",source:"Livro Base",fixedSkills:["INVESTIGACAO","PERCEPCAO"],variableSkillCount:0,professionRequired:!1,powerName:"Faro para Pistas"},{code:"LUTADOR",label:"Lutador",source:"Livro Base",fixedSkills:["LUTA","REFLEXOS"],variableSkillCount:0,professionRequired:!1,powerName:"Lutador Exímio"},{code:"MAGNATA",label:"Magnata",source:"Livro Base",fixedSkills:["DIPLOMACIA","PILOTAGEM"],variableSkillCount:0,professionRequired:!1,powerName:"Ajudante Fiel"},{code:"MERCENARIO",label:"Mercenário",source:"Livro Base",fixedSkills:["INICIATIVA","INTIMIDACAO"],variableSkillCount:0,professionRequired:!1,powerName:"Posição de Combate"},{code:"MILITAR",label:"Militar",source:"Livro Base",fixedSkills:["PONTARIA","TATICA"],variableSkillCount:0,professionRequired:!1,powerName:"Em Formação"},{code:"OPERARIO",label:"Operário",source:"Livro Base",fixedSkills:["FORTITUDE","PROFISSAO"],variableSkillCount:0,professionRequired:!0,powerName:"Ferramenta de Trabalho"},{code:"POLICIAL",label:"Policial",source:"Livro Base",fixedSkills:["PERCEPCAO","PONTARIA"],variableSkillCount:0,professionRequired:!1,powerName:"Patrulha"},{code:"RELIGIOSO",label:"Religioso",source:"Livro Base",fixedSkills:["RELIGIAO","VONTADE"],variableSkillCount:0,professionRequired:!1,powerName:"Acalentar"},{code:"SERVIDOR_PUBLICO",label:"Servidor Público",source:"Livro Base",fixedSkills:["INTUICAO","VONTADE"],variableSkillCount:0,professionRequired:!1,powerName:"Espírito Cívico"},{code:"TEORICO_CONSPIRACAO",label:"Teórico da Conspiração",source:"Livro Base",fixedSkills:["INVESTIGACAO","OCULTISMO"],variableSkillCount:0,professionRequired:!1,powerName:"Eu Já Sabia"},{code:"TI",label:"T.I.",source:"Livro Base",fixedSkills:["INVESTIGACAO","TECNOLOGIA"],variableSkillCount:0,professionRequired:!1,powerName:"Motor de Busca"},{code:"TRABALHADOR_RURAL",label:"Trabalhador Rural",source:"Livro Base",fixedSkills:["ADESTRAMENTO","SOBREVIVENCIA"],variableSkillCount:0,professionRequired:!1,powerName:"Desbravador"},{code:"TRAMBIQUEIRO",label:"Trambiqueiro",source:"Livro Base",fixedSkills:["CRIME","ENGANACAO"],variableSkillCount:0,professionRequired:!1,powerName:"Impostor"},{code:"UNIVERSITARIO",label:"Universitário",source:"Livro Base",fixedSkills:["ATUALIDADES","INVESTIGACAO"],variableSkillCount:0,professionRequired:!1,powerName:"Dedicação"},{code:"VITIMA",label:"Vítima",source:"Livro Base",fixedSkills:["REFLEXOS","VONTADE"],variableSkillCount:0,professionRequired:!1,powerName:"Cicatrizes Psicológicas"},{code:"AMIGO_ANIMAIS",label:"Amigo dos Animais",source:"Sobrevivendo ao Horror",fixedSkills:["ADESTRAMENTO","PERCEPCAO"],variableSkillCount:0,professionRequired:!1,powerName:"Companheiro Animal"},{code:"ASTRONAUTA",label:"Astronauta",source:"Sobrevivendo ao Horror",fixedSkills:["CIENCIAS","FORTITUDE"],variableSkillCount:0,professionRequired:!1,powerName:"Acostumado ao Extremo"},{code:"CHEF_OUTRO_LADO",label:"Chef do Outro Lado",source:"Sobrevivendo ao Horror",fixedSkills:["OCULTISMO","PROFISSAO"],variableSkillCount:0,professionRequired:!0,powerName:"Fome do Outro Lado"},{code:"COLEGIAL",label:"Colegial",source:"Sobrevivendo ao Horror",fixedSkills:["ATUALIDADES","TECNOLOGIA"],variableSkillCount:0,professionRequired:!1,powerName:"Poder da Amizade"},{code:"COSPLAYER",label:"Cosplayer",source:"Sobrevivendo ao Horror",fixedSkills:["ARTES","VONTADE"],variableSkillCount:0,professionRequired:!1,powerName:"Não é fantasia, é cosplay!"},{code:"DIPLOMATA",label:"Diplomata",source:"Sobrevivendo ao Horror",fixedSkills:["ATUALIDADES","DIPLOMACIA"],variableSkillCount:0,professionRequired:!1,powerName:"Conexões"},{code:"EXPLORADOR",label:"Explorador",source:"Sobrevivendo ao Horror",fixedSkills:["FORTITUDE","SOBREVIVENCIA"],variableSkillCount:0,professionRequired:!1,powerName:"Manual do Sobrevivente"},{code:"EXPERIMENTO",label:"Experimento",source:"Sobrevivendo ao Horror",fixedSkills:["ATLETISMO","FORTITUDE"],variableSkillCount:0,professionRequired:!1,powerName:"Mutação"},{code:"FANATICO_CRIATURAS",label:"Fanático por Criaturas",source:"Sobrevivendo ao Horror",fixedSkills:["INVESTIGACAO","OCULTISMO"],variableSkillCount:0,professionRequired:!1,powerName:"Conhecimento Oculto"},{code:"FOTOGRAFO",label:"Fotógrafo",source:"Sobrevivendo ao Horror",fixedSkills:["ARTES","PERCEPCAO"],variableSkillCount:0,professionRequired:!1,powerName:"Através da Lente"},{code:"INVENTOR_PARANORMAL",label:"Inventor Paranormal",source:"Sobrevivendo ao Horror",fixedSkills:["PROFISSAO","VONTADE"],variableSkillCount:0,professionRequired:!0,powerName:"Invenção Paranormal"},{code:"JOVEM_MISTICO",label:"Jovem Místico",source:"Sobrevivendo ao Horror",fixedSkills:["OCULTISMO","RELIGIAO"],variableSkillCount:0,professionRequired:!1,powerName:"A Culpa é das Estrelas"},{code:"LEGISTA_NOTURNO",label:"Legista do Turno da Noite",source:"Sobrevivendo ao Horror",fixedSkills:["CIENCIAS","MEDICINA"],variableSkillCount:0,professionRequired:!1,powerName:"Luto Habitual"},{code:"MATEIRO",label:"Mateiro",source:"Sobrevivendo ao Horror",fixedSkills:["PERCEPCAO","SOBREVIVENCIA"],variableSkillCount:0,professionRequired:!1,powerName:"Mapa Celeste"},{code:"MERGULHADOR",label:"Mergulhador",source:"Sobrevivendo ao Horror",fixedSkills:["ATLETISMO","FORTITUDE"],variableSkillCount:0,professionRequired:!1,powerName:"Fôlego de Nadador"},{code:"MOTORISTA",label:"Motorista",source:"Sobrevivendo ao Horror",fixedSkills:["PILOTAGEM","REFLEXOS"],variableSkillCount:0,professionRequired:!1,powerName:"Mãos no Volante"},{code:"NERD_ENTUSIASTA",label:"Nerd Entusiasta",source:"Sobrevivendo ao Horror",fixedSkills:["CIENCIAS","TECNOLOGIA"],variableSkillCount:0,professionRequired:!1,powerName:"O Inteligentão"},{code:"PSICOLOGO",label:"Psicólogo",source:"Sobrevivendo ao Horror",fixedSkills:["INTUICAO","PROFISSAO"],variableSkillCount:0,professionRequired:!0,powerName:"Terapia"},{code:"REPORTER_INVESTIGATIVO",label:"Repórter Investigativo",source:"Sobrevivendo ao Horror",fixedSkills:["ATUALIDADES","INVESTIGACAO"],variableSkillCount:0,professionRequired:!1,powerName:"Encontrar a Verdade"},{code:"ACALENTADOR",label:"Acalentador",source:"Suplemento Órion",fixedSkills:["DIPLOMACIA","INTUICAO"],variableSkillCount:0,professionRequired:!1,powerName:"Apoio Emocional"},{code:"ALFAIATE",label:"Alfaiate",source:"Suplemento Órion",fixedSkills:["ARTES","PROFISSAO"],variableSkillCount:0,professionRequired:!0,powerName:"Fada Madrinha"},{code:"APOSTADOR",label:"Apostador",source:"Suplemento Órion",fixedSkills:["CRIME","ENGANACAO"],variableSkillCount:0,professionRequired:!1,powerName:"Carta na Manga"},{code:"ATIRADOR_EXIMIO",label:"Atirador Exímio",source:"Suplemento Órion",fixedSkills:["PERCEPCAO","PONTARIA"],variableSkillCount:0,professionRequired:!1,powerName:"Precisão Mortal"},{code:"BOMBADO",label:"Bombado",source:"Suplemento Órion",fixedSkills:["ATLETISMO","FORTITUDE"],variableSkillCount:0,professionRequired:!1,powerName:"AESTHETIC!"},{code:"BOTICARIO",label:"Boticário",source:"Suplemento Órion",fixedSkills:["CIENCIAS","MEDICINA"],variableSkillCount:0,professionRequired:!1,powerName:"Medicina Amarga"},{code:"COLECIONADOR",label:"Colecionador",source:"Suplemento Órion",fixedSkills:["OCULTISMO","SOBREVIVENCIA"],variableSkillCount:0,professionRequired:!1,powerName:"Recompensa de Espólios"},{code:"CRIANCA_AMALDICOADA",label:"Criança Amaldiçoada",source:"Suplemento Órion",fixedSkills:["OCULTISMO","VONTADE"],variableSkillCount:0,professionRequired:!1,powerName:"Feito de Medo"},{code:"DESOCUPADO",label:"Desocupado",source:"Suplemento Órion",fixedSkills:["ATUALIDADES"],variableSkillCount:1,professionRequired:!1,powerName:"Conhecimento Específico"},{code:"HERDEIRO",label:"Herdeiro",source:"Suplemento Órion",fixedSkills:["ATUALIDADES","OCULTISMO"],variableSkillCount:0,professionRequired:!1,powerName:"Herança"},{code:"INVENTOR",label:"Inventor",source:"Suplemento Órion",fixedSkills:["INTUICAO","PROFISSAO"],variableSkillCount:0,professionRequired:!0,powerName:"Gambiarra Aprimorada"},{code:"LINHA_FRENTE",label:"Linha de Frente",source:"Suplemento Órion",fixedSkills:["FORTITUDE","LUTA"],variableSkillCount:0,professionRequired:!1,powerName:"O Tanque"},{code:"MOCHILEIRO_ORIGEM",label:"Mochileiro",source:"Suplemento Órion",fixedSkills:["DIPLOMACIA","SOBREVIVENCIA"],variableSkillCount:0,professionRequired:!1,powerName:"Bom Mochileiro"},{code:"PLAYER",label:"Player",source:"Suplemento Órion",fixedSkills:["REFLEXOS","TECNOLOGIA"],variableSkillCount:0,professionRequired:!1,powerName:"Easter Egg"},{code:"PROFETA",label:"Profeta",source:"Suplemento Órion",fixedSkills:["INTUICAO","RELIGIAO"],variableSkillCount:0,professionRequired:!1,powerName:"Voz do Além"},{code:"REVOLUCIONARIO",label:"Revolucionário",source:"Suplemento Órion",fixedSkills:["DIPLOMACIA","INTIMIDACAO"],variableSkillCount:0,professionRequired:!1,powerName:"Contra à Opressão"},{code:"VETERINARIO",label:"Veterinário",source:"Suplemento Órion",fixedSkills:["ADESTRAMENTO","MEDICINA"],variableSkillCount:0,professionRequired:!1,powerName:"Animalis"},{code:"BODYBUILDER",label:"Bodybuilder",source:"Suplemento Órion",fixedSkills:["ATLETISMO","FORTITUDE"],variableSkillCount:0,professionRequired:!1,powerName:"Saindo da Jaula"},{code:"BLASTER",label:"Blaster",source:"Suplemento Órion",fixedSkills:["CIENCIAS","PROFISSAO"],variableSkillCount:0,professionRequired:!0,powerName:"Explosão Solidária"},{code:"PERSONAL_TRAINER",label:"Personal Trainer",source:"Suplemento Órion",fixedSkills:["ATLETISMO","CIENCIAS"],variableSkillCount:0,professionRequired:!1,powerName:"Todo Mundo Pagando 10"},{code:"EXORCIZADO",label:"Exorcizado",source:"Arquivos Secretos #7",fixedSkills:["FORTITUDE","OCULTISMO"],variableSkillCount:0,professionRequired:!1,powerName:"O Que Restou"},{code:"SENSITIVO_REBELDE",label:"Sensitivo Rebelde",source:"Arquivos Secretos #7",fixedSkills:["INTUICAO","VONTADE"],variableSkillCount:0,professionRequired:!1,powerName:"Sussurros e Vultos"}].map(i=>Object.freeze({...i,fixedSkills:Object.freeze(i.fixedSkills)}))),Pf=Object.freeze([{code:"ACROBACIA",label:"Acrobacia",attribute:"AGI",trainedOnly:!1,usesKit:!1},{code:"ADESTRAMENTO",label:"Adestramento",attribute:"PRE",trainedOnly:!0,usesKit:!1},{code:"ARTES",label:"Artes",attribute:"PRE",trainedOnly:!0,usesKit:!1},{code:"ATLETISMO",label:"Atletismo",attribute:"FOR",trainedOnly:!1,usesKit:!1},{code:"ATUALIDADES",label:"Atualidades",attribute:"INT",trainedOnly:!1,usesKit:!1},{code:"CIENCIAS",label:"Ciências",attribute:"INT",trainedOnly:!0,usesKit:!1},{code:"CRIME",label:"Crime",attribute:"AGI",trainedOnly:!0,usesKit:!0},{code:"DIPLOMACIA",label:"Diplomacia",attribute:"PRE",trainedOnly:!1,usesKit:!1},{code:"ENGANACAO",label:"Enganação",attribute:"PRE",trainedOnly:!1,usesKit:!0},{code:"FORTITUDE",label:"Fortitude",attribute:"VIG",trainedOnly:!1,usesKit:!1},{code:"FURTIVIDADE",label:"Furtividade",attribute:"AGI",trainedOnly:!1,usesKit:!1},{code:"INICIATIVA",label:"Iniciativa",attribute:"AGI",trainedOnly:!1,usesKit:!1},{code:"INTIMIDACAO",label:"Intimidação",attribute:"PRE",trainedOnly:!1,usesKit:!1},{code:"INTUICAO",label:"Intuição",attribute:"PRE",trainedOnly:!1,usesKit:!1},{code:"INVESTIGACAO",label:"Investigação",attribute:"INT",trainedOnly:!1,usesKit:!1},{code:"LUTA",label:"Luta",attribute:"FOR",trainedOnly:!1,usesKit:!1},{code:"MEDICINA",label:"Medicina",attribute:"INT",trainedOnly:!1,usesKit:!0},{code:"OCULTISMO",label:"Ocultismo",attribute:"INT",trainedOnly:!0,usesKit:!1},{code:"PERCEPCAO",label:"Percepção",attribute:"PRE",trainedOnly:!1,usesKit:!1},{code:"PILOTAGEM",label:"Pilotagem",attribute:"AGI",trainedOnly:!0,usesKit:!1},{code:"PONTARIA",label:"Pontaria",attribute:"AGI",trainedOnly:!1,usesKit:!1},{code:"PROFISSAO",label:"Profissão",attribute:"INT",trainedOnly:!0,usesKit:!1},{code:"REFLEXOS",label:"Reflexos",attribute:"AGI",trainedOnly:!1,usesKit:!1},{code:"RELIGIAO",label:"Religião",attribute:"PRE",trainedOnly:!0,usesKit:!1},{code:"SOBREVIVENCIA",label:"Sobrevivência",attribute:"INT",trainedOnly:!1,usesKit:!1},{code:"TATICA",label:"Tática",attribute:"INT",trainedOnly:!0,usesKit:!1},{code:"TECNOLOGIA",label:"Tecnologia",attribute:"INT",trainedOnly:!0,usesKit:!0},{code:"VONTADE",label:"Vontade",attribute:"PRE",trainedOnly:!1,usesKit:!1}].map(Object.freeze)),bb=Object.freeze({ACADEMICO:"Você pesquisava documentos antigos na biblioteca de uma universidade.",AGENTE_SAUDE:"Você cuidava de pacientes no plantão noturno de um hospital.",ARTISTA:"Você pintava murais pela cidade para pagar as contas.",ATLETA:"Você treinava todos os dias para disputar o campeonato da sua cidade.",CHEF:"Você comandava a cozinha de um pequeno restaurante de bairro.",CRIMINOSO:"Você abria fechaduras para uma quadrilha de ladrões.",CULTISTA_ARREPENDIDO:"Você abandonou uma seita e tentou reconstruir a vida longe dela.",DESGARRADO:"Você mudava de cidade com uma mochila e aceitava trabalhos temporários.",ENGENHEIRO:"Você projetava máquinas e passava as tardes entre ferramentas e plantas.",EXECUTIVO:"Você negociava contratos e resolvia problemas de uma grande empresa.",INVESTIGADOR:"Você procurava pessoas desaparecidas num pequeno escritório de detetive.",LUTADOR:"Você dava aulas de luta numa academia e competia nos fins de semana.",MAGNATA:"Você administrava os negócios da família e frequentava eventos exclusivos.",MERCENARIO:"Você aceitava trabalhos perigosos para quem pudesse pagar.",MILITAR:"Você servia numa unidade militar e participava dos treinamentos de campo.",OPERARIO:"Você consertava equipamentos durante o turno de uma fábrica.",POLICIAL:"Você atendia ocorrências e fazia patrulhas nas ruas do seu bairro.",RELIGIOSO:"Você acolhia os moradores de uma pequena comunidade religiosa.",SERVIDOR_PUBLICO:"Você atendia o público e organizava documentos numa repartição.",TEORICO_CONSPIRACAO:"Você reunia recortes de jornal sobre casos que ninguém conseguia explicar.",TI:"Você mantinha os computadores de uma empresa funcionando.",TRABALHADOR_RURAL:"Você cuidava da plantação e dos animais numa propriedade do interior.",TRAMBIQUEIRO:"Você vivia de pequenos golpes, sempre inventando uma nova história.",UNIVERSITARIO:"Você dividia os dias entre aulas, estágio e trabalhos da faculdade.",VITIMA:"Você tentava retomar a rotina depois de sobreviver a um acontecimento terrível.",AMIGO_ANIMAIS:"Você resgatava animais de rua e ajudava a encontrar novos lares para eles.",ASTRONAUTA:"Você passou anos treinando para integrar uma missão espacial.",CHEF_OUTRO_LADO:"Você começou a investigar uma receita estranha encontrada no caderno da família.",COLEGIAL:"Você estudava de manhã e passava as tardes com os amigos da escola.",COSPLAYER:"Você costurava fantasias e participava de encontros de fãs.",DIPLOMATA:"Você representava uma instituição em reuniões e negociações delicadas.",EXPLORADOR:"Você participava de expedições para conhecer regiões pouco visitadas.",EXPERIMENTO:"Você escapou de um laboratório e tentou descobrir o que fizeram com você.",FANATICO_CRIATURAS:"Você mantinha um caderno cheio de relatos sobre criaturas misteriosas.",FOTOGRAFO:"Você fotografava festas e eventos para pagar o aluguel.",INVENTOR_PARANORMAL:"Você montava aparelhos para tentar registrar fenômenos inexplicáveis.",JOVEM_MISTICO:"Você lia cartas para os amigos e colecionava histórias sobre o oculto.",LEGISTA_NOTURNO:"Você examinava corpos no turno da noite de um instituto médico-legal.",MATEIRO:"Você guiava viajantes pelas trilhas e matas da região onde cresceu.",MERGULHADOR:"Você trabalhava inspecionando embarcações debaixo d’água.",MOTORISTA:"Você atravessava estradas fazendo entregas entre cidades.",NERD_ENTUSIASTA:"Você organizava encontros para conversar sobre seu assunto favorito.",PSICOLOGO:"Você atendia pessoas num consultório e ouvia suas histórias.",REPORTER_INVESTIGATIVO:"Você seguia denúncias anônimas para escrever reportagens sobre gente poderosa.",ACALENTADOR:"Você acolhia vizinhos que precisavam conversar depois de um dia difícil.",ALFAIATE:"Você ajustava roupas e costurava peças sob medida numa pequena oficina.",APOSTADOR:"Você frequentava mesas de cartas e apostava parte do que ganhava.",ATIRADOR_EXIMIO:"Você treinava tiro esportivo e participava de competições locais.",BOMBADO:"Você passava boa parte do tempo na academia, seguindo uma rotina de treino.",BOTICARIO:"Você preparava remédios e misturas numa pequena botica.",COLECIONADOR:"Você visitava feiras de antiguidades em busca de objetos incomuns.",CRIANCA_AMALDICOADA:"Você cresceu ouvindo a família contar histórias sobre coisas estranhas ao seu redor.",DESOCUPADO:"Você fazia bicos quando precisava e passava o tempo explorando seus interesses.",HERDEIRO:"Você recebeu uma herança de um parente que quase não conhecia.",INVENTOR:"Você desmontava aparelhos velhos para construir suas próprias invenções.",LINHA_FRENTE:"Você trabalhava protegendo pessoas em lugares onde havia perigo.",MOCHILEIRO_ORIGEM:"Você viajava de carona, conhecendo pessoas e dormindo onde conseguia.",PLAYER:"Você jogava com os amigos e participava de pequenos torneios.",PROFETA:"Você anotava sonhos estranhos num caderno que levava a todo lugar.",REVOLUCIONARIO:"Você organizava protestos para mudar uma situação injusta na sua comunidade.",VETERINARIO:"Você atendia animais numa clínica e ajudava um abrigo nos fins de semana.",BODYBUILDER:"Você se preparava para subir ao palco de uma competição de fisiculturismo.",BLASTER:"Você trabalhava com demolições e acompanhava a preparação de explosivos.",PERSONAL_TRAINER:"Você montava treinos e acompanhava os alunos de uma academia.",EXORCIZADO:"Você tentou retomar a rotina depois de passar por um exorcismo.",SENSITIVO_REBELDE:"Você escondia suas percepções estranhas de uma família que não acreditava."});function yc(i){return bb[i.code]??""}const Sr=Object.freeze([{id:"investigar",label:"Investigar",prompt:"Quero descobrir o que está escondido.",skills:["INVESTIGACAO","PERCEPCAO","CIENCIAS","ATUALIDADES"]},{id:"cuidar",label:"Cuidar",prompt:"Quero cuidar de pessoas ou animais.",skills:["MEDICINA","ADESTRAMENTO","INTUICAO"]},{id:"criar",label:"Criar e consertar",prompt:"Quero criar, consertar ou entender máquinas.",skills:["TECNOLOGIA","PROFISSAO","ARTES"]},{id:"convencer",label:"Convencer",prompt:"Quero lidar com pessoas e influenciar decisões.",skills:["DIPLOMACIA","ENGANACAO","INTIMIDACAO"]},{id:"sobreviver",label:"Sobreviver",prompt:"Quero explorar e me virar em lugares difíceis.",skills:["SOBREVIVENCIA","FORTITUDE","PILOTAGEM"]},{id:"agir",label:"Agir sob pressão",prompt:"Quero uma história ligada à ação e ao esforço físico.",skills:["LUTA","PONTARIA","ATLETISMO","REFLEXOS","INICIATIVA"]},{id:"paranormal",label:"Paranormal",prompt:"Quero um passado próximo do inexplicável.",skills:["OCULTISMO","RELIGIAO"]},{id:"discricao",label:"Agir com discrição",prompt:"Quero alguém que saiba agir sem chamar atenção.",skills:["CRIME","FURTIVIDADE"]}].map(i=>Object.freeze({...i,skills:Object.freeze(i.skills)}))),Mb={ACADEMICO:"Uma vida entre estudos, perguntas e conhecimento. Nem toda resposta estava nos livros.",AGENTE_SAUDE:"Cuidar de pessoas fazia parte da sua rotina, muito antes do inexplicável.",ARTISTA:"Você encontrava na arte uma forma de dizer o que palavras comuns não alcançavam.",ATLETA:"Treino, disciplina e movimento marcaram sua vida.",CHEF:"Sua história passava pela cozinha, pelos sabores e pelas pessoas ao redor da mesa.",CRIMINOSO:"Você conheceu caminhos que as pessoas preferem não mencionar.",CULTISTA_ARREPENDIDO:"Seu passado se aproximou de uma crença que você decidiu abandonar.",DESGARRADO:"Você aprendeu a seguir em frente mesmo sem um lugar ao qual pertencer.",ENGENHEIRO:"Entender como as coisas funcionam sempre foi parte da sua maneira de ver o mundo.",EXECUTIVO:"Decisões, negociações e responsabilidades preenchiam seus dias.",INVESTIGADOR:"Você aprendeu a procurar pistas onde outras pessoas só viam detalhes.",LUTADOR:"Seu corpo, seu treino e sua determinação contam parte da sua história.",MAGNATA:"Dinheiro, influência e os círculos que os acompanham fizeram parte da sua vida.",MERCENARIO:"Você já esteve em situações perigosas em troca de pagamento.",MILITAR:"Disciplina e treinamento militar deixaram marcas no seu passado.",OPERARIO:"Seu conhecimento nasceu do trabalho e da prática cotidiana.",POLICIAL:"Sua rotina envolvia ocorrências, investigação e a vida nas ruas.",RELIGIOSO:"A fé foi uma presença importante na sua trajetória.",SERVIDOR_PUBLICO:"Você conheceu o trabalho diário de atender pessoas e fazer instituições funcionarem.",TEORICO_CONSPIRACAO:"Você suspeitava que havia algo por trás das versões oficiais.",TI:"Computadores, sistemas e informação faziam parte do seu cotidiano.",TRABALHADOR_RURAL:"Sua vida estava ligada à terra, aos animais e aos ritmos do campo.",TRAMBIQUEIRO:"Você aprendeu a sair de situações difíceis com conversa e esperteza.",UNIVERSITARIO:"Estudos, descobertas e uma vida ainda em construção compunham sua rotina.",VITIMA:"Algo que você viveu deixou marcas. Sua história continua para além delas.",AMIGO_ANIMAIS:"Sua relação com os animais sempre teve um lugar especial na sua vida.",ASTRONAUTA:"Você construiu uma trajetória ligada ao espaço e aos seus desafios.",CHEF_OUTRO_LADO:"A cozinha e o inexplicável se encontram na ideia desse passado.",COLEGIAL:"Sua história começou entre aulas, amizades e descobertas da vida escolar.",COSPLAYER:"Criar e interpretar outras figuras era uma forma de expressão para você.",DIPLOMATA:"Sua experiência passava por diálogo, negociações e relações entre pessoas.",EXPLORADOR:"Lugares desconhecidos e a vontade de descobrir marcaram sua trajetória.",EXPERIMENTO:"Uma experiência incomum faz parte da história que você quer contar.",FANATICO_CRIATURAS:"O interesse por criaturas e pelo desconhecido ocupava seus pensamentos.",FOTOGRAFO:"Você aprendeu a perceber o mundo por meio de enquadramentos e imagens.",INVENTOR_PARANORMAL:"Criar coisas e se aproximar do inexplicável se cruzam no seu passado.",JOVEM_MISTICO:"Crenças e sinais incomuns acompanharam suas primeiras descobertas.",LEGISTA_NOTURNO:"Seu trabalho passava por perguntas que os mortos deixavam para os vivos.",MATEIRO:"Você se acostumou a observar caminhos, rastros e a vida fora das cidades.",MERGULHADOR:"Seu passado está ligado às profundezas e à experiência de mergulhar.",MOTORISTA:"Estradas, trajetos e o tempo ao volante fizeram parte da sua rotina.",NERD_ENTUSIASTA:"Seus interesses renderam horas de estudo, curiosidade e dedicação.",PSICOLOGO:"Ouvir pessoas e buscar compreender suas experiências marcou sua vida.",REPORTER_INVESTIGATIVO:"Você buscava histórias, fontes e os fatos por trás das aparências.",ACALENTADOR:"Acolher pessoas e estar presente para elas era parte da sua história.",ALFAIATE:"Seu trabalho transformava tecido, medidas e ideias em vestimentas.",APOSTADOR:"Jogos, apostas e decisões arriscadas atravessaram seu passado.",ATIRADOR_EXIMIO:"Precisão e treinamento de tiro fazem parte da história que você quer contar.",BOMBADO:"A dedicação ao treino físico deixou marcas na sua rotina.",BOTICARIO:"Preparos, ingredientes e cuidados faziam parte do seu conhecimento.",COLECIONADOR:"Você reunia objetos e histórias que tinham um significado particular.",CRIANCA_AMALDICOADA:"Um passado de infância atravessado pelo inexplicável compõe essa ideia de história.",DESOCUPADO:"Sua trajetória não cabe facilmente em uma profissão ou rotina definida.",HERDEIRO:"O que veio antes de você deixou uma herança na sua história.",INVENTOR:"Você procurava soluções e gostava de transformar ideias em coisas.",LINHA_FRENTE:"Estar perto do perigo faz parte da história que você quer contar.",MOCHILEIRO_ORIGEM:"Viagens, encontros e caminhos abertos marcaram sua vida.",PLAYER:"Jogos e suas descobertas fazem parte dos seus interesses.",PROFETA:"Sua história se aproxima da fé e de sinais difíceis de explicar.",REVOLUCIONARIO:"Mudar a realidade ao seu redor era uma motivação importante para você.",VETERINARIO:"Cuidar da saúde dos animais fazia parte da sua vida.",BODYBUILDER:"Construir o próprio corpo era um projeto feito de rotina e dedicação.",BLASTER:"Seu interesse por explosivos faz parte da ideia desse passado.",PERSONAL_TRAINER:"Você ajudava outras pessoas a desenvolver o corpo por meio do treino.",EXORCIZADO:"Um exorcismo atravessa a história que você quer contar.",SENSITIVO_REBELDE:"Percepções incomuns e uma postura de questionamento atravessam essa ideia de passado."},Eb={AGENTE_SAUDE:"médico médica enfermeiro enfermeira hospital",TI:"computador informática hacker programador programação",RELIGIOSO:"padre pastor freira igreja",OPERARIO:"fábrica construção trabalhador",INVESTIGADOR:"detetive pistas mistério",TRABALHADOR_RURAL:"fazenda campo agricultor",ACALENTADOR:"acolhimento apoio",VETERINARIO:"bicho pet animal",BOTICARIO:"remédio farmácia",PERSONAL_TRAINER:"academia exercício"};function hh(i){return String(i??"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLocaleLowerCase("pt-BR").replace(/[^a-z0-9]+/g," ").trim()}function Ja(i){return Pf.find(e=>e.code===i)?.label??i}function Lf(i){return Mb[i.code]??"Escolha esta origem para explorar uma possibilidade para o seu passado."}function Tb(i){return Sr.filter(e=>i.fixedSkills.some(t=>e.skills.includes(t)))}function fh({query:i="",interest:e="",source:t="",skill:n=""}={}){const s=hh(i).split(" ").filter(Boolean);return Mi.filter(r=>{const a=hh([r.label,r.powerName,r.source,Lf(r),yc(r),Eb[r.code]??"",...r.fixedSkills.map(Ja)].join(" "));return(!t||r.source===t)&&(!n||r.fixedSkills.includes(n))&&(!e||Tb(r).some(o=>o.id===e))&&s.every(o=>a.includes(o))}).sort((r,a)=>r.label.localeCompare(a.label,"pt-BR"))}const ge=i=>`<path d="${i}"/>`,qe=(i,e,t)=>`<circle cx="${i}" cy="${e}" r="${t}"/>`,ph=(i,e,t,n)=>`<ellipse cx="${i}" cy="${e}" rx="${t}" ry="${n}"/>`,mh=ge("M7 12q9-5 17 1 8-6 17-1v25q-9-4-17 1-8-5-17-1ZM24 13v25M11 18l8 1m-8 5 8 1m10-6 8-1m-8 7 8-1"),Ab=ge("M21 17h6v7h7v6h-7v7h-6v-7h-7v-6h7Z"),wb=qe(16,16,3)+qe(24,12,3)+qe(32,16,3)+ge("M24 21c-5 0-7 6-10 9-4 6 1 10 6 7 3-2 5-2 8 0 5 3 10-1 6-7-3-3-5-9-10-9Z"),Rb=ge("M24 34 12 22c-9-10 7-18 12-8 5-10 21-2 12 8Z"),gh=ge("M18 32v-4c-10-8-5-22 6-22s16 14 6 22v4ZM18 36h12m-10 5h8M24 4V1M9 12l-4-3m34 3 4-3"),Cb=ge("M7 15q17 6 34 0v8c0 13-17 19-17 19S7 36 7 23ZM13 24q4-5 8 0m6 0q4-5 8 0M19 32q5 4 10 0"),vh=ge("M14 15v-4q0-4 4-4h12q4 0 4 4v4M7 16h34v25H7ZM18 7v8m12-8v8"),Ib=qe(24,24,17)+ge("m29 14-2 13-13 7 7-13ZM24 4v5m0 30v5M4 24h5m30 0h5"),_l=ge("M24 5q-8 6-17 6v12c0 11 17 20 17 20s17-9 17-20V11q-9 0-17-6Z"),_h=ge("M12 26c-13-3-8-20 4-15 2-11 17-11 19 0 12-4 16 12 2 15v13H12ZM12 33h25"),xh=ge("M13 18q-1-10 11-10t11 10l3 22H10ZM18 9V5h12v4M14 25h20v11H14Zm4-7h12m-20 5-5 4v12h5m28-16 5 4v12h-5"),yh=ge("M4 24q20-22 40 0-20 22-40 0Z")+qe(24,24,7)+qe(24,24,2),Pb=Object.freeze({ACADEMICO:mh+ge("M31 9V4h6v9l-3-2Z"),AGENTE_SAUDE:vh+Ab,ARTISTA:ge("M24 6C3 6 1 34 15 39c8 3 6-6 12-7 8-2 13 7 17-4C49 15 36 6 24 6Z")+qe(14,19,2)+qe(20,13,2)+qe(29,13,2)+qe(36,19,2)+ge("m14 42 15-22 4 3-15 21Z"),ATLETA:ge("M6 31c5-1 8-10 11-20l8 3-1 9 9 4 9 3v9H6ZM7 35h34M21 22l5 4m-9-1 5 4m7-3 4 4"),CHEF:_h+ge("M18 30v-5m7 5v-5m6 5v-5"),CRIMINOSO:ge("M5 17q19-9 38 0l-3 13q-8 4-16-2-8 6-16 2ZM10 21q5-4 10 0-4 8-10 0Zm18 0q5-4 10 0-4 8-10 0ZM20 36h8m-5-4v8"),CULTISTA_ARREPENDIDO:qe(24,24,17)+ge("m24 9 9 27-23-17h28L15 36ZM7 41 41 7M18 5l3 6m17 29-4-5"),DESGARRADO:ge("M8 39h32M24 36V18m0 7L12 13m12 8 9-15M5 12l7-2 4 6m14-9 7-2 2 8M8 42l4-6m22 6-4-6")+qe(24,12,4),ENGENHEIRO:ge("M9 38 29 18c-5-10 4-17 13-13l-8 7 3 6 8-7c4 9-5 17-13 12L14 43Z")+qe(11,38,2)+ge("M6 9h13M12 3v13m-6 8 6-6"),EXECUTIVO:vh+ge("M7 25q17 8 34 0M20 25h8v7h-8ZM30 10l6-5 5 4"),INVESTIGADOR:qe(20,19,12)+ge("m29 28 14 14-4 4-14-14M13 16q4-5 10-4")+qe(18,22,1),LUTADOR:ge("M15 38 8 27q-3-6 2-8l4 5V11q1-5 5-2v13-15q3-4 6 0v15-13q3-4 6 0v15-9q3-3 6 0v13l-7 10v6H15ZM15 34l20-4M16 39h14m-12 3h12"),MAGNATA:ge("m24 5 12 10-12 12-12-12ZM12 15h24M24 5l-5 10 5 12 5-12ZM12 27c-9 20 33 20 24 0M9 34h30"),MERCENARIO:ge("M14 7h19l6 6v24l-6 6H14V7Zm5 0v-4m8 0v4M19 16h12m-12 6h12m-12 6h7M8 35l32-28m-6 0 6 0v6"),MILITAR:ge("m24 5 7 13 14 2-10 10 2 14-13-7-13 7 2-14L3 20l14-2ZM15 25l9-6 9 6m-18 6 9-6 9 6"),OPERARIO:ge("m7 8 10-3 9 9-5 5-9-9-5 3ZM17 17l24 24-5 5-24-24M38 5c-9-3-15 5-11 12L7 37l4 4 21-20c8 3 16-6 12-13l-7 7-4-4Z"),POLICIAL:_l+ge("m24 13 3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1Z"),RELIGIOSO:ge("M18 23h12v19H18Zm6-3c-10-6 5-12 0-19 11 8 7 15 0 19ZM12 43h24M11 14l-6-2m32 2 6-2M14 6l-3-4m23 4 3-4"),SERVIDOR_PUBLICO:ge("m5 16 19-11 19 11ZM8 19h32M10 19v19m9-19v19m10-19v19m9-19v19M6 39h36v5H6Z")+qe(24,11,1),TEORICO_CONSPIRACAO:ge("M6 7h36v34H6ZM11 13l7 5 13-4 6 13-16 8-10-10 7-7m3 17 10-21M11 25l26 2")+qe(18,18,3)+qe(31,14,2)+qe(21,35,2),TI:ge("M8 7h32v26H8ZM4 39h40l-3 4H7ZM14 15l6 5-6 5m10 0h9M18 37h12"),TRABALHADOR_RURAL:ge("M24 43V18M24 28C7 32 4 20 4 20s17-3 20 8Zm0-10C39 21 43 9 43 9S27 6 24 18ZM8 43h32M11 5l-5 7 9 3"),TRAMBIQUEIRO:ge("m5 13 22-7 11 30-22 7ZM19 9l15-3 8 31-5 1M11 19l4-1m7 18 4-1")+ge("m20 18-4 9 9-3Z"),UNIVERSITARIO:ge("m3 17 21-11 21 11-21 11ZM12 22v13q12 9 24 0V22M43 19v19m-3 0h6M18 41h12"),VITIMA:_l+ge("m25 8-8 12 12 7-9 15M17 22l5-5m-1 12 6-6m-8 12 7-5"),AMIGO_ANIMAIS:wb+ge("M7 7c-5-7 7-9 8-3 1-6 13-4 8 3l-8 8Z"),ASTRONAUTA:ge("M9 28V21c0-22 30-22 30 0v7M8 27h32v14H8ZM13 20q11-8 22 0v11H13ZM16 41v4h16v-4M17 15l8-3")+qe(13,36,1)+qe(35,36,1),CHEF_OUTRO_LADO:_h+ge("m24 17 2 5 5 1-4 3 1 5-4-3-4 3 1-5-4-3 5-1ZM8 30c-10-2-7 13-1 10m34-10c9-2 7 13 0 10"),COLEGIAL:xh+ge("m19 28 4 4 7-6M20 17h8"),COSPLAYER:Cb+ge("m8 5 2 5 5 2-5 2-2 5-2-5-5-2 5-2ZM37 5v7m-4-3h8"),DIPLOMATA:ge("M4 22 12 12l9 5 7-3 16 10-9 14-14-3-7-7-5 1ZM18 18l-6 8 6 5 8-9 12 10m-20 3 7-9m-1 11 7-8M4 22l6 5m28-10 5 5"),EXPLORADOR:Ib+ge("m16 35 8-5 9 5M21 10h6"),EXPERIMENTO:ge("M18 4h12m-10 0v14L8 38q-2 6 4 6h24q6 0 4-6L28 18V4M14 30h20M20 14l8 5m-12 5 15 4")+qe(21,35,2)+qe(29,38,1),FANATICO_CRIATURAS:mh+ge("M16 12 11 3l11 8m9 1 6-9-1 10M17 25l4 3m7 0 4-3"),FOTOGRAFO:ge("M5 15h10l4-7h12l4 7h8v26H5ZM8 20h6m22 0h3")+qe(25,28,9)+qe(25,28,5),INVENTOR_PARANORMAL:gh+ge("m24 12 3 7 7 1-6 4 2 7-6-4-6 4 2-7-6-4 7-1Z"),JOVEM_MISTICO:ge("m9 22 7-11 7 11-7 21ZM9 22h14M16 11v32m10-18 6-7 6 7-6 16ZM26 25h12M33 4c-11 3-8 15 2 15-6-5-6-10-2-15Z"),LEGISTA_NOTURNO:ge("M12 23C2 0 46 0 36 23l-5 5v11H17V28ZM17 34h14m-10-6v11m6-11v11M20 18h-6v6h6Zm8 0h6v6h-6ZM22 27l2-5 2 5M7 42h34"),MATEIRO:ge("M11 32C5 12 25 7 39 6 39 27 30 38 11 32ZM10 39 33 13M17 31v-9m7 3 9-2m-10-4v-7M5 43h8m13-3 6-4m7 6h5"),MERGULHADOR:ge("M4 20h40v14H31l-7-5-7 5H4ZM8 24h10v6H8Zm22 0h10v6H30ZM41 18V6h-7v9m10-9v22M17 40q7 5 14 0")+qe(10,11,2),MOTORISTA:qe(24,24,19)+qe(24,24,14)+qe(24,24,4)+ge("M6 19l15 4m6 0 15-4M24 28v14M11 16q13-7 26 0"),NERD_ENTUSIASTA:ge("M4 18h17v11H6Zm23 0h17l-2 11H27ZM21 22h6M4 18l3-6m37 6-3-6M12 38l12-5 12 5-12 7Z")+qe(24,39,1),PSICOLOGO:ge("M17 42v-9c-10-7-9-24 3-27 16-5 23 9 19 17l5 6h-7v8H27v5M19 14c-7-5-12 4-6 8m6-8c8-8 16 2 9 7m-8-7v13m-5-7c-5 5 2 11 5 7m0-6c8-5 14 5 6 8"),REPORTER_INVESTIGATIVO:ge("M7 8h24v34H7ZM12 14h13m-13 6h10m-10 6h13m-13 6h8M37 6c-8 0-8 13 0 13s8-13 0-13ZM37 19v15m-7-17v5q7 9 14 0v-5m-12 17h10"),ACALENTADOR:Rb+ge("M4 31l8 7 12 5 12-5 8-7M5 31l5-6 10 9m23-3-5-6-10 9"),ALFAIATE:qe(12,34,6)+qe(34,34,6)+ge("m16 30 19-25 2 4-14 20L13 5l-2 4 20 21M23 25l-3 5")+qe(23,25,1),APOSTADOR:ge("m7 14 22-7 11 28-22 7ZM8 14l14 8 18-1M22 22l-4 20m4-20 7-15")+qe(15,21,1)+qe(22,34,1)+qe(32,28,1)+qe(34,33,1),ATIRADOR_EXIMIO:qe(24,24,14)+qe(24,24,7)+ge("M24 2v15m0 14v15M2 24h15m14 0h15M9 5l5 5m20 28 5 5"),BOMBADO:ge("M8 36c3-6 8-6 13-5l-3-8-8-3 2-8 9-5 7 5-2 6-6-1 9 13c10-5 17 2 13 9-8 8-28 6-34-3ZM19 12l7 2m3 16-7 3M10 40l3-6"),BOTICARIO:ge("M8 26h32q-1 15-16 15T8 26ZM16 41h16v4H16ZM25 25l9-19 6 3-9 16M10 17C6 6 16 5 21 4c2 9-2 16-11 13Zm1-1 6-6"),COLECIONADOR:ge("M5 7h38v36H5ZM5 27h38M11 11h8v12h-8ZM26 10h6v4l4 3v6H22v-6l4-3ZM12 32h8v8h-8Zm16 0h9v8h-9Z"),CRIANCA_AMALDICOADA:qe(13,11,5)+qe(35,11,5)+ph(24,20,13,12)+ph(24,37,11,8)+ge("M18 18l5 5m0-5-5 5M29 19h3M21 27h6M9 33l7 4m16 0 7-4M24 32v11"),DESOCUPADO:ge("M11 23V12q13-8 26 0v11M6 24q5-6 10 0v10h16V24q5-6 10 0v18H6ZM12 42v3m24-3v3M17 18h14M2 10h5m-3-5 3 2"),HERDEIRO:ge("m9 9 8 7 7-13 7 13 8-7-4 17H13ZM15 21h18M24 30v15m0-5h8m-8 5h5")+qe(24,31,5),INVENTOR:gh+ge("M20 17h8v9h-8ZM24 13v4m0 9v5m-8-10h4m8 0h5"),LINHA_FRENTE:_l+ge("M9 20h30M8 28h32M17 13v7m14-7v7M24 20v8m-8 0v8m16-8v8"),MOCHILEIRO_ORIGEM:xh+ge("m16 33 7-11 9 11ZM7 8l-3-4m35 4 5-4"),PLAYER:ge("M12 14h24c8 1 13 25 6 26-5 1-8-8-13-8H19c-5 0-8 9-13 8-7-1-2-25 6-26ZM16 18v12m-6-6h12M24 14V7h8")+qe(33,21,2)+qe(38,27,2),PROFETA:yh+ge("M24 2v5m-13 0 3 5m23-5-3 5M24 41v5m-13-5 3-5m23 5-3-5"),REVOLUCIONARIO:ge("M10 45V4m0 2c10-8 19 10 30 2v20c-11 8-20-10-30-2M18 13l5 5 9-5M5 45h10"),VETERINARIO:qe(24,29,6)+ge("M24 35v3c0 10 18 10 18-3V19M7 5v11c0 14 19 14 19 0V5M4 5h7m12 0h7")+qe(41,15,4)+ge("M22 29h4m-2-2v4"),BODYBUILDER:ge("M17 24h14M7 13h5v22H7ZM12 9h6v30h-6ZM30 9h6v30h-6Zm6 4h5v22h-5M5 24H2m39 0h5M15 43l9 3 9-3M20 3h8"),BLASTER:ge("M8 16h10v26H8Zm11 0h10v26H19Zm11 0h10v26H30ZM8 25h32m-32 9h32M24 16V9q0-8 10-6m0 0 3 5m-3-5 5-1m-5 1-2-3"),PERSONAL_TRAINER:qe(24,26,16)+ge("M19 4h10v6H19ZM24 14v12l8 5M9 10l4 4m22 0 4-4M8 42l-4 3m36-3 4 3"),EXORCIZADO:ge("M16 8C-1 18 7 42 23 42m9-3C48 29 40 8 28 7M22 4l-3 9 7-2-4 9M20 26h8v14h-8ZM24 23c-6-5 4-8 0-13 8 7 5 10 0 13Z"),SENSITIVO_REBELDE:yh+ge("m27 2-9 16 10-2-8 13 9-2-7 18M7 8l5 4m24 24 5 4")});function Da(i){const e=Pb[i];if(!e)throw new Error("Missing origin pictogram: "+i);return`<svg class="origin-icon" data-origin-icon="${i}" viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${e}</svg>`}const fn=Object.freeze([{code:"COMBATENTE",label:"Combatente",atlas:0,theme:"Confronto e proteção",summary:"Treinamento para enfrentar ameaças de forma direta.",strengths:["Mais Pontos de Vida na base.","Treinamento voltado a armas e confronto."],limits:["Menos escolhas livres de perícias na base.","Menos Esforço e Sanidade na base."],example:"Você era segurança e passou a treinar para enfrentar as ameaças que antes tentava conter.",base:{pv:20,pe:2,san:12,freeSkills:1}},{code:"ESPECIALISTA",label:"Especialista",atlas:1,theme:"Perícias e soluções",summary:"Versatilidade para investigar e resolver problemas com técnica.",strengths:["Mais perícias livres na base.","Versatilidade em tarefas especializadas."],limits:["Base de Vida abaixo do Combatente.","Base de Esforço abaixo do Ocultista."],example:"Você era técnico de manutenção e usava seu conhecimento para investigar casos estranhos.",base:{pv:16,pe:3,san:16,freeSkills:7}},{code:"OCULTISTA",label:"Ocultista",atlas:2,theme:"Rituais e paranormal",summary:"Estudo e uso do paranormal por meio de rituais.",strengths:["Mais Esforço e Sanidade na base.","Acesso a rituais pela classe."],limits:["Menor base de Pontos de Vida.","Rituais exigem gerenciar custos e condições."],example:"Você era pesquisador e começou a estudar rituais ao encontrar registros do Outro Lado.",base:{pv:12,pe:4,san:20,freeSkills:3}}].map(i=>Object.freeze({...i,base:Object.freeze(i.base),strengths:Object.freeze(i.strengths),limits:Object.freeze(i.limits)})));function Qc(i){return fn.find(e=>e.code===i)??null}function Sh(i){return(i%fn.length+fn.length)%fn.length}function bh(i,e,t){const n=(i*120-e)*Math.PI/180,s=(Math.cos(n)+1)/2;return{x:Math.sin(n)*t,y:-30*(1-s),scale:.62+.38*s,z:Math.round(s*100)}}function Lb(i,e){const t=Qc(e);return!t||!i?.origin?.code||typeof i.name!="string"||!i.name.trim()?null:{...i,step:"class",classCode:t.code}}function Sc(i,e){let t=null,n=-1/0;const s=l=>{l.isPrimary&&(l.pointerType==="touch"||l.pointerType==="pen")&&!i.disabled&&(t={id:l.pointerId,x:l.clientX,y:l.clientY})},r=l=>{t&&l.pointerId===t.id&&Math.hypot(l.clientX-t.x,l.clientY-t.y)>10&&(t=null)},a=()=>{t=null},o=l=>{const u=t;t=null,!(!u||l.pointerId!==u.id||i.disabled||Math.hypot(l.clientX-u.x,l.clientY-u.y)>10)&&i.contains(document.elementFromPoint(l.clientX,l.clientY))&&(n=performance.now(),e(l))},c=l=>{if(l.detail>0&&l.pointerType!=="mouse"&&performance.now()-n<700){l.preventDefault();return}e(l)};return i.addEventListener("pointerdown",s),i.addEventListener("pointermove",r),i.addEventListener("pointerup",o),i.addEventListener("pointercancel",a),i.addEventListener("click",c),()=>{i.removeEventListener("pointerdown",s),i.removeEventListener("pointermove",r),i.removeEventListener("pointerup",o),i.removeEventListener("pointercancel",a),i.removeEventListener("click",c)}}const Db="/assets/workshop/classes-v18.png";let xl=null;function Df(){if(!xl){const i=new Image;i.src=Db,xl=i.decode().then(()=>!0).catch(()=>!1)}return xl}const Mh=i=>({transform:`translate(-50%,-50%) translate(${i.x}px,${i.y}px) scale(${i.scale})`,zIndex:i.z});function Nb(i,{name:e,originLabel:t,classCode:n=null,reducedMotion:s=!1,onConfirm:r=()=>!1,onBack:a=()=>{}}){const o={index:Math.max(0,fn.findIndex(M=>M.code===n)),rotation:0,busy:!1,confirmed:Qc(n)?.code??null};o.rotation=o.index*120;let c=!1,l=[],u=null,d=0;i.innerHTML=`<div class="paper-chapter"><span>03 / CLASSE</span></div><h1 id="classPaperTitle" tabindex="-1">Escolha sua classe.</h1><p class="paper-intro">Gire ou use as setas. Confirme a classe que você quer.</p>
  <p class="class-context"><strong class="class-arauto"></strong><span aria-hidden="true"> · </span><span class="class-origin"></span></p>
  <div class="class-layout"><section class="class-picker" aria-label="Roleta de classes" aria-roledescription="carrossel"><div class="class-orbit" tabindex="0" aria-label="Use as setas esquerda e direita para explorar as classes"><div class="roulette-ink-ring" aria-hidden="true"></div>${fn.map(M=>`<button type="button" class="roulette-option" data-class-index="${M.atlas}" aria-label="Ver classe ${M.label}" aria-pressed="false"><span class="class-silhouette class-silhouette-${M.atlas}" aria-hidden="true"></span><span class="roulette-label">${M.label}</span></button>`).join("")}<p class="class-art-loading" role="status">Preparando as silhuetas…</p></div>
   <div class="class-rotation-controls"><button type="button" class="class-previous ink-link" aria-label="Classe anterior">←</button><button type="button" class="class-spin ink-primary">Girar roleta <span aria-hidden="true">↻</span></button><button type="button" class="class-next ink-link" aria-label="Próxima classe">→</button></div>
   <nav class="class-pages" aria-label="Escolher classe em destaque">${fn.map(M=>`<button type="button" data-class-page="${M.atlas}" aria-pressed="false">${M.label}</button>`).join("")}</nav><p class="class-position" aria-live="off"></p>
  </section><section class="class-reading" aria-labelledby="className"><span class="class-theme"></span><h2 id="className"></h2><p class="class-summary"></p><div class="class-tradeoffs"><section><h3>Pontos fortes</h3><ul class="class-strengths"></ul></section><section><h3>Limitações</h3><ul class="class-limits"></ul></section></div><section class="origin-example class-example" aria-label="Exemplo de personagem"><span>Por exemplo…</span><p></p></section>
   <details class="class-comparison"><summary>Comparar as três classes</summary><p>Valores-base da classe. Atributos, origem e outras escolhas alteram o total.</p><div class="class-table-scroll"><table><caption>Bases de recursos e escolhas livres de perícias</caption><thead><tr><th scope="col">Base</th>${fn.map(M=>`<th scope="col">${M.label}</th>`).join("")}</tr></thead><tbody>${[["PV","pv"],["PE","pe"],["SAN","san"],["Perícias livres","freeSkills"]].map(([M,C])=>`<tr><th scope="row">${M}</th>${fn.map(b=>`<td>${b.base[C]}${C==="freeSkills"?" + INT":""}</td>`).join("")}</tr>`).join("")}</tbody></table></div><dl class="class-resource-key"><div><dt>PV</dt><dd>Pontos de Vida</dd></div><div><dt>PE</dt><dd>Pontos de Esforço</dd></div><div><dt>SAN</dt><dd>Sanidade</dd></div></dl><small>Perícias livres não incluem os treinamentos fixos de classe e origem.</small></details>
   <button type="button" class="confirm-class ink-primary">Escolher esta classe <span aria-hidden="true">→</span></button><p class="class-status" role="status" aria-live="polite"></p>
  </section></div><footer class="paper-footer class-footer"><button type="button" class="back-to-origins ink-link">← Rever origem</button><span class="paper-page">ÓRION / 03</span></footer>`;const h=M=>i.querySelector(M),p=h(".class-orbit"),g=[...i.querySelectorAll("[data-class-index]")],v=[...i.querySelectorAll("[data-class-page]")],m=[],f=(M,C)=>m.push(Sc(M,C));h(".class-arauto").textContent=e,h(".class-origin").textContent=t;function _(){return Math.min(210,p.clientWidth*.36)}function x(M){g.forEach((C,b)=>Object.assign(C.style,Mh(bh(b,M,_()))))}function y(){const M=fn[o.index];h(".class-theme").textContent=M.theme,h("#className").textContent=M.label,h(".class-summary").textContent=M.summary;for(const[b,S]of[[".class-strengths",M.strengths],[".class-limits",M.limits]])h(b).replaceChildren(...S.map(D=>{const w=document.createElement("li");return w.textContent=D,w}));h(".class-example p").textContent=M.example,h(".class-position").textContent=`${o.index+1} / 3 · ${M.label}`,g.forEach((b,S)=>{b.setAttribute("aria-pressed",String(S===o.index)),b.classList.toggle("is-front",S===o.index)}),v.forEach((b,S)=>{b.setAttribute("aria-pressed",String(S===o.index)),b.disabled=o.busy});for(const b of[".class-previous",".class-next",".class-spin"])h(b).disabled=o.busy;const C=h(".confirm-class");C.disabled=o.busy||o.confirmed===M.code,C.firstChild.textContent=o.confirmed===M.code?"✓ Classe escolhida ":"Escolher esta classe ",i.setAttribute("aria-busy",String(o.busy))}async function A(M,C=!1){if(c||o.busy||!M)return;const b=o.rotation,S=b+M*120;if(o.busy=!0,y(),h(".class-status").textContent=C?"Girando a roleta…":"Mudando a classe em destaque…",!s){const I=C?72:18,D=_();l=g.map((w,U)=>w.animate(Array.from({length:I+1},(O,F)=>{const V=F/I,k=1-(1-V)**3;return{offset:V,...Mh(bh(U,b+(S-b)*k,D))}}),{duration:C?1550:460,easing:"linear",fill:"forwards"})),await Promise.all(l.map(w=>w.finished.catch(()=>{})))}if(!c){o.rotation=S,o.index=Sh(Math.round(S/120)),x(S);for(const I of l)I.cancel();l=[],o.busy=!1,y(),h(".class-status").textContent=`${fn[o.index].label} em destaque. Confirme se quiser escolher.`}}f(h(".class-previous"),()=>A(-1)),f(h(".class-next"),()=>A(1)),f(h(".class-spin"),()=>A(6+Math.floor(Math.random()*3),!0));for(const M of[...g,...v])f(M,C=>{if(C.type==="click"&&C.detail>0&&C.pointerType!=="mouse"&&performance.now()<d)return;const b=Number(M.dataset.classIndex??M.dataset.classPage),S=Sh(b-o.index);A(S===2?-1:S)});p.addEventListener("keydown",M=>{(M.key==="ArrowLeft"||M.key==="ArrowRight")&&(M.preventDefault(),A(M.key==="ArrowLeft"?-1:1))}),p.addEventListener("pointerdown",M=>{M.isPrimary&&(M.pointerType==="touch"||M.pointerType==="pen")&&(u={x:M.clientX,y:M.clientY})}),p.addEventListener("pointerup",M=>{if(!u)return;const C=M.clientX-u.x,b=M.clientY-u.y;u=null,Math.abs(C)>45&&Math.abs(C)>Math.abs(b)*1.3&&(d=performance.now()+400,A(C<0?1:-1))}),p.addEventListener("pointercancel",()=>{u=null}),f(h(".confirm-class"),()=>{if(o.busy||o.confirmed===fn[o.index].code)return;const M=fn[o.index];r(M.code)?(o.confirmed=M.code,y(),h(".class-status").textContent=`${M.label} é a classe de ${e}. Você pode revisar sua escolha.`):h(".class-status").textContent="Não foi possível guardar esta classe. Tente novamente."}),f(h(".back-to-origins"),a);const E=new ResizeObserver(()=>{o.busy||x(o.rotation)});return E.observe(p),y(),x(o.rotation),Df().then(M=>{c||(i.dataset.classArt=M?"ready":"error",h(".class-art-loading").textContent=M?"":"As silhuetas não carregaram. As descrições continuam disponíveis.",h(".class-art-loading").hidden=M)}),{get state(){return{...o}},dispose(){c=!0,E.disconnect();for(const M of m)M();for(const M of l)M.cancel();i.replaceChildren()}}}const Ob="/assets/workshop/walnut-v15.png",bn=i=>String(i??"").replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e]),Ub=i=>i.fixedSkills.map(Ja).join(" · "),Fb={investigar:"INVESTIGADOR",cuidar:"AGENTE_SAUDE",criar:"INVENTOR",convencer:"DIPLOMATA",sobreviver:"EXPLORADOR",agir:"LUTADOR",paranormal:"JOVEM_MISTICO",discricao:"CRIMINOSO"};let Ms=null,yl=null;function Nf(){if(!yl){const i=new Image;i.src=Ob,yl=i.decode().catch(()=>{})}return yl}function Bb(i,{onReturn:e=()=>{},onChoose:t=()=>{},reducedMotion:n=!1}={}){if(Ms)return Ms;const s=document.activeElement,r=document.createElement("section"),a={query:"",interest:"",source:"",skill:"",selected:null,compared:[],confirmed:null};let o=Qc(i.classCode)?.code??null,c=null;r.className="paper-workshop",r.setAttribute("aria-label","Ficha de criação: origem"),r.dataset.phase="preparing",r.innerHTML=`<div class="workshop-mist" aria-hidden="true"></div><p class="paper-preparing" role="status">Materializando sua história…</p>
  <div class="workshop-planks" aria-hidden="true">${Array.from({length:6},(w,U)=>`<div class="workshop-plank" style="--plank:${U};--grain:${U*19}%"></div>`).join("")}</div>
  <div class="paper-scroll"><div class="paper-landing"><article class="physical-sheet" aria-labelledby="paperTitle" aria-busy="true">
   <div class="paper-content" inert>
    <header class="paper-header"><div class="paper-imprint"><span>ÓRION</span><small>Ficha do arauto · prévia</small></div><button class="paper-return ink-link" type="button">← Voltar à identidade</button></header>
    <section class="origin-chapter-content">
    <div class="paper-chapter"><span>02 / ORIGEM</span></div>
    <h1 id="paperTitle" tabindex="-1">Toda história deixa marcas.</h1>
    <p class="paper-intro">Escolha o passado do seu arauto.</p>
    <div class="paper-identity"><div><span>Nome do arauto</span><strong class="paper-name"></strong></div><div><span>Origem</span><strong class="paper-chosen-name">Ainda por escrever</strong></div></div>
    <nav class="discovery-modes" aria-label="Como explorar as origens"><button type="button" data-mode="explore" aria-pressed="true">Explorar origens</button><button type="button" data-mode="guide" aria-pressed="false">Me ajude a escolher</button></nav>
    <section class="origin-guide" aria-label="Ajuda para escolher uma origem" hidden><h2>Que passado você imagina?</h2><p>Comece por uma ideia.</p><div>${Sr.map(w=>`<button type="button" data-guide="${w.id}" aria-label="${w.prompt}" aria-pressed="false">${Da(Fb[w.id])}<strong>${w.label}</strong><span class="guide-check" aria-hidden="true">✓</span></button>`).join("")}</div></section>
    <section class="origin-tools" aria-label="Buscar e filtrar origens">
     <div class="paper-search"><label for="originSearch">Encontre uma história</label><div><span aria-hidden="true">⌕</span><input id="originSearch" type="search" placeholder="Nome, profissão ou perícia…" autocomplete="off" aria-controls="originResults"><button class="clear-search ink-link" type="button" aria-label="Limpar busca" hidden>×</button></div></div>
     <div class="interest-filters" role="group" aria-label="Filtrar por interesse"><button type="button" data-interest="" aria-pressed="true">Todas</button>${Sr.map(w=>`<button type="button" data-interest="${w.id}" aria-pressed="false">${w.label}</button>`).join("")}</div>
     <details class="advanced-origins"><summary>Filtrar por livro e perícia</summary><div><label>Livro de origem<select id="originSource"><option value="">Todos os livros</option>${[...new Set(Mi.map(w=>w.source))].map(w=>`<option>${w}</option>`).join("")}</select></label><label>Perícia associada<select id="originSkill"><option value="">Todas as perícias</option>${Pf.map(w=>`<option value="${w.code}">${w.label}</option>`).join("")}</select></label></div></details>
    </section>
    <section class="origin-filter-feedback" id="originFilters" aria-label="Filtros aplicados" hidden><span class="filter-seal" aria-hidden="true">✓</span><div><small>Filtro aplicado</small><strong class="filter-applied-label"></strong><p class="filter-result-count"></p></div><div class="filter-feedback-actions"><button type="button" class="change-interest ink-link">Trocar interesse</button><button type="button" class="reset-filters ink-link">Limpar filtros</button></div></section>
    <div class="origin-library"><section class="origin-index" aria-labelledby="originCount"><div class="index-heading"><h2 id="originCount" tabindex="-1"></h2></div><ol id="originResults"></ol><p class="origin-empty" hidden>Nenhuma origem com esses filtros. Tente outra palavra ou limpe os filtros.</p></section>
     <section class="origin-detail" id="originDetail" aria-labelledby="originDetailTitle"><div class="detail-placeholder"><span class="ink-star" aria-hidden="true">✧</span><h2 id="originDetailTitle">Seu passado começa aqui.</h2><small>Abra uma origem para ver um exemplo.</small></div></section></div>
    <footer class="paper-footer"><div><button class="open-comparison ink-link" type="button" disabled>Comparar origens (0/2)</button><p class="paper-status" role="status" aria-live="polite">Abra uma origem para começar.</p><button type="button" class="origin-next ink-primary" hidden>Continuar para classe <span aria-hidden="true">→</span></button><small class="origin-next-hint" hidden>Confirme a origem aberta para continuar.</small></div><span class="paper-page">ÓRION / 02</span></footer>
    </section><section class="class-chapter" aria-label="Escolha da classe" hidden></section>
   </div>
  </article></div></div>
  <dialog class="origin-comparison" aria-labelledby="compareTitle"><header><div><small>Duas possibilidades para sua história</small><h2 id="compareTitle">Lado a lado</h2></div><button type="button" class="close-comparison ink-link" aria-label="Fechar comparação">×</button></header><div class="comparison-content"></div></dialog>`,document.body.append(r),document.documentElement.dataset.paperActive="1",r.querySelector(".paper-name").textContent=i.name;const l=w=>r.querySelector(w),u=l(".paper-status"),d=l("#originResults"),h=l("#originDetail"),p=l(".paper-content"),g=l(".physical-sheet"),v=l("dialog"),m=h.innerHTML;let f=!1;function _(w){u.textContent=w}function x(){const w=l(".origin-next"),U=!!(a.selected&&a.selected!==a.confirmed);w.hidden=!a.confirmed,w.disabled=U,l(".origin-next-hint").hidden=!a.confirmed||!U,w.firstChild.textContent=o?"Rever classe ":"Continuar para classe "}function y(){c?.dispose(),c=null,l(".class-chapter").hidden=!0,l(".origin-chapter-content").hidden=!1,r.dataset.chapter="origin",r.setAttribute("aria-label","Ficha de criação: origem"),g.setAttribute("aria-labelledby","paperTitle"),l(".paper-return").textContent="← Voltar à identidade",x(),l(".origin-next").focus()}function A(){if(!a.confirmed||l(".origin-next").disabled)return;const w=Mi.find(U=>U.code===a.confirmed);l(".origin-chapter-content").hidden=!0,l(".class-chapter").hidden=!1,r.dataset.chapter="class",r.setAttribute("aria-label","Ficha de criação: classe"),g.setAttribute("aria-labelledby","classPaperTitle"),l(".paper-return").textContent="← Voltar às origens",c=Nb(l(".class-chapter"),{name:i.name,originLabel:w.label,classCode:o,reducedMotion:n,onBack:y,onConfirm(U){const O=Lb({...i,origin:{code:w.code,label:w.label,source:w.source}},U);if(!O)return!1;try{return sessionStorage.setItem(_c,JSON.stringify(O)),o=U,t(O),r.dispatchEvent(new CustomEvent("orion:class-chosen",{detail:O,bubbles:!0})),x(),!0}catch{return!1}}}),l(".paper-scroll").scrollTop=0,l("#classPaperTitle").focus({preventScroll:!0})}function E(){const w=l(".open-comparison");w.textContent=`Comparar origens (${a.compared.length}/2)`,w.disabled=a.compared.length!==2}function M(){for(const w of d.querySelectorAll("[data-origin]"))w.setAttribute("aria-pressed",String(w.dataset.origin===a.selected)),w.querySelector(".origin-row-arrow").textContent=w.dataset.origin===a.selected?"✓":"→"}function C(){const w=fh(a);l("#originCount").textContent=`${w.length} ${w.length===1?"origem":"origens"}`,d.innerHTML=w.map(O=>`<li><button type="button" data-origin="${O.code}" aria-pressed="${O.code===a.selected}" aria-controls="originDetail"><span class="origin-row-symbol">${Da(O.code)}</span><strong>${bn(O.label)}</strong><span class="origin-row-arrow" aria-hidden="true">${O.code===a.selected?"✓":"→"}</span></button></li>`).join(""),l(".origin-empty").hidden=w.length>0,l(".reset-filters").hidden=!(a.query||a.interest||a.source||a.skill),l(".clear-search").hidden=!a.query;for(const O of r.querySelectorAll("[data-interest]"))O.setAttribute("aria-pressed",String(O.dataset.interest===a.interest));for(const O of r.querySelectorAll("[data-guide]"))O.setAttribute("aria-pressed",String(O.dataset.guide===a.interest));const U=[Sr.find(O=>O.id===a.interest)?.label,a.query?`Busca: ${a.query}`:"",a.source,a.skill?Ja(a.skill):""].filter(Boolean);l("#originFilters").hidden=!U.length,l(".filter-applied-label").textContent=U.join(" · "),l(".filter-result-count").textContent=`${w.length} ${w.length===1?"origem para explorar":"origens para explorar"}`,l(".change-interest").hidden=!a.interest,_(`${w.length} ${w.length===1?"origem encontrada":"origens encontradas"}.${a.selected?" A origem aberta continua disponível para revisão.":""}`)}function b(){x();const w=Mi.find(U=>U.code===a.selected);if(!w){h.innerHTML=m;return}h.innerHTML=`<div class="detail-overline"><button class="back-to-index ink-link" type="button">↑ Voltar à lista</button></div><div class="origin-heading"><div class="origin-portrait">${Da(w.code)}</div><h2 id="originDetailTitle" tabindex="-1">${bn(w.label)}</h2></div><section class="origin-example" aria-label="Exemplo de passado"><span>Por exemplo…</span><p>${bn(yc(w))}</p></section><dl class="origin-facts"><div><dt>Perícias</dt><dd><ul class="origin-skill-chips">${w.fixedSkills.map(U=>`<li>${bn(Ja(U))}</li>`).join("")}${w.variableSkillCount?`<li>+${w.variableSkillCount} à escolha</li>`:""}</ul></dd></div><div><dt>Habilidade</dt><dd>${bn(w.powerName)}</dd></div></dl>${w.professionRequired?'<p class="origin-choice-note">Exige uma especialidade de Profissão.</p>':""}<details class="origin-more"><summary>Ver contexto e fonte</summary><p class="origin-story">${bn(Lf(w))}</p><p class="origin-book">${bn(w.source)}</p><small>O exemplo é só uma inspiração para sua história.</small></details><div class="origin-detail-actions"><button type="button" class="choose-origin ink-primary" ${a.confirmed===w.code?"disabled":""}>${a.confirmed===w.code?"✓ Origem escolhida":"Escolher esta origem"}<span aria-hidden="true">→</span></button><button type="button" class="compare-origin ink-link" aria-pressed="${a.compared.includes(w.code)}">${a.compared.includes(w.code)?"− Retirar da comparação":"+ Comparar esta origem"}</button></div>`,l(".choose-origin").addEventListener("click",()=>{const U={...i,step:"origin",origin:{code:w.code,label:w.label,source:w.source},...o?{classCode:o}:{}};try{sessionStorage.setItem(_c,JSON.stringify(U)),a.confirmed=w.code,l(".paper-chosen-name").textContent=w.label,b(),Df(),_(`${w.label} é a origem de ${i.name}. Continue para escolher a classe.`),t(U),r.dispatchEvent(new CustomEvent("orion:origin-chosen",{detail:U,bubbles:!0}))}catch{_("Não foi possível guardar esta escolha. Você pode continuar explorando e tentar novamente.")}}),l(".compare-origin").addEventListener("click",()=>{if(a.compared.includes(w.code))a.compared=a.compared.filter(U=>U!==w.code);else if(a.compared.length<2)a.compared.push(w.code);else{_("Há duas origens na comparação. Retire uma delas para adicionar outra.");return}E(),b(),l(".compare-origin").focus({preventScroll:!0}),_(a.compared.length===2?"Duas origens separadas. Abra a comparação no fim da folha.":`${a.compared.length} origem na comparação.`)}),l(".back-to-index").addEventListener("click",()=>{d.querySelector(`[data-origin="${w.code}"]`)?.focus()})}d.addEventListener("click",w=>{const U=w.target.closest("[data-origin]");U&&(a.selected=U.dataset.origin,M(),b(),_(`${Mi.find(O=>O.code===a.selected).label} aberta. Confira os detalhes antes de escolher.`),matchMedia("(max-width: 760px)").matches&&(l("#originDetailTitle").focus({preventScroll:!0}),h.scrollIntoView({behavior:n?"instant":"smooth",block:"start"})))}),l("#originSearch").addEventListener("input",w=>{a.query=w.target.value,C()}),l(".clear-search").addEventListener("click",()=>{a.query="",l("#originSearch").value="",C(),l("#originSearch").focus()});function S(w){a.interest=w,C()}function I(w){for(const U of r.querySelectorAll("[data-mode]"))U.setAttribute("aria-pressed",String(U.dataset.mode==="guide"===w));l(".origin-guide").hidden=!w,l(".origin-tools").hidden=w,l(".origin-library").hidden=w,l("#originFilters").hidden=w||!(a.query||a.interest||a.source||a.skill)}function D(){(l("#originFilters").hidden?l(".origin-library"):l("#originFilters")).scrollIntoView({behavior:n?"instant":"smooth",block:"start"}),l("#originCount").focus({preventScroll:!0})}for(const w of r.querySelectorAll("[data-interest]"))w.addEventListener("click",()=>S(w.dataset.interest));for(const w of r.querySelectorAll("[data-guide]"))w.addEventListener("click",()=>{Object.assign(a,{query:"",source:"",skill:"",selected:null}),l("#originSearch").value="",l("#originSource").value="",l("#originSkill").value="",S(w.dataset.guide),b(),I(!1),D(),_(`${Sr.find(U=>U.id===a.interest).label}: filtro aplicado. ${fh(a).length} origens para explorar.`)});for(const w of r.querySelectorAll("[data-mode]"))w.addEventListener("click",()=>I(w.dataset.mode==="guide"));return l(".change-interest").addEventListener("click",()=>{I(!0),l(".origin-guide").scrollIntoView({behavior:n?"instant":"smooth",block:"start"}),r.querySelector(`[data-guide="${a.interest}"]`)?.focus({preventScroll:!0})}),l("#originSource").addEventListener("change",w=>{a.source=w.target.value,C()}),l("#originSkill").addEventListener("change",w=>{a.skill=w.target.value,C()}),l(".reset-filters").addEventListener("click",()=>{Object.assign(a,{query:"",interest:"",source:"",skill:""}),l("#originSearch").value="",l("#originSource").value="",l("#originSkill").value="",C(),D()}),l(".open-comparison").addEventListener("click",()=>{l(".comparison-content").innerHTML=a.compared.map(w=>{const U=Mi.find(O=>O.code===w);return`<section><div class="comparison-origin-heading">${Da(U.code)}<h3>${bn(U.label)}</h3></div><p class="comparison-background">${bn(yc(U))}</p><dl><dt>Perícias</dt><dd>${bn(Ub(U))}</dd><dt>Habilidade</dt><dd>${bn(U.powerName)}</dd><dt>Livro</dt><dd>${bn(U.source)}</dd></dl><button type="button" class="ink-link" data-remove-compare="${U.code}">Retirar da comparação</button></section>`}).join(""),v.showModal()}),l(".comparison-content").addEventListener("click",w=>{const U=w.target.closest("[data-remove-compare]");U&&(a.compared=a.compared.filter(O=>O!==U.dataset.removeCompare),E(),b(),v.close(),_("Origem retirada da comparação."))}),l(".close-comparison").addEventListener("click",()=>v.close()),Sc(l(".origin-next"),A),Sc(l(".paper-return"),()=>{if(r.dataset.chapter==="class"){y();return}f=!0,c?.dispose(),r.remove(),delete document.documentElement.dataset.paperActive,delete document.documentElement.dataset.paperReady,Ms=null,e(),s?.focus({preventScroll:!0})}),i.origin&&Mi.some(w=>w.code===i.origin.code)&&(a.selected=a.confirmed=i.origin.code,l(".paper-chosen-name").textContent=Mi.find(w=>w.code===a.selected).label,b()),C(),x(),r.dataset.chapter="origin",Ms=(async()=>{if(await Nf(),f)return;r.dataset.phase="landing",l(".paper-preparing").textContent="";const w=[...r.querySelectorAll(".workshop-plank")];n||await Promise.all(w.map((O,F)=>O.animate([{transform:`translate3d(${F%2?3:-3}%, -115vh, 180px) rotateX(28deg) rotateZ(${F%2?3:-3}deg)`,opacity:.3},{transform:"translate3d(0, 3px, 0) rotateX(0) rotateZ(0)",opacity:1,offset:.86},{transform:"none",opacity:1}],{duration:650,delay:F*95,easing:"cubic-bezier(.24,.66,.32,1)",fill:"both"}).finished)),!(f||(r.dataset.phase="paper",await l(".paper-landing").animate(n?[{opacity:0},{opacity:1}]:[{transform:"translate3d(0,-105vh,120px) rotateX(14deg) rotateZ(-6deg) scale(1.04)",opacity:0},{opacity:1,offset:.13},{transform:"translate3d(0,5px,0) rotateX(0) rotateZ(.35deg)",opacity:1,offset:.87},{transform:"none",opacity:1}],{duration:n?120:860,easing:"cubic-bezier(.22,.68,.30,1)",fill:"both"}).finished,f))&&(r.dataset.phase="ready",p.inert=!1,g.setAttribute("aria-busy","false"),document.documentElement.dataset.paperReady="1",l("#paperTitle").focus({preventScroll:!0}))})().catch(w=>{throw r.remove(),Ms=null,delete document.documentElement.dataset.paperActive,delete document.documentElement.dataset.paperReady,w}),Ms}function kb(i,{hands:e,reducedMotion:t=!1,scene:n,camera:s,environment:r}){let a=ib(),o=null,c={x:0,y:0},l=!1,u=null,d=null;const h=document.createElement("section");h.className="herald-creation",h.setAttribute("aria-label","O nascimento do Marcado"),h.innerHTML=`
 <a class="creation-back" href="index.html?stars=0" aria-label="Voltar ao observatório">←</a>
 <span class="creation-label">O despertar</span>
 <div class="creation-stage">
  <section class="birth-stage" aria-label="O despertar">
   <h1 class="blood-prologue">Tudo começa pelo sangue.</h1>
   <div class="sealed-being"><button class="baby-target" type="button" data-creation-point aria-label="Contemplar a silhueta etérea" aria-controls="markBeing" aria-expanded="false"><span class="sr-only">Acorrentado pela realidade: uma silhueta cercada por sigilos de conhecimento</span><span class="interaction-cue" aria-hidden="true">Clique para despertar</span></button></div>
   <div class="mark-slot"><button class="mark-being" id="markBeing" aria-label="Tornar Marcado" type="button" hidden disabled><span class="mark-sigil" aria-hidden="true">✧</span><span class="mark-title">Tornar Marcado</span><span class="mark-hint">Romper o vínculo</span></button></div>
  </section>
  <form id="identityForm" class="identity-form" hidden>
   <header class="identity-title" hidden><h1>O início de uma história.</h1><p>Escolha uma representação para seu arauto.</p></header>
   <fieldset class="child-choices"><legend class="sr-only">Escolha a silhueta ou não defina gênero</legend>${["menina","menino"].map(D=>`<button type="button" class="child-choice" data-gender="${D}" data-creation-point aria-label="Escolher ${D}" aria-pressed="false"><i class="soul-anchor" aria-hidden="true"></i><span>${D==="menina"?"Menina":"Menino"}<small>Selecionar</small></span></button>`).join("")}</fieldset>
   <div class="identity-controls">
    <div class="identity-fields"><label for="herald-name" class="name-label">Nome do arauto</label><input id="herald-name" name="name" type="text" placeholder="Nomeie seu arauto" maxlength="60" required autocomplete="off" aria-describedby="creationStatus"><label class="undefined-choice"><input type="checkbox" id="undefinedGender">Não definir gênero</label></div>
    <div class="identity-action" hidden><button class="creation-next" type="submit" aria-label="Continuar com esta identidade" hidden disabled><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14m-6-6 6 6-6 6"/></svg></button><span aria-hidden="true">Continuar</span></div>
   </div>
  </form>
 </div>
 <p id="creationStatus" class="creation-status" role="status" aria-live="polite">Tudo começa pelo sangue.</p>`,i.append(h),i.dataset.input==="touch"&&(h.querySelector(".interaction-cue").textContent="Toque para despertar");const p=ep(location.href);p.searchParams.set("stars","0"),h.querySelector(".creation-back").href=p.href;const g=h.querySelector(".baby-target"),v=h.querySelector("#markBeing"),m=h.querySelector(".sealed-being"),f=h.querySelector("form"),_=h.querySelector("#herald-name"),x=h.querySelector("#undefinedGender"),y=h.querySelector(".creation-next"),A=h.querySelector("#creationStatus"),E=Sb({scene:n,camera:s,panel:h,reducedMotion:t,environment:r});g.disabled=!0,E.ready.then(()=>{i.dataset.creationArt="ready",g.disabled=!1,v.disabled=!1,A.textContent="Clique na silhueta para despertar."}).catch(()=>{i.dataset.creationArt="error",A.textContent="Não foi possível carregar a cena. Recarregue a página."}),new URLSearchParams(location.search).has("debug")&&(window.__orionCreationDebug=E);function M(){h.dataset.phase=a.phase,i.dataset.creationPhase=a.phase,h.querySelector(".creation-label").textContent=a.phase==="identity"?"Identidade":"O despertar",h.querySelector(".identity-title").hidden=a.phase!=="identity",h.querySelector(".birth-stage").hidden=a.phase==="identity",h.querySelector(".identity-action").hidden=a.gender===null,h.querySelector(".blood-prologue").setAttribute("aria-hidden",String(a.phase==="identity"));for(const D of h.querySelectorAll("[data-gender]"))D.setAttribute("aria-pressed",String(D.dataset.gender===a.gender)),D.querySelector("small").textContent=D.dataset.gender===a.gender?"✓ Selecionado":"Selecionar";x.checked=a.gender==="nao-definir",y.hidden=a.gender===null,y.disabled=!xc(a)||a.continued}function C(){o=performance.now(),e.setStarHovered?.(!0)}function b(D){if(E.update(D),e.setStarDirection?.(c.x,c.y),o!==null){const w=xf((D-o)/1e3,t);e.setStarSelection?.(w.progress<1?w:null),w.progress>=1&&(o=null)}}function S(D){c={x:(D.clientX/innerWidth-.5)*2,y:(.5-D.clientY/innerHeight)*2},e.setStarHovered?.(!!D.target.closest("[data-creation-point]")),E.point(c),E.hover(D.target.closest(".baby-target")?"baby":D.target.closest("[data-gender]")?.dataset.gender??null)}h.addEventListener("focusin",D=>{e.setStarHovered?.(D.target.matches(":focus-visible")&&!!D.target.closest("[data-creation-point]")),E.hover(D.target===g?"baby":D.target.dataset.gender??null)}),h.addEventListener("focusout",()=>{e.setStarHovered?.(!1),E.hover(null)}),h.addEventListener("pointerleave",()=>E.hover(null)),g.addEventListener("click",()=>{a.phase==="sealed"&&(a=bs(a,{type:"reveal"}),C(),M(),g.setAttribute("aria-expanded","true"),v.hidden=!1,A.textContent="Acorrentado pela realidade.",v.focus({preventScroll:!0}))}),v.addEventListener("click",async()=>{a.phase==="revealed"&&(Nf(),a=bs(a,{type:"mark"}),M(),o=null,e.setStarSelection?.(null),e.setStarHovered?.(!1),v.disabled=!0,g.inert=!0,f.append(A),f.hidden=!1,f.inert=!0,A.textContent="Os sigilos se desfazem. A alma desperta.",await E.release(),a=bs(a,{type:"released"}),M(),m.hidden=!0,v.hidden=!0,f.hidden=!1,f.inert=!1,A.textContent="Dê um nome ao seu arauto e escolha como deseja representá-lo.",h.querySelector(".child-choice").focus({preventScroll:!0}))});function I(D){a=bs(a,{type:"gender",value:D}),E.select(D),(D==="menina"||D==="menino")&&C(),M(),A.textContent=a.name.trim()?"Sua identidade começa a tomar forma.":"Digite um nome para continuar."}for(const D of h.querySelectorAll("[data-gender]"))D.addEventListener("click",()=>I(D.dataset.gender));return x.addEventListener("change",()=>I(x.checked?"nao-definir":null)),_.addEventListener("input",()=>{a=bs(a,{type:"name",value:_.value}),M(),A.textContent=a.gender===null?"Escolha uma silhueta ou não defina gênero.":a.name.trim()?"Sua identidade está pronta para continuar.":"Digite um nome para continuar."}),f.addEventListener("submit",D=>{if(D.preventDefault(),!xc(a)||a.continued){a.name.trim()||(_.setCustomValidity("Dê um nome ao seu arauto."),_.reportValidity(),_.setCustomValidity(""));return}a=bs(a,{type:"continue"}),M();const w={version:1,name:a.name,gender:a.gender,step:"identity",...u?{origin:u}:{},...d?{classCode:d}:{}};try{sessionStorage.setItem(_c,JSON.stringify(w))}catch{l=!0}A.textContent=l?"Seu navegador não permitiu guardar o rascunho. Você ainda pode explorar as origens.":"Preparando sua ficha…",i.dispatchEvent(new CustomEvent("orion:creation-continue",{detail:w,bubbles:!0})),i.inert=!0,Bb(w,{reducedMotion:t,onChoose(U){u=U.origin,d=U.classCode??null},onReturn(){i.inert=!1,a={...a,continued:!1},M(),A.textContent="Revise sua identidade e continue quando quiser."}}).catch(()=>{i.inert=!1,delete document.documentElement.dataset.paperActive,a={...a,continued:!1},M(),A.textContent="Não foi possível abrir a ficha. Tente continuar novamente."})}),M(),{ready:E.ready,point:S,update:b,finishFrame(){const D=new Set;e.root?.traverse(w=>{w.isMesh&&w.material&&!D.has(w.material)&&(D.add(w.material),w.material.opacity*=.56)})},get state(){return{...a}}}}function zb({root:i,isLocked:e,onDismiss:t,onSwipe:n}){const s={dragging:!1,gestures:0};let r=null,a=!1;const o=g=>{const v=g.closest("button,a,input,summary,#heraldCard,.debug");return v&&!v.matches(".herald-target")};function c(g){if(g.pointerType!=="touch"){a=!1;return}if(!e()){if(r){d();return}a=!1,!(!g.isPrimary||o(g.target))&&(r={id:g.pointerId,x:g.clientX,y:g.clientY,star:!!g.target.closest(".herald-target")})}}function l(g){if(!r||g.pointerId!==r.id||e())return;const v=g.clientX-r.x,m=g.clientY-r.y;!s.dragging&&Math.hypot(v,m)<10||s.dragging||(s.dragging=!0,s.gestures++,t(),i.setPointerCapture(g.pointerId))}function u(g){if(!r||g.pointerId!==r.id)return;l(g);const v=g.clientX-r.x,m=g.clientY-r.y,f=Math.max(48,Math.min(80,i.clientWidth*.14));s.dragging&&Math.abs(v)>=f&&Math.abs(v)>Math.abs(m)*1.25&&n(v<0?1:-1),a=s.dragging,!s.dragging&&!r.star&&t();const _=r.id;r=null,s.dragging=!1,i.hasPointerCapture(_)&&i.releasePointerCapture(_)}function d(){if(!r)return;const g=r.id;r=null,s.dragging=!1,a=!0,i.hasPointerCapture(g)&&i.releasePointerCapture(g)}function h(g){g.target===i&&!i.hasPointerCapture(g.pointerId)&&d()}function p(g){!a||g.detail===0||(a=!1,g.preventDefault(),g.stopImmediatePropagation())}return i.addEventListener("pointerdown",c),i.addEventListener("pointermove",l),i.addEventListener("pointerup",u),i.addEventListener("pointercancel",d),i.addEventListener("lostpointercapture",h),i.addEventListener("click",p,!0),window.addEventListener("blur",d),{state:s,cancel:d,dispose(){d(),i.removeEventListener("pointerdown",c),i.removeEventListener("pointermove",l),i.removeEventListener("pointerup",u),i.removeEventListener("pointercancel",d),i.removeEventListener("lostpointercapture",h),i.removeEventListener("click",p,!0),window.removeEventListener("blur",d)}}}function Of(i,e,t=0,n=0){const s=2*Math.tan(52*Math.PI/360)*496,r=s*e,a=e>1,o=a?.5-.22*n:.5,c=a?.34+.12*n:.36-.13*n;return Array.from({length:i},(l,u)=>({x:(u-t)*r*1.12+(o-.5)*r+t*8,y:(.5-c)*s,z:-470,scale:Math.min(1,Math.max(.65,e/.95))}))}function Vb({root:i,heralds:e,reducedMotion:t,isLocked:n,onChange:s}){const r=document.getElementById("starBrowser"),a=document.getElementById("browseName"),o=document.getElementById("browseCount"),c=document.getElementById("starPages"),l=document.getElementById("previousStar"),u=document.getElementById("nextStar"),d=document.getElementById("swipeHint"),h={index:0,position:0,summary:0,settled:!0,changes:0},p=e.map((f,_)=>{const x=document.createElement("button");return x.type="button",x.className="star-page",x.setAttribute("aria-label",`Mostrar ${f.data.name}, ${_+1} de ${e.length}`),x.addEventListener("click",()=>v(_)),c.appendChild(x),x});r.hidden=!1,r.dataset.single=String(e.length===1);function g(){a.textContent=e[h.index].data.name,o.textContent=`${h.index+1} / ${e.length}`,l.disabled=h.index===0,u.disabled=h.index===e.length-1,p.forEach((f,_)=>f.setAttribute("aria-current",String(_===h.index))),d.textContent="Deslize para mudar de estrela"}function v(f){if(n())return!1;const _=Math.max(0,Math.min(e.length-1,f));return _===h.index?!1:(h.index=_,h.changes++,h.settled=t,t&&(h.position=_),i.dataset.browseMoving=String(!h.settled),s(e[_]),g(),!0)}function m(f,_){const x=t?1:1-Math.exp(-Math.max(0,f)*12);h.position+=(h.index-h.position)*x,h.summary+=(Number(_)-h.summary)*x,h.settled=Math.abs(h.index-h.position)<.002,h.settled&&(h.position=h.index);const y=String(!h.settled);i.dataset.browseMoving!==y&&(i.dataset.browseMoving=y);const A=!!_||n();r.inert!==A&&(r.inert=A);for(const[E,M]of e.entries()){const C=E!==h.index,b=C||!h.settled||n();M.target.hidden!==C&&(M.target.hidden=C),M.target.tabIndex!==(C?-1:0)&&(M.target.tabIndex=C?-1:0),M.target.disabled!==b&&(M.target.disabled=b)}}return l.addEventListener("click",()=>v(h.index-1)),u.addEventListener("click",()=>v(h.index+1)),i.addEventListener("keydown",f=>{!["ArrowLeft","ArrowRight"].includes(f.key)||f.target.closest("#heraldCard,input,.debug")||(f.preventDefault(),v(h.index+(f.key==="ArrowRight"?1:-1)))}),g(),m(0,!1),{state:h,choose:v,step:f=>v(h.index+f),update:m}}const Pn=document.getElementById("observatory"),Nt=document.body.dataset.page==="creation";let qs=null;const Hb=document.getElementById("world");let Zi=document.getElementById("heraldTarget");const Wt=document.getElementById("heraldCard"),Pi=document.getElementById("hint"),Sl=document.getElementById("notice"),bc=document.getElementById("loading"),Ys=document.getElementById("arrivalFlash"),js=document.getElementById("debug"),Mc=document.getElementById("depth"),Uf=document.getElementById("depthValue"),at=matchMedia("(prefers-reduced-motion: reduce)").matches,xt=matchMedia("(pointer: coarse)").matches;Pn.dataset.input=xt?"touch":"pointer";const Ff=xt?"Toque na estrela para conhecer":"Concentre seu olhar sobre uma estrela";Pi.textContent=Ff;let mn=Number(new URLSearchParams(location.search).get("depth")||1);Number.isFinite(mn)||(mn=1);mn=_e.clamp(mn,.5,2.5);Mc.value=String(mn);Uf.textContent=mn.toFixed(1).replace(".",",")+"×";const Yn=new URLSearchParams(location.search),ln=Yn.has("debug"),Gb=Yn.get("depthMotion")!=="off",Wb=Yn.get("foreground")!=="off",ai=Yn.get("hands"),Ei=["on","fps","vr","rig","3d","2d"].includes(ai)||["overlay","mesh"].includes(ai)||ai!=="off",Ai=ai==="2d"?"2d":ai==="3d"?"3d":ai==="rig"?"rig":ai==="vr"?"vr":ai==="fps"?"fps":ai==="overlay"?"overlay":"mesh",Eh=document.getElementById("fpsHandsCredit");Eh&&(Eh.hidden=!Ei||Ai!=="fps");js.hidden=!ln;const Xb=xt||navigator.deviceMemory!==void 0&&navigator.deviceMemory<=4||navigator.hardwareConcurrency!==void 0&&navigator.hardwareConcurrency<=4,Yi=Yn.get("quality"),Bf=["eco","eco-plus","lite","low","balanced","high"].includes(Yi),Qa=["no-bloom","no-gas"].includes(Yn.get("effects"))?Yn.get("effects"):"normal",qb=Yi==="eco"?"eco":Yi==="eco-plus"?"eco-plus":Yi==="lite"||Yi==="low"?"lite":Yi==="high"?"high":Yi==="balanced"?"balanced":Xb?"lite":"balanced",Th=["eco","eco-plus","lite","balanced","high"];let Xn=qb,eu=0;const Yb={eco:{dpr:.53,maxPixels:5e5,bloomScale:.2,gas:[],fpsCap:60},"eco-plus":{dpr:.6,maxPixels:67e4,bloomScale:.22,gas:[],fpsCap:60},lite:{dpr:.75,maxPixels:95e4,bloomScale:.24,gas:[2],fpsCap:60},balanced:{dpr:1,maxPixels:22e5,bloomScale:.34,gas:[0,2],fpsCap:60},high:{dpr:1.25,maxPixels:32e5,bloomScale:.42,gas:[0,1,2,3,4],fpsCap:60}};function Xr(){return Yb[Xn]}function kf(){const i=Xr(),e=Math.max(.5,window.devicePixelRatio||1);return Nt&&!Bf?Math.min(e,1.25,Math.sqrt(22e5/Math.max(1,innerWidth*innerHeight))):Math.min(e,i.dpr,Math.sqrt(i.maxPixels/Math.max(1,innerWidth*innerHeight)))}const jb={get mode(){return Xn},get pixelRatio(){return Pt.getPixelRatio()},get maxPixels(){return Xr().maxPixels},get visibleGas(){return wn.layers.filter(i=>i.visible).length},get adaptations(){return eu},get drawCalls(){return Pt.info.render.calls},get textures(){return Pt.info.memory.textures}};ln&&(window.__orionPerformance=jb);let Ah=0;function $b(i){Sl.textContent=i,Sl.hidden=!1,clearTimeout(Ah),Ah=setTimeout(()=>{Sl.hidden=!0},5500)}document.getElementById("leave").addEventListener("click",()=>$b("Protótipo visual: não há conta conectada para sair."));Mc.addEventListener("input",()=>{mn=Number(Mc.value),Uf.textContent=mn.toFixed(1).replace(".",",")+"×"});window.addEventListener("keydown",i=>{i.key.toLowerCase()==="d"&&!["INPUT","TEXTAREA"].includes(document.activeElement.tagName)&&(js.hidden=!js.hidden)});let Pt;try{Pt=new ay({antialias:Nt||Xn==="high",alpha:!0,powerPreference:"high-performance"})}catch(i){throw bc.textContent="WebGL indisponível neste navegador. Tente no Chrome com aceleração de hardware ativada.",i}Pt.setPixelRatio(kf());Pt.setSize(innerWidth,innerHeight);Pt.outputColorSpace=_t;Pt.toneMapping=Nh;Pt.toneMappingExposure=1.24;Pt.info.autoReset=!1;Hb.appendChild(Pt.domElement);const Ln=new ef,ut=new Kt(52,innerWidth/innerHeight,.2,900),qr=new At,po=new At,mo=new At,go=new At;Ln.add(qr);qr.add(po);po.add(mo);mo.add(go);go.add(ut);qr.position.set(0,0,26);ut.position.set(0,0,0);const vt=Ai==="mesh"?nb(ut,{enabled:Ei,reducedMotion:at,animation:["mesh","rig","perspective"].includes(Yn.get("handsMotion"))?Yn.get("handsMotion"):"perspective",touchLayout:xt}):Ai==="overlay"?qS(Pn,{enabled:Ei,reducedMotion:at}):Ai==="2d"?Uy(ut,{enabled:Ei,reducedMotion:at}):Ai==="3d"?Vy(ut,{enabled:Ei,reducedMotion:at}):Ai==="rig"?TS(ut,{enabled:Ei,reducedMotion:at}):Ai==="vr"?DS(ut,{enabled:Ei,reducedMotion:at}):XS(ut,{enabled:Ei,reducedMotion:at});vt.state.mode=Ai;ln&&(window.__orionHandsDebug=vt);const Ji=[],Kb=new Qs;function zf(i){const e=Kb.load(i,void 0,void 0,t=>console.warn("[nebula]",i,t));return e.colorSpace=_t,e.anisotropy=1,e.minFilter=Gt,e.magFilter=Lt,e.generateMipmaps=!0,e}function tr(i,e,t,n,s,r,a,o=2048/768,c={}){const l=new Ut({map:zf(i),transparent:!0,opacity:t,depthTest:!1,depthWrite:!1,toneMapped:!1,side:Mt,blending:c.additive?gn:Ci}),u=new pt(new _n(1,1),l);return u.position.set(n,s,e),u.renderOrder=a,u.userData.factor=r,u.userData.aspect=o,u.userData.layerName=c.name||i.split("/").pop(),Ln.add(u),Ji.push(u),u}const Zb=tr("/assets/00-starfield-base.jpg",-700,1,0,0,1.58,-1,2,{name:"00 · Fundo espacial"});Zb.visible=!1;const Vf=tr("/assets/01-nebula-far.webp",-360,.11,0,-5,1.53,1,3072/1152,{name:"01 · Nebulosa distante"});Vf.visible=!1;const Li=tr(Nt?If():"/assets/nebula-eso-photographic.jpg",-540,1,0,-3,1.31,2,Nt?16/9:5e3/1850,{name:Nt?"Interior da nebulosa":"02 · Via Láctea fotográfica · ESO"});Li.material.color.setRGB(.43,.46,.53);Nt&&Li.material.color.setRGB(.55,.56,.68);const eo=Sy(Li,ut),Jb=tr("/assets/03-mid-clouds.webp",-155,.031,-2,-4,1.42,3,3072/1152,{name:"03 · Detalhe da nebulosa",additive:!0}),Qb=tr("/assets/04-front-fog.png",-92,.027,9,-10,1.56,4,2560/960,{name:"04 · Névoa frontal",additive:!0}),Hf=tr("/assets/05-star-dust.png",-58,.062,0,0,1.62,5,3072/1152,{name:"05 · Poeira estelar",additive:!0});Hf.visible=!1;const tu=[{mesh:Vf,base:.11,amp:.045,rate:.43,phase:.5},{mesh:Jb,base:.031,amp:.052,rate:.59,phase:1.8},{mesh:Qb,base:.027,amp:.048,rate:.49,phase:3.1},{mesh:Hf,base:.062,amp:.03,rate:.69,phase:2.6}],As={gas:1,star:1,beacon:0},wn=uy(Ln,{reducedMotion:at||xt});Ji.push(...wn.layers);if(Nt)for(const i of tu)i.mesh.visible=!1;const wh={reducedMotion:at||xt&&!Nt,parallaxEnabled:Gb&&(!Nt||!xt),foregroundEnabled:Wb},Zt=Nt?_b(Ln,Li,wh):Iy(Ln,Li,wh);Ji.push(...Zt.layers);function Gf(){const i=new Set(Nt||Qa==="no-gas"?[]:Xr().gas);wn.layers.forEach((e,t)=>{e.visible=i.has(t)}),Zt.applyQuality(Xn)}Gf();if(ln){const i=document.createElement("fieldset");i.className="layer-inspector";const e=document.createElement("legend");e.textContent="Camadas da nebulosa",i.appendChild(e);for(const s of Ji){const r=document.createElement("label");r.className="layer-switch";const a=document.createElement("input");a.type="checkbox",a.checked=s.visible,a.addEventListener("change",()=>{s.visible=a.checked});const o=document.createElement("span");o.textContent=s.userData.layerName,r.append(a,o),i.appendChild(r)}js.appendChild(i);const t=document.createElement("fieldset");t.className="layer-inspector",t.innerHTML="<legend>Nebulosa Viva</legend>";const n=(s,r,a,o,c,l)=>{const u=document.createElement("label");u.className="atmosphere-slider";const d=document.createElement("span");d.textContent=s;const h=document.createElement("output");h.textContent=Number(r).toFixed(2);const p=document.createElement("input");p.type="range",p.min=String(a),p.max=String(o),p.step=String(c),p.value=String(r),p.setAttribute("aria-label",s),p.addEventListener("input",()=>{const g=Number(p.value);h.textContent=g.toFixed(2),l(g)}),u.append(d,h,p),t.appendChild(u)};n("Densidade do gás",wn.state.density,0,1.5,.05,wn.setDensity),n("Fluxo orgânico",wn.state.flow,0,1,.05,wn.setFlow),n("Paralaxe da nebulosa",Zt.state.parallaxStrength,.45,1.6,.05,Zt.setParallaxStrength),window.__orionBloomSliderFactory=n,js.appendChild(t)}const nu=[],vo=new At;Ln.add(vo);function _o(i,e,t,n,s,r,a,o={}){const c=new Float32Array(i*3),l=new Float32Array(i),u=new Float32Array(i),d=new Float32Array(i),h=new Float32Array(i),p=new Float32Array(i),g=new Float32Array(i*3),v=a.map(A=>new Re(A)),m=Math.tan(_e.degToRad(52/2)),f=innerWidth/innerHeight,_=43/496;for(let A=0;A<i;A++){const E=A*3;let M,C,b,S,I,D=0;do{M=(Math.random()-.5)*n,C=(Math.random()-.5)*s,b=e+Math.random()*(t-e);const O=26-b;S=M/O/(m*f),I=(C/O-_)/m,D++}while((S/.51)**2+(I/.42)**2<1&&D<150);c[E]=M,c[E+1]=C,c[E+2]=b,l[A]=r[0]+Math.random()*(r[1]-r[0]),u[A]=Math.random()*6.283;const w=o.group?{low:.46,high:1.05,min:.04,max:.11}:t<-255?{low:.2,high:.66,min:.035,max:.095}:t<-95?{low:.32,high:.91,min:.05,max:.14}:{low:.55,high:1.23,min:.07,max:.17};d[A]=w.low+Math.random()*(w.high-w.low),h[A]=w.min+Math.random()*(w.max-w.min),p[A]=Math.random()*6.283;const U=v[Math.floor(Math.random()*v.length)];g[E]=U.r,g[E+1]=U.g,g[E+2]=U.b}const x=new It;x.setAttribute("position",new ct(c,3)),x.setAttribute("aSize",new ct(l,1)),x.setAttribute("aPhase",new ct(u,1)),x.setAttribute("aTwinkleRate",new ct(d,1)),x.setAttribute("aTwinkleAmp",new ct(h,1)),x.setAttribute("aTwinkleSecondary",new ct(p,1)),x.setAttribute("aColor",new ct(g,3));const y=new Rt({transparent:!0,depthWrite:!1,blending:gn,uniforms:{uTime:{value:0},uDpr:{value:Math.min(devicePixelRatio||1,2)},uOpacity:{value:1}},vertexShader:`
      attribute float aSize;attribute float aPhase;attribute float aTwinkleRate;attribute float aTwinkleAmp;attribute float aTwinkleSecondary;attribute vec3 aColor;
      uniform float uTime;uniform float uDpr;uniform float uOpacity;
      varying vec3 vColor;varying float vOpacity;
      void main(){
        vec4 mv=modelViewMatrix*vec4(position,1.0);
        gl_Position=projectionMatrix*mv;
        gl_PointSize=clamp(aSize*96.0/max(5.0,-mv.z)*uDpr,0.6,3.7);
        vColor=aColor;
        // Estrelas não cintilam em sincronismo. Cada ponto tem frequência,
        // amplitude e segunda fase independente (sem gasto extra de draw calls).
        float low=sin(uTime*aTwinkleRate+aPhase);
        float irregular=sin(uTime*(aTwinkleRate*1.753+.12)+aTwinkleSecondary);
        vOpacity=clamp(.61+low*aTwinkleAmp*.40+irregular*aTwinkleAmp*.18,.32,.78)*uOpacity;
      }`,fragmentShader:`
      varying vec3 vColor;varying float vOpacity;
      void main(){
        float r=length(gl_PointCoord-vec2(.5));
        float alpha=(1.0-smoothstep(.1,.48,r))*vOpacity;
        gl_FragColor=vec4(vColor,alpha);
      }`});y.userData.baseOpacity=o.opacity??1,nu.push(y),(o.group||vo).add(new Gc(x,y))}_o(110,-540,-270,1100,570,[1.3,3.2],["#c1cce1","#8791c8","#d5c9c4"],{opacity:.38});_o(28,-255,-105,510,290,[.8,2],["#c9d0ed","#a99cc9","#d5c8a9"],{opacity:.34});_o(8,-95,-15,250,140,[.6,1.15],["#bfc6dd","#a5a8ce","#d2c8bc"],{opacity:.28});const xo=new At;Ln.add(xo);_o(0,-56,-6,128,72,[.65,1],["#d6dfff","#d3baff","#f7eacf"],{group:xo,opacity:0});ln&&(window.__orionDepthDebug={rigRoot:qr,rigYaw:po,rigPitch:mo,rigRoll:go,camera:ut,foregroundParticles:xo,layers:Ji,nebulaMotion:Zt.state});const yo=new N(0,43,-470),to=yo.clone();let on=new At;on.position.copy(yo);Ln.add(on);function eM(){const i=document.createElement("canvas");i.width=i.height=512;const e=i.getContext("2d"),t=e.createRadialGradient(256,256,5,256,256,245);t.addColorStop(0,"rgba(255,255,255,1)"),t.addColorStop(.03,"rgba(255,252,233,1)"),t.addColorStop(.08,"rgba(255,222,158,.87)"),t.addColorStop(.18,"rgba(249,209,133,.34)"),t.addColorStop(.42,"rgba(225,190,122,.105)"),t.addColorStop(1,"rgba(215,185,140,0)"),e.fillStyle=t,e.fillRect(0,0,512,512);const n=[[0,1.4,190],[1.4,0,192],[-.7,.7,96],[.7,.7,96]];e.save(),e.translate(256,256);for(const[r,a,o]of n){const c=Math.hypot(r,a),l=r/c,u=a/c;for(const d of[-1,1]){const h=e.createLinearGradient(0,0,l*o*d,u*o*d);h.addColorStop(0,"rgba(255,250,237,.7)"),h.addColorStop(1,"rgba(255,250,237,0)"),e.strokeStyle=h,e.lineWidth=r===0||a===0?1.6:.7,e.beginPath(),e.moveTo(0,0),e.lineTo(l*o*d,u*o*d),e.stroke()}}e.restore();const s=new co(i);return s.colorSpace=_t,s}const tM=eM();function So(i,e){const t=new kr({map:tM,transparent:!0,opacity:e,blending:gn,depthWrite:!1,depthTest:!1,toneMapped:!1}),n=new oo(t);return n.scale.set(i,i,1),n.renderOrder=12,on.add(n),n}let Qi=new oo(new kr({map:zf("/assets/06-star-glow.png"),transparent:!0,opacity:.16,blending:gn,depthTest:!1,depthWrite:!1,toneMapped:!1}));Qi.scale.set(60,60,1);Qi.renderOrder=10;on.add(Qi);let bo=So(47,.25),Mo=So(22,.8),Eo=So(7,1),Yr=new pt(new uo(7.25,7.28,144),new Ut({color:15257490,transparent:!0,opacity:.015,side:Mt,depthWrite:!1,depthTest:!1}));Yr.renderOrder=14;on.add(Yr);let es=So(178,0);es.renderOrder=11;es.layers.enable(1);let jr=yf(on,{reducedMotion:at}),Di=new oo(new kr({color:16777215,transparent:!0,opacity:0,depthTest:!1,depthWrite:!1}));Di.scale.setScalar(56);Di.layers.set(2);Di.renderOrder=0;on.add(Di);const no=new Mg;no.layers.set(2);const Rh=new Ie;Qi.layers.enable(1);bo.layers.enable(1);Mo.layers.enable(1);Eo.layers.enable(1);const Wf=tp(Yn),Ni=Wf.length===0,nM={id:"new-herald",name:"Sua primeira estrela",subtitle:"Um novo começo",creation:!0,stats:{level:"—",origin:"—",trail:"—",rank:"—",em:"—",ec:"—"}},iM=Ni||Nt?[nM]:Wf;Pn.dataset.empty=String(Ni);Ni&&(Pi.textContent="Uma nova história espera por você");const Ch={group:on,glows:{halo:Qi,soft:bo,main:Mo,core:Eo},orbit:Yr,beacon:es,spikes:jr,pick:Di,target:Zi},Ct=iM.map((i,e)=>{let t=Ch;if(e){const n=new At;Ln.add(n);const s=o=>{const c=o.clone();return c.material=o.material.clone(),n.add(c),c},r=Object.fromEntries(Object.entries(Ch.glows).map(([o,c])=>[o,s(c)])),a=Zi.cloneNode(!1);a.id=`heraldTarget-${i.id}`,Zi.parentNode.insertBefore(a,Wt),t={group:n,glows:r,orbit:s(Yr),beacon:s(es),pick:s(Di),target:a,spikes:yf(n,{reducedMotion:at,sharedTexture:jr.primary.material.map})}}return t.pick.userData.heraldIndex=e,t.target.setAttribute("aria-label",i.creation?"Criar meu primeiro arauto":`Selecionar ${i.name}${i.demo?", estrela de demonstração":", arauto ativo, nível 9"}`),{data:i,...t,basePosition:new N,screen:{x:NaN,y:NaN},focus:0}});let rn=Ct[0],Cn=null;document.getElementById("heraldCount").textContent=Ni?"Sua primeira história":Ct.length===1?"1 arauto ativo":`${Ct.length} estrelas · prévia`;const iu=ip(Ys);function sM(){const i=rn.data;document.getElementById("heraldName").textContent=i.name,document.getElementById("heraldSubtitle").textContent=i.subtitle,document.getElementById("heraldStatus").textContent=i.demo?"Demonstração":"Arauto ativo",Wt.setAttribute("aria-label",`Resumo de ${i.name}`),document.getElementById("dismissHerald").setAttribute("aria-label",`Fechar resumo de ${i.name}`);for(const e of Wt.querySelectorAll("[data-herald-stat]"))e.textContent=i.stats[e.dataset.heraldStat];su=Wt.offsetHeight}function Ls(i){if(i===rn)return!0;if(St||Ht.state.active||Cn)return!1;rn=i,Zi=i.target,on=i.group,{halo:Qi,soft:bo,main:Mo,core:Eo}=i.glows,Yr=i.orbit,es=i.beacon,jr=i.spikes,Di=i.pick,yo.copy(i.group.position),to.copy(i.basePosition),Ht=i.selection,sM();for(const e of Ct)e.target.setAttribute("aria-expanded",String(In&&e===i));return In&&(Pi.textContent=`${i.data.name} · ${xt?"Escolha":"Clique para"} atravessar o véu`),!0}const Ds=xy(Pt,Ln,ut,{initial:xt?.1:.18,reducedMotion:at});ln&&(window.__orionBloomSliderFactory("Bloom seletivo",Ds.state.intensity,0,1.5,.05,Ds.setIntensity),window.__orionAtmosphereDebug={atmosphere:wn,selectiveBloom:Ds},window.__orionRespirationDebug={state:As,veils:tu,nebula:Li,get beaconGlow(){return es},get heraldGroup(){return on}},window.__orionCinematicDebug={get spikes(){return jr},starsGroup:vo,foregroundParticles:xo},delete window.__orionBloomSliderFactory);let sn={x:0,y:0},pn={x:0,y:0},In=!1,St=!1,Xf=0,Es=0,Ec=!1,su=Wt.offsetHeight;const Mn={cx:NaN,cy:NaN,focusAt:0,focusX:NaN,focusY:NaN},Ns={pointerEvents:0,raycasts:0,focusWrites:0};ln&&(window.__orionInteractionMetrics={get pointerEvents(){return Ns.pointerEvents},get raycasts(){return Ns.raycasts},get focusWrites(){return Ns.focusWrites}});const rM={get x(){return pn.x},get y(){return pn.y},get targetX(){return sn.x},get targetY(){return sn.y},get volumeLayers(){return Zt.layers.length}};ln&&(window.__orionMotionDebug=rM);let Tr=performance.now();const bl=new N;function aM(){for(const a of Ct){bl.copy(a.group.position).project(ut);const o=(bl.x*.5+.5)*innerWidth,c=(-bl.y*.5+.5)*innerHeight;!Number.isFinite(o)||!Number.isFinite(c)||(!Number.isFinite(a.screen.x)||Math.abs(o-a.screen.x)>.45||Math.abs(c-a.screen.y)>.45)&&(a.target.style.left=o.toFixed(1)+"px",a.target.style.top=c.toFixed(1)+"px",a.screen.x=o,a.screen.y=c)}const{x:i,y:e}=rn.screen;vt.setStarDirection?.((i/innerWidth-.5)*2,(.5-e/innerHeight)*2),St&&(Ys.style.setProperty("--arrival-x",(i/innerWidth*100).toFixed(2)+"%"),Ys.style.setProperty("--arrival-y",(e/innerHeight*100).toFixed(2)+"%"));const t=performance.now();if(t-Mn.focusAt>90&&(!Number.isFinite(Mn.focusX)||Math.abs(i-Mn.focusX)>2||Math.abs(e-Mn.focusY)>2)&&(Pn.style.setProperty("--nox-focus-x",(i/innerWidth*100).toFixed(1)+"%"),Pn.style.setProperty("--nox-focus-y",(e/innerHeight*100).toFixed(1)+"%"),Mn.focusAt=t,Mn.focusX=i,Mn.focusY=e,Ns.focusWrites++),xt)return;const n=265,s=_e.clamp(i+170+n<innerWidth-15?i+119:i-150-n,12,innerWidth-n-12),r=_e.clamp(e-93,110,Math.max(112,innerHeight-su-18));(!Number.isFinite(Mn.cx)||Math.abs(s-Mn.cx)>.5||Math.abs(r-Mn.cy)>.5)&&(Wt.style.left=s.toFixed(1)+"px",Wt.style.top=r.toFixed(1)+"px",Mn.cx=s,Mn.cy=r)}function wi(i){if(!Nt){if(Ni){if(St||Ht.state.active)return;vt.setStarHovered?.(i),Pi.textContent="Clique na estrela para começar sua história";return}if(!(St||Ht.state.active)){In=i,Pn.dataset.summary=String(i),Wt.classList.toggle("visible",i),Wt.setAttribute("aria-hidden",String(!i)),Wt.inert=!i;for(const e of Ct)e.target.setAttribute("aria-expanded",String(i&&e===rn));vt.setStarHovered?.(i),Pi.textContent=i?`${rn.data.name} · ${xt?"Escolha":"Clique para"} atravessar o véu`:Ff}}}function $r(i=!1){St||Ht.state.active||(i&&(Ec=!0,Zi.focus({preventScroll:!0}),Ec=!1),wi(!1))}document.getElementById("dismissHerald").addEventListener("click",()=>$r(!0));document.getElementById("confirmHerald").addEventListener("click",()=>{In&&io()});window.addEventListener("keydown",i=>{i.key==="Escape"&&In&&(i.preventDefault(),$r(!0))});const ci=xt?Vb({root:Pn,heralds:Ct,reducedMotion:at,isLocked:()=>St||!!Cn,onChange:i=>{$r(),Ls(i),Pi.textContent=`${i.data.name} · Toque na estrela para conhecer`}}):null,ru=xt?zb({root:Pn,isLocked:()=>St||!!Cn,onDismiss:()=>$r(),onSwipe:i=>ci.step(i)}):null;ln&&(window.__orionMobileDebug=ci);ln&&(window.__orionTouchDebug=ru);for(const i of Ct){const e=i.target;e.addEventListener("mouseenter",()=>{!xt&&Ls(i)&&wi(!0)}),e.addEventListener("mouseleave",()=>{xt||wi(!1)}),e.addEventListener("focus",()=>{!Ec&&(!xt||e.matches(":focus-visible"))&&Ls(i)&&wi(!0)}),e.addEventListener("blur",()=>{xt||wi(!1)}),e.addEventListener("click",t=>{if(!(St||Ht.state.active||!Ls(i))){if(Ni){io(i);return}if(xt){if(!ci.state.settled)return;wi(!0);return}if(t.detail===0&&!In){wi(!0);return}io(i)}})}function qf(i,e){if(St||Nt)return null;const t=Math.max(120,innerHeight*.15),n=Ct.filter(r=>Math.abs(i-r.screen.x)<=t&&Math.abs(e-r.screen.y)<=t);if(!n.length)return null;Ns.raycasts++,Rh.set(i/innerWidth*2-1,1-e/innerHeight*2),ut.updateWorldMatrix(!0,!1);for(const r of n)r.group.updateWorldMatrix(!0,!0);no.setFromCamera(Rh,ut);const s=no.intersectObjects(n.map(r=>r.pick),!1)[0];return s?Ct[s.object.userData.heraldIndex]:null}window.addEventListener("pointermove",i=>{if(qs){!xt&&i.pointerType!=="touch"&&(sn.x=(i.clientX/innerWidth-.5)*2,sn.y=(.5-i.clientY/innerHeight)*2),qs.point(i);return}if(xt||i.pointerType==="touch"||St||Ht.state.active)return;Ns.pointerEvents++,sn.x=(i.clientX/innerWidth-.5)*2,sn.y=(.5-i.clientY/innerHeight)*2;const e=qf(i.clientX,i.clientY),t=Ct.find(s=>document.activeElement===s.target&&s.target.matches(":focus-visible"));(e||t)&&Ls(e||t);const n=!!(e||t);document.body.classList.toggle("star-aimed",!!e),vt.setStarHovered?.(n),In!==n&&wi(n)},{passive:!0});const au=()=>{$r(),document.body.classList.remove("star-aimed"),vt.setStarHovered?.(!1)};document.documentElement.addEventListener("pointerleave",i=>{i.pointerType!=="touch"&&au()});window.addEventListener("blur",au);window.addEventListener("pointerdown",i=>{if(i.pointerType==="touch"||St||Ht.state.active||i.button!==0||i.target.closest("a,button,input,.debug"))return;const e=qf(i.clientX,i.clientY);e&&(i.preventDefault(),io(e))});const Ur=My({scene:Ln,camera:ut,star:on,glows:{halo:Qi,soft:bo,main:Mo,core:Eo},layers:Ji,gasLayers:wn.layers,selectiveBloom:Ds,flash:Ys,sky:eo,reducedMotion:at,onArrive:()=>{try{sessionStorage.setItem("orion-last-trip-v09",JSON.stringify({heraldId:Cn.data.id,passedGasLayers:wn.layers.filter(i=>ut.position.z<i.position.z).length,endZ:ut.position.z,starZ:on.position.z}))}catch{}iu.navigate(Lh(location.href,Cn.data))}});for(const i of Ct)i.selection=wy(i.group,{camera:ut,hands:vt,reducedMotion:at,onDepart:Ih,onConfirm:Ih});let Ht=rn.selection;ln&&(window.__orionStarDebug={journey:Ur,get selection(){return Ht},get heraldGroup(){return on},get heraldPickSprite(){return Di},raycaster:no,heralds:Ct,get selectedHeraldId(){return Cn?.data.id},transition:iu.state,sky:eo});function io(i=rn){if(!(St||!Ls(i)||!Ht.begin())){if(Cn=i,xt&&(Pn.dataset.confirming="true",document.getElementById("starBrowser").inert=!0),i.data.creation)for(const e of Object.values(Za)){if(document.querySelector(`link[data-creation-preload="${e}"]`))continue;const t=document.createElement("link");t.rel="prefetch",t.as="image",t.href=e,t.dataset.creationPreload=e,document.head.append(t)}iu.prepare(Lh(location.href,i.data)),Xf=performance.now(),ru?.cancel(),In=!1,Wt.classList.remove("visible"),Wt.setAttribute("aria-hidden","true"),Wt.inert=!0,Zi.setAttribute("aria-expanded","false"),document.body.classList.remove("star-aimed"),Pi.textContent=`${i.data.name} selecionada · Atravessando o véu…`}}function Ih(){if(!St&&(Ur.setDestination(Cn.group,Cn.glows),!!Ur.begin())){for(const i of Ct)i.beacon.visible=!1,i!==Cn&&i.group.traverse(e=>{e.material&&(e.userData.departureOpacity=e.material.opacity)});St=!0,vt.setStarHovered?.(!1),vt.beginTravel(),In=!1,Wt.classList.remove("visible"),Wt.setAttribute("aria-hidden","true"),Wt.inert=!0,Zi.setAttribute("aria-expanded","false"),Pn.classList.add("jumping"),document.body.classList.remove("star-aimed"),Pi.textContent="Atravessando o véu…"}}function ou(){if(su=Wt.offsetHeight,ut.aspect=innerWidth/innerHeight,ut.updateProjectionMatrix(),!St&&!Cn){const i=xt?Of(Ct.length,ut.aspect,ci.state.position,ci.state.summary):sp(Ct.length,ut.aspect);Ct.forEach((e,t)=>{const n=Ni?{x:0,y:0,z:-470,scale:1}:i[t];e.group.position.set(n.x,n.y,n.z),e.group.scale.setScalar(n.scale),e.basePosition.copy(e.group.position)}),yo.copy(rn.group.position),to.copy(rn.basePosition)}vt.resize(),Pt.setPixelRatio(kf()),Pt.setSize(innerWidth,innerHeight),Ds.resize(innerWidth,innerHeight,Xr().bloomScale);for(const i of Ji){if(i.userData.volumeFragment||i===Li&&eo.state.active)continue;const e=26-i.position.z,t=2*Math.tan(_e.degToRad(52/2))*e*i.userData.factor;i.scale.set(t*i.userData.aspect,t,1)}eo.state.active||Zt.resize();for(const i of nu)i.uniforms.uDpr.value=Pt.getPixelRatio()}window.addEventListener("resize",ou);ou();window.addEventListener("pageshow",i=>{i.persisted&&St&&location.reload()});const so=ln?Ny(js,()=>({quality:Xn,effects:Qa,bloomRest:Xn!=="eco"&&Qa!=="no-bloom",canvasPixels:Pt.domElement.width*Pt.domElement.height,dpr:Number(Pt.getPixelRatio().toFixed(2)),gasLayers:wn.layers.filter(i=>i.visible).length,volumeLayers:Zt.layers.filter(i=>i.visible).length,foregroundNear:Zt.layers.some(i=>i.visible&&i.userData.volumeFragment&&i.position.z>-100),handsVisible:vt.state.visible,handsSurfaces:vt.state.drawSurfaces,handsMode:vt.state.mode,handsTriangles:vt.state.triangles||0,handsTextures:vt.state.textureCount,handsReady:vt.state.loaded??vt.state.enabled,handsJoints:vt.state.joints||0,handsFingerJoints:vt.state.fingerJoints||0,handsLoadError:vt.state.loadError||null,depthMotion:Zt.state.parallaxEnabled,parallaxStrength:Zt.state.parallaxStrength,drawCalls:Pt.info.render.calls,textures:Pt.info.memory.textures,mouseDeltaPx:Number(Math.hypot((pn.x-sn.x)*innerWidth*.5,(pn.y-sn.y)*innerHeight*.5).toFixed(1)),adaptations:eu,viewport:innerWidth+"×"+innerHeight})):null;ln&&(window.__orionDiagnostic=so);let Ts=0,Tc=performance.now(),Va=0,Ha=0,_r=0;function oM(i,e){if(St||document.hidden||at||(Va+=e,Ha++,i-Tc<3e3))return;const t=Va/Math.max(1,Ha);Tc=i,Va=0,Ha=0,_r=t>32?_r+1:Math.max(0,_r-1),_r>=2&&!Bf&&Xn!=="eco"&&(Xn=Th[Math.max(0,Th.indexOf(Xn)-1)],eu++,_r=0,Gf(),ou())}document.addEventListener("visibilitychange",()=>{document.hidden&&(ru?.cancel(),au()),document.hidden||(Tr=performance.now(),Tc=Tr,Va=0,Ha=0,so?.reset())});let Ph=0;function Yf(i){if(requestAnimationFrame(Yf),Nt&&document.documentElement.dataset.paperActive==="1"){Tr=i,Ts=i;return}if(document.hidden)return;const e=Xr();if(!St&&e.fpsCap<60&&Ts&&i-Ts<1e3/e.fpsCap-1)return;const t=Ts?i-Ts:16.67,n=Math.min(100,t);Ts=i,so?.record(i,t),oM(i,n);const s=Math.max(0,(i-Tr)/1e3),r=Math.min(s,.05);Tr=i;const a=i*.001;if(Ht.update(Math.min(s,Math.max(0,(i-Xf)/1e3))),St)es.visible=!1,Ur.update(i,r);else{if(xt&&!Cn){ci.update(s,In);const _=Of(Ct.length,ut.aspect,ci.state.position,ci.state.summary);Ct.forEach((x,y)=>{const A=Ni?{x:0,y:0,z:-470,scale:1}:_[y];x.group.position.set(A.x,A.y,A.z),x.group.scale.setScalar(A.scale),x.basePosition.copy(x.group.position)}),to.copy(rn.basePosition)}else xt||on.position.copy(to);vo.position.z=0;const o=at?1:1-Math.exp(-Math.max(.001,r)*(Nt?4:18)),c=Nt?.35:1;pn.x=_e.lerp(pn.x,sn.x,o),pn.y=_e.lerp(pn.y,sn.y,o);const l=at?0:Math.sin(a*.29)*.23;qr.position.set(xt?ci.state.position*8:pn.x*6.8*mn*c,pn.y*4.35*mn*c+l,26+(at?0:Math.sin(a*.21)*.25)),po.rotation.y=-pn.x*.068*mn*c,mo.rotation.x=pn.y*.052*mn*c,go.rotation.z=at||xt?0:-pn.x*.011*mn*c+Math.sin(a*.27)*.0015;const u=In||Ht.state.active,d=u?1:0;Es=at?0:_e.lerp(Es,d,1-Math.exp(-r*12)),Math.abs(Es-d)<5e-4&&(Es=d),ut.position.z=-.9*Es;const h=52-Es;Math.abs(ut.fov-h)>.001&&(ut.fov=h,ut.updateProjectionMatrix());const p=at?0:Math.sin(a*.42+.6),g=at?0:Math.sin(a*.24+1.5);As.gas=1+.019*p+.011*g;for(const _ of tu){const x=at?0:.68*Math.sin(a*_.rate+_.phase)+.32*Math.sin(a*_.rate*.57+_.phase*1.73);_.mesh.material.opacity=_.base*(1+_.amp*x+(As.gas-1)*.5)}const v=at?0:Math.sin(a*.77+.4),m=at?0:.65*Math.sin(a*2.16+1.1)+.35*Math.sin(a*3.24+2.4),f=at?0:Math.pow(Math.max(0,Math.cos(a*.7392-1.35)),10);As.beacon=f,As.star=1+.028*v+.013*m;for(const _ of Ct){const{halo:x,soft:y,main:A,core:E}=_.glows,{beacon:M,orbit:C}=_;_.focus=at?0:_e.lerp(_.focus,_===rn&&u?1:0,1-Math.exp(-r*12));const b=1+.22*_.focus;if(x.scale.setScalar(156*(As.star+.055*f)*b),y.scale.setScalar(118*(1+.034*v+.045*f)*b),A.scale.setScalar(66*(1+.048*v+.022*m+.075*f)*b),E.scale.setScalar(18*(1+.026*m)*(1+.18*_.focus)),x.material.opacity=.075+.045*_.focus+.012*v+.028*f,y.material.opacity=.13+.085*_.focus+.012*v+.024*f,A.material.opacity=.48+.19*_.focus+.015*m+.04*f,E.material.opacity=.94,M.scale.setScalar(154+42*f),M.material.opacity=.046*f*(1+.55*_.focus),C.material.opacity=0,_===rn&&Ht.state.active){const S=Ht.state.light,I=Ht.state.charge,D=Ht.state.burst;A.material.opacity+=.3*S,y.material.opacity+=.22*I+.18*D,x.material.opacity+=.12*D,A.scale.multiplyScalar(1+.12*I+.22*D),E.scale.multiplyScalar(1+.12*I+.45*D),x.scale.multiplyScalar(1+.1*I+.12*D)}}Zt.update(a,sn.x,sn.y,r),Ys.style.opacity="0",Ys.style.setProperty("--veil-opacity","0")}qs?.update(i),vt.update(a,r,sn.x,sn.y),qs?.finishFrame();for(const o of nu)o.uniforms.uTime.value=at?0:a,o.uniforms.uOpacity.value=o.userData.baseOpacity*(St?1.24:1);jr.update(a,In||Ht.state.active,St);for(const o of Ct)if(o!==rn&&(o.spikes.update(a,!1,St),St)){const c=Ur.companionOpacity;o.group.traverse(l=>{l.material&&(l.material.opacity=l.userData.departureOpacity*c)})}ut.updateWorldMatrix(!0,!1),aM(),wn.update(a),Ph++,Pt.info.reset(),Ds.render(St||Ph%2===1,St||Xn!=="eco"&&Qa!=="no-bloom"),so?.refresh(i)}if(Nt){Pn.classList.add("creation-scene");for(const i of Ct)i.group.visible=!1,i.target.hidden=!0,i.target.inert=!0;qs=kb(Pn,{hands:vt,reducedMotion:at,scene:Ln,camera:ut,environment:Zt}),ln&&(window.__orionCreationEnvironment={state:Zt.state,layers:Zt.layers,photo:Li})}requestAnimationFrame(Yf);document.documentElement.dataset.sceneReady="1";const lM=new Promise((i,e)=>{const t=new Image;t.onload=i,t.onerror=()=>e(new Error("Não foi possível carregar o fundo.")),t.src=Nt?If():"/assets/nebula-eso-photographic.jpg"});Promise.all([lM,vt.ready,qs?.ready]).then(async()=>{if(vt.state.loadError)throw new Error(vt.state.loadError);await new Promise(i=>requestAnimationFrame(()=>requestAnimationFrame(i))),document.documentElement.dataset.presentationReady="1",bc.classList.add("done"),Nt&&await np()}).catch(i=>{document.documentElement.dataset.sceneError=i.message,document.getElementById("loadErrorText").textContent=i.message,document.getElementById("loadIssue").hidden=!1,bc.hidden=!0});
